
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", var1);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "hi!", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addCategoryLabelToolTip(var2, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Font var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseItemLabelFont(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = null;
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var14 = var2.createHotSpotShape(var3, var4, var5, var7, var8, var9, 100, 100, false, var13);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.labels.ItemLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBasePositiveItemLabelPosition(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.awt.Color var1 = java.awt.Color.getColor("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelInsets(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLegendItemLabelGenerator(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var15 = null;
//     boolean var16 = var2.hitTest(100.0d, 1.0d, var5, var6, var7, var9, var10, var11, 0, 100, false, var15);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    java.awt.Paint var8 = var2.getSeriesFillPaint(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    org.jfree.chart.plot.CategoryPlot var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setPlot(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     var2.setUseOutlinePaint(false);
//     boolean var9 = var2.getItemShapeVisible(0, (-1));
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.util.Layer var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var2.drawAnnotations(var10, var11, var13, var14, var15, var16);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    java.awt.Stroke var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlineStroke(var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.Stroke var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setTickMarkStroke(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getRowKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject((-1), 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.event.DatasetChangeInfo var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.event.DatasetChangeEvent var3 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)(short)100, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var12 = var10.getLegendTextFont(10);
//     java.awt.Paint var16 = var10.getItemPaint(10, 100, true);
//     var2.setSeriesOutlinePaint(2, var16, true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = null;
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var12 = var2.initialise(var7, var8, var9, var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.event.RendererChangeListener var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.removeChangeListener(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Stroke var12 = var2.lookupSeriesOutlineStroke((-1));
    org.jfree.chart.labels.ItemLabelPosition var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseNegativeItemLabelPosition(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
    java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShape((-1), var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    java.awt.Color var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator(1, var1, 10.0f, 0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    var0.clear();

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    boolean var3 = var1.isVisible();
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.Marker var3 = null;
//     org.jfree.chart.util.Layer var4 = null;
//     var0.addRangeMarker(0, var3, var4, false);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.renderer.category.BarPainter var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(2, var4, var5);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesURLGenerator((-1), var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("hi!");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    java.awt.Font var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelFont(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    java.awt.Paint var11 = var2.lookupLegendTextPaint((-1));
    var2.setAutoPopulateSeriesFillPaint(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesLinesVisible((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisLocation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var3, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = var6.getSeriesURLGenerator(1);
//     java.awt.Shape var12 = var6.getItemShape(0, (-1), false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var17 = null;
//     var15.setSeriesFillPaint(10, var17);
//     int var19 = var15.getPassCount();
//     var15.setAutoPopulateSeriesShape(true);
//     java.awt.Paint var22 = var15.getBaseItemLabelPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var28 = var26.getLegendTextFont(10);
//     java.awt.Paint var32 = var26.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("", var32);
//     java.awt.Stroke var34 = var33.getLineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var39 = var37.getLegendTextFont(10);
//     java.awt.Paint var43 = var37.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem("hi!", "", "", "hi!", var12, var22, var34, var43);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var26
//     assertTrue("Contract failed: equals-hashcode on var15 and var26", var15.equals(var26) ? var15.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var37
//     assertTrue("Contract failed: equals-hashcode on var15 and var37", var15.equals(var37) ? var15.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var15
//     assertTrue("Contract failed: equals-hashcode on var26 and var15", var26.equals(var15) ? var26.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var15
//     assertTrue("Contract failed: equals-hashcode on var37 and var15", var37.equals(var15) ? var37.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    java.awt.Paint var12 = var2.getItemOutlinePaint(10, 0, false);
    java.awt.Stroke var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesStroke((-1), var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.plot.Marker var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var5 = var0.removeRangeMarker(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var0.setRangeAxes(var8);
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     var2.setUseOutlinePaint(false);
//     boolean var9 = var2.getItemShapeVisible(0, (-1));
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var12 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     var11.zoomDomainAxes(100.0d, var14, var15, true);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis[] var19 = new org.jfree.chart.axis.ValueAxis[] { var18};
//     var11.setRangeAxes(var19);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var29 = var27.getLegendTextFont(10);
//     java.awt.Paint var33 = var27.getItemPaint(10, 100, true);
//     var24.setAxisLinePaint(var33);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var40 = var38.getLegendTextFont(10);
//     java.awt.Paint var44 = var38.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("", var44);
//     java.awt.Stroke var46 = var45.getLineStroke();
//     java.awt.Paint var47 = var45.getLabelPaint();
//     java.awt.Stroke var48 = var45.getOutlineStroke();
//     var2.drawDomainLine(var10, var11, var21, 1.0d, var33, var48);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    var1.setTickMarksVisible(true);
    org.jfree.chart.util.RectangleInsets var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var3, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    java.awt.Paint var11 = var2.lookupLegendTextPaint((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setItemMargin(1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    org.jfree.chart.util.PaintList var3 = new org.jfree.chart.util.PaintList();
    java.lang.Object var4 = var3.clone();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var7 = var6.getLabelAngle();
    boolean var8 = var3.equals((java.lang.Object)var6);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var6.getCategoryEnd((-1), 0, var11, var12);
    var0.setDomainAxis(var6);
    org.jfree.chart.axis.AxisLocation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var15, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    boolean var10 = var2.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.data.general.Dataset var11 = null;
    org.jfree.chart.event.DatasetChangeInfo var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.event.DatasetChangeEvent var13 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var2, var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject((java.lang.Comparable)100.0f, (java.lang.Object)'4');
//     java.lang.Object var3 = var2.clone();
//     java.lang.Object var4 = var2.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var4
//     assertTrue("Contract failed: equals-hashcode on var3 and var4", var3.equals(var4) ? var3.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var3
//     assertTrue("Contract failed: equals-hashcode on var4 and var3", var4.equals(var3) ? var4.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    java.awt.Font var11 = var2.getSeriesItemLabelFont(1);
    var2.setBaseSeriesVisibleInLegend(false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setItemMargin(1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
//     double var9 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var15 = null;
//     var13.setSeriesFillPaint(10, var15);
//     int var17 = var13.getPassCount();
//     int var18 = var13.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var23 = var21.getSeriesURLGenerator(1);
//     java.awt.Shape var27 = var21.getItemShape(0, (-1), false);
//     var21.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var31 = var21.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var35 = var21.getPositiveItemLabelPosition(1, 0, false);
//     var13.setBaseNegativeItemLabelPosition(var35);
//     var2.setSeriesNegativeItemLabelPosition(100, var35, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var2.", var21.equals(var2) == var2.equals(var21));
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     int var7 = var2.getPassCount();
//     var2.setDataBoundsIncludesVisibleSeriesOnly(true);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var12 = var11.getRangeCrosshairPaint();
//     float var13 = var11.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var14 = var11.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var23 = var21.getLegendTextFont(10);
//     java.awt.Paint var27 = var21.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", var27);
//     java.awt.Stroke var29 = var28.getLineStroke();
//     java.awt.Paint var30 = var28.getLabelPaint();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var37 = var35.getLegendTextFont(10);
//     java.awt.Paint var41 = var35.getItemPaint(10, 100, true);
//     var32.setAxisLinePaint(var41);
//     var28.setLinePaint(var41);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var49 = var47.getLegendTextFont(10);
//     java.awt.Paint var53 = var47.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("", var53);
//     java.awt.Stroke var55 = var54.getLineStroke();
//     var2.drawRangeLine(var10, var11, var15, var16, 10.0d, var41, var55);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var11 = null;
    var10.setFixedRangeAxisSpace(var11);
    boolean var13 = var10.isRangeGridlinesVisible();
    var10.setRangeCrosshairValue(0.0d, true);
    java.awt.geom.Rectangle2D var17 = null;
    java.awt.Paint var19 = null;
    org.jfree.chart.util.PaintList var20 = new org.jfree.chart.util.PaintList();
    java.lang.Object var21 = var20.clone();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var24 = var23.getLabelAngle();
    boolean var25 = var20.equals((java.lang.Object)var23);
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var23.getCategoryEnd((-1), 0, var28, var29);
    double var31 = var23.getFixedDimension();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var37 = var35.getLegendTextFont(10);
    java.awt.Paint var41 = var35.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("", var41);
    java.awt.Stroke var43 = var42.getLineStroke();
    var23.setTickMarkStroke(var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.drawDomainLine(var9, var10, var17, 1.0d, var19, var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.Marker var6 = null;
//     org.jfree.chart.util.Layer var7 = null;
//     var0.addRangeMarker(1, var6, var7, false);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     java.awt.Font var8 = var2.lookupLegendTextFont(0);
//     java.awt.Font var9 = null;
//     var2.setBaseLegendTextFont(var9);
//     java.awt.Font var12 = var2.getLegendTextFont(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var17 = var15.getLegendTextFont(10);
//     java.awt.Paint var21 = var15.getItemPaint(10, 100, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var26 = null;
//     var24.setSeriesFillPaint(10, var26);
//     int var28 = var24.getPassCount();
//     int var29 = var24.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var34 = var32.getSeriesURLGenerator(1);
//     java.awt.Shape var38 = var32.getItemShape(0, (-1), false);
//     var32.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var42 = var32.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var46 = var32.getPositiveItemLabelPosition(1, 0, false);
//     var24.setBaseNegativeItemLabelPosition(var46);
//     var15.setBasePositiveItemLabelPosition(var46);
//     var2.setBasePositiveItemLabelPosition(var46);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var32
//     assertTrue("Contract failed: equals-hashcode on var2 and var32", var2.equals(var32) ? var2.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var2
//     assertTrue("Contract failed: equals-hashcode on var32 and var2", var32.equals(var2) ? var32.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var4 = var3.getRangeCrosshairPaint();
//     var0.addChangeListener((org.jfree.data.event.DatasetChangeListener)var3);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.RenderingSource var6 = null;
//     var1.select(0.05d, (-1.0d), var5, var6);
//     org.jfree.chart.plot.Marker var9 = null;
//     org.jfree.chart.util.Layer var10 = null;
//     var1.addRangeMarker((-1), var9, var10);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    java.util.List var2 = var0.getAnnotations();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisOffset(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var7 = var2.getAutoPopulateSeriesOutlinePaint();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var11 = var10.getRangeCrosshairPaint();
    var10.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var15 = var2.initialise(var8, var9, var10, var13, var14);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var18 = var17.getRangeCrosshairPaint();
    java.util.List var19 = var17.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.mapDatasetToRangeAxes(2, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var0.setRangeAxes(var8);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getLabelAngle();
    var11.setTickMarksVisible(true);
    var0.setDomainAxis(var11);
    java.util.List var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var11.getCategoryMiddle((java.lang.Comparable)false, var17, var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var5 = null;
//     var3.setSeriesFillPaint(10, var5);
//     int var7 = var3.getPassCount();
//     boolean var9 = var3.isSeriesVisible(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = var3.getLegendItemURLGenerator();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.Marker var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var3.drawRangeMarker(var11, var12, var13, var14, var15);
//     org.jfree.chart.LegendItemCollection var17 = new org.jfree.chart.LegendItemCollection();
//     var12.setFixedLegendItems(var17);
//     var0.addAll(var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     int var7 = var2.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
//     java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
//     var2.setBaseShape(var16);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(100.0d, var3, var4, true);
//     var0.setNotify(true);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     org.jfree.chart.plot.PlotState var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var0.draw(var9, var10, var11, var12, var13);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject((java.lang.Comparable)' ', (java.lang.Comparable)(-1));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.util.ShadowGenerator var4 = var0.getShadowGenerator();
    org.jfree.chart.util.RectangleInsets var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisOffset(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject((-1), 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var4 = null;
//     var3.setFixedRangeAxisSpace(var4);
//     var3.setRangeCrosshairLockedOnData(true);
//     boolean var8 = var0.hasListener((java.util.EventListener)var3);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(100.0d, var3, var4, true);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     org.jfree.chart.plot.PlotState var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.draw(var7, var8, var9, var10, var11);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Stroke var11 = var10.getLineStroke();
    org.jfree.chart.util.GradientPaintTransformer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setFillPaintTransformer(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var6 = null;
    var4.setSeriesFillPaint(10, var6);
    int var8 = var4.getPassCount();
    java.awt.Font var10 = var4.lookupLegendTextFont(0);
    java.awt.Shape var12 = var4.lookupSeriesShape(10);
    var0.setShape(10, var12);
    org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity(var12);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var21 = null;
    var19.setSeriesFillPaint(10, var21);
    int var23 = var19.getPassCount();
    java.awt.Font var25 = var19.lookupLegendTextFont(0);
    java.awt.Shape var27 = var19.lookupSeriesShape(10);
    var15.setShape(10, var27);
    org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity(var27);
    var14.setArea(var27);
    org.jfree.data.category.CategoryDataset var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var36 = new org.jfree.chart.entity.CategoryItemEntity(var27, "", "hi!", var33, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)0.5f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.Marker var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var2.drawRangeMarker(var10, var11, var12, var13, var14);
    var2.setAutoPopulateSeriesShape(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxis();
//     org.jfree.data.category.CategoryDataset var5 = var0.getDataset(10);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var0.handleClick(100, 1, var8);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     java.lang.Comparable var7 = null;
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var10.setLowerMargin(10.0d);
//     double var13 = var10.getUpperMargin();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var15 = var14.getRangeCrosshairPaint();
//     float var16 = var14.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var17 = var14.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var19 = null;
//     var18.setFixedRangeAxisSpace(var19);
//     org.jfree.chart.util.PaintList var21 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var25 = var24.getLabelAngle();
//     boolean var26 = var21.equals((java.lang.Object)var24);
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var24.getCategoryEnd((-1), 0, var29, var30);
//     var18.setDomainAxis(var24);
//     var18.setDrawSharedDomainAxis(true);
//     java.awt.Paint var35 = var18.getRangeZeroBaselinePaint();
//     var14.setRangeCrosshairPaint(var35);
//     var10.setAxisLinePaint(var35);
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var40 = null;
//     var39.setFixedRangeAxisSpace(var40);
//     org.jfree.chart.util.RectangleEdge var42 = var39.getDomainAxisEdge();
//     double var43 = var2.getItemMiddle((java.lang.Comparable)1, var7, var8, var10, var38, var42);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    boolean var8 = var1.isRangeCrosshairVisible();
    java.lang.Comparable var9 = null;
    var1.setDomainCrosshairColumnKey(var9);
    org.jfree.chart.axis.AxisSpace var11 = null;
    var1.setFixedRangeAxisSpace(var11, false);
    java.awt.Stroke var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeCrosshairStroke(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     var2.setAutoPopulateSeriesShape(true);
//     java.awt.Paint var9 = var2.getBaseItemLabelPaint();
//     org.jfree.chart.urls.CategoryURLGenerator var11 = var2.getSeriesURLGenerator(1);
//     org.jfree.chart.util.PaintList var13 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var17 = var16.getLabelAngle();
//     boolean var18 = var13.equals((java.lang.Object)var16);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var16.getCategoryEnd((-1), 0, var21, var22);
//     double var24 = var16.getFixedDimension();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var30 = var28.getLegendTextFont(10);
//     java.awt.Paint var34 = var28.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", var34);
//     java.awt.Stroke var36 = var35.getLineStroke();
//     var16.setTickMarkStroke(var36);
//     var2.setSeriesStroke(10, var36, true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var2
//     assertTrue("Contract failed: equals-hashcode on var28 and var2", var28.equals(var2) ? var28.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var2.", var28.equals(var2) == var2.equals(var28));
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    boolean var8 = var1.isRangeCrosshairVisible();
    java.awt.Font var9 = var1.getNoDataMessageFont();
    org.jfree.chart.plot.Marker var11 = null;
    org.jfree.chart.util.Layer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var13 = var1.removeRangeMarker((-1), var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     int var5 = var2.getPassCount();
//     var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var2.setAutoPopulateSeriesOutlineStroke(true);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var12 = var11.getRangeCrosshairPaint();
//     var2.setBasePaint(var12);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var21 = var19.getLegendTextFont(10);
//     java.awt.Paint var25 = var19.getItemPaint(10, 100, true);
//     var16.setAxisLinePaint(var25);
//     var2.setSeriesItemLabelPaint(0, var25);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var2.", var19.equals(var2) == var2.equals(var19));
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     java.awt.Font var8 = var2.lookupLegendTextFont(0);
//     java.awt.Font var9 = null;
//     var2.setBaseLegendTextFont(var9);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var13 = null;
//     var12.setFixedRangeAxisSpace(var13);
//     boolean var15 = var12.isRangeGridlinesVisible();
//     var12.setRangeCrosshairValue(0.0d, true);
//     boolean var19 = var12.isRangeMinorGridlinesVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var24 = var22.getSeriesURLGenerator(1);
//     java.awt.Shape var28 = var22.getItemShape(0, (-1), false);
//     var22.setAutoPopulateSeriesOutlineStroke(true);
//     java.awt.Stroke var32 = var22.lookupSeriesOutlineStroke((-1));
//     var12.setDomainGridlineStroke(var32);
//     var2.setSeriesOutlineStroke(2, var32, false);
//     
//     // Checks the contract:  equals-hashcode on var22 and var2
//     assertTrue("Contract failed: equals-hashcode on var22 and var2", var22.equals(var2) ? var22.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var2.", var22.equals(var2) == var2.equals(var22));
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     org.jfree.chart.util.PaintList var3 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var4 = var3.clone();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var7 = var6.getLabelAngle();
//     boolean var8 = var3.equals((java.lang.Object)var6);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var6.getCategoryEnd((-1), 0, var11, var12);
//     var0.setDomainAxis(var6);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     org.jfree.chart.axis.AxisState var21 = var6.draw(var15, 10.0d, var17, var18, var19, var20);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var5 = null;
    var4.setFixedRangeAxisSpace(var5);
    org.jfree.chart.util.PaintList var7 = new org.jfree.chart.util.PaintList();
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var11 = var10.getLabelAngle();
    boolean var12 = var7.equals((java.lang.Object)var10);
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.util.RectangleEdge var16 = null;
    double var17 = var10.getCategoryEnd((-1), 0, var15, var16);
    var4.setDomainAxis(var10);
    var4.setDrawSharedDomainAxis(true);
    java.awt.Paint var21 = var4.getRangeZeroBaselinePaint();
    var0.setRangeCrosshairPaint(var21);
    org.jfree.chart.plot.Marker var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var24 = var0.removeRangeMarker(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     boolean var8 = var2.isSeriesVisible(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
//     org.jfree.chart.event.RendererChangeEvent var10 = null;
//     var2.notifyListeners(var10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var17 = var15.getLegendTextFont(10);
//     java.awt.Paint var21 = var15.getItemPaint(10, 100, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var26 = null;
//     var24.setSeriesFillPaint(10, var26);
//     int var28 = var24.getPassCount();
//     int var29 = var24.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var34 = var32.getSeriesURLGenerator(1);
//     java.awt.Shape var38 = var32.getItemShape(0, (-1), false);
//     var32.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var42 = var32.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var46 = var32.getPositiveItemLabelPosition(1, 0, false);
//     var24.setBaseNegativeItemLabelPosition(var46);
//     var15.setBasePositiveItemLabelPosition(var46);
//     boolean var50 = var46.equals((java.lang.Object)'a');
//     var2.setSeriesNegativeItemLabelPosition(2, var46, false);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var2
//     assertTrue("Contract failed: equals-hashcode on var32 and var2", var32.equals(var2) ? var32.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var2.", var15.equals(var2) == var2.equals(var15));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var32 and var2.", var32.equals(var2) == var2.equals(var32));
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     java.awt.Paint var10 = var2.getItemPaint(0, 100, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var16 = var14.getLegendTextFont(10);
//     java.awt.Paint var20 = var14.getItemPaint(10, 100, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var25 = null;
//     var23.setSeriesFillPaint(10, var25);
//     int var27 = var23.getPassCount();
//     int var28 = var23.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var33 = var31.getSeriesURLGenerator(1);
//     java.awt.Shape var37 = var31.getItemShape(0, (-1), false);
//     var31.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var41 = var31.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var45 = var31.getPositiveItemLabelPosition(1, 0, false);
//     var23.setBaseNegativeItemLabelPosition(var45);
//     var14.setBasePositiveItemLabelPosition(var45);
//     boolean var49 = var45.equals((java.lang.Object)'a');
//     var2.setSeriesNegativeItemLabelPosition(0, var45);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var2
//     assertTrue("Contract failed: equals-hashcode on var31 and var2", var31.equals(var2) ? var31.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var2.", var14.equals(var2) == var2.equals(var14));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var2.", var31.equals(var2) == var2.equals(var31));
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var2 = null;
    org.jfree.chart.util.Layer var3 = null;
    boolean var4 = var0.removeDomainMarker(1, var2, var3);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.Marker var4 = null;
//     boolean var5 = var0.removeDomainMarker(var4);
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var11 = null;
//     var9.setSeriesFillPaint(10, var11);
//     int var13 = var9.getPassCount();
//     int var14 = var9.getPassCount();
//     boolean var15 = var6.equals((java.lang.Object)var14);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var20 = var18.getSeriesURLGenerator(1);
//     java.awt.Shape var24 = var18.getItemShape(0, (-1), false);
//     var18.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var28 = var18.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var32 = var18.getPositiveItemLabelPosition(1, 0, false);
//     int var33 = var18.getRowCount();
//     boolean var34 = var6.equals((java.lang.Object)var33);
//     
//     // Checks the contract:  equals-hashcode on var9 and var18
//     assertTrue("Contract failed: equals-hashcode on var9 and var18", var9.equals(var18) ? var9.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var9
//     assertTrue("Contract failed: equals-hashcode on var18 and var9", var18.equals(var9) ? var18.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     java.awt.Paint var4 = null;
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
//     java.awt.Paint var6 = null;
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     java.awt.Stroke var8 = null;
//     java.awt.Stroke[] var9 = new java.awt.Stroke[] { var8};
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Shape var12 = null;
//     java.awt.Shape[] var13 = new java.awt.Shape[] { var12};
//     org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var7, var9, var11, var13);
//     boolean var16 = var14.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var21 = null;
//     var19.setSeriesFillPaint(10, var21);
//     int var23 = var19.getPassCount();
//     java.awt.Font var25 = var19.lookupLegendTextFont(0);
//     java.awt.Shape var27 = var19.lookupSeriesShape(10);
//     boolean var28 = var14.equals((java.lang.Object)var27);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var33 = var31.getSeriesURLGenerator(1);
//     java.awt.Shape var37 = var31.getItemShape(0, (-1), false);
//     java.awt.Paint var41 = var31.getItemOutlinePaint(10, 0, false);
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var27, var41);
//     
//     // Checks the contract:  equals-hashcode on var19 and var31
//     assertTrue("Contract failed: equals-hashcode on var19 and var31", var19.equals(var31) ? var19.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var19
//     assertTrue("Contract failed: equals-hashcode on var31 and var19", var31.equals(var19) ? var31.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var4 = var2.getLegendTextFont(10);
//     java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
//     java.awt.Paint var12 = var2.getItemLabelPaint(2, 0, false);
//     var2.setDefaultEntityRadius(1);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var16.setFixedRangeAxisSpace(var17);
//     boolean var19 = var16.isRangeGridlinesVisible();
//     var16.setRangeCrosshairValue(0.0d, true);
//     boolean var23 = var16.isRangeMinorGridlinesVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var28 = var26.getSeriesURLGenerator(1);
//     java.awt.Shape var32 = var26.getItemShape(0, (-1), false);
//     var26.setAutoPopulateSeriesOutlineStroke(true);
//     java.awt.Stroke var36 = var26.lookupSeriesOutlineStroke((-1));
//     var16.setDomainGridlineStroke(var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var46 = var44.getLegendTextFont(10);
//     java.awt.Paint var50 = var44.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("", var50);
//     java.awt.Stroke var52 = var51.getLineStroke();
//     java.awt.Paint var53 = var51.getLabelPaint();
//     java.awt.Paint var54 = var51.getFillPaint();
//     org.jfree.chart.util.PaintList var55 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var56 = var55.clone();
//     org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var59 = var58.getLabelAngle();
//     boolean var60 = var55.equals((java.lang.Object)var58);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var58.getCategoryEnd((-1), 0, var63, var64);
//     java.lang.String var66 = var58.getLabelToolTip();
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var68 = null;
//     var67.setFixedRangeAxisSpace(var68);
//     org.jfree.chart.util.PaintList var70 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var71 = var70.clone();
//     org.jfree.chart.axis.CategoryAxis var73 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var74 = var73.getLabelAngle();
//     boolean var75 = var70.equals((java.lang.Object)var73);
//     java.awt.geom.Rectangle2D var78 = null;
//     org.jfree.chart.util.RectangleEdge var79 = null;
//     double var80 = var73.getCategoryEnd((-1), 0, var78, var79);
//     var67.setDomainAxis(var73);
//     var67.setDrawSharedDomainAxis(true);
//     java.awt.Paint var84 = var67.getRangeZeroBaselinePaint();
//     boolean var85 = var58.hasListener((java.util.EventListener)var67);
//     java.awt.Stroke var86 = var67.getRangeZeroBaselineStroke();
//     var2.drawRangeLine(var15, var16, var38, var39, 100.0d, var54, var86);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", var1, var2);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    var0.clearDomainMarkers();
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var0.removeRangeMarker(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     float var2 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.util.ShadowGenerator var4 = var0.getShadowGenerator();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var6.setLabelURL("");
//     boolean var9 = var6.isMinorTickMarksVisible();
//     int var10 = var0.getDomainAxisIndex(var6);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var14 = null;
//     org.jfree.chart.util.Layer var15 = null;
//     boolean var16 = var12.removeDomainMarker(1, var14, var15);
//     org.jfree.chart.axis.AxisLocation var18 = var12.getDomainAxisLocation(100);
//     org.jfree.chart.axis.AxisLocation var19 = org.jfree.chart.axis.AxisLocation.getOpposite(var18);
//     var0.setDomainAxisLocation(1, var18, false);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(100.0d, var3, var4, true);
//     org.jfree.data.category.AbstractCategoryDataset var7 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var9 = var7.hasListener((java.util.EventListener)var8);
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.RenderingSource var13 = null;
//     var8.select(0.05d, (-1.0d), var12, var13);
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint var18 = null;
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Shape var24 = null;
//     java.awt.Shape[] var25 = new java.awt.Shape[] { var24};
//     org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var19, var21, var23, var25);
//     boolean var27 = var15.equals((java.lang.Object)var25);
//     var8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var15, true);
//     var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var15, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
    java.lang.String var11 = var3.getLabelToolTip();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var13 = null;
    var12.setFixedRangeAxisSpace(var13);
    org.jfree.chart.util.PaintList var15 = new org.jfree.chart.util.PaintList();
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var19 = var18.getLabelAngle();
    boolean var20 = var15.equals((java.lang.Object)var18);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var18.getCategoryEnd((-1), 0, var23, var24);
    var12.setDomainAxis(var18);
    var12.setDrawSharedDomainAxis(true);
    java.awt.Paint var29 = var12.getRangeZeroBaselinePaint();
    boolean var30 = var3.hasListener((java.util.EventListener)var12);
    org.jfree.chart.annotations.CategoryAnnotation var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var32 = var12.removeAnnotation(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    var0.configureDomainAxes();
    org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxis();
    org.jfree.data.category.CategoryDataset var5 = var0.getDataset(10);
    org.jfree.chart.plot.CategoryMarker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(2, var7, var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     var2.setUseOutlinePaint(false);
//     boolean var9 = var2.getItemShapeVisible(0, (-1));
//     java.awt.Font var11 = var2.getSeriesItemLabelFont(1);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var19 = var17.getLegendTextFont(10);
//     java.awt.Paint var23 = var17.getItemPaint(10, 100, true);
//     var14.setAxisLinePaint(var23);
//     var2.setSeriesOutlinePaint(100, var23, false);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var17 and var2.", var17.equals(var2) == var2.equals(var17));
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.5f, 0.5f, 0.5f);
    int var4 = var3.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 128);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var2
//     assertTrue("Contract failed: equals-hashcode on var1 and var2", var1.equals(var2) ? var1.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var1
//     assertTrue("Contract failed: equals-hashcode on var2 and var1", var2.equals(var1) ? var2.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.CategoryMarker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(3, var5, var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Stroke var11 = var10.getLineStroke();
    var10.setSeriesIndex((-1));
    var10.setToolTipText("");
    java.awt.Paint var16 = var10.getFillPaint();
    java.awt.Stroke var17 = var10.getOutlineStroke();
    java.lang.String var18 = var10.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var9 = var7.getLegendTextFont(10);
    java.awt.Paint var13 = var7.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var13);
    java.awt.Stroke var15 = var14.getLineStroke();
    java.awt.Paint var16 = var14.getLabelPaint();
    java.awt.Paint var17 = var14.getFillPaint();
    java.awt.Shape var18 = var14.getShape();
    java.awt.Paint var19 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var24 = null;
    var22.setSeriesFillPaint(10, var24);
    int var26 = var22.getPassCount();
    boolean var28 = var22.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var29 = var22.getLegendItemURLGenerator();
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.plot.Marker var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    var22.drawRangeMarker(var30, var31, var32, var33, var34);
    org.jfree.chart.util.PaintList var36 = new org.jfree.chart.util.PaintList();
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var40 = var39.getLabelAngle();
    boolean var41 = var36.equals((java.lang.Object)var39);
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleEdge var45 = null;
    double var46 = var39.getCategoryEnd((-1), 0, var44, var45);
    java.lang.String var47 = var39.getLabelToolTip();
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var49 = null;
    var48.setFixedRangeAxisSpace(var49);
    org.jfree.chart.util.PaintList var51 = new org.jfree.chart.util.PaintList();
    java.lang.Object var52 = var51.clone();
    org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var55 = var54.getLabelAngle();
    boolean var56 = var51.equals((java.lang.Object)var54);
    java.awt.geom.Rectangle2D var59 = null;
    org.jfree.chart.util.RectangleEdge var60 = null;
    double var61 = var54.getCategoryEnd((-1), 0, var59, var60);
    var48.setDomainAxis(var54);
    var48.setDrawSharedDomainAxis(true);
    java.awt.Paint var65 = var48.getRangeZeroBaselinePaint();
    boolean var66 = var39.hasListener((java.util.EventListener)var48);
    java.awt.Stroke var67 = var48.getRangeZeroBaselineStroke();
    var22.setBaseStroke(var67);
    org.jfree.chart.axis.CategoryAxis var70 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var70.setLowerMargin(10.0d);
    double var73 = var70.getUpperMargin();
    org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var75 = var74.getRangeCrosshairPaint();
    float var76 = var74.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var77 = var74.getFixedRangeAxisSpace();
    org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var79 = null;
    var78.setFixedRangeAxisSpace(var79);
    org.jfree.chart.util.PaintList var81 = new org.jfree.chart.util.PaintList();
    java.lang.Object var82 = var81.clone();
    org.jfree.chart.axis.CategoryAxis var84 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var85 = var84.getLabelAngle();
    boolean var86 = var81.equals((java.lang.Object)var84);
    java.awt.geom.Rectangle2D var89 = null;
    org.jfree.chart.util.RectangleEdge var90 = null;
    double var91 = var84.getCategoryEnd((-1), 0, var89, var90);
    var78.setDomainAxis(var84);
    var78.setDrawSharedDomainAxis(true);
    java.awt.Paint var95 = var78.getRangeZeroBaselinePaint();
    var74.setRangeCrosshairPaint(var95);
    var70.setAxisLinePaint(var95);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var98 = new org.jfree.chart.LegendItem("", "", "DatasetRenderingOrder.REVERSE", "", var18, var19, var67, var95);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Font var11 = var10.getLabelFont();
    var10.setSeriesKey((java.lang.Comparable)2);
    org.jfree.chart.util.GradientPaintTransformer var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setFillPaintTransformer(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var4 = var2.getLegendTextFont(10);
//     java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
//     java.awt.Paint var10 = null;
//     var2.setSeriesFillPaint(10, var10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var18 = var16.getLegendTextFont(10);
//     java.awt.Paint var22 = var16.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var22);
//     java.awt.Font var24 = var23.getLabelFont();
//     java.awt.Shape var25 = var23.getShape();
//     var2.setSeriesShape(0, var25);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var2.", var16.equals(var2) == var2.equals(var16));
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    boolean var11 = var10.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    boolean var2 = var0.equals((java.lang.Object)1.0d);
    java.awt.Paint var3 = null;
    java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
    java.awt.Paint var5 = null;
    java.awt.Paint[] var6 = new java.awt.Paint[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Stroke var9 = null;
    java.awt.Stroke[] var10 = new java.awt.Stroke[] { var9};
    java.awt.Shape var11 = null;
    java.awt.Shape[] var12 = new java.awt.Shape[] { var11};
    org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var6, var8, var10, var12);
    boolean var15 = var13.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var20 = null;
    var18.setSeriesFillPaint(10, var20);
    int var22 = var18.getPassCount();
    java.awt.Font var24 = var18.lookupLegendTextFont(0);
    java.awt.Shape var26 = var18.lookupSeriesShape(10);
    boolean var27 = var13.equals((java.lang.Object)var26);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var30 = null;
    org.jfree.chart.util.Layer var31 = null;
    boolean var32 = var28.removeDomainMarker(1, var30, var31);
    org.jfree.chart.axis.AxisLocation var34 = var28.getDomainAxisLocation(100);
    org.jfree.chart.entity.PlotEntity var36 = new org.jfree.chart.entity.PlotEntity(var26, (org.jfree.chart.plot.Plot)var28, "hi!");
    boolean var37 = var0.equals((java.lang.Object)"hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Shape var8 = null;
//     java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
//     boolean var12 = var10.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var17 = null;
//     var15.setSeriesFillPaint(10, var17);
//     int var19 = var15.getPassCount();
//     java.awt.Font var21 = var15.lookupLegendTextFont(0);
//     java.awt.Shape var23 = var15.lookupSeriesShape(10);
//     boolean var24 = var10.equals((java.lang.Object)var23);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var27 = null;
//     org.jfree.chart.util.Layer var28 = null;
//     boolean var29 = var25.removeDomainMarker(1, var27, var28);
//     org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var25, "hi!");
//     org.jfree.chart.axis.AxisSpace var34 = null;
//     var25.setFixedRangeAxisSpace(var34);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var40 = var38.getSeriesURLGenerator(1);
//     int var41 = var38.getPassCount();
//     var38.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var38.setAutoPopulateSeriesOutlineStroke(true);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var48 = var47.getRangeCrosshairPaint();
//     var38.setBasePaint(var48);
//     var25.setOutlinePaint(var48);
//     
//     // Checks the contract:  equals-hashcode on var15 and var38
//     assertTrue("Contract failed: equals-hashcode on var15 and var38", var15.equals(var38) ? var15.hashCode() == var38.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var38.", var15.equals(var38) == var38.equals(var15));
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var8 = null;
//     var6.setSeriesFillPaint(10, var8);
//     int var10 = var6.getPassCount();
//     java.awt.Font var12 = var6.lookupLegendTextFont(0);
//     java.awt.Shape var14 = var6.lookupSeriesShape(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var19 = var17.getLegendTextFont(10);
//     java.awt.Paint var23 = var17.getItemPaint(10, 100, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var28 = var26.getSeriesURLGenerator(1);
//     int var29 = var26.getPassCount();
//     int var30 = var26.getDefaultEntityRadius();
//     java.awt.Stroke var31 = var26.getBaseOutlineStroke();
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var33 = null;
//     var32.setFixedRangeAxisSpace(var33);
//     org.jfree.chart.axis.ValueAxis var35 = var32.getRangeAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var40 = var38.getSeriesURLGenerator(1);
//     java.awt.Shape var44 = var38.getItemShape(0, (-1), false);
//     java.awt.Paint var48 = var38.getItemOutlinePaint(10, 0, false);
//     var32.setRangeMinorGridlinePaint(var48);
//     org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("", "hi!", "DatasetRenderingOrder.REVERSE", "DatasetRenderingOrder.REVERSE", var14, var23, var31, var48);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var26
//     assertTrue("Contract failed: equals-hashcode on var6 and var26", var6.equals(var26) ? var6.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var38
//     assertTrue("Contract failed: equals-hashcode on var6 and var38", var6.equals(var38) ? var6.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var6
//     assertTrue("Contract failed: equals-hashcode on var26 and var6", var26.equals(var6) ? var26.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var6
//     assertTrue("Contract failed: equals-hashcode on var38 and var6", var38.equals(var6) ? var38.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     boolean var8 = var2.isSeriesVisible(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.Marker var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var2.drawRangeMarker(var10, var11, var12, var13, var14);
//     org.jfree.chart.LegendItemCollection var16 = new org.jfree.chart.LegendItemCollection();
//     var11.setFixedLegendItems(var16);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var23 = var21.getLegendTextFont(10);
//     java.awt.Paint var27 = var21.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", var27);
//     java.awt.Stroke var29 = var28.getLineStroke();
//     var28.setSeriesIndex((-1));
//     var28.setToolTipText("");
//     java.awt.Paint var34 = var28.getFillPaint();
//     java.awt.Stroke var35 = var28.getOutlineStroke();
//     boolean var36 = var16.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var2 and var21
//     assertTrue("Contract failed: equals-hashcode on var2 and var21", var2.equals(var21) ? var2.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var2
//     assertTrue("Contract failed: equals-hashcode on var21 and var2", var21.equals(var2) ? var21.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var2 = null;
    org.jfree.chart.util.Layer var3 = null;
    boolean var4 = var0.removeDomainMarker(1, var2, var3);
    org.jfree.chart.plot.Marker var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var0.removeRangeMarker(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.LegendItemCollection var1 = new org.jfree.chart.LegendItemCollection();
//     var0.addAll(var1);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke var6 = null;
    java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
    java.awt.Shape var8 = null;
    java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
    boolean var12 = var10.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var17 = null;
    var15.setSeriesFillPaint(10, var17);
    int var19 = var15.getPassCount();
    java.awt.Font var21 = var15.lookupLegendTextFont(0);
    java.awt.Shape var23 = var15.lookupSeriesShape(10);
    boolean var24 = var10.equals((java.lang.Object)var23);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var27 = null;
    org.jfree.chart.util.Layer var28 = null;
    boolean var29 = var25.removeDomainMarker(1, var27, var28);
    org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
    org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var25, "hi!");
    org.jfree.chart.axis.AxisSpace var34 = null;
    var25.setFixedRangeAxisSpace(var34, true);
    boolean var37 = var25.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    java.awt.Paint var4 = null;
    java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
    java.awt.Paint var6 = null;
    java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
    java.awt.Stroke var8 = null;
    java.awt.Stroke[] var9 = new java.awt.Stroke[] { var8};
    java.awt.Stroke var10 = null;
    java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
    java.awt.Shape var12 = null;
    java.awt.Shape[] var13 = new java.awt.Shape[] { var12};
    org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var7, var9, var11, var13);
    boolean var16 = var14.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var21 = null;
    var19.setSeriesFillPaint(10, var21);
    int var23 = var19.getPassCount();
    java.awt.Font var25 = var19.lookupLegendTextFont(0);
    java.awt.Shape var27 = var19.lookupSeriesShape(10);
    boolean var28 = var14.equals((java.lang.Object)var27);
    java.awt.Stroke var29 = null;
    java.awt.Color var33 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var34 = null;
    java.awt.Rectangle var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    java.awt.geom.AffineTransform var37 = null;
    java.awt.RenderingHints var38 = null;
    java.awt.PaintContext var39 = var33.createContext(var34, var35, var36, var37, var38);
    java.awt.color.ColorSpace var40 = var33.getColorSpace();
    java.awt.Color var41 = var33.brighter();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.REVERSE", "DatasetRenderingOrder.REVERSE", "hi!", "hi!", var27, var29, (java.awt.Paint)var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.5f, 0.5f, 0.5f);
    float[] var6 = new float[] { 0.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getRGBColorComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.clear();
    var0.setObject((java.lang.Object)true, (java.lang.Comparable)1, (java.lang.Comparable)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = var0.getObject(128, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Shape var8 = null;
//     java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var15 = var13.getSeriesURLGenerator(1);
//     int var16 = var13.getPassCount();
//     var13.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var13.setAutoPopulateSeriesOutlineStroke(true);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var23 = var22.getRangeCrosshairPaint();
//     var13.setBasePaint(var23);
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var23};
//     java.awt.Paint var26 = null;
//     java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
//     java.awt.Paint var28 = null;
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var28};
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Shape var34 = null;
//     java.awt.Shape[] var35 = new java.awt.Shape[] { var34};
//     org.jfree.chart.plot.DefaultDrawingSupplier var36 = new org.jfree.chart.plot.DefaultDrawingSupplier(var27, var29, var31, var33, var35);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var42 = var40.getLegendTextFont(10);
//     java.awt.Paint var46 = var40.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem("", var46);
//     java.awt.Stroke var48 = var47.getLineStroke();
//     var47.setSeriesIndex((-1));
//     var47.setToolTipText("");
//     java.awt.Paint var53 = var47.getFillPaint();
//     java.awt.Stroke var54 = var47.getOutlineStroke();
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     java.awt.Paint var56 = null;
//     java.awt.Paint[] var57 = new java.awt.Paint[] { var56};
//     java.awt.Paint var58 = null;
//     java.awt.Paint[] var59 = new java.awt.Paint[] { var58};
//     java.awt.Stroke var60 = null;
//     java.awt.Stroke[] var61 = new java.awt.Stroke[] { var60};
//     java.awt.Stroke var62 = null;
//     java.awt.Stroke[] var63 = new java.awt.Stroke[] { var62};
//     java.awt.Shape var64 = null;
//     java.awt.Shape[] var65 = new java.awt.Shape[] { var64};
//     org.jfree.chart.plot.DefaultDrawingSupplier var66 = new org.jfree.chart.plot.DefaultDrawingSupplier(var57, var59, var61, var63, var65);
//     org.jfree.chart.plot.DefaultDrawingSupplier var67 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var25, var31, var55, var65);
//     
//     // Checks the contract:  equals-hashcode on var10 and var36
//     assertTrue("Contract failed: equals-hashcode on var10 and var36", var10.equals(var36) ? var10.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var66
//     assertTrue("Contract failed: equals-hashcode on var10 and var66", var10.equals(var66) ? var10.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var10
//     assertTrue("Contract failed: equals-hashcode on var36 and var10", var36.equals(var10) ? var36.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var66
//     assertTrue("Contract failed: equals-hashcode on var36 and var66", var36.equals(var66) ? var36.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var10
//     assertTrue("Contract failed: equals-hashcode on var66 and var10", var66.equals(var10) ? var66.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var36
//     assertTrue("Contract failed: equals-hashcode on var66 and var36", var66.equals(var36) ? var66.hashCode() == var36.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var40 and var13.", var40.equals(var13) == var13.equals(var40));
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var4 = var2.getLegendTextFont(10);
//     java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
//     java.awt.Paint var10 = null;
//     var2.setSeriesFillPaint(10, var10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var17 = var15.getLegendTextFont(10);
//     java.awt.Paint var21 = var15.getItemPaint(10, 100, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var26 = null;
//     var24.setSeriesFillPaint(10, var26);
//     int var28 = var24.getPassCount();
//     int var29 = var24.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var34 = var32.getSeriesURLGenerator(1);
//     java.awt.Shape var38 = var32.getItemShape(0, (-1), false);
//     var32.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var42 = var32.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var46 = var32.getPositiveItemLabelPosition(1, 0, false);
//     var24.setBaseNegativeItemLabelPosition(var46);
//     var15.setBasePositiveItemLabelPosition(var46);
//     boolean var50 = var46.equals((java.lang.Object)'a');
//     var2.setSeriesPositiveItemLabelPosition(0, var46);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var2
//     assertTrue("Contract failed: equals-hashcode on var32 and var2", var32.equals(var2) ? var32.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var2.", var15.equals(var2) == var2.equals(var15));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var32 and var2.", var32.equals(var2) == var2.equals(var32));
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Shape var8 = null;
//     java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
//     boolean var12 = var10.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var17 = null;
//     var15.setSeriesFillPaint(10, var17);
//     int var19 = var15.getPassCount();
//     java.awt.Font var21 = var15.lookupLegendTextFont(0);
//     java.awt.Shape var23 = var15.lookupSeriesShape(10);
//     boolean var24 = var10.equals((java.lang.Object)var23);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var27 = null;
//     org.jfree.chart.util.Layer var28 = null;
//     boolean var29 = var25.removeDomainMarker(1, var27, var28);
//     org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var25, "hi!");
//     org.jfree.chart.plot.Marker var34 = null;
//     var25.addRangeMarker(var34);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var7 = var2.getAutoPopulateSeriesOutlinePaint();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var11 = var10.getRangeCrosshairPaint();
    var10.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var15 = var2.initialise(var8, var9, var10, var13, var14);
    org.jfree.chart.plot.CategoryMarker var17 = null;
    org.jfree.chart.util.Layer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addDomainMarker(0, var17, var18, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.Marker var4 = null;
    boolean var5 = var0.removeDomainMarker(var4);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var0.zoomRangeAxes(1.0d, 100.0d, var8, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     boolean var6 = var1.removeDomainMarker(0, var4, var5);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var7.setFixedRangeAxisSpace(var8);
//     org.jfree.chart.util.PaintList var10 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var14 = var13.getLabelAngle();
//     boolean var15 = var10.equals((java.lang.Object)var13);
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var13.getCategoryEnd((-1), 0, var18, var19);
//     var7.setDomainAxis(var13);
//     var13.setTickMarksVisible(false);
//     var1.setDomainAxis(var13);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(100.0d, var3, var4, true);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
//     var0.setRangeAxes(var8);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var12 = var11.getLabelAngle();
//     var11.setTickMarksVisible(true);
//     var0.setDomainAxis(var11);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var18 = var17.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     var17.zoomDomainAxes(100.0d, var20, var21, true);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis[] var25 = new org.jfree.chart.axis.ValueAxis[] { var24};
//     var17.setRangeAxes(var25);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var29 = var28.getRangeCrosshairPaint();
//     float var30 = var28.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var31 = var28.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var33 = null;
//     var32.setFixedRangeAxisSpace(var33);
//     org.jfree.chart.util.PaintList var35 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var36 = var35.clone();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var39 = var38.getLabelAngle();
//     boolean var40 = var35.equals((java.lang.Object)var38);
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var38.getCategoryEnd((-1), 0, var43, var44);
//     var32.setDomainAxis(var38);
//     var32.setDrawSharedDomainAxis(true);
//     java.awt.Paint var49 = var32.getRangeZeroBaselinePaint();
//     var28.setRangeCrosshairPaint(var49);
//     org.jfree.chart.util.RectangleEdge var52 = var28.getRangeAxisEdge(100);
//     org.jfree.chart.axis.AxisSpace var53 = null;
//     org.jfree.chart.axis.AxisSpace var54 = var11.reserveSpace(var16, (org.jfree.chart.plot.Plot)var17, var27, var52, var53);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = var6.getSeriesURLGenerator(1);
//     java.awt.Shape var12 = var6.getItemShape(0, (-1), false);
//     double var13 = var6.getItemMargin();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = null;
//     var6.setLegendItemURLGenerator(var14);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var20 = null;
//     var18.setSeriesFillPaint(10, var20);
//     int var22 = var18.getPassCount();
//     java.awt.Font var24 = var18.lookupLegendTextFont(0);
//     java.awt.Shape var26 = var18.lookupSeriesShape(10);
//     var6.setBaseLegendShape(var26);
//     java.awt.Color var31 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var32 = null;
//     java.awt.Rectangle var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     java.awt.geom.AffineTransform var35 = null;
//     java.awt.RenderingHints var36 = null;
//     java.awt.PaintContext var37 = var31.createContext(var32, var33, var34, var35, var36);
//     java.awt.color.ColorSpace var38 = var31.getColorSpace();
//     java.awt.Color var39 = var31.brighter();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var44 = var42.getSeriesURLGenerator(1);
//     var42.setUseOutlinePaint(false);
//     boolean var49 = var42.getItemShapeVisible(0, (-1));
//     java.awt.Font var51 = var42.getSeriesItemLabelFont(1);
//     var42.setBaseSeriesVisibleInLegend(false, false);
//     java.awt.Paint var55 = var42.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var59 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var61 = var59.getLegendTextFont(10);
//     java.awt.Paint var65 = var59.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var66 = new org.jfree.chart.LegendItem("", var65);
//     java.awt.Stroke var67 = var66.getLineStroke();
//     java.awt.Paint var68 = var66.getLabelPaint();
//     java.awt.Stroke var69 = var66.getOutlineStroke();
//     var42.setBaseStroke(var69, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var74 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var76 = var74.getLegendTextFont(10);
//     java.awt.Paint var80 = var74.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var81 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.REVERSE", "hi!", "", "hi!", var26, (java.awt.Paint)var39, var69, var80);
//     
//     // Checks the contract:  equals-hashcode on var18 and var59
//     assertTrue("Contract failed: equals-hashcode on var18 and var59", var18.equals(var59) ? var18.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var74
//     assertTrue("Contract failed: equals-hashcode on var18 and var74", var18.equals(var74) ? var18.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var18
//     assertTrue("Contract failed: equals-hashcode on var59 and var18", var59.equals(var18) ? var59.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var18
//     assertTrue("Contract failed: equals-hashcode on var74 and var18", var74.equals(var18) ? var74.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Shape var8 = null;
//     java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
//     boolean var12 = var10.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var17 = null;
//     var15.setSeriesFillPaint(10, var17);
//     int var19 = var15.getPassCount();
//     java.awt.Font var21 = var15.lookupLegendTextFont(0);
//     java.awt.Shape var23 = var15.lookupSeriesShape(10);
//     boolean var24 = var10.equals((java.lang.Object)var23);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var27 = null;
//     org.jfree.chart.util.Layer var28 = null;
//     boolean var29 = var25.removeDomainMarker(1, var27, var28);
//     org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var25, "hi!");
//     java.lang.String var34 = var33.toString();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var39 = var37.getSeriesURLGenerator(1);
//     int var40 = var37.getPassCount();
//     var37.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var37.setAutoPopulateSeriesOutlineStroke(true);
//     boolean var46 = var33.equals((java.lang.Object)var37);
//     
//     // Checks the contract:  equals-hashcode on var15 and var37
//     assertTrue("Contract failed: equals-hashcode on var15 and var37", var15.equals(var37) ? var15.hashCode() == var37.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var37.", var15.equals(var37) == var37.equals(var15));
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     float var2 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(var4, var5);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Shape var8 = null;
//     java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Paint var13 = null;
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var19 = null;
//     java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var14, var16, var18, var20);
//     java.awt.Paint var22 = null;
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
//     java.awt.Paint var24 = null;
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Stroke var26 = null;
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     java.awt.Stroke var28 = null;
//     java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
//     java.awt.Shape var30 = null;
//     java.awt.Shape[] var31 = new java.awt.Shape[] { var30};
//     org.jfree.chart.plot.DefaultDrawingSupplier var32 = new org.jfree.chart.plot.DefaultDrawingSupplier(var23, var25, var27, var29, var31);
//     java.awt.Paint var33 = null;
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     java.awt.Paint var35 = null;
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Shape var41 = null;
//     java.awt.Shape[] var42 = new java.awt.Shape[] { var41};
//     org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var36, var38, var40, var42);
//     org.jfree.chart.LegendItemCollection var44 = new org.jfree.chart.LegendItemCollection();
//     java.awt.Paint var45 = null;
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var45};
//     java.awt.Paint var47 = null;
//     java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
//     java.awt.Stroke var49 = null;
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
//     java.awt.Stroke var51 = null;
//     java.awt.Stroke[] var52 = new java.awt.Stroke[] { var51};
//     java.awt.Shape var53 = null;
//     java.awt.Shape[] var54 = new java.awt.Shape[] { var53};
//     org.jfree.chart.plot.DefaultDrawingSupplier var55 = new org.jfree.chart.plot.DefaultDrawingSupplier(var46, var48, var50, var52, var54);
//     boolean var56 = var44.equals((java.lang.Object)var50);
//     java.awt.Shape[] var57 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var58 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var12, var25, var40, var50, var57);
//     
//     // Checks the contract:  equals-hashcode on var10 and var21
//     assertTrue("Contract failed: equals-hashcode on var10 and var21", var10.equals(var21) ? var10.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var32
//     assertTrue("Contract failed: equals-hashcode on var10 and var32", var10.equals(var32) ? var10.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var43
//     assertTrue("Contract failed: equals-hashcode on var10 and var43", var10.equals(var43) ? var10.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var55
//     assertTrue("Contract failed: equals-hashcode on var10 and var55", var10.equals(var55) ? var10.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var10
//     assertTrue("Contract failed: equals-hashcode on var21 and var10", var21.equals(var10) ? var21.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var32
//     assertTrue("Contract failed: equals-hashcode on var21 and var32", var21.equals(var32) ? var21.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var43
//     assertTrue("Contract failed: equals-hashcode on var21 and var43", var21.equals(var43) ? var21.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var55
//     assertTrue("Contract failed: equals-hashcode on var21 and var55", var21.equals(var55) ? var21.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var10
//     assertTrue("Contract failed: equals-hashcode on var32 and var10", var32.equals(var10) ? var32.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var21
//     assertTrue("Contract failed: equals-hashcode on var32 and var21", var32.equals(var21) ? var32.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var43
//     assertTrue("Contract failed: equals-hashcode on var32 and var43", var32.equals(var43) ? var32.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var55
//     assertTrue("Contract failed: equals-hashcode on var32 and var55", var32.equals(var55) ? var32.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var10
//     assertTrue("Contract failed: equals-hashcode on var43 and var10", var43.equals(var10) ? var43.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var21
//     assertTrue("Contract failed: equals-hashcode on var43 and var21", var43.equals(var21) ? var43.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var32
//     assertTrue("Contract failed: equals-hashcode on var43 and var32", var43.equals(var32) ? var43.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var55
//     assertTrue("Contract failed: equals-hashcode on var43 and var55", var43.equals(var55) ? var43.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var10
//     assertTrue("Contract failed: equals-hashcode on var55 and var10", var55.equals(var10) ? var55.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var21
//     assertTrue("Contract failed: equals-hashcode on var55 and var21", var55.equals(var21) ? var55.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var32
//     assertTrue("Contract failed: equals-hashcode on var55 and var32", var55.equals(var32) ? var55.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var43
//     assertTrue("Contract failed: equals-hashcode on var55 and var43", var55.equals(var43) ? var55.hashCode() == var43.hashCode() : true);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     int var5 = var2.getPassCount();
//     var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var2.setAutoPopulateSeriesOutlineStroke(true);
//     java.awt.Paint var11 = var2.getBasePaint();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var14 = null;
//     var13.setFixedRangeAxisSpace(var14);
//     boolean var16 = var13.isRangeGridlinesVisible();
//     org.jfree.chart.plot.Marker var17 = null;
//     boolean var18 = var13.removeDomainMarker(var17);
//     java.awt.geom.Rectangle2D var19 = null;
//     var2.drawBackground(var12, var13, var19);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     boolean var8 = var2.isSeriesVisible(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.Marker var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var2.drawRangeMarker(var10, var11, var12, var13, var14);
//     org.jfree.chart.LegendItemCollection var16 = new org.jfree.chart.LegendItemCollection();
//     var11.setFixedLegendItems(var16);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var23 = var21.getLegendTextFont(10);
//     java.awt.Paint var27 = var21.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", var27);
//     java.awt.Stroke var29 = var28.getLineStroke();
//     java.awt.Paint var30 = var28.getLabelPaint();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var37 = var35.getLegendTextFont(10);
//     java.awt.Paint var41 = var35.getItemPaint(10, 100, true);
//     var32.setAxisLinePaint(var41);
//     var28.setLinePaint(var41);
//     java.lang.String var44 = var28.getDescription();
//     var16.add(var28);
//     
//     // Checks the contract:  equals-hashcode on var2 and var21
//     assertTrue("Contract failed: equals-hashcode on var2 and var21", var2.equals(var21) ? var2.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var35
//     assertTrue("Contract failed: equals-hashcode on var2 and var35", var2.equals(var35) ? var2.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var2
//     assertTrue("Contract failed: equals-hashcode on var21 and var2", var21.equals(var2) ? var21.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var2
//     assertTrue("Contract failed: equals-hashcode on var35 and var2", var35.equals(var2) ? var35.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke var6 = null;
    java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
    java.awt.Shape var8 = null;
    java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
    boolean var12 = var10.equals((java.lang.Object)'#');
    java.awt.Paint var13 = var10.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    java.awt.Font var8 = var2.lookupLegendTextFont(0);
    java.awt.Font var9 = null;
    var2.setBaseLegendTextFont(var9);
    java.awt.Font var12 = var2.getLegendTextFont(10);
    org.jfree.chart.LegendItem var15 = var2.getLegendItem(0, 10);
    java.awt.Color var20 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var21 = null;
    java.awt.Rectangle var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    java.awt.geom.AffineTransform var24 = null;
    java.awt.RenderingHints var25 = null;
    java.awt.PaintContext var26 = var20.createContext(var21, var22, var23, var24, var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesFillPaint((-1), (java.awt.Paint)var20, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var4 = var2.getLegendTextFont(10);
    java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
    java.awt.Paint var12 = var2.getItemLabelPaint(2, 0, false);
    boolean var15 = var2.getItemLineVisible(10, 2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShapesFilled((-1), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getColumnCount();
    int var2 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
//     var2.setAutoPopulateSeriesOutlineStroke(true);
//     java.awt.Stroke var12 = var2.lookupSeriesOutlineStroke((-1));
//     boolean var13 = var2.getUseFillPaint();
//     java.awt.Stroke var15 = var2.lookupSeriesOutlineStroke((-1));
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var18 = null;
//     var17.setFixedRangeAxisSpace(var18);
//     var17.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var29 = var27.getSeriesURLGenerator(1);
//     var27.setUseOutlinePaint(false);
//     boolean var34 = var27.getItemShapeVisible(0, (-1));
//     java.awt.Font var36 = var27.getSeriesItemLabelFont(1);
//     var27.setBaseSeriesVisibleInLegend(false, false);
//     java.awt.Paint var40 = var27.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var42 = null;
//     var41.setFixedRangeAxisSpace(var42);
//     boolean var44 = var41.isRangeGridlinesVisible();
//     var41.setRangeCrosshairValue(0.0d, true);
//     boolean var48 = var41.isRangeMinorGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     java.awt.geom.Point2D var51 = null;
//     var41.zoomDomainAxes(100.0d, var50, var51, false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var54 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var55 = null;
//     java.awt.Paint[] var56 = new java.awt.Paint[] { var55};
//     java.awt.Paint var57 = null;
//     java.awt.Paint[] var58 = new java.awt.Paint[] { var57};
//     java.awt.Stroke var59 = null;
//     java.awt.Stroke[] var60 = new java.awt.Stroke[] { var59};
//     java.awt.Stroke var61 = null;
//     java.awt.Stroke[] var62 = new java.awt.Stroke[] { var61};
//     java.awt.Shape var63 = null;
//     java.awt.Shape[] var64 = new java.awt.Shape[] { var63};
//     org.jfree.chart.plot.DefaultDrawingSupplier var65 = new org.jfree.chart.plot.DefaultDrawingSupplier(var56, var58, var60, var62, var64);
//     boolean var66 = var54.equals((java.lang.Object)var64);
//     java.awt.Stroke var67 = var54.getNextOutlineStroke();
//     var41.setOutlineStroke(var67);
//     var2.drawRangeLine(var16, var17, var22, var23, 100.05d, var40, var67);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = var0.getBoolean(128);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getLabelAngle();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var16 = var14.getLegendTextFont(10);
//     java.awt.Paint var20 = var14.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", var20);
//     var3.setLabelPaint(var20);
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.data.category.AbstractCategoryDataset var29 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var31 = var29.hasListener((java.util.EventListener)var30);
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.RenderingSource var35 = null;
//     var30.select(0.05d, (-1.0d), var34, var35);
//     boolean var37 = var30.isRangeCrosshairVisible();
//     java.lang.Comparable var38 = null;
//     var30.setDomainCrosshairColumnKey(var38);
//     org.jfree.chart.axis.AxisSpace var40 = null;
//     var30.setFixedRangeAxisSpace(var40, false);
//     org.jfree.data.category.CategoryDataset var43 = null;
//     int var44 = var30.indexOf(var43);
//     org.jfree.chart.util.RectangleEdge var45 = var30.getRangeAxisEdge();
//     double var46 = var3.getCategorySeriesMiddle(1, 128, 15, 10, 0.2d, var28, var45);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.AxisSpace var4 = null;
    var0.setFixedRangeAxisSpace(var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.getRangeAxisIndex(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     java.awt.Paint var3 = null;
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     java.awt.Paint var5 = null;
//     java.awt.Paint[] var6 = new java.awt.Paint[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Stroke var9 = null;
//     java.awt.Stroke[] var10 = new java.awt.Stroke[] { var9};
//     java.awt.Shape var11 = null;
//     java.awt.Shape[] var12 = new java.awt.Shape[] { var11};
//     org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var6, var8, var10, var12);
//     boolean var15 = var13.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var20 = null;
//     var18.setSeriesFillPaint(10, var20);
//     int var22 = var18.getPassCount();
//     java.awt.Font var24 = var18.lookupLegendTextFont(0);
//     java.awt.Shape var26 = var18.lookupSeriesShape(10);
//     boolean var27 = var13.equals((java.lang.Object)var26);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var30 = null;
//     org.jfree.chart.util.Layer var31 = null;
//     boolean var32 = var28.removeDomainMarker(1, var30, var31);
//     org.jfree.chart.axis.AxisLocation var34 = var28.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var36 = new org.jfree.chart.entity.PlotEntity(var26, (org.jfree.chart.plot.Plot)var28, "hi!");
//     org.jfree.chart.plot.PlotOrientation var37 = var28.getOrientation();
//     var1.setOrientation(var37);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.Marker var6 = null;
//     org.jfree.chart.util.Layer var7 = null;
//     var0.addRangeMarker(0, var6, var7);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
    boolean var6 = var0.getDrawSharedDomainAxis();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var2.setBaseItemLabelGenerator(var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var12 = null;
    var10.setSeriesFillPaint(10, var12);
    int var14 = var10.getPassCount();
    boolean var16 = var10.isSeriesVisible(1);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var19 = null;
    var18.setFixedRangeAxisSpace(var19);
    boolean var21 = var18.isRangeGridlinesVisible();
    var18.setRangeCrosshairValue(0.0d, true);
    boolean var25 = var18.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    java.awt.geom.Point2D var28 = null;
    var18.zoomDomainAxes(100.0d, var27, var28, false);
    org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var32 = null;
    java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
    java.awt.Paint var34 = null;
    java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
    java.awt.Stroke var36 = null;
    java.awt.Stroke[] var37 = new java.awt.Stroke[] { var36};
    java.awt.Stroke var38 = null;
    java.awt.Stroke[] var39 = new java.awt.Stroke[] { var38};
    java.awt.Shape var40 = null;
    java.awt.Shape[] var41 = new java.awt.Shape[] { var40};
    org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier(var33, var35, var37, var39, var41);
    boolean var43 = var31.equals((java.lang.Object)var41);
    java.awt.Stroke var44 = var31.getNextOutlineStroke();
    var18.setOutlineStroke(var44);
    var10.setSeriesStroke(2, var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesStroke((-1), var44, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    int var7 = var2.getPassCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
    java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
    var10.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var24 = var10.getPositiveItemLabelPosition(1, 0, false);
    var2.setBaseNegativeItemLabelPosition(var24);
    org.jfree.chart.event.RendererChangeListener var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addChangeListener(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.clear();
    var0.setObject((java.lang.Object)true, (java.lang.Comparable)1, (java.lang.Comparable)100);
    boolean var7 = var0.equals((java.lang.Object)1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var0.getRowKey(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var10 = null;
//     var8.setSeriesFillPaint(10, var10);
//     int var12 = var8.getPassCount();
//     java.awt.Font var14 = var8.lookupLegendTextFont(0);
//     java.awt.Shape var16 = var8.lookupSeriesShape(10);
//     var4.setShape(10, var16);
//     org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var23 = var21.getSeriesURLGenerator(1);
//     java.awt.Shape var27 = var21.getItemShape(0, (-1), false);
//     var21.setAutoPopulateSeriesOutlineStroke(true);
//     java.awt.Stroke var31 = var21.lookupSeriesOutlineStroke((-1));
//     boolean var32 = var21.getUseFillPaint();
//     java.awt.Stroke var34 = var21.lookupSeriesOutlineStroke((-1));
//     java.awt.Paint var35 = null;
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = hi!", "PlotEntity: tooltip = hi!", "PlotEntity: tooltip = hi!", "DatasetRenderingOrder.REVERSE", var16, var34, var35);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("PlotEntity: tooltip = hi!", var1);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
    java.lang.String var11 = var3.getLabelToolTip();
    var3.setFixedDimension(1.0d);
    java.lang.Comparable var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.removeCategoryLabelToolTip(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var0.setRangeAxes(var8);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getLabelAngle();
    var11.setTickMarksVisible(true);
    var0.setDomainAxis(var11);
    var0.clearDomainAxes();
    java.awt.Paint var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeMinorGridlinePaint(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var7 = var2.getAutoPopulateSeriesOutlinePaint();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var11 = var10.getRangeCrosshairPaint();
    var10.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var15 = var2.initialise(var8, var9, var10, var13, var14);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = var2.getBaseToolTipGenerator();
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)false, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelGenerator((-1), var22, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    java.lang.Object var3 = var1.get((-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var10 = var8.getLegendTextFont(10);
    java.awt.Paint var14 = var8.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("", var14);
    java.awt.Font var16 = var15.getLabelFont();
    boolean var17 = var15.isLineVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set(0, (java.lang.Object)var17);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    int var1 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    float[] var4 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(3, 10, 3, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getColumnKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var0.setRangeAxes(var8);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getLabelAngle();
    var11.setTickMarksVisible(true);
    var0.setDomainAxis(var11);
    var0.clearDomainAxes();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    java.util.List var20 = var18.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxes(2, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    java.util.List var2 = var0.getAnnotations();
    java.awt.Image var3 = var0.getBackgroundImage();
    org.jfree.chart.axis.AxisSpace var4 = null;
    var0.setFixedDomainAxisSpace(var4, false);
    var0.clearDomainAxes();
    org.jfree.chart.annotations.CategoryAnnotation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var0.removeAnnotation(var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getLabelAngle();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
//     java.lang.String var11 = var3.getLabelToolTip();
//     var3.setFixedDimension(1.0d);
//     java.lang.Object var14 = var3.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var14.", var1.equals(var14) == var14.equals(var1));
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.5f, 0.5f, 0.5f);
    java.awt.Color var7 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var8 = null;
    java.awt.Rectangle var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    java.awt.geom.AffineTransform var11 = null;
    java.awt.RenderingHints var12 = null;
    java.awt.PaintContext var13 = var7.createContext(var8, var9, var10, var11, var12);
    java.awt.color.ColorSpace var14 = var7.getColorSpace();
    float[] var17 = new float[] { 10.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var18 = var3.getComponents(var14, var17);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.clear();
    var0.setObject((java.lang.Object)true, (java.lang.Comparable)1, (java.lang.Comparable)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)true);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var0.axisChanged(var7);
    org.jfree.data.KeyedObjects2D var10 = new org.jfree.data.KeyedObjects2D();
    int var11 = var10.getColumnCount();
    int var12 = var10.getColumnCount();
    var10.clear();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var16 = var15.getLabelAngle();
    var15.setMinorTickMarkInsideLength(10.0f);
    boolean var19 = var15.isMinorTickMarksVisible();
    float var20 = var15.getMinorTickMarkInsideLength();
    var10.addObject((java.lang.Object)var15, (java.lang.Comparable)(byte)10, (java.lang.Comparable)0L);
    var0.setDomainAxis(100, var15);
    org.jfree.chart.plot.Plot var25 = var0.getParent();
    java.awt.Stroke var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeMinorGridlineStroke(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var2 = null;
//     org.jfree.chart.util.Layer var3 = null;
//     boolean var4 = var0.removeDomainMarker(1, var2, var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(100);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var7.setFixedRangeAxisSpace(var8);
//     boolean var10 = var7.isRangeGridlinesVisible();
//     var7.setRangeCrosshairValue(0.0d, true);
//     boolean var14 = var7.isRangeMinorGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var7.zoomDomainAxes(0.0d, var16, var17);
//     boolean var19 = var7.canSelectByPoint();
//     boolean var20 = var6.equals((java.lang.Object)var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    java.util.List var2 = var0.getAnnotations();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.String var6 = var5.getLabel();
    org.jfree.data.category.AbstractCategoryDataset var7 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    boolean var9 = var7.hasListener((java.util.EventListener)var8);
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.RenderingSource var13 = null;
    var8.select(0.05d, (-1.0d), var12, var13);
    boolean var15 = var8.isRangeCrosshairVisible();
    java.awt.Font var16 = var8.getNoDataMessageFont();
    var5.setLabelFont(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-1), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var4 = var2.getLegendTextFont(10);
    java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
    java.awt.Paint var12 = var2.getItemLabelPaint(2, 0, false);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var17 = var2.isSeriesItemLabelsVisible(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     boolean var8 = var2.isSeriesVisible(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.Marker var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var2.drawRangeMarker(var10, var11, var12, var13, var14);
//     org.jfree.chart.LegendItemCollection var16 = new org.jfree.chart.LegendItemCollection();
//     var11.setFixedLegendItems(var16);
//     org.jfree.chart.util.SortOrder var18 = var11.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var25 = var23.getLegendTextFont(10);
//     java.awt.Paint var29 = var23.getItemPaint(10, 100, true);
//     var20.setAxisLinePaint(var29);
//     java.lang.String var31 = var20.getLabelURL();
//     java.awt.Paint var33 = var20.getTickLabelPaint((java.lang.Comparable)10.0d);
//     var11.setNoDataMessagePaint(var33);
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var12 = var11.getRangeCrosshairPaint();
    var2.setBasePaint(var12);
    var2.setSeriesLinesVisible(3, true);
    java.lang.Boolean var18 = var2.getSeriesVisibleInLegend(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     var2.setUseOutlinePaint(false);
//     boolean var9 = var2.getItemShapeVisible(0, (-1));
//     java.awt.Font var11 = var2.getSeriesItemLabelFont(1);
//     var2.setBaseSeriesVisibleInLegend(false, false);
//     java.awt.Paint var15 = var2.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var19 = null;
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var21 = var17.removeDomainMarker(1, var19, var20);
//     java.awt.Font var22 = var17.getNoDataMessageFont();
//     var2.setSeriesItemLabelFont(0, var22, false);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var26 = var25.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Point2D var29 = null;
//     var25.zoomDomainAxes(100.0d, var28, var29, true);
//     var25.setNotify(true);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var25.getRenderer();
//     int var35 = var25.getBackgroundImageAlignment();
//     var2.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var25);
//     
//     // Checks the contract:  equals-hashcode on var17 and var25
//     assertTrue("Contract failed: equals-hashcode on var17 and var25", var17.equals(var25) ? var17.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var17
//     assertTrue("Contract failed: equals-hashcode on var25 and var17", var25.equals(var17) ? var25.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
    java.lang.String var11 = var3.getLabelToolTip();
    var3.setFixedDimension(1.0d);
    var3.setTickLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setLowerMargin(10.0d);
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    var1.setLabelPaint((java.awt.Paint)var6);
    java.awt.Color var11 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var12 = null;
    java.awt.Rectangle var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    java.awt.geom.AffineTransform var15 = null;
    java.awt.RenderingHints var16 = null;
    java.awt.PaintContext var17 = var11.createContext(var12, var13, var14, var15, var16);
    java.awt.color.ColorSpace var18 = var11.getColorSpace();
    float[] var22 = new float[] { 1.0f, 100.0f, 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var23 = var6.getComponents(var18, var22);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    int var3 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var0.getObject((java.lang.Comparable)(byte)100, (java.lang.Comparable)'a');
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.RenderingSource var6 = null;
//     var1.select(0.05d, (-1.0d), var5, var6);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var9.setFixedRangeAxisSpace(var10);
//     boolean var12 = var9.isRangeGridlinesVisible();
//     org.jfree.chart.plot.Marker var13 = null;
//     boolean var14 = var9.removeDomainMarker(var13);
//     org.jfree.chart.plot.DatasetRenderingOrder var15 = var9.getDatasetRenderingOrder();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var20 = null;
//     var18.setSeriesFillPaint(10, var20);
//     int var22 = var18.getPassCount();
//     int var23 = var18.getPassCount();
//     boolean var24 = var15.equals((java.lang.Object)var23);
//     java.lang.String var25 = var15.toString();
//     var1.setDatasetRenderingOrder(var15);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var4 = null;
    java.awt.Rectangle var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    java.awt.geom.AffineTransform var7 = null;
    java.awt.RenderingHints var8 = null;
    java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
    java.awt.color.ColorSpace var10 = var3.getColorSpace();
    java.awt.Color var11 = var3.brighter();
    float[] var12 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var13 = var3.getRGBColorComponents(var12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke var6 = null;
    java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
    java.awt.Shape var8 = null;
    java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
    boolean var12 = var10.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var17 = null;
    var15.setSeriesFillPaint(10, var17);
    int var19 = var15.getPassCount();
    java.awt.Font var21 = var15.lookupLegendTextFont(0);
    java.awt.Shape var23 = var15.lookupSeriesShape(10);
    boolean var24 = var10.equals((java.lang.Object)var23);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var27 = null;
    org.jfree.chart.util.Layer var28 = null;
    boolean var29 = var25.removeDomainMarker(1, var27, var28);
    org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
    org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var25, "hi!");
    org.jfree.chart.plot.Plot var34 = var33.getPlot();
    org.jfree.chart.plot.Plot var35 = var34.getParent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    var1.setRenderer(1, var15);
    org.jfree.data.KeyedObjects2D var18 = new org.jfree.data.KeyedObjects2D();
    java.util.List var19 = var18.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.mapDatasetToRangeAxes(2, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 1.0d, (-0.7853981633974483d), 100.05d, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis[] var4 = null;
//     var0.setDomainAxes(var4);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    java.util.List var2 = var0.getAnnotations();
    java.awt.Image var3 = var0.getBackgroundImage();
    org.jfree.chart.axis.AxisSpace var4 = null;
    var0.setFixedDomainAxisSpace(var4, false);
    org.jfree.chart.plot.Marker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var0.removeRangeMarker(15, var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     boolean var3 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.0d, true);
//     boolean var7 = var0.isRangeMinorGridlinesVisible();
//     var0.configureRangeAxes();
//     org.jfree.chart.util.PaintList var10 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var14 = var13.getLabelAngle();
//     boolean var15 = var10.equals((java.lang.Object)var13);
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var13.getCategoryEnd((-1), 0, var18, var19);
//     java.lang.String var21 = var13.getLabelToolTip();
//     var13.setFixedDimension(1.0d);
//     var0.setDomainAxis(128, var13);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     org.jfree.chart.axis.AxisState var29 = null;
//     var13.drawTickMarks(var25, 100.0d, var27, var28, var29);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     int var7 = var2.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
//     java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
//     var10.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var10.getPositiveItemLabelPosition(1, 0, false);
//     var2.setBaseNegativeItemLabelPosition(var24);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = var2.getLegendItemToolTipGenerator();
//     boolean var27 = var2.getBaseSeriesVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var33 = null;
//     var31.setSeriesFillPaint(10, var33);
//     int var35 = var31.getPassCount();
//     int var36 = var31.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var41 = var39.getSeriesURLGenerator(1);
//     java.awt.Shape var45 = var39.getItemShape(0, (-1), false);
//     var39.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var49 = var39.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var53 = var39.getPositiveItemLabelPosition(1, 0, false);
//     var31.setBaseNegativeItemLabelPosition(var53);
//     org.jfree.data.KeyedObject var57 = new org.jfree.data.KeyedObject((java.lang.Comparable)100.0f, (java.lang.Object)'4');
//     java.lang.Object var58 = var57.clone();
//     java.lang.Comparable var59 = var57.getKey();
//     boolean var60 = var53.equals((java.lang.Object)var57);
//     var2.setSeriesPositiveItemLabelPosition(0, var53, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var2.", var31.equals(var2) == var2.equals(var31));
//     
//     // Checks the contract:  equals-hashcode on var24 and var53
//     assertTrue("Contract failed: equals-hashcode on var24 and var53", var24.equals(var53) ? var24.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var24
//     assertTrue("Contract failed: equals-hashcode on var53 and var24", var53.equals(var24) ? var53.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     float var2 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.util.ShadowGenerator var4 = var0.getShadowGenerator();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var6.setLabelURL("");
//     boolean var9 = var6.isMinorTickMarksVisible();
//     int var10 = var0.getDomainAxisIndex(var6);
//     java.lang.Object var11 = var0.clone();
//     org.jfree.chart.util.PaintList var12 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var16 = var15.getLabelAngle();
//     boolean var17 = var12.equals((java.lang.Object)var15);
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var15.getCategoryEnd((-1), 0, var20, var21);
//     java.lang.String var23 = var15.getLabelToolTip();
//     var15.setMinorTickMarkOutsideLength(100.0f);
//     java.awt.Stroke var26 = var15.getTickMarkStroke();
//     var0.setRangeZeroBaselineStroke(var26);
//     
//     // Checks the contract:  equals-hashcode on var13 and var11
//     assertTrue("Contract failed: equals-hashcode on var13 and var11", var13.equals(var11) ? var13.hashCode() == var11.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var11.", var13.equals(var11) == var11.equals(var13));
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     boolean var6 = var1.removeDomainMarker(0, var4, var5);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     var1.zoomDomainAxes(100.0d, var8, var9, false);
//     var1.setCrosshairDatasetIndex(3);
//     org.jfree.chart.plot.Plot var14 = var1.getParent();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var16 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var15.zoomDomainAxes(100.0d, var18, var19, true);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var22};
//     var15.setRangeAxes(var23);
//     var1.setRangeAxes(var23);
//     boolean var26 = var1.isRangeMinorGridlinesVisible();
//     org.jfree.chart.util.Layer var27 = null;
//     java.util.Collection var28 = var1.getRangeMarkers(var27);
//     java.awt.Graphics2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     var1.drawOutline(var29, var30);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getColumnCount();
    int var2 = var0.getColumnCount();
    java.lang.Comparable var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject(var3, (java.lang.Comparable)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
    java.lang.String var11 = var3.getLabelToolTip();
    var3.removeCategoryLabelToolTip((java.lang.Comparable)15);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var16 = var15.getRangeCrosshairPaint();
    java.util.List var17 = var15.getAnnotations();
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var20 = var19.getRangeCrosshairPaint();
    float var21 = var19.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var22 = var19.getFixedRangeAxisSpace();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var24 = null;
    var23.setFixedRangeAxisSpace(var24);
    org.jfree.chart.util.PaintList var26 = new org.jfree.chart.util.PaintList();
    java.lang.Object var27 = var26.clone();
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var30 = var29.getLabelAngle();
    boolean var31 = var26.equals((java.lang.Object)var29);
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.util.RectangleEdge var35 = null;
    double var36 = var29.getCategoryEnd((-1), 0, var34, var35);
    var23.setDomainAxis(var29);
    var23.setDrawSharedDomainAxis(true);
    java.awt.Paint var40 = var23.getRangeZeroBaselinePaint();
    var19.setRangeCrosshairPaint(var40);
    org.jfree.chart.util.RectangleEdge var43 = var19.getRangeAxisEdge(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var44 = var3.getCategoryMiddle((java.lang.Comparable)(short)0, var17, var18, var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.RenderingSource var6 = null;
//     var1.select(0.05d, (-1.0d), var5, var6);
//     org.jfree.chart.plot.DefaultDrawingSupplier var8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var9 = null;
//     java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Stroke var13 = null;
//     java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Shape var17 = null;
//     java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
//     org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var12, var14, var16, var18);
//     boolean var20 = var8.equals((java.lang.Object)var18);
//     var1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var8, true);
//     org.jfree.chart.plot.Marker var24 = null;
//     org.jfree.chart.util.Layer var25 = null;
//     var1.addRangeMarker(15, var24, var25);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     int var5 = var2.getPassCount();
//     var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var2.getBaseURLGenerator();
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Paint var13 = null;
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var19 = null;
//     java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var14, var16, var18, var20);
//     boolean var23 = var21.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var28 = null;
//     var26.setSeriesFillPaint(10, var28);
//     int var30 = var26.getPassCount();
//     java.awt.Font var32 = var26.lookupLegendTextFont(0);
//     java.awt.Shape var34 = var26.lookupSeriesShape(10);
//     boolean var35 = var21.equals((java.lang.Object)var34);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var38 = null;
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var36.removeDomainMarker(1, var38, var39);
//     org.jfree.chart.axis.AxisLocation var42 = var36.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var44 = new org.jfree.chart.entity.PlotEntity(var34, (org.jfree.chart.plot.Plot)var36, "hi!");
//     org.jfree.chart.axis.AxisSpace var45 = null;
//     var36.setFixedRangeAxisSpace(var45);
//     java.awt.Stroke var47 = var36.getDomainCrosshairStroke();
//     var2.setSeriesOutlineStroke(1, var47, false);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var2.", var26.equals(var2) == var2.equals(var26));
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 128, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    java.awt.Paint var12 = var2.getItemOutlinePaint(10, 0, false);
    boolean var13 = var2.getAutoPopulateSeriesOutlinePaint();
    java.lang.Boolean var15 = var2.getSeriesVisibleInLegend(3);
    java.awt.Paint var16 = var2.getBaseItemLabelPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var22 = var20.getLegendTextFont(10);
    java.awt.Paint var26 = var20.getItemPaint(10, 100, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var31 = null;
    var29.setSeriesFillPaint(10, var31);
    int var33 = var29.getPassCount();
    int var34 = var29.getPassCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var39 = var37.getSeriesURLGenerator(1);
    java.awt.Shape var43 = var37.getItemShape(0, (-1), false);
    var37.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var47 = var37.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var51 = var37.getPositiveItemLabelPosition(1, 0, false);
    var29.setBaseNegativeItemLabelPosition(var51);
    var20.setBasePositiveItemLabelPosition(var51);
    boolean var55 = var51.equals((java.lang.Object)'a');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesPositiveItemLabelPosition((-1), var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    java.lang.Boolean var7 = var2.getSeriesItemLabelsVisible(0);
    java.awt.Paint var9 = var2.getSeriesItemLabelPaint(2);
    boolean var13 = var2.isItemLabelVisible(128, 10, false);
    java.awt.Font var15 = null;
    var2.setLegendTextFont(0, var15);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = null;
    var2.setLegendItemToolTipGenerator(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Stroke var12 = var2.lookupSeriesOutlineStroke((-1));
    boolean var13 = var2.getUseFillPaint();
    java.awt.Stroke var15 = var2.lookupSeriesOutlineStroke((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShapesFilled((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Stroke var12 = var2.lookupSeriesOutlineStroke((-1));
    boolean var13 = var2.getBaseItemLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var11 = var1.removeAnnotation(var9, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    org.jfree.chart.plot.Plot var14 = var1.getParent();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var16 = var15.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var15.zoomDomainAxes(100.0d, var18, var19, true);
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var22};
    var15.setRangeAxes(var23);
    var1.setRangeAxes(var23);
    boolean var26 = var1.isRangeMinorGridlinesVisible();
    org.jfree.chart.util.Layer var27 = null;
    java.util.Collection var28 = var1.getRangeMarkers(var27);
    java.awt.Stroke var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeZeroBaselineStroke(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var12 = var2.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var16 = var2.getPositiveItemLabelPosition(1, 0, false);
    java.lang.Boolean var18 = var2.getSeriesCreateEntities(3);
    var2.setDataBoundsIncludesVisibleSeriesOnly(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(100.0d, var3, var4, true);
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var0.axisChanged(var7);
//     org.jfree.chart.plot.Marker var10 = null;
//     org.jfree.chart.util.Layer var11 = null;
//     var0.addRangeMarker(128, var10, var11, true);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.05d, 10.0d, 0.0d, 0.05d);
    double var6 = var4.calculateTopOutset(100.0d);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var4.createOutsetRectangle(var7, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var10 = null;
    var8.setSeriesFillPaint(10, var10);
    int var12 = var8.getPassCount();
    java.awt.Font var14 = var8.lookupLegendTextFont(0);
    java.awt.Shape var16 = var8.lookupSeriesShape(10);
    var4.setShape(10, var16);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16);
    org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var25 = null;
    var23.setSeriesFillPaint(10, var25);
    int var27 = var23.getPassCount();
    java.awt.Font var29 = var23.lookupLegendTextFont(0);
    java.awt.Shape var31 = var23.lookupSeriesShape(10);
    var19.setShape(10, var31);
    org.jfree.chart.entity.ChartEntity var33 = new org.jfree.chart.entity.ChartEntity(var31);
    var18.setArea(var31);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var39 = null;
    var37.setSeriesFillPaint(10, var39);
    int var41 = var37.getPassCount();
    boolean var43 = var37.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var44 = var37.getLegendItemURLGenerator();
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.plot.Marker var48 = null;
    java.awt.geom.Rectangle2D var49 = null;
    var37.drawRangeMarker(var45, var46, var47, var48, var49);
    org.jfree.chart.util.PaintList var51 = new org.jfree.chart.util.PaintList();
    java.lang.Object var52 = var51.clone();
    org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var55 = var54.getLabelAngle();
    boolean var56 = var51.equals((java.lang.Object)var54);
    java.awt.geom.Rectangle2D var59 = null;
    org.jfree.chart.util.RectangleEdge var60 = null;
    double var61 = var54.getCategoryEnd((-1), 0, var59, var60);
    java.lang.String var62 = var54.getLabelToolTip();
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var64 = null;
    var63.setFixedRangeAxisSpace(var64);
    org.jfree.chart.util.PaintList var66 = new org.jfree.chart.util.PaintList();
    java.lang.Object var67 = var66.clone();
    org.jfree.chart.axis.CategoryAxis var69 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var70 = var69.getLabelAngle();
    boolean var71 = var66.equals((java.lang.Object)var69);
    java.awt.geom.Rectangle2D var74 = null;
    org.jfree.chart.util.RectangleEdge var75 = null;
    double var76 = var69.getCategoryEnd((-1), 0, var74, var75);
    var63.setDomainAxis(var69);
    var63.setDrawSharedDomainAxis(true);
    java.awt.Paint var80 = var63.getRangeZeroBaselinePaint();
    boolean var81 = var54.hasListener((java.util.EventListener)var63);
    java.awt.Stroke var82 = var63.getRangeZeroBaselineStroke();
    var37.setBaseStroke(var82);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var86 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var88 = null;
    var86.setSeriesFillPaint(10, var88);
    int var90 = var86.getPassCount();
    java.awt.Paint var94 = var86.getItemPaint(0, 100, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var95 = new org.jfree.chart.LegendItem(var0, "hi!", "", "", var31, var82, var94);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    java.awt.Color var1 = java.awt.Color.getColor("PlotEntity: tooltip = hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    boolean var8 = var1.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.Marker var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var1.removeRangeMarker(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    java.lang.Object var0 = null;
    org.jfree.chart.JFreeChart var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == false);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.Font var7 = var3.getTickLabelFont((java.lang.Comparable)(byte)0);
    java.awt.Paint var8 = var3.getTickMarkPaint();
    java.awt.Stroke var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setAxisLineStroke(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
//     var2.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var12 = var2.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var2.getPositiveItemLabelPosition(1, 0, false);
//     java.lang.Boolean var18 = var2.getSeriesCreateEntities(3);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var24 = var22.getSeriesURLGenerator(1);
//     int var25 = var22.getPassCount();
//     var22.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = null;
//     var22.setBaseItemLabelGenerator(var29, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var37 = var35.getLegendTextFont(10);
//     java.awt.Paint var41 = var35.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("", var41);
//     java.awt.Stroke var43 = var42.getLineStroke();
//     var42.setSeriesIndex((-1));
//     var42.setToolTipText("");
//     java.lang.Comparable var48 = var42.getSeriesKey();
//     java.awt.Shape var49 = var42.getShape();
//     java.awt.Color var53 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var54 = null;
//     java.awt.Rectangle var55 = null;
//     java.awt.geom.Rectangle2D var56 = null;
//     java.awt.geom.AffineTransform var57 = null;
//     java.awt.RenderingHints var58 = null;
//     java.awt.PaintContext var59 = var53.createContext(var54, var55, var56, var57, var58);
//     java.awt.color.ColorSpace var60 = var53.getColorSpace();
//     java.awt.Color var61 = var53.brighter();
//     var42.setLinePaint((java.awt.Paint)var53);
//     var22.setBaseItemLabelPaint((java.awt.Paint)var53, false);
//     var2.setSeriesFillPaint(128, (java.awt.Paint)var53, false);
//     
//     // Checks the contract:  equals-hashcode on var35 and var2
//     assertTrue("Contract failed: equals-hashcode on var35 and var2", var35.equals(var2) ? var35.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var2.", var35.equals(var2) == var2.equals(var35));
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getLabelAngle();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
//     java.lang.String var11 = var3.getLabelToolTip();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var13 = null;
//     var12.setFixedRangeAxisSpace(var13);
//     org.jfree.chart.util.PaintList var15 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var19 = var18.getLabelAngle();
//     boolean var20 = var15.equals((java.lang.Object)var18);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var18.getCategoryEnd((-1), 0, var23, var24);
//     var12.setDomainAxis(var18);
//     var12.setDrawSharedDomainAxis(true);
//     java.awt.Paint var29 = var12.getRangeZeroBaselinePaint();
//     boolean var30 = var3.hasListener((java.util.EventListener)var12);
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var35 = var34.getRangeCrosshairPaint();
//     float var36 = var34.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var37 = var34.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var39 = null;
//     var38.setFixedRangeAxisSpace(var39);
//     org.jfree.chart.util.PaintList var41 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var42 = var41.clone();
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var45 = var44.getLabelAngle();
//     boolean var46 = var41.equals((java.lang.Object)var44);
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var44.getCategoryEnd((-1), 0, var49, var50);
//     var38.setDomainAxis(var44);
//     var38.setDrawSharedDomainAxis(true);
//     java.awt.Paint var55 = var38.getRangeZeroBaselinePaint();
//     var34.setRangeCrosshairPaint(var55);
//     org.jfree.chart.util.RectangleEdge var58 = var34.getRangeAxisEdge(100);
//     double var59 = var3.getCategoryStart(15, 0, var33, var58);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var3 = var2.getLabelAngle();
    var2.setMinorTickMarkInsideLength(10.0f);
    double var6 = var2.getLowerMargin();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
    java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
    var10.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var25 = var10.getItemOutlineStroke((-1), (-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d, true);
    boolean var7 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    java.awt.geom.Point2D var10 = null;
    var0.zoomDomainAxes(100.0d, var9, var10, false);
    boolean var13 = var0.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    var1.setTickMarksVisible(true);
    double var5 = var1.getFixedDimension();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var7 = null;
    var6.setFixedRangeAxisSpace(var7);
    boolean var9 = var6.isRangeGridlinesVisible();
    var6.setRangeCrosshairValue(0.0d, true);
    boolean var13 = var6.isRangeMinorGridlinesVisible();
    boolean var14 = var1.hasListener((java.util.EventListener)var6);
    org.jfree.chart.axis.CategoryLabelPositions var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var5 = null;
    var4.setFixedRangeAxisSpace(var5);
    org.jfree.chart.util.PaintList var7 = new org.jfree.chart.util.PaintList();
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var11 = var10.getLabelAngle();
    boolean var12 = var7.equals((java.lang.Object)var10);
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.util.RectangleEdge var16 = null;
    double var17 = var10.getCategoryEnd((-1), 0, var15, var16);
    var4.setDomainAxis(var10);
    var4.setDrawSharedDomainAxis(true);
    java.awt.Paint var21 = var4.getRangeZeroBaselinePaint();
    var0.setRangeCrosshairPaint(var21);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var25 = var24.getRangeCrosshairPaint();
    java.util.List var26 = var24.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxes(100, var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     double var1 = var0.getAngle();
//     java.awt.image.BufferedImage var2 = null;
//     java.awt.image.BufferedImage var3 = var0.createDropShadow(var2);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Stroke var11 = var10.getLineStroke();
    var10.setSeriesIndex((-1));
    var10.setToolTipText("");
    java.lang.Comparable var16 = var10.getSeriesKey();
    java.awt.Shape var17 = var10.getShape();
    org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity(var17, "", "hi!");
    org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var17);
    java.lang.String var22 = var21.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(100.0d, var3, var4, true);
//     var0.setNotify(true);
//     var0.setRangeCrosshairValue(100.0d, true);
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     var0.zoomRangeAxes(0.0d, 1.0d, var14, var15);
//     org.jfree.chart.plot.Marker var18 = null;
//     org.jfree.chart.util.Layer var19 = null;
//     var0.addRangeMarker(0, var18, var19, true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var6 = var4.getLegendTextFont(10);
    java.awt.Paint var10 = var4.getItemPaint(10, 100, true);
    var1.setAxisLinePaint(var10);
    var1.setMaximumCategoryLabelWidthRatio(0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    var1.setMinorTickMarkInsideLength(10.0f);
    boolean var5 = var1.isMinorTickMarksVisible();
    float var6 = var1.getMinorTickMarkInsideLength();
    boolean var7 = var1.isMinorTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Paint var11 = var2.getBasePaint();
    boolean var12 = var2.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject((java.lang.Comparable)(-1L), (java.lang.Comparable)(-101.05d));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.Marker var4 = null;
    boolean var5 = var0.removeDomainMarker(var4);
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var0.removeAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var3 = var2.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var2.zoomDomainAxes(100.0d, var5, var6, true);
    var0.addObject((java.lang.Comparable)0.2d, (java.lang.Object)var5);
    java.lang.Comparable var10 = null;
    org.jfree.data.general.DatasetGroup var12 = new org.jfree.data.general.DatasetGroup("hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setObject(var10, (java.lang.Object)var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(100.0d, var3, var4, true);
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var0.axisChanged(var7);
//     org.jfree.data.KeyedObjects2D var10 = new org.jfree.data.KeyedObjects2D();
//     int var11 = var10.getColumnCount();
//     int var12 = var10.getColumnCount();
//     var10.clear();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var16 = var15.getLabelAngle();
//     var15.setMinorTickMarkInsideLength(10.0f);
//     boolean var19 = var15.isMinorTickMarksVisible();
//     float var20 = var15.getMinorTickMarkInsideLength();
//     var10.addObject((java.lang.Object)var15, (java.lang.Comparable)(byte)10, (java.lang.Comparable)0L);
//     var0.setDomainAxis(100, var15);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     var0.drawOutline(var25, var26);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var6 = null;
    var4.setSeriesFillPaint(10, var6);
    int var8 = var4.getPassCount();
    java.awt.Font var10 = var4.lookupLegendTextFont(0);
    java.awt.Shape var12 = var4.lookupSeriesShape(10);
    var0.setShape(10, var12);
    org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity(var12);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var21 = null;
    var19.setSeriesFillPaint(10, var21);
    int var23 = var19.getPassCount();
    java.awt.Font var25 = var19.lookupLegendTextFont(0);
    java.awt.Shape var27 = var19.lookupSeriesShape(10);
    var15.setShape(10, var27);
    org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity(var27);
    var14.setArea(var27);
    org.jfree.chart.entity.ChartEntity var31 = new org.jfree.chart.entity.ChartEntity(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var3 = var0.getPaint(0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = var7.getSeriesURLGenerator(1);
    int var10 = var7.getPassCount();
    var7.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var7.setAutoPopulateSeriesOutlineStroke(true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var17 = var16.getRangeCrosshairPaint();
    var7.setBasePaint(var17);
    var0.setPaint(1, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    int var7 = var2.getPassCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
    java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
    var10.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var24 = var10.getPositiveItemLabelPosition(1, 0, false);
    var2.setBaseNegativeItemLabelPosition(var24);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = var2.getLegendItemToolTipGenerator();
    boolean var27 = var2.getBaseSeriesVisible();
    java.lang.Boolean var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShapesVisible((-1), var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setTickLabelPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Stroke var11 = var10.getLineStroke();
    var10.setSeriesIndex((-1));
    var10.setToolTipText("");
    java.lang.Comparable var16 = var10.getSeriesKey();
    java.awt.Shape var17 = var10.getShape();
    java.awt.Color var21 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    java.awt.color.ColorSpace var28 = var21.getColorSpace();
    java.awt.Color var29 = var21.brighter();
    var10.setLinePaint((java.awt.Paint)var21);
    java.awt.Color var34 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var35 = null;
    java.awt.Rectangle var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    java.awt.geom.AffineTransform var38 = null;
    java.awt.RenderingHints var39 = null;
    java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
    java.awt.color.ColorSpace var41 = var34.getColorSpace();
    float[] var43 = new float[] { (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var44 = var21.getColorComponents(var41, var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(15, var2);
    boolean var4 = var0.getBaseItemLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("GradientPaintTransformType.VERTICAL");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
//     var0.mapDatasetToRangeAxis(10, 0);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var9.setFixedRangeAxisSpace(var10);
//     org.jfree.chart.util.PaintList var12 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var16 = var15.getLabelAngle();
//     boolean var17 = var12.equals((java.lang.Object)var15);
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var15.getCategoryEnd((-1), 0, var20, var21);
//     var9.setDomainAxis(var15);
//     org.jfree.chart.plot.Plot var24 = var15.getPlot();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var30 = var28.getLegendTextFont(10);
//     java.awt.Paint var34 = var28.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", var34);
//     java.awt.Stroke var36 = var35.getLineStroke();
//     var24.setOutlineStroke(var36);
//     var0.setOutlineStroke(var36);
//     org.jfree.data.category.AbstractCategoryDataset var39 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var41 = var39.hasListener((java.util.EventListener)var40);
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.RenderingSource var45 = null;
//     var40.select(0.05d, (-1.0d), var44, var45);
//     org.jfree.chart.plot.Plot var47 = var40.getRootPlot();
//     org.jfree.chart.plot.DatasetRenderingOrder var48 = var40.getDatasetRenderingOrder();
//     java.lang.Object var49 = var40.clone();
//     var0.setParent((org.jfree.chart.plot.Plot)var40);
//     
//     // Checks the contract:  equals-hashcode on var13 and var49
//     assertTrue("Contract failed: equals-hashcode on var13 and var49", var13.equals(var49) ? var13.hashCode() == var49.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var49.", var13.equals(var49) == var49.equals(var13));
// 
//   }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     int var7 = var2.getPassCount();
//     var2.setDataBoundsIncludesVisibleSeriesOnly(true);
//     java.awt.Paint var11 = var2.getLegendTextPaint((-1));
//     org.jfree.chart.urls.CategoryURLGenerator var12 = null;
//     var2.setBaseURLGenerator(var12, true);
//     java.awt.Paint var18 = var2.getItemOutlinePaint(128, 3, false);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var21 = var20.getLabelAngle();
//     var20.setTickMarksVisible(true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var28 = var26.getSeriesURLGenerator(1);
//     java.awt.Paint var30 = null;
//     var26.setSeriesPaint(0, var30, true);
//     org.jfree.data.category.AbstractCategoryDataset var33 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var35 = var33.hasListener((java.util.EventListener)var34);
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.RenderingSource var39 = null;
//     var34.select(0.05d, (-1.0d), var38, var39);
//     boolean var41 = var34.isRangeCrosshairVisible();
//     java.awt.Font var42 = var34.getNoDataMessageFont();
//     var26.setBaseItemLabelFont(var42, false);
//     var20.setTickLabelFont(var42);
//     var2.setBaseItemLabelFont(var42);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var3 = var2.getLabelAngle();
//     var2.setMinorTickMarkInsideLength(10.0f);
//     double var6 = var2.getLowerMargin();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
//     java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
//     var10.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var27 = var25.getSeriesURLGenerator(1);
//     var25.setUseOutlinePaint(false);
//     boolean var32 = var25.getItemShapeVisible(0, (-1));
//     java.awt.Font var34 = var25.getSeriesItemLabelFont(1);
//     var25.setBaseSeriesVisibleInLegend(false, false);
//     java.awt.Paint var38 = var25.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var44 = var42.getLegendTextFont(10);
//     java.awt.Paint var48 = var42.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", var48);
//     java.awt.Stroke var50 = var49.getLineStroke();
//     java.awt.Paint var51 = var49.getLabelPaint();
//     java.awt.Stroke var52 = var49.getOutlineStroke();
//     var25.setBaseStroke(var52, false);
//     var10.setSeriesOutlineStroke(15, var52, true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var10
//     assertTrue("Contract failed: equals-hashcode on var42 and var10", var42.equals(var10) ? var42.hashCode() == var10.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var42 and var10.", var42.equals(var10) == var10.equals(var42));
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setLabelURL("");
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var5 = var4.getRangeCrosshairPaint();
//     float var6 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers();
//     var4.setNoDataMessage("hi!");
//     org.jfree.chart.axis.CategoryAnchor var10 = var4.getDomainGridlinePosition();
//     java.lang.Object var11 = null;
//     boolean var12 = var10.equals(var11);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.category.AbstractCategoryDataset var16 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var18 = var16.hasListener((java.util.EventListener)var17);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.RenderingSource var22 = null;
//     var17.select(0.05d, (-1.0d), var21, var22);
//     boolean var24 = var17.isRangeCrosshairVisible();
//     java.lang.Comparable var25 = null;
//     var17.setDomainCrosshairColumnKey(var25);
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var17.setFixedRangeAxisSpace(var27, false);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     int var31 = var17.indexOf(var30);
//     org.jfree.chart.util.RectangleEdge var32 = var17.getRangeAxisEdge();
//     double var33 = var1.getCategoryJava2DCoordinate(var10, 100, 128, var15, var32);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     boolean var6 = var1.removeDomainMarker(0, var4, var5);
//     org.jfree.data.category.AbstractCategoryDataset var7 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var9 = var7.hasListener((java.util.EventListener)var8);
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.RenderingSource var13 = null;
//     var8.select(0.05d, (-1.0d), var12, var13);
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint var18 = null;
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Shape var24 = null;
//     java.awt.Shape[] var25 = new java.awt.Shape[] { var24};
//     org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var19, var21, var23, var25);
//     boolean var27 = var15.equals((java.lang.Object)var25);
//     var8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var15, true);
//     var1.setParent((org.jfree.chart.plot.Plot)var8);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    int var6 = var2.getDefaultEntityRadius();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var12 = null;
    var10.setSeriesFillPaint(10, var12);
    int var14 = var10.getPassCount();
    java.awt.Font var16 = var10.lookupLegendTextFont(0);
    java.awt.Font var17 = null;
    var10.setBaseLegendTextFont(var17);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var22 = var21.getLabelAngle();
    var21.setMinorTickMarkInsideLength(10.0f);
    boolean var25 = var21.isMinorTickMarksVisible();
    float var26 = var21.getMinorTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var28 = null;
    var27.setFixedRangeAxisSpace(var28);
    org.jfree.chart.util.PaintList var30 = new org.jfree.chart.util.PaintList();
    java.lang.Object var31 = var30.clone();
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var34 = var33.getLabelAngle();
    boolean var35 = var30.equals((java.lang.Object)var33);
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    double var40 = var33.getCategoryEnd((-1), 0, var38, var39);
    var27.setDomainAxis(var33);
    var27.setDrawSharedDomainAxis(true);
    java.awt.Paint var44 = var27.getRangeZeroBaselinePaint();
    var21.setTickLabelPaint(var44);
    var10.setSeriesFillPaint(128, var44);
    org.jfree.chart.labels.ItemLabelPosition var50 = var10.getPositiveItemLabelPosition(10, 10, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesPositiveItemLabelPosition((-1), var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getLabelAngle();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
//     java.lang.String var11 = var3.getLabelToolTip();
//     var3.removeCategoryLabelToolTip((java.lang.Comparable)15);
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var21 = null;
//     var20.setFixedRangeAxisSpace(var21);
//     org.jfree.chart.util.RectangleEdge var23 = var20.getDomainAxisEdge();
//     double var24 = var3.getCategorySeriesMiddle(2, 10, 15, (-1), 0.0d, var19, var23);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    var0.setNotify(true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
    var0.mapDatasetToRangeAxis(100, 3);
    java.awt.Stroke var13 = var0.getDomainCrosshairStroke();
    org.jfree.chart.plot.Marker var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var18 = var0.removeRangeMarker(3, var15, var16, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    java.awt.Font var11 = var2.getSeriesItemLabelFont(1);
    var2.setBaseSeriesVisibleInLegend(false, false);
    java.awt.Paint var15 = var2.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var21 = var19.getLegendTextFont(10);
    java.awt.Paint var25 = var19.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", var25);
    java.awt.Stroke var27 = var26.getLineStroke();
    java.awt.Paint var28 = var26.getLabelPaint();
    java.awt.Stroke var29 = var26.getOutlineStroke();
    var2.setBaseStroke(var29, false);
    java.lang.Boolean var33 = var2.getSeriesCreateEntities(1);
    java.awt.Paint var35 = null;
    java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
    java.awt.Paint var37 = null;
    java.awt.Paint[] var38 = new java.awt.Paint[] { var37};
    java.awt.Stroke var39 = null;
    java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
    java.awt.Stroke var41 = null;
    java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
    java.awt.Shape var43 = null;
    java.awt.Shape[] var44 = new java.awt.Shape[] { var43};
    org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier(var36, var38, var40, var42, var44);
    boolean var47 = var45.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var52 = null;
    var50.setSeriesFillPaint(10, var52);
    int var54 = var50.getPassCount();
    java.awt.Font var56 = var50.lookupLegendTextFont(0);
    java.awt.Shape var58 = var50.lookupSeriesShape(10);
    boolean var59 = var45.equals((java.lang.Object)var58);
    org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var62 = null;
    org.jfree.chart.util.Layer var63 = null;
    boolean var64 = var60.removeDomainMarker(1, var62, var63);
    org.jfree.chart.axis.AxisLocation var66 = var60.getDomainAxisLocation(100);
    org.jfree.chart.entity.PlotEntity var68 = new org.jfree.chart.entity.PlotEntity(var58, (org.jfree.chart.plot.Plot)var60, "hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShape((-1), var58, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.awt.Paint var1 = null;
    java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
    java.awt.Paint var3 = null;
    java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var4, var6, var8, var10);
    boolean var12 = var0.equals((java.lang.Object)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var14 = var0.get(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.AffineTransform var7 = null;
//     java.awt.RenderingHints var8 = null;
//     java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
//     java.awt.color.ColorSpace var10 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var15 = var13.getSeriesURLGenerator(1);
//     int var16 = var13.getPassCount();
//     var13.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var20 = null;
//     var13.setBaseItemLabelGenerator(var20, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var28 = var26.getLegendTextFont(10);
//     java.awt.Paint var32 = var26.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("", var32);
//     java.awt.Stroke var34 = var33.getLineStroke();
//     var33.setSeriesIndex((-1));
//     var33.setToolTipText("");
//     java.lang.Comparable var39 = var33.getSeriesKey();
//     java.awt.Shape var40 = var33.getShape();
//     java.awt.Color var44 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var45 = null;
//     java.awt.Rectangle var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     java.awt.geom.AffineTransform var48 = null;
//     java.awt.RenderingHints var49 = null;
//     java.awt.PaintContext var50 = var44.createContext(var45, var46, var47, var48, var49);
//     java.awt.color.ColorSpace var51 = var44.getColorSpace();
//     java.awt.Color var52 = var44.brighter();
//     var33.setLinePaint((java.awt.Paint)var44);
//     var13.setBaseItemLabelPaint((java.awt.Paint)var44, false);
//     float[] var59 = new float[] { 100.0f, 0.0f, 10.0f};
//     float[] var60 = var44.getColorComponents(var59);
//     float[] var61 = var3.getComponents(var10, var59);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)0.5f);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     float var2 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedRangeAxisSpace(var3, false);
//     var0.zoom((-101.05d));
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.awt.GradientPaint var1 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var7 = var5.getLegendTextFont(10);
//     java.awt.Paint var11 = var5.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("", var11);
//     java.awt.Stroke var13 = var12.getLineStroke();
//     java.awt.Paint var14 = var12.getLabelPaint();
//     java.awt.Paint var15 = var12.getFillPaint();
//     java.awt.Shape var16 = var12.getShape();
//     java.awt.GradientPaint var17 = var0.transform(var1, var16);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var7 = var2.getAutoPopulateSeriesOutlinePaint();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var11 = var10.getRangeCrosshairPaint();
    var10.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var15 = var2.initialise(var8, var9, var10, var13, var14);
    org.jfree.chart.util.RectangleInsets var16 = var10.getInsets();
    org.jfree.chart.plot.CategoryMarker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addDomainMarker(3, var18, var19, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.clear();
    java.util.List var2 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Shape var8 = null;
//     java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
//     boolean var12 = var10.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var17 = null;
//     var15.setSeriesFillPaint(10, var17);
//     int var19 = var15.getPassCount();
//     java.awt.Font var21 = var15.lookupLegendTextFont(0);
//     java.awt.Shape var23 = var15.lookupSeriesShape(10);
//     boolean var24 = var10.equals((java.lang.Object)var23);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var27 = null;
//     org.jfree.chart.util.Layer var28 = null;
//     boolean var29 = var25.removeDomainMarker(1, var27, var28);
//     org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var25, "hi!");
//     org.jfree.chart.plot.PlotOrientation var34 = var25.getOrientation();
//     java.lang.Object var35 = null;
//     boolean var36 = var34.equals(var35);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var41 = var39.getLegendTextFont(10);
//     java.awt.Paint var45 = var39.getItemPaint(10, 100, true);
//     int var46 = var39.getPassCount();
//     boolean var47 = var34.equals((java.lang.Object)var39);
//     
//     // Checks the contract:  equals-hashcode on var15 and var39
//     assertTrue("Contract failed: equals-hashcode on var15 and var39", var15.equals(var39) ? var15.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var15
//     assertTrue("Contract failed: equals-hashcode on var39 and var15", var39.equals(var15) ? var39.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-1), var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    boolean var12 = var1.isDomainPannable();
    org.jfree.chart.plot.DrawingSupplier var13 = var1.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.clear();
    java.util.List var2 = var0.getRowKeys();
    java.lang.Comparable var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject(var3, (java.lang.Comparable)10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    int var3 = var0.getRowIndex((java.lang.Comparable)(short)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var5 = var3.getLegendTextFont(10);
//     java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
//     java.awt.Stroke var11 = var10.getLineStroke();
//     var10.setSeriesIndex((-1));
//     var10.setToolTipText("");
//     java.lang.Comparable var16 = var10.getSeriesKey();
//     java.awt.Shape var17 = var10.getShape();
//     org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity(var17, "", "hi!");
//     org.jfree.chart.util.PaintList var21 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var25 = var24.getLabelAngle();
//     boolean var26 = var21.equals((java.lang.Object)var24);
//     boolean var27 = var20.equals((java.lang.Object)var24);
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var28 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var29 = null;
//     java.lang.String var30 = var20.getImageMapAreaTag(var28, var29);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), 1.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16646144));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     var2.setUseOutlinePaint(false);
//     boolean var7 = var2.getAutoPopulateSeriesOutlinePaint();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var11 = var10.getRangeCrosshairPaint();
//     var10.configureDomainAxes();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var15 = var2.initialise(var8, var9, var10, var13, var14);
//     boolean var18 = var2.getItemShapeVisible(0, 100);
//     org.jfree.chart.labels.ItemLabelPosition var19 = var2.getBasePositiveItemLabelPosition();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var25 = var23.getSeriesURLGenerator(1);
//     var23.setUseOutlinePaint(false);
//     boolean var28 = var23.getAutoPopulateSeriesOutlinePaint();
//     java.awt.Graphics2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var32 = var31.getRangeCrosshairPaint();
//     var31.configureDomainAxes();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var36 = var23.initialise(var29, var30, var31, var34, var35);
//     var31.setBackgroundAlpha(1.0f);
//     org.jfree.chart.util.PaintList var39 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var40 = var39.clone();
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var43 = var42.getLabelAngle();
//     boolean var44 = var39.equals((java.lang.Object)var42);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var46 = null;
//     var45.setFixedRangeAxisSpace(var46);
//     var45.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.util.SortOrder var50 = var45.getColumnRenderingOrder();
//     var45.mapDatasetToRangeAxis(10, 0);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var55 = null;
//     var54.setFixedRangeAxisSpace(var55);
//     org.jfree.chart.util.PaintList var57 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var58 = var57.clone();
//     org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var61 = var60.getLabelAngle();
//     boolean var62 = var57.equals((java.lang.Object)var60);
//     java.awt.geom.Rectangle2D var65 = null;
//     org.jfree.chart.util.RectangleEdge var66 = null;
//     double var67 = var60.getCategoryEnd((-1), 0, var65, var66);
//     var54.setDomainAxis(var60);
//     org.jfree.chart.plot.Plot var69 = var60.getPlot();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var73 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var75 = var73.getLegendTextFont(10);
//     java.awt.Paint var79 = var73.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var80 = new org.jfree.chart.LegendItem("", var79);
//     java.awt.Stroke var81 = var80.getLineStroke();
//     var69.setOutlineStroke(var81);
//     var45.setOutlineStroke(var81);
//     var42.setTickMarkStroke(var81);
//     var31.setRangeZeroBaselineStroke(var81);
//     org.jfree.chart.axis.CategoryAxis var87 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var88 = var87.getLabelAngle();
//     var87.setTickMarksVisible(true);
//     double var91 = var87.getFixedDimension();
//     java.awt.Paint var92 = var87.getLabelPaint();
//     java.awt.Stroke var93 = var87.getAxisLineStroke();
//     org.jfree.chart.plot.CategoryMarker var94 = null;
//     java.awt.geom.Rectangle2D var95 = null;
//     var2.drawDomainMarker(var20, var31, var87, var94, var95);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.Marker var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var2.drawRangeMarker(var10, var11, var12, var13, var14);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    var11.clearSelection();
    org.jfree.chart.util.RectangleInsets var22 = new org.jfree.chart.util.RectangleInsets(1.0d, 0.05d, 0.05d, 100.0d);
    double var23 = var22.getTop();
    org.jfree.chart.util.UnitType var24 = var22.getUnitType();
    var11.setAxisOffset(var22);
    org.jfree.chart.util.UnitType var26 = var22.getUnitType();
    java.lang.String var27 = var26.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "UnitType.ABSOLUTE"+ "'", var27.equals("UnitType.ABSOLUTE"));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Stroke var11 = var10.getLineStroke();
    var10.setSeriesIndex((-1));
    var10.setToolTipText("");
    java.lang.Comparable var16 = var10.getSeriesKey();
    java.awt.Shape var17 = var10.getShape();
    java.awt.Paint var18 = var10.getOutlinePaint();
    java.lang.String var19 = var10.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + ""+ "'", var19.equals(""));

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var3 = var2.getLabelAngle();
//     var2.setMinorTickMarkInsideLength(10.0f);
//     double var6 = var2.getLowerMargin();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
//     java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
//     var10.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     java.awt.Font var22 = var21.getNoDataMessageFont();
//     org.jfree.chart.util.RectangleInsets var23 = var21.getAxisOffset();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var28 = null;
//     var26.setSeriesFillPaint(10, var28);
//     int var30 = var26.getPassCount();
//     var26.setAutoPopulateSeriesShape(true);
//     java.awt.Paint var33 = var26.getBaseItemLabelPaint();
//     var21.setRangeZeroBaselinePaint(var33);
//     
//     // Checks the contract:  equals-hashcode on var10 and var26
//     assertTrue("Contract failed: equals-hashcode on var10 and var26", var10.equals(var26) ? var10.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var10
//     assertTrue("Contract failed: equals-hashcode on var26 and var10", var26.equals(var10) ? var26.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    java.awt.Paint var11 = var2.lookupLegendTextPaint((-1));
    java.awt.Stroke var15 = var2.getItemStroke(3, 10, true);
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseItemLabelPaint(var16, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    org.jfree.chart.axis.CategoryAxis var14 = var1.getDomainAxis();
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addAnnotation(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    var1.setDrawSharedDomainAxis(false);
    var1.setDomainCrosshairRowKey((java.lang.Comparable)(short)0);
    var1.setDomainCrosshairRowKey((java.lang.Comparable)(byte)10, false);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var23 = var22.getLabelAngle();
    boolean var24 = var22.isVisible();
    double var25 = var22.getFixedDimension();
    java.lang.String var26 = var22.getLabel();
    java.lang.String var27 = var22.getLabelURL();
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var30 = var29.getLabelAngle();
    var29.setMinorTickMarkInsideLength(10.0f);
    boolean var33 = var29.isMinorTickMarksVisible();
    float var34 = var29.getMinorTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var36 = null;
    var35.setFixedRangeAxisSpace(var36);
    org.jfree.chart.util.PaintList var38 = new org.jfree.chart.util.PaintList();
    java.lang.Object var39 = var38.clone();
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var42 = var41.getLabelAngle();
    boolean var43 = var38.equals((java.lang.Object)var41);
    java.awt.geom.Rectangle2D var46 = null;
    org.jfree.chart.util.RectangleEdge var47 = null;
    double var48 = var41.getCategoryEnd((-1), 0, var46, var47);
    var35.setDomainAxis(var41);
    var35.setDrawSharedDomainAxis(true);
    java.awt.Paint var52 = var35.getRangeZeroBaselinePaint();
    var29.setTickLabelPaint(var52);
    var22.setTickLabelPaint(var52);
    var1.setBackgroundPaint(var52);
    org.jfree.chart.plot.Marker var56 = null;
    org.jfree.chart.util.Layer var57 = null;
    boolean var58 = var1.removeDomainMarker(var56, var57);
    org.jfree.chart.axis.CategoryAxis var60 = var1.getDomainAxis(2);
    java.awt.Paint var61 = var1.getNoDataMessagePaint();
    org.jfree.chart.plot.Marker var63 = null;
    org.jfree.chart.util.Layer var64 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var65 = var1.removeRangeMarker(100, var63, var64);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "hi!"+ "'", var26.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    var2.setAutoPopulateSeriesStroke(true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var2.getLegendItemToolTipGenerator();
    var2.setUseOutlinePaint(false);
    org.jfree.chart.LegendItem var17 = var2.getLegendItem(128, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     org.jfree.chart.urls.CategoryURLGenerator var7 = null;
//     var2.setBaseURLGenerator(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.category.AbstractCategoryDataset var10 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var12 = var10.hasListener((java.util.EventListener)var11);
//     org.jfree.chart.plot.Marker var14 = null;
//     org.jfree.chart.util.Layer var15 = null;
//     boolean var16 = var11.removeDomainMarker(0, var14, var15);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var11.zoomDomainAxes(100.0d, var18, var19, false);
//     var11.setCrosshairDatasetIndex(3);
//     org.jfree.chart.plot.Plot var24 = var11.getParent();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var30 = var28.getLegendTextFont(10);
//     java.awt.Paint var34 = var28.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", var34);
//     java.awt.Stroke var36 = var35.getLineStroke();
//     var35.setSeriesIndex((-1));
//     var35.setToolTipText("");
//     java.lang.Comparable var41 = var35.getSeriesKey();
//     java.awt.Shape var42 = var35.getShape();
//     org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "", "hi!");
//     org.jfree.chart.util.PaintList var46 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var47 = var46.clone();
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var50 = var49.getLabelAngle();
//     boolean var51 = var46.equals((java.lang.Object)var49);
//     boolean var52 = var45.equals((java.lang.Object)var49);
//     org.jfree.chart.plot.CategoryMarker var53 = null;
//     java.awt.geom.Rectangle2D var54 = null;
//     var2.drawDomainMarker(var9, var11, var49, var53, var54);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var5 = var3.getLegendTextFont(10);
//     java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
//     java.awt.Stroke var11 = var10.getLineStroke();
//     var10.setSeriesIndex((-1));
//     var10.setToolTipText("");
//     java.awt.Paint var16 = var10.getFillPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var22 = var20.getLegendTextFont(10);
//     java.awt.Paint var26 = var20.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("", var26);
//     java.awt.Stroke var28 = var27.getLineStroke();
//     var27.setSeriesIndex((-1));
//     var27.setToolTipText("");
//     java.awt.Paint var33 = var27.getFillPaint();
//     var10.setFillPaint(var33);
//     
//     // Checks the contract:  equals-hashcode on var10 and var27
//     assertTrue("Contract failed: equals-hashcode on var10 and var27", var10.equals(var27) ? var10.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var10
//     assertTrue("Contract failed: equals-hashcode on var27 and var10", var27.equals(var10) ? var27.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    org.jfree.data.category.AbstractCategoryDataset var7 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    boolean var9 = var7.hasListener((java.util.EventListener)var8);
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.RenderingSource var13 = null;
    var8.select(0.05d, (-1.0d), var12, var13);
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = null;
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Paint var18 = null;
    java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
    java.awt.Stroke var20 = null;
    java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
    java.awt.Stroke var22 = null;
    java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
    java.awt.Shape var24 = null;
    java.awt.Shape[] var25 = new java.awt.Shape[] { var24};
    org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var19, var21, var23, var25);
    boolean var27 = var15.equals((java.lang.Object)var25);
    var8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var15, true);
    java.awt.Stroke var30 = var15.getNextStroke();
    var2.setBaseStroke(var30, true);
    java.awt.Shape var34 = var2.lookupSeriesShape(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected(15, 0, true);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    boolean var8 = var1.isRangeMinorGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getLabelAngle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDomainAxis((-1), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = var0.getRowIndex(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Stroke var12 = var2.lookupSeriesOutlineStroke((-1));
    boolean var13 = var2.getUseFillPaint();
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var16.setLowerMargin(10.0d);
    double var19 = var16.getUpperMargin();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var21 = var20.getRangeCrosshairPaint();
    float var22 = var20.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var23 = var20.getFixedRangeAxisSpace();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var25 = null;
    var24.setFixedRangeAxisSpace(var25);
    org.jfree.chart.util.PaintList var27 = new org.jfree.chart.util.PaintList();
    java.lang.Object var28 = var27.clone();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var31 = var30.getLabelAngle();
    boolean var32 = var27.equals((java.lang.Object)var30);
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var30.getCategoryEnd((-1), 0, var35, var36);
    var24.setDomainAxis(var30);
    var24.setDrawSharedDomainAxis(true);
    java.awt.Paint var41 = var24.getRangeZeroBaselinePaint();
    var20.setRangeCrosshairPaint(var41);
    var16.setAxisLinePaint(var41);
    var2.setSeriesItemLabelPaint(3, var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.RenderingSource var6 = null;
//     var1.select(0.05d, (-1.0d), var5, var6);
//     org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
//     org.jfree.chart.plot.DatasetRenderingOrder var9 = var1.getDatasetRenderingOrder();
//     java.lang.Object var10 = var1.clone();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var11.setFixedRangeAxisSpace(var12);
//     var11.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.util.SortOrder var16 = var11.getColumnRenderingOrder();
//     var11.mapDatasetToRangeAxis(10, 0);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var21 = null;
//     var20.setFixedRangeAxisSpace(var21);
//     org.jfree.chart.util.PaintList var23 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var24 = var23.clone();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var27 = var26.getLabelAngle();
//     boolean var28 = var23.equals((java.lang.Object)var26);
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     double var33 = var26.getCategoryEnd((-1), 0, var31, var32);
//     var20.setDomainAxis(var26);
//     org.jfree.chart.plot.Plot var35 = var26.getPlot();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var41 = var39.getLegendTextFont(10);
//     java.awt.Paint var45 = var39.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("", var45);
//     java.awt.Stroke var47 = var46.getLineStroke();
//     var35.setOutlineStroke(var47);
//     var11.setOutlineStroke(var47);
//     var1.setRangeZeroBaselineStroke(var47);
//     
//     // Checks the contract:  equals-hashcode on var24 and var10
//     assertTrue("Contract failed: equals-hashcode on var24 and var10", var24.equals(var10) ? var24.hashCode() == var10.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var10.", var24.equals(var10) == var10.equals(var24));
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.clear();
    var0.setObject((java.lang.Object)true, (java.lang.Comparable)1, (java.lang.Comparable)100);
    boolean var7 = var0.equals((java.lang.Object)1.0d);
    int var9 = var0.getColumnIndex((java.lang.Comparable)10);
    java.lang.Comparable var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.getColumnIndex(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     org.jfree.chart.util.PaintList var3 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var4 = var3.clone();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var7 = var6.getLabelAngle();
//     boolean var8 = var3.equals((java.lang.Object)var6);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var6.getCategoryEnd((-1), 0, var11, var12);
//     var0.setDomainAxis(var6);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var16 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var15.zoomDomainAxes(100.0d, var18, var19, true);
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var15.axisChanged(var22);
//     org.jfree.data.KeyedObjects2D var25 = new org.jfree.data.KeyedObjects2D();
//     int var26 = var25.getColumnCount();
//     int var27 = var25.getColumnCount();
//     var25.clear();
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var31 = var30.getLabelAngle();
//     var30.setMinorTickMarkInsideLength(10.0f);
//     boolean var34 = var30.isMinorTickMarksVisible();
//     float var35 = var30.getMinorTickMarkInsideLength();
//     var25.addObject((java.lang.Object)var30, (java.lang.Comparable)(byte)10, (java.lang.Comparable)0L);
//     var15.setDomainAxis(100, var30);
//     var15.setRangeCrosshairValue(0.2d, true);
//     var6.setPlot((org.jfree.chart.plot.Plot)var15);
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var48 = null;
//     var47.setFixedRangeAxisSpace(var48);
//     boolean var50 = var47.isRangeGridlinesVisible();
//     var47.setRangeCrosshairValue(0.0d, true);
//     boolean var54 = var47.isRangeMinorGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     java.awt.geom.Point2D var57 = null;
//     var47.zoomDomainAxes(100.0d, var56, var57, false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var61 = null;
//     java.awt.Paint[] var62 = new java.awt.Paint[] { var61};
//     java.awt.Paint var63 = null;
//     java.awt.Paint[] var64 = new java.awt.Paint[] { var63};
//     java.awt.Stroke var65 = null;
//     java.awt.Stroke[] var66 = new java.awt.Stroke[] { var65};
//     java.awt.Stroke var67 = null;
//     java.awt.Stroke[] var68 = new java.awt.Stroke[] { var67};
//     java.awt.Shape var69 = null;
//     java.awt.Shape[] var70 = new java.awt.Shape[] { var69};
//     org.jfree.chart.plot.DefaultDrawingSupplier var71 = new org.jfree.chart.plot.DefaultDrawingSupplier(var62, var64, var66, var68, var70);
//     boolean var72 = var60.equals((java.lang.Object)var70);
//     java.awt.Stroke var73 = var60.getNextOutlineStroke();
//     var47.setOutlineStroke(var73);
//     org.jfree.chart.axis.ValueAxis var75 = var47.getRangeAxis();
//     org.jfree.chart.util.RectangleEdge var77 = var47.getRangeAxisEdge(0);
//     double var78 = var6.getCategoryEnd(128, 15, var46, var77);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    double var9 = var2.getItemMargin();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = null;
    var2.setLegendItemURLGenerator(var10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var16 = null;
    var14.setSeriesFillPaint(10, var16);
    int var18 = var14.getPassCount();
    java.awt.Font var20 = var14.lookupLegendTextFont(0);
    java.awt.Shape var22 = var14.lookupSeriesShape(10);
    var2.setBaseLegendShape(var22);
    java.awt.Paint var24 = null;
    var2.setBaseLegendTextPaint(var24);
    var2.removeAnnotations();
    java.awt.Color var31 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    var2.setSeriesItemLabelPaint(2, (java.awt.Paint)var31);
    boolean var33 = var2.getAutoPopulateSeriesStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var5 = var3.getLegendTextFont(10);
//     java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
//     java.awt.Stroke var11 = var10.getLineStroke();
//     var10.setSeriesIndex((-1));
//     var10.setToolTipText("");
//     java.lang.Comparable var16 = var10.getSeriesKey();
//     java.awt.Shape var17 = var10.getShape();
//     java.awt.Color var21 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.awt.geom.AffineTransform var25 = null;
//     java.awt.RenderingHints var26 = null;
//     java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
//     java.awt.color.ColorSpace var28 = var21.getColorSpace();
//     java.awt.Color var29 = var21.brighter();
//     var10.setLinePaint((java.awt.Paint)var21);
//     java.awt.color.ColorSpace var31 = var21.getColorSpace();
//     java.awt.color.ColorSpace var32 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var43 = var41.getSeriesURLGenerator(1);
//     int var44 = var41.getPassCount();
//     var41.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var48 = null;
//     var41.setBaseItemLabelGenerator(var48, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var56 = var54.getLegendTextFont(10);
//     java.awt.Paint var60 = var54.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("", var60);
//     java.awt.Stroke var62 = var61.getLineStroke();
//     var61.setSeriesIndex((-1));
//     var61.setToolTipText("");
//     java.lang.Comparable var67 = var61.getSeriesKey();
//     java.awt.Shape var68 = var61.getShape();
//     java.awt.Color var72 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var73 = null;
//     java.awt.Rectangle var74 = null;
//     java.awt.geom.Rectangle2D var75 = null;
//     java.awt.geom.AffineTransform var76 = null;
//     java.awt.RenderingHints var77 = null;
//     java.awt.PaintContext var78 = var72.createContext(var73, var74, var75, var76, var77);
//     java.awt.color.ColorSpace var79 = var72.getColorSpace();
//     java.awt.Color var80 = var72.brighter();
//     var61.setLinePaint((java.awt.Paint)var72);
//     var41.setBaseItemLabelPaint((java.awt.Paint)var72, false);
//     float[] var87 = new float[] { 100.0f, 0.0f, 10.0f};
//     float[] var88 = var72.getColorComponents(var87);
//     float[] var89 = java.awt.Color.RGBtoHSB(100, 0, 128, var88);
//     float[] var90 = java.awt.Color.RGBtoHSB(10, 100, 2, var88);
//     float[] var91 = var21.getComponents(var32, var90);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var11 = null;
    var10.setFixedRangeAxisSpace(var11);
    boolean var13 = var10.isRangeGridlinesVisible();
    var10.setRangeCrosshairValue(0.0d, true);
    boolean var17 = var10.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var10.zoomDomainAxes(100.0d, var19, var20, false);
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var24 = null;
    java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
    java.awt.Paint var26 = null;
    java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
    java.awt.Stroke var28 = null;
    java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
    java.awt.Stroke var30 = null;
    java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
    java.awt.Shape var32 = null;
    java.awt.Shape[] var33 = new java.awt.Shape[] { var32};
    org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier(var25, var27, var29, var31, var33);
    boolean var35 = var23.equals((java.lang.Object)var33);
    java.awt.Stroke var36 = var23.getNextOutlineStroke();
    var10.setOutlineStroke(var36);
    var2.setSeriesStroke(2, var36);
    java.awt.Paint var40 = var2.getSeriesFillPaint(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    java.lang.Object var3 = null;
    var0.setObject((java.lang.Comparable)"hi!", var3);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var11 = var9.getSeriesURLGenerator(1);
    int var12 = var9.getPassCount();
    var9.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var9.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Paint var18 = var9.getBasePaint();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.String var22 = var21.getLabel();
    org.jfree.data.category.AbstractCategoryDataset var23 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    boolean var25 = var23.hasListener((java.util.EventListener)var24);
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.RenderingSource var29 = null;
    var24.select(0.05d, (-1.0d), var28, var29);
    boolean var31 = var24.isRangeCrosshairVisible();
    java.awt.Font var32 = var24.getNoDataMessageFont();
    var21.setLabelFont(var32);
    org.jfree.chart.util.PaintList var34 = new org.jfree.chart.util.PaintList();
    java.lang.Object var35 = var34.clone();
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var38 = var37.getLabelAngle();
    boolean var39 = var34.equals((java.lang.Object)var37);
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.util.RectangleEdge var43 = null;
    double var44 = var37.getCategoryEnd((-1), 0, var42, var43);
    java.lang.String var45 = var37.getLabelToolTip();
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var47 = null;
    var46.setFixedRangeAxisSpace(var47);
    org.jfree.chart.util.PaintList var49 = new org.jfree.chart.util.PaintList();
    java.lang.Object var50 = var49.clone();
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var53 = var52.getLabelAngle();
    boolean var54 = var49.equals((java.lang.Object)var52);
    java.awt.geom.Rectangle2D var57 = null;
    org.jfree.chart.util.RectangleEdge var58 = null;
    double var59 = var52.getCategoryEnd((-1), 0, var57, var58);
    var46.setDomainAxis(var52);
    var46.setDrawSharedDomainAxis(true);
    java.awt.Paint var63 = var46.getRangeZeroBaselinePaint();
    boolean var64 = var37.hasListener((java.util.EventListener)var46);
    java.awt.Stroke var65 = var46.getRangeZeroBaselineStroke();
    var21.setTickMarkStroke(var65);
    var9.setSeriesOutlineStroke(0, var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue(4, (java.lang.Comparable)0.05d, (java.lang.Object)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "hi!"+ "'", var22.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Stroke var11 = var10.getLineStroke();
    var10.setSeriesIndex((-1));
    var10.setToolTipText("");
    java.lang.Comparable var16 = var10.getSeriesKey();
    java.awt.Shape var17 = var10.getShape();
    java.awt.Paint var18 = var10.getOutlinePaint();
    var10.setSeriesKey((java.lang.Comparable)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     boolean var3 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.0d, true);
//     boolean var7 = var0.isRangeMinorGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     var0.zoomDomainAxes(0.0d, var9, var10);
//     java.awt.Paint var12 = var0.getBackgroundPaint();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var14 = null;
//     var13.setFixedRangeAxisSpace(var14);
//     org.jfree.chart.util.PaintList var16 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var20 = var19.getLabelAngle();
//     boolean var21 = var16.equals((java.lang.Object)var19);
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var19.getCategoryEnd((-1), 0, var24, var25);
//     var13.setDomainAxis(var19);
//     org.jfree.chart.plot.Plot var28 = var19.getPlot();
//     org.jfree.chart.axis.CategoryAxis[] var29 = new org.jfree.chart.axis.CategoryAxis[] { var19};
//     var0.setDomainAxes(var29);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    double var9 = var2.getItemMargin();
    org.jfree.chart.urls.CategoryURLGenerator var10 = var2.getBaseURLGenerator();
    java.awt.Paint var11 = null;
    var2.setBasePaint(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    java.lang.Boolean var7 = var2.getSeriesItemLabelsVisible(0);
    java.awt.Paint var9 = var2.getSeriesItemLabelPaint(2);
    boolean var13 = var2.isItemLabelVisible(128, 10, false);
    boolean var14 = var2.getDrawOutlines();
    org.jfree.chart.labels.CategoryToolTipGenerator var18 = var2.getToolTipGenerator(2, (-1), false);
    java.awt.Stroke var22 = var2.getItemStroke(100, 2, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    boolean var5 = var1.removeDomainMarker(1, var3, var4);
    var1.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var1.getRangeMarkers(var8);
    java.awt.Stroke var10 = var1.getRangeCrosshairStroke();
    boolean var11 = var0.equals((java.lang.Object)var10);
    int var12 = var0.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)2.0d);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.awt.Paint var1 = null;
    java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
    java.awt.Paint var3 = null;
    java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var4, var6, var8, var10);
    boolean var12 = var0.equals((java.lang.Object)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var14 = var0.get(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     java.awt.Paint var1 = null;
//     java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
//     java.awt.Paint var3 = null;
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape var9 = null;
//     java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var4, var6, var8, var10);
//     java.awt.Paint var12 = null;
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     java.awt.Paint var14 = null;
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Stroke var16 = null;
//     java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
//     java.awt.Stroke var18 = null;
//     java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
//     java.awt.Shape var20 = null;
//     java.awt.Shape[] var21 = new java.awt.Shape[] { var20};
//     org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var15, var17, var19, var21);
//     org.jfree.chart.util.PaintList var23 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var24 = var23.clone();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var27 = var26.getLabelAngle();
//     boolean var28 = var23.equals((java.lang.Object)var26);
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     double var33 = var26.getCategoryEnd((-1), 0, var31, var32);
//     java.lang.String var34 = var26.getLabelToolTip();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var36 = null;
//     var35.setFixedRangeAxisSpace(var36);
//     org.jfree.chart.util.PaintList var38 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var39 = var38.clone();
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var42 = var41.getLabelAngle();
//     boolean var43 = var38.equals((java.lang.Object)var41);
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleEdge var47 = null;
//     double var48 = var41.getCategoryEnd((-1), 0, var46, var47);
//     var35.setDomainAxis(var41);
//     var35.setDrawSharedDomainAxis(true);
//     java.awt.Paint var52 = var35.getRangeZeroBaselinePaint();
//     boolean var53 = var26.hasListener((java.util.EventListener)var35);
//     java.awt.Stroke var54 = var35.getRangeZeroBaselineStroke();
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     java.awt.Shape[] var56 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var57 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var4, var19, var55, var56);
//     
//     // Checks the contract:  equals-hashcode on var11 and var22
//     assertTrue("Contract failed: equals-hashcode on var11 and var22", var11.equals(var22) ? var11.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var11
//     assertTrue("Contract failed: equals-hashcode on var22 and var11", var22.equals(var11) ? var22.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.Marker var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var2.drawRangeMarker(var10, var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = new org.jfree.chart.LegendItemCollection();
    var11.setFixedLegendItems(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var19 = var16.get((-16646144));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    java.lang.Object var3 = null;
    var0.setObject((java.lang.Comparable)"hi!", var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)"");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.data.category.CategoryDatasetSelectionState var1 = var0.getSelectionState();
    var0.validateObject();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    var1.setDrawSharedDomainAxis(false);
    var1.setDomainCrosshairRowKey((java.lang.Comparable)(short)0);
    org.jfree.chart.plot.CategoryMarker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addDomainMarker(1, var19, var20, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    java.lang.Boolean var7 = var2.getSeriesItemLabelsVisible(0);
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.lang.Object var10 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getLabelAngle();
//     var1.setTickMarksVisible(true);
//     double var5 = var1.getFixedDimension();
//     double var6 = var1.getFixedDimension();
//     java.awt.Paint var8 = var1.getTickLabelPaint((java.lang.Comparable)100.05d);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.category.AbstractCategoryDataset var12 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var14 = var12.hasListener((java.util.EventListener)var13);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.RenderingSource var18 = null;
//     var13.select(0.05d, (-1.0d), var17, var18);
//     boolean var20 = var13.isRangeCrosshairVisible();
//     java.lang.Comparable var21 = null;
//     var13.setDomainCrosshairColumnKey(var21);
//     org.jfree.chart.axis.AxisSpace var23 = null;
//     var13.setFixedRangeAxisSpace(var23, false);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     int var27 = var13.indexOf(var26);
//     org.jfree.chart.util.RectangleEdge var28 = var13.getRangeAxisEdge();
//     java.util.List var29 = var1.refreshTicks(var9, var10, var11, var28);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     int var7 = var2.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
//     java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
//     var10.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var10.getPositiveItemLabelPosition(1, 0, false);
//     var2.setBaseNegativeItemLabelPosition(var24);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = var2.getLegendItemToolTipGenerator();
//     boolean var27 = var2.getBaseSeriesVisible();
//     boolean var28 = var2.getAutoPopulateSeriesStroke();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var32 = null;
//     org.jfree.chart.util.Layer var33 = null;
//     boolean var34 = var30.removeDomainMarker(1, var32, var33);
//     java.awt.Font var35 = var30.getNoDataMessageFont();
//     org.jfree.chart.util.PaintList var36 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var40 = var39.getLabelAngle();
//     boolean var41 = var36.equals((java.lang.Object)var39);
//     java.awt.Font var43 = var39.getTickLabelFont((java.lang.Comparable)(byte)0);
//     java.awt.Paint var44 = var39.getTickMarkPaint();
//     org.jfree.chart.plot.CategoryMarker var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     var2.drawDomainMarker(var29, var30, var39, var45, var46);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Stroke var11 = var10.getLineStroke();
    var10.setSeriesIndex((-1));
    var10.setSeriesKey((java.lang.Comparable)10L);
    java.lang.Object var16 = var10.clone();
    org.jfree.chart.util.GradientPaintTransformer var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setFillPaintTransformer(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     org.jfree.chart.util.Layer var4 = null;
//     java.util.Collection var5 = var0.getRangeMarkers((-1), var4);
//     java.awt.Paint var6 = var0.getRangeGridlinePaint();
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     java.awt.Paint var8 = null;
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
//     java.awt.Paint var10 = null;
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
//     java.awt.Stroke var12 = null;
//     java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
//     java.awt.Stroke var14 = null;
//     java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
//     java.awt.Shape var16 = null;
//     java.awt.Shape[] var17 = new java.awt.Shape[] { var16};
//     org.jfree.chart.plot.DefaultDrawingSupplier var18 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var11, var13, var15, var17);
//     java.awt.Paint var19 = null;
//     java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
//     java.awt.Paint var21 = null;
//     java.awt.Paint[] var22 = new java.awt.Paint[] { var21};
//     java.awt.Stroke var23 = null;
//     java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Shape var27 = null;
//     java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
//     org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var22, var24, var26, var28);
//     java.awt.Paint var30 = null;
//     java.awt.Paint[] var31 = new java.awt.Paint[] { var30};
//     java.awt.Paint var32 = null;
//     java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Stroke var36 = null;
//     java.awt.Stroke[] var37 = new java.awt.Stroke[] { var36};
//     java.awt.Shape var38 = null;
//     java.awt.Shape[] var39 = new java.awt.Shape[] { var38};
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var31, var33, var35, var37, var39);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var45 = null;
//     var43.setSeriesFillPaint(10, var45);
//     int var47 = var43.getPassCount();
//     java.awt.Font var49 = var43.lookupLegendTextFont(0);
//     java.awt.Shape var51 = var43.lookupSeriesShape(10);
//     org.jfree.chart.entity.ChartEntity var54 = new org.jfree.chart.entity.ChartEntity(var51, "PlotEntity: tooltip = hi!", "");
//     java.awt.Shape[] var55 = new java.awt.Shape[] { var51};
//     org.jfree.chart.plot.DefaultDrawingSupplier var56 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var9, var26, var35, var55);
//     
//     // Checks the contract:  equals-hashcode on var18 and var29
//     assertTrue("Contract failed: equals-hashcode on var18 and var29", var18.equals(var29) ? var18.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var40
//     assertTrue("Contract failed: equals-hashcode on var18 and var40", var18.equals(var40) ? var18.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var18
//     assertTrue("Contract failed: equals-hashcode on var29 and var18", var29.equals(var18) ? var29.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var40
//     assertTrue("Contract failed: equals-hashcode on var29 and var40", var29.equals(var40) ? var29.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var18
//     assertTrue("Contract failed: equals-hashcode on var40 and var18", var40.equals(var18) ? var40.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var29
//     assertTrue("Contract failed: equals-hashcode on var40 and var29", var40.equals(var29) ? var40.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
//     java.awt.Paint var12 = var2.getItemOutlinePaint(10, 0, false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var2.drawOutline(var13, var14, var15);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.labels.ItemLabelPosition var10 = var3.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var11 = var10.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var12 = new org.jfree.chart.labels.ItemLabelPosition(var0, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var8 = null;
    var6.setSeriesFillPaint(10, var8);
    int var10 = var6.getPassCount();
    java.awt.Font var12 = var6.lookupLegendTextFont(0);
    java.awt.Shape var14 = var6.lookupSeriesShape(10);
    org.jfree.chart.entity.ChartEntity var17 = new org.jfree.chart.entity.ChartEntity(var14, "PlotEntity: tooltip = hi!", "");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var22 = null;
    var20.setSeriesFillPaint(10, var22);
    int var24 = var20.getPassCount();
    int var25 = var20.getPassCount();
    var20.setDataBoundsIncludesVisibleSeriesOnly(true);
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var30.setLowerMargin(10.0d);
    double var33 = var30.getUpperMargin();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var35 = var34.getRangeCrosshairPaint();
    float var36 = var34.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var37 = var34.getFixedRangeAxisSpace();
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var39 = null;
    var38.setFixedRangeAxisSpace(var39);
    org.jfree.chart.util.PaintList var41 = new org.jfree.chart.util.PaintList();
    java.lang.Object var42 = var41.clone();
    org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var45 = var44.getLabelAngle();
    boolean var46 = var41.equals((java.lang.Object)var44);
    java.awt.geom.Rectangle2D var49 = null;
    org.jfree.chart.util.RectangleEdge var50 = null;
    double var51 = var44.getCategoryEnd((-1), 0, var49, var50);
    var38.setDomainAxis(var44);
    var38.setDrawSharedDomainAxis(true);
    java.awt.Paint var55 = var38.getRangeZeroBaselinePaint();
    var34.setRangeCrosshairPaint(var55);
    var30.setAxisLinePaint(var55);
    var20.setLegendTextPaint(4, var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem(var0, "DatasetRenderingOrder.REVERSE", "", "org.jfree.chart.event.ChartChangeEvent[source=1.0]", var14, var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
//     org.jfree.chart.util.GradientPaintTransformType var2 = var0.getType();
//     java.awt.GradientPaint var3 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = var6.getSeriesURLGenerator(1);
//     java.awt.Shape var12 = var6.getItemShape(0, (-1), false);
//     java.awt.Shape var14 = null;
//     var6.setLegendShape(0, var14);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var6.setSeriesURLGenerator(100, var17);
//     java.awt.Shape var20 = var6.lookupLegendShape(10);
//     java.awt.GradientPaint var21 = var0.transform(var3, var20);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.Marker var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var2.drawRangeMarker(var10, var11, var12, var13, var14);
    var2.setSeriesCreateEntities(100, (java.lang.Boolean)false);
    java.awt.Shape var20 = null;
    var2.setSeriesShape(1, var20, true);
    java.lang.Boolean var24 = var2.getSeriesVisibleInLegend(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    int var7 = var2.getPassCount();
    var2.setDataBoundsIncludesVisibleSeriesOnly(true);
    int var10 = var2.getPassCount();
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
    var2.setBaseItemLabelGenerator(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var8 = var7.getLabelAngle();
//     var7.setTickMarksVisible(true);
//     double var11 = var7.getFixedDimension();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     java.awt.Stroke var13 = var7.getAxisLineStroke();
//     var7.setVisible(true);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var16.setFixedRangeAxisSpace(var17);
//     boolean var19 = var16.isRangeGridlinesVisible();
//     var16.setRangeCrosshairValue(0.0d, true);
//     boolean var23 = var16.isRangeMinorGridlinesVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var28 = var26.getSeriesURLGenerator(1);
//     java.awt.Shape var32 = var26.getItemShape(0, (-1), false);
//     var26.setAutoPopulateSeriesOutlineStroke(true);
//     java.awt.Stroke var36 = var26.lookupSeriesOutlineStroke((-1));
//     var16.setDomainGridlineStroke(var36);
//     var7.setAxisLineStroke(var36);
//     var2.setBaseOutlineStroke(var36, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setLabelURL("");
    java.lang.String var4 = var1.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + ""+ "'", var4.equals(""));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    boolean var8 = var1.isRangeCrosshairVisible();
    java.lang.Comparable var9 = null;
    var1.setDomainCrosshairColumnKey(var9);
    org.jfree.chart.axis.AxisSpace var11 = null;
    var1.setFixedRangeAxisSpace(var11, false);
    org.jfree.data.category.CategoryDataset var14 = null;
    int var15 = var1.indexOf(var14);
    org.jfree.chart.util.RectangleEdge var16 = var1.getRangeAxisEdge();
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var1.zoomDomainAxes((-1.0d), 0.05d, var19, var20);
    org.jfree.chart.plot.Marker var22 = null;
    org.jfree.chart.util.Layer var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var24 = var1.removeRangeMarker(var22, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(1.0d, 0.05d, 0.05d, 100.0d);
    double var5 = var4.getTop();
    org.jfree.chart.util.UnitType var6 = var4.getUnitType();
    double var7 = var4.getTop();
    double var9 = var4.calculateBottomOutset(1.0d);
    java.awt.geom.Rectangle2D var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var11 = var4.createOutsetRectangle(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.data.SelectableValue var1 = new org.jfree.data.SelectableValue((java.lang.Number)(short)100);
    boolean var2 = var1.isSelected();
    var1.setSelected(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var3 = var0.getItemPaint(1, 100);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var8 = var7.getLabelAngle();
//     var7.setMinorTickMarkInsideLength(10.0f);
//     double var11 = var7.getLowerMargin();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = var15.getSeriesURLGenerator(1);
//     java.awt.Shape var21 = var15.getItemShape(0, (-1), false);
//     var15.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var25 = var15.getSeriesShapesFilled(1);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var5, var7, var12, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     java.awt.Font var27 = var26.getNoDataMessageFont();
//     var0.setSeriesLabelFont(128, var27);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.5f, 0.5f, 0.5f);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var6.getSeriesURLGenerator(1);
    int var9 = var6.getPassCount();
    var6.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = null;
    var6.setBaseItemLabelGenerator(var13, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var21 = var19.getLegendTextFont(10);
    java.awt.Paint var25 = var19.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", var25);
    java.awt.Stroke var27 = var26.getLineStroke();
    var26.setSeriesIndex((-1));
    var26.setToolTipText("");
    java.lang.Comparable var32 = var26.getSeriesKey();
    java.awt.Shape var33 = var26.getShape();
    java.awt.Color var37 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var38 = null;
    java.awt.Rectangle var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    java.awt.geom.AffineTransform var41 = null;
    java.awt.RenderingHints var42 = null;
    java.awt.PaintContext var43 = var37.createContext(var38, var39, var40, var41, var42);
    java.awt.color.ColorSpace var44 = var37.getColorSpace();
    java.awt.Color var45 = var37.brighter();
    var26.setLinePaint((java.awt.Paint)var37);
    var6.setBaseItemLabelPaint((java.awt.Paint)var37, false);
    float[] var52 = new float[] { 100.0f, 0.0f, 10.0f};
    float[] var53 = var37.getColorComponents(var52);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var54 = var3.getComponents(var53);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    java.lang.Boolean var7 = var2.getSeriesItemLabelsVisible(0);
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    boolean var10 = var2.getBaseCreateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var12 = var11.getRangeCrosshairPaint();
    var2.setBasePaint(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesCreateEntities((-1), (java.lang.Boolean)false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var3 = var2.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var2.zoomDomainAxes(100.0d, var5, var6, true);
    var0.addObject((java.lang.Comparable)0.2d, (java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue((-1), (java.lang.Comparable)1, (java.lang.Object)"RectangleInsets[t=1.0,l=0.05,b=0.05,r=100.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var0.axisChanged(var7);
    org.jfree.data.KeyedObjects2D var10 = new org.jfree.data.KeyedObjects2D();
    int var11 = var10.getColumnCount();
    int var12 = var10.getColumnCount();
    var10.clear();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var16 = var15.getLabelAngle();
    var15.setMinorTickMarkInsideLength(10.0f);
    boolean var19 = var15.isMinorTickMarksVisible();
    float var20 = var15.getMinorTickMarkInsideLength();
    var10.addObject((java.lang.Object)var15, (java.lang.Comparable)(byte)10, (java.lang.Comparable)0L);
    var0.setDomainAxis(100, var15);
    var0.setRangeCrosshairValue(0.2d, true);
    org.jfree.chart.axis.AxisSpace var28 = var0.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Paint var6 = null;
    var2.setSeriesPaint(0, var6, true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemToolTipGenerator();
    var2.setBaseSeriesVisibleInLegend(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesVisible((-16646144), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     java.lang.Comparable var3 = var0.getDomainCrosshairColumnKey();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var7.getSeriesURLGenerator(1);
//     java.awt.Shape var13 = var7.getItemShape(0, (-1), false);
//     java.awt.Paint var17 = var7.getItemOutlinePaint(10, 0, false);
//     var0.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer)var7, false);
//     org.jfree.data.category.AbstractCategoryDataset var20 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var22 = var20.hasListener((java.util.EventListener)var21);
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.RenderingSource var26 = null;
//     var21.select(0.05d, (-1.0d), var25, var26);
//     org.jfree.chart.plot.Plot var28 = var21.getRootPlot();
//     org.jfree.chart.plot.DatasetRenderingOrder var29 = var21.getDatasetRenderingOrder();
//     java.lang.Object var30 = var21.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var36 = var34.getLegendTextFont(10);
//     java.awt.Paint var40 = var34.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", var40);
//     java.awt.Stroke var42 = var41.getLineStroke();
//     var41.setSeriesIndex((-1));
//     var41.setToolTipText("");
//     java.lang.Comparable var47 = var41.getSeriesKey();
//     java.awt.Shape var48 = var41.getShape();
//     java.awt.Paint var49 = var41.getOutlinePaint();
//     var21.setRangeZeroBaselinePaint(var49);
//     var7.setBasePaint(var49);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.Marker var4 = null;
    boolean var5 = var0.removeDomainMarker(var4);
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var11 = null;
    var9.setSeriesFillPaint(10, var11);
    int var13 = var9.getPassCount();
    int var14 = var9.getPassCount();
    boolean var15 = var6.equals((java.lang.Object)var14);
    java.lang.String var16 = var6.toString();
    java.lang.String var17 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var16.equals("DatasetRenderingOrder.REVERSE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var17.equals("DatasetRenderingOrder.REVERSE"));

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var4 = var2.getLegendTextFont(10);
    java.awt.Paint var8 = var2.getItemPaint(10, 100, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var13 = null;
    var11.setSeriesFillPaint(10, var13);
    int var15 = var11.getPassCount();
    int var16 = var11.getPassCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var21 = var19.getSeriesURLGenerator(1);
    java.awt.Shape var25 = var19.getItemShape(0, (-1), false);
    var19.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var29 = var19.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var33 = var19.getPositiveItemLabelPosition(1, 0, false);
    var11.setBaseNegativeItemLabelPosition(var33);
    var2.setBasePositiveItemLabelPosition(var33);
    boolean var37 = var33.equals((java.lang.Object)'a');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var42 = var40.getLegendTextFont(10);
    java.awt.Stroke var46 = var40.getItemStroke(0, 1, true);
    java.awt.Paint var50 = var40.getItemLabelPaint(2, 0, false);
    boolean var51 = var33.equals((java.lang.Object)var40);
    org.jfree.chart.text.TextAnchor var52 = var33.getTextAnchor();
    org.jfree.data.category.AbstractCategoryDataset var53 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    boolean var55 = var53.hasListener((java.util.EventListener)var54);
    org.jfree.data.category.CategoryDatasetSelectionState var56 = var53.getSelectionState();
    org.jfree.data.category.AbstractCategoryDataset var57 = new org.jfree.data.category.AbstractCategoryDataset();
    java.lang.Object var58 = var57.clone();
    org.jfree.data.general.DatasetGroup var59 = new org.jfree.data.general.DatasetGroup();
    var57.setGroup(var59);
    var53.setGroup(var59);
    boolean var62 = var33.equals((java.lang.Object)var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getFixedDimension();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator(1);
    int var6 = var3.getPassCount();
    var3.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = null;
    var3.setBaseItemLabelGenerator(var10, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var18 = var16.getLegendTextFont(10);
    java.awt.Paint var22 = var16.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var22);
    java.awt.Stroke var24 = var23.getLineStroke();
    var23.setSeriesIndex((-1));
    var23.setToolTipText("");
    java.lang.Comparable var29 = var23.getSeriesKey();
    java.awt.Shape var30 = var23.getShape();
    java.awt.Color var34 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var35 = null;
    java.awt.Rectangle var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    java.awt.geom.AffineTransform var38 = null;
    java.awt.RenderingHints var39 = null;
    java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
    java.awt.color.ColorSpace var41 = var34.getColorSpace();
    java.awt.Color var42 = var34.brighter();
    var23.setLinePaint((java.awt.Paint)var34);
    var3.setBaseItemLabelPaint((java.awt.Paint)var34, false);
    float[] var49 = new float[] { 100.0f, 0.0f, 10.0f};
    float[] var50 = var34.getColorComponents(var49);
    int var51 = var34.getTransparency();
    var0.setDefaultLabelPaint((java.awt.Paint)var34);
    java.awt.Paint var53 = var0.getDefaultPaint();
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var56 = null;
    var55.setFixedRangeAxisSpace(var56);
    org.jfree.chart.util.PaintList var58 = new org.jfree.chart.util.PaintList();
    java.lang.Object var59 = var58.clone();
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var62 = var61.getLabelAngle();
    boolean var63 = var58.equals((java.lang.Object)var61);
    java.awt.geom.Rectangle2D var66 = null;
    org.jfree.chart.util.RectangleEdge var67 = null;
    double var68 = var61.getCategoryEnd((-1), 0, var66, var67);
    var55.setDomainAxis(var61);
    var55.setDrawSharedDomainAxis(true);
    java.awt.Paint var72 = var55.getRangeZeroBaselinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var72);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var1 = var0.getDefaultOutlinePaint();
//     java.awt.Font var4 = var0.getItemLabelFont(4, 3);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    java.awt.Stroke var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDomainCrosshairStroke(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.Marker var4 = null;
//     boolean var5 = var0.removeDomainMarker(var4);
//     org.jfree.chart.plot.Marker var6 = null;
//     org.jfree.chart.util.Layer var7 = null;
//     var0.addRangeMarker(var6, var7);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getLabelAngle();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
//     double var11 = var3.getFixedDimension();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var17 = var15.getLegendTextFont(10);
//     java.awt.Paint var21 = var15.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("", var21);
//     java.awt.Stroke var23 = var22.getLineStroke();
//     var3.setTickMarkStroke(var23);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var30 = null;
//     var29.setFixedRangeAxisSpace(var30);
//     boolean var32 = var29.isRangeGridlinesVisible();
//     var29.setRangeCrosshairValue(0.0d, true);
//     boolean var36 = var29.isRangeMinorGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     java.awt.geom.Point2D var39 = null;
//     var29.zoomDomainAxes(100.0d, var38, var39, false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var43 = null;
//     java.awt.Paint[] var44 = new java.awt.Paint[] { var43};
//     java.awt.Paint var45 = null;
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var45};
//     java.awt.Stroke var47 = null;
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     java.awt.Stroke var49 = null;
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
//     java.awt.Shape var51 = null;
//     java.awt.Shape[] var52 = new java.awt.Shape[] { var51};
//     org.jfree.chart.plot.DefaultDrawingSupplier var53 = new org.jfree.chart.plot.DefaultDrawingSupplier(var44, var46, var48, var50, var52);
//     boolean var54 = var42.equals((java.lang.Object)var52);
//     java.awt.Stroke var55 = var42.getNextOutlineStroke();
//     var29.setOutlineStroke(var55);
//     org.jfree.chart.axis.ValueAxis var57 = var29.getRangeAxis();
//     org.jfree.chart.util.RectangleEdge var59 = var29.getRangeAxisEdge(0);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     org.jfree.chart.axis.AxisState var61 = var3.draw(var25, (-1.0d), var27, var28, var59, var60);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.data.SelectableValue var2 = new org.jfree.data.SelectableValue((java.lang.Number)(byte)10, false);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    java.awt.Paint var11 = var2.lookupLegendTextPaint((-1));
    int var12 = var2.getPassCount();
    java.awt.Color var16 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    java.awt.geom.AffineTransform var20 = null;
    java.awt.RenderingHints var21 = null;
    java.awt.PaintContext var22 = var16.createContext(var17, var18, var19, var20, var21);
    var2.setBaseFillPaint((java.awt.Paint)var16);
    int var24 = var16.getTransparency();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.data.SelectableValue var1 = new org.jfree.data.SelectableValue((java.lang.Number)0.0f);
    var1.setSelected(true);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    java.lang.Boolean var7 = var2.getSeriesItemLabelsVisible(0);
    java.awt.Paint var9 = var2.getSeriesItemLabelPaint(2);
    java.awt.Shape var11 = var2.lookupLegendShape(3);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var15.setFixedRangeAxisSpace(var16);
    org.jfree.chart.util.PaintList var18 = new org.jfree.chart.util.PaintList();
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var22 = var21.getLabelAngle();
    boolean var23 = var18.equals((java.lang.Object)var21);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var21.getCategoryEnd((-1), 0, var26, var27);
    var15.setDomainAxis(var21);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.data.category.DefaultCategoryDataset var31 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var32 = null;
    var31.setValue(var32, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var43 = var41.getSeriesURLGenerator(1);
    var41.setUseOutlinePaint(false);
    boolean var46 = var41.getAutoPopulateSeriesOutlinePaint();
    java.awt.Graphics2D var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var50 = var49.getRangeCrosshairPaint();
    var49.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var52 = null;
    org.jfree.chart.plot.PlotRenderingInfo var53 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var54 = var41.initialise(var47, var48, var49, var52, var53);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var55 = var2.createHotSpotShape(var12, var13, var14, var21, var30, (org.jfree.data.category.CategoryDataset)var31, 1, 15, true, var54);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    org.jfree.chart.util.Layer var4 = null;
    java.util.Collection var5 = var0.getRangeMarkers((-1), var4);
    boolean var6 = var0.isRangeGridlinesVisible();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets(0.05d, 10.0d, 0.0d, 0.05d);
    double var13 = var11.calculateTopOutset(100.0d);
    double var15 = var11.calculateBottomInset(0.0d);
    var0.setInsets(var11, false);
    double var19 = var11.calculateLeftOutset(1.0d);
    double var21 = var11.calculateRightOutset(100.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.05d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)(short)10);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var6.getSeriesURLGenerator(1);
    java.awt.Shape var12 = var6.getItemShape(0, (-1), false);
    double var13 = var6.getItemMargin();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = null;
    var6.setLegendItemURLGenerator(var14);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var20 = null;
    var18.setSeriesFillPaint(10, var20);
    int var22 = var18.getPassCount();
    java.awt.Font var24 = var18.lookupLegendTextFont(0);
    java.awt.Shape var26 = var18.lookupSeriesShape(10);
    var6.setBaseLegendShape(var26);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var29 = null;
    var28.setFixedRangeAxisSpace(var29);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var28.getRangeMarkers((-1), var32);
    java.awt.Paint var34 = var28.getRangeGridlinePaint();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = hi!", "GradientPaintTransformType.VERTICAL", "", "GradientPaintTransformType.VERTICAL", var26, var34);
    org.jfree.data.category.DefaultCategoryDataset var38 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var39 = null;
    var38.setValue(var39, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var38.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    java.lang.Comparable var48 = var38.getColumnKey(0);
    var38.removeRow(0);
    org.jfree.chart.entity.CategoryItemEntity var53 = new org.jfree.chart.entity.CategoryItemEntity(var26, "hi!", "RectangleInsets[t=1.0,l=0.05,b=0.05,r=100.0]", (org.jfree.data.category.CategoryDataset)var38, (java.lang.Comparable)"DatasetRenderingOrder.REVERSE", (java.lang.Comparable)(short)1);
    org.jfree.data.category.CategoryDataset var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var53.setDataset(var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + 100.05d+ "'", var48.equals(100.05d));

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var4 = var2.getLegendTextFont(10);
    java.awt.Paint var8 = var2.getItemPaint(10, 100, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setItemMargin((-100.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var3 = var0.getItemLabelPaint((-1), (-1));
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     java.awt.Paint var6 = null;
//     var2.setSeriesPaint(0, var6, true);
//     java.awt.Paint var12 = var2.getItemOutlinePaint(100, 3, true);
//     java.lang.Object var13 = var2.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesFillPaint(10, var19);
//     java.awt.Paint var22 = null;
//     var17.setSeriesOutlinePaint(3, var22);
//     java.awt.Stroke var27 = var17.getItemStroke(100, 1, true);
//     var2.setSeriesStroke(2, var27);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var17 and var2.", var17.equals(var2) == var2.equals(var17));
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     java.awt.Font var8 = var2.lookupLegendTextFont(0);
//     java.awt.Font var9 = null;
//     var2.setBaseLegendTextFont(var9);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var14 = var13.getLabelAngle();
//     var13.setMinorTickMarkInsideLength(10.0f);
//     boolean var17 = var13.isMinorTickMarksVisible();
//     float var18 = var13.getMinorTickMarkInsideLength();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var20 = null;
//     var19.setFixedRangeAxisSpace(var20);
//     org.jfree.chart.util.PaintList var22 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var23 = var22.clone();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var26 = var25.getLabelAngle();
//     boolean var27 = var22.equals((java.lang.Object)var25);
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var25.getCategoryEnd((-1), 0, var30, var31);
//     var19.setDomainAxis(var25);
//     var19.setDrawSharedDomainAxis(true);
//     java.awt.Paint var36 = var19.getRangeZeroBaselinePaint();
//     var13.setTickLabelPaint(var36);
//     var2.setSeriesFillPaint(128, var36);
//     org.jfree.chart.labels.ItemLabelPosition var42 = var2.getPositiveItemLabelPosition(10, 10, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var48 = var46.getLegendTextFont(10);
//     java.awt.Paint var52 = var46.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("", var52);
//     java.awt.Stroke var54 = var53.getLineStroke();
//     var53.setSeriesIndex((-1));
//     var53.setToolTipText("");
//     java.awt.Paint var59 = var53.getFillPaint();
//     var2.setBasePaint(var59);
//     
//     // Checks the contract:  equals-hashcode on var46 and var2
//     assertTrue("Contract failed: equals-hashcode on var46 and var2", var46.equals(var2) ? var46.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var46 and var2.", var46.equals(var2) == var2.equals(var46));
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    var0.setNotify(true);
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.util.RectangleEdge var12 = var0.getRangeAxisEdge(100);
    java.awt.Stroke var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeGridlineStroke(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var4 = var2.getLegendTextFont(10);
//     java.awt.Paint var8 = var2.getItemPaint(10, 100, true);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var10 = var9.getTextAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var15 = var13.getSeriesURLGenerator(1);
//     java.awt.Paint var17 = null;
//     var13.setSeriesPaint(0, var17, true);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = var13.getLegendItemToolTipGenerator();
//     boolean var21 = var10.equals((java.lang.Object)var13);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    int var3 = var0.getColumnCount();
    int var5 = var0.getRowIndex((java.lang.Comparable)0.05d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)"");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.Marker var4 = null;
    boolean var5 = var0.removeDomainMarker(var4);
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = var0.getRenderer();
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var0.removeChangeListener(var8);
    var0.setDomainCrosshairRowKey((java.lang.Comparable)'#', false);
    double var13 = var0.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    java.lang.Object var3 = var1.get(0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var9 = null;
    var7.setSeriesFillPaint(10, var9);
    int var11 = var7.getPassCount();
    boolean var13 = var7.isSeriesVisible(1);
    boolean var14 = var7.getUseFillPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var19 = null;
    var17.setSeriesFillPaint(10, var19);
    int var21 = var17.getPassCount();
    java.awt.Paint var25 = var17.getItemPaint(0, 100, true);
    var7.setBaseLegendTextPaint(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set((-1), (java.lang.Object)var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    var3.setTickMarksVisible(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var11 = var9.getSeriesURLGenerator(1);
    java.awt.Paint var13 = null;
    var9.setSeriesPaint(0, var13, true);
    org.jfree.data.category.AbstractCategoryDataset var16 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    boolean var18 = var16.hasListener((java.util.EventListener)var17);
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.RenderingSource var22 = null;
    var17.select(0.05d, (-1.0d), var21, var22);
    boolean var24 = var17.isRangeCrosshairVisible();
    java.awt.Font var25 = var17.getNoDataMessageFont();
    var9.setBaseItemLabelFont(var25, false);
    var3.setTickLabelFont(var25);
    var0.setLegendTextFont(2, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var1 = null;
//     java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
//     java.awt.Paint var3 = null;
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape var9 = null;
//     java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var4, var6, var8, var10);
//     boolean var12 = var0.equals((java.lang.Object)var10);
//     java.awt.Stroke var13 = var0.getNextOutlineStroke();
//     java.lang.Object var14 = var0.clone();
//     java.lang.Object var15 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var14 and var15
//     assertTrue("Contract failed: equals-hashcode on var14 and var15", var14.equals(var15) ? var14.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var14
//     assertTrue("Contract failed: equals-hashcode on var15 and var14", var15.equals(var14) ? var15.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getLabelAngle();
//     var1.setTickMarksVisible(true);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.AxisState var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.data.category.AbstractCategoryDataset var8 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var10 = var8.hasListener((java.util.EventListener)var9);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.RenderingSource var14 = null;
//     var9.select(0.05d, (-1.0d), var13, var14);
//     boolean var16 = var9.isRangeCrosshairVisible();
//     java.lang.Comparable var17 = null;
//     var9.setDomainCrosshairColumnKey(var17);
//     org.jfree.chart.axis.AxisSpace var19 = null;
//     var9.setFixedRangeAxisSpace(var19, false);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     int var23 = var9.indexOf(var22);
//     org.jfree.chart.util.RectangleEdge var24 = var9.getRangeAxisEdge();
//     java.util.List var25 = var1.refreshTicks(var5, var6, var7, var24);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    org.jfree.chart.plot.DefaultDrawingSupplier var8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var9 = null;
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    java.awt.Paint var11 = null;
    java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var12, var14, var16, var18);
    boolean var20 = var8.equals((java.lang.Object)var18);
    var1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var8, true);
    java.awt.Stroke var23 = var8.getNextStroke();
    java.awt.Paint var24 = var8.getNextFillPaint();
    org.jfree.data.KeyedObjects2D var25 = new org.jfree.data.KeyedObjects2D();
    java.util.List var26 = var25.getRowKeys();
    boolean var27 = var8.equals((java.lang.Object)var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.removeRow(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var4 = var2.getLegendTextFont(10);
//     java.awt.Paint var8 = var2.getItemPaint(10, 100, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var13 = null;
//     var11.setSeriesFillPaint(10, var13);
//     int var15 = var11.getPassCount();
//     int var16 = var11.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var21 = var19.getSeriesURLGenerator(1);
//     java.awt.Shape var25 = var19.getItemShape(0, (-1), false);
//     var19.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var29 = var19.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var33 = var19.getPositiveItemLabelPosition(1, 0, false);
//     var11.setBaseNegativeItemLabelPosition(var33);
//     var2.setBasePositiveItemLabelPosition(var33);
//     boolean var36 = var2.getDataBoundsIncludesVisibleSeriesOnly();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var41 = null;
//     var39.setSeriesFillPaint(10, var41);
//     int var43 = var39.getPassCount();
//     int var44 = var39.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var49 = var47.getSeriesURLGenerator(1);
//     java.awt.Shape var53 = var47.getItemShape(0, (-1), false);
//     var47.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var57 = var47.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var61 = var47.getPositiveItemLabelPosition(1, 0, false);
//     var39.setBaseNegativeItemLabelPosition(var61);
//     var2.setBasePositiveItemLabelPosition(var61);
//     
//     // Checks the contract:  equals-hashcode on var33 and var61
//     assertTrue("Contract failed: equals-hashcode on var33 and var61", var33.equals(var61) ? var33.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var33
//     assertTrue("Contract failed: equals-hashcode on var61 and var33", var61.equals(var33) ? var61.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    boolean var3 = var1.isVisible();
    double var4 = var1.getFixedDimension();
    java.lang.String var5 = var1.getLabel();
    java.lang.String var6 = var1.getLabelURL();
    var1.setMaximumCategoryLabelWidthRatio(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var0.setRangeAxes(var8);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getLabelAngle();
    var11.setTickMarksVisible(true);
    var0.setDomainAxis(var11);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var20 = var18.getSeriesURLGenerator(1);
    int var21 = var18.getPassCount();
    java.lang.Boolean var23 = var18.getSeriesItemLabelsVisible(0);
    var18.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var18};
    var0.setRenderers(var26);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    java.awt.geom.Point2D var31 = null;
    var0.zoomRangeAxes(1.0d, (-100.0d), var30, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    var0.clear();
    int var5 = var0.getColumnIndex((java.lang.Comparable)(short)10);
    java.lang.Comparable var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    var1.setTickMarksVisible(true);
    double var5 = var1.getFixedDimension();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var7 = null;
    var6.setFixedRangeAxisSpace(var7);
    boolean var9 = var6.isRangeGridlinesVisible();
    var6.setRangeCrosshairValue(0.0d, true);
    boolean var13 = var6.isRangeMinorGridlinesVisible();
    boolean var14 = var1.hasListener((java.util.EventListener)var6);
    org.jfree.chart.plot.Marker var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var16 = var6.removeRangeMarker(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator(1);
//     int var6 = var3.getPassCount();
//     var3.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = null;
//     var3.setBaseItemLabelGenerator(var10, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var18 = var16.getLegendTextFont(10);
//     java.awt.Paint var22 = var16.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var22);
//     java.awt.Stroke var24 = var23.getLineStroke();
//     var23.setSeriesIndex((-1));
//     var23.setToolTipText("");
//     java.lang.Comparable var29 = var23.getSeriesKey();
//     java.awt.Shape var30 = var23.getShape();
//     java.awt.Color var34 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var35 = null;
//     java.awt.Rectangle var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
//     java.awt.color.ColorSpace var41 = var34.getColorSpace();
//     java.awt.Color var42 = var34.brighter();
//     var23.setLinePaint((java.awt.Paint)var34);
//     var3.setBaseItemLabelPaint((java.awt.Paint)var34, false);
//     float[] var49 = new float[] { 100.0f, 0.0f, 10.0f};
//     float[] var50 = var34.getColorComponents(var49);
//     int var51 = var34.getTransparency();
//     var0.setDefaultLabelPaint((java.awt.Paint)var34);
//     java.awt.Font var55 = var0.getItemLabelFont(128, 100);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var1 = null;
    java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
    java.awt.Paint var3 = null;
    java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var4, var6, var8, var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.awt.Stroke var13 = var0.getNextOutlineStroke();
    java.lang.Object var14 = var0.clone();
    java.awt.Paint var15 = var0.getNextFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.util.ShadowGenerator var4 = var0.getShadowGenerator();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.setLabelURL("");
    boolean var9 = var6.isMinorTickMarksVisible();
    int var10 = var0.getDomainAxisIndex(var6);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var17 = null;
    var15.setSeriesFillPaint(10, var17);
    int var19 = var15.getPassCount();
    var15.setAutoPopulateSeriesShape(true);
    java.awt.Paint var22 = var15.getBaseItemLabelPaint();
    var15.setAutoPopulateSeriesFillPaint(false);
    var0.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var32 = var30.getSeriesURLGenerator(1);
    java.awt.Shape var36 = var30.getItemShape(0, (-1), false);
    var30.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var40 = var30.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var44 = var30.getPositiveItemLabelPosition(1, 0, false);
    double var45 = var44.getAngle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setSeriesPositiveItemLabelPosition((-16646144), var44, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     boolean var3 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.0d, true);
//     boolean var7 = var0.isRangeMinorGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     var0.zoomDomainAxes(100.0d, var9, var10, false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var14 = null;
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Stroke var18 = null;
//     java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Shape var22 = null;
//     java.awt.Shape[] var23 = new java.awt.Shape[] { var22};
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var15, var17, var19, var21, var23);
//     boolean var25 = var13.equals((java.lang.Object)var23);
//     java.awt.Stroke var26 = var13.getNextOutlineStroke();
//     var0.setOutlineStroke(var26);
//     org.jfree.chart.axis.ValueAxis var28 = var0.getRangeAxis();
//     org.jfree.chart.util.RectangleEdge var30 = var0.getRangeAxisEdge(0);
//     var0.setDomainCrosshairColumnKey((java.lang.Comparable)(-101.05d));
//     java.awt.Graphics2D var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     var0.drawBackground(var33, var34);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getLabelAngle();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var13 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var12.zoomDomainAxes(100.0d, var15, var16, true);
//     var12.setNotify(true);
//     var12.setRangeCrosshairVisible(false);
//     org.jfree.chart.util.RectangleEdge var24 = var12.getRangeAxisEdge(100);
//     double var25 = var3.getCategorySeriesMiddle(255, 255, (-16646144), 2, 100.05d, var11, var24);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    int var6 = var0.getRowIndex((java.lang.Comparable)2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var8 = var0.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    boolean var12 = var1.isDomainPannable();
    org.jfree.chart.plot.Marker var14 = null;
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var16 = var1.removeRangeMarker(0, var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     float var2 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedRangeAxisSpace(var3, false);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     org.jfree.chart.plot.PlotState var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var0.draw(var6, var7, var8, var9, var10);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var4 = var2.getLegendTextFont(10);
    java.awt.Paint var6 = var2.getSeriesPaint(128);
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var2.removeAnnotation(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     boolean var3 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.0d, true);
//     boolean var7 = var0.isRangeMinorGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     var0.zoomDomainAxes(100.0d, var9, var10, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = var15.getSeriesURLGenerator(1);
//     java.awt.Shape var21 = var15.getItemShape(0, (-1), false);
//     var15.setAutoPopulateSeriesOutlineStroke(true);
//     int var24 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     var15.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
//     double var29 = var15.getItemLabelAnchorOffset();
//     java.lang.Boolean var31 = var15.getSeriesCreateEntities((-1));
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var34 = null;
//     var33.setFixedRangeAxisSpace(var34);
//     org.jfree.chart.util.PaintList var36 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var40 = var39.getLabelAngle();
//     boolean var41 = var36.equals((java.lang.Object)var39);
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var39.getCategoryEnd((-1), 0, var44, var45);
//     var33.setDomainAxis(var39);
//     org.jfree.chart.plot.Plot var48 = var39.getPlot();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var54 = var52.getLegendTextFont(10);
//     java.awt.Paint var58 = var52.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("", var58);
//     java.awt.Stroke var60 = var59.getLineStroke();
//     var48.setOutlineStroke(var60);
//     var15.setSeriesStroke(2, var60);
//     
//     // Checks the contract:  equals-hashcode on var52 and var15
//     assertTrue("Contract failed: equals-hashcode on var52 and var15", var52.equals(var15) ? var52.hashCode() == var15.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var52 and var15.", var52.equals(var15) == var15.equals(var52));
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.Marker var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var2.drawRangeMarker(var10, var11, var12, var13, var14);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    var11.clearSelection();
    org.jfree.chart.event.AnnotationChangeEvent var18 = null;
    var11.annotationChanged(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d, true);
    int var7 = var0.getCrosshairDatasetIndex();
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var0.removeChangeListener(var8);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var13 = var12.getLabelAngle();
    var12.setTickMarksVisible(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var20 = var18.getSeriesURLGenerator(1);
    java.awt.Paint var22 = null;
    var18.setSeriesPaint(0, var22, true);
    org.jfree.data.category.AbstractCategoryDataset var25 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    boolean var27 = var25.hasListener((java.util.EventListener)var26);
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.RenderingSource var31 = null;
    var26.select(0.05d, (-1.0d), var30, var31);
    boolean var33 = var26.isRangeCrosshairVisible();
    java.awt.Font var34 = var26.getNoDataMessageFont();
    var18.setBaseItemLabelFont(var34, false);
    var12.setTickLabelFont(var34);
    boolean var38 = var12.isTickMarksVisible();
    var0.setDomainAxis(0, var12);
    org.jfree.chart.plot.CategoryMarker var40 = null;
    org.jfree.chart.util.Layer var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var40, var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var4 = var2.getLegendTextFont(10);
    java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
    java.awt.Paint var12 = var2.getItemLabelPaint(2, 0, false);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    var2.setBaseCreateEntities(true, false);
    java.awt.Paint var20 = var2.getSeriesItemLabelPaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1.0f);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=1.0]"+ "'", var2.equals("org.jfree.chart.event.ChartChangeEvent[source=1.0]"));

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var16 = var14.getLegendTextFont(10);
    java.awt.Paint var20 = var14.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", var20);
    var3.setLabelPaint(var20);
    org.jfree.chart.axis.CategoryLabelPositions var23 = var3.getCategoryLabelPositions();
    double var24 = var3.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.05d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    java.awt.Font var8 = var2.lookupLegendTextFont(0);
    java.awt.Font var9 = null;
    var2.setBaseLegendTextFont(var9);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var14 = var13.getLabelAngle();
    var13.setMinorTickMarkInsideLength(10.0f);
    boolean var17 = var13.isMinorTickMarksVisible();
    float var18 = var13.getMinorTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var20 = null;
    var19.setFixedRangeAxisSpace(var20);
    org.jfree.chart.util.PaintList var22 = new org.jfree.chart.util.PaintList();
    java.lang.Object var23 = var22.clone();
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var26 = var25.getLabelAngle();
    boolean var27 = var22.equals((java.lang.Object)var25);
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var25.getCategoryEnd((-1), 0, var30, var31);
    var19.setDomainAxis(var25);
    var19.setDrawSharedDomainAxis(true);
    java.awt.Paint var36 = var19.getRangeZeroBaselinePaint();
    var13.setTickLabelPaint(var36);
    var2.setSeriesFillPaint(128, var36);
    var2.removeAnnotations();
    var2.setDefaultEntityRadius(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     int var5 = var2.getPassCount();
//     var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var2.getBaseURLGenerator();
//     boolean var11 = var2.isSeriesItemLabelsVisible(0);
//     java.awt.Shape var15 = var2.getItemShape(0, (-1), true);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var17 = var16.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     java.awt.geom.Point2D var20 = null;
//     var16.zoomDomainAxes(100.0d, var19, var20, true);
//     org.jfree.chart.event.AxisChangeEvent var23 = null;
//     var16.axisChanged(var23);
//     org.jfree.chart.entity.PlotEntity var25 = new org.jfree.chart.entity.PlotEntity(var15, (org.jfree.chart.plot.Plot)var16);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var30 = var28.getSeriesURLGenerator(1);
//     java.awt.Shape var34 = var28.getItemShape(0, (-1), false);
//     java.awt.Paint var38 = var28.getItemOutlinePaint(10, 0, false);
//     boolean var39 = var28.getAutoPopulateSeriesOutlinePaint();
//     java.lang.Boolean var41 = var28.getSeriesVisibleInLegend(3);
//     java.awt.Paint var42 = var28.getBaseItemLabelPaint();
//     boolean var43 = var25.equals((java.lang.Object)var28);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var2.", var28.equals(var2) == var2.equals(var28));
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    int var6 = var0.getRowIndex((java.lang.Comparable)2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getLabelAngle();
//     var1.setTickMarksVisible(true);
//     double var5 = var1.getFixedDimension();
//     org.jfree.data.category.DefaultCategoryDataset var8 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var9 = null;
//     var8.setValue(var9, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
//     var8.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var21 = null;
//     var19.setSeriesFillPaint(10, var21);
//     int var23 = var19.getPassCount();
//     java.awt.Font var25 = var19.lookupLegendTextFont(0);
//     java.awt.Font var26 = null;
//     var19.setBaseLegendTextFont(var26);
//     java.awt.Font var29 = var19.getLegendTextFont(10);
//     org.jfree.chart.LegendItem var32 = var19.getLegendItem(0, 10);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.data.category.AbstractCategoryDataset var34 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var36 = var34.hasListener((java.util.EventListener)var35);
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.RenderingSource var40 = null;
//     var35.select(0.05d, (-1.0d), var39, var40);
//     boolean var42 = var35.isRangeCrosshairVisible();
//     java.lang.Comparable var43 = null;
//     var35.setDomainCrosshairColumnKey(var43);
//     org.jfree.chart.axis.AxisSpace var45 = null;
//     var35.setFixedRangeAxisSpace(var45, false);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.plot.Marker var49 = null;
//     java.awt.geom.Rectangle2D var50 = null;
//     var19.drawRangeMarker(var33, var35, var48, var49, var50);
//     var19.setBaseCreateEntities(true, true);
//     boolean var55 = var8.equals((java.lang.Object)true);
//     org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var58 = var57.getLabelAngle();
//     boolean var59 = var57.isVisible();
//     double var60 = var57.getFixedDimension();
//     java.lang.String var61 = var57.getLabel();
//     java.lang.String var62 = var57.getLabelURL();
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var64 = null;
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, var57, var63, var64);
//     java.awt.geom.Rectangle2D var67 = null;
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var69 = var68.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     java.awt.geom.Point2D var72 = null;
//     var68.zoomDomainAxes(100.0d, var71, var72, true);
//     var68.setNotify(true);
//     var68.setRangeCrosshairVisible(false);
//     org.jfree.chart.util.RectangleEdge var80 = var68.getRangeAxisEdge(100);
//     double var81 = var1.getCategorySeriesMiddle((java.lang.Comparable)2.0d, (java.lang.Comparable)false, (org.jfree.data.category.CategoryDataset)var8, 100.0d, var67, var80);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var2.setFixedRangeAxisSpace(var3);
//     var2.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.util.SortOrder var7 = var2.getColumnRenderingOrder();
//     var2.mapDatasetToRangeAxis(10, 0);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var11.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.util.PaintList var14 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var15 = var14.clone();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var18 = var17.getLabelAngle();
//     boolean var19 = var14.equals((java.lang.Object)var17);
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.util.RectangleEdge var23 = null;
//     double var24 = var17.getCategoryEnd((-1), 0, var22, var23);
//     var11.setDomainAxis(var17);
//     org.jfree.chart.plot.Plot var26 = var17.getPlot();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var32 = var30.getLegendTextFont(10);
//     java.awt.Paint var36 = var30.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("", var36);
//     java.awt.Stroke var38 = var37.getLineStroke();
//     var26.setOutlineStroke(var38);
//     var2.setOutlineStroke(var38);
//     var0.set(15, (java.lang.Object)var2);
//     org.jfree.chart.util.PaintList var42 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var43 = var42.clone();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var46 = var45.getLabelAngle();
//     boolean var47 = var42.equals((java.lang.Object)var45);
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleEdge var51 = null;
//     double var52 = var45.getCategoryEnd((-1), 0, var50, var51);
//     double var53 = var45.getFixedDimension();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var59 = var57.getLegendTextFont(10);
//     java.awt.Paint var63 = var57.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("", var63);
//     java.awt.Stroke var65 = var64.getLineStroke();
//     var45.setTickMarkStroke(var65);
//     var2.setDomainCrosshairStroke(var65);
//     
//     // Checks the contract:  equals-hashcode on var37 and var64
//     assertTrue("Contract failed: equals-hashcode on var37 and var64", var37.equals(var64) ? var37.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var37
//     assertTrue("Contract failed: equals-hashcode on var64 and var37", var64.equals(var37) ? var64.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    var1.setDrawSharedDomainAxis(false);
    org.jfree.data.general.DatasetGroup var16 = var1.getDatasetGroup();
    var1.setWeight(1);
    org.jfree.chart.plot.Marker var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var20 = var1.removeRangeMarker(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getLabelAngle();
//     var1.setTickMarksVisible(true);
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.data.category.AbstractCategoryDataset var8 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var10 = var8.hasListener((java.util.EventListener)var9);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.RenderingSource var14 = null;
//     var9.select(0.05d, (-1.0d), var13, var14);
//     boolean var16 = var9.isRangeCrosshairVisible();
//     java.lang.Comparable var17 = null;
//     var9.setDomainCrosshairColumnKey(var17);
//     org.jfree.chart.axis.AxisSpace var19 = null;
//     var9.setFixedRangeAxisSpace(var19, false);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     int var23 = var9.indexOf(var22);
//     org.jfree.chart.util.RectangleEdge var24 = var9.getRangeAxisEdge();
//     double var25 = var1.getCategoryStart((-16646144), 15, var7, var24);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getColumnCount();
    int var2 = var0.getColumnCount();
    var0.clear();
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var0.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((java.lang.Comparable)(-0.7853981633974483d));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setLowerMargin(10.0d);
    double var4 = var1.getUpperMargin();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var6 = var5.getRangeCrosshairPaint();
    float var7 = var5.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var8 = var5.getFixedRangeAxisSpace();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var10 = null;
    var9.setFixedRangeAxisSpace(var10);
    org.jfree.chart.util.PaintList var12 = new org.jfree.chart.util.PaintList();
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var16 = var15.getLabelAngle();
    boolean var17 = var12.equals((java.lang.Object)var15);
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var15.getCategoryEnd((-1), 0, var20, var21);
    var9.setDomainAxis(var15);
    var9.setDrawSharedDomainAxis(true);
    java.awt.Paint var26 = var9.getRangeZeroBaselinePaint();
    var5.setRangeCrosshairPaint(var26);
    var1.setAxisLinePaint(var26);
    boolean var29 = var1.isMinorTickMarksVisible();
    org.jfree.data.KeyedObjects2D var31 = new org.jfree.data.KeyedObjects2D();
    var31.clear();
    java.util.List var33 = var31.getRowKeys();
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.util.RectangleEdge var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var36 = var1.getCategoryMiddle((java.lang.Comparable)4, var33, var34, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.Marker var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var2.drawRangeMarker(var10, var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = new org.jfree.chart.LegendItemCollection();
    var11.setFixedLegendItems(var16);
    org.jfree.chart.LegendItemCollection var18 = var11.getFixedLegendItems();
    java.awt.Stroke var19 = var11.getRangeZeroBaselineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Stroke var12 = var2.lookupSeriesOutlineStroke((-1));
    var2.setBaseItemLabelsVisible(false);
    java.awt.Paint var16 = null;
    var2.setSeriesFillPaint(255, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var0.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    java.lang.Comparable var10 = var0.getColumnKey(0);
    var0.removeRow(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var15 = var0.isSelected(10, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100.05d+ "'", var10.equals(100.05d));

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var1 = null;
//     org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
//     java.awt.Paint var3 = null;
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     java.awt.Paint var5 = null;
//     java.awt.Paint[] var6 = new java.awt.Paint[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Stroke var9 = null;
//     java.awt.Stroke[] var10 = new java.awt.Stroke[] { var9};
//     java.awt.Shape var11 = null;
//     java.awt.Shape[] var12 = new java.awt.Shape[] { var11};
//     org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var6, var8, var10, var12);
//     boolean var14 = var2.equals((java.lang.Object)var8);
//     org.jfree.chart.LegendItemCollection var15 = new org.jfree.chart.LegendItemCollection();
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint var18 = null;
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Shape var24 = null;
//     java.awt.Shape[] var25 = new java.awt.Shape[] { var24};
//     org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var19, var21, var23, var25);
//     boolean var27 = var15.equals((java.lang.Object)var21);
//     java.awt.Paint var28 = null;
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var28};
//     java.awt.Paint var30 = null;
//     java.awt.Paint[] var31 = new java.awt.Paint[] { var30};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Shape var36 = null;
//     java.awt.Shape[] var37 = new java.awt.Shape[] { var36};
//     org.jfree.chart.plot.DefaultDrawingSupplier var38 = new org.jfree.chart.plot.DefaultDrawingSupplier(var29, var31, var33, var35, var37);
//     org.jfree.chart.plot.DefaultDrawingSupplier var39 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var8, var21, var37);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var26
//     assertTrue("Contract failed: equals-hashcode on var13 and var26", var13.equals(var26) ? var13.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var38
//     assertTrue("Contract failed: equals-hashcode on var13 and var38", var13.equals(var38) ? var13.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var13
//     assertTrue("Contract failed: equals-hashcode on var26 and var13", var26.equals(var13) ? var26.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var38
//     assertTrue("Contract failed: equals-hashcode on var26 and var38", var26.equals(var38) ? var26.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var13
//     assertTrue("Contract failed: equals-hashcode on var38 and var13", var38.equals(var13) ? var38.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var26
//     assertTrue("Contract failed: equals-hashcode on var38 and var26", var38.equals(var26) ? var38.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke var6 = null;
    java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
    java.awt.Shape var8 = null;
    java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
    boolean var12 = var10.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var17 = null;
    var15.setSeriesFillPaint(10, var17);
    int var19 = var15.getPassCount();
    java.awt.Font var21 = var15.lookupLegendTextFont(0);
    java.awt.Shape var23 = var15.lookupSeriesShape(10);
    boolean var24 = var10.equals((java.lang.Object)var23);
    java.awt.Shape var25 = var10.getNextShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    var1.setTickMarksVisible(true);
    double var5 = var1.getFixedDimension();
    double var6 = var1.getFixedDimension();
    java.awt.Paint var8 = var1.getTickLabelPaint((java.lang.Comparable)100.05d);
    boolean var9 = var1.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.data.category.CategoryDatasetSelectionState var3 = var0.getSelectionState();
//     org.jfree.data.category.AbstractCategoryDataset var4 = new org.jfree.data.category.AbstractCategoryDataset();
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.general.DatasetGroup var6 = new org.jfree.data.general.DatasetGroup();
//     var4.setGroup(var6);
//     var0.setGroup(var6);
//     org.jfree.data.category.AbstractCategoryDataset var9 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var11 = var9.hasListener((java.util.EventListener)var10);
//     boolean var12 = var6.equals((java.lang.Object)var9);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    org.jfree.chart.plot.DefaultDrawingSupplier var8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var9 = null;
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    java.awt.Paint var11 = null;
    java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var12, var14, var16, var18);
    boolean var20 = var8.equals((java.lang.Object)var18);
    var1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var8, true);
    java.awt.Stroke var23 = var8.getNextStroke();
    java.awt.Paint var24 = var8.getNextFillPaint();
    org.jfree.data.KeyedObjects2D var25 = new org.jfree.data.KeyedObjects2D();
    java.util.List var26 = var25.getRowKeys();
    boolean var27 = var8.equals((java.lang.Object)var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var29 = var25.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var1 = null;
//     var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
//     var0.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var13 = null;
//     var11.setSeriesFillPaint(10, var13);
//     int var15 = var11.getPassCount();
//     java.awt.Font var17 = var11.lookupLegendTextFont(0);
//     java.awt.Font var18 = null;
//     var11.setBaseLegendTextFont(var18);
//     java.awt.Font var21 = var11.getLegendTextFont(10);
//     org.jfree.chart.LegendItem var24 = var11.getLegendItem(0, 10);
//     java.awt.Graphics2D var25 = null;
//     org.jfree.data.category.AbstractCategoryDataset var26 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var28 = var26.hasListener((java.util.EventListener)var27);
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.RenderingSource var32 = null;
//     var27.select(0.05d, (-1.0d), var31, var32);
//     boolean var34 = var27.isRangeCrosshairVisible();
//     java.lang.Comparable var35 = null;
//     var27.setDomainCrosshairColumnKey(var35);
//     org.jfree.chart.axis.AxisSpace var37 = null;
//     var27.setFixedRangeAxisSpace(var37, false);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.plot.Marker var41 = null;
//     java.awt.geom.Rectangle2D var42 = null;
//     var11.drawRangeMarker(var25, var27, var40, var41, var42);
//     var11.setBaseCreateEntities(true, true);
//     boolean var47 = var0.equals((java.lang.Object)true);
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var50 = var49.getLabelAngle();
//     boolean var51 = var49.isVisible();
//     double var52 = var49.getFixedDimension();
//     java.lang.String var53 = var49.getLabel();
//     java.lang.String var54 = var49.getLabelURL();
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var49, var55, var56);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var60 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var62 = var60.getSeriesURLGenerator(1);
//     int var63 = var60.getPassCount();
//     var60.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.urls.CategoryURLGenerator var67 = var60.getBaseURLGenerator();
//     boolean var69 = var60.isSeriesItemLabelsVisible(0);
//     java.awt.Shape var73 = var60.getItemShape(0, (-1), true);
//     org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var75 = var74.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     java.awt.geom.Point2D var78 = null;
//     var74.zoomDomainAxes(100.0d, var77, var78, true);
//     org.jfree.chart.event.AxisChangeEvent var81 = null;
//     var74.axisChanged(var81);
//     org.jfree.chart.entity.PlotEntity var83 = new org.jfree.chart.entity.PlotEntity(var73, (org.jfree.chart.plot.Plot)var74);
//     var0.addChangeListener((org.jfree.data.event.DatasetChangeListener)var74);
//     
//     // Checks the contract:  equals-hashcode on var11 and var60
//     assertTrue("Contract failed: equals-hashcode on var11 and var60", var11.equals(var60) ? var11.hashCode() == var60.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var60.", var11.equals(var60) == var60.equals(var11));
//     
//     // Checks the contract:  equals-hashcode on var27 and var74
//     assertTrue("Contract failed: equals-hashcode on var27 and var74", var27.equals(var74) ? var27.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var27
//     assertTrue("Contract failed: equals-hashcode on var74 and var27", var74.equals(var27) ? var74.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var3 = var0.getPaint(0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var8 = null;
    var6.setSeriesFillPaint(10, var8);
    int var10 = var6.getPassCount();
    boolean var12 = var6.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var6.getLegendItemURLGenerator();
    java.awt.Paint var15 = var6.getSeriesItemLabelPaint(15);
    boolean var16 = var0.equals((java.lang.Object)var6);
    int var17 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getLabelAngle();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
//     java.lang.String var11 = var3.getLabelToolTip();
//     var3.setMinorTickMarkOutsideLength(100.0f);
//     java.awt.Stroke var14 = var3.getTickMarkStroke();
//     org.jfree.data.category.DefaultCategoryDataset var17 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var18 = null;
//     var17.setValue(var18, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
//     var17.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var30 = null;
//     var28.setSeriesFillPaint(10, var30);
//     int var32 = var28.getPassCount();
//     java.awt.Font var34 = var28.lookupLegendTextFont(0);
//     java.awt.Font var35 = null;
//     var28.setBaseLegendTextFont(var35);
//     java.awt.Font var38 = var28.getLegendTextFont(10);
//     org.jfree.chart.LegendItem var41 = var28.getLegendItem(0, 10);
//     java.awt.Graphics2D var42 = null;
//     org.jfree.data.category.AbstractCategoryDataset var43 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var45 = var43.hasListener((java.util.EventListener)var44);
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.RenderingSource var49 = null;
//     var44.select(0.05d, (-1.0d), var48, var49);
//     boolean var51 = var44.isRangeCrosshairVisible();
//     java.lang.Comparable var52 = null;
//     var44.setDomainCrosshairColumnKey(var52);
//     org.jfree.chart.axis.AxisSpace var54 = null;
//     var44.setFixedRangeAxisSpace(var54, false);
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.plot.Marker var58 = null;
//     java.awt.geom.Rectangle2D var59 = null;
//     var28.drawRangeMarker(var42, var44, var57, var58, var59);
//     var28.setBaseCreateEntities(true, true);
//     boolean var64 = var17.equals((java.lang.Object)true);
//     int var66 = var17.getRowIndex((java.lang.Comparable)(short)10);
//     java.awt.geom.Rectangle2D var68 = null;
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var70 = var69.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     java.awt.geom.Point2D var73 = null;
//     var69.zoomDomainAxes(100.0d, var72, var73, true);
//     var69.setNotify(true);
//     var69.setRangeCrosshairVisible(false);
//     org.jfree.chart.util.RectangleEdge var81 = var69.getRangeAxisEdge(100);
//     double var82 = var3.getCategorySeriesMiddle((java.lang.Comparable)3, (java.lang.Comparable)"RectangleInsets[t=1.0,l=0.05,b=0.05,r=100.0]", (org.jfree.data.category.CategoryDataset)var17, 100.05d, var68, var81);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.5f, 0.5f, 0.5f);
    java.awt.color.ColorSpace var4 = var3.getColorSpace();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = var7.getSeriesURLGenerator(1);
    java.awt.Shape var13 = var7.getItemShape(0, (-1), false);
    var7.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Color var19 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var20 = null;
    java.awt.Rectangle var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    java.awt.geom.AffineTransform var23 = null;
    java.awt.RenderingHints var24 = null;
    java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
    java.awt.color.ColorSpace var26 = var19.getColorSpace();
    java.awt.Color var27 = var19.brighter();
    var7.setBaseOutlinePaint((java.awt.Paint)var27);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var39 = var37.getSeriesURLGenerator(1);
    int var40 = var37.getPassCount();
    var37.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var44 = null;
    var37.setBaseItemLabelGenerator(var44, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var52 = var50.getLegendTextFont(10);
    java.awt.Paint var56 = var50.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("", var56);
    java.awt.Stroke var58 = var57.getLineStroke();
    var57.setSeriesIndex((-1));
    var57.setToolTipText("");
    java.lang.Comparable var63 = var57.getSeriesKey();
    java.awt.Shape var64 = var57.getShape();
    java.awt.Color var68 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    java.awt.image.ColorModel var69 = null;
    java.awt.Rectangle var70 = null;
    java.awt.geom.Rectangle2D var71 = null;
    java.awt.geom.AffineTransform var72 = null;
    java.awt.RenderingHints var73 = null;
    java.awt.PaintContext var74 = var68.createContext(var69, var70, var71, var72, var73);
    java.awt.color.ColorSpace var75 = var68.getColorSpace();
    java.awt.Color var76 = var68.brighter();
    var57.setLinePaint((java.awt.Paint)var68);
    var37.setBaseItemLabelPaint((java.awt.Paint)var68, false);
    float[] var83 = new float[] { 100.0f, 0.0f, 10.0f};
    float[] var84 = var68.getColorComponents(var83);
    float[] var85 = java.awt.Color.RGBtoHSB(100, 0, 128, var84);
    float[] var86 = java.awt.Color.RGBtoHSB(10, 100, 2, var84);
    float[] var87 = var27.getRGBColorComponents(var84);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var88 = var3.getRGBComponents(var87);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     var2.setSeriesVisibleInLegend(2, (java.lang.Boolean)true);
//     boolean var11 = var2.getItemLineVisible(0, 1);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var18 = var16.getLegendTextFont(10);
//     java.awt.Paint var22 = var16.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var22);
//     var2.setSeriesPaint(10, var22, false);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var2.", var16.equals(var2) == var2.equals(var16));
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     boolean var8 = var2.isSeriesVisible(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.Marker var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var2.drawRangeMarker(var10, var11, var12, var13, var14);
//     org.jfree.chart.LegendItemCollection var16 = new org.jfree.chart.LegendItemCollection();
//     var11.setFixedLegendItems(var16);
//     java.util.Iterator var18 = var16.iterator();
//     org.jfree.chart.LegendItemCollection var19 = new org.jfree.chart.LegendItemCollection();
//     java.util.Iterator var20 = var19.iterator();
//     var16.addAll(var19);
//     
//     // Checks the contract:  equals-hashcode on var16 and var19
//     assertTrue("Contract failed: equals-hashcode on var16 and var19", var16.equals(var19) ? var16.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var16
//     assertTrue("Contract failed: equals-hashcode on var19 and var16", var19.equals(var16) ? var19.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     java.util.List var2 = var0.getAnnotations();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var4 = null;
//     var3.setFixedRangeAxisSpace(var4);
//     boolean var6 = var3.isRangeGridlinesVisible();
//     var3.setRangeCrosshairValue(0.0d, true);
//     boolean var10 = var3.isRangeMinorGridlinesVisible();
//     double var11 = var3.getRangeCrosshairValue();
//     boolean var12 = var3.isOutlineVisible();
//     org.jfree.chart.util.SortOrder var13 = var3.getRowRenderingOrder();
//     var0.setColumnRenderingOrder(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject(1, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    java.lang.Boolean var10 = var2.getSeriesCreateEntities(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var2.setBaseToolTipGenerator(var11, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Paint var11 = var2.getBasePaint();
    var2.setBaseCreateEntities(false);
    java.awt.Stroke var15 = var2.getSeriesStroke((-16646144));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    org.jfree.chart.util.PaintList var3 = new org.jfree.chart.util.PaintList();
    java.lang.Object var4 = var3.clone();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var7 = var6.getLabelAngle();
    boolean var8 = var3.equals((java.lang.Object)var6);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var6.getCategoryEnd((-1), 0, var11, var12);
    var0.setDomainAxis(var6);
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.event.PlotChangeListener var17 = null;
    var0.addChangeListener(var17);
    int var19 = var0.getRendererCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var0.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    java.lang.Comparable var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setValue((java.lang.Number)0, (java.lang.Comparable)1L, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    int var6 = var2.getDefaultEntityRadius();
    java.awt.Stroke var7 = var2.getBaseOutlineStroke();
    var2.setBaseSeriesVisible(false);
    boolean var10 = var2.getBaseCreateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var2 = null;
//     org.jfree.chart.util.Layer var3 = null;
//     boolean var4 = var0.removeDomainMarker(1, var2, var3);
//     java.awt.Font var5 = var0.getNoDataMessageFont();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation((-1));
//     java.awt.Paint var9 = null;
//     java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Stroke var13 = null;
//     java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Shape var17 = null;
//     java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
//     org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var12, var14, var16, var18);
//     boolean var21 = var19.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var26 = null;
//     var24.setSeriesFillPaint(10, var26);
//     int var28 = var24.getPassCount();
//     java.awt.Font var30 = var24.lookupLegendTextFont(0);
//     java.awt.Shape var32 = var24.lookupSeriesShape(10);
//     boolean var33 = var19.equals((java.lang.Object)var32);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var36 = null;
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var34.removeDomainMarker(1, var36, var37);
//     org.jfree.chart.axis.AxisLocation var40 = var34.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var42 = new org.jfree.chart.entity.PlotEntity(var32, (org.jfree.chart.plot.Plot)var34, "hi!");
//     org.jfree.chart.plot.PlotOrientation var43 = var34.getOrientation();
//     java.lang.Object var44 = null;
//     boolean var45 = var43.equals(var44);
//     org.jfree.chart.util.RectangleEdge var46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var8, var43);
//     
//     // Checks the contract:  equals-hashcode on var0 and var34
//     assertTrue("Contract failed: equals-hashcode on var0 and var34", var0.equals(var34) ? var0.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var0
//     assertTrue("Contract failed: equals-hashcode on var34 and var0", var34.equals(var0) ? var34.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var4 = var2.getLegendTextFont(10);
//     java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
//     java.awt.Paint var12 = var2.getItemLabelPaint(2, 0, false);
//     boolean var15 = var2.getItemLineVisible(10, 2);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var21 = var19.getSeriesURLGenerator(1);
//     int var22 = var19.getPassCount();
//     java.lang.Boolean var24 = var19.getSeriesItemLabelsVisible(0);
//     java.awt.Paint var26 = var19.getSeriesItemLabelPaint(2);
//     java.awt.Shape var28 = var19.lookupLegendShape(3);
//     var2.setSeriesShape(2, var28, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var2.", var19.equals(var2) == var2.equals(var19));
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    java.awt.Font var8 = var2.lookupLegendTextFont(0);
    java.awt.Font var9 = null;
    var2.setBaseLegendTextFont(var9);
    java.awt.Font var12 = var2.getLegendTextFont(10);
    org.jfree.chart.LegendItem var15 = var2.getLegendItem(0, 10);
    java.awt.Graphics2D var16 = null;
    org.jfree.data.category.AbstractCategoryDataset var17 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var17.hasListener((java.util.EventListener)var18);
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.RenderingSource var23 = null;
    var18.select(0.05d, (-1.0d), var22, var23);
    boolean var25 = var18.isRangeCrosshairVisible();
    java.lang.Comparable var26 = null;
    var18.setDomainCrosshairColumnKey(var26);
    org.jfree.chart.axis.AxisSpace var28 = null;
    var18.setFixedRangeAxisSpace(var28, false);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.plot.Marker var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    var2.drawRangeMarker(var16, var18, var31, var32, var33);
    var18.setDomainGridlinesVisible(false);
    org.jfree.chart.annotations.CategoryAnnotation var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.addAnnotation(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    java.lang.Boolean var7 = var2.getSeriesItemLabelsVisible(0);
    java.awt.Paint var9 = var2.getSeriesItemLabelPaint(2);
    boolean var13 = var2.isItemLabelVisible(128, 10, false);
    boolean var14 = var2.getDrawOutlines();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var21 = var19.getLegendTextFont(10);
    java.awt.Paint var25 = var19.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", var25);
    java.awt.Stroke var27 = var26.getLineStroke();
    java.awt.Paint var28 = var26.getLabelPaint();
    java.awt.Stroke var29 = var26.getOutlineStroke();
    java.awt.Paint var30 = var26.getLinePaint();
    java.lang.Comparable var31 = var26.getSeriesKey();
    java.awt.Shape var32 = var26.getShape();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLegendShape((-1), var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, 0.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-10));

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     double var1 = var0.getAngle();
//     float var2 = var0.getShadowOpacity();
//     java.awt.image.BufferedImage var3 = null;
//     java.awt.image.BufferedImage var4 = var0.createDropShadow(var3);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    java.lang.Object var3 = var1.get((-1));
    java.lang.Object var5 = var1.get(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject((java.lang.Comparable)100.0f, (java.lang.Object)'4');
//     java.lang.Object var3 = var2.clone();
//     java.lang.Comparable var4 = var2.getKey();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var10 = var8.getLegendTextFont(10);
//     java.awt.Paint var14 = var8.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("", var14);
//     java.awt.Stroke var16 = var15.getLineStroke();
//     java.awt.Paint var17 = var15.getLabelPaint();
//     java.awt.Stroke var18 = var15.getOutlineStroke();
//     var15.setDatasetIndex(0);
//     var2.setObject((java.lang.Object)0);
//     org.jfree.data.category.AbstractCategoryDataset var22 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var24 = var22.hasListener((java.util.EventListener)var23);
//     org.jfree.chart.plot.Marker var26 = null;
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var28 = var23.removeDomainMarker(0, var26, var27);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     java.awt.geom.Point2D var31 = null;
//     var23.zoomDomainAxes(100.0d, var30, var31, false);
//     var23.setCrosshairDatasetIndex(3);
//     var23.setDrawSharedDomainAxis(false);
//     var23.setDomainCrosshairRowKey((java.lang.Comparable)(short)0);
//     var23.setDomainCrosshairRowKey((java.lang.Comparable)(byte)10, false);
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var45 = var44.getLabelAngle();
//     boolean var46 = var44.isVisible();
//     double var47 = var44.getFixedDimension();
//     java.lang.String var48 = var44.getLabel();
//     java.lang.String var49 = var44.getLabelURL();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var52 = var51.getLabelAngle();
//     var51.setMinorTickMarkInsideLength(10.0f);
//     boolean var55 = var51.isMinorTickMarksVisible();
//     float var56 = var51.getMinorTickMarkInsideLength();
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var58 = null;
//     var57.setFixedRangeAxisSpace(var58);
//     org.jfree.chart.util.PaintList var60 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var61 = var60.clone();
//     org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var64 = var63.getLabelAngle();
//     boolean var65 = var60.equals((java.lang.Object)var63);
//     java.awt.geom.Rectangle2D var68 = null;
//     org.jfree.chart.util.RectangleEdge var69 = null;
//     double var70 = var63.getCategoryEnd((-1), 0, var68, var69);
//     var57.setDomainAxis(var63);
//     var57.setDrawSharedDomainAxis(true);
//     java.awt.Paint var74 = var57.getRangeZeroBaselinePaint();
//     var51.setTickLabelPaint(var74);
//     var44.setTickLabelPaint(var74);
//     var23.setBackgroundPaint(var74);
//     var2.setObject((java.lang.Object)var23);
//     
//     // Checks the contract:  equals-hashcode on var61 and var3
//     assertTrue("Contract failed: equals-hashcode on var61 and var3", var61.equals(var3) ? var61.hashCode() == var3.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var61 and var3.", var61.equals(var3) == var3.equals(var61));
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
//     var0.addAll(var2);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     int var7 = var2.getPassCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
//     java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
//     var10.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var10.getPositiveItemLabelPosition(1, 0, false);
//     var2.setBaseNegativeItemLabelPosition(var24);
//     var2.setUseSeriesOffset(false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var33 = var31.getLegendTextFont(10);
//     java.awt.Paint var37 = var31.getItemPaint(10, 100, true);
//     org.jfree.chart.labels.ItemLabelPosition var38 = var31.getBasePositiveItemLabelPosition();
//     java.lang.Object var39 = null;
//     boolean var40 = var38.equals(var39);
//     var2.setSeriesPositiveItemLabelPosition(2, var38);
//     
//     // Checks the contract:  equals-hashcode on var24 and var38
//     assertTrue("Contract failed: equals-hashcode on var24 and var38", var24.equals(var38) ? var24.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var24
//     assertTrue("Contract failed: equals-hashcode on var38 and var24", var38.equals(var24) ? var38.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    var0.clear();
    java.util.List var3 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getShadowYOffset();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = var5.getSeriesURLGenerator(1);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
//     var5.setBaseItemLabelGenerator(var8);
//     boolean var12 = var5.getItemLineVisible(15, 2);
//     java.awt.Paint var14 = var5.lookupSeriesFillPaint(0);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var18 = var17.getRangeCrosshairPaint();
//     var17.configureDomainAxes();
//     org.jfree.chart.axis.ValueAxis var20 = var17.getRangeAxis();
//     org.jfree.data.category.CategoryDataset var21 = var17.getDataset();
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var24 = var5.initialise(var15, var16, var17, var22, var23);
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var26.setFixedRangeAxisSpace(var27);
//     boolean var29 = var26.isRangeGridlinesVisible();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var40 = var38.getSeriesURLGenerator(1);
//     java.awt.Shape var44 = var38.getItemShape(0, (-1), false);
//     double var45 = var38.getItemMargin();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = null;
//     var38.setLegendItemURLGenerator(var46);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var52 = null;
//     var50.setSeriesFillPaint(10, var52);
//     int var54 = var50.getPassCount();
//     java.awt.Font var56 = var50.lookupLegendTextFont(0);
//     java.awt.Shape var58 = var50.lookupSeriesShape(10);
//     var38.setBaseLegendShape(var58);
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var61 = null;
//     var60.setFixedRangeAxisSpace(var61);
//     org.jfree.chart.util.Layer var64 = null;
//     java.util.Collection var65 = var60.getRangeMarkers((-1), var64);
//     java.awt.Paint var66 = var60.getRangeGridlinePaint();
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = hi!", "GradientPaintTransformType.VERTICAL", "", "GradientPaintTransformType.VERTICAL", var58, var66);
//     org.jfree.data.category.DefaultCategoryDataset var70 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var71 = null;
//     var70.setValue(var71, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
//     var70.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
//     java.lang.Comparable var80 = var70.getColumnKey(0);
//     var70.removeRow(0);
//     org.jfree.chart.entity.CategoryItemEntity var85 = new org.jfree.chart.entity.CategoryItemEntity(var58, "hi!", "RectangleInsets[t=1.0,l=0.05,b=0.05,r=100.0]", (org.jfree.data.category.CategoryDataset)var70, (java.lang.Comparable)"DatasetRenderingOrder.REVERSE", (java.lang.Comparable)(short)1);
//     var0.drawItem(var2, var24, var25, var26, var30, var31, (org.jfree.data.category.CategoryDataset)var70, (-16646144), (-16646144), true, 1);
//     
//     // Checks the contract:  equals-hashcode on var5 and var50
//     assertTrue("Contract failed: equals-hashcode on var5 and var50", var5.equals(var50) ? var5.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var5
//     assertTrue("Contract failed: equals-hashcode on var50 and var5", var50.equals(var5) ? var50.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var26
//     assertTrue("Contract failed: equals-hashcode on var17 and var26", var17.equals(var26) ? var17.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var60
//     assertTrue("Contract failed: equals-hashcode on var17 and var60", var17.equals(var60) ? var17.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var17
//     assertTrue("Contract failed: equals-hashcode on var26 and var17", var26.equals(var17) ? var26.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var60
//     assertTrue("Contract failed: equals-hashcode on var26 and var60", var26.equals(var60) ? var26.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var17
//     assertTrue("Contract failed: equals-hashcode on var60 and var17", var60.equals(var17) ? var60.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var26
//     assertTrue("Contract failed: equals-hashcode on var60 and var26", var60.equals(var26) ? var60.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    java.awt.Font var8 = var2.lookupLegendTextFont(0);
    java.awt.Font var9 = null;
    var2.setBaseLegendTextFont(var9);
    java.awt.Font var12 = var2.getLegendTextFont(10);
    org.jfree.chart.LegendItem var15 = var2.getLegendItem(0, 10);
    java.awt.Graphics2D var16 = null;
    org.jfree.data.category.AbstractCategoryDataset var17 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var17.hasListener((java.util.EventListener)var18);
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.RenderingSource var23 = null;
    var18.select(0.05d, (-1.0d), var22, var23);
    boolean var25 = var18.isRangeCrosshairVisible();
    java.lang.Comparable var26 = null;
    var18.setDomainCrosshairColumnKey(var26);
    org.jfree.chart.axis.AxisSpace var28 = null;
    var18.setFixedRangeAxisSpace(var28, false);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.plot.Marker var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    var2.drawRangeMarker(var16, var18, var31, var32, var33);
    var18.setDomainGridlinesVisible(false);
    var18.setDomainCrosshairRowKey((java.lang.Comparable)' ', false);
    org.jfree.chart.plot.Marker var40 = null;
    org.jfree.chart.util.Layer var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var42 = var18.removeRangeMarker(var40, var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    int var7 = var2.getPassCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
    java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
    var10.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var24 = var10.getPositiveItemLabelPosition(1, 0, false);
    var2.setBaseNegativeItemLabelPosition(var24);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = var2.getLegendItemToolTipGenerator();
    var2.setUseSeriesOffset(true);
    boolean var29 = var2.getBaseSeriesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var0.axisChanged(var7);
    org.jfree.chart.util.PaintList var9 = new org.jfree.chart.util.PaintList();
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var13 = var12.getLabelAngle();
    boolean var14 = var9.equals((java.lang.Object)var12);
    java.lang.Object var15 = null;
    boolean var16 = var12.equals(var15);
    var12.setTickMarksVisible(false);
    var0.setDomainAxis(var12);
    var12.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke var6 = null;
    java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
    java.awt.Shape var8 = null;
    java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
    boolean var12 = var10.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var17 = null;
    var15.setSeriesFillPaint(10, var17);
    int var19 = var15.getPassCount();
    java.awt.Font var21 = var15.lookupLegendTextFont(0);
    java.awt.Shape var23 = var15.lookupSeriesShape(10);
    boolean var24 = var10.equals((java.lang.Object)var23);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var27 = null;
    org.jfree.chart.util.Layer var28 = null;
    boolean var29 = var25.removeDomainMarker(1, var27, var28);
    org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
    org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var25, "hi!");
    org.jfree.chart.axis.AxisSpace var34 = null;
    var25.setFixedRangeAxisSpace(var34, true);
    org.jfree.chart.util.ShadowGenerator var37 = null;
    var25.setShadowGenerator(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    java.awt.Paint var11 = var2.lookupLegendTextPaint((-1));
    var2.setAutoPopulateSeriesFillPaint(false);
    java.awt.Paint var17 = var2.getItemOutlinePaint(128, 10, false);
    var2.setAutoPopulateSeriesPaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var18 = var16.getSeriesURLGenerator(1);
    java.awt.Shape var22 = var16.getItemShape(0, (-1), false);
    double var23 = var16.getItemMargin();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = null;
    var16.setLegendItemURLGenerator(var24);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var30 = null;
    var28.setSeriesFillPaint(10, var30);
    int var32 = var28.getPassCount();
    java.awt.Font var34 = var28.lookupLegendTextFont(0);
    java.awt.Shape var36 = var28.lookupSeriesShape(10);
    var16.setBaseLegendShape(var36);
    java.awt.Paint var38 = null;
    var16.setBaseLegendTextPaint(var38);
    var16.removeAnnotations();
    java.awt.Color var45 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
    var16.setSeriesItemLabelPaint(2, (java.awt.Paint)var45);
    boolean var47 = var1.equals((java.lang.Object)2);
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var50 = var49.getRangeCrosshairPaint();
    java.util.List var51 = var49.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.mapDatasetToRangeAxes(255, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var3 = var2.clone();
    var2.clear();
    int var5 = var2.getColumnCount();
    var0.addObject((java.lang.Comparable)10.0f, (java.lang.Object)var5);
    java.util.List var7 = var0.getKeys();
    var0.removeValue(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var2 = null;
    org.jfree.chart.util.Layer var3 = null;
    boolean var4 = var0.removeDomainMarker(1, var2, var3);
    var0.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getRangeMarkers(var7);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var0.getRenderer(0);
    org.jfree.chart.annotations.CategoryAnnotation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var7 = var2.getAutoPopulateSeriesOutlinePaint();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var11 = var10.getRangeCrosshairPaint();
    var10.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var15 = var2.initialise(var8, var9, var10, var13, var14);
    var10.setBackgroundAlpha(1.0f);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var20 = var19.getRangeCrosshairPaint();
    java.util.List var21 = var19.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.mapDatasetToRangeAxes(1, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     org.jfree.chart.util.PaintList var3 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var4 = var3.clone();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var7 = var6.getLabelAngle();
//     boolean var8 = var3.equals((java.lang.Object)var6);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var6.getCategoryEnd((-1), 0, var11, var12);
//     var0.setDomainAxis(var6);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var16.setFixedRangeAxisSpace(var17);
//     java.lang.Comparable var19 = var16.getDomainCrosshairColumnKey();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var25 = var23.getSeriesURLGenerator(1);
//     java.awt.Shape var29 = var23.getItemShape(0, (-1), false);
//     java.awt.Paint var33 = var23.getItemOutlinePaint(10, 0, false);
//     var16.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23, false);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var38 = null;
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var36.removeDomainMarker(1, var38, var39);
//     org.jfree.chart.axis.AxisLocation var42 = var36.getDomainAxisLocation(100);
//     org.jfree.chart.axis.AxisLocation var43 = org.jfree.chart.axis.AxisLocation.getOpposite(var42);
//     var16.setDomainAxisLocation(var42, false);
//     var0.setRangeAxisLocation(10, var42);
//     java.awt.Paint var47 = null;
//     java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
//     java.awt.Paint var49 = null;
//     java.awt.Paint[] var50 = new java.awt.Paint[] { var49};
//     java.awt.Stroke var51 = null;
//     java.awt.Stroke[] var52 = new java.awt.Stroke[] { var51};
//     java.awt.Stroke var53 = null;
//     java.awt.Stroke[] var54 = new java.awt.Stroke[] { var53};
//     java.awt.Shape var55 = null;
//     java.awt.Shape[] var56 = new java.awt.Shape[] { var55};
//     org.jfree.chart.plot.DefaultDrawingSupplier var57 = new org.jfree.chart.plot.DefaultDrawingSupplier(var48, var50, var52, var54, var56);
//     boolean var59 = var57.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var62 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var64 = null;
//     var62.setSeriesFillPaint(10, var64);
//     int var66 = var62.getPassCount();
//     java.awt.Font var68 = var62.lookupLegendTextFont(0);
//     java.awt.Shape var70 = var62.lookupSeriesShape(10);
//     boolean var71 = var57.equals((java.lang.Object)var70);
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var74 = null;
//     org.jfree.chart.util.Layer var75 = null;
//     boolean var76 = var72.removeDomainMarker(1, var74, var75);
//     org.jfree.chart.axis.AxisLocation var78 = var72.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var80 = new org.jfree.chart.entity.PlotEntity(var70, (org.jfree.chart.plot.Plot)var72, "hi!");
//     org.jfree.chart.plot.PlotOrientation var81 = var72.getOrientation();
//     org.jfree.chart.util.RectangleEdge var82 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var42, var81);
//     
//     // Checks the contract:  equals-hashcode on var36 and var72
//     assertTrue("Contract failed: equals-hashcode on var36 and var72", var36.equals(var72) ? var36.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var36
//     assertTrue("Contract failed: equals-hashcode on var72 and var36", var72.equals(var36) ? var72.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var62
//     assertTrue("Contract failed: equals-hashcode on var23 and var62", var23.equals(var62) ? var23.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var23
//     assertTrue("Contract failed: equals-hashcode on var62 and var23", var62.equals(var23) ? var62.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = var6.getSeriesURLGenerator(1);
//     java.awt.Shape var12 = var6.getItemShape(0, (-1), false);
//     double var13 = var6.getItemMargin();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = null;
//     var6.setLegendItemURLGenerator(var14);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var20 = null;
//     var18.setSeriesFillPaint(10, var20);
//     int var22 = var18.getPassCount();
//     java.awt.Font var24 = var18.lookupLegendTextFont(0);
//     java.awt.Shape var26 = var18.lookupSeriesShape(10);
//     var6.setBaseLegendShape(var26);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var29 = null;
//     var28.setFixedRangeAxisSpace(var29);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var28.getRangeMarkers((-1), var32);
//     java.awt.Paint var34 = var28.getRangeGridlinePaint();
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = hi!", "GradientPaintTransformType.VERTICAL", "", "GradientPaintTransformType.VERTICAL", var26, var34);
//     org.jfree.data.category.DefaultCategoryDataset var38 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Number var39 = null;
//     var38.setValue(var39, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
//     var38.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
//     java.lang.Comparable var48 = var38.getColumnKey(0);
//     var38.removeRow(0);
//     org.jfree.chart.entity.CategoryItemEntity var53 = new org.jfree.chart.entity.CategoryItemEntity(var26, "hi!", "RectangleInsets[t=1.0,l=0.05,b=0.05,r=100.0]", (org.jfree.data.category.CategoryDataset)var38, (java.lang.Comparable)"DatasetRenderingOrder.REVERSE", (java.lang.Comparable)(short)1);
//     org.jfree.data.category.CategoryDataset var54 = var53.getDataset();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var59 = var57.getSeriesURLGenerator(1);
//     java.awt.Shape var63 = var57.getItemShape(0, (-1), false);
//     var57.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var67 = var57.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var71 = var57.getPositiveItemLabelPosition(1, 0, false);
//     int var72 = var57.getRowCount();
//     java.awt.Font var74 = var57.getSeriesItemLabelFont(15);
//     boolean var76 = var57.isSeriesVisible(15);
//     java.awt.Stroke var78 = var57.lookupSeriesOutlineStroke(100);
//     boolean var79 = var53.equals((java.lang.Object)var57);
//     
//     // Checks the contract:  equals-hashcode on var18 and var57
//     assertTrue("Contract failed: equals-hashcode on var18 and var57", var18.equals(var57) ? var18.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var18
//     assertTrue("Contract failed: equals-hashcode on var57 and var18", var57.equals(var18) ? var57.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var0.axisChanged(var7);
    org.jfree.data.KeyedObjects2D var10 = new org.jfree.data.KeyedObjects2D();
    int var11 = var10.getColumnCount();
    int var12 = var10.getColumnCount();
    var10.clear();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var16 = var15.getLabelAngle();
    var15.setMinorTickMarkInsideLength(10.0f);
    boolean var19 = var15.isMinorTickMarksVisible();
    float var20 = var15.getMinorTickMarkInsideLength();
    var10.addObject((java.lang.Object)var15, (java.lang.Comparable)(byte)10, (java.lang.Comparable)0L);
    var0.setDomainAxis(100, var15);
    org.jfree.chart.LegendItemCollection var25 = var0.getLegendItems();
    int var26 = var25.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator(1);
    java.awt.Paint var7 = null;
    var3.setSeriesPaint(0, var7, true);
    java.awt.Paint var13 = var3.getItemOutlinePaint(100, 3, true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var3.getPositiveItemLabelPosition(3, (-1), false);
    org.jfree.chart.text.TextAnchor var18 = var17.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var19 = new org.jfree.chart.labels.ItemLabelPosition(var0, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var12 = var2.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var16 = var2.getPositiveItemLabelPosition(1, 0, false);
    org.jfree.chart.labels.ItemLabelPosition var20 = var2.getNegativeItemLabelPosition(3, 2, true);
    java.awt.Paint var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseFillPaint(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.image.BufferedImage var1 = null;
//     java.awt.image.BufferedImage var2 = var0.createDropShadow(var1);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var4 = var2.getLegendTextFont(10);
//     java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
//     java.awt.Paint var12 = var2.getItemLabelPaint(2, 0, false);
//     var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     var2.setBaseCreateEntities(true, false);
//     boolean var19 = var2.getUseOutlinePaint();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var24 = var23.getLabelAngle();
//     var23.setMinorTickMarkInsideLength(10.0f);
//     var23.setLabel("");
//     org.jfree.chart.plot.CategoryMarker var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     var2.drawDomainMarker(var20, var21, var23, var29, var30);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var0.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    java.lang.Comparable var10 = var0.getColumnKey(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected(15, 2, true);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100.05d+ "'", var10.equals(100.05d));

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(100.0d, var3, var4, true);
//     var0.setNotify(true);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
//     var0.setRangeCrosshairValue(0.0d);
//     var0.setDomainCrosshairRowKey((java.lang.Comparable)2.0d, false);
//     java.lang.Object var15 = var0.clone();
//     org.jfree.chart.plot.Marker var16 = null;
//     var0.addRangeMarker(var16);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var0.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var13 = null;
    var11.setSeriesFillPaint(10, var13);
    int var15 = var11.getPassCount();
    java.awt.Font var17 = var11.lookupLegendTextFont(0);
    java.awt.Font var18 = null;
    var11.setBaseLegendTextFont(var18);
    java.awt.Font var21 = var11.getLegendTextFont(10);
    org.jfree.chart.LegendItem var24 = var11.getLegendItem(0, 10);
    java.awt.Graphics2D var25 = null;
    org.jfree.data.category.AbstractCategoryDataset var26 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    boolean var28 = var26.hasListener((java.util.EventListener)var27);
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.RenderingSource var32 = null;
    var27.select(0.05d, (-1.0d), var31, var32);
    boolean var34 = var27.isRangeCrosshairVisible();
    java.lang.Comparable var35 = null;
    var27.setDomainCrosshairColumnKey(var35);
    org.jfree.chart.axis.AxisSpace var37 = null;
    var27.setFixedRangeAxisSpace(var37, false);
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.plot.Marker var41 = null;
    java.awt.geom.Rectangle2D var42 = null;
    var11.drawRangeMarker(var25, var27, var40, var41, var42);
    var11.setBaseCreateEntities(true, true);
    boolean var47 = var0.equals((java.lang.Object)true);
    int var49 = var0.getRowIndex((java.lang.Comparable)(short)10);
    java.util.List var50 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((java.lang.Comparable)(byte)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     java.awt.Paint var4 = null;
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
//     java.awt.Paint var6 = null;
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     java.awt.Stroke var8 = null;
//     java.awt.Stroke[] var9 = new java.awt.Stroke[] { var8};
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Shape var12 = null;
//     java.awt.Shape[] var13 = new java.awt.Shape[] { var12};
//     org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var7, var9, var11, var13);
//     boolean var16 = var14.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var21 = null;
//     var19.setSeriesFillPaint(10, var21);
//     int var23 = var19.getPassCount();
//     java.awt.Font var25 = var19.lookupLegendTextFont(0);
//     java.awt.Shape var27 = var19.lookupSeriesShape(10);
//     boolean var28 = var14.equals((java.lang.Object)var27);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var30 = null;
//     var29.setFixedRangeAxisSpace(var30);
//     java.lang.Comparable var32 = var29.getDomainCrosshairColumnKey();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var38 = var36.getSeriesURLGenerator(1);
//     java.awt.Shape var42 = var36.getItemShape(0, (-1), false);
//     java.awt.Paint var46 = var36.getItemOutlinePaint(10, 0, false);
//     var29.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36, false);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var51 = null;
//     org.jfree.chart.util.Layer var52 = null;
//     boolean var53 = var49.removeDomainMarker(1, var51, var52);
//     org.jfree.chart.axis.AxisLocation var55 = var49.getDomainAxisLocation(100);
//     org.jfree.chart.axis.AxisLocation var56 = org.jfree.chart.axis.AxisLocation.getOpposite(var55);
//     var29.setDomainAxisLocation(var55, false);
//     java.awt.Stroke var59 = var29.getRangeGridlineStroke();
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var61 = var60.getRangeCrosshairPaint();
//     float var62 = var60.getBackgroundImageAlpha();
//     var60.clearDomainMarkers();
//     var60.setNoDataMessage("hi!");
//     org.jfree.chart.axis.CategoryAnchor var66 = var60.getDomainGridlinePosition();
//     java.awt.Paint var67 = var60.getRangeMinorGridlinePaint();
//     java.awt.Paint var68 = var60.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var69 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "UnitType.ABSOLUTE", "Category Plot", "UnitType.ABSOLUTE", var27, var59, var68);
//     
//     // Checks the contract:  equals-hashcode on var19 and var36
//     assertTrue("Contract failed: equals-hashcode on var19 and var36", var19.equals(var36) ? var19.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var19
//     assertTrue("Contract failed: equals-hashcode on var36 and var19", var36.equals(var19) ? var36.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     org.jfree.chart.util.RectangleEdge var3 = var0.getDomainAxisEdge();
//     org.jfree.chart.plot.Plot var4 = var0.getRootPlot();
//     var0.setRangeCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var8 = var7.getRangeCrosshairPaint();
//     float var9 = var7.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var10 = var7.getFixedRangeAxisSpace();
//     var7.setWeight(100);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     var7.setRangeAxis(var13);
//     org.jfree.chart.plot.Marker var16 = null;
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var18 = var7.removeDomainMarker(100, var16, var17);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var20 = null;
//     var19.setFixedRangeAxisSpace(var20);
//     var19.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.util.SortOrder var24 = var19.getColumnRenderingOrder();
//     var7.setRowRenderingOrder(var24);
//     var0.setColumnRenderingOrder(var24);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d, true);
    org.jfree.chart.util.RectangleEdge var7 = var0.getRangeAxisEdge();
    double var8 = var0.getRangeCrosshairValue();
    java.awt.Stroke var9 = var0.getRangeMinorGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    int var6 = var0.getRowIndex((java.lang.Comparable)2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected((-16646144), (-1), true, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator(1);
    java.awt.Paint var7 = null;
    var3.setSeriesPaint(0, var7, true);
    java.awt.Paint var13 = var3.getItemOutlinePaint(100, 3, true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var3.getPositiveItemLabelPosition(3, (-1), false);
    org.jfree.chart.text.TextAnchor var18 = var17.getRotationAnchor();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var23 = var21.getSeriesURLGenerator(1);
    java.awt.Shape var27 = var21.getItemShape(0, (-1), false);
    var21.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var31 = var21.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var35 = var21.getPositiveItemLabelPosition(1, 0, false);
    double var36 = var35.getAngle();
    org.jfree.chart.text.TextAnchor var37 = var35.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var39 = new org.jfree.chart.labels.ItemLabelPosition(var0, var18, var37, (-101.05d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d, true);
    boolean var7 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.Marker var8 = null;
    boolean var9 = var0.removeDomainMarker(var8);
    java.awt.Paint var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNoDataMessagePaint(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    var1.setTickMarksVisible(true);
    double var5 = var1.getFixedDimension();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var7 = null;
    var6.setFixedRangeAxisSpace(var7);
    boolean var9 = var6.isRangeGridlinesVisible();
    var6.setRangeCrosshairValue(0.0d, true);
    boolean var13 = var6.isRangeMinorGridlinesVisible();
    boolean var14 = var1.hasListener((java.util.EventListener)var6);
    java.lang.Comparable var15 = null;
    org.jfree.chart.util.PaintList var16 = new org.jfree.chart.util.PaintList();
    java.lang.Object var17 = var16.clone();
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var20 = var19.getLabelAngle();
    boolean var21 = var16.equals((java.lang.Object)var19);
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var19.getCategoryEnd((-1), 0, var24, var25);
    java.lang.String var27 = var19.getLabelToolTip();
    var19.removeCategoryLabelToolTip((java.lang.Comparable)15);
    java.awt.Font var30 = var19.getLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelFont(var15, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    int var7 = var2.getPassCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator(1);
    java.awt.Shape var16 = var10.getItemShape(0, (-1), false);
    var10.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var20 = var10.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var24 = var10.getPositiveItemLabelPosition(1, 0, false);
    var2.setBaseNegativeItemLabelPosition(var24);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = var2.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = var2.getSeriesToolTipGenerator(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("-3,-3,3,3");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var5.setFixedRangeAxisSpace(var6);
//     org.jfree.chart.util.RectangleEdge var8 = var5.getDomainAxisEdge();
//     double var9 = var1.getCategoryStart(10, 2, var4, var8);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    java.lang.Boolean var7 = var2.getSeriesItemLabelsVisible(0);
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var16 = var14.getLegendTextFont(10);
    java.awt.Paint var20 = var14.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", var20);
    java.awt.Stroke var22 = var21.getLineStroke();
    var21.setSeriesIndex((-1));
    var21.setToolTipText("");
    java.lang.Comparable var27 = var21.getSeriesKey();
    java.awt.Shape var28 = var21.getShape();
    java.awt.Paint var29 = var21.getOutlinePaint();
    org.jfree.chart.util.GradientPaintTransformer var30 = var21.getFillPaintTransformer();
    var21.setSeriesKey((java.lang.Comparable)15);
    java.awt.Paint var33 = var21.getFillPaint();
    var2.setSeriesOutlinePaint(1, var33, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var0.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var13 = null;
    var11.setSeriesFillPaint(10, var13);
    int var15 = var11.getPassCount();
    java.awt.Font var17 = var11.lookupLegendTextFont(0);
    java.awt.Font var18 = null;
    var11.setBaseLegendTextFont(var18);
    java.awt.Font var21 = var11.getLegendTextFont(10);
    org.jfree.chart.LegendItem var24 = var11.getLegendItem(0, 10);
    java.awt.Graphics2D var25 = null;
    org.jfree.data.category.AbstractCategoryDataset var26 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    boolean var28 = var26.hasListener((java.util.EventListener)var27);
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.RenderingSource var32 = null;
    var27.select(0.05d, (-1.0d), var31, var32);
    boolean var34 = var27.isRangeCrosshairVisible();
    java.lang.Comparable var35 = null;
    var27.setDomainCrosshairColumnKey(var35);
    org.jfree.chart.axis.AxisSpace var37 = null;
    var27.setFixedRangeAxisSpace(var37, false);
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.plot.Marker var41 = null;
    java.awt.geom.Rectangle2D var42 = null;
    var11.drawRangeMarker(var25, var27, var40, var41, var42);
    var11.setBaseCreateEntities(true, true);
    boolean var47 = var0.equals((java.lang.Object)true);
    int var49 = var0.getRowIndex((java.lang.Comparable)(short)10);
    org.jfree.data.category.DefaultCategoryDataset var50 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var51 = null;
    var50.setValue(var51, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var0.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var50);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.removeRow(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1));

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
    var0.mapDatasetToRangeAxis(10, 0);
    var0.setAnchorValue(10.0d);
    var0.setAnchorValue((-1.0d), false);
    boolean var14 = var0.isDomainCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.Marker var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var2.drawRangeMarker(var10, var11, var12, var13, var14);
    var2.setSeriesCreateEntities(100, (java.lang.Boolean)false);
    java.awt.Shape var20 = null;
    var2.setSeriesShape(1, var20, true);
    java.awt.Paint var24 = var2.getSeriesItemLabelPaint((-1));
    var2.setBaseShapesFilled(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    java.awt.Font var8 = var2.lookupLegendTextFont(0);
    java.awt.Shape var10 = var2.lookupSeriesShape(10);
    var2.setSeriesShapesFilled(10, true);
    boolean var14 = var2.getUseSeriesOffset();
    java.lang.Boolean var16 = var2.getSeriesItemLabelsVisible(15);
    boolean var19 = var2.getItemVisible(15, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getLabelAngle();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
//     java.lang.String var11 = var3.getLabelToolTip();
//     var3.removeCategoryLabelToolTip((java.lang.Comparable)15);
//     int var14 = var3.getCategoryLabelPositionOffset();
//     var3.setMaximumCategoryLabelLines(10);
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.data.category.AbstractCategoryDataset var20 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var22 = var20.hasListener((java.util.EventListener)var21);
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.RenderingSource var26 = null;
//     var21.select(0.05d, (-1.0d), var25, var26);
//     org.jfree.chart.plot.Plot var28 = var21.getRootPlot();
//     org.jfree.chart.plot.DatasetRenderingOrder var29 = var21.getDatasetRenderingOrder();
//     java.lang.Object var30 = var21.clone();
//     boolean var31 = var21.isRangeZoomable();
//     org.jfree.chart.util.RectangleEdge var33 = var21.getDomainAxisEdge((-16646144));
//     double var34 = var3.getCategoryMiddle(4, 5, var19, var33);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject((java.lang.Comparable)"RectangleInsets[t=1.0,l=0.05,b=0.05,r=100.0]", (java.lang.Comparable)(-100.0d));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Paint var6 = null;
    var2.setSeriesPaint(0, var6, true);
    boolean var11 = var2.getItemLineVisible(100, (-16646144));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getColumnCount();
    int var2 = var0.getColumnCount();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject((java.lang.Comparable)(-1.0f), (java.lang.Comparable)(byte)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     java.awt.Paint var1 = null;
//     java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
//     java.awt.Paint var3 = null;
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape var9 = null;
//     java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var4, var6, var8, var10);
//     java.awt.Paint[] var12 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.LegendItemCollection var13 = new org.jfree.chart.LegendItemCollection();
//     java.awt.Paint var14 = null;
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Stroke var18 = null;
//     java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Shape var22 = null;
//     java.awt.Shape[] var23 = new java.awt.Shape[] { var22};
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var15, var17, var19, var21, var23);
//     boolean var25 = var13.equals((java.lang.Object)var19);
//     org.jfree.chart.LegendItemCollection var26 = new org.jfree.chart.LegendItemCollection();
//     java.awt.Paint var27 = null;
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     java.awt.Paint var29 = null;
//     java.awt.Paint[] var30 = new java.awt.Paint[] { var29};
//     java.awt.Stroke var31 = null;
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     java.awt.Stroke var33 = null;
//     java.awt.Stroke[] var34 = new java.awt.Stroke[] { var33};
//     java.awt.Shape var35 = null;
//     java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var28, var30, var32, var34, var36);
//     boolean var38 = var26.equals((java.lang.Object)var32);
//     java.awt.Paint var39 = null;
//     java.awt.Paint[] var40 = new java.awt.Paint[] { var39};
//     java.awt.Paint var41 = null;
//     java.awt.Paint[] var42 = new java.awt.Paint[] { var41};
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Shape var47 = null;
//     java.awt.Shape[] var48 = new java.awt.Shape[] { var47};
//     org.jfree.chart.plot.DefaultDrawingSupplier var49 = new org.jfree.chart.plot.DefaultDrawingSupplier(var40, var42, var44, var46, var48);
//     org.jfree.chart.plot.DefaultDrawingSupplier var50 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var2, var12, var19, var32, var48);
//     
//     // Checks the contract:  equals-hashcode on var11 and var24
//     assertTrue("Contract failed: equals-hashcode on var11 and var24", var11.equals(var24) ? var11.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var37
//     assertTrue("Contract failed: equals-hashcode on var11 and var37", var11.equals(var37) ? var11.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var49
//     assertTrue("Contract failed: equals-hashcode on var11 and var49", var11.equals(var49) ? var11.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var11
//     assertTrue("Contract failed: equals-hashcode on var24 and var11", var24.equals(var11) ? var24.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var37
//     assertTrue("Contract failed: equals-hashcode on var24 and var37", var24.equals(var37) ? var24.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var49
//     assertTrue("Contract failed: equals-hashcode on var24 and var49", var24.equals(var49) ? var24.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var11
//     assertTrue("Contract failed: equals-hashcode on var37 and var11", var37.equals(var11) ? var37.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var24
//     assertTrue("Contract failed: equals-hashcode on var37 and var24", var37.equals(var24) ? var37.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var49
//     assertTrue("Contract failed: equals-hashcode on var37 and var49", var37.equals(var49) ? var37.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var11
//     assertTrue("Contract failed: equals-hashcode on var49 and var11", var49.equals(var11) ? var49.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var24
//     assertTrue("Contract failed: equals-hashcode on var49 and var24", var49.equals(var24) ? var49.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var37
//     assertTrue("Contract failed: equals-hashcode on var49 and var37", var49.equals(var37) ? var49.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var26
//     assertTrue("Contract failed: equals-hashcode on var13 and var26", var13.equals(var26) ? var13.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var13
//     assertTrue("Contract failed: equals-hashcode on var26 and var13", var26.equals(var13) ? var26.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var1 = null;
    var0.setValue(var1, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var0.setValue(110.05d, (java.lang.Comparable)'#', (java.lang.Comparable)"DatasetRenderingOrder.REVERSE");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.incrementValue(4.0d, (java.lang.Comparable)4.0d, (java.lang.Comparable)10.0f);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     float var2 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.util.ShadowGenerator var4 = var0.getShadowGenerator();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var6.setLabelURL("");
//     boolean var9 = var6.isMinorTickMarksVisible();
//     int var10 = var0.getDomainAxisIndex(var6);
//     var6.clearCategoryLabelToolTips();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var13 = var12.getRangeCrosshairPaint();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var16 = var15.getRangeCrosshairPaint();
//     float var17 = var15.getBackgroundImageAlpha();
//     var15.clearDomainMarkers();
//     var15.setNoDataMessage("hi!");
//     org.jfree.chart.axis.CategoryAnchor var21 = var15.getDomainGridlinePosition();
//     java.lang.Object var22 = null;
//     boolean var23 = var21.equals(var22);
//     var12.setDomainGridlinePosition(var21);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var29 = null;
//     var28.setFixedRangeAxisSpace(var29);
//     org.jfree.chart.util.RectangleEdge var31 = var28.getDomainAxisEdge();
//     double var32 = var6.getCategoryJava2DCoordinate(var21, 5, 255, var27, var31);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    boolean var5 = var1.removeDomainMarker(1, var3, var4);
    var1.setRangeCrosshairValue(100.0d);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var1.getRangeMarkers(var8);
    java.awt.Stroke var10 = var1.getRangeCrosshairStroke();
    boolean var11 = var0.equals((java.lang.Object)var10);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var14 = var0.getObject((java.lang.Comparable)5);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     java.lang.Comparable var3 = var0.getDomainCrosshairColumnKey();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var7.getSeriesURLGenerator(1);
//     java.awt.Shape var13 = var7.getItemShape(0, (-1), false);
//     java.awt.Paint var17 = var7.getItemOutlinePaint(10, 0, false);
//     var0.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer)var7, false);
//     var7.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.category.AbstractCategoryDataset var23 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var25 = var23.hasListener((java.util.EventListener)var24);
//     org.jfree.chart.plot.Marker var27 = null;
//     org.jfree.chart.util.Layer var28 = null;
//     boolean var29 = var24.removeDomainMarker(0, var27, var28);
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     java.awt.geom.Point2D var32 = null;
//     var24.zoomDomainAxes(100.0d, var31, var32, false);
//     boolean var35 = var24.isDomainPannable();
//     var7.setPlot(var24);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var0.", var24.equals(var0) == var0.equals(var24));
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator(1);
//     int var6 = var3.getPassCount();
//     var3.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = null;
//     var3.setBaseItemLabelGenerator(var10, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var18 = var16.getLegendTextFont(10);
//     java.awt.Paint var22 = var16.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var22);
//     java.awt.Stroke var24 = var23.getLineStroke();
//     var23.setSeriesIndex((-1));
//     var23.setToolTipText("");
//     java.lang.Comparable var29 = var23.getSeriesKey();
//     java.awt.Shape var30 = var23.getShape();
//     java.awt.Color var34 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var35 = null;
//     java.awt.Rectangle var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
//     java.awt.color.ColorSpace var41 = var34.getColorSpace();
//     java.awt.Color var42 = var34.brighter();
//     var23.setLinePaint((java.awt.Paint)var34);
//     var3.setBaseItemLabelPaint((java.awt.Paint)var34, false);
//     float[] var49 = new float[] { 100.0f, 0.0f, 10.0f};
//     float[] var50 = var34.getColorComponents(var49);
//     int var51 = var34.getTransparency();
//     var0.setDefaultLabelPaint((java.awt.Paint)var34);
//     java.awt.Paint var53 = var0.getDefaultPaint();
//     java.lang.Boolean var54 = var0.getDefaultCreateEntity();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var60 = null;
//     var58.setSeriesFillPaint(10, var60);
//     int var62 = var58.getPassCount();
//     var58.setAutoPopulateSeriesShape(true);
//     java.awt.Paint var65 = var58.getBaseItemLabelPaint();
//     var0.setSeriesLabelPaint((-1), var65);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    float var2 = var0.getBackgroundImageAlpha();
    java.lang.String var3 = var0.getNoDataMessage();
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisSpace var7 = null;
    var0.setFixedDomainAxisSpace(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var11 = null;
    var10.setFixedRangeAxisSpace(var11);
    boolean var13 = var10.isRangeGridlinesVisible();
    var10.setRangeCrosshairValue(0.0d, true);
    boolean var17 = var10.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var10.zoomDomainAxes(100.0d, var19, var20, false);
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var24 = null;
    java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
    java.awt.Paint var26 = null;
    java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
    java.awt.Stroke var28 = null;
    java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
    java.awt.Stroke var30 = null;
    java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
    java.awt.Shape var32 = null;
    java.awt.Shape[] var33 = new java.awt.Shape[] { var32};
    org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier(var25, var27, var29, var31, var33);
    boolean var35 = var23.equals((java.lang.Object)var33);
    java.awt.Stroke var36 = var23.getNextOutlineStroke();
    var10.setOutlineStroke(var36);
    var2.setSeriesStroke(2, var36);
    java.awt.Font var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseItemLabelFont(var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     int var5 = var2.getPassCount();
//     var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var2.setAutoPopulateSeriesOutlineStroke(true);
//     java.awt.Paint var11 = var2.getBasePaint();
//     var2.setBaseShapesFilled(true);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var15.setFixedRangeAxisSpace(var16);
//     java.lang.Comparable var18 = var15.getDomainCrosshairColumnKey();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var24 = var22.getSeriesURLGenerator(1);
//     java.awt.Shape var28 = var22.getItemShape(0, (-1), false);
//     java.awt.Paint var32 = var22.getItemOutlinePaint(10, 0, false);
//     var15.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22, false);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var37 = null;
//     org.jfree.chart.util.Layer var38 = null;
//     boolean var39 = var35.removeDomainMarker(1, var37, var38);
//     org.jfree.chart.axis.AxisLocation var41 = var35.getDomainAxisLocation(100);
//     org.jfree.chart.axis.AxisLocation var42 = org.jfree.chart.axis.AxisLocation.getOpposite(var41);
//     var15.setDomainAxisLocation(var41, false);
//     java.awt.Stroke var45 = var15.getRangeGridlineStroke();
//     java.awt.geom.Rectangle2D var46 = null;
//     var2.drawOutline(var14, var15, var46);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1.0f);
    org.jfree.chart.JFreeChart var2 = null;
    var1.setChart(var2);
    java.lang.Object var4 = var1.getSource();
    java.lang.String var5 = var1.toString();
    java.lang.Object var6 = var1.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0f+ "'", var4.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=1.0]"+ "'", var5.equals("org.jfree.chart.event.ChartChangeEvent[source=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0f+ "'", var6.equals(1.0f));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getRowKey((-16646144));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getLabelAngle();
    var1.setMinorTickMarkInsideLength(10.0f);
    var1.setAxisLineVisible(false);
    var1.setLabelURL("rect");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
    var0.mapDatasetToRangeAxis(10, 0);
    java.lang.Comparable var9 = var0.getDomainCrosshairColumnKey();
    boolean var10 = var0.isRangeCrosshairLockedOnData();
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePaint(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.CategoryMarker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addDomainMarker(5, var8, var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var3 = var2.clone();
    var2.clear();
    int var5 = var2.getColumnCount();
    var0.addObject((java.lang.Comparable)10.0f, (java.lang.Object)var5);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var10 = var9.getRangeCrosshairPaint();
    java.awt.Font var11 = var9.getNoDataMessageFont();
    var9.setDomainGridlinesVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var9.zoomDomainAxes(0.05d, var15, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue(100, (java.lang.Comparable)0, (java.lang.Object)0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     boolean var6 = var1.removeDomainMarker(0, var4, var5);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     var1.zoomDomainAxes(100.0d, var8, var9, false);
//     var1.setCrosshairDatasetIndex(3);
//     org.jfree.chart.plot.Plot var14 = var1.getParent();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var16 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var15.zoomDomainAxes(100.0d, var18, var19, true);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var22};
//     var15.setRangeAxes(var23);
//     var1.setRangeAxes(var23);
//     org.jfree.data.category.AbstractCategoryDataset var26 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var28 = var26.hasListener((java.util.EventListener)var27);
//     org.jfree.chart.plot.Marker var30 = null;
//     org.jfree.chart.util.Layer var31 = null;
//     boolean var32 = var27.removeDomainMarker(0, var30, var31);
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     java.awt.geom.Point2D var35 = null;
//     var27.zoomDomainAxes(100.0d, var34, var35, false);
//     var27.setCrosshairDatasetIndex(3);
//     org.jfree.chart.plot.Plot var40 = var27.getParent();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var42 = var41.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Point2D var45 = null;
//     var41.zoomDomainAxes(100.0d, var44, var45, true);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis[] var49 = new org.jfree.chart.axis.ValueAxis[] { var48};
//     var41.setRangeAxes(var49);
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var53 = var52.getLabelAngle();
//     var52.setTickMarksVisible(true);
//     var41.setDomainAxis(var52);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var59 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var61 = var59.getSeriesURLGenerator(1);
//     int var62 = var59.getPassCount();
//     java.lang.Boolean var64 = var59.getSeriesItemLabelsVisible(0);
//     var59.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var67 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var59};
//     var41.setRenderers(var67);
//     var27.setRenderers(var67);
//     var1.setRenderers(var67);
//     
//     // Checks the contract:  equals-hashcode on var1 and var27
//     assertTrue("Contract failed: equals-hashcode on var1 and var27", var1.equals(var27) ? var1.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var1
//     assertTrue("Contract failed: equals-hashcode on var27 and var1", var27.equals(var1) ? var27.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var3 = var0.getItemPaint(1, 100);
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.5f, 0.5f, 0.5f);
//     java.awt.color.ColorSpace var9 = var8.getColorSpace();
//     java.awt.color.ColorSpace var10 = var8.getColorSpace();
//     var0.setSeriesFillPaint(0, (java.awt.Paint)var8);
//     java.awt.Paint var14 = var0.getItemOutlinePaint(15, 0);
//     java.awt.Shape var17 = var0.getItemShape(255, 10);
//     java.lang.Boolean var19 = var0.getSeriesCreateEntity(5);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var1.removeDomainMarker(0, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var1.zoomDomainAxes(100.0d, var8, var9, false);
    var1.setCrosshairDatasetIndex(3);
    var1.setDrawSharedDomainAxis(false);
    var1.setDomainCrosshairRowKey((java.lang.Comparable)(short)0);
    java.awt.geom.GeneralPath var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.RenderingSource var20 = null;
    var1.select(var18, var19, var20);
    org.jfree.chart.LegendItemCollection var22 = var1.getFixedLegendItems();
    var1.setRangeCrosshairValue(4.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var2 = var0.hasListener((java.util.EventListener)var1);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.RenderingSource var6 = null;
//     var1.select(0.05d, (-1.0d), var5, var6);
//     org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
//     org.jfree.chart.plot.DatasetRenderingOrder var9 = var1.getDatasetRenderingOrder();
//     java.lang.Object var10 = var1.clone();
//     java.awt.Paint var11 = var1.getNoDataMessagePaint();
//     org.jfree.chart.plot.Marker var12 = null;
//     org.jfree.chart.util.Layer var13 = null;
//     var1.addRangeMarker(var12, var13);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getFixedDimension();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.data.category.AbstractCategoryDataset var7 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var9 = var7.hasListener((java.util.EventListener)var8);
//     org.jfree.chart.plot.Marker var11 = null;
//     org.jfree.chart.util.Layer var12 = null;
//     boolean var13 = var8.removeDomainMarker(0, var11, var12);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var8.zoomDomainAxes(100.0d, var15, var16, false);
//     var8.setCrosshairDatasetIndex(3);
//     org.jfree.chart.plot.Plot var21 = var8.getParent();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var23 = var22.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     var22.zoomDomainAxes(100.0d, var25, var26, true);
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis[] var30 = new org.jfree.chart.axis.ValueAxis[] { var29};
//     var22.setRangeAxes(var30);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var34 = var33.getLabelAngle();
//     var33.setTickMarksVisible(true);
//     var22.setDomainAxis(var33);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var42 = var40.getSeriesURLGenerator(1);
//     int var43 = var40.getPassCount();
//     java.lang.Boolean var45 = var40.getSeriesItemLabelsVisible(0);
//     var40.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var48 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var40};
//     var22.setRenderers(var48);
//     var8.setRenderers(var48);
//     org.jfree.chart.util.RectangleEdge var51 = var8.getDomainAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     org.jfree.chart.axis.AxisState var53 = var1.draw(var3, 100.0d, var5, var6, var51, var52);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    org.jfree.chart.util.PaintList var3 = new org.jfree.chart.util.PaintList();
    java.lang.Object var4 = var3.clone();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var7 = var6.getLabelAngle();
    boolean var8 = var3.equals((java.lang.Object)var6);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var6.getCategoryEnd((-1), 0, var11, var12);
    var0.setDomainAxis(var6);
    var6.setTickMarksVisible(false);
    var6.setMaximumCategoryLabelWidthRatio(100.0f);
    var6.setMinorTickMarksVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var1 = var0.getRangeCrosshairPaint();
//     float var2 = var0.getBackgroundImageAlpha();
//     var0.clearDomainMarkers();
//     var0.setNoDataMessage("hi!");
//     org.jfree.chart.axis.CategoryAnchor var6 = var0.getDomainGridlinePosition();
//     java.lang.String var7 = var0.getPlotType();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var0.handleClick(255, 0, var10);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var2.setBaseItemLabelGenerator(var5);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var12 = null;
//     var10.setSeriesFillPaint(10, var12);
//     int var14 = var10.getPassCount();
//     int var15 = var10.getPassCount();
//     var10.setDataBoundsIncludesVisibleSeriesOnly(true);
//     java.awt.Paint var19 = var10.getLegendTextPaint((-1));
//     org.jfree.chart.urls.CategoryURLGenerator var20 = null;
//     var10.setBaseURLGenerator(var20, true);
//     java.awt.Paint var26 = var10.getItemOutlinePaint(128, 3, false);
//     var2.setSeriesPaint(1, var26);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     boolean var3 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.0d, true);
//     boolean var7 = var0.isRangeMinorGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     var0.zoomDomainAxes(100.0d, var9, var10, false);
//     var0.configureDomainAxes();
//     org.jfree.chart.plot.Marker var15 = null;
//     org.jfree.chart.util.Layer var16 = null;
//     var0.addRangeMarker(1, var15, var16, false);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var3 = var0.getItemPaint(1, 100);
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.5f, 0.5f, 0.5f);
//     java.awt.color.ColorSpace var9 = var8.getColorSpace();
//     java.awt.color.ColorSpace var10 = var8.getColorSpace();
//     var0.setSeriesFillPaint(0, (java.awt.Paint)var8);
//     java.awt.Paint var14 = var0.getItemOutlinePaint(15, 0);
//     java.awt.Shape var17 = var0.getItemShape(255, 10);
//     java.lang.Boolean var19 = var0.getSeriesLabelVisible(1);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke var6 = null;
    java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
    java.awt.Shape var8 = null;
    java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9);
    boolean var12 = var10.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var17 = null;
    var15.setSeriesFillPaint(10, var17);
    int var19 = var15.getPassCount();
    java.awt.Font var21 = var15.lookupLegendTextFont(0);
    java.awt.Shape var23 = var15.lookupSeriesShape(10);
    boolean var24 = var10.equals((java.lang.Object)var23);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var27 = null;
    org.jfree.chart.util.Layer var28 = null;
    boolean var29 = var25.removeDomainMarker(1, var27, var28);
    org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
    org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var25, "hi!");
    java.awt.Shape var34 = var33.getArea();
    java.lang.String var35 = var33.getShapeCoords();
    org.jfree.data.category.AbstractCategoryDataset var36 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    boolean var38 = var36.hasListener((java.util.EventListener)var37);
    org.jfree.chart.plot.Marker var40 = null;
    org.jfree.chart.util.Layer var41 = null;
    boolean var42 = var37.removeDomainMarker(0, var40, var41);
    org.jfree.chart.plot.PlotRenderingInfo var44 = null;
    java.awt.geom.Point2D var45 = null;
    var37.zoomDomainAxes(100.0d, var44, var45, false);
    var37.setCrosshairDatasetIndex(3);
    var37.setDrawSharedDomainAxis(false);
    var37.setDomainCrosshairRowKey((java.lang.Comparable)(short)0);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var55 = var54.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var57 = null;
    java.awt.geom.Point2D var58 = null;
    var54.zoomDomainAxes(100.0d, var57, var58, true);
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.axis.ValueAxis[] var62 = new org.jfree.chart.axis.ValueAxis[] { var61};
    var54.setRangeAxes(var62);
    org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var66 = var65.getLabelAngle();
    var65.setTickMarksVisible(true);
    var54.setDomainAxis(var65);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var72 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var74 = var72.getSeriesURLGenerator(1);
    int var75 = var72.getPassCount();
    java.lang.Boolean var77 = var72.getSeriesItemLabelsVisible(0);
    var72.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var80 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var72};
    var54.setRenderers(var80);
    var37.setRenderers(var80);
    boolean var83 = var33.equals((java.lang.Object)var37);
    java.lang.String var84 = var33.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "-3,-3,3,3"+ "'", var35.equals("-3,-3,3,3"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var84 + "' != '" + "PlotEntity: tooltip = hi!"+ "'", var84.equals("PlotEntity: tooltip = hi!"));

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var1 = null;
//     var0.setFixedRangeAxisSpace(var1);
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.Marker var4 = null;
//     boolean var5 = var0.removeDomainMarker(var4);
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = var0.getRenderer();
//     var0.clearDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.handleClick((-16646144), 5, var11);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var9 = var1.getDatasetRenderingOrder();
    java.lang.Object var10 = var1.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var16 = var14.getLegendTextFont(10);
    java.awt.Paint var20 = var14.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", var20);
    java.awt.Stroke var22 = var21.getLineStroke();
    var21.setSeriesIndex((-1));
    var21.setToolTipText("");
    java.lang.Comparable var27 = var21.getSeriesKey();
    java.awt.Shape var28 = var21.getShape();
    java.awt.Paint var29 = var21.getOutlinePaint();
    var1.setRangeZeroBaselinePaint(var29);
    org.jfree.data.category.DefaultCategoryDataset var31 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var32 = null;
    var31.setValue(var32, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var31.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    var1.setDataset((org.jfree.data.category.CategoryDataset)var31);
    var31.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator(1);
//     int var6 = var3.getPassCount();
//     var3.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = null;
//     var3.setBaseItemLabelGenerator(var10, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var18 = var16.getLegendTextFont(10);
//     java.awt.Paint var22 = var16.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var22);
//     java.awt.Stroke var24 = var23.getLineStroke();
//     var23.setSeriesIndex((-1));
//     var23.setToolTipText("");
//     java.lang.Comparable var29 = var23.getSeriesKey();
//     java.awt.Shape var30 = var23.getShape();
//     java.awt.Color var34 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var35 = null;
//     java.awt.Rectangle var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
//     java.awt.color.ColorSpace var41 = var34.getColorSpace();
//     java.awt.Color var42 = var34.brighter();
//     var23.setLinePaint((java.awt.Paint)var34);
//     var3.setBaseItemLabelPaint((java.awt.Paint)var34, false);
//     float[] var49 = new float[] { 100.0f, 0.0f, 10.0f};
//     float[] var50 = var34.getColorComponents(var49);
//     int var51 = var34.getTransparency();
//     var0.setDefaultLabelPaint((java.awt.Paint)var34);
//     java.awt.Paint var53 = var0.getDefaultPaint();
//     java.awt.Stroke var55 = var0.getSeriesOutlineStroke(0);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     boolean var8 = var2.isSeriesVisible(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.Marker var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var2.drawRangeMarker(var10, var11, var12, var13, var14);
//     org.jfree.chart.LegendItemCollection var16 = new org.jfree.chart.LegendItemCollection();
//     var11.setFixedLegendItems(var16);
//     java.util.Iterator var18 = var16.iterator();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var24 = var22.getLegendTextFont(10);
//     java.awt.Paint var28 = var22.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", var28);
//     java.awt.Stroke var30 = var29.getLineStroke();
//     java.awt.Paint var31 = var29.getLabelPaint();
//     java.awt.Stroke var32 = var29.getOutlineStroke();
//     var29.setDatasetIndex(0);
//     java.awt.Stroke var35 = var29.getOutlineStroke();
//     var16.add(var29);
//     
//     // Checks the contract:  equals-hashcode on var2 and var22
//     assertTrue("Contract failed: equals-hashcode on var2 and var22", var2.equals(var22) ? var2.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var2
//     assertTrue("Contract failed: equals-hashcode on var22 and var2", var22.equals(var2) ? var22.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    boolean var2 = var0.hasListener((java.util.EventListener)var1);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(0.05d, (-1.0d), var5, var6);
    org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var9 = var1.getDatasetRenderingOrder();
    java.lang.Object var10 = var1.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var16 = var14.getLegendTextFont(10);
    java.awt.Paint var20 = var14.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", var20);
    java.awt.Stroke var22 = var21.getLineStroke();
    var21.setSeriesIndex((-1));
    var21.setToolTipText("");
    java.lang.Comparable var27 = var21.getSeriesKey();
    java.awt.Shape var28 = var21.getShape();
    java.awt.Paint var29 = var21.getOutlinePaint();
    var1.setRangeZeroBaselinePaint(var29);
    org.jfree.data.category.DefaultCategoryDataset var31 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Number var32 = null;
    var31.setValue(var32, (java.lang.Comparable)(byte)0, (java.lang.Comparable)100.05d);
    var31.addValue(0.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)"-3,-3,3,3");
    var1.setDataset((org.jfree.data.category.CategoryDataset)var31);
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var42 = null;
    var41.setFixedRangeAxisSpace(var42);
    java.lang.Comparable var44 = var41.getDomainCrosshairColumnKey();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var50 = var48.getSeriesURLGenerator(1);
    java.awt.Shape var54 = var48.getItemShape(0, (-1), false);
    java.awt.Paint var58 = var48.getItemOutlinePaint(10, 0, false);
    var41.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer)var48, false);
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var63 = null;
    org.jfree.chart.util.Layer var64 = null;
    boolean var65 = var61.removeDomainMarker(1, var63, var64);
    org.jfree.chart.axis.AxisLocation var67 = var61.getDomainAxisLocation(100);
    org.jfree.chart.axis.AxisLocation var68 = org.jfree.chart.axis.AxisLocation.getOpposite(var67);
    var41.setDomainAxisLocation(var67, false);
    var1.setRangeAxisLocation(var67, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(100.0d, var3, var4, true);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var0.setRangeAxes(var8);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var12 = var11.getLabelAngle();
    var11.setTickMarksVisible(true);
    var0.setDomainAxis(var11);
    var0.clearDomainAxes();
    org.jfree.chart.event.MarkerChangeEvent var17 = null;
    var0.markerChanged(var17);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var0.panDomainAxes(10.0d, var20, var21);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var24 = null;
    var23.setFixedRangeAxisSpace(var24);
    org.jfree.chart.util.PaintList var26 = new org.jfree.chart.util.PaintList();
    java.lang.Object var27 = var26.clone();
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var30 = var29.getLabelAngle();
    boolean var31 = var26.equals((java.lang.Object)var29);
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.util.RectangleEdge var35 = null;
    double var36 = var29.getCategoryEnd((-1), 0, var34, var35);
    var23.setDomainAxis(var29);
    var29.setTickMarksVisible(false);
    var29.setMaximumCategoryLabelWidthRatio(100.0f);
    org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets(0.05d, 10.0d, 0.0d, 0.05d);
    double var48 = var46.calculateTopOutset(100.0d);
    var29.setLabelInsets(var46, false);
    var0.setAxisOffset(var46);
    java.awt.geom.Rectangle2D var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var55 = var46.createOutsetRectangle(var52, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.05d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(1.0d, 0.05d, 0.05d, 100.0d);
    double var5 = var4.getTop();
    org.jfree.chart.util.UnitType var6 = var4.getUnitType();
    double var7 = var4.getTop();
    java.lang.String var8 = var4.toString();
    java.awt.geom.Rectangle2D var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var12 = var4.createOutsetRectangle(var9, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleInsets[t=1.0,l=0.05,b=0.05,r=100.0]"+ "'", var8.equals("RectangleInsets[t=1.0,l=0.05,b=0.05,r=100.0]"));

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.util.SortOrder var5 = var0.getColumnRenderingOrder();
    var0.mapDatasetToRangeAxis(10, 0);
    java.lang.Comparable var9 = var0.getDomainCrosshairColumnKey();
    boolean var10 = var0.isRangeCrosshairLockedOnData();
    boolean var11 = var0.isDomainPannable();
    var0.setCrosshairDatasetIndex(100, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
//     java.awt.Shape var8 = var2.getItemShape(0, (-1), false);
//     var2.setAutoPopulateSeriesOutlineStroke(true);
//     java.lang.Boolean var12 = var2.getSeriesShapesFilled(1);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var2.getPositiveItemLabelPosition(1, 0, false);
//     int var17 = var2.getRowCount();
//     java.awt.Shape var19 = var2.lookupSeriesShape(3);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var21 = null;
//     var20.setFixedRangeAxisSpace(var21);
//     boolean var23 = var20.isRangeGridlinesVisible();
//     var20.setRangeCrosshairValue(0.0d, true);
//     boolean var27 = var20.isRangeMinorGridlinesVisible();
//     var20.configureRangeAxes();
//     org.jfree.chart.util.PaintList var30 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var31 = var30.clone();
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var34 = var33.getLabelAngle();
//     boolean var35 = var30.equals((java.lang.Object)var33);
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var33.getCategoryEnd((-1), 0, var38, var39);
//     java.lang.String var41 = var33.getLabelToolTip();
//     var33.setFixedDimension(1.0d);
//     var20.setDomainAxis(128, var33);
//     org.jfree.chart.axis.CategoryAxis var46 = var20.getDomainAxisForDataset(3);
//     org.jfree.chart.entity.PlotEntity var48 = new org.jfree.chart.entity.PlotEntity(var19, (org.jfree.chart.plot.Plot)var20, "");
//     org.jfree.chart.plot.DefaultDrawingSupplier var49 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.lang.Object var50 = var49.clone();
//     var20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var49);
//     
//     // Checks the contract:  equals-hashcode on var31 and var50
//     assertTrue("Contract failed: equals-hashcode on var31 and var50", var31.equals(var50) ? var31.hashCode() == var50.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var50.", var31.equals(var50) == var50.equals(var31));
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d, true);
    boolean var7 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    java.awt.geom.Point2D var10 = null;
    var0.zoomDomainAxes(100.0d, var9, var10, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var17 = var15.getSeriesURLGenerator(1);
    java.awt.Shape var21 = var15.getItemShape(0, (-1), false);
    var15.setAutoPopulateSeriesOutlineStroke(true);
    int var24 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    java.awt.Font var26 = var15.lookupLegendTextFont(2);
    org.jfree.chart.labels.CategoryToolTipGenerator var27 = null;
    var15.setBaseToolTipGenerator(var27, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    java.awt.Paint var6 = null;
    var2.setSeriesPaint(0, var6, true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemToolTipGenerator();
    java.awt.Font var11 = var2.getLegendTextFont(128);
    java.awt.Font var12 = var2.getBaseItemLabelFont();
    boolean var13 = var2.getBaseItemLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
//     org.jfree.chart.renderer.RenderAttributes var2 = new org.jfree.chart.renderer.RenderAttributes();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = var5.getSeriesURLGenerator(1);
//     int var8 = var5.getPassCount();
//     var5.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
//     var5.setBaseItemLabelGenerator(var12, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var20 = var18.getLegendTextFont(10);
//     java.awt.Paint var24 = var18.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", var24);
//     java.awt.Stroke var26 = var25.getLineStroke();
//     var25.setSeriesIndex((-1));
//     var25.setToolTipText("");
//     java.lang.Comparable var31 = var25.getSeriesKey();
//     java.awt.Shape var32 = var25.getShape();
//     java.awt.Color var36 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var37 = null;
//     java.awt.Rectangle var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     java.awt.geom.AffineTransform var40 = null;
//     java.awt.RenderingHints var41 = null;
//     java.awt.PaintContext var42 = var36.createContext(var37, var38, var39, var40, var41);
//     java.awt.color.ColorSpace var43 = var36.getColorSpace();
//     java.awt.Color var44 = var36.brighter();
//     var25.setLinePaint((java.awt.Paint)var36);
//     var5.setBaseItemLabelPaint((java.awt.Paint)var36, false);
//     float[] var51 = new float[] { 100.0f, 0.0f, 10.0f};
//     float[] var52 = var36.getColorComponents(var51);
//     int var53 = var36.getTransparency();
//     var2.setDefaultLabelPaint((java.awt.Paint)var36);
//     boolean var55 = var0.equals((java.lang.Object)var2);
//     org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var59 = var58.getLabelAngle();
//     var58.setTickMarksVisible(true);
//     double var62 = var58.getFixedDimension();
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var64 = null;
//     var63.setFixedRangeAxisSpace(var64);
//     boolean var66 = var63.isRangeGridlinesVisible();
//     var63.setRangeCrosshairValue(0.0d, true);
//     boolean var70 = var63.isRangeMinorGridlinesVisible();
//     boolean var71 = var58.hasListener((java.util.EventListener)var63);
//     java.awt.Paint var72 = var58.getLabelPaint();
//     org.jfree.chart.util.PaintList var73 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var74 = var73.clone();
//     org.jfree.chart.axis.CategoryAxis var76 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var77 = var76.getLabelAngle();
//     boolean var78 = var73.equals((java.lang.Object)var76);
//     java.awt.Font var80 = var76.getTickLabelFont((java.lang.Comparable)(byte)0);
//     var58.setLabelFont(var80);
//     var2.setSeriesLabelFont(10, var80);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getColumnKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    int var5 = var2.getPassCount();
    var2.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Paint var11 = var2.getBasePaint();
    var2.setBaseShapesFilled(true);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var2.setBaseURLGenerator(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.Marker var4 = null;
    boolean var5 = var0.removeDomainMarker(var4);
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = var0.getRenderer();
    var0.clearDomainAxes();
    org.jfree.chart.plot.Marker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var13 = var0.removeRangeMarker((-10), var10, var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     float var1 = var0.getShadowOpacity();
//     java.awt.image.BufferedImage var2 = null;
//     java.awt.image.BufferedImage var3 = var0.createDropShadow(var2);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var5 = var3.getLegendTextFont(10);
//     java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
//     java.awt.Stroke var11 = var10.getLineStroke();
//     var10.setSeriesIndex((-1));
//     var10.setToolTipText("");
//     java.awt.Paint var16 = var10.getFillPaint();
//     var10.setSeriesIndex((-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var23 = null;
//     var21.setSeriesFillPaint(10, var23);
//     java.awt.Paint var26 = null;
//     var21.setSeriesOutlinePaint(3, var26);
//     java.awt.Stroke var31 = var21.getItemStroke(100, 1, true);
//     var10.setOutlineStroke(var31);
//     
//     // Checks the contract:  equals-hashcode on var3 and var21
//     assertTrue("Contract failed: equals-hashcode on var3 and var21", var3.equals(var21) ? var3.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var3
//     assertTrue("Contract failed: equals-hashcode on var21 and var3", var21.equals(var3) ? var21.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesFillPaint(10, var4);
//     int var6 = var2.getPassCount();
//     boolean var8 = var2.isSeriesVisible(1);
//     java.awt.Paint var10 = null;
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
//     java.awt.Paint var12 = null;
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     java.awt.Stroke var14 = null;
//     java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
//     java.awt.Stroke var16 = null;
//     java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
//     java.awt.Shape var18 = null;
//     java.awt.Shape[] var19 = new java.awt.Shape[] { var18};
//     org.jfree.chart.plot.DefaultDrawingSupplier var20 = new org.jfree.chart.plot.DefaultDrawingSupplier(var11, var13, var15, var17, var19);
//     boolean var22 = var20.equals((java.lang.Object)'#');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var27 = null;
//     var25.setSeriesFillPaint(10, var27);
//     int var29 = var25.getPassCount();
//     java.awt.Font var31 = var25.lookupLegendTextFont(0);
//     java.awt.Shape var33 = var25.lookupSeriesShape(10);
//     boolean var34 = var20.equals((java.lang.Object)var33);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.Marker var37 = null;
//     org.jfree.chart.util.Layer var38 = null;
//     boolean var39 = var35.removeDomainMarker(1, var37, var38);
//     org.jfree.chart.axis.AxisLocation var41 = var35.getDomainAxisLocation(100);
//     org.jfree.chart.entity.PlotEntity var43 = new org.jfree.chart.entity.PlotEntity(var33, (org.jfree.chart.plot.Plot)var35, "hi!");
//     boolean var44 = var35.isDomainGridlinesVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Paint var49 = null;
//     var47.setSeriesFillPaint(10, var49);
//     int var51 = var47.getPassCount();
//     boolean var53 = var47.isSeriesVisible(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var54 = var47.getLegendItemURLGenerator();
//     org.jfree.chart.event.RendererChangeEvent var55 = null;
//     var47.notifyListeners(var55);
//     java.awt.Stroke var58 = var47.lookupSeriesStroke(4);
//     var35.setDomainGridlineStroke(var58);
//     var2.setSeriesOutlineStroke(255, var58);
//     
//     // Checks the contract:  equals-hashcode on var25 and var2
//     assertTrue("Contract failed: equals-hashcode on var25 and var2", var25.equals(var2) ? var25.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var2
//     assertTrue("Contract failed: equals-hashcode on var47 and var2", var47.equals(var2) ? var47.hashCode() == var2.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var25 and var2.", var25.equals(var2) == var2.equals(var25));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var47 and var2.", var47.equals(var2) == var2.equals(var47));
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    java.lang.Comparable var3 = var0.getDomainCrosshairColumnKey();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = var7.getSeriesURLGenerator(1);
    java.awt.Shape var13 = var7.getItemShape(0, (-1), false);
    java.awt.Paint var17 = var7.getItemOutlinePaint(10, 0, false);
    var0.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer)var7, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var24 = var22.getSeriesURLGenerator(1);
    int var25 = var22.getPassCount();
    int var26 = var22.getDefaultEntityRadius();
    java.awt.Stroke var27 = var22.getBaseOutlineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var32 = var30.getSeriesURLGenerator(1);
    java.awt.Shape var36 = var30.getItemShape(0, (-1), false);
    var30.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var40 = var30.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var44 = var30.getPositiveItemLabelPosition(1, 0, false);
    var22.setBasePositiveItemLabelPosition(var44);
    var7.setBaseNegativeItemLabelPosition(var44);
    double var47 = var7.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var5 = var3.getLegendTextFont(10);
    java.awt.Paint var9 = var3.getItemPaint(10, 100, true);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", var9);
    java.awt.Stroke var11 = var10.getLineStroke();
    var10.setSeriesIndex((-1));
    var10.setToolTipText("");
    java.lang.Comparable var16 = var10.getSeriesKey();
    java.awt.Shape var17 = var10.getShape();
    boolean var18 = var10.isShapeFilled();
    java.lang.Object var19 = var10.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject((java.lang.Comparable)100.0f, (java.lang.Object)'4');
    java.lang.Object var3 = var2.getObject();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + '4'+ "'", var3.equals('4'));

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator(1);
    var2.setUseOutlinePaint(false);
    boolean var9 = var2.getItemShapeVisible(0, (-1));
    java.awt.Font var11 = var2.getSeriesItemLabelFont(1);
    var2.setBaseSeriesVisibleInLegend(false, false);
    java.awt.Paint var15 = var2.getBaseOutlinePaint();
    java.awt.Stroke var17 = var2.getSeriesStroke(3);
    java.awt.Paint var19 = null;
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    java.awt.Paint var21 = null;
    java.awt.Paint[] var22 = new java.awt.Paint[] { var21};
    java.awt.Stroke var23 = null;
    java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Shape var27 = null;
    java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var22, var24, var26, var28);
    boolean var31 = var29.equals((java.lang.Object)'#');
    org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var36 = null;
    var34.setSeriesFillPaint(10, var36);
    int var38 = var34.getPassCount();
    java.awt.Font var40 = var34.lookupLegendTextFont(0);
    java.awt.Shape var42 = var34.lookupSeriesShape(10);
    boolean var43 = var29.equals((java.lang.Object)var42);
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.Marker var46 = null;
    org.jfree.chart.util.Layer var47 = null;
    boolean var48 = var44.removeDomainMarker(1, var46, var47);
    org.jfree.chart.axis.AxisLocation var50 = var44.getDomainAxisLocation(100);
    org.jfree.chart.entity.PlotEntity var52 = new org.jfree.chart.entity.PlotEntity(var42, (org.jfree.chart.plot.Plot)var44, "hi!");
    java.awt.Shape var53 = var52.getArea();
    var2.setSeriesShape(5, var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var4 = var3.getLabelAngle();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var3.getCategoryEnd((-1), 0, var8, var9);
    java.lang.String var11 = var3.getLabelToolTip();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var13 = null;
    var12.setFixedRangeAxisSpace(var13);
    org.jfree.chart.util.PaintList var15 = new org.jfree.chart.util.PaintList();
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var19 = var18.getLabelAngle();
    boolean var20 = var15.equals((java.lang.Object)var18);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var18.getCategoryEnd((-1), 0, var23, var24);
    var12.setDomainAxis(var18);
    var12.setDrawSharedDomainAxis(true);
    java.awt.Paint var29 = var12.getRangeZeroBaselinePaint();
    boolean var30 = var3.hasListener((java.util.EventListener)var12);
    java.lang.Comparable var31 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var36 = var34.getSeriesURLGenerator(1);
    var34.setUseOutlinePaint(false);
    boolean var41 = var34.getItemShapeVisible(0, (-1));
    java.awt.Font var43 = var34.getSeriesItemLabelFont(1);
    var34.setBaseSeriesVisibleInLegend(false, false);
    boolean var47 = var34.getUseSeriesOffset();
    org.jfree.data.category.AbstractCategoryDataset var49 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    boolean var51 = var49.hasListener((java.util.EventListener)var50);
    java.awt.geom.Rectangle2D var54 = null;
    org.jfree.chart.RenderingSource var55 = null;
    var50.select(0.05d, (-1.0d), var54, var55);
    boolean var57 = var50.isRangeCrosshairVisible();
    java.awt.Font var58 = var50.getNoDataMessageFont();
    var34.setLegendTextFont(0, var58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setTickLabelFont(var31, var58);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Font var4 = var2.getLegendTextFont(10);
    java.awt.Stroke var8 = var2.getItemStroke(0, 1, true);
    java.awt.Paint var10 = null;
    var2.setSeriesFillPaint(10, var10);
    org.jfree.chart.urls.CategoryURLGenerator var12 = null;
    var2.setBaseURLGenerator(var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
    var2.setBaseToolTipGenerator(var15, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    org.jfree.chart.urls.CategoryURLGenerator var23 = var21.getSeriesURLGenerator(1);
    java.awt.Shape var27 = var21.getItemShape(0, (-1), false);
    var21.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var31 = var21.getSeriesShapesFilled(1);
    org.jfree.chart.labels.ItemLabelPosition var35 = var21.getPositiveItemLabelPosition(1, 0, false);
    double var36 = var35.getAngle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesNegativeItemLabelPosition((-2), var35, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator(1);
//     int var6 = var3.getPassCount();
//     var3.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = null;
//     var3.setBaseItemLabelGenerator(var10, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var18 = var16.getLegendTextFont(10);
//     java.awt.Paint var22 = var16.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var22);
//     java.awt.Stroke var24 = var23.getLineStroke();
//     var23.setSeriesIndex((-1));
//     var23.setToolTipText("");
//     java.lang.Comparable var29 = var23.getSeriesKey();
//     java.awt.Shape var30 = var23.getShape();
//     java.awt.Color var34 = java.awt.Color.getHSBColor(10.0f, 10.0f, 100.0f);
//     java.awt.image.ColorModel var35 = null;
//     java.awt.Rectangle var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
//     java.awt.color.ColorSpace var41 = var34.getColorSpace();
//     java.awt.Color var42 = var34.brighter();
//     var23.setLinePaint((java.awt.Paint)var34);
//     var3.setBaseItemLabelPaint((java.awt.Paint)var34, false);
//     float[] var49 = new float[] { 100.0f, 0.0f, 10.0f};
//     float[] var50 = var34.getColorComponents(var49);
//     int var51 = var34.getTransparency();
//     var0.setDefaultLabelPaint((java.awt.Paint)var34);
//     java.awt.Paint var53 = var0.getDefaultPaint();
//     java.awt.Paint var55 = var0.getSeriesPaint(10);
//     var0.setDefaultLabelVisible((java.lang.Boolean)true);
//     java.awt.Paint var58 = var0.getDefaultOutlinePaint();
//     java.lang.Boolean var61 = var0.getCreateEntity(255, 0);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var1 = var0.getShadowsVisible();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getNegativeItemLabelPositionFallback();
//     boolean var3 = var0.isDrawBarOutline();
//     org.jfree.chart.LegendItem var6 = var0.getLegendItem(100, 255);
//     double var7 = var0.getBase();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var10 = var9.getRangeCrosshairPaint();
//     float var11 = var9.getBackgroundImageAlpha();
//     var9.clearDomainMarkers();
//     var9.setNoDataMessage("hi!");
//     org.jfree.chart.axis.CategoryAnchor var15 = var9.getDomainGridlinePosition();
//     org.jfree.chart.util.PaintList var16 = new org.jfree.chart.util.PaintList();
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var20 = var19.getLabelAngle();
//     boolean var21 = var16.equals((java.lang.Object)var19);
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var19.getCategoryEnd((-1), 0, var24, var25);
//     var19.setAxisLineVisible(true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Font var35 = var33.getLegendTextFont(10);
//     java.awt.Paint var39 = var33.getItemPaint(10, 100, true);
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("", var39);
//     java.awt.Stroke var41 = var40.getLineStroke();
//     var40.setSeriesIndex((-1));
//     var40.setToolTipText("");
//     java.lang.Comparable var46 = var40.getSeriesKey();
//     java.awt.Shape var47 = var40.getShape();
//     java.awt.Paint var48 = var40.getOutlinePaint();
//     var19.setTickLabelPaint((java.lang.Comparable)(short)0, var48);
//     org.jfree.chart.plot.CategoryMarker var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     var0.drawDomainMarker(var8, var9, var19, var50, var51);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedRangeAxisSpace(var1);
    boolean var3 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d, true);
    boolean var7 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    java.awt.geom.Point2D var10 = null;
    var0.zoomDomainAxes(100.0d, var9, var10, false);
    org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var14 = null;
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Paint var16 = null;
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Stroke var18 = null;
    java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
    java.awt.Stroke var20 = null;
    java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
    java.awt.Shape var22 = null;
    java.awt.Shape[] var23 = new java.awt.Shape[] { var22};
    org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var15, var17, var19, var21, var23);
    boolean var25 = var13.equals((java.lang.Object)var23);
    java.awt.Stroke var26 = var13.getNextOutlineStroke();
    var0.setOutlineStroke(var26);
    org.jfree.chart.axis.ValueAxis var29 = var0.getRangeAxis(3);
    double var30 = var0.getAnchorValue();
    java.awt.Paint var31 = var0.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Paint var4 = null;
    var2.setSeriesFillPaint(10, var4);
    int var6 = var2.getPassCount();
    boolean var8 = var2.isSeriesVisible(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemURLGenerator();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.Marker var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var2.drawRangeMarker(var10, var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = new org.jfree.chart.LegendItemCollection();
    var11.setFixedLegendItems(var16);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var11.panRangeAxes(99.05d, var19, var20);
    int var22 = var11.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 15);

  }

}
