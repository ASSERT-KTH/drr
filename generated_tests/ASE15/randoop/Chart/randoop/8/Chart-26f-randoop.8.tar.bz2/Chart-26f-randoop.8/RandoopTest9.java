
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var6 = var3.getItemLabelPaint((-1), 100);
    java.awt.Stroke var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(1.0d, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 1.0d, var4, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     double var6 = var2.getItemMargin();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     var2.drawDomainGridline(var7, var8, var9, 1.0d);
// 
//   }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("hi!");
//     var13.setLabel("");
//     org.jfree.data.category.CategoryDataset var16 = null;
//     var2.drawItem(var7, var8, var9, var10, var11, (org.jfree.chart.axis.ValueAxis)var13, var16, 0, 1, 13);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var2.drawBackground(var3, var4, var5);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.setLabel("");
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.Plot var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     org.jfree.chart.axis.AxisSpace var9 = var1.reserveSpace(var4, var5, var6, var7, var8);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var10.setSeriesPositiveItemLabelPosition(100, var12);
//     java.awt.Stroke var14 = var10.getBaseOutlineStroke();
//     var2.setSeriesStroke(10, var14, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryLabelEntity var4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(byte)1, var1, "hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    java.awt.Font var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setItemFont(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.IntervalMarker var4 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var5 = null;
//     var4.notifyListeners(var5);
//     org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
//     var4.setLabelPaint(var12);
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var12, 1.0f, 10, var16);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     double var7 = var2.getItemMargin();
//     java.lang.Object var8 = var2.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(13);
//     var2.setSeriesPositiveItemLabelPosition(0, var14);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var2.", var12.equals(var2) == var2.equals(var12));
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setAutoTickUnitSelection(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var8.removeChangeListener(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     double var6 = var2.getItemMargin();
//     java.awt.Font var8 = null;
//     var2.setSeriesItemLabelFont(0, var8);
//     java.awt.Font var12 = var2.getItemLabelFont(0, (-1));
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     org.jfree.chart.util.RectangleInsets var22 = var21.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var28 = var25.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var35 = var32.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var32);
//     org.jfree.chart.util.RectangleInsets var37 = var36.getMargin();
//     var29.setItemLabelPadding(var37);
//     java.awt.geom.Rectangle2D var39 = var29.getBounds();
//     java.awt.geom.Rectangle2D var42 = var22.createInsetRectangle(var39, false, false);
//     var2.drawBackground(var13, var14, var39);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    java.io.ObjectOutputStream var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0f, "", var2, var3, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    org.jfree.chart.util.VerticalAlignment var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setVerticalAlignment(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, var1);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.LengthAdjustmentType var17 = null;
    org.jfree.chart.util.LengthAdjustmentType var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var19 = var14.createAdjustedRectangle(var16, var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.setUpperBound(1.0d);
//     boolean var4 = var1.isNegativeArrowVisible();
//     org.jfree.data.time.SimpleTimePeriod var7 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var8 = var7.getStart();
//     java.util.Date var9 = null;
//     var1.setRange(var8, var9);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    double var7 = var2.getBase();
    org.jfree.chart.plot.DrawingSupplier var8 = var2.getDrawingSupplier();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var2.getLegendItemToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     double var6 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var10.setSeriesPositiveItemLabelPosition(100, var12);
//     java.awt.Stroke var14 = var10.getBaseOutlineStroke();
//     double var15 = var10.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(13);
//     var10.setBasePositiveItemLabelPosition(var20, true);
//     var2.setSeriesPositiveItemLabelPosition(0, var20, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var2.", var18.equals(var2) == var2.equals(var18));
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 10.0f, 0.0f, 1.0d, 1.0f, (-1.0f));
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    java.awt.Shape var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseShape(var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }
// 
// 
//     java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var2 = var1.getBlue();
//     java.awt.color.ColorSpace var3 = null;
//     float[] var4 = new float[] { };
//     float[] var5 = var1.getComponents(var3, var4);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     var3.setLabel("");
//     boolean var6 = var3.isAxisLineVisible();
//     java.text.DateFormat var7 = var3.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
//     var9.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     var12.setNotify(false);
//     java.awt.RenderingHints var15 = null;
//     var12.setRenderingHints(var15);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleEdge var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLegendItemGraphicEdge(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var2.notifyListeners(var3);
    org.jfree.chart.util.RectangleAnchor var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelAnchor(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, 0.0d, 100, (java.lang.Comparable)1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var6 = null;
    var4.setSeriesPositiveItemLabelPosition(100, var6);
    double var8 = var4.getItemMargin();
    java.awt.Font var10 = null;
    var4.setSeriesItemLabelFont(0, var10);
    java.awt.Paint var12 = var4.getBaseOutlinePaint();
    org.jfree.chart.util.RectangleEdge var13 = null;
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var28 = var25.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
    org.jfree.chart.util.RectangleInsets var30 = var29.getMargin();
    var22.setItemLabelPadding(var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("hi!", var1, var12, var13, var14, var15, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.data.Range var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var16 = var14.toRangeHeight(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
    boolean var9 = var2.isItemLabelVisible(1, 100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = null;
    var2.setBaseItemLabelGenerator(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(13);
//     org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var10 = null;
//     var8.setSeriesPositiveItemLabelPosition(100, var10);
//     double var12 = var8.getItemMargin();
//     java.awt.Font var14 = null;
//     var8.setSeriesItemLabelFont(0, var14);
//     java.awt.Font var18 = var8.getItemLabelFont(0, (-1));
//     var2.setSeriesItemLabelFont(10, var18);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var2.", var8.equals(var2) == var2.equals(var8));
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(short)0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    org.jfree.chart.plot.Marker var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.MarkerChangeEvent var1 = new org.jfree.chart.event.MarkerChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var8 = null;
//     var6.setSeriesPositiveItemLabelPosition(100, var8);
//     double var10 = var6.getItemMargin();
//     java.awt.Font var12 = null;
//     var6.setSeriesItemLabelFont(0, var12);
//     java.awt.Font var16 = var6.getItemLabelFont(0, (-1));
//     org.jfree.chart.plot.IntervalMarker var19 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var20 = null;
//     var19.notifyListeners(var20);
//     org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
//     var19.setLabelPaint(var27);
//     org.jfree.chart.text.TextLine var29 = new org.jfree.chart.text.TextLine("hi!", var16, var27);
//     var2.setLabelPaint(var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.setLabel("");
//     boolean var4 = var1.isAxisLineVisible();
//     org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
//     var1.setRange(var7, true, true);
//     org.jfree.chart.axis.DateTickUnit var11 = null;
//     java.util.Date var12 = var1.calculateHighestVisibleTickValue(var11);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var7 = null;
//     var5.setSeriesPositiveItemLabelPosition(100, var7);
//     java.awt.Stroke var9 = var5.getBaseOutlineStroke();
//     var2.setStroke(var9);
//     java.lang.Class var11 = null;
//     java.util.EventListener[] var12 = var2.getListeners(var11);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleEdge var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setPosition(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)"");

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    org.jfree.chart.util.RectangleAnchor var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var29.setLabelAnchor(var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(13);
//     org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var11 = null;
//     var9.setSeriesPositiveItemLabelPosition(100, var11);
//     double var13 = var9.getItemMargin();
//     java.awt.Font var15 = null;
//     var9.setSeriesItemLabelFont(0, var15);
//     java.awt.Font var19 = var9.getItemLabelFont(0, (-1));
//     org.jfree.chart.plot.IntervalMarker var22 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var23 = null;
//     var22.notifyListeners(var23);
//     org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
//     var22.setLabelPaint(var30);
//     org.jfree.chart.text.TextLine var32 = new org.jfree.chart.text.TextLine("hi!", var19, var30);
//     var2.setSeriesItemLabelFont(0, var19);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var2.", var27.equals(var2) == var2.equals(var27));
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
    var2.setAutoPopulateSeriesShape(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     double var7 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
//     var2.setBasePositiveItemLabelPosition(var12, true);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
//     var19.setLabel("");
//     boolean var22 = var19.isAxisLineVisible();
//     java.text.DateFormat var23 = var19.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
//     org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var30 = null;
//     var29.notifyListeners(var30);
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
//     org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
//     org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
//     var46.setItemLabelPadding(var54);
//     java.awt.geom.Rectangle2D var56 = var46.getBounds();
//     java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
//     var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
//     org.jfree.data.xy.XYDataset var61 = null;
//     org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("hi!");
//     var63.setLabel("");
//     boolean var66 = var63.isAxisLineVisible();
//     java.text.DateFormat var67 = var63.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var68 = null;
//     org.jfree.chart.plot.PolarPlot var69 = new org.jfree.chart.plot.PolarPlot(var61, (org.jfree.chart.axis.ValueAxis)var63, var68);
//     org.jfree.chart.axis.ValueAxis var70 = var69.getAxis();
//     org.jfree.data.xy.XYDataset var71 = null;
//     var69.setDataset(var71);
//     var29.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var69);
//     
//     // Checks the contract:  equals-hashcode on var25 and var69
//     assertTrue("Contract failed: equals-hashcode on var25 and var69", var25.equals(var69) ? var25.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var25
//     assertTrue("Contract failed: equals-hashcode on var69 and var25", var69.equals(var25) ? var69.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
    var10.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var18 = var10.getItemOutlineStroke(0, (-1));
    var2.setBaseStroke(var18);
    java.awt.Paint var20 = var2.getBaseItemLabelPaint();
    double var21 = var2.getItemLabelAnchorOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelsVisible((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.Paint var16 = var6.getItemPaint();
    org.jfree.chart.util.VerticalAlignment var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setVerticalAlignment(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.Axis var34 = var33.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var2 = var1.getBlue();
    float[] var3 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var4 = var1.getRGBColorComponents(var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
    boolean var9 = var2.isItemLabelVisible(1, 100);
    org.jfree.data.category.CategoryDataset var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var11 = var2.findRangeBounds(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.awt.Shape var7 = var3.getUpArrow();
    var1.setRightArrow(var7);
    double var9 = var1.getFixedAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths((-1), var1);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 10.0f, 100.0f, var4, 0.0d, var6);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.chart.util.RectangleEdge var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLegendItemGraphicEdge(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "hi!"};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    var2.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var10 = var2.getItemOutlineStroke(0, (-1));
    java.awt.Color var13 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var14 = var13.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var18 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var19 = var13.equals((java.lang.Object)"");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelPaint((-1), (java.awt.Paint)var13, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     double var7 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
//     var2.setBasePositiveItemLabelPosition(var12, true);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var2.getBaseNegativeItemLabelPosition();
//     
//     // Checks the contract:  equals-hashcode on var12 and var15
//     assertTrue("Contract failed: equals-hashcode on var12 and var15", var12.equals(var15) ? var12.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var12
//     assertTrue("Contract failed: equals-hashcode on var15 and var12", var15.equals(var12) ? var15.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.awt.Shape var7 = var3.getUpArrow();
    var1.setRightArrow(var7);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, (-1.0d), 100.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var22 = var19.getItemLabelPaint((-1), 100);
    var6.setBackgroundPaint(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    org.jfree.chart.event.AxisChangeListener var4 = null;
    var1.addChangeListener(var4);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var8.setSeriesPositiveItemLabelPosition(100, var10);
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    double var13 = var8.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(13);
    var8.setBasePositiveItemLabelPosition(var18, true);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLabel("");
    boolean var28 = var25.isAxisLineVisible();
    java.text.DateFormat var29 = var25.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var30);
    org.jfree.chart.axis.ValueAxis var32 = var31.getAxis();
    org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var35.notifyListeners(var36);
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
    var52.setItemLabelPadding(var60);
    java.awt.geom.Rectangle2D var62 = var52.getBounds();
    java.awt.geom.Rectangle2D var65 = var45.createInsetRectangle(var62, false, false);
    var8.drawRangeMarker(var21, var22, var32, (org.jfree.chart.plot.Marker)var35, var65);
    var1.setRightArrow((java.awt.Shape)var65);
    var1.setRangeWithMargins((-1.0d), 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Polar Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var6 = var3.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
//     org.jfree.chart.util.RectangleInsets var8 = var7.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var14 = var11.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getMargin();
//     var15.setItemLabelPadding(var23);
//     java.awt.geom.Rectangle2D var25 = var15.getBounds();
//     java.awt.geom.Rectangle2D var28 = var8.createInsetRectangle(var25, false, false);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, (java.awt.Shape)var28, 1.0d, 0.0f, 0.0f);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    var2.setBaseSeriesVisibleInLegend(false, false);
    java.awt.Shape var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseShape(var10, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }


    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.SimpleTimePeriod var7 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var8 = var7.getEnd();
    org.jfree.data.gantt.Task var9 = new org.jfree.data.gantt.Task("", var4, var8);
    java.lang.Object var10 = var9.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    var2.setAxisLineStroke(var11);
    var2.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.util.RectangleInsets var29 = var28.getMargin();
    var21.setItemLabelPadding(var29);
    java.awt.geom.Rectangle2D var31 = var21.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var31, "hi!", "hi!");
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var0, (java.awt.Shape)var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity(var0, "Polar Plot", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    java.awt.Paint var51 = var50.getOutlinePaint();
    java.awt.Stroke var52 = var50.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
//     org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var10.setSeriesPositiveItemLabelPosition(100, var12);
//     double var14 = var10.getItemMargin();
//     java.awt.Font var16 = null;
//     var10.setSeriesItemLabelFont(0, var16);
//     java.awt.Paint var18 = var10.getBaseOutlinePaint();
//     boolean var19 = var7.equals((java.lang.Object)var10);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    var9.zoomRange(0.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }


    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(13, 1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, (-1.0f), 10.0f, var4, (-1.0d), 1.0f, 1.0f);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     boolean var8 = var2.isSeriesVisible(100);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
//     var12.setLabel("");
//     org.jfree.chart.event.AxisChangeListener var15 = null;
//     var12.addChangeListener(var15);
//     org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var21 = null;
//     var19.setSeriesPositiveItemLabelPosition(100, var21);
//     java.awt.Stroke var23 = var19.getBaseOutlineStroke();
//     double var24 = var19.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var27.getSeriesNegativeItemLabelPosition(13);
//     var19.setBasePositiveItemLabelPosition(var29, true);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = null;
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
//     var36.setLabel("");
//     boolean var39 = var36.isAxisLineVisible();
//     java.text.DateFormat var40 = var36.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var41 = null;
//     org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, var41);
//     org.jfree.chart.axis.ValueAxis var43 = var42.getAxis();
//     org.jfree.chart.plot.IntervalMarker var46 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var47 = null;
//     var46.notifyListeners(var47);
//     org.jfree.chart.renderer.category.BarRenderer3D var51 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var54 = var51.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
//     org.jfree.chart.util.RectangleInsets var56 = var55.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
//     org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var69 = var66.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66);
//     org.jfree.chart.util.RectangleInsets var71 = var70.getMargin();
//     var63.setItemLabelPadding(var71);
//     java.awt.geom.Rectangle2D var73 = var63.getBounds();
//     java.awt.geom.Rectangle2D var76 = var56.createInsetRectangle(var73, false, false);
//     var19.drawRangeMarker(var32, var33, var43, (org.jfree.chart.plot.Marker)var46, var76);
//     var12.setRightArrow((java.awt.Shape)var76);
//     var2.drawBackground(var9, var10, var76);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     double var7 = var2.getBase();
//     java.awt.Shape var10 = var2.getItemShape(1, 0);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var2.drawOutline(var11, var12, var13);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     double var7 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var10.setSeriesPositiveItemLabelPosition(100, var12);
//     java.awt.Stroke var14 = var10.getBaseOutlineStroke();
//     var2.setBaseStroke(var14, true);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.plot.CategoryMarker var20 = null;
//     java.awt.Shape var21 = null;
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("hi!");
//     var23.setUpperBound(1.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var30 = null;
//     var28.setSeriesPositiveItemLabelPosition(100, var30);
//     java.awt.Stroke var32 = var28.getBaseOutlineStroke();
//     var23.setAxisLineStroke(var32);
//     var23.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var41 = var38.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
//     org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
//     org.jfree.chart.util.RectangleInsets var50 = var49.getMargin();
//     var42.setItemLabelPadding(var50);
//     java.awt.geom.Rectangle2D var52 = var42.getBounds();
//     org.jfree.chart.entity.AxisLabelEntity var55 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var23, (java.awt.Shape)var52, "hi!", "hi!");
//     boolean var56 = org.jfree.chart.util.ShapeUtilities.equal(var21, (java.awt.Shape)var52);
//     var2.drawDomainMarker(var17, var18, var19, var20, var52);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var5 = null;
//     var3.setSeriesPositiveItemLabelPosition(100, var5);
//     double var7 = var3.getItemMargin();
//     java.awt.Font var9 = null;
//     var3.setSeriesItemLabelFont(0, var9);
//     java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
//     org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var17 = null;
//     var16.notifyListeners(var17);
//     org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var24 = var21.getItemLabelPaint((-1), 100);
//     var16.setLabelPaint(var24);
//     org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine("hi!", var13, var24);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.text.TextAnchor var30 = null;
//     var26.draw(var27, 0.0f, (-1.0f), var30, 0.0f, 0.0f, 1.0d);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.Paint var16 = var6.getItemPaint();
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setHorizontalAlignment(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    java.awt.Paint var51 = var50.getOutlinePaint();
    java.lang.Object var52 = null;
    boolean var53 = var50.equals(var52);
    var50.setShapeFilled(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    var50.setLineVisible(true);
    org.jfree.chart.util.RectangleAnchor var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setShapeAnchor(var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
    var14.setLabel("");
    boolean var17 = var14.isAxisLineVisible();
    java.text.DateFormat var18 = var14.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var19 = null;
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var19);
    var20.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
    var23.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    var23.addSubtitle((org.jfree.chart.title.Title)var32);
    java.awt.image.BufferedImage var36 = var23.createBufferedImage(10, 1);
    var8.setBackgroundImage((java.awt.Image)var36);
    boolean var38 = var8.isAngleGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.VerticalAlignment var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setVerticalAlignment(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
    var14.setLabel("");
    boolean var17 = var14.isAxisLineVisible();
    java.text.DateFormat var18 = var14.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var19 = null;
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var19);
    var20.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
    var23.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    var23.addSubtitle((org.jfree.chart.title.Title)var32);
    java.awt.image.BufferedImage var36 = var23.createBufferedImage(10, 1);
    var8.setBackgroundImage((java.awt.Image)var36);
    float var38 = var8.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.5f);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var4 = org.jfree.data.Range.shift(var2, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 13);
    float[] var5 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var3.getColorComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    java.util.List var8 = var6.getLines();
    java.util.List var9 = var6.getLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    java.util.List var8 = var6.getLines();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLineAlignment(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
//     var6.setItemLabelPadding(var14);
//     java.awt.geom.Rectangle2D var16 = var6.getBounds();
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
//     var20.setLabel("");
//     boolean var23 = var20.isAxisLineVisible();
//     java.text.DateFormat var24 = var20.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var25 = null;
//     org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
//     var26.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
//     var29.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     var29.addSubtitle((org.jfree.chart.title.Title)var38);
//     java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
//     var29.setBackgroundPaint(var48);
//     org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
//     var50.setLineVisible(true);
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
//     org.jfree.chart.util.RectangleInsets var61 = var60.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var64 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var67 = var64.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var64);
//     org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var74 = var71.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var71);
//     org.jfree.chart.util.RectangleInsets var76 = var75.getMargin();
//     var68.setItemLabelPadding(var76);
//     java.awt.geom.Rectangle2D var78 = var68.getBounds();
//     java.awt.geom.Rectangle2D var81 = var61.createInsetRectangle(var78, false, false);
//     var50.draw(var53, var78);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 10.0d, true);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var11 = var8.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getMargin();
//     var12.setItemLabelPadding(var20);
//     java.awt.geom.Rectangle2D var22 = var12.getBounds();
//     org.jfree.chart.plot.CategoryPlot var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
//     var27.setLabel("");
//     boolean var30 = var27.isAxisLineVisible();
//     java.text.DateFormat var31 = var27.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
//     var35.setLabel("");
//     boolean var38 = var35.isAxisLineVisible();
//     org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     var41.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
//     org.jfree.chart.LegendItemCollection var46 = var41.getLegendItems();
//     boolean var47 = var35.equals((java.lang.Object)var46);
//     var33.setAxis((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     var3.drawItem(var4, var5, var22, var23, var24, (org.jfree.chart.axis.ValueAxis)var35, var49, 1, 10, 13);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var8.addChangeListener(var13);
    org.jfree.data.general.DatasetChangeEvent var15 = null;
    var8.datasetChanged(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    var2.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var10 = var2.getItemOutlineStroke(0, (-1));
    org.jfree.chart.plot.DrawingSupplier var11 = var2.getDrawingSupplier();
    var2.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setHorizontalAlignment(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    org.jfree.chart.util.RectangleInsets var27 = var26.getMargin();
    var19.setItemLabelPadding(var27);
    java.awt.geom.Rectangle2D var29 = var19.getBounds();
    var12.addLegend(var19);
    org.jfree.chart.ChartRenderingInfo var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var36 = var12.createBufferedImage(100, 0, (-1.0d), 10.0d, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var4 = null;
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
//     var6.setLabel("");
//     org.jfree.chart.event.AxisChangeListener var9 = null;
//     var6.addChangeListener(var9);
//     org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var15 = null;
//     var13.setSeriesPositiveItemLabelPosition(100, var15);
//     java.awt.Stroke var17 = var13.getBaseOutlineStroke();
//     double var18 = var13.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var23 = var21.getSeriesNegativeItemLabelPosition(13);
//     var13.setBasePositiveItemLabelPosition(var23, true);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = null;
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
//     var30.setLabel("");
//     boolean var33 = var30.isAxisLineVisible();
//     java.text.DateFormat var34 = var30.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var35 = null;
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.axis.ValueAxis var37 = var36.getAxis();
//     org.jfree.chart.plot.IntervalMarker var40 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var41 = null;
//     var40.notifyListeners(var41);
//     org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
//     org.jfree.chart.util.RectangleInsets var50 = var49.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53);
//     org.jfree.chart.renderer.category.BarRenderer3D var60 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var63 = var60.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60);
//     org.jfree.chart.util.RectangleInsets var65 = var64.getMargin();
//     var57.setItemLabelPadding(var65);
//     java.awt.geom.Rectangle2D var67 = var57.getBounds();
//     java.awt.geom.Rectangle2D var70 = var50.createInsetRectangle(var67, false, false);
//     var13.drawRangeMarker(var26, var27, var37, (org.jfree.chart.plot.Marker)var40, var70);
//     var6.setRightArrow((java.awt.Shape)var70);
//     org.jfree.chart.plot.CategoryPlot var73 = null;
//     org.jfree.chart.axis.CategoryAxis var74 = null;
//     org.jfree.chart.axis.DateAxis var76 = new org.jfree.chart.axis.DateAxis("hi!");
//     var76.setLabel("");
//     boolean var79 = var76.isAxisLineVisible();
//     java.text.DateFormat var80 = var76.getDateFormatOverride();
//     org.jfree.chart.plot.Plot var81 = var76.getPlot();
//     org.jfree.chart.renderer.category.BarRenderer3D var84 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var86 = null;
//     var84.setSeriesPositiveItemLabelPosition(100, var86);
//     double var88 = var84.getItemMargin();
//     java.awt.Font var90 = null;
//     var84.setSeriesItemLabelFont(0, var90);
//     java.awt.Paint var92 = var84.getBaseOutlinePaint();
//     var76.setLabelPaint(var92);
//     org.jfree.data.category.CategoryDataset var94 = null;
//     var2.drawItem(var3, var4, var70, var73, var74, (org.jfree.chart.axis.ValueAxis)var76, var94, (-1), 0, 10);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     var3.setLabel("");
//     boolean var6 = var3.isAxisLineVisible();
//     java.text.DateFormat var7 = var3.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
//     var9.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     var12.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     var12.addSubtitle((org.jfree.chart.title.Title)var21);
//     java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
//     var12.setBackgroundPaint(var31);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var39 = var36.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
//     org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
//     org.jfree.chart.util.RectangleInsets var48 = var47.getMargin();
//     var40.setItemLabelPadding(var48);
//     java.awt.geom.Rectangle2D var50 = var40.getBounds();
//     var12.draw(var33, var50);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }
// 
// 
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
//     var6.setLabel("");
//     boolean var9 = var6.isAxisLineVisible();
//     java.text.DateFormat var10 = var6.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var11);
//     var12.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var12);
//     var15.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var23 = var20.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
//     var15.addSubtitle((org.jfree.chart.title.Title)var24);
//     java.awt.image.BufferedImage var28 = var15.createBufferedImage(10, 1);
//     org.jfree.chart.ui.ProjectInfo var32 = new org.jfree.chart.ui.ProjectInfo("", "Polar Plot", "", (java.awt.Image)var28, "Polar Plot", "Polar Plot", "Polar Plot");
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
//     var35.setLabel("");
//     boolean var38 = var35.isAxisLineVisible();
//     java.text.DateFormat var39 = var35.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, var40);
//     org.jfree.chart.event.AxisChangeEvent var42 = null;
//     var41.axisChanged(var42);
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis("hi!");
//     var47.setLabel("");
//     boolean var50 = var47.isAxisLineVisible();
//     java.text.DateFormat var51 = var47.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var52 = null;
//     org.jfree.chart.plot.PolarPlot var53 = new org.jfree.chart.plot.PolarPlot(var45, (org.jfree.chart.axis.ValueAxis)var47, var52);
//     var53.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var53);
//     var56.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var64 = var61.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var61);
//     var56.addSubtitle((org.jfree.chart.title.Title)var65);
//     java.awt.image.BufferedImage var69 = var56.createBufferedImage(10, 1);
//     var41.setBackgroundImage((java.awt.Image)var69);
//     var32.setLogo((java.awt.Image)var69);
//     
//     // Checks the contract:  equals-hashcode on var12 and var53
//     assertTrue("Contract failed: equals-hashcode on var12 and var53", var12.equals(var53) ? var12.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var12
//     assertTrue("Contract failed: equals-hashcode on var53 and var12", var53.equals(var12) ? var53.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var56
//     assertTrue("Contract failed: equals-hashcode on var15 and var56", var15.equals(var56) ? var15.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var15
//     assertTrue("Contract failed: equals-hashcode on var56 and var15", var56.equals(var15) ? var56.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var9 = var7.get((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
    var2.setAutoPopulateSeriesFillPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    org.jfree.chart.util.RectangleAnchor var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLegendItemGraphicAnchor(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     var2.setBaseSeriesVisible(false);
//     java.awt.Stroke var10 = var2.getSeriesStroke(10);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
//     var14.setUpperBound(1.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var21 = null;
//     var19.setSeriesPositiveItemLabelPosition(100, var21);
//     java.awt.Stroke var23 = var19.getBaseOutlineStroke();
//     var14.setAxisLineStroke(var23);
//     var14.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var32 = var29.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
//     org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var39 = var36.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
//     org.jfree.chart.util.RectangleInsets var41 = var40.getMargin();
//     var33.setItemLabelPadding(var41);
//     java.awt.geom.Rectangle2D var43 = var33.getBounds();
//     org.jfree.chart.entity.AxisLabelEntity var46 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var14, (java.awt.Shape)var43, "hi!", "hi!");
//     var2.drawDomainGridline(var11, var12, var43, 0.0d);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }
// 
// 
//     boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == false);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    java.awt.Font var8 = null;
    var2.setSeriesItemLabelFont(0, var8);
    java.awt.Paint var10 = var2.getBaseOutlinePaint();
    java.awt.Paint var11 = var2.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var16 = null;
    var14.setSeriesPositiveItemLabelPosition(100, var16);
    java.awt.Stroke var18 = var14.getBaseOutlineStroke();
    java.lang.Object var19 = var14.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
    var22.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var30 = var22.getItemOutlineStroke(0, (-1));
    var14.setBaseStroke(var30);
    java.awt.Paint var32 = var14.getBaseItemLabelPaint();
    double var33 = var14.getItemLabelAnchorOffset();
    org.jfree.chart.labels.ItemLabelPosition var35 = var14.getSeriesPositiveItemLabelPosition(0);
    var2.setBasePositiveItemLabelPosition(var35);
    var2.setAutoPopulateSeriesFillPaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    java.awt.Paint var12 = var8.getNoDataMessagePaint();
    java.awt.Paint var13 = null;
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
    var16.setLabel("");
    boolean var19 = var16.isAxisLineVisible();
    java.text.DateFormat var20 = var16.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var21 = null;
    org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var21);
    int var23 = var22.getSeriesCount();
    org.jfree.data.xy.XYDataset var24 = null;
    var22.setDataset(var24);
    java.awt.Paint var26 = var22.getNoDataMessagePaint();
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
    var29.setLabel("");
    boolean var32 = var29.isAxisLineVisible();
    java.text.DateFormat var33 = var29.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var27, (org.jfree.chart.axis.ValueAxis)var29, var34);
    var35.setNoDataMessage("hi!");
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    org.jfree.chart.util.RectangleInsets var52 = var51.getMargin();
    var44.setItemLabelPadding(var52);
    java.awt.geom.Rectangle2D var54 = var44.getBounds();
    org.jfree.data.xy.XYDataset var56 = null;
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis("hi!");
    var58.setLabel("");
    boolean var61 = var58.isAxisLineVisible();
    java.text.DateFormat var62 = var58.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var63 = null;
    org.jfree.chart.plot.PolarPlot var64 = new org.jfree.chart.plot.PolarPlot(var56, (org.jfree.chart.axis.ValueAxis)var58, var63);
    var64.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var64);
    var67.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var72 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var75 = var72.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var72);
    var67.addSubtitle((org.jfree.chart.title.Title)var76);
    java.awt.image.BufferedImage var80 = var67.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var83 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var86 = var83.getItemLabelPaint((-1), 100);
    var67.setBackgroundPaint(var86);
    org.jfree.chart.title.LegendGraphic var88 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var54, var86);
    var35.setAngleLabelPaint(var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.WaterfallBarRenderer var90 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var12, var13, var26, var86);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var14 = null;
    var12.setSeriesPositiveItemLabelPosition(100, var14);
    java.awt.Stroke var16 = var12.getBaseOutlineStroke();
    var7.setAxisLineStroke(var16);
    var2.setBaseOutlineStroke(var16);
    java.awt.Stroke var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesStroke((-1), var20, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     java.lang.Object var7 = var2.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
//     var10.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var18 = var10.getItemOutlineStroke(0, (-1));
//     var2.setBaseStroke(var18);
//     int var20 = var2.getRowCount();
//     var2.setSeriesVisible(1, (java.lang.Boolean)true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.text.DateFormat var5 = var1.getDateFormatOverride();
    org.jfree.data.time.SimpleTimePeriod var9 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var10 = var9.getStart();
    org.jfree.data.time.SimpleTimePeriod var13 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var14 = var13.getEnd();
    org.jfree.data.gantt.Task var15 = new org.jfree.data.gantt.Task("", var10, var14);
    org.jfree.data.time.SimpleTimePeriod var18 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var19 = var18.getStart();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var14, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    java.awt.Font var8 = null;
    var2.setSeriesItemLabelFont(0, var8);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var2.setBaseToolTipGenerator(var10);
    java.awt.Stroke var13 = var2.lookupSeriesStroke(1);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var19 = null;
    var17.setSeriesPositiveItemLabelPosition(100, var19);
    java.awt.Stroke var21 = var17.getBaseOutlineStroke();
    java.lang.Object var22 = var17.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var28 = var25.getItemLabelPaint((-1), 100);
    var25.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var33 = var25.getItemOutlineStroke(0, (-1));
    var17.setBaseStroke(var33);
    int var35 = var17.getRowCount();
    org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var40 = null;
    var38.setSeriesPositiveItemLabelPosition(100, var40);
    java.awt.Stroke var42 = var38.getBaseOutlineStroke();
    double var43 = var38.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var48 = var46.getSeriesNegativeItemLabelPosition(13);
    var38.setBasePositiveItemLabelPosition(var48, true);
    double var51 = var48.getAngle();
    var17.setBasePositiveItemLabelPosition(var48, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesNegativeItemLabelPosition((-1), var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }


    double[][] var0 = null;
    double[] var1 = null;
    double[][] var2 = new double[][] { var1};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    var2.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var10 = var2.getItemOutlineStroke(0, (-1));
    java.lang.Boolean var12 = var2.getSeriesCreateEntities(100);
    java.awt.Paint var14 = var2.lookupSeriesPaint(1);
    java.io.ObjectOutputStream var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 1);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }


    java.text.DateFormat var4 = null;
    org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var4);
    int var6 = var5.getCalendarField();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var65 = null;
    var63.setSeriesPositiveItemLabelPosition(100, var65);
    java.awt.Stroke var67 = var63.getBaseOutlineStroke();
    double var68 = var63.getItemMargin();
    org.jfree.chart.util.GradientPaintTransformer var69 = var63.getGradientPaintTransformer();
    var29.setGradientPaintTransformer(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    var50.setLineVisible(true);
    org.jfree.chart.util.RectangleAnchor var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setShapeLocation(var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.plot.IntervalMarker var5 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var10 = null;
//     var8.setSeriesPositiveItemLabelPosition(100, var10);
//     java.awt.Stroke var12 = var8.getBaseOutlineStroke();
//     var5.setStroke(var12);
//     var2.setBaseOutlineStroke(var12);
//     var2.setSeriesVisible(1, (java.lang.Boolean)false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var2.", var8.equals(var2) == var2.equals(var8));
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setAngleLabelsVisible(true);
    var8.setBackgroundImageAlignment(0);
    java.awt.Paint var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setAngleLabelPaint(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var8.addChangeListener(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleAnchor var18 = null;
    java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
    var8.zoomRangeAxes(10.0d, var16, var19);
    java.io.ObjectOutputStream var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var19, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var5 = null;
//     var3.setSeriesPositiveItemLabelPosition(100, var5);
//     double var7 = var3.getItemMargin();
//     java.awt.Font var9 = null;
//     var3.setSeriesItemLabelFont(0, var9);
//     java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var18 = null;
//     var16.setSeriesPositiveItemLabelPosition(100, var18);
//     java.awt.Stroke var20 = var16.getBaseOutlineStroke();
//     java.lang.Object var21 = var16.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
//     var24.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var32 = var24.getItemOutlineStroke(0, (-1));
//     var16.setBaseStroke(var32);
//     java.awt.Paint var34 = var16.getBaseItemLabelPaint();
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("", var13, var34);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.text.TextAnchor var37 = null;
//     float var38 = var35.calculateBaselineOffset(var36, var37);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "", "hi!");
    java.lang.Object var5 = null;
    boolean var6 = var4.equals(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.axis.TickUnitSource var14 = var1.getStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    var1.setLowerBound(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.lang.Object var61 = var29.clone();
    org.jfree.chart.event.MarkerChangeEvent var62 = null;
    var29.notifyListeners(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    boolean var4 = var1.isNegativeArrowVisible();
    java.util.Date var5 = var1.getMinimumDate();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    org.jfree.chart.block.Arrangement var11 = null;
    org.jfree.chart.block.Arrangement var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8, var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.chart.block.LengthConstraintType var15 = var14.getHeightConstraintType();
    java.lang.String var16 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"+ "'", var16.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.lang.Object var3 = var2.clone();
    var2.setBaseShapesFilled(false);
    var2.setBaseLinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    var8.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("hi!");
    var13.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var20 = null;
    var18.setSeriesPositiveItemLabelPosition(100, var20);
    java.awt.Stroke var22 = var18.getBaseOutlineStroke();
    var13.setAxisLineStroke(var22);
    var13.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
    org.jfree.chart.util.RectangleInsets var40 = var39.getMargin();
    var32.setItemLabelPadding(var40);
    java.awt.geom.Rectangle2D var42 = var32.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var45 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var13, (java.awt.Shape)var42, "hi!", "hi!");
    java.awt.Shape var46 = var45.getArea();
    boolean var47 = var8.equals((java.lang.Object)var45);
    org.jfree.chart.renderer.PolarItemRenderer var48 = var8.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    java.lang.String var9 = var8.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Polar Plot"+ "'", var9.equals("Polar Plot"));

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    java.awt.Font var8 = null;
    var2.setSeriesItemLabelFont(0, var8);
    org.jfree.chart.urls.CategoryURLGenerator var10 = var2.getBaseURLGenerator();
    var2.setBase((-1.0d));
    java.awt.Stroke var15 = var2.getItemOutlineStroke(10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    var1.resizeRange((-1.0d), 100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    var9.setSeriesPositiveItemLabelPosition(100, var11);
    double var13 = var9.getItemMargin();
    java.awt.Font var15 = null;
    var9.setSeriesItemLabelFont(0, var15);
    java.awt.Font var19 = var9.getItemLabelFont(0, (-1));
    var1.setTickLabelFont(var19);
    boolean var21 = var1.isVerticalTickLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.setLabel("");
//     boolean var4 = var1.isAxisLineVisible();
//     org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     var7.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
//     org.jfree.chart.LegendItemCollection var12 = var7.getLegendItems();
//     boolean var13 = var1.equals((java.lang.Object)var12);
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var18 = null;
//     var16.setSeriesPositiveItemLabelPosition(100, var18);
//     java.awt.Stroke var20 = var16.getBaseOutlineStroke();
//     java.lang.Object var21 = var16.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
//     var24.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var32 = var24.getItemOutlineStroke(0, (-1));
//     var16.setBaseStroke(var32);
//     var1.setTickMarkStroke(var32);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var7.", var16.equals(var7) == var7.equals(var16));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var7.", var24.equals(var7) == var7.equals(var24));
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    double var8 = var2.getItemLabelAnchorOffset();
    var2.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }


    java.awt.Color var1 = java.awt.Color.getColor("Range[0.0,0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    var2.setAxisLineStroke(var11);
    var2.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.util.RectangleInsets var29 = var28.getMargin();
    var21.setItemLabelPadding(var29);
    java.awt.geom.Rectangle2D var31 = var21.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var31, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
    var36.setLabel("");
    boolean var39 = var36.isAxisLineVisible();
    org.jfree.data.Range var42 = new org.jfree.data.Range(0.0d, 0.0d);
    var36.setRange(var42, true, true);
    var2.setRange(var42, false, false);
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(var42, 1.0d);
    org.jfree.data.KeyedObject var51 = new org.jfree.data.KeyedObject((java.lang.Comparable)0.0f, (java.lang.Object)var42);
    java.lang.Comparable var52 = var51.getKey();
    java.lang.Object var53 = var51.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + 0.0f+ "'", var52.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.text.DateFormat var5 = var1.getDateFormatOverride();
    var1.setLabelURL("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var22 = var19.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
    org.jfree.chart.util.RectangleInsets var24 = var23.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    var31.setItemLabelPadding(var39);
    java.awt.geom.Rectangle2D var41 = var31.getBounds();
    java.awt.geom.Rectangle2D var44 = var24.createInsetRectangle(var41, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    org.jfree.chart.util.RectangleInsets var52 = var51.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.renderer.category.BarRenderer3D var62 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var65 = var62.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var62);
    org.jfree.chart.util.RectangleInsets var67 = var66.getMargin();
    var59.setItemLabelPadding(var67);
    java.awt.geom.Rectangle2D var69 = var59.getBounds();
    java.awt.geom.Rectangle2D var72 = var52.createInsetRectangle(var69, false, false);
    boolean var73 = org.jfree.chart.util.ShapeUtilities.intersects(var44, var72);
    boolean var74 = org.jfree.chart.util.ShapeUtilities.intersects(var16, var44);
    org.jfree.data.category.CategoryDataset var77 = null;
    java.text.DateFormat var83 = null;
    org.jfree.chart.axis.DateTickUnit var84 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var83);
    int var85 = var84.getRollUnit();
    int var86 = var84.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var89 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var90 = var89.getStart();
    java.util.Date var91 = var84.rollDate(var90);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var92 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var16, "", "Polar Plot", var77, (java.lang.Comparable)"Range[0.0,0.0]", (java.lang.Comparable)var84);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    var2.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var10 = var2.getItemOutlineStroke(0, (-1));
    org.jfree.chart.plot.DrawingSupplier var11 = var2.getDrawingSupplier();
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var17 = null;
    var15.setSeriesPositiveItemLabelPosition(100, var17);
    double var19 = var15.getItemMargin();
    java.awt.Font var21 = null;
    var15.setSeriesItemLabelFont(0, var21);
    java.awt.Font var25 = var15.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var30 = null;
    var28.setSeriesPositiveItemLabelPosition(100, var30);
    java.awt.Stroke var32 = var28.getBaseOutlineStroke();
    java.lang.Object var33 = var28.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var39 = var36.getItemLabelPaint((-1), 100);
    var36.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var44 = var36.getItemOutlineStroke(0, (-1));
    var28.setBaseStroke(var44);
    java.awt.Paint var46 = var28.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var47 = new org.jfree.chart.text.TextFragment("", var25, var46);
    var2.setBaseItemLabelPaint(var46, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    var1.resizeRange((-1.0d), 100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    var9.setSeriesPositiveItemLabelPosition(100, var11);
    double var13 = var9.getItemMargin();
    java.awt.Font var15 = null;
    var9.setSeriesItemLabelFont(0, var15);
    java.awt.Font var19 = var9.getItemLabelFont(0, (-1));
    var1.setTickLabelFont(var19);
    java.awt.Shape var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var21, "Polar Plot", "Polar Plot");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    var1.centerRange(100.0d);
    org.jfree.data.Range var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var2 = var1.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var6 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var7 = var1.equals((java.lang.Object)"");
    java.awt.color.ColorSpace var8 = var1.getColorSpace();
    float[] var11 = new float[] { (-1.0f), 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var12 = var1.getComponents(var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var10 = null;
    var9.notifyListeners(var10);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    var9.setLabelPaint(var17);
    var6.setBackgroundPaint(var17);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("hi!");
    var23.setLabel("");
    boolean var26 = var23.isAxisLineVisible();
    java.text.DateFormat var27 = var23.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var28 = null;
    org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, var28);
    var29.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var29);
    var32.setNotify(false);
    var32.clearSubtitles();
    var6.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var32);
    org.jfree.chart.event.ChartChangeListener var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var32.removeChangeListener(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("", "Range[0.0,0.0]");

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setNoDataMessage("hi!");
    boolean var11 = var8.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     double var7 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
//     var2.setBasePositiveItemLabelPosition(var12, true);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
//     var19.setLabel("");
//     boolean var22 = var19.isAxisLineVisible();
//     java.text.DateFormat var23 = var19.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
//     org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var30 = null;
//     var29.notifyListeners(var30);
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
//     org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
//     org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
//     var46.setItemLabelPadding(var54);
//     java.awt.geom.Rectangle2D var56 = var46.getBounds();
//     java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
//     var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
//     java.lang.Object var61 = var29.clone();
//     var29.setEndValue(0.0d);
//     org.jfree.data.xy.XYDataset var64 = null;
//     org.jfree.chart.axis.DateAxis var66 = new org.jfree.chart.axis.DateAxis("hi!");
//     var66.setLabel("");
//     boolean var69 = var66.isAxisLineVisible();
//     java.text.DateFormat var70 = var66.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var71 = null;
//     org.jfree.chart.plot.PolarPlot var72 = new org.jfree.chart.plot.PolarPlot(var64, (org.jfree.chart.axis.ValueAxis)var66, var71);
//     org.jfree.chart.axis.ValueAxis var73 = var72.getAxis();
//     java.awt.Paint var74 = var72.getNoDataMessagePaint();
//     var29.setOutlinePaint(var74);
//     
//     // Checks the contract:  equals-hashcode on var25 and var72
//     assertTrue("Contract failed: equals-hashcode on var25 and var72", var25.equals(var72) ? var25.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var25
//     assertTrue("Contract failed: equals-hashcode on var72 and var25", var72.equals(var25) ? var72.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    boolean var5 = var2.getItemShapeFilled(0, 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
    var10.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var18 = var10.getItemOutlineStroke(0, (-1));
    var2.setBaseStroke(var18);
    boolean var20 = var2.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }
// 
// 
//     org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
//     org.jfree.data.category.CategoryDataset var4 = null;
//     java.lang.String var7 = var3.generateURL(var4, 100, 0);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    int var15 = var12.getBackgroundImageAlignment();
    org.jfree.chart.title.TextTitle var16 = var12.getTitle();
    java.awt.Paint var17 = var16.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    java.util.List var8 = var6.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var14 = null;
    var12.setSeriesPositiveItemLabelPosition(100, var14);
    double var16 = var12.getItemMargin();
    java.awt.Font var18 = null;
    var12.setSeriesItemLabelFont(0, var18);
    java.awt.Font var22 = var12.getItemLabelFont(0, (-1));
    org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var26 = null;
    var25.notifyListeners(var26);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    var25.setLabelPaint(var33);
    org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("hi!", var22, var33);
    var6.addLine(var35);
    org.jfree.chart.util.HorizontalAlignment var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLineAlignment(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }


    java.awt.Color var1 = java.awt.Color.getColor("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var8.addChangeListener(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleAnchor var18 = null;
    java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
    var8.zoomRangeAxes(10.0d, var16, var19);
    boolean var21 = var8.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     double var7 = var2.getItemMargin();
//     java.lang.Object var8 = var2.clone();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
//     var12.setUpperBound(1.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var19 = null;
//     var17.setSeriesPositiveItemLabelPosition(100, var19);
//     java.awt.Stroke var21 = var17.getBaseOutlineStroke();
//     var12.setAxisLineStroke(var21);
//     var12.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
//     var31.setItemLabelPadding(var39);
//     java.awt.geom.Rectangle2D var41 = var31.getBounds();
//     org.jfree.chart.entity.AxisLabelEntity var44 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var12, (java.awt.Shape)var41, "hi!", "hi!");
//     var2.drawDomainGridline(var9, var10, var41, 0.0d);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.lang.Object var61 = var29.clone();
    double var62 = var29.getEndValue();
    java.lang.String var63 = var29.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }


    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var7 = null;
    var5.setSeriesPositiveItemLabelPosition(100, var7);
    double var9 = var5.getItemMargin();
    java.awt.Font var11 = null;
    var5.setSeriesItemLabelFont(0, var11);
    java.awt.Font var15 = var5.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("Polar Plot", var15);
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var21 = null;
    var19.setSeriesPositiveItemLabelPosition(100, var21);
    java.awt.Stroke var23 = var19.getBaseOutlineStroke();
    double var24 = var19.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var29 = var27.getSeriesNegativeItemLabelPosition(13);
    var19.setBasePositiveItemLabelPosition(var29, true);
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = null;
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
    var36.setLabel("");
    boolean var39 = var36.isAxisLineVisible();
    java.text.DateFormat var40 = var36.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var41 = null;
    org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, var41);
    org.jfree.chart.axis.ValueAxis var43 = var42.getAxis();
    org.jfree.chart.plot.IntervalMarker var46 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var47 = null;
    var46.notifyListeners(var47);
    org.jfree.chart.renderer.category.BarRenderer3D var51 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var54 = var51.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
    org.jfree.chart.util.RectangleInsets var56 = var55.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
    org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var69 = var66.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66);
    org.jfree.chart.util.RectangleInsets var71 = var70.getMargin();
    var63.setItemLabelPadding(var71);
    java.awt.geom.Rectangle2D var73 = var63.getBounds();
    java.awt.geom.Rectangle2D var76 = var56.createInsetRectangle(var73, false, false);
    var19.drawRangeMarker(var32, var33, var43, (org.jfree.chart.plot.Marker)var46, var76);
    java.lang.Object var78 = var46.clone();
    java.awt.Color var80 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var81 = var80.getBlue();
    var46.setOutlinePaint((java.awt.Paint)var80);
    org.jfree.chart.text.TextBlock var83 = org.jfree.chart.text.TextUtilities.createTextBlock("Polar Plot", var15, (java.awt.Paint)var80);
    org.jfree.chart.renderer.category.BarRenderer3D var86 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var88 = null;
    var86.setSeriesPositiveItemLabelPosition(100, var88);
    double var90 = var86.getItemMargin();
    java.awt.Font var92 = null;
    var86.setSeriesItemLabelFont(0, var92);
    java.awt.Paint var94 = var86.getBaseOutlinePaint();
    java.awt.Paint var95 = var86.getWallPaint();
    org.jfree.chart.text.TextBlock var96 = org.jfree.chart.text.TextUtilities.createTextBlock("", var15, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, (-1), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[][] var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    java.awt.Paint var51 = var50.getOutlinePaint();
    java.lang.Object var52 = null;
    boolean var53 = var50.equals(var52);
    boolean var54 = var50.isShapeFilled();
    org.jfree.chart.util.RectangleAnchor var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setShapeAnchor(var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    java.awt.Font var8 = null;
    var2.setSeriesItemLabelFont(0, var8);
    java.awt.Paint var10 = var2.getBaseOutlinePaint();
    java.awt.Paint var11 = var2.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var16 = null;
    var14.setSeriesPositiveItemLabelPosition(100, var16);
    java.awt.Stroke var18 = var14.getBaseOutlineStroke();
    java.lang.Object var19 = var14.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
    var22.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var30 = var22.getItemOutlineStroke(0, (-1));
    var14.setBaseStroke(var30);
    java.awt.Paint var32 = var14.getBaseItemLabelPaint();
    double var33 = var14.getItemLabelAnchorOffset();
    org.jfree.chart.labels.ItemLabelPosition var35 = var14.getSeriesPositiveItemLabelPosition(0);
    var2.setBasePositiveItemLabelPosition(var35);
    java.awt.Font var37 = var2.getBaseItemLabelFont();
    org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis("hi!");
    var39.setLabel("");
    boolean var42 = var39.isAxisLineVisible();
    java.text.DateFormat var43 = var39.getDateFormatOverride();
    org.jfree.chart.plot.Plot var44 = var39.getPlot();
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var49 = null;
    var47.setSeriesPositiveItemLabelPosition(100, var49);
    double var51 = var47.getItemMargin();
    java.awt.Font var53 = null;
    var47.setSeriesItemLabelFont(0, var53);
    java.awt.Paint var55 = var47.getBaseOutlinePaint();
    var39.setLabelPaint(var55);
    var2.setBaseItemLabelPaint(var55, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 13);
    java.lang.String var4 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "#64000d"+ "'", var4.equals("#64000d"));

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }


    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.SimpleTimePeriod var7 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var8 = var7.getEnd();
    org.jfree.data.gantt.Task var9 = new org.jfree.data.gantt.Task("", var4, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = var10.getNearestDayOfWeek(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     var3.setLabel("");
//     boolean var6 = var3.isAxisLineVisible();
//     java.text.DateFormat var7 = var3.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
//     var9.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     var12.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     var12.addSubtitle((org.jfree.chart.title.Title)var21);
//     java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     var12.handleClick(0, 0, var28);
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }
// 
// 
//     org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
//     org.jfree.data.category.CategoryDataset var4 = null;
//     java.lang.String var7 = var3.generateURL(var4, 1, 0);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var4);
//     int var6 = var5.getRollUnit();
//     int var7 = var5.getRollCount();
//     java.text.DateFormat var12 = null;
//     org.jfree.chart.axis.DateTickUnit var13 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var12);
//     int var14 = var13.getRollUnit();
//     int var15 = var13.getRollCount();
//     org.jfree.data.time.SimpleTimePeriod var18 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var19 = var18.getStart();
//     java.util.Date var20 = var13.rollDate(var19);
//     java.util.Date var21 = var5.rollDate(var20);
//     java.util.TimeZone var22 = null;
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year(var20, var22);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(1.0d, 10.0d);
    var2.setHeight(100.0d);
    var2.setHeight(100.0d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    boolean var4 = var1.isNegativeArrowVisible();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    var1.setStandardTickUnits(var7);
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var14 = var11.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    org.jfree.chart.util.RectangleInsets var23 = var22.getMargin();
    var15.setItemLabelPadding(var23);
    java.awt.geom.Rectangle2D var25 = var15.getBounds();
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    org.jfree.chart.util.RectangleInsets var33 = var32.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var39 = var36.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
    org.jfree.chart.util.RectangleInsets var48 = var47.getMargin();
    var40.setItemLabelPadding(var48);
    java.awt.geom.Rectangle2D var50 = var40.getBounds();
    java.awt.geom.Rectangle2D var53 = var33.createInsetRectangle(var50, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
    org.jfree.chart.util.RectangleInsets var61 = var60.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var64 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var67 = var64.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var64);
    org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var74 = var71.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var71);
    org.jfree.chart.util.RectangleInsets var76 = var75.getMargin();
    var68.setItemLabelPadding(var76);
    java.awt.geom.Rectangle2D var78 = var68.getBounds();
    java.awt.geom.Rectangle2D var81 = var61.createInsetRectangle(var78, false, false);
    boolean var82 = org.jfree.chart.util.ShapeUtilities.intersects(var53, var81);
    boolean var83 = org.jfree.chart.util.ShapeUtilities.intersects(var25, var53);
    org.jfree.chart.entity.ChartEntity var85 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var25, "Polar Plot");
    var1.setRightArrow((java.awt.Shape)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    java.awt.Font var8 = null;
    var2.setSeriesItemLabelFont(0, var8);
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
    var2.setSeriesItemLabelGenerator(1, var11, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.text.TextBlockAnchor var10 = null;
    var6.draw(var7, 0.0f, 100.0f, var10, 10.0f, 100.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelOffset();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var10.setSeriesPositiveItemLabelPosition(100, var12);
    java.awt.Stroke var14 = var10.getBaseOutlineStroke();
    var5.setAxisLineStroke(var14);
    var2.setStroke(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    boolean var7 = var2.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    var2.setBaseItemLabelGenerator(var8);
    boolean var10 = var2.getAutoPopulateSeriesOutlineStroke();
    boolean var13 = var2.getItemCreateEntity(1, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var55 = null;
    var53.setSeriesPositiveItemLabelPosition(100, var55);
    java.awt.Stroke var57 = var53.getBaseOutlineStroke();
    double var58 = var53.getItemMargin();
    org.jfree.chart.util.GradientPaintTransformer var59 = var53.getGradientPaintTransformer();
    var50.setFillPaintTransformer(var59);
    var50.setShapeVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getPadding();
    org.jfree.chart.block.BlockFrame var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setFrame(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    org.jfree.chart.axis.ValueAxis var10 = var9.getAxis();
    org.jfree.data.xy.XYDataset var11 = null;
    var9.setDataset(var11);
    org.jfree.chart.util.RectangleInsets var13 = var9.getInsets();
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var9.addChangeListener(var14);
    java.lang.String var16 = var9.getPlotType();
    boolean var17 = var9.isOutlineVisible();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    java.awt.Color var21 = java.awt.Color.getColor("", 10);
    var18.setBackgroundPaint((java.awt.Paint)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Polar Plot"+ "'", var16.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
    var35.setLabel("");
    boolean var38 = var35.isAxisLineVisible();
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 0.0d);
    var35.setRange(var41, true, true);
    var1.setRange(var41, false, false);
    org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(var41, 1.0d);
    org.jfree.chart.block.LengthConstraintType var50 = var49.getWidthConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setUpperBound(1.0d);
    var2.resizeRange((-1.0d), 100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var10.setSeriesPositiveItemLabelPosition(100, var12);
    double var14 = var10.getItemMargin();
    java.awt.Font var16 = null;
    var10.setSeriesItemLabelFont(0, var16);
    java.awt.Font var20 = var10.getItemLabelFont(0, (-1));
    var2.setTickLabelFont(var20);
    java.awt.Font var23 = null;
    java.awt.Paint var24 = null;
    org.jfree.chart.text.TextMeasurer var27 = null;
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, var24, 100.0f, 1, var27);
    java.util.List var29 = var28.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var36 = null;
    var34.setSeriesPositiveItemLabelPosition(100, var36);
    double var38 = var34.getItemMargin();
    java.awt.Font var40 = null;
    var34.setSeriesItemLabelFont(0, var40);
    java.awt.Font var44 = var34.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("Polar Plot", var44);
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("hi!");
    var49.setLabel("");
    boolean var52 = var49.isAxisLineVisible();
    java.text.DateFormat var53 = var49.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot(var47, (org.jfree.chart.axis.ValueAxis)var49, var54);
    var55.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var58 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var55);
    var55.setRadiusGridlinesVisible(false);
    java.awt.Paint var61 = var55.getOutlinePaint();
    var28.addLine("Polar Plot", var44, var61);
    org.jfree.chart.text.TextFragment var63 = new org.jfree.chart.text.TextFragment("", var20, var61);
    java.lang.String var64 = var63.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + ""+ "'", var64.equals(""));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(13);
    boolean var6 = var2.isSeriesItemLabelsVisible(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var7 = var2.lookupSeriesOutlineStroke(10);
    org.jfree.chart.urls.StandardCategoryURLGenerator var11 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    var2.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var11, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    boolean var2 = var1.getRenderAsPercentages();
    java.awt.Stroke var4 = var1.lookupSeriesOutlineStroke(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("", "");
    java.lang.String var3 = var2.getEmail();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.text.DateFormat var7 = null;
    org.jfree.chart.axis.DateTickUnit var8 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var7);
    var1.setTickUnit(var8, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    org.jfree.chart.plot.IntervalMarker var22 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var23 = null;
    var22.notifyListeners(var23);
    org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
    var22.setLabelPaint(var30);
    var19.setBackgroundPaint(var30);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
    var36.setLabel("");
    boolean var39 = var36.isAxisLineVisible();
    java.text.DateFormat var40 = var36.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var41 = null;
    org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, var41);
    var42.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var42);
    var45.setNotify(false);
    var45.clearSubtitles();
    var19.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var45);
    java.awt.geom.Rectangle2D var50 = var19.getBounds();
    org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53);
    org.jfree.chart.util.RectangleInsets var58 = var57.getMargin();
    org.jfree.chart.util.RectangleEdge var59 = var57.getLegendItemGraphicEdge();
    double var60 = var1.valueToJava2D(0.0d, var50, var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    java.awt.Stroke var20 = var16.getBaseOutlineStroke();
    double var21 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(13);
    var16.setBasePositiveItemLabelPosition(var26, true);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
    var33.setLabel("");
    boolean var36 = var33.isAxisLineVisible();
    java.text.DateFormat var37 = var33.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var38);
    org.jfree.chart.axis.ValueAxis var40 = var39.getAxis();
    org.jfree.chart.plot.IntervalMarker var43 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var44 = null;
    var43.notifyListeners(var44);
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.util.RectangleInsets var53 = var52.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
    var60.setItemLabelPadding(var68);
    java.awt.geom.Rectangle2D var70 = var60.getBounds();
    java.awt.geom.Rectangle2D var73 = var53.createInsetRectangle(var70, false, false);
    var16.drawRangeMarker(var29, var30, var40, (org.jfree.chart.plot.Marker)var43, var73);
    java.lang.Object var75 = var43.clone();
    java.awt.Color var77 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var78 = var77.getBlue();
    var43.setOutlinePaint((java.awt.Paint)var77);
    org.jfree.chart.block.LabelBlock var80 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", var13, (java.awt.Paint)var77);
    int var81 = var77.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == (-16777216));

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var10.setSeriesPositiveItemLabelPosition(100, var12);
    java.awt.Stroke var14 = var10.getBaseOutlineStroke();
    java.lang.Object var15 = var10.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    var18.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var26 = var18.getItemOutlineStroke(0, (-1));
    var10.setBaseStroke(var26);
    int var28 = var10.getRowCount();
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var33 = null;
    var31.setSeriesPositiveItemLabelPosition(100, var33);
    java.awt.Stroke var35 = var31.getBaseOutlineStroke();
    double var36 = var31.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var39 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var41 = var39.getSeriesNegativeItemLabelPosition(13);
    var31.setBasePositiveItemLabelPosition(var41, true);
    double var44 = var41.getAngle();
    var10.setBasePositiveItemLabelPosition(var41, false);
    var2.setBasePositiveItemLabelPosition(var41, false);
    java.awt.Graphics2D var49 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var55 = var52.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
    org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
    org.jfree.chart.util.RectangleInsets var64 = var63.getMargin();
    var56.setItemLabelPadding(var64);
    double var67 = var64.trimHeight((-1.0d));
    double var69 = var64.calculateLeftOutset(100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var72 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var75 = var72.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var72);
    org.jfree.chart.renderer.category.BarRenderer3D var79 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var82 = var79.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var83 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var79);
    org.jfree.chart.util.RectangleInsets var84 = var83.getMargin();
    var76.setItemLabelPadding(var84);
    java.awt.geom.Rectangle2D var86 = var76.getBounds();
    java.awt.geom.Rectangle2D var89 = var64.createInsetRectangle(var86, false, false);
    org.jfree.chart.plot.CategoryPlot var90 = null;
    org.jfree.chart.plot.PlotRenderingInfo var92 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var93 = var2.initialise(var49, var86, var90, 1, var92);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.chart.block.LengthConstraintType var15 = var14.getHeightConstraintType();
    org.jfree.chart.block.LengthConstraintType var16 = var14.getHeightConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("Polar Plot", var13);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.block.RectangleConstraint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var17 = var14.arrange(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    var18.setLabel("");
    boolean var21 = var18.isAxisLineVisible();
    java.text.DateFormat var22 = var18.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var23 = null;
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot(var16, (org.jfree.chart.axis.ValueAxis)var18, var23);
    org.jfree.chart.axis.ValueAxis var25 = var24.getAxis();
    org.jfree.data.xy.XYDataset var26 = null;
    var24.setDataset(var26);
    org.jfree.chart.util.RectangleInsets var28 = var24.getInsets();
    org.jfree.chart.event.PlotChangeListener var29 = null;
    var24.addChangeListener(var29);
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleAnchor var34 = null;
    java.awt.geom.Point2D var35 = org.jfree.chart.util.RectangleAnchor.coordinates(var33, var34);
    var24.zoomRangeAxes(10.0d, var32, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.zoomRangeAxes(100.0d, 0.0d, var15, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var8.addChangeListener(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleAnchor var18 = null;
    java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
    var8.zoomRangeAxes(10.0d, var16, var19);
    java.lang.Object var21 = var8.clone();
    var8.setForegroundAlpha(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateTickMarkPosition var34 = var1.getTickMarkPosition();
    java.awt.Color var36 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var37 = var36.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var41 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var42 = var36.equals((java.lang.Object)"");
    var1.setTickLabelPaint((java.awt.Paint)var36);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var1.setUpArrow(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }


    org.jfree.chart.block.Arrangement var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var6.arrange(var8);
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var14 = null;
//     var12.setSeriesPositiveItemLabelPosition(100, var14);
//     double var16 = var12.getItemMargin();
//     java.awt.Font var18 = null;
//     var12.setSeriesItemLabelFont(0, var18);
//     java.awt.Paint var20 = var12.getBaseOutlinePaint();
//     java.awt.Paint var21 = var12.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var26 = null;
//     var24.setSeriesPositiveItemLabelPosition(100, var26);
//     java.awt.Stroke var28 = var24.getBaseOutlineStroke();
//     java.lang.Object var29 = var24.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var35 = var32.getItemLabelPaint((-1), 100);
//     var32.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var40 = var32.getItemOutlineStroke(0, (-1));
//     var24.setBaseStroke(var40);
//     java.awt.Paint var42 = var24.getBaseItemLabelPaint();
//     double var43 = var24.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.ItemLabelPosition var45 = var24.getSeriesPositiveItemLabelPosition(0);
//     var12.setBasePositiveItemLabelPosition(var45);
//     java.awt.Font var47 = var12.getBaseItemLabelFont();
//     org.jfree.chart.LegendItemSource[] var48 = new org.jfree.chart.LegendItemSource[] { var12};
//     var6.setSources(var48);
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.util.Size2D var51 = var6.arrange(var50);
//     
//     // Checks the contract:  equals-hashcode on var9 and var51
//     assertTrue("Contract failed: equals-hashcode on var9 and var51", var9.equals(var51) ? var9.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var9
//     assertTrue("Contract failed: equals-hashcode on var51 and var9", var51.equals(var9) ? var51.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setLowerBound((-1.0d));
//     java.text.DateFormat var5 = var2.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
//     var7.setUpperBound(1.0d);
//     boolean var10 = var7.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
//     java.lang.Object var13 = var12.clone();
//     java.lang.Object var14 = var12.clone();
//     
//     // Checks the contract:  equals-hashcode on var13 and var14
//     assertTrue("Contract failed: equals-hashcode on var13 and var14", var13.equals(var14) ? var13.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var13
//     assertTrue("Contract failed: equals-hashcode on var14 and var13", var14.equals(var13) ? var14.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
    var50.setFillPaint(var56);
    org.jfree.chart.util.RectangleAnchor var58 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setShapeLocation(var58);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     double var7 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
//     var2.setBasePositiveItemLabelPosition(var12, true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
//     var2.setBaseToolTipGenerator(var15);
//     var2.setSeriesCreateEntities(1, (java.lang.Boolean)false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.plot.PlotOrientation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setOrientation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    double var15 = var14.getWidth();
    java.lang.String var16 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"+ "'", var16.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.axis.DateAxis var68 = new org.jfree.chart.axis.DateAxis("hi!");
    var68.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var73 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var75 = null;
    var73.setSeriesPositiveItemLabelPosition(100, var75);
    java.awt.Stroke var77 = var73.getBaseOutlineStroke();
    var68.setAxisLineStroke(var77);
    var63.setBaseOutlineStroke(var77);
    var29.setStroke(var77);
    double var81 = var29.getStartValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 1.0d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }


    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("hi!");
    var4.setLabel("");
    boolean var7 = var4.isAxisLineVisible();
    java.text.DateFormat var8 = var4.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, var9);
    var10.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var10);
    var10.setRadiusGridlinesVisible(false);
    java.awt.Paint var16 = var10.getOutlinePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var21 = null;
    var19.setSeriesPositiveItemLabelPosition(100, var21);
    java.awt.Stroke var23 = var19.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryMarker var24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)0L, var16, var23);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
    var27.setLabel("");
    boolean var30 = var27.isAxisLineVisible();
    java.text.DateFormat var31 = var27.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
    org.jfree.chart.axis.ValueAxis var34 = var33.getAxis();
    org.jfree.data.xy.XYDataset var35 = null;
    var33.setDataset(var35);
    org.jfree.chart.util.RectangleInsets var37 = var33.getInsets();
    var33.setAngleGridlinesVisible(true);
    boolean var40 = var24.equals((java.lang.Object)var33);
    org.jfree.chart.util.RectangleAnchor var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var24.setLabelAnchor(var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    var12.clearSubtitles();
    org.jfree.chart.event.ChartChangeListener var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.removeChangeListener(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var9.setRadiusGridlinesVisible(false);
    int var15 = var9.getSeriesCount();
    var9.setOutlineVisible(false);
    org.jfree.chart.renderer.PolarItemRenderer var18 = var9.getRenderer();
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var24 = var21.getItemLabelPaint((-1), 100);
    org.jfree.chart.labels.ItemLabelPosition var25 = var21.getPositiveItemLabelPositionFallback();
    boolean var28 = var21.isItemLabelVisible(1, 100);
    java.awt.Stroke var31 = var21.getItemStroke(1, (-1));
    boolean var32 = var9.equals((java.lang.Object)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.util.Size2D var9 = var6.arrange(var8);
    java.lang.String var10 = var9.toString();
    double var11 = var9.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var10.equals("Size2D[width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    double var17 = var14.trimHeight((-1.0d));
    double var19 = var14.calculateLeftOutset(100.0d);
    double var21 = var14.calculateRightInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    var1.centerRange(100.0d);
    var1.setVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
//     org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     var10.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
//     org.jfree.chart.LegendItemCollection var15 = var10.getLegendItems();
//     var7.addAll(var15);
//     
//     // Checks the contract:  equals-hashcode on var7 and var15
//     assertTrue("Contract failed: equals-hashcode on var7 and var15", var7.equals(var15) ? var7.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var7
//     assertTrue("Contract failed: equals-hashcode on var15 and var7", var15.equals(var7) ? var15.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }


    java.awt.Font var2 = null;
    java.awt.Paint var3 = null;
    org.jfree.chart.text.TextMeasurer var6 = null;
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 100.0f, 1, var6);
    java.util.List var8 = var7.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var15 = null;
    var13.setSeriesPositiveItemLabelPosition(100, var15);
    double var17 = var13.getItemMargin();
    java.awt.Font var19 = null;
    var13.setSeriesItemLabelFont(0, var19);
    java.awt.Font var23 = var13.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("Polar Plot", var23);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
    var28.setLabel("");
    boolean var31 = var28.isAxisLineVisible();
    java.text.DateFormat var32 = var28.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var33 = null;
    org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var33);
    var34.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var34);
    var34.setRadiusGridlinesVisible(false);
    java.awt.Paint var40 = var34.getOutlinePaint();
    var7.addLine("Polar Plot", var23, var40);
    org.jfree.chart.util.HorizontalAlignment var42 = var7.getLineAlignment();
    org.jfree.chart.text.TextBlockAnchor var43 = null;
    org.jfree.chart.text.TextAnchor var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var46 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)1L, var7, var43, var44, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getPadding();
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.LengthAdjustmentType var6 = null;
    org.jfree.chart.util.LengthAdjustmentType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var4.createAdjustedRectangle(var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var3 = null;
//     var2.notifyListeners(var3);
//     double var5 = var2.getEndValue();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("hi!");
//     var8.setLabel("");
//     boolean var11 = var8.isAxisLineVisible();
//     java.text.DateFormat var12 = var8.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, var13);
//     org.jfree.chart.event.AxisChangeEvent var15 = null;
//     var14.axisChanged(var15);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
//     var20.setLabel("");
//     boolean var23 = var20.isAxisLineVisible();
//     java.text.DateFormat var24 = var20.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var25 = null;
//     org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
//     var26.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
//     var29.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     var29.addSubtitle((org.jfree.chart.title.Title)var38);
//     java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
//     var14.setBackgroundImage((java.awt.Image)var42);
//     var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var14);
//     org.jfree.chart.plot.IntervalMarker var47 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var52 = null;
//     var50.setSeriesPositiveItemLabelPosition(100, var52);
//     java.awt.Stroke var54 = var50.getBaseOutlineStroke();
//     var47.setStroke(var54);
//     var2.setStroke(var54);
//     
//     // Checks the contract:  equals-hashcode on var2 and var47
//     assertTrue("Contract failed: equals-hashcode on var2 and var47", var2.equals(var47) ? var2.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var2
//     assertTrue("Contract failed: equals-hashcode on var47 and var2", var47.equals(var2) ? var47.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    boolean var3 = var2.getDrawOutlines();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "hi!");
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    boolean var7 = var4.equals((java.lang.Object)"");
    var4.setVersion("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setLowerBound((-1.0d));
//     java.text.DateFormat var5 = var2.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
//     var7.setUpperBound(1.0d);
//     boolean var10 = var7.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
//     var12.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var12.handleClick(1, 0, var16);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Stroke var5 = var2.getItemOutlineStroke((-1), (-1));
    boolean var8 = var2.getItemShapeVisible(10, 100);
    boolean var9 = var2.getUseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 10.0d, true);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    double var12 = var7.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(13);
    var7.setBasePositiveItemLabelPosition(var17, true);
    var3.setSeriesNegativeItemLabelPosition(100, var17, false);
    var3.setMinimumBarLength((-1.0d));
    boolean var24 = var3.getRenderAsPercentages();
    var3.setBase((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setAngleLabelsVisible(true);
    var8.setBackgroundImageAlignment(0);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    double var20 = var16.getItemMargin();
    java.awt.Font var22 = null;
    var16.setSeriesItemLabelFont(0, var22);
    java.awt.Font var26 = var16.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var31 = null;
    var29.setSeriesPositiveItemLabelPosition(100, var31);
    java.awt.Stroke var33 = var29.getBaseOutlineStroke();
    java.lang.Object var34 = var29.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var37 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var40 = var37.getItemLabelPaint((-1), 100);
    var37.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var45 = var37.getItemOutlineStroke(0, (-1));
    var29.setBaseStroke(var45);
    java.awt.Paint var47 = var29.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("", var26, var47);
    boolean var49 = var8.equals((java.lang.Object)var48);
    org.jfree.data.xy.XYDataset var50 = null;
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("hi!");
    var52.setLabel("");
    boolean var55 = var52.isAxisLineVisible();
    java.text.DateFormat var56 = var52.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var57 = null;
    org.jfree.chart.plot.PolarPlot var58 = new org.jfree.chart.plot.PolarPlot(var50, (org.jfree.chart.axis.ValueAxis)var52, var57);
    org.jfree.chart.axis.ValueAxis var59 = var58.getAxis();
    org.jfree.data.xy.XYDataset var60 = null;
    var58.setDataset(var60);
    org.jfree.chart.util.RectangleInsets var62 = var58.getInsets();
    org.jfree.chart.event.PlotChangeListener var63 = null;
    var58.addChangeListener(var63);
    org.jfree.chart.plot.PlotRenderingInfo var66 = null;
    java.awt.geom.Rectangle2D var67 = null;
    org.jfree.chart.util.RectangleAnchor var68 = null;
    java.awt.geom.Point2D var69 = org.jfree.chart.util.RectangleAnchor.coordinates(var67, var68);
    var58.zoomRangeAxes(10.0d, var66, var69);
    var8.setParent((org.jfree.chart.plot.Plot)var58);
    org.jfree.data.general.DatasetGroup var72 = var58.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var2.notifyListeners(var3);
    java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var7 = var6.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var11 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var12 = var6.equals((java.lang.Object)"");
    java.awt.color.ColorSpace var13 = var6.getColorSpace();
    var2.setLabelPaint((java.awt.Paint)var6);
    java.io.ObjectOutputStream var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint)var6, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }
// 
// 
//     java.util.Date var1 = null;
//     java.lang.Class var2 = null;
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("hi!");
//     var4.setAutoRangeMinimumSize(10.0d, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     org.jfree.chart.util.RectangleInsets var22 = var21.getMargin();
//     var14.setItemLabelPadding(var22);
//     java.awt.geom.Rectangle2D var24 = var14.getBounds();
//     var4.setLeftArrow((java.awt.Shape)var24);
//     org.jfree.data.time.SimpleTimePeriod var29 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SimpleTimePeriod var33 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var34 = var33.getEnd();
//     org.jfree.data.gantt.Task var35 = new org.jfree.data.gantt.Task("", var30, var34);
//     org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var41 = var38.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
//     org.jfree.chart.util.RectangleInsets var43 = var42.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var49 = var46.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46);
//     org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53);
//     org.jfree.chart.util.RectangleInsets var58 = var57.getMargin();
//     var50.setItemLabelPadding(var58);
//     java.awt.geom.Rectangle2D var60 = var50.getBounds();
//     java.awt.geom.Rectangle2D var63 = var43.createInsetRectangle(var60, false, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var69 = var66.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66);
//     org.jfree.chart.util.RectangleInsets var71 = var70.getMargin();
//     org.jfree.chart.util.RectangleEdge var72 = var70.getLegendItemGraphicEdge();
//     double var73 = var4.dateToJava2D(var34, var60, var72);
//     java.util.TimeZone var74 = null;
//     org.jfree.data.time.RegularTimePeriod var75 = org.jfree.data.time.RegularTimePeriod.createInstance(var2, var34, var74);
//     org.jfree.data.gantt.Task var76 = new org.jfree.data.gantt.Task("Polar Plot", var1, var34);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    boolean var4 = var1.isNegativeArrowVisible();
    double var5 = var1.getLabelAngle();
    boolean var7 = var1.isHiddenValue((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var5 = org.jfree.data.Range.shift(var2, 1.0d, false);
    java.lang.Object var6 = null;
    boolean var7 = var2.equals(var6);
    double var8 = var2.getCentralValue();
    double var9 = var2.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setAngleLabelsVisible(true);
    var8.setBackgroundImageAlignment(0);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    double var20 = var16.getItemMargin();
    java.awt.Font var22 = null;
    var16.setSeriesItemLabelFont(0, var22);
    java.awt.Font var26 = var16.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var31 = null;
    var29.setSeriesPositiveItemLabelPosition(100, var31);
    java.awt.Stroke var33 = var29.getBaseOutlineStroke();
    java.lang.Object var34 = var29.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var37 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var40 = var37.getItemLabelPaint((-1), 100);
    var37.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var45 = var37.getItemOutlineStroke(0, (-1));
    var29.setBaseStroke(var45);
    java.awt.Paint var47 = var29.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("", var26, var47);
    boolean var49 = var8.equals((java.lang.Object)var48);
    org.jfree.chart.axis.ValueAxis var50 = var8.getAxis();
    java.awt.Paint var51 = var50.getTickMarkPaint();
    boolean var52 = var50.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }


    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.SimpleTimePeriod var7 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var8 = var7.getEnd();
    org.jfree.data.gantt.Task var9 = new org.jfree.data.gantt.Task("", var4, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = var10.getNearestDayOfWeek(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.JFreeChart var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPieChart(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setPositiveArrowVisible(true);
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setBackgroundImageAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
    java.awt.Paint var8 = var2.getBasePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var39 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    boolean var40 = var33.equals((java.lang.Object)"hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("");
    java.lang.String var2 = var1.toString();
    java.lang.String var3 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: "+ "'", var2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: "+ "'", var3.equals("org.jfree.data.time.TimePeriodFormatException: "));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }


    java.awt.Font var2 = null;
    java.awt.Paint var3 = null;
    org.jfree.chart.text.TextMeasurer var6 = null;
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 100.0f, 1, var6);
    java.util.List var8 = var7.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var15 = null;
    var13.setSeriesPositiveItemLabelPosition(100, var15);
    double var17 = var13.getItemMargin();
    java.awt.Font var19 = null;
    var13.setSeriesItemLabelFont(0, var19);
    java.awt.Font var23 = var13.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("Polar Plot", var23);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
    var28.setLabel("");
    boolean var31 = var28.isAxisLineVisible();
    java.text.DateFormat var32 = var28.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var33 = null;
    org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var33);
    var34.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var34);
    var34.setRadiusGridlinesVisible(false);
    java.awt.Paint var40 = var34.getOutlinePaint();
    var7.addLine("Polar Plot", var23, var40);
    org.jfree.chart.text.TextBlockAnchor var42 = null;
    org.jfree.chart.text.TextAnchor var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var45 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var7, var42, var43, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.setLabel("");
//     org.jfree.chart.event.AxisChangeListener var4 = null;
//     var1.addChangeListener(var4);
//     org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var10 = null;
//     var8.setSeriesPositiveItemLabelPosition(100, var10);
//     java.awt.Stroke var12 = var8.getBaseOutlineStroke();
//     double var13 = var8.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(13);
//     var8.setBasePositiveItemLabelPosition(var18, true);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
//     var25.setLabel("");
//     boolean var28 = var25.isAxisLineVisible();
//     java.text.DateFormat var29 = var25.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var30 = null;
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.axis.ValueAxis var32 = var31.getAxis();
//     org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var35.notifyListeners(var36);
//     org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
//     org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
//     org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
//     var52.setItemLabelPadding(var60);
//     java.awt.geom.Rectangle2D var62 = var52.getBounds();
//     java.awt.geom.Rectangle2D var65 = var45.createInsetRectangle(var62, false, false);
//     var8.drawRangeMarker(var21, var22, var32, (org.jfree.chart.plot.Marker)var35, var65);
//     var1.setRightArrow((java.awt.Shape)var65);
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.DateAxis var70 = new org.jfree.chart.axis.DateAxis("hi!");
//     var70.setLabel("");
//     boolean var73 = var70.isAxisLineVisible();
//     java.text.DateFormat var74 = var70.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var75 = null;
//     org.jfree.chart.plot.PolarPlot var76 = new org.jfree.chart.plot.PolarPlot(var68, (org.jfree.chart.axis.ValueAxis)var70, var75);
//     org.jfree.chart.axis.ValueAxis var77 = var76.getAxis();
//     org.jfree.data.xy.XYDataset var78 = null;
//     var76.setDataset(var78);
//     org.jfree.chart.util.RectangleInsets var80 = var76.getInsets();
//     double var82 = var80.trimHeight(10.0d);
//     var1.setLabelInsets(var80);
//     
//     // Checks the contract:  equals-hashcode on var31 and var76
//     assertTrue("Contract failed: equals-hashcode on var31 and var76", var31.equals(var76) ? var31.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var31
//     assertTrue("Contract failed: equals-hashcode on var76 and var31", var76.equals(var31) ? var76.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    var50.setLineVisible(false);
    var50.setHeight(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(13);
    java.awt.Stroke var6 = var2.lookupSeriesOutlineStroke(100);
    var2.setBaseSeriesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    java.lang.Boolean var9 = var2.getSeriesItemLabelsVisible(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    var12.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var17 = var12.getDomainAxisEdge();
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.awt.Shape var23 = var19.getUpArrow();
    boolean var25 = var19.isHiddenValue(1L);
    int var26 = var12.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }


    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
    var6.setLabel("");
    boolean var9 = var6.isAxisLineVisible();
    java.text.DateFormat var10 = var6.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var11 = null;
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var11);
    var12.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var12);
    var15.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var23 = var20.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    var15.addSubtitle((org.jfree.chart.title.Title)var24);
    java.awt.image.BufferedImage var28 = var15.createBufferedImage(10, 1);
    org.jfree.chart.ui.ProjectInfo var32 = new org.jfree.chart.ui.ProjectInfo("", "Polar Plot", "", (java.awt.Image)var28, "Polar Plot", "Polar Plot", "Polar Plot");
    var32.setLicenceText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     double var6 = var2.getItemMargin();
//     java.awt.Font var8 = null;
//     var2.setSeriesItemLabelFont(0, var8);
//     java.awt.Paint var10 = var2.getBaseOutlinePaint();
//     java.awt.Paint var11 = var2.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var16 = null;
//     var14.setSeriesPositiveItemLabelPosition(100, var16);
//     java.awt.Stroke var18 = var14.getBaseOutlineStroke();
//     java.lang.Object var19 = var14.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
//     var22.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var30 = var22.getItemOutlineStroke(0, (-1));
//     var14.setBaseStroke(var30);
//     java.awt.Paint var32 = var14.getBaseItemLabelPaint();
//     double var33 = var14.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.ItemLabelPosition var35 = var14.getSeriesPositiveItemLabelPosition(0);
//     var2.setBasePositiveItemLabelPosition(var35);
//     java.awt.Font var37 = var2.getBaseItemLabelFont();
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     var2.drawOutline(var38, var39, var40);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.lang.Object var61 = var29.clone();
    float var62 = var29.getAlpha();
    var29.setLabel("Range[0.0,0.0]");
    double var65 = var29.getEndValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 10.0d);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     var1.setAutoRangeMinimumSize(100.0d, false);
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
//     var9.setAutoRangeMinimumSize(10.0d, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getMargin();
//     var19.setItemLabelPadding(var27);
//     java.awt.geom.Rectangle2D var29 = var19.getBounds();
//     var9.setLeftArrow((java.awt.Shape)var29);
//     org.jfree.data.time.SimpleTimePeriod var34 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var35 = var34.getStart();
//     org.jfree.data.time.SimpleTimePeriod var38 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var39 = var38.getEnd();
//     org.jfree.data.gantt.Task var40 = new org.jfree.data.gantt.Task("", var35, var39);
//     org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
//     org.jfree.chart.util.RectangleInsets var48 = var47.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var51 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var54 = var51.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
//     org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var61 = var58.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
//     org.jfree.chart.util.RectangleInsets var63 = var62.getMargin();
//     var55.setItemLabelPadding(var63);
//     java.awt.geom.Rectangle2D var65 = var55.getBounds();
//     java.awt.geom.Rectangle2D var68 = var48.createInsetRectangle(var65, false, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var74 = var71.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var71);
//     org.jfree.chart.util.RectangleInsets var76 = var75.getMargin();
//     org.jfree.chart.util.RectangleEdge var77 = var75.getLegendItemGraphicEdge();
//     double var78 = var9.dateToJava2D(var39, var65, var77);
//     double var79 = var1.java2DToValue((-1.0d), var7, var77);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "(100.0, 10.0)"};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLowerBound((-1.0d));
    java.text.DateFormat var6 = var3.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("hi!");
    var8.setUpperBound(1.0d);
    boolean var11 = var8.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var8, var12);
    org.jfree.chart.plot.PlotOrientation var14 = var13.getOrientation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var5 = null;
//     var3.setSeriesPositiveItemLabelPosition(100, var5);
//     double var7 = var3.getItemMargin();
//     java.awt.Font var9 = null;
//     var3.setSeriesItemLabelFont(0, var9);
//     java.awt.Paint var11 = var3.getBaseOutlinePaint();
//     java.awt.Paint var12 = var3.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var17 = null;
//     var15.setSeriesPositiveItemLabelPosition(100, var17);
//     java.awt.Stroke var19 = var15.getBaseOutlineStroke();
//     java.lang.Object var20 = var15.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
//     var23.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var31 = var23.getItemOutlineStroke(0, (-1));
//     var15.setBaseStroke(var31);
//     java.awt.Paint var33 = var15.getBaseItemLabelPaint();
//     double var34 = var15.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.ItemLabelPosition var36 = var15.getSeriesPositiveItemLabelPosition(0);
//     var3.setBasePositiveItemLabelPosition(var36);
//     java.awt.Font var38 = var3.getBaseItemLabelFont();
//     java.awt.Color var40 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     org.jfree.chart.text.TextMeasurer var42 = null;
//     org.jfree.chart.text.TextBlock var43 = org.jfree.chart.text.TextUtilities.createTextBlock("#64000d", var38, (java.awt.Paint)var40, (-1.0f), var42);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    var12.setForegroundAlpha(100.0f);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setLabel("");
    boolean var25 = var22.isAxisLineVisible();
    java.text.DateFormat var26 = var22.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var27 = null;
    org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, var27);
    org.jfree.chart.axis.ValueAxis var29 = var28.getAxis();
    org.jfree.data.xy.XYDataset var30 = null;
    var28.setDataset(var30);
    org.jfree.chart.util.RectangleInsets var32 = var28.getInsets();
    org.jfree.chart.event.PlotChangeListener var33 = null;
    var28.addChangeListener(var33);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleAnchor var38 = null;
    java.awt.geom.Point2D var39 = org.jfree.chart.util.RectangleAnchor.coordinates(var37, var38);
    var28.zoomRangeAxes(10.0d, var36, var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.zoomDomainAxes(100.0d, (-1.0d), var19, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    java.awt.Paint var12 = var8.getNoDataMessagePaint();
    java.awt.Paint var13 = var8.getRadiusGridlinePaint();
    var8.clearCornerTextItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var10 = var7.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    var11.setItemLabelPadding(var19);
    java.awt.geom.Rectangle2D var21 = var11.getBounds();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLabel("");
    boolean var28 = var25.isAxisLineVisible();
    java.text.DateFormat var29 = var25.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var30);
    var31.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var31);
    var34.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var39 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var42 = var39.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
    var34.addSubtitle((org.jfree.chart.title.Title)var43);
    java.awt.image.BufferedImage var47 = var34.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var53 = var50.getItemLabelPaint((-1), 100);
    var34.setBackgroundPaint(var53);
    org.jfree.chart.title.LegendGraphic var55 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var21, var53);
    org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var61 = var58.getItemLabelPaint((-1), 100);
    var55.setFillPaint(var61);
    org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var67 = null;
    var65.setSeriesPositiveItemLabelPosition(100, var67);
    double var69 = var65.getItemMargin();
    java.awt.Font var71 = null;
    var65.setSeriesItemLabelFont(0, var71);
    java.awt.Paint var73 = var65.getBaseOutlinePaint();
    java.awt.Paint var74 = var65.getWallPaint();
    boolean var75 = org.jfree.chart.util.PaintUtilities.equal(var61, var74);
    java.awt.Stroke var76 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var79 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var82 = var79.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var83 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var79);
    double var84 = var79.getItemMargin();
    java.awt.Font var86 = var79.getSeriesItemLabelFont((-1));
    java.awt.Color var88 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var89 = var88.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var93 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var94 = var88.equals((java.lang.Object)"");
    var79.setBasePaint((java.awt.Paint)var88, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var97 = new org.jfree.chart.LegendItem(var0, "", "Range[0.0,0.0]", "Range[0.0,0.0]", var4, var61, var76, (java.awt.Paint)var88);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    var1.resizeRange((-1.0d), 100.0d);
    var1.resizeRange(1.0d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLowerBound((-1.0d));
    java.text.DateFormat var4 = var1.getDateFormatOverride();
    java.awt.Shape var5 = var1.getLeftArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.setUpperBound(1.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var8 = null;
//     var6.setSeriesPositiveItemLabelPosition(100, var8);
//     java.awt.Stroke var10 = var6.getBaseOutlineStroke();
//     var1.setAxisLineStroke(var10);
//     var1.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
//     org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
//     org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
//     var20.setItemLabelPadding(var28);
//     java.awt.geom.Rectangle2D var30 = var20.getBounds();
//     org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
//     java.awt.Shape var34 = null;
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
//     var36.setUpperBound(1.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var43 = null;
//     var41.setSeriesPositiveItemLabelPosition(100, var43);
//     java.awt.Stroke var45 = var41.getBaseOutlineStroke();
//     var36.setAxisLineStroke(var45);
//     var36.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var51 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var54 = var51.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
//     org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var61 = var58.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
//     org.jfree.chart.util.RectangleInsets var63 = var62.getMargin();
//     var55.setItemLabelPadding(var63);
//     java.awt.geom.Rectangle2D var65 = var55.getBounds();
//     org.jfree.chart.entity.AxisLabelEntity var68 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var36, (java.awt.Shape)var65, "hi!", "hi!");
//     boolean var69 = org.jfree.chart.util.ShapeUtilities.equal(var34, (java.awt.Shape)var65);
//     boolean var70 = org.jfree.chart.util.ShapeUtilities.intersects(var30, var65);
//     
//     // Checks the contract:  equals-hashcode on var33 and var68
//     assertTrue("Contract failed: equals-hashcode on var33 and var68", var33.equals(var68) ? var33.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var33
//     assertTrue("Contract failed: equals-hashcode on var68 and var33", var68.equals(var33) ? var68.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "hi!");
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var7 = var4.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var7 = null;
    var5.setSeriesPositiveItemLabelPosition(100, var7);
    java.awt.Stroke var9 = var5.getBaseOutlineStroke();
    var2.setStroke(var9);
    org.jfree.chart.util.RectangleInsets var11 = var2.getLabelOffset();
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
    var14.setLabel("");
    boolean var17 = var14.isAxisLineVisible();
    java.text.DateFormat var18 = var14.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var19 = null;
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var19);
    var20.setAngleLabelsVisible(true);
    var20.setBackgroundImageAlignment(0);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var30 = null;
    var28.setSeriesPositiveItemLabelPosition(100, var30);
    double var32 = var28.getItemMargin();
    java.awt.Font var34 = null;
    var28.setSeriesItemLabelFont(0, var34);
    java.awt.Font var38 = var28.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var43 = null;
    var41.setSeriesPositiveItemLabelPosition(100, var43);
    java.awt.Stroke var45 = var41.getBaseOutlineStroke();
    java.lang.Object var46 = var41.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    var49.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var57 = var49.getItemOutlineStroke(0, (-1));
    var41.setBaseStroke(var57);
    java.awt.Paint var59 = var41.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("", var38, var59);
    boolean var61 = var20.equals((java.lang.Object)var60);
    org.jfree.chart.axis.ValueAxis var62 = var20.getAxis();
    java.awt.Paint var63 = var62.getTickMarkPaint();
    var2.setLabelPaint(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.lang.Object var61 = var29.clone();
    double var62 = var29.getEndValue();
    float var63 = var29.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.8f);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
    org.jfree.chart.util.RectangleInsets var8 = var6.getLegendItemGraphicPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    org.jfree.chart.event.AxisChangeListener var4 = null;
    var1.addChangeListener(var4);
    boolean var6 = var1.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.text.DateFormat var3 = var1.getDateFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    var50.setPadding((-1.0d), 100.0d, 0.0d, 100.0d);
    java.awt.Stroke var56 = null;
    var50.setOutlineStroke(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setLabel("");
//     boolean var5 = var2.isAxisLineVisible();
//     java.text.DateFormat var6 = var2.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
//     org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
//     org.jfree.data.xy.XYDataset var10 = null;
//     var8.setDataset(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
//     var16.setLabel("");
//     boolean var19 = var16.isAxisLineVisible();
//     java.text.DateFormat var20 = var16.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var21 = null;
//     org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var21);
//     var22.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var22);
//     var25.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     var25.addSubtitle((org.jfree.chart.title.Title)var34);
//     java.awt.image.BufferedImage var38 = var25.createBufferedImage(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var44 = var41.getItemLabelPaint((-1), 100);
//     var25.setBackgroundPaint(var44);
//     org.jfree.chart.event.ChartChangeEvent var46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var25);
//     
//     // Checks the contract:  equals-hashcode on var8 and var22
//     assertTrue("Contract failed: equals-hashcode on var8 and var22", var8.equals(var22) ? var8.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var8
//     assertTrue("Contract failed: equals-hashcode on var22 and var8", var22.equals(var8) ? var22.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.setLabel("");
//     boolean var4 = var1.isAxisLineVisible();
//     org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
//     var1.setRange(var7, true, true);
//     boolean var11 = var1.isAutoRange();
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
//     var14.setLabel("");
//     boolean var17 = var14.isAxisLineVisible();
//     java.text.DateFormat var18 = var14.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var19);
//     org.jfree.chart.axis.ValueAxis var21 = var20.getAxis();
//     org.jfree.data.xy.XYDataset var22 = null;
//     var20.setDataset(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var20.getInsets();
//     double var26 = var24.trimHeight(10.0d);
//     var1.setLabelInsets(var24);
//     org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     org.jfree.chart.plot.IntervalMarker var37 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var38 = null;
//     var37.notifyListeners(var38);
//     org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
//     var37.setLabelPaint(var45);
//     var34.setBackgroundPaint(var45);
//     org.jfree.data.xy.XYDataset var49 = null;
//     org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis("hi!");
//     var51.setLabel("");
//     boolean var54 = var51.isAxisLineVisible();
//     java.text.DateFormat var55 = var51.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var56 = null;
//     org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot(var49, (org.jfree.chart.axis.ValueAxis)var51, var56);
//     var57.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var60 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var57);
//     var60.setNotify(false);
//     var60.clearSubtitles();
//     var34.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var60);
//     java.awt.geom.Rectangle2D var65 = var34.getBounds();
//     org.jfree.chart.util.LengthAdjustmentType var66 = null;
//     org.jfree.chart.util.LengthAdjustmentType var67 = null;
//     java.awt.geom.Rectangle2D var68 = var24.createAdjustedRectangle(var65, var66, var67);
//     
//     // Checks the contract:  equals-hashcode on var20 and var57
//     assertTrue("Contract failed: equals-hashcode on var20 and var57", var20.equals(var57) ? var20.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var20
//     assertTrue("Contract failed: equals-hashcode on var57 and var20", var57.equals(var20) ? var57.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    org.jfree.chart.util.RectangleInsets var51 = var50.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("DateTickUnit[YEAR, -1]", var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("#64000d", var1, (-1.0f), 100.0f, 0.0d, 10.0f, (-1.0f));
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var17 = null;
    var16.notifyListeners(var17);
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var24 = var21.getItemLabelPaint((-1), 100);
    var16.setLabelPaint(var24);
    org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine("hi!", var13, var24);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
    var30.setLabel("");
    boolean var33 = var30.isAxisLineVisible();
    java.text.DateFormat var34 = var30.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var35 = null;
    org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, var35);
    var36.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var36);
    var39.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var44 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var47 = var44.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var44);
    var39.addSubtitle((org.jfree.chart.title.Title)var48);
    java.awt.image.BufferedImage var52 = var39.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    var39.setBackgroundPaint(var58);
    boolean var60 = var26.equals((java.lang.Object)var58);
    org.jfree.chart.text.TextFragment var61 = var26.getFirstTextFragment();
    float var62 = var61.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0f);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test287"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var2.notifyListeners(var3);
    org.jfree.chart.util.RectangleInsets var5 = var2.getLabelOffset();
    double var7 = var5.extendHeight(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 16.0d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test288"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 13);
    float[] var5 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var3.getRGBComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test289"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
//     org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot(var8);
//     org.jfree.data.category.CategoryDataset var10 = null;
//     var9.setDataset(var10);
//     org.jfree.chart.LegendItemCollection var12 = var9.getLegendItems();
//     var7.addAll(var12);
//     
//     // Checks the contract:  equals-hashcode on var7 and var12
//     assertTrue("Contract failed: equals-hashcode on var7 and var12", var7.equals(var12) ? var7.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var7
//     assertTrue("Contract failed: equals-hashcode on var12 and var7", var12.equals(var7) ? var12.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test290"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(100, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test291"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)100.0d, (java.lang.Number)10.0f);
    java.lang.String var3 = var2.toString();
    java.lang.Number var4 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "(100.0, 10.0)"+ "'", var3.equals("(100.0, 10.0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10.0f+ "'", var4.equals(10.0f));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test292"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.text.DateFormat var5 = var1.getDateFormatOverride();
    org.jfree.chart.plot.Plot var6 = var1.getPlot();
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    var9.setSeriesPositiveItemLabelPosition(100, var11);
    double var13 = var9.getItemMargin();
    java.awt.Font var15 = null;
    var9.setSeriesItemLabelFont(0, var15);
    java.awt.Paint var17 = var9.getBaseOutlinePaint();
    var1.setLabelPaint(var17);
    java.lang.String var19 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + ""+ "'", var19.equals(""));

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test293"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
    org.jfree.chart.title.LegendTitle var26 = var12.getLegend();
    org.jfree.chart.ChartRenderingInfo var31 = null;
    java.awt.image.BufferedImage var32 = var12.createBufferedImage(1, 100, (-1.0d), 0.0d, var31);
    org.jfree.chart.util.RectangleInsets var33 = var12.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test294"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var8.addChangeListener(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleAnchor var18 = null;
    java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
    var8.zoomRangeAxes(10.0d, var16, var19);
    java.lang.Object var21 = var8.clone();
    boolean var22 = var8.isSubplot();
    var8.setAngleLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test295"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    java.awt.Paint var51 = var50.getOutlinePaint();
    org.jfree.chart.util.RectangleAnchor var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setShapeLocation(var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test296"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.awt.Shape var7 = var3.getUpArrow();
    var1.setRightArrow(var7);
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var7, "", "");
    java.lang.String var12 = var11.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test297"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    var8.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("hi!");
    var13.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var20 = null;
    var18.setSeriesPositiveItemLabelPosition(100, var20);
    java.awt.Stroke var22 = var18.getBaseOutlineStroke();
    var13.setAxisLineStroke(var22);
    var13.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
    org.jfree.chart.util.RectangleInsets var40 = var39.getMargin();
    var32.setItemLabelPadding(var40);
    java.awt.geom.Rectangle2D var42 = var32.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var45 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var13, (java.awt.Shape)var42, "hi!", "hi!");
    java.awt.Shape var46 = var45.getArea();
    boolean var47 = var8.equals((java.lang.Object)var45);
    org.jfree.chart.event.RendererChangeEvent var48 = null;
    var8.rendererChanged(var48);
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var54 = null;
    var52.setSeriesPositiveItemLabelPosition(100, var54);
    double var56 = var52.getItemMargin();
    boolean var57 = var52.getAutoPopulateSeriesOutlineStroke();
    java.awt.Stroke var58 = var52.getBaseStroke();
    var8.setAngleGridlineStroke(var58);
    boolean var60 = var8.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test298"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
    var10.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var18 = var10.getItemOutlineStroke(0, (-1));
    var2.setBaseStroke(var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var25 = null;
    var23.setSeriesPositiveItemLabelPosition(100, var25);
    java.awt.Stroke var27 = var23.getBaseOutlineStroke();
    double var28 = var23.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var33 = var31.getSeriesNegativeItemLabelPosition(13);
    var23.setBasePositiveItemLabelPosition(var33, true);
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = null;
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis("hi!");
    var40.setLabel("");
    boolean var43 = var40.isAxisLineVisible();
    java.text.DateFormat var44 = var40.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var45 = null;
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot(var38, (org.jfree.chart.axis.ValueAxis)var40, var45);
    org.jfree.chart.axis.ValueAxis var47 = var46.getAxis();
    org.jfree.chart.plot.IntervalMarker var50 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var51 = null;
    var50.notifyListeners(var51);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.renderer.category.BarRenderer3D var70 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var73 = var70.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var70);
    org.jfree.chart.util.RectangleInsets var75 = var74.getMargin();
    var67.setItemLabelPadding(var75);
    java.awt.geom.Rectangle2D var77 = var67.getBounds();
    java.awt.geom.Rectangle2D var80 = var60.createInsetRectangle(var77, false, false);
    var23.drawRangeMarker(var36, var37, var47, (org.jfree.chart.plot.Marker)var50, var80);
    org.jfree.chart.plot.CategoryPlot var82 = null;
    org.jfree.chart.plot.PlotRenderingInfo var84 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var85 = var2.initialise(var20, var80, var82, 100, var84);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test299"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    var2.setAxisLineStroke(var11);
    var2.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.util.RectangleInsets var29 = var28.getMargin();
    var21.setItemLabelPadding(var29);
    java.awt.geom.Rectangle2D var31 = var21.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var31, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
    var36.setLabel("");
    boolean var39 = var36.isAxisLineVisible();
    org.jfree.data.Range var42 = new org.jfree.data.Range(0.0d, 0.0d);
    var36.setRange(var42, true, true);
    var2.setRange(var42, false, false);
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(var42, 1.0d);
    org.jfree.data.KeyedObject var51 = new org.jfree.data.KeyedObject((java.lang.Comparable)0.0f, (java.lang.Object)var42);
    java.lang.Comparable var52 = var51.getKey();
    java.lang.Object var53 = var51.getObject();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + 0.0f+ "'", var52.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test300"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)(short)10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test301"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var14 = null;
    var12.setSeriesPositiveItemLabelPosition(100, var14);
    double var16 = var12.getItemMargin();
    java.awt.Font var18 = null;
    var12.setSeriesItemLabelFont(0, var18);
    java.awt.Font var22 = var12.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("Polar Plot", var22);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
    var27.setLabel("");
    boolean var30 = var27.isAxisLineVisible();
    java.text.DateFormat var31 = var27.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
    var33.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var33);
    var33.setRadiusGridlinesVisible(false);
    java.awt.Paint var39 = var33.getOutlinePaint();
    var6.addLine("Polar Plot", var22, var39);
    org.jfree.chart.util.HorizontalAlignment var41 = var6.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 0.0d);
    org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis("hi!");
    var47.setLabel("");
    boolean var50 = var47.isAxisLineVisible();
    org.jfree.data.Range var53 = new org.jfree.data.Range(0.0d, 0.0d);
    var47.setRange(var53, true, true);
    org.jfree.data.Range var59 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var60 = new org.jfree.chart.block.RectangleConstraint(var53, var59);
    double var61 = var60.getWidth();
    boolean var62 = var45.equals((java.lang.Object)var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test302"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    boolean var8 = var2.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test303"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Stroke var5 = var2.getItemOutlineStroke((-1), (-1));
    boolean var6 = var2.getDrawOutlines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test304"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, (-1.0f), (-1.0f), 100.0d, 100.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test305"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var8.setSeriesPositiveItemLabelPosition(100, var10);
    double var12 = var8.getItemMargin();
    java.awt.Font var14 = null;
    var8.setSeriesItemLabelFont(0, var14);
    java.awt.Font var18 = var8.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("Polar Plot", var18);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var25 = null;
    var23.setSeriesPositiveItemLabelPosition(100, var25);
    double var27 = var23.getItemMargin();
    java.awt.Font var29 = null;
    var23.setSeriesItemLabelFont(0, var29);
    java.awt.Font var33 = var23.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var38 = null;
    var36.setSeriesPositiveItemLabelPosition(100, var38);
    java.awt.Stroke var40 = var36.getBaseOutlineStroke();
    java.lang.Object var41 = var36.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var44 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var47 = var44.getItemLabelPaint((-1), 100);
    var44.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var52 = var44.getItemOutlineStroke(0, (-1));
    var36.setBaseStroke(var52);
    java.awt.Paint var54 = var36.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("", var33, var54);
    var19.setFont(var33);
    org.jfree.chart.axis.MarkerAxisBand var57 = new org.jfree.chart.axis.MarkerAxisBand(var0, (-1.0d), 0.0d, (-1.0d), 100.0d, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test306"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     var3.setLabel("");
//     boolean var6 = var3.isAxisLineVisible();
//     java.text.DateFormat var7 = var3.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
//     var9.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     var12.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     var12.addSubtitle((org.jfree.chart.title.Title)var21);
//     java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
//     var12.setBackgroundPaint(var31);
//     var12.fireChartChanged();
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
//     var36.setUpperBound(1.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var43 = null;
//     var41.setSeriesPositiveItemLabelPosition(100, var43);
//     java.awt.Stroke var45 = var41.getBaseOutlineStroke();
//     var36.setAxisLineStroke(var45);
//     var36.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var51 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var54 = var51.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
//     org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var61 = var58.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
//     org.jfree.chart.util.RectangleInsets var63 = var62.getMargin();
//     var55.setItemLabelPadding(var63);
//     java.awt.geom.Rectangle2D var65 = var55.getBounds();
//     org.jfree.chart.entity.AxisLabelEntity var68 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var36, (java.awt.Shape)var65, "hi!", "hi!");
//     java.awt.geom.Point2D var69 = null;
//     org.jfree.chart.ChartRenderingInfo var70 = null;
//     var12.draw(var34, var65, var69, var70);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test307"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("Polar Plot", var13);
    double var15 = var14.getHeight();
    var14.setID("Range[0.0,0.0]");
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var27 = null;
    var25.setSeriesPositiveItemLabelPosition(100, var27);
    java.awt.Stroke var29 = var25.getBaseOutlineStroke();
    var20.setAxisLineStroke(var29);
    var20.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.util.RectangleInsets var47 = var46.getMargin();
    var39.setItemLabelPadding(var47);
    java.awt.geom.Rectangle2D var49 = var39.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var52 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var20, (java.awt.Shape)var49, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("hi!");
    var54.setLabel("");
    boolean var57 = var54.isAxisLineVisible();
    org.jfree.data.Range var60 = new org.jfree.data.Range(0.0d, 0.0d);
    var54.setRange(var60, true, true);
    var20.setRange(var60, false, false);
    org.jfree.chart.block.RectangleConstraint var68 = new org.jfree.chart.block.RectangleConstraint(var60, 1.0d);
    double var69 = var68.getWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var70 = var14.arrange(var18, var68);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test308"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
    org.jfree.chart.title.LegendTitle var26 = var12.getLegend();
    org.jfree.chart.ChartRenderingInfo var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var32 = var12.createBufferedImage(10, 0, (-1.0d), 1.0d, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test309"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    boolean var61 = var26.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test310"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.text.DateFormat var3 = var1.getDateFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test311"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test312"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    var50.setLineVisible(true);
    var50.setID("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test313"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test314"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.lang.String var2 = var1.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test315"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    var2.setBaseSeriesVisible(false);
    java.lang.Boolean var10 = var2.getSeriesItemLabelsVisible(13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
    var2.setBaseItemLabelGenerator(var11, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test316"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
    var35.setLabel("");
    boolean var38 = var35.isAxisLineVisible();
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 0.0d);
    var35.setRange(var41, true, true);
    var1.setRange(var41, false, false);
    var1.setLabelURL("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test317"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
    double var8 = var6.getContentXOffset();
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var14 = var11.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    org.jfree.chart.util.RectangleInsets var16 = var15.getMargin();
    org.jfree.chart.util.RectangleEdge var17 = var15.getLegendItemGraphicEdge();
    var6.setLegendItemGraphicEdge(var17);
    var6.setID("org.jfree.data.time.TimePeriodFormatException: ");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test318"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.removeCategoryLabelToolTip((java.lang.Comparable)16.0d);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test319"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.text.DateFormat var7 = null;
//     org.jfree.chart.axis.DateTickUnit var8 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var7);
//     var1.setTickUnit(var8, false, false);
//     java.text.DateFormat var16 = null;
//     org.jfree.chart.axis.DateTickUnit var17 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var16);
//     int var18 = var17.getRollUnit();
//     int var19 = var17.getRollCount();
//     org.jfree.data.time.SimpleTimePeriod var22 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var23 = var22.getStart();
//     java.util.Date var24 = var17.rollDate(var23);
//     java.util.TimeZone var25 = null;
//     java.util.Date var26 = var8.addToDate(var23, var25);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test320"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test321"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)100.0d, (java.lang.Number)10.0f);
    java.lang.Number var3 = var2.getValue();
    java.lang.Number var4 = null;
    var2.setValue(var4);
    boolean var7 = var2.equals((java.lang.Object)(byte)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0f+ "'", var3.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test322"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod((-1L), 0L);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test323"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var12.getRangeMarkers(10, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test324"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    var12.setBackgroundPaint(var31);
    var12.setBackgroundImageAlpha(1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var35 = var12.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test325"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Nearest"+ "'", var1.equals("Nearest"));

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test326"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    boolean var12 = var8.isRangeZoomable();
    java.lang.Object var13 = var8.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test327"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
//     java.util.List var7 = var6.getLines();
//     java.util.List var8 = var6.getLines();
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var14 = null;
//     var12.setSeriesPositiveItemLabelPosition(100, var14);
//     double var16 = var12.getItemMargin();
//     java.awt.Font var18 = null;
//     var12.setSeriesItemLabelFont(0, var18);
//     java.awt.Font var22 = var12.getItemLabelFont(0, (-1));
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var26 = null;
//     var25.notifyListeners(var26);
//     org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
//     var25.setLabelPaint(var33);
//     org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("hi!", var22, var33);
//     var6.addLine(var35);
//     java.awt.Font var38 = null;
//     java.awt.Paint var39 = null;
//     org.jfree.chart.text.TextMeasurer var42 = null;
//     org.jfree.chart.text.TextBlock var43 = org.jfree.chart.text.TextUtilities.createTextBlock("", var38, var39, 100.0f, 1, var42);
//     java.util.List var44 = var43.getLines();
//     java.awt.Font var46 = null;
//     java.awt.Paint var47 = null;
//     org.jfree.chart.text.TextMeasurer var50 = null;
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, var47, 100.0f, 1, var50);
//     java.util.List var52 = var51.getLines();
//     java.util.List var53 = var51.getLines();
//     org.jfree.chart.renderer.category.BarRenderer3D var57 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var59 = null;
//     var57.setSeriesPositiveItemLabelPosition(100, var59);
//     double var61 = var57.getItemMargin();
//     java.awt.Font var63 = null;
//     var57.setSeriesItemLabelFont(0, var63);
//     java.awt.Font var67 = var57.getItemLabelFont(0, (-1));
//     org.jfree.chart.plot.IntervalMarker var70 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var71 = null;
//     var70.notifyListeners(var71);
//     org.jfree.chart.renderer.category.BarRenderer3D var75 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var78 = var75.getItemLabelPaint((-1), 100);
//     var70.setLabelPaint(var78);
//     org.jfree.chart.text.TextLine var80 = new org.jfree.chart.text.TextLine("hi!", var67, var78);
//     var51.addLine(var80);
//     var43.addLine(var80);
//     var6.addLine(var80);
//     
//     // Checks the contract:  equals-hashcode on var25 and var70
//     assertTrue("Contract failed: equals-hashcode on var25 and var70", var25.equals(var70) ? var25.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var25
//     assertTrue("Contract failed: equals-hashcode on var70 and var25", var70.equals(var25) ? var70.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test328"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    java.awt.Shape var4 = var1.getDownArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test329"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.data.Range var15 = var14.getWidthRange();
    double var16 = var15.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test330"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setLabel("");
//     boolean var5 = var2.isAxisLineVisible();
//     java.text.DateFormat var6 = var2.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
//     var8.setAngleLabelsVisible(true);
//     var8.setBackgroundImageAlignment(0);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
//     var15.setLabel("");
//     boolean var18 = var15.isAxisLineVisible();
//     java.text.DateFormat var19 = var15.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, var20);
//     var21.setAngleLabelsVisible(true);
//     var21.setBackgroundImageAlignment(0);
//     org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var31 = null;
//     var29.setSeriesPositiveItemLabelPosition(100, var31);
//     double var33 = var29.getItemMargin();
//     java.awt.Font var35 = null;
//     var29.setSeriesItemLabelFont(0, var35);
//     java.awt.Font var39 = var29.getItemLabelFont(0, (-1));
//     org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var44 = null;
//     var42.setSeriesPositiveItemLabelPosition(100, var44);
//     java.awt.Stroke var46 = var42.getBaseOutlineStroke();
//     java.lang.Object var47 = var42.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var53 = var50.getItemLabelPaint((-1), 100);
//     var50.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var58 = var50.getItemOutlineStroke(0, (-1));
//     var42.setBaseStroke(var58);
//     java.awt.Paint var60 = var42.getBaseItemLabelPaint();
//     org.jfree.chart.text.TextFragment var61 = new org.jfree.chart.text.TextFragment("", var39, var60);
//     boolean var62 = var21.equals((java.lang.Object)var61);
//     org.jfree.chart.axis.ValueAxis var63 = var21.getAxis();
//     java.awt.Paint var64 = var63.getTickMarkPaint();
//     org.jfree.data.Range var65 = var8.getDataRange(var63);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test331"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 1.0f);
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test332"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.clearCategoryLabelToolTips();
    double var3 = var1.getUpperMargin();
    java.awt.Font var5 = null;
    java.awt.Paint var6 = null;
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var6, 100.0f, 1, var9);
    java.util.List var11 = var10.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    double var20 = var16.getItemMargin();
    java.awt.Font var22 = null;
    var16.setSeriesItemLabelFont(0, var22);
    java.awt.Font var26 = var16.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("Polar Plot", var26);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setLabel("");
    boolean var34 = var31.isAxisLineVisible();
    java.text.DateFormat var35 = var31.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var36 = null;
    org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, var36);
    var37.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var37);
    var37.setRadiusGridlinesVisible(false);
    java.awt.Paint var43 = var37.getOutlinePaint();
    var10.addLine("Polar Plot", var26, var43);
    org.jfree.chart.util.HorizontalAlignment var45 = var10.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var46 = null;
    org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement(var45, var46, 10.0d, 0.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var55 = var52.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
    org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
    org.jfree.chart.util.RectangleInsets var64 = var63.getMargin();
    var56.setItemLabelPadding(var64);
    org.jfree.chart.event.TitleChangeListener var66 = null;
    var56.addChangeListener(var66);
    org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var73 = null;
    var71.setSeriesPositiveItemLabelPosition(100, var73);
    double var75 = var71.getItemMargin();
    java.awt.Font var77 = null;
    var71.setSeriesItemLabelFont(0, var77);
    java.awt.Font var81 = var71.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var82 = new org.jfree.chart.title.TextTitle("Polar Plot", var81);
    var56.setItemFont(var81);
    org.jfree.data.time.SimpleTimePeriod var86 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var87 = var86.getStart();
    org.jfree.chart.plot.IntervalMarker var90 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var91 = null;
    var90.notifyListeners(var91);
    org.jfree.chart.util.RectangleInsets var93 = var90.getLabelOffset();
    boolean var94 = var86.equals((java.lang.Object)var90);
    var49.add((org.jfree.chart.block.Block)var56, (java.lang.Object)var86);
    var1.removeCategoryLabelToolTip((java.lang.Comparable)var86);
    double var97 = var1.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0.05d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test333"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    org.jfree.chart.util.RectangleInsets var27 = var26.getMargin();
    var19.setItemLabelPadding(var27);
    java.awt.geom.Rectangle2D var29 = var19.getBounds();
    var12.addLegend(var19);
    org.jfree.chart.util.RectangleAnchor var31 = var19.getLegendItemGraphicLocation();
    org.jfree.chart.text.TextBlockAnchor var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var33 = new org.jfree.chart.axis.CategoryLabelPosition(var31, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test334"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
//     boolean var9 = var2.isItemLabelVisible(1, 100);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var22 = null;
//     var21.notifyListeners(var22);
//     org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var29 = var26.getItemLabelPaint((-1), 100);
//     var21.setLabelPaint(var29);
//     var18.setBackgroundPaint(var29);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
//     var35.setLabel("");
//     boolean var38 = var35.isAxisLineVisible();
//     java.text.DateFormat var39 = var35.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, var40);
//     var41.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var41);
//     var44.setNotify(false);
//     var44.clearSubtitles();
//     var18.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var44);
//     java.awt.geom.Rectangle2D var49 = var18.getBounds();
//     var2.drawOutline(var10, var11, var49);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test335"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateTickMarkPosition var34 = var1.getTickMarkPosition();
    java.awt.Color var36 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var37 = var36.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var41 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var42 = var36.equals((java.lang.Object)"");
    var1.setTickLabelPaint((java.awt.Paint)var36);
    java.text.DateFormat var48 = null;
    org.jfree.chart.axis.DateTickUnit var49 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var48);
    int var50 = var49.getRollUnit();
    var1.setTickUnit(var49, false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 100);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test336"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    int var4 = var2.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test337"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    java.awt.Stroke var20 = var16.getBaseOutlineStroke();
    double var21 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(13);
    var16.setBasePositiveItemLabelPosition(var26, true);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
    var33.setLabel("");
    boolean var36 = var33.isAxisLineVisible();
    java.text.DateFormat var37 = var33.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var38);
    org.jfree.chart.axis.ValueAxis var40 = var39.getAxis();
    org.jfree.chart.plot.IntervalMarker var43 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var44 = null;
    var43.notifyListeners(var44);
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.util.RectangleInsets var53 = var52.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
    var60.setItemLabelPadding(var68);
    java.awt.geom.Rectangle2D var70 = var60.getBounds();
    java.awt.geom.Rectangle2D var73 = var53.createInsetRectangle(var70, false, false);
    var16.drawRangeMarker(var29, var30, var40, (org.jfree.chart.plot.Marker)var43, var73);
    java.lang.Object var75 = var43.clone();
    java.awt.Color var77 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var78 = var77.getBlue();
    var43.setOutlinePaint((java.awt.Paint)var77);
    org.jfree.chart.block.LabelBlock var80 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", var13, (java.awt.Paint)var77);
    var80.setToolTipText("#64000d");
    var80.setURLText("Polar Plot");
    var80.setToolTipText("Polar Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test338"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("org.jfree.data.time.TimePeriodFormatException: ");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test339"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setUpperBound(1.0d);
    var2.resizeRange((-1.0d), 100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var10.setSeriesPositiveItemLabelPosition(100, var12);
    double var14 = var10.getItemMargin();
    java.awt.Font var16 = null;
    var10.setSeriesItemLabelFont(0, var16);
    java.awt.Font var20 = var10.getItemLabelFont(0, (-1));
    var2.setTickLabelFont(var20);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var26 = null;
    var24.setSeriesPositiveItemLabelPosition(100, var26);
    double var28 = var24.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
    org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var41 = var38.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
    org.jfree.chart.util.RectangleInsets var43 = var42.getMargin();
    var35.setItemLabelPadding(var43);
    java.awt.geom.Rectangle2D var45 = var35.getBounds();
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("hi!");
    var49.setLabel("");
    boolean var52 = var49.isAxisLineVisible();
    java.text.DateFormat var53 = var49.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot(var47, (org.jfree.chart.axis.ValueAxis)var49, var54);
    var55.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var58 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var55);
    var58.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    var58.addSubtitle((org.jfree.chart.title.Title)var67);
    java.awt.image.BufferedImage var71 = var58.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var74 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var77 = var74.getItemLabelPaint((-1), 100);
    var58.setBackgroundPaint(var77);
    org.jfree.chart.title.LegendGraphic var79 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var45, var77);
    org.jfree.chart.renderer.category.BarRenderer3D var82 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var85 = var82.getItemLabelPaint((-1), 100);
    var79.setFillPaint(var85);
    var24.setBaseFillPaint(var85, true);
    org.jfree.chart.block.LabelBlock var89 = new org.jfree.chart.block.LabelBlock("#64000d", var20, var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test340"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    org.jfree.chart.event.AxisChangeListener var4 = null;
    var1.addChangeListener(var4);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var8.setSeriesPositiveItemLabelPosition(100, var10);
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    double var13 = var8.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(13);
    var8.setBasePositiveItemLabelPosition(var18, true);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLabel("");
    boolean var28 = var25.isAxisLineVisible();
    java.text.DateFormat var29 = var25.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var30);
    org.jfree.chart.axis.ValueAxis var32 = var31.getAxis();
    org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var35.notifyListeners(var36);
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
    var52.setItemLabelPadding(var60);
    java.awt.geom.Rectangle2D var62 = var52.getBounds();
    java.awt.geom.Rectangle2D var65 = var45.createInsetRectangle(var62, false, false);
    var8.drawRangeMarker(var21, var22, var32, (org.jfree.chart.plot.Marker)var35, var65);
    var1.setRightArrow((java.awt.Shape)var65);
    java.awt.Paint var68 = var1.getAxisLinePaint();
    java.awt.Shape var69 = var1.getLeftArrow();
    org.jfree.data.Range var72 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var75 = org.jfree.data.Range.shift(var72, 1.0d, false);
    org.jfree.data.Range var77 = org.jfree.data.Range.shift(var72, 1.0d);
    var1.setRangeWithMargins(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test341"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.setLabel("");
//     boolean var4 = var1.isAxisLineVisible();
//     org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
//     var1.setRange(var7, true, true);
//     boolean var11 = var1.isAutoRange();
//     java.lang.String var12 = var1.getLabelURL();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.AxisState var14 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     org.jfree.chart.util.RectangleInsets var22 = var21.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var28 = var25.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var35 = var32.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var32);
//     org.jfree.chart.util.RectangleInsets var37 = var36.getMargin();
//     var29.setItemLabelPadding(var37);
//     java.awt.geom.Rectangle2D var39 = var29.getBounds();
//     java.awt.geom.Rectangle2D var42 = var22.createInsetRectangle(var39, false, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
//     org.jfree.chart.util.RectangleInsets var50 = var49.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53);
//     org.jfree.chart.renderer.category.BarRenderer3D var60 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var63 = var60.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60);
//     org.jfree.chart.util.RectangleInsets var65 = var64.getMargin();
//     var57.setItemLabelPadding(var65);
//     java.awt.geom.Rectangle2D var67 = var57.getBounds();
//     java.awt.geom.Rectangle2D var70 = var50.createInsetRectangle(var67, false, false);
//     boolean var71 = org.jfree.chart.util.ShapeUtilities.intersects(var42, var70);
//     org.jfree.chart.renderer.category.BarRenderer3D var74 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var77 = var74.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var78 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var74);
//     org.jfree.chart.util.RectangleInsets var79 = var78.getMargin();
//     org.jfree.chart.util.RectangleEdge var80 = var78.getLegendItemGraphicEdge();
//     java.util.List var81 = var1.refreshTicks(var13, var14, var70, var80);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test342"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var8.addChangeListener(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleAnchor var18 = null;
    java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
    var8.zoomRangeAxes(10.0d, var16, var19);
    java.awt.Font var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setAngleLabelFont(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test343"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("DateTickUnit[YEAR, -1]", var1, var2);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test344"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    boolean var2 = var1.getRenderAsPercentages();
    double var3 = var1.getXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 12.0d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test345"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var8.datasetChanged(var11);
    org.jfree.chart.plot.Plot var13 = var8.getRootPlot();
    java.awt.Image var14 = var13.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test346"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var22 = var19.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
    org.jfree.chart.util.RectangleInsets var24 = var23.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    var31.setItemLabelPadding(var39);
    java.awt.geom.Rectangle2D var41 = var31.getBounds();
    java.awt.geom.Rectangle2D var44 = var24.createInsetRectangle(var41, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    org.jfree.chart.util.RectangleInsets var52 = var51.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.renderer.category.BarRenderer3D var62 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var65 = var62.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var62);
    org.jfree.chart.util.RectangleInsets var67 = var66.getMargin();
    var59.setItemLabelPadding(var67);
    java.awt.geom.Rectangle2D var69 = var59.getBounds();
    java.awt.geom.Rectangle2D var72 = var52.createInsetRectangle(var69, false, false);
    boolean var73 = org.jfree.chart.util.ShapeUtilities.intersects(var44, var72);
    boolean var74 = org.jfree.chart.util.ShapeUtilities.intersects(var16, var44);
    java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test347"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    java.awt.Paint var51 = var50.getOutlinePaint();
    java.awt.Stroke var52 = var50.getLineStroke();
    org.jfree.chart.util.RectangleInsets var57 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), (-1.0d), 10.0d);
    double var58 = var57.getRight();
    var50.setPadding(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 10.0d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test348"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, (-1.0f), 0.0f, 1.0d, 1.0f, 0.0f);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test349"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "hi!");
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    java.lang.String var7 = var4.getName();
    java.lang.String var8 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test350"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.awt.Shape var5 = var1.getUpArrow();
    var1.setLowerBound(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test351"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    var12.setBackgroundPaint(var31);
    java.util.List var33 = var12.getSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test352"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    float var13 = var7.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test353"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.util.Size2D var9 = var6.arrange(var8);
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var14 = null;
    var12.setSeriesPositiveItemLabelPosition(100, var14);
    double var16 = var12.getItemMargin();
    java.awt.Font var18 = null;
    var12.setSeriesItemLabelFont(0, var18);
    java.awt.Paint var20 = var12.getBaseOutlinePaint();
    java.awt.Paint var21 = var12.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var26 = null;
    var24.setSeriesPositiveItemLabelPosition(100, var26);
    java.awt.Stroke var28 = var24.getBaseOutlineStroke();
    java.lang.Object var29 = var24.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var35 = var32.getItemLabelPaint((-1), 100);
    var32.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var40 = var32.getItemOutlineStroke(0, (-1));
    var24.setBaseStroke(var40);
    java.awt.Paint var42 = var24.getBaseItemLabelPaint();
    double var43 = var24.getItemLabelAnchorOffset();
    org.jfree.chart.labels.ItemLabelPosition var45 = var24.getSeriesPositiveItemLabelPosition(0);
    var12.setBasePositiveItemLabelPosition(var45);
    java.awt.Font var47 = var12.getBaseItemLabelFont();
    org.jfree.chart.LegendItemSource[] var48 = new org.jfree.chart.LegendItemSource[] { var12};
    var6.setSources(var48);
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var55 = var52.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
    org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
    org.jfree.chart.util.RectangleInsets var64 = var63.getMargin();
    var56.setItemLabelPadding(var64);
    var6.setLegendItemGraphicPadding(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test354"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedDomainAxisSpace();
    int var16 = var12.getRangeAxisCount();
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var22 = null;
    var20.setSeriesPositiveItemLabelPosition(100, var22);
    double var24 = var20.getItemMargin();
    java.awt.Font var26 = null;
    var20.setSeriesItemLabelFont(0, var26);
    java.awt.Font var30 = var20.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var33 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var35 = null;
    var33.setSeriesPositiveItemLabelPosition(100, var35);
    java.awt.Stroke var37 = var33.getBaseOutlineStroke();
    java.lang.Object var38 = var33.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var44 = var41.getItemLabelPaint((-1), 100);
    var41.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var49 = var41.getItemOutlineStroke(0, (-1));
    var33.setBaseStroke(var49);
    java.awt.Paint var51 = var33.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var52 = new org.jfree.chart.text.TextFragment("", var30, var51);
    var12.setDomainCrosshairPaint(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test355"); }


    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((-1.0d), 16.0d, 0.0d, 1.0d, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test356"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.lang.Object var61 = var29.clone();
    var29.setEndValue(0.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var68 = null;
    var66.setSeriesPositiveItemLabelPosition(100, var68);
    java.awt.Stroke var70 = var66.getBaseOutlineStroke();
    java.lang.Object var71 = var66.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var74 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var77 = var74.getItemLabelPaint((-1), 100);
    var74.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var82 = var74.getItemOutlineStroke(0, (-1));
    var66.setBaseStroke(var82);
    java.awt.Paint var84 = var66.getBaseItemLabelPaint();
    var29.setPaint(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test357"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedDomainAxisSpace();
    var12.clearDomainMarkers(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test358"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    var2.setAxisLineStroke(var11);
    var2.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.util.RectangleInsets var29 = var28.getMargin();
    var21.setItemLabelPadding(var29);
    java.awt.geom.Rectangle2D var31 = var21.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var31, "hi!", "hi!");
    org.jfree.chart.axis.DateTickMarkPosition var35 = var2.getTickMarkPosition();
    java.awt.Font var36 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("#64000d", var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test359"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.LegendItemCollection var4 = var1.getLegendItems();
    var1.setLimit(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test360"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
    var2.setBaseSeriesVisible(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test361"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     double var7 = var2.getBase();
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var2.setBaseToolTipGenerator(var8, false);
//     org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(100, 0, 13);
//     var2.setSeriesOutlinePaint(0, (java.awt.Paint)var15, true);
//     org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var24 = var21.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
//     org.jfree.chart.plot.IntervalMarker var28 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var29 = null;
//     var28.notifyListeners(var29);
//     org.jfree.chart.renderer.category.BarRenderer3D var33 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var36 = var33.getItemLabelPaint((-1), 100);
//     var28.setLabelPaint(var36);
//     var25.setBackgroundPaint(var36);
//     var2.setSeriesItemLabelPaint(13, var36, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var2.", var21.equals(var2) == var2.equals(var21));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var33 and var2.", var33.equals(var2) == var2.equals(var33));
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test362"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var14 = var12.getDomainAxisForDataset((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test363"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    org.jfree.chart.util.RectangleInsets var27 = var26.getMargin();
    var19.setItemLabelPadding(var27);
    java.awt.geom.Rectangle2D var29 = var19.getBounds();
    var12.addLegend(var19);
    org.jfree.chart.util.RectangleAnchor var31 = var19.getLegendItemGraphicLocation();
    org.jfree.chart.text.TextBlockAnchor var32 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var35 = new org.jfree.chart.axis.CategoryLabelPosition(var31, var32, var33, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test364"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.lang.Object var7 = var6.clone();
    var6.setBaseShapesFilled(false);
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var16 = var13.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    org.jfree.chart.util.RectangleInsets var18 = var17.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var24 = var21.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    org.jfree.chart.util.RectangleInsets var33 = var32.getMargin();
    var25.setItemLabelPadding(var33);
    java.awt.geom.Rectangle2D var35 = var25.getBounds();
    java.awt.geom.Rectangle2D var38 = var18.createInsetRectangle(var35, false, false);
    var6.setSeriesShape(1, (java.awt.Shape)var38, true);
    org.jfree.chart.util.RectangleEdge var41 = null;
    double var42 = var1.valueToJava2D(100.0d, var38, var41);
    org.jfree.chart.axis.Timeline var43 = var1.getTimeline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test365"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test366"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    var50.setPadding((-1.0d), 100.0d, 0.0d, 100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var60 = null;
    var58.setSeriesPositiveItemLabelPosition(100, var60);
    java.awt.Stroke var62 = var58.getBaseOutlineStroke();
    double var63 = var58.getItemMargin();
    org.jfree.chart.util.GradientPaintTransformer var64 = var58.getGradientPaintTransformer();
    var50.setFillPaintTransformer(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test367"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
    org.jfree.chart.axis.ValueAxis var16 = null;
    int var17 = var12.getRangeAxisIndex(var16);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setAutoRangeMinimumSize(10.0d, false);
    org.jfree.chart.plot.Plot var24 = var20.getPlot();
    var20.setTickMarkInsideLength((-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test368"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var2.notifyListeners(var3);
    java.awt.Font var6 = null;
    java.awt.Paint var7 = null;
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var7, 100.0f, 1, var10);
    java.util.List var12 = var11.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var19 = null;
    var17.setSeriesPositiveItemLabelPosition(100, var19);
    double var21 = var17.getItemMargin();
    java.awt.Font var23 = null;
    var17.setSeriesItemLabelFont(0, var23);
    java.awt.Font var27 = var17.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("Polar Plot", var27);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
    var32.setLabel("");
    boolean var35 = var32.isAxisLineVisible();
    java.text.DateFormat var36 = var32.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var37 = null;
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var37);
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var38);
    var38.setRadiusGridlinesVisible(false);
    java.awt.Paint var44 = var38.getOutlinePaint();
    var11.addLine("Polar Plot", var27, var44);
    var2.setOutlinePaint(var44);
    org.jfree.chart.util.LengthAdjustmentType var47 = var2.getLabelOffsetType();
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("hi!");
    var49.setLabel("");
    boolean var52 = var49.isAxisLineVisible();
    java.text.DateFormat var53 = var49.getDateFormatOverride();
    var49.setTickMarkInsideLength(1.0f);
    java.text.DateFormat var60 = null;
    org.jfree.chart.axis.DateTickUnit var61 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var60);
    int var62 = var61.getRollUnit();
    int var63 = var61.getRollCount();
    java.text.DateFormat var68 = null;
    org.jfree.chart.axis.DateTickUnit var69 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var68);
    int var70 = var69.getRollUnit();
    int var71 = var69.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var74 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var75 = var74.getStart();
    java.util.Date var76 = var69.rollDate(var75);
    java.util.Date var77 = var61.rollDate(var76);
    java.util.Date var78 = var49.calculateLowestVisibleTickValue(var61);
    boolean var79 = var47.equals((java.lang.Object)var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test369"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    org.jfree.chart.util.RectangleInsets var16 = var6.getItemLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test370"); }


    java.text.DateFormat var4 = null;
    org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var4);
    int var6 = var5.getRollUnit();
    int var7 = var5.getRollCount();
    java.text.DateFormat var12 = null;
    org.jfree.chart.axis.DateTickUnit var13 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var12);
    int var14 = var13.getRollUnit();
    int var15 = var13.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var18 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var19 = var18.getStart();
    java.util.Date var20 = var13.rollDate(var19);
    java.util.Date var21 = var5.rollDate(var20);
    org.jfree.data.KeyedValues var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var21, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test371"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     var3.setLabel("");
//     boolean var6 = var3.isAxisLineVisible();
//     java.text.DateFormat var7 = var3.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
//     var9.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     var12.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     var12.addSubtitle((org.jfree.chart.title.Title)var21);
//     boolean var23 = var12.isBorderVisible();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
//     org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
//     org.jfree.chart.util.RectangleInsets var47 = var46.getMargin();
//     var39.setItemLabelPadding(var47);
//     java.awt.geom.Rectangle2D var49 = var39.getBounds();
//     java.awt.geom.Rectangle2D var52 = var32.createInsetRectangle(var49, false, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
//     org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
//     org.jfree.chart.renderer.category.BarRenderer3D var70 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var73 = var70.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var70);
//     org.jfree.chart.util.RectangleInsets var75 = var74.getMargin();
//     var67.setItemLabelPadding(var75);
//     java.awt.geom.Rectangle2D var77 = var67.getBounds();
//     java.awt.geom.Rectangle2D var80 = var60.createInsetRectangle(var77, false, false);
//     boolean var81 = org.jfree.chart.util.ShapeUtilities.intersects(var52, var80);
//     org.jfree.chart.ChartRenderingInfo var82 = null;
//     var12.draw(var24, var52, var82);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test372"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
    double var8 = var6.getContentXOffset();
    org.jfree.chart.block.BlockContainer var9 = null;
    var6.setWrapper(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test373"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.awt.Stroke var13 = var12.getRangeCrosshairStroke();
    java.awt.Paint var14 = var12.getDomainCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test374"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.clearCategoryLabelToolTips();
    double var3 = var1.getUpperMargin();
    org.jfree.data.time.SimpleTimePeriod var6 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test375"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    var12.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    var18.setAutoRangeMinimumSize(10.0d, false);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
    org.jfree.chart.util.RectangleInsets var36 = var35.getMargin();
    var28.setItemLabelPadding(var36);
    java.awt.geom.Rectangle2D var38 = var28.getBounds();
    var18.setLeftArrow((java.awt.Shape)var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var18, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test376"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
    double var8 = var6.getContentXOffset();
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var14 = var11.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    org.jfree.chart.util.RectangleInsets var16 = var15.getMargin();
    org.jfree.chart.util.RectangleEdge var17 = var15.getLegendItemGraphicEdge();
    var6.setLegendItemGraphicEdge(var17);
    org.jfree.chart.block.BlockFrame var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setFrame(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test377"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    var8.setAngleGridlinesVisible(true);
    java.lang.Object var15 = null;
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)true, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test378"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var2.notifyListeners(var3);
    double var5 = var2.getEndValue();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("hi!");
    var8.setLabel("");
    boolean var11 = var8.isAxisLineVisible();
    java.text.DateFormat var12 = var8.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, var13);
    org.jfree.chart.event.AxisChangeEvent var15 = null;
    var14.axisChanged(var15);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    var14.setBackgroundImage((java.awt.Image)var42);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var14);
    var14.zoom(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test379"); }


    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    var9.setLabel("");
    boolean var12 = var9.isAxisLineVisible();
    java.text.DateFormat var13 = var9.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var14 = null;
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var14);
    var15.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
    var18.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    var18.addSubtitle((org.jfree.chart.title.Title)var27);
    java.awt.image.BufferedImage var31 = var18.createBufferedImage(10, 1);
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "Polar Plot", "", (java.awt.Image)var31, "Polar Plot", "Polar Plot", "Polar Plot");
    org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "", "org.jfree.data.time.TimePeriodFormatException: ", (java.awt.Image)var31, "(100.0, 10.0)", "Polar Plot", "org.jfree.data.time.TimePeriodFormatException: ");
    var39.setLicenceText("Polar Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test380"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("Polar Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test381"); }


    java.lang.Object var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test382"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    java.awt.Stroke var20 = var16.getBaseOutlineStroke();
    double var21 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(13);
    var16.setBasePositiveItemLabelPosition(var26, true);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
    var33.setLabel("");
    boolean var36 = var33.isAxisLineVisible();
    java.text.DateFormat var37 = var33.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var38);
    org.jfree.chart.axis.ValueAxis var40 = var39.getAxis();
    org.jfree.chart.plot.IntervalMarker var43 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var44 = null;
    var43.notifyListeners(var44);
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.util.RectangleInsets var53 = var52.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
    var60.setItemLabelPadding(var68);
    java.awt.geom.Rectangle2D var70 = var60.getBounds();
    java.awt.geom.Rectangle2D var73 = var53.createInsetRectangle(var70, false, false);
    var16.drawRangeMarker(var29, var30, var40, (org.jfree.chart.plot.Marker)var43, var73);
    java.lang.Object var75 = var43.clone();
    java.awt.Color var77 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var78 = var77.getBlue();
    var43.setOutlinePaint((java.awt.Paint)var77);
    org.jfree.chart.block.LabelBlock var80 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", var13, (java.awt.Paint)var77);
    double var81 = var80.getContentXOffset();
    java.lang.String var82 = var80.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test383"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test384"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    var12.clearDomainMarkers();
    org.jfree.data.general.DatasetChangeEvent var14 = null;
    var12.datasetChanged(var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.data.Range var17 = var12.getDataRange(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test385"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    org.jfree.chart.axis.ValueAxis var10 = var9.getAxis();
    var9.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
    var14.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var21 = null;
    var19.setSeriesPositiveItemLabelPosition(100, var21);
    java.awt.Stroke var23 = var19.getBaseOutlineStroke();
    var14.setAxisLineStroke(var23);
    var14.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var32 = var29.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
    org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var39 = var36.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
    org.jfree.chart.util.RectangleInsets var41 = var40.getMargin();
    var33.setItemLabelPadding(var41);
    java.awt.geom.Rectangle2D var43 = var33.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var46 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var14, (java.awt.Shape)var43, "hi!", "hi!");
    java.awt.Shape var47 = var46.getArea();
    boolean var48 = var9.equals((java.lang.Object)var46);
    org.jfree.chart.event.RendererChangeEvent var49 = null;
    var9.rendererChanged(var49);
    org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart("Nearest", (org.jfree.chart.plot.Plot)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test386"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.plot.PlotOrientation var13 = var12.getOrientation();
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var12.axisChanged(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test387"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 10.0d, true);
//     org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var9 = null;
//     var7.setSeriesPositiveItemLabelPosition(100, var9);
//     java.awt.Stroke var11 = var7.getBaseOutlineStroke();
//     double var12 = var7.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(13);
//     var7.setBasePositiveItemLabelPosition(var17, true);
//     var3.setSeriesNegativeItemLabelPosition(100, var17, false);
//     var3.setMinimumBarLength((-1.0d));
//     boolean var24 = var3.getRenderAsPercentages();
//     org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var27.getSeriesNegativeItemLabelPosition(13);
//     var3.setBasePositiveItemLabelPosition(var29);
//     
//     // Checks the contract:  equals-hashcode on var17 and var29
//     assertTrue("Contract failed: equals-hashcode on var17 and var29", var17.equals(var29) ? var17.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var17
//     assertTrue("Contract failed: equals-hashcode on var29 and var17", var29.equals(var17) ? var29.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test388"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    org.jfree.chart.util.RectangleInsets var27 = var26.getMargin();
    var19.setItemLabelPadding(var27);
    java.awt.geom.Rectangle2D var29 = var19.getBounds();
    var12.addLegend(var19);
    org.jfree.chart.util.RectangleAnchor var31 = var19.getLegendItemGraphicLocation();
    java.lang.String var32 = var31.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "RectangleAnchor.CENTER"+ "'", var32.equals("RectangleAnchor.CENTER"));

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test389"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setNoDataMessage("hi!");
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("hi!");
    var13.setLabel("");
    boolean var16 = var13.isAxisLineVisible();
    java.text.DateFormat var17 = var13.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, var18);
    var19.setAngleLabelsVisible(true);
    var19.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
    java.awt.Font var26 = null;
    java.awt.Paint var27 = null;
    org.jfree.chart.text.TextMeasurer var30 = null;
    org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, var27, 100.0f, 1, var30);
    java.util.List var32 = var31.getLines();
    java.util.List var33 = var31.getLines();
    var24.setSubtitles(var33);
    java.lang.Object var35 = var24.getTextAntiAlias();
    var8.addChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test390"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var6 = null;
//     var4.setSeriesPositiveItemLabelPosition(100, var6);
//     double var8 = var4.getItemMargin();
//     java.awt.Font var10 = null;
//     var4.setSeriesItemLabelFont(0, var10);
//     java.awt.Font var14 = var4.getItemLabelFont(0, (-1));
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var19 = null;
//     var17.setSeriesPositiveItemLabelPosition(100, var19);
//     java.awt.Stroke var21 = var17.getBaseOutlineStroke();
//     java.lang.Object var22 = var17.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var28 = var25.getItemLabelPaint((-1), 100);
//     var25.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var33 = var25.getItemOutlineStroke(0, (-1));
//     var17.setBaseStroke(var33);
//     java.awt.Paint var35 = var17.getBaseItemLabelPaint();
//     org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("", var14, var35);
//     java.awt.Color var38 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     org.jfree.chart.text.TextLine var39 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]", var14, (java.awt.Paint)var38);
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.text.TextAnchor var43 = null;
//     var39.draw(var40, 1.0f, (-1.0f), var43, 0.0f, 1.0f, (-9.223372036854776E18d));
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test391"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("DateTickUnit[YEAR, -1]", "", "(100.0, 10.0)", "");

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test392"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Stroke var5 = var2.getItemOutlineStroke((-1), (-1));
    boolean var8 = var2.getItemShapeVisible(10, 100);
    var2.setSeriesLinesVisible(10, true);
    boolean var14 = var2.getItemLineVisible((-1), 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test393"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    boolean var2 = var1.getRenderAsPercentages();
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var8 = var5.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var10 = var5.getBase();
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var5.setBaseToolTipGenerator(var11, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var5.getLegendItemLabelGenerator();
    var1.setLegendItemURLGenerator(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test394"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    var1.centerRange(100.0d);
    java.awt.Font var17 = null;
    java.awt.Paint var18 = null;
    org.jfree.chart.text.TextMeasurer var21 = null;
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, var18, 100.0f, 1, var21);
    java.util.List var23 = var22.getLines();
    java.util.List var24 = var22.getLines();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.text.TextBlockAnchor var28 = null;
    java.awt.Shape var32 = var22.calculateBounds(var25, 10.0f, 100.0f, var28, 1.0f, 100.0f, 0.0d);
    var1.setRightArrow(var32);
    org.jfree.data.general.SeriesChangeEvent var34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test395"); }


    org.jfree.data.general.Dataset var1 = null;
    org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)1, var1);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test396"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), (-1.0d), 10.0d);
    double var5 = var4.getRight();
    double var7 = var4.calculateBottomInset(16.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0d));

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test397"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAutoRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange((-1.0d), (-9.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test398"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
    var10.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var18 = var10.getItemOutlineStroke(0, (-1));
    var2.setBaseStroke(var18);
    int var20 = var2.getRowCount();
    var2.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test399"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    var12.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var16 = var12.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test400"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     java.lang.Object var7 = var2.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
//     var10.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var18 = var10.getItemOutlineStroke(0, (-1));
//     var2.setBaseStroke(var18);
//     java.awt.Paint var20 = var2.getBaseItemLabelPaint();
//     java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var30 = null;
//     var28.setSeriesPositiveItemLabelPosition(100, var30);
//     java.awt.Stroke var32 = var28.getBaseOutlineStroke();
//     java.lang.Object var33 = var28.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var39 = var36.getItemLabelPaint((-1), 100);
//     var36.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var44 = var36.getItemOutlineStroke(0, (-1));
//     var28.setBaseStroke(var44);
//     java.awt.Color var47 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var48 = var47.getBlue();
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.DateAxis var53 = new org.jfree.chart.axis.DateAxis("hi!");
//     var53.setLabel("");
//     boolean var56 = var53.isAxisLineVisible();
//     java.text.DateFormat var57 = var53.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var58 = null;
//     org.jfree.chart.plot.PolarPlot var59 = new org.jfree.chart.plot.PolarPlot(var51, (org.jfree.chart.axis.ValueAxis)var53, var58);
//     var59.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var59);
//     var59.setRadiusGridlinesVisible(false);
//     java.awt.Paint var65 = var59.getOutlinePaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var68 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var70 = null;
//     var68.setSeriesPositiveItemLabelPosition(100, var70);
//     java.awt.Stroke var72 = var68.getBaseOutlineStroke();
//     org.jfree.chart.plot.CategoryMarker var73 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)0L, var65, var72);
//     org.jfree.chart.plot.IntervalMarker var75 = new org.jfree.chart.plot.IntervalMarker(10.0d, 1.0d, (java.awt.Paint)var25, var44, (java.awt.Paint)var47, var72, 0.0f);
//     var2.setSeriesOutlineStroke(0, var72);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var2.", var28.equals(var2) == var2.equals(var28));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var36 and var2.", var36.equals(var2) == var2.equals(var36));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var68 and var2.", var68.equals(var2) == var2.equals(var68));
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test401"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var16 = null;
    var14.setSeriesPositiveItemLabelPosition(100, var16);
    double var18 = var14.getItemMargin();
    java.awt.Font var20 = null;
    var14.setSeriesItemLabelFont(0, var20);
    java.awt.Font var24 = var14.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("Polar Plot", var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var32 = var29.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
    org.jfree.chart.util.RectangleInsets var34 = var33.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var37 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var40 = var37.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
    org.jfree.chart.renderer.category.BarRenderer3D var44 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var47 = var44.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var44);
    org.jfree.chart.util.RectangleInsets var49 = var48.getMargin();
    var41.setItemLabelPadding(var49);
    java.awt.geom.Rectangle2D var51 = var41.getBounds();
    java.awt.geom.Rectangle2D var54 = var34.createInsetRectangle(var51, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var57 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var60 = var57.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57);
    org.jfree.chart.util.RectangleInsets var62 = var61.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var68 = var65.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var65);
    org.jfree.chart.renderer.category.BarRenderer3D var72 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var75 = var72.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var72);
    org.jfree.chart.util.RectangleInsets var77 = var76.getMargin();
    var69.setItemLabelPadding(var77);
    java.awt.geom.Rectangle2D var79 = var69.getBounds();
    java.awt.geom.Rectangle2D var82 = var62.createInsetRectangle(var79, false, false);
    boolean var83 = org.jfree.chart.util.ShapeUtilities.intersects(var54, var82);
    var25.draw(var26, var54);
    org.jfree.chart.renderer.category.BarRenderer3D var87 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var90 = var87.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var91 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var87);
    org.jfree.chart.util.RectangleInsets var92 = var91.getMargin();
    org.jfree.chart.util.RectangleEdge var93 = var91.getLegendItemGraphicEdge();
    double var94 = var9.lengthToJava2D((-9.0d), var54, var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test402"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var10.setSeriesPositiveItemLabelPosition(100, var12);
    java.awt.Stroke var14 = var10.getBaseOutlineStroke();
    var5.setAxisLineStroke(var14);
    var5.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var23 = var20.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    org.jfree.chart.util.RectangleInsets var32 = var31.getMargin();
    var24.setItemLabelPadding(var32);
    java.awt.geom.Rectangle2D var34 = var24.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var37 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var5, (java.awt.Shape)var34, "hi!", "hi!");
    java.awt.Shape var38 = var37.getArea();
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var45 = null;
    var43.setSeriesPositiveItemLabelPosition(100, var45);
    double var47 = var43.getItemMargin();
    java.awt.Font var49 = null;
    var43.setSeriesItemLabelFont(0, var49);
    java.awt.Font var53 = var43.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var58 = null;
    var56.setSeriesPositiveItemLabelPosition(100, var58);
    java.awt.Stroke var60 = var56.getBaseOutlineStroke();
    java.lang.Object var61 = var56.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var64 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var67 = var64.getItemLabelPaint((-1), 100);
    var64.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var72 = var64.getItemOutlineStroke(0, (-1));
    var56.setBaseStroke(var72);
    java.awt.Paint var74 = var56.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var75 = new org.jfree.chart.text.TextFragment("", var53, var74);
    java.awt.Color var77 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    org.jfree.chart.text.TextLine var78 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]", var53, (java.awt.Paint)var77);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var79 = new org.jfree.chart.LegendItem(var0, "", "Nearest", "Nearest", var38, (java.awt.Paint)var77);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test403"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var6 = var3.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
    org.jfree.chart.util.RectangleInsets var15 = var14.getMargin();
    var7.setItemLabelPadding(var15);
    org.jfree.chart.event.TitleChangeListener var17 = null;
    var7.addChangeListener(var17);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var24 = null;
    var22.setSeriesPositiveItemLabelPosition(100, var24);
    double var26 = var22.getItemMargin();
    java.awt.Font var28 = null;
    var22.setSeriesItemLabelFont(0, var28);
    java.awt.Font var32 = var22.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("Polar Plot", var32);
    var7.setItemFont(var32);
    org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("#64000d", var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test404"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     double var7 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var10.setSeriesPositiveItemLabelPosition(100, var12);
//     java.awt.Stroke var14 = var10.getBaseOutlineStroke();
//     var2.setBaseStroke(var14, true);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var2.getSeriesURLGenerator(13);
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
//     org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var32 = var29.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
//     org.jfree.chart.util.RectangleInsets var34 = var33.getMargin();
//     var26.setItemLabelPadding(var34);
//     java.awt.geom.Rectangle2D var36 = var26.getBounds();
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis("hi!");
//     var40.setLabel("");
//     boolean var43 = var40.isAxisLineVisible();
//     java.text.DateFormat var44 = var40.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var45 = null;
//     org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot(var38, (org.jfree.chart.axis.ValueAxis)var40, var45);
//     var46.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var46);
//     var49.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var54 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var57 = var54.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54);
//     var49.addSubtitle((org.jfree.chart.title.Title)var58);
//     java.awt.image.BufferedImage var62 = var49.createBufferedImage(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var68 = var65.getItemLabelPaint((-1), 100);
//     var49.setBackgroundPaint(var68);
//     org.jfree.chart.title.LegendGraphic var70 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var36, var68);
//     org.jfree.chart.renderer.category.BarRenderer3D var73 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var76 = var73.getItemLabelPaint((-1), 100);
//     var70.setFillPaint(var76);
//     org.jfree.chart.renderer.category.BarRenderer3D var80 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var82 = null;
//     var80.setSeriesPositiveItemLabelPosition(100, var82);
//     double var84 = var80.getItemMargin();
//     java.awt.Font var86 = null;
//     var80.setSeriesItemLabelFont(0, var86);
//     java.awt.Paint var88 = var80.getBaseOutlinePaint();
//     java.awt.Paint var89 = var80.getWallPaint();
//     boolean var90 = org.jfree.chart.util.PaintUtilities.equal(var76, var89);
//     var2.setSeriesOutlinePaint(1, var89);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var2.", var22.equals(var2) == var2.equals(var22));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var2.", var29.equals(var2) == var2.equals(var29));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var54 and var2.", var54.equals(var2) == var2.equals(var54));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var65 and var2.", var65.equals(var2) == var2.equals(var65));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var73 and var2.", var73.equals(var2) == var2.equals(var73));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var80 and var2.", var80.equals(var2) == var2.equals(var80));
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test405"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setAngleLabelsVisible(true);
    double var11 = var8.getMaxRadius();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test406"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setUpperBound(1.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var9 = null;
//     var7.setSeriesPositiveItemLabelPosition(100, var9);
//     java.awt.Stroke var11 = var7.getBaseOutlineStroke();
//     var2.setAxisLineStroke(var11);
//     var2.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
//     org.jfree.chart.util.RectangleInsets var29 = var28.getMargin();
//     var21.setItemLabelPadding(var29);
//     java.awt.geom.Rectangle2D var31 = var21.getBounds();
//     org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var31, "hi!", "hi!");
//     org.jfree.chart.axis.DateTickMarkPosition var35 = var2.getTickMarkPosition();
//     java.awt.Font var36 = var2.getLabelFont();
//     java.awt.Color var38 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var39 = var38.getBlue();
//     org.jfree.chart.urls.StandardCategoryURLGenerator var43 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
//     boolean var44 = var38.equals((java.lang.Object)"");
//     java.awt.color.ColorSpace var45 = var38.getColorSpace();
//     java.awt.Color var46 = var38.darker();
//     org.jfree.chart.text.TextMeasurer var48 = null;
//     org.jfree.chart.text.TextBlock var49 = org.jfree.chart.text.TextUtilities.createTextBlock("Polar Plot", var36, (java.awt.Paint)var46, 100.0f, var48);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test407"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.JFreeChart var4 = var1.getPieChart();
    var4.setBorderVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test408"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test409"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var20};
    var12.setRenderers(var21);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("hi!");
    var26.setLowerBound((-1.0d));
    java.text.DateFormat var29 = var26.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setUpperBound(1.0d);
    boolean var34 = var31.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var31, var35);
    java.lang.Object var37 = var36.clone();
    org.jfree.data.xy.XYDataset var39 = var36.getDataset(10);
    float var40 = var36.getBackgroundAlpha();
    org.jfree.chart.axis.AxisLocation var42 = var36.getDomainAxisLocation(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setRangeAxisLocation((-1), var42, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test410"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
//     boolean var2 = var1.getRenderAsPercentages();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var10 = var7.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
//     var11.setItemLabelPadding(var19);
//     java.awt.geom.Rectangle2D var21 = var11.getBounds();
//     var1.drawOutline(var3, var4, var21);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test411"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.text.DateFormat var5 = var1.getDateFormatOverride();
    var1.setTickMarkInsideLength(1.0f);
    java.text.DateFormat var12 = null;
    org.jfree.chart.axis.DateTickUnit var13 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var12);
    int var14 = var13.getRollUnit();
    int var15 = var13.getRollCount();
    java.text.DateFormat var20 = null;
    org.jfree.chart.axis.DateTickUnit var21 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var20);
    int var22 = var21.getRollUnit();
    int var23 = var21.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var26 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var27 = var26.getStart();
    java.util.Date var28 = var21.rollDate(var27);
    java.util.Date var29 = var13.rollDate(var28);
    java.util.Date var30 = var1.calculateLowestVisibleTickValue(var13);
    var1.setAutoRangeMinimumSize(1.0d, true);
    org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var39 = var36.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
    org.jfree.chart.util.RectangleInsets var48 = var47.getMargin();
    var40.setItemLabelPadding(var48);
    java.awt.geom.Rectangle2D var50 = var40.getBounds();
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("hi!");
    var54.setLabel("");
    boolean var57 = var54.isAxisLineVisible();
    java.text.DateFormat var58 = var54.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var59 = null;
    org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, var59);
    var60.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var60);
    var63.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var68 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var71 = var68.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var72 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var68);
    var63.addSubtitle((org.jfree.chart.title.Title)var72);
    java.awt.image.BufferedImage var76 = var63.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var79 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var82 = var79.getItemLabelPaint((-1), 100);
    var63.setBackgroundPaint(var82);
    org.jfree.chart.title.LegendGraphic var84 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var50, var82);
    org.jfree.chart.entity.AxisLabelEntity var87 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var50, "", "Nearest");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test412"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    var10.setAntiAlias(true);
    boolean var13 = var10.isNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test413"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    java.lang.String var15 = var12.getPlotType();
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    var18.setLabel("");
    boolean var21 = var18.isAxisLineVisible();
    java.text.DateFormat var22 = var18.getDateFormatOverride();
    var18.setTickMarkInsideLength(1.0f);
    java.text.DateFormat var29 = null;
    org.jfree.chart.axis.DateTickUnit var30 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var29);
    int var31 = var30.getRollUnit();
    int var32 = var30.getRollCount();
    java.text.DateFormat var37 = null;
    org.jfree.chart.axis.DateTickUnit var38 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var37);
    int var39 = var38.getRollUnit();
    int var40 = var38.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var43 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var44 = var43.getStart();
    java.util.Date var45 = var38.rollDate(var44);
    java.util.Date var46 = var30.rollDate(var45);
    java.util.Date var47 = var18.calculateLowestVisibleTickValue(var30);
    var12.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "XY Plot"+ "'", var15.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test414"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    java.awt.Paint var10 = var8.getNoDataMessagePaint();
    java.awt.Paint var11 = var8.getAngleGridlinePaint();
    var8.setAngleGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test415"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.LegendItemCollection var4 = var1.getLegendItems();
    java.lang.String var5 = var1.getPlotType();
    double var6 = var1.getLimit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Multiple Pie Plot"+ "'", var5.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test416"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.util.RectangleInsets var21 = var20.getMargin();
    var13.setItemLabelPadding(var21);
    java.awt.geom.Rectangle2D var23 = var13.getBounds();
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
    var27.setLabel("");
    boolean var30 = var27.isAxisLineVisible();
    java.text.DateFormat var31 = var27.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
    var33.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var33);
    var36.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var44 = var41.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
    var36.addSubtitle((org.jfree.chart.title.Title)var45);
    java.awt.image.BufferedImage var49 = var36.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var55 = var52.getItemLabelPaint((-1), 100);
    var36.setBackgroundPaint(var55);
    org.jfree.chart.title.LegendGraphic var57 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var23, var55);
    org.jfree.chart.renderer.category.BarRenderer3D var60 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var63 = var60.getItemLabelPaint((-1), 100);
    var57.setFillPaint(var63);
    var2.setBaseFillPaint(var63, true);
    var2.setAutoPopulateSeriesOutlinePaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test417"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var2.setBaseToolTipGenerator(var7, true);
    boolean var10 = var2.getAutoPopulateSeriesShape();
    var2.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = var2.getToolTipGenerator(1, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test418"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.clearCategoryLabelToolTips();
    double var3 = var1.getUpperMargin();
    java.awt.Font var5 = null;
    java.awt.Paint var6 = null;
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var6, 100.0f, 1, var9);
    java.util.List var11 = var10.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    double var20 = var16.getItemMargin();
    java.awt.Font var22 = null;
    var16.setSeriesItemLabelFont(0, var22);
    java.awt.Font var26 = var16.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("Polar Plot", var26);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setLabel("");
    boolean var34 = var31.isAxisLineVisible();
    java.text.DateFormat var35 = var31.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var36 = null;
    org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, var36);
    var37.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var37);
    var37.setRadiusGridlinesVisible(false);
    java.awt.Paint var43 = var37.getOutlinePaint();
    var10.addLine("Polar Plot", var26, var43);
    org.jfree.chart.util.HorizontalAlignment var45 = var10.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var46 = null;
    org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement(var45, var46, 10.0d, 0.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var55 = var52.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
    org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
    org.jfree.chart.util.RectangleInsets var64 = var63.getMargin();
    var56.setItemLabelPadding(var64);
    org.jfree.chart.event.TitleChangeListener var66 = null;
    var56.addChangeListener(var66);
    org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var73 = null;
    var71.setSeriesPositiveItemLabelPosition(100, var73);
    double var75 = var71.getItemMargin();
    java.awt.Font var77 = null;
    var71.setSeriesItemLabelFont(0, var77);
    java.awt.Font var81 = var71.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var82 = new org.jfree.chart.title.TextTitle("Polar Plot", var81);
    var56.setItemFont(var81);
    org.jfree.data.time.SimpleTimePeriod var86 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var87 = var86.getStart();
    org.jfree.chart.plot.IntervalMarker var90 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var91 = null;
    var90.notifyListeners(var91);
    org.jfree.chart.util.RectangleInsets var93 = var90.getLabelOffset();
    boolean var94 = var86.equals((java.lang.Object)var90);
    var49.add((org.jfree.chart.block.Block)var56, (java.lang.Object)var86);
    var1.removeCategoryLabelToolTip((java.lang.Comparable)var86);
    int var97 = var1.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 4);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test419"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setUpperBound(1.0d);
//     var2.resizeRange((-1.0d), 100.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var10.setSeriesPositiveItemLabelPosition(100, var12);
//     double var14 = var10.getItemMargin();
//     java.awt.Font var16 = null;
//     var10.setSeriesItemLabelFont(0, var16);
//     java.awt.Font var20 = var10.getItemLabelFont(0, (-1));
//     var2.setTickLabelFont(var20);
//     org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
//     org.jfree.chart.util.RectangleInsets var36 = var35.getMargin();
//     var28.setItemLabelPadding(var36);
//     java.awt.geom.Rectangle2D var38 = var28.getBounds();
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("hi!");
//     var42.setLabel("");
//     boolean var45 = var42.isAxisLineVisible();
//     java.text.DateFormat var46 = var42.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var47 = null;
//     org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot(var40, (org.jfree.chart.axis.ValueAxis)var42, var47);
//     var48.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var48);
//     var51.setNotify(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
//     var51.addSubtitle((org.jfree.chart.title.Title)var60);
//     java.awt.image.BufferedImage var64 = var51.createBufferedImage(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var67 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var70 = var67.getItemLabelPaint((-1), 100);
//     var51.setBackgroundPaint(var70);
//     org.jfree.chart.title.LegendGraphic var72 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var38, var70);
//     org.jfree.chart.renderer.category.BarRenderer3D var75 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var78 = var75.getItemLabelPaint((-1), 100);
//     var72.setFillPaint(var78);
//     org.jfree.chart.text.TextMeasurer var81 = null;
//     org.jfree.chart.text.TextBlock var82 = org.jfree.chart.text.TextUtilities.createTextBlock("#64000d", var20, var78, 1.0f, var81);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test420"); }


    java.text.DateFormat var4 = null;
    org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var4);
    int var6 = var5.getRollUnit();
    int var7 = var5.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var10 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var11 = var10.getStart();
    java.util.Date var12 = var5.rollDate(var11);
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    org.jfree.chart.util.RectangleInsets var27 = var26.getMargin();
    var19.setItemLabelPadding(var27);
    java.awt.geom.Rectangle2D var29 = var19.getBounds();
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
    var33.setLabel("");
    boolean var36 = var33.isAxisLineVisible();
    java.text.DateFormat var37 = var33.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var38);
    var39.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var39);
    var42.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    var42.addSubtitle((org.jfree.chart.title.Title)var51);
    java.awt.image.BufferedImage var55 = var42.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var61 = var58.getItemLabelPaint((-1), 100);
    var42.setBackgroundPaint(var61);
    org.jfree.chart.title.LegendGraphic var63 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var29, var61);
    java.awt.Paint var64 = var63.getOutlinePaint();
    java.lang.Object var65 = null;
    boolean var66 = var63.equals(var65);
    boolean var67 = var63.isShapeFilled();
    java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var63.setShape(var70);
    int var72 = var5.compareTo((java.lang.Object)var70);
    org.jfree.chart.entity.TickLabelEntity var75 = new org.jfree.chart.entity.TickLabelEntity(var70, "", "DateTickUnit[YEAR, -1]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == (-1));

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test421"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.chart.block.LengthConstraintType var15 = var14.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var16 = var14.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var18 = var14.toFixedHeight(16.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test422"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var20};
    var12.setRenderers(var21);
    org.jfree.chart.axis.AxisSpace var23 = var12.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test423"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setAngleLabelsVisible(true);
    var8.setBackgroundImageAlignment(0);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    double var20 = var16.getItemMargin();
    java.awt.Font var22 = null;
    var16.setSeriesItemLabelFont(0, var22);
    java.awt.Font var26 = var16.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var31 = null;
    var29.setSeriesPositiveItemLabelPosition(100, var31);
    java.awt.Stroke var33 = var29.getBaseOutlineStroke();
    java.lang.Object var34 = var29.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var37 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var40 = var37.getItemLabelPaint((-1), 100);
    var37.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var45 = var37.getItemOutlineStroke(0, (-1));
    var29.setBaseStroke(var45);
    java.awt.Paint var47 = var29.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("", var26, var47);
    boolean var49 = var8.equals((java.lang.Object)var48);
    org.jfree.data.xy.XYDataset var50 = null;
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("hi!");
    var52.setLabel("");
    boolean var55 = var52.isAxisLineVisible();
    java.text.DateFormat var56 = var52.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var57 = null;
    org.jfree.chart.plot.PolarPlot var58 = new org.jfree.chart.plot.PolarPlot(var50, (org.jfree.chart.axis.ValueAxis)var52, var57);
    org.jfree.chart.axis.ValueAxis var59 = var58.getAxis();
    org.jfree.data.xy.XYDataset var60 = null;
    var58.setDataset(var60);
    org.jfree.chart.util.RectangleInsets var62 = var58.getInsets();
    org.jfree.chart.event.PlotChangeListener var63 = null;
    var58.addChangeListener(var63);
    org.jfree.chart.plot.PlotRenderingInfo var66 = null;
    java.awt.geom.Rectangle2D var67 = null;
    org.jfree.chart.util.RectangleAnchor var68 = null;
    java.awt.geom.Point2D var69 = org.jfree.chart.util.RectangleAnchor.coordinates(var67, var68);
    var58.zoomRangeAxes(10.0d, var66, var69);
    var8.setParent((org.jfree.chart.plot.Plot)var58);
    java.awt.Paint var72 = var8.getRadiusGridlinePaint();
    org.jfree.chart.event.MarkerChangeEvent var73 = null;
    var8.markerChanged(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test424"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    double var7 = var2.getItemMargin();
    java.awt.Font var9 = var2.getSeriesItemLabelFont((-1));
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var2.setPositiveItemLabelPositionFallback(var10);
    double var12 = var2.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test425"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "hi!");
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    var4.setName("hi!");
    org.jfree.chart.ui.Library var13 = new org.jfree.chart.ui.Library("", "", "hi!", "");
    java.lang.String var14 = var13.getInfo();
    var4.addLibrary(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + ""+ "'", var14.equals(""));

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test426"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
    float var16 = var12.getBackgroundAlpha();
    org.jfree.chart.axis.AxisLocation var18 = var12.getDomainAxisLocation(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test427"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     double var6 = var2.getItemMargin();
//     boolean var7 = var2.getAutoPopulateSeriesOutlineStroke();
//     double var8 = var2.getBase();
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var15 = var12.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
//     var12.setBaseSeriesVisible(false);
//     java.awt.Stroke var20 = var12.getSeriesStroke(10);
//     org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var25 = null;
//     var23.setSeriesPositiveItemLabelPosition(100, var25);
//     java.awt.Stroke var27 = var23.getBaseOutlineStroke();
//     double var28 = var23.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var33 = var31.getSeriesNegativeItemLabelPosition(13);
//     var23.setBasePositiveItemLabelPosition(var33, true);
//     double var36 = var33.getAngle();
//     org.jfree.chart.labels.ItemLabelAnchor var37 = var33.getItemLabelAnchor();
//     var12.setPositiveItemLabelPositionFallback(var33);
//     var2.setSeriesPositiveItemLabelPosition(0, var33);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var2.", var31.equals(var2) == var2.equals(var31));
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test428"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    double var7 = var2.getItemMargin();
    java.lang.Object var8 = var2.clone();
    var2.setBaseItemLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test429"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     double var6 = var2.getItemMargin();
//     boolean var7 = var2.getAutoPopulateSeriesOutlineStroke();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
//     var2.setBaseItemLabelGenerator(var8);
//     boolean var10 = var2.getAutoPopulateSeriesOutlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var16 = null;
//     var14.setSeriesPositiveItemLabelPosition(100, var16);
//     double var18 = var14.getItemMargin();
//     java.awt.Font var20 = null;
//     var14.setSeriesItemLabelFont(0, var20);
//     java.awt.Paint var22 = var14.getBaseOutlinePaint();
//     java.awt.Paint var23 = var14.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var28 = null;
//     var26.setSeriesPositiveItemLabelPosition(100, var28);
//     java.awt.Stroke var30 = var26.getBaseOutlineStroke();
//     java.lang.Object var31 = var26.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
//     var34.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var42 = var34.getItemOutlineStroke(0, (-1));
//     var26.setBaseStroke(var42);
//     java.awt.Paint var44 = var26.getBaseItemLabelPaint();
//     double var45 = var26.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.ItemLabelPosition var47 = var26.getSeriesPositiveItemLabelPosition(0);
//     var14.setBasePositiveItemLabelPosition(var47);
//     var2.setSeriesNegativeItemLabelPosition(1, var47);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var2.", var14.equals(var2) == var2.equals(var14));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var2.", var26.equals(var2) == var2.equals(var26));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var34 and var2.", var34.equals(var2) == var2.equals(var34));
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test430"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var22 = var19.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
    org.jfree.chart.util.RectangleInsets var24 = var23.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    var31.setItemLabelPadding(var39);
    java.awt.geom.Rectangle2D var41 = var31.getBounds();
    java.awt.geom.Rectangle2D var44 = var24.createInsetRectangle(var41, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    org.jfree.chart.util.RectangleInsets var52 = var51.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.renderer.category.BarRenderer3D var62 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var65 = var62.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var62);
    org.jfree.chart.util.RectangleInsets var67 = var66.getMargin();
    var59.setItemLabelPadding(var67);
    java.awt.geom.Rectangle2D var69 = var59.getBounds();
    java.awt.geom.Rectangle2D var72 = var52.createInsetRectangle(var69, false, false);
    boolean var73 = org.jfree.chart.util.ShapeUtilities.intersects(var44, var72);
    boolean var74 = org.jfree.chart.util.ShapeUtilities.intersects(var16, var44);
    org.jfree.chart.entity.ChartEntity var76 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var16, "Range[0.0,0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test431"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setLabel("");
    boolean var13 = var10.isAxisLineVisible();
    java.text.DateFormat var14 = var10.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, var15);
    var16.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var16);
    var19.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    var19.addSubtitle((org.jfree.chart.title.Title)var28);
    java.awt.image.BufferedImage var32 = var19.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
    var19.setBackgroundPaint(var38);
    java.awt.Stroke var40 = null;
    org.jfree.data.xy.XYDataset var41 = null;
    org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis("hi!");
    var43.setLabel("");
    boolean var46 = var43.isAxisLineVisible();
    java.text.DateFormat var47 = var43.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var48 = null;
    org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot(var41, (org.jfree.chart.axis.ValueAxis)var43, var48);
    org.jfree.chart.axis.ValueAxis var50 = var49.getAxis();
    java.awt.Paint var51 = var49.getNoDataMessagePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem(var0, "Nearest", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "Nearest", var6, var38, var40, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test432"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.clearCategoryLabelToolTips();
    double var3 = var1.getUpperMargin();
    java.awt.Font var5 = null;
    java.awt.Paint var6 = null;
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var6, 100.0f, 1, var9);
    java.util.List var11 = var10.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    double var20 = var16.getItemMargin();
    java.awt.Font var22 = null;
    var16.setSeriesItemLabelFont(0, var22);
    java.awt.Font var26 = var16.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("Polar Plot", var26);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setLabel("");
    boolean var34 = var31.isAxisLineVisible();
    java.text.DateFormat var35 = var31.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var36 = null;
    org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, var36);
    var37.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var37);
    var37.setRadiusGridlinesVisible(false);
    java.awt.Paint var43 = var37.getOutlinePaint();
    var10.addLine("Polar Plot", var26, var43);
    org.jfree.chart.util.HorizontalAlignment var45 = var10.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var46 = null;
    org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement(var45, var46, 10.0d, 0.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var55 = var52.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
    org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
    org.jfree.chart.util.RectangleInsets var64 = var63.getMargin();
    var56.setItemLabelPadding(var64);
    org.jfree.chart.event.TitleChangeListener var66 = null;
    var56.addChangeListener(var66);
    org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var73 = null;
    var71.setSeriesPositiveItemLabelPosition(100, var73);
    double var75 = var71.getItemMargin();
    java.awt.Font var77 = null;
    var71.setSeriesItemLabelFont(0, var77);
    java.awt.Font var81 = var71.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var82 = new org.jfree.chart.title.TextTitle("Polar Plot", var81);
    var56.setItemFont(var81);
    org.jfree.data.time.SimpleTimePeriod var86 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var87 = var86.getStart();
    org.jfree.chart.plot.IntervalMarker var90 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var91 = null;
    var90.notifyListeners(var91);
    org.jfree.chart.util.RectangleInsets var93 = var90.getLabelOffset();
    boolean var94 = var86.equals((java.lang.Object)var90);
    var49.add((org.jfree.chart.block.Block)var56, (java.lang.Object)var86);
    var1.removeCategoryLabelToolTip((java.lang.Comparable)var86);
    float var97 = var1.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0.0f);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test433"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("Polar Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test434"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setAngleLabelsVisible(true);
    org.jfree.chart.axis.ValueAxis var11 = var8.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test435"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    var10.setBackgroundImageAlpha(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test436"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
    boolean var9 = var2.isItemLabelVisible(1, 100);
    java.awt.Paint var11 = var2.lookupSeriesPaint(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test437"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var8.datasetChanged(var11);
    org.jfree.chart.plot.Plot var13 = var8.getRootPlot();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test438"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Polar Plot");

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test439"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    java.awt.Shape var4 = var1.getUpArrow();
    double var5 = var1.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test440"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.JFreeChart var4 = var1.getPieChart();
    var4.setAntiAlias(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test441"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "hi!");
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    boolean var7 = var4.equals((java.lang.Object)"");
    var4.setLicenceName("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test442"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
//     java.awt.Font var5 = var2.getItemLabelFont(0, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var10 = null;
//     var8.setSeriesPositiveItemLabelPosition(100, var10);
//     java.awt.Stroke var12 = var8.getBaseOutlineStroke();
//     java.lang.Object var13 = var8.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
//     var16.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var24 = var16.getItemOutlineStroke(0, (-1));
//     var8.setBaseStroke(var24);
//     java.awt.Paint var26 = var8.getBaseItemLabelPaint();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.data.time.TimePeriodFormatException: ", var5, var26, 0.0f, var28);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test443"); }


    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    var9.setLabel("");
    boolean var12 = var9.isAxisLineVisible();
    java.text.DateFormat var13 = var9.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var14 = null;
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var14);
    var15.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
    var18.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    var18.addSubtitle((org.jfree.chart.title.Title)var27);
    java.awt.image.BufferedImage var31 = var18.createBufferedImage(10, 1);
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "Polar Plot", "", (java.awt.Image)var31, "Polar Plot", "Polar Plot", "Polar Plot");
    org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "", "org.jfree.data.time.TimePeriodFormatException: ", (java.awt.Image)var31, "(100.0, 10.0)", "Polar Plot", "org.jfree.data.time.TimePeriodFormatException: ");
    java.util.List var40 = var39.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test444"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((-1.0d), 1.0d, 1.0d, (-9.0d));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test445"); }


    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.SimpleTimePeriod var7 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var8 = var7.getEnd();
    org.jfree.data.gantt.Task var9 = new org.jfree.data.gantt.Task("", var4, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    var10.setDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var14 = var10.getNearestDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test446"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
    org.jfree.chart.title.LegendTitle var26 = var12.getLegend();
    org.jfree.chart.ChartRenderingInfo var31 = null;
    java.awt.image.BufferedImage var32 = var12.createBufferedImage(1, 100, (-1.0d), 0.0d, var31);
    var12.setBackgroundImageAlpha(1.0f);
    var12.setTextAntiAlias(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test447"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    boolean var4 = var1.isNegativeArrowVisible();
    java.text.DateFormat var9 = null;
    org.jfree.chart.axis.DateTickUnit var10 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var9);
    int var11 = var10.getRollUnit();
    java.util.Date var12 = var1.calculateHighestVisibleTickValue(var10);
    java.lang.String var13 = var10.toString();
    int var14 = var10.getUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "DateTickUnit[YEAR, -1]"+ "'", var13.equals("DateTickUnit[YEAR, -1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test448"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    org.jfree.chart.labels.ItemLabelPosition var4 = var1.getPositiveItemLabelPosition((-1), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test449"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    var1.centerRange(100.0d);
    org.jfree.chart.util.RectangleInsets var16 = var1.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test450"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    org.jfree.chart.util.UnitType var16 = var14.getUnitType();
    java.lang.String var17 = var16.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "UnitType.ABSOLUTE"+ "'", var17.equals("UnitType.ABSOLUTE"));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test451"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var2 = var1.getBlue();
    int var3 = var1.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test452"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test453"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    var12.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var17 = var12.getDomainAxisEdge();
    boolean var18 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var17);
    boolean var19 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test454"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Nearest", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test455"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    double var4 = var1.getLimit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test456"); }


    org.jfree.data.time.TimePeriod var1 = null;
    org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("hi!", var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var4 = var2.getSubtask(13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test457"); }


    org.jfree.data.time.SimpleTimePeriod var4 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.SimpleTimePeriod var8 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var9 = var8.getEnd();
    org.jfree.data.gantt.Task var10 = new org.jfree.data.gantt.Task("", var5, var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.DefaultKeyedValue var13 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)var11, (java.lang.Number)(short)1);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test458"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    java.awt.Stroke var20 = var16.getBaseOutlineStroke();
    double var21 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(13);
    var16.setBasePositiveItemLabelPosition(var26, true);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
    var33.setLabel("");
    boolean var36 = var33.isAxisLineVisible();
    java.text.DateFormat var37 = var33.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var38);
    org.jfree.chart.axis.ValueAxis var40 = var39.getAxis();
    org.jfree.chart.plot.IntervalMarker var43 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var44 = null;
    var43.notifyListeners(var44);
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.util.RectangleInsets var53 = var52.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
    var60.setItemLabelPadding(var68);
    java.awt.geom.Rectangle2D var70 = var60.getBounds();
    java.awt.geom.Rectangle2D var73 = var53.createInsetRectangle(var70, false, false);
    var16.drawRangeMarker(var29, var30, var40, (org.jfree.chart.plot.Marker)var43, var73);
    java.lang.Object var75 = var43.clone();
    java.awt.Color var77 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var78 = var77.getBlue();
    var43.setOutlinePaint((java.awt.Paint)var77);
    org.jfree.chart.block.LabelBlock var80 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", var13, (java.awt.Paint)var77);
    float[] var83 = new float[] { 1.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var84 = var77.getColorComponents(var83);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test459"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    java.awt.Stroke var20 = var16.getBaseOutlineStroke();
    double var21 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(13);
    var16.setBasePositiveItemLabelPosition(var26, true);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
    var33.setLabel("");
    boolean var36 = var33.isAxisLineVisible();
    java.text.DateFormat var37 = var33.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var38);
    org.jfree.chart.axis.ValueAxis var40 = var39.getAxis();
    org.jfree.chart.plot.IntervalMarker var43 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var44 = null;
    var43.notifyListeners(var44);
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.util.RectangleInsets var53 = var52.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
    var60.setItemLabelPadding(var68);
    java.awt.geom.Rectangle2D var70 = var60.getBounds();
    java.awt.geom.Rectangle2D var73 = var53.createInsetRectangle(var70, false, false);
    var16.drawRangeMarker(var29, var30, var40, (org.jfree.chart.plot.Marker)var43, var73);
    java.lang.Object var75 = var43.clone();
    java.awt.Color var77 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var78 = var77.getBlue();
    var43.setOutlinePaint((java.awt.Paint)var77);
    org.jfree.chart.block.LabelBlock var80 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", var13, (java.awt.Paint)var77);
    var80.setToolTipText("#64000d");
    java.lang.String var83 = var80.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test460"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var25 = var22.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    org.jfree.chart.util.RectangleInsets var27 = var26.getMargin();
    var19.setItemLabelPadding(var27);
    java.awt.geom.Rectangle2D var29 = var19.getBounds();
    var12.addLegend(var19);
    org.jfree.chart.util.RectangleAnchor var31 = var19.getLegendItemGraphicLocation();
    org.jfree.chart.util.RectangleInsets var32 = var19.getItemLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test461"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Polar Plot", var1, 0.0f, 100.0f, 100.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test462"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    double var7 = var2.getItemMargin();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var14 = var11.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    org.jfree.chart.util.RectangleInsets var23 = var22.getMargin();
    var15.setItemLabelPadding(var23);
    java.awt.geom.Rectangle2D var25 = var15.getBounds();
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var29 = var2.initialise(var8, var25, var26, 10, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test463"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedDomainAxisSpace();
    int var16 = var12.getRangeAxisCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    var12.setRenderer(100, var18, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test464"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.text.DateFormat var5 = var1.getDateFormatOverride();
    org.jfree.chart.plot.Plot var6 = var1.getPlot();
    var1.setInverted(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test465"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test466"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    var1.setTickLabelsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test467"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    var2.setBaseSeriesVisible(false);
    java.awt.Stroke var10 = var2.getSeriesStroke(10);
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var15 = null;
    var13.setSeriesPositiveItemLabelPosition(100, var15);
    java.awt.Stroke var17 = var13.getBaseOutlineStroke();
    double var18 = var13.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var23 = var21.getSeriesNegativeItemLabelPosition(13);
    var13.setBasePositiveItemLabelPosition(var23, true);
    double var26 = var23.getAngle();
    org.jfree.chart.labels.ItemLabelAnchor var27 = var23.getItemLabelAnchor();
    var2.setPositiveItemLabelPositionFallback(var23);
    java.awt.Stroke var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseStroke(var29, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test468"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    double var15 = var12.getAngle();
    org.jfree.chart.labels.ItemLabelAnchor var16 = var12.getItemLabelAnchor();
    org.jfree.chart.text.TextAnchor var17 = null;
    org.jfree.chart.text.TextAnchor var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var20 = new org.jfree.chart.labels.ItemLabelPosition(var16, var17, var18, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test469"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var20};
    var12.setRenderers(var21);
    var12.configureDomainAxes();
    org.jfree.chart.plot.IntervalMarker var27 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    var30.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var38 = var30.getItemOutlineStroke(0, (-1));
    java.lang.Boolean var40 = var30.getSeriesCreateEntities(100);
    java.awt.Paint var42 = var30.lookupSeriesPaint(1);
    var27.setLabelPaint(var42);
    org.jfree.chart.util.Layer var44 = null;
    var12.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var27, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test470"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    boolean var8 = var2.isSeriesVisible(100);
    var2.setSeriesItemLabelsVisible(1, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test471"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 10.0d, true);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    double var12 = var7.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(13);
    var7.setBasePositiveItemLabelPosition(var17, true);
    var3.setSeriesNegativeItemLabelPosition(100, var17, false);
    var3.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test472"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
//     java.util.List var7 = var6.getLines();
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var14 = null;
//     var12.setSeriesPositiveItemLabelPosition(100, var14);
//     double var16 = var12.getItemMargin();
//     java.awt.Font var18 = null;
//     var12.setSeriesItemLabelFont(0, var18);
//     java.awt.Font var22 = var12.getItemLabelFont(0, (-1));
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("Polar Plot", var22);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
//     var27.setLabel("");
//     boolean var30 = var27.isAxisLineVisible();
//     java.text.DateFormat var31 = var27.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
//     var33.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var33);
//     var33.setRadiusGridlinesVisible(false);
//     java.awt.Paint var39 = var33.getOutlinePaint();
//     var6.addLine("Polar Plot", var22, var39);
//     org.jfree.chart.util.HorizontalAlignment var41 = var6.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var46 = null;
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("hi!");
//     var49.setLabel("");
//     boolean var52 = var49.isAxisLineVisible();
//     org.jfree.data.Range var55 = new org.jfree.data.Range(0.0d, 0.0d);
//     var49.setRange(var55, true, true);
//     org.jfree.data.Range var61 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var62 = new org.jfree.chart.block.RectangleConstraint(var55, var61);
//     org.jfree.chart.block.LengthConstraintType var63 = var62.getHeightConstraintType();
//     org.jfree.chart.block.RectangleConstraint var64 = var62.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var65 = var45.arrange(var46, var47, var62);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test473"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
    org.jfree.chart.axis.ValueAxis var16 = null;
    int var17 = var12.getRangeAxisIndex(var16);
    org.jfree.chart.plot.SeriesRenderingOrder var18 = var12.getSeriesRenderingOrder();
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setRenderer((-1), var20, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test474"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    java.awt.Paint var15 = var12.getDomainGridlinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    int var17 = var12.getIndexOf(var16);
    org.jfree.data.xy.XYDataset var19 = null;
    var12.setDataset(100, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test475"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    var2.setSeriesShapesFilled(13, false);
    org.jfree.chart.plot.CategoryPlot var6 = var2.getPlot();
    var2.setSeriesShapesFilled(13, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test476"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    var9.setLabel("");
    boolean var12 = var9.isAxisLineVisible();
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    var9.setRange(var15, true, true);
    org.jfree.data.Range var21 = org.jfree.data.Range.expand(var15, 0.0d, 0.0d);
    boolean var22 = var6.equals((java.lang.Object)0.0d);
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.text.TextBlockAnchor var26 = null;
    var6.draw(var23, 1.0f, 100.0f, var26, 1.0f, 0.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test477"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 10.0d, true);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    double var12 = var7.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(13);
    var7.setBasePositiveItemLabelPosition(var17, true);
    var3.setSeriesNegativeItemLabelPosition(100, var17, false);
    java.awt.Paint var23 = var3.lookupSeriesPaint(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test478"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var7 = var2.lookupSeriesOutlineStroke(10);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
    var11.setLabel("");
    boolean var14 = var11.isAxisLineVisible();
    java.text.DateFormat var15 = var11.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var16);
    var17.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    org.jfree.chart.util.RectangleInsets var35 = var34.getMargin();
    var27.setItemLabelPadding(var35);
    java.awt.geom.Rectangle2D var37 = var27.getBounds();
    var20.addLegend(var27);
    org.jfree.chart.event.ChartChangeEventType var39 = null;
    org.jfree.chart.event.ChartChangeEvent var40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var20, var39);
    org.jfree.chart.JFreeChart var41 = var40.getChart();
    org.jfree.chart.JFreeChart var42 = var40.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test479"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("(100.0, 10.0)");

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test480"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var6 = null;
//     var4.setSeriesPositiveItemLabelPosition(100, var6);
//     double var8 = var4.getItemMargin();
//     java.awt.Font var10 = null;
//     var4.setSeriesItemLabelFont(0, var10);
//     java.awt.Font var14 = var4.getItemLabelFont(0, (-1));
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("Polar Plot", var14);
//     org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var20 = null;
//     var18.setSeriesPositiveItemLabelPosition(100, var20);
//     java.awt.Stroke var22 = var18.getBaseOutlineStroke();
//     double var23 = var18.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var26.getSeriesNegativeItemLabelPosition(13);
//     var18.setBasePositiveItemLabelPosition(var28, true);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = null;
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
//     var35.setLabel("");
//     boolean var38 = var35.isAxisLineVisible();
//     java.text.DateFormat var39 = var35.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, var40);
//     org.jfree.chart.axis.ValueAxis var42 = var41.getAxis();
//     org.jfree.chart.plot.IntervalMarker var45 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var46 = null;
//     var45.notifyListeners(var46);
//     org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var53 = var50.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
//     org.jfree.chart.util.RectangleInsets var55 = var54.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var61 = var58.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
//     org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var68 = var65.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var65);
//     org.jfree.chart.util.RectangleInsets var70 = var69.getMargin();
//     var62.setItemLabelPadding(var70);
//     java.awt.geom.Rectangle2D var72 = var62.getBounds();
//     java.awt.geom.Rectangle2D var75 = var55.createInsetRectangle(var72, false, false);
//     var18.drawRangeMarker(var31, var32, var42, (org.jfree.chart.plot.Marker)var45, var75);
//     java.lang.Object var77 = var45.clone();
//     java.awt.Color var79 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var80 = var79.getBlue();
//     var45.setOutlinePaint((java.awt.Paint)var79);
//     org.jfree.chart.text.TextBlock var82 = org.jfree.chart.text.TextUtilities.createTextBlock("Polar Plot", var14, (java.awt.Paint)var79);
//     java.awt.Graphics2D var83 = null;
//     org.jfree.chart.text.TextBlockAnchor var86 = null;
//     var82.draw(var83, 100.0f, 0.0f, var86, 1.0f, 100.0f, 1.0d);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test481"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    var12.setDomainGridlinesVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var17 = var12.getQuadrantPaint((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test482"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.text.DateFormat var7 = null;
    org.jfree.chart.axis.DateTickUnit var8 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var7);
    var1.setTickUnit(var8, false, false);
    boolean var12 = var1.isVisible();
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
    var14.setLabel("");
    boolean var17 = var14.isAxisLineVisible();
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
    var14.setRange(var20, true, true);
    boolean var24 = var14.isAutoRange();
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
    var27.setLabel("");
    boolean var30 = var27.isAxisLineVisible();
    java.text.DateFormat var31 = var27.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
    org.jfree.chart.axis.ValueAxis var34 = var33.getAxis();
    org.jfree.data.xy.XYDataset var35 = null;
    var33.setDataset(var35);
    org.jfree.chart.util.RectangleInsets var37 = var33.getInsets();
    double var39 = var37.trimHeight(10.0d);
    var14.setLabelInsets(var37);
    double var42 = var37.extendHeight(0.0d);
    double var44 = var37.trimHeight((-1.0d));
    var1.setTickLabelInsets(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-9.0d));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test483"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var8.datasetChanged(var11);
    org.jfree.chart.plot.Plot var13 = var8.getRootPlot();
    var8.setAngleGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test484"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setAngleLabelsVisible(true);
    var8.addCornerTextItem("hi!");
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("hi!");
    var17.setLabel("");
    boolean var20 = var17.isAxisLineVisible();
    java.text.DateFormat var21 = var17.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, var22);
    org.jfree.chart.axis.ValueAxis var24 = var23.getAxis();
    org.jfree.data.xy.XYDataset var25 = null;
    var23.setDataset(var25);
    org.jfree.chart.util.RectangleInsets var27 = var23.getInsets();
    org.jfree.chart.event.PlotChangeListener var28 = null;
    var23.addChangeListener(var28);
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleAnchor var33 = null;
    java.awt.geom.Point2D var34 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var33);
    var23.zoomRangeAxes(10.0d, var31, var34);
    var8.zoomDomainAxes((-9.223372036854776E18d), var14, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test485"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    var2.setAutoPopulateSeriesShape(true);
    var2.setBaseSeriesVisible(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test486"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.VerticalAlignment var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setVerticalAlignment(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test487"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
    var50.setFillPaint(var56);
    boolean var58 = var50.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test488"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.lang.Object var61 = var29.clone();
    java.awt.Color var63 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var64 = var63.getBlue();
    var29.setOutlinePaint((java.awt.Paint)var63);
    double var66 = var29.getStartValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test489"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test490"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setLowerBound((-1.0d));
//     java.text.DateFormat var5 = var2.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
//     var7.setUpperBound(1.0d);
//     boolean var10 = var7.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var12.handleClick((-1), 13, var16);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test491"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedDomainAxisSpace();
    int var16 = var12.getRangeAxisCount();
    java.util.List var17 = var12.getAnnotations();
    int var18 = var12.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test492"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var6 = var5.getBlue();
    var3.setBackgroundPaint((java.awt.Paint)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test493"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
    org.jfree.chart.title.LegendTitle var26 = var12.getLegend();
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var32 = var29.getItemLabelPaint((-1), 100);
    var29.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var37 = var29.getItemOutlineStroke(0, (-1));
    boolean var38 = var12.equals((java.lang.Object)0);
    org.jfree.chart.plot.Plot var39 = var12.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test494"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.text.DateFormat var5 = var1.getDateFormatOverride();
    org.jfree.chart.plot.Plot var6 = var1.getPlot();
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    var9.setSeriesPositiveItemLabelPosition(100, var11);
    double var13 = var9.getItemMargin();
    java.awt.Font var15 = null;
    var9.setSeriesItemLabelFont(0, var15);
    java.awt.Paint var17 = var9.getBaseOutlinePaint();
    var1.setLabelPaint(var17);
    java.lang.Object var19 = var1.clone();
    java.lang.String var20 = var1.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test495"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var2.notifyListeners(var3);
    java.awt.Font var6 = null;
    java.awt.Paint var7 = null;
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var7, 100.0f, 1, var10);
    java.util.List var12 = var11.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var19 = null;
    var17.setSeriesPositiveItemLabelPosition(100, var19);
    double var21 = var17.getItemMargin();
    java.awt.Font var23 = null;
    var17.setSeriesItemLabelFont(0, var23);
    java.awt.Font var27 = var17.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("Polar Plot", var27);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
    var32.setLabel("");
    boolean var35 = var32.isAxisLineVisible();
    java.text.DateFormat var36 = var32.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var37 = null;
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var37);
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var38);
    var38.setRadiusGridlinesVisible(false);
    java.awt.Paint var44 = var38.getOutlinePaint();
    var11.addLine("Polar Plot", var27, var44);
    var2.setOutlinePaint(var44);
    org.jfree.chart.util.LengthAdjustmentType var47 = var2.getLabelOffsetType();
    org.jfree.chart.util.LengthAdjustmentType var48 = var2.getLabelOffsetType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test496"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var7 = var2.lookupSeriesOutlineStroke(10);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
    var11.setLabel("");
    boolean var14 = var11.isAxisLineVisible();
    java.text.DateFormat var15 = var11.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var16);
    var17.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    org.jfree.chart.util.RectangleInsets var35 = var34.getMargin();
    var27.setItemLabelPadding(var35);
    java.awt.geom.Rectangle2D var37 = var27.getBounds();
    var20.addLegend(var27);
    org.jfree.chart.event.ChartChangeEventType var39 = null;
    org.jfree.chart.event.ChartChangeEvent var40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var20, var39);
    org.jfree.chart.JFreeChart var41 = var40.getChart();
    org.jfree.chart.event.ChartChangeListener var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var41.removeChangeListener(var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test497"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.ValueAxis var11 = var8.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test498"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    org.jfree.chart.event.ChartProgressListener var23 = null;
    var12.addProgressListener(var23);
    java.awt.Image var25 = null;
    var12.setBackgroundImage(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test499"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var14 = null;
    var12.setSeriesPositiveItemLabelPosition(100, var14);
    double var16 = var12.getItemMargin();
    java.awt.Font var18 = null;
    var12.setSeriesItemLabelFont(0, var18);
    java.awt.Font var22 = var12.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("Polar Plot", var22);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
    var27.setLabel("");
    boolean var30 = var27.isAxisLineVisible();
    java.text.DateFormat var31 = var27.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
    var33.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var33);
    var33.setRadiusGridlinesVisible(false);
    java.awt.Paint var39 = var33.getOutlinePaint();
    var6.addLine("Polar Plot", var22, var39);
    org.jfree.chart.util.HorizontalAlignment var41 = var6.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 0.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
    var52.setItemLabelPadding(var60);
    org.jfree.chart.event.TitleChangeListener var62 = null;
    var52.addChangeListener(var62);
    org.jfree.chart.renderer.category.BarRenderer3D var67 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var69 = null;
    var67.setSeriesPositiveItemLabelPosition(100, var69);
    double var71 = var67.getItemMargin();
    java.awt.Font var73 = null;
    var67.setSeriesItemLabelFont(0, var73);
    java.awt.Font var77 = var67.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var78 = new org.jfree.chart.title.TextTitle("Polar Plot", var77);
    var52.setItemFont(var77);
    org.jfree.data.time.SimpleTimePeriod var82 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var83 = var82.getStart();
    org.jfree.chart.plot.IntervalMarker var86 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var87 = null;
    var86.notifyListeners(var87);
    org.jfree.chart.util.RectangleInsets var89 = var86.getLabelOffset();
    boolean var90 = var82.equals((java.lang.Object)var86);
    var45.add((org.jfree.chart.block.Block)var52, (java.lang.Object)var82);
    org.jfree.chart.util.VerticalAlignment var92 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var52.setVerticalAlignment(var92);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test500"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    java.awt.Paint var51 = var50.getOutlinePaint();
    java.awt.Stroke var52 = var50.getLineStroke();
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.renderer.category.BarRenderer3D var62 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var65 = var62.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var62);
    org.jfree.chart.util.RectangleInsets var67 = var66.getMargin();
    var59.setItemLabelPadding(var67);
    double var70 = var67.trimHeight((-1.0d));
    double var72 = var67.calculateLeftOutset(100.0d);
    double var74 = var67.extendHeight(0.0d);
    var50.setPadding(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);

  }

}
