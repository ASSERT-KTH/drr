
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var9 = var6.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var16 = var13.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    org.jfree.chart.util.RectangleInsets var18 = var17.getMargin();
    var10.setItemLabelPadding(var18);
    java.awt.geom.Rectangle2D var20 = var10.getBounds();
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
    org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var41 = var38.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
    org.jfree.chart.util.RectangleInsets var43 = var42.getMargin();
    var35.setItemLabelPadding(var43);
    java.awt.geom.Rectangle2D var45 = var35.getBounds();
    java.awt.geom.Rectangle2D var48 = var28.createInsetRectangle(var45, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var51 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var54 = var51.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
    org.jfree.chart.util.RectangleInsets var56 = var55.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
    org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var69 = var66.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66);
    org.jfree.chart.util.RectangleInsets var71 = var70.getMargin();
    var63.setItemLabelPadding(var71);
    java.awt.geom.Rectangle2D var73 = var63.getBounds();
    java.awt.geom.Rectangle2D var76 = var56.createInsetRectangle(var73, false, false);
    boolean var77 = org.jfree.chart.util.ShapeUtilities.intersects(var48, var76);
    boolean var78 = org.jfree.chart.util.ShapeUtilities.intersects(var20, var48);
    org.jfree.chart.renderer.category.BarRenderer3D var81 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var83 = null;
    var81.setSeriesPositiveItemLabelPosition(100, var83);
    java.awt.Stroke var85 = var81.getBaseOutlineStroke();
    java.awt.Color var87 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var88 = var87.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var92 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var93 = var87.equals((java.lang.Object)"");
    java.awt.color.ColorSpace var94 = var87.getColorSpace();
    java.awt.Color var95 = var87.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var96 = new org.jfree.chart.LegendItem(var0, "org.jfree.data.time.TimePeriodFormatException: ", "Polar Plot", "", (java.awt.Shape)var48, var85, (java.awt.Paint)var95);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 10.0d, true);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    java.lang.Object var12 = var7.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var18 = var15.getItemLabelPaint((-1), 100);
    var15.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var23 = var15.getItemOutlineStroke(0, (-1));
    var7.setBaseStroke(var23);
    int var25 = var7.getRowCount();
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.plot.DrawingSupplier var32 = var28.getDrawingSupplier();
    java.awt.Paint var33 = var28.getBasePaint();
    var7.setBaseItemLabelPaint(var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSeriesItemLabelPaint((-1), var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     var3.setLabel("");
//     boolean var6 = var3.isAxisLineVisible();
//     java.text.DateFormat var7 = var3.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
//     var9.setAngleLabelsVisible(true);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     var12.setNotify(false);
//     int var15 = var12.getBackgroundImageAlignment();
//     org.jfree.chart.title.TextTitle var16 = var12.getTitle();
//     boolean var17 = var12.isNotify();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var24 = var21.getItemLabelPaint((-1), 100);
//     org.jfree.chart.labels.ItemLabelPosition var25 = var21.getPositiveItemLabelPositionFallback();
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = null;
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
//     var29.setLabel("");
//     boolean var32 = var29.isAxisLineVisible();
//     java.text.DateFormat var33 = var29.getDateFormatOverride();
//     org.jfree.chart.plot.Plot var34 = var29.getPlot();
//     org.jfree.chart.renderer.category.BarRenderer3D var37 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var39 = null;
//     var37.setSeriesPositiveItemLabelPosition(100, var39);
//     double var41 = var37.getItemMargin();
//     java.awt.Font var43 = null;
//     var37.setSeriesItemLabelFont(0, var43);
//     java.awt.Paint var45 = var37.getBaseOutlinePaint();
//     var29.setLabelPaint(var45);
//     org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
//     org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
//     org.jfree.chart.util.RectangleInsets var61 = var60.getMargin();
//     var53.setItemLabelPadding(var61);
//     double var64 = var61.trimHeight((-1.0d));
//     double var66 = var61.calculateLeftOutset(100.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var69 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var72 = var69.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var69);
//     org.jfree.chart.renderer.category.BarRenderer3D var76 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var79 = var76.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var80 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var76);
//     org.jfree.chart.util.RectangleInsets var81 = var80.getMargin();
//     var73.setItemLabelPadding(var81);
//     java.awt.geom.Rectangle2D var83 = var73.getBounds();
//     java.awt.geom.Rectangle2D var86 = var61.createInsetRectangle(var83, false, false);
//     var21.drawRangeGridline(var26, var27, (org.jfree.chart.axis.ValueAxis)var29, var86, 100.0d);
//     var12.draw(var18, var86);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
    org.jfree.chart.axis.ValueAxis var16 = null;
    int var17 = var12.getRangeAxisIndex(var16);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLowerBound((-1.0d));
    java.text.DateFormat var23 = var20.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setUpperBound(1.0d);
    boolean var28 = var25.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var25, var29);
    org.jfree.chart.plot.PlotOrientation var31 = var30.getOrientation();
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("hi!");
    var34.setUpperBound(1.0d);
    var34.resizeRange((-1.0d), 100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var44 = null;
    var42.setSeriesPositiveItemLabelPosition(100, var44);
    double var46 = var42.getItemMargin();
    java.awt.Font var48 = null;
    var42.setSeriesItemLabelFont(0, var48);
    java.awt.Font var52 = var42.getItemLabelFont(0, (-1));
    var34.setTickLabelFont(var52);
    java.awt.Font var55 = null;
    java.awt.Paint var56 = null;
    org.jfree.chart.text.TextMeasurer var59 = null;
    org.jfree.chart.text.TextBlock var60 = org.jfree.chart.text.TextUtilities.createTextBlock("", var55, var56, 100.0f, 1, var59);
    java.util.List var61 = var60.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var68 = null;
    var66.setSeriesPositiveItemLabelPosition(100, var68);
    double var70 = var66.getItemMargin();
    java.awt.Font var72 = null;
    var66.setSeriesItemLabelFont(0, var72);
    java.awt.Font var76 = var66.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var77 = new org.jfree.chart.title.TextTitle("Polar Plot", var76);
    org.jfree.data.xy.XYDataset var79 = null;
    org.jfree.chart.axis.DateAxis var81 = new org.jfree.chart.axis.DateAxis("hi!");
    var81.setLabel("");
    boolean var84 = var81.isAxisLineVisible();
    java.text.DateFormat var85 = var81.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var86 = null;
    org.jfree.chart.plot.PolarPlot var87 = new org.jfree.chart.plot.PolarPlot(var79, (org.jfree.chart.axis.ValueAxis)var81, var86);
    var87.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var90 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var87);
    var87.setRadiusGridlinesVisible(false);
    java.awt.Paint var93 = var87.getOutlinePaint();
    var60.addLine("Polar Plot", var76, var93);
    org.jfree.chart.text.TextFragment var95 = new org.jfree.chart.text.TextFragment("", var52, var93);
    boolean var96 = var31.equals((java.lang.Object)var93);
    var12.setRangeGridlinePaint(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.plot.IntervalMarker var5 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var8.setSeriesPositiveItemLabelPosition(100, var10);
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    var5.setStroke(var12);
    var2.setBaseOutlineStroke(var12);
    int var15 = var2.getPassCount();
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var20 = null;
    var18.setSeriesPositiveItemLabelPosition(100, var20);
    double var22 = var18.getItemMargin();
    java.awt.Font var24 = null;
    var18.setSeriesItemLabelFont(0, var24);
    org.jfree.chart.urls.CategoryURLGenerator var26 = var18.getBaseURLGenerator();
    boolean var27 = var2.equals((java.lang.Object)var18);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var28 = var2.getLegendItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    java.awt.Font var8 = null;
    var2.setSeriesItemLabelFont(0, var8);
    java.awt.Paint var10 = var2.getBaseOutlinePaint();
    java.awt.Paint var11 = var2.getWallPaint();
    var2.setAutoPopulateSeriesStroke(true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var2.getBaseItemLabelGenerator();
    var2.setBaseCreateEntities(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAutoRangeMinimumSize(10.0d, false);
    org.jfree.data.Range var5 = var1.getDefaultAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    var12.setDomainGridlinesVisible(false);
    org.jfree.chart.annotations.XYAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var17 = var12.removeAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "hi!");
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    var4.setName("hi!");
    java.lang.String var9 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "hi!"+ "'", var9.equals("hi!"));

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    var9.setLabel("");
    boolean var12 = var9.isAxisLineVisible();
    java.text.DateFormat var13 = var9.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var14 = null;
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var14);
    var15.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
    var18.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    var18.addSubtitle((org.jfree.chart.title.Title)var27);
    java.awt.image.BufferedImage var31 = var18.createBufferedImage(10, 1);
    org.jfree.chart.ui.ProjectInfo var35 = new org.jfree.chart.ui.ProjectInfo("", "Polar Plot", "", (java.awt.Image)var31, "Polar Plot", "Polar Plot", "Polar Plot");
    org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("", "", "org.jfree.data.time.TimePeriodFormatException: ", (java.awt.Image)var31, "(100.0, 10.0)", "Polar Plot", "org.jfree.data.time.TimePeriodFormatException: ");
    var39.addOptionalLibrary("DateTickUnit[YEAR, -1]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    org.jfree.chart.urls.CategoryURLGenerator var17 = var2.getURLGenerator(100, 10);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var24 = null;
    var22.setSeriesPositiveItemLabelPosition(100, var24);
    double var26 = var22.getItemMargin();
    java.awt.Font var28 = null;
    var22.setSeriesItemLabelFont(0, var28);
    java.awt.Font var32 = var22.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var37 = null;
    var35.setSeriesPositiveItemLabelPosition(100, var37);
    java.awt.Stroke var39 = var35.getBaseOutlineStroke();
    java.lang.Object var40 = var35.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
    var43.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var51 = var43.getItemOutlineStroke(0, (-1));
    var35.setBaseStroke(var51);
    java.awt.Paint var53 = var35.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var32, var53);
    java.awt.Color var56 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    org.jfree.chart.text.TextLine var57 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]", var32, (java.awt.Paint)var56);
    var2.setBaseItemLabelFont(var32, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setLowerBound((-1.0d));
//     java.text.DateFormat var5 = var2.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
//     var7.setUpperBound(1.0d);
//     boolean var10 = var7.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
//     var12.mapDatasetToDomainAxis(13, 10);
//     var12.setRangeGridlinesVisible(false);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("hi!");
//     var23.setLowerBound((-1.0d));
//     java.text.DateFormat var26 = var23.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
//     var28.setUpperBound(1.0d);
//     boolean var31 = var28.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var28, var32);
//     java.lang.Object var34 = var33.clone();
//     org.jfree.data.xy.XYDataset var36 = var33.getDataset(10);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     int var38 = var33.getRangeAxisIndex(var37);
//     org.jfree.chart.plot.SeriesRenderingOrder var39 = var33.getSeriesRenderingOrder();
//     var12.setSeriesRenderingOrder(var39);
//     
//     // Checks the contract:  equals-hashcode on var13 and var34
//     assertTrue("Contract failed: equals-hashcode on var13 and var34", var13.equals(var34) ? var13.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var13
//     assertTrue("Contract failed: equals-hashcode on var34 and var13", var34.equals(var13) ? var34.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.lang.Object var61 = var29.clone();
    java.awt.Color var63 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var64 = var63.getBlue();
    var29.setOutlinePaint((java.awt.Paint)var63);
    java.awt.color.ColorSpace var66 = var63.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    var1.setUpperMargin((-1.0d));
    org.jfree.data.Range var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDefaultAutoRange(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    double var15 = var12.getAngle();
    org.jfree.chart.labels.ItemLabelAnchor var16 = var12.getItemLabelAnchor();
    java.lang.Object var17 = null;
    boolean var18 = var16.equals(var17);
    org.jfree.chart.text.TextAnchor var19 = null;
    org.jfree.chart.text.TextAnchor var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var22 = new org.jfree.chart.labels.ItemLabelPosition(var16, var19, var20, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }


    org.jfree.data.time.SimpleTimePeriod var4 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var5 = var4.getStart();
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var8.notifyListeners(var9);
    org.jfree.chart.util.RectangleInsets var11 = var8.getLabelOffset();
    boolean var12 = var4.equals((java.lang.Object)var8);
    org.jfree.data.gantt.Task var13 = new org.jfree.data.gantt.Task("Polar Plot", (org.jfree.data.time.TimePeriod)var4);
    org.jfree.data.gantt.Task var14 = new org.jfree.data.gantt.Task("#64000d", (org.jfree.data.time.TimePeriod)var4);
    java.util.Date var15 = var4.getStart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    int var14 = var12.getIndexOf(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var2.resizeRange((-1.0d), (-9.223372036854776E18d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    org.jfree.chart.axis.ValueAxis var10 = var9.getAxis();
    org.jfree.data.xy.XYDataset var11 = null;
    var9.setDataset(var11);
    org.jfree.chart.util.RectangleInsets var13 = var9.getInsets();
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var9.addChangeListener(var14);
    java.lang.String var16 = var9.getPlotType();
    boolean var17 = var9.isOutlineVisible();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var18.fireChartChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Polar Plot"+ "'", var16.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    var12.clearDomainMarkers();
    org.jfree.data.general.DatasetChangeEvent var14 = null;
    var12.datasetChanged(var14);
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("hi!");
    var23.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var30 = null;
    var28.setSeriesPositiveItemLabelPosition(100, var30);
    java.awt.Stroke var32 = var28.getBaseOutlineStroke();
    var23.setAxisLineStroke(var32);
    var18.setBaseOutlineStroke(var32);
    var12.setRangeZeroBaselineStroke(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    double var7 = var2.getItemMargin();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setLowerBound((-1.0d));
    java.text.DateFormat var13 = var10.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setUpperBound(1.0d);
    boolean var18 = var15.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var15, var19);
    var2.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
    var20.setDomainZeroBaselineVisible(false);
    org.jfree.chart.util.Layer var25 = null;
    java.util.Collection var26 = var20.getRangeMarkers(10, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setMaximumCategoryLabelWidthRatio(0.0f);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    boolean var7 = var2.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    var2.setBaseItemLabelGenerator(var8);
    java.awt.Shape var11 = var2.getSeriesShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    var2.setSeriesShapesFilled(13, false);
    org.jfree.chart.plot.CategoryPlot var6 = var2.getPlot();
    var2.setBaseSeriesVisibleInLegend(false, true);
    var2.setBaseShapesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", var3);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("(100.0, 10.0)");

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test27"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
    float var16 = var12.getBackgroundAlpha();
    org.jfree.chart.plot.IntervalMarker var19 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var24 = null;
    var22.setSeriesPositiveItemLabelPosition(100, var24);
    java.awt.Stroke var26 = var22.getBaseOutlineStroke();
    var19.setStroke(var26);
    org.jfree.chart.util.RectangleInsets var28 = var19.getLabelOffset();
    org.jfree.chart.util.Layer var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.addDomainMarker((org.jfree.chart.plot.Marker)var19, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test28"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAutoRangeMinimumSize(10.0d, false);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var10 = var7.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    var11.setItemLabelPadding(var19);
    java.awt.geom.Rectangle2D var21 = var11.getBounds();
    var1.setLeftArrow((java.awt.Shape)var21);
    org.jfree.data.time.SimpleTimePeriod var26 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var27 = var26.getStart();
    org.jfree.data.time.SimpleTimePeriod var30 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var31 = var30.getEnd();
    org.jfree.data.gantt.Task var32 = new org.jfree.data.gantt.Task("", var27, var31);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
    org.jfree.chart.util.RectangleInsets var40 = var39.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
    org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var53 = var50.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
    org.jfree.chart.util.RectangleInsets var55 = var54.getMargin();
    var47.setItemLabelPadding(var55);
    java.awt.geom.Rectangle2D var57 = var47.getBounds();
    java.awt.geom.Rectangle2D var60 = var40.createInsetRectangle(var57, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
    org.jfree.chart.util.RectangleEdge var69 = var67.getLegendItemGraphicEdge();
    double var70 = var1.dateToJava2D(var31, var57, var69);
    org.jfree.data.xy.XYDataset var72 = null;
    org.jfree.chart.axis.DateAxis var74 = new org.jfree.chart.axis.DateAxis("hi!");
    var74.setLabel("");
    boolean var77 = var74.isAxisLineVisible();
    java.text.DateFormat var78 = var74.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var79 = null;
    org.jfree.chart.plot.PolarPlot var80 = new org.jfree.chart.plot.PolarPlot(var72, (org.jfree.chart.axis.ValueAxis)var74, var79);
    var80.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var83 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var80);
    var83.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var88 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var91 = var88.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var92 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var88);
    var83.addSubtitle((org.jfree.chart.title.Title)var92);
    java.awt.image.BufferedImage var96 = var83.createBufferedImage(10, 1);
    org.jfree.chart.title.LegendTitle var97 = var83.getLegend();
    boolean var98 = var1.hasListener((java.util.EventListener)var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == false);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test29"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var8.addChangeListener(var13);
    boolean var15 = var8.isAngleLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test30"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
    var50.setFillPaint(var56);
    java.awt.Stroke var58 = var50.getLineStroke();
    org.jfree.chart.util.RectangleAnchor var59 = var50.getShapeLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test31"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Range[0.0,0.0]", var1, var2);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test32"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    boolean var3 = var2.getUseFillPaint();
    org.jfree.chart.urls.StandardCategoryURLGenerator var8 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Range[0.0,0.0]", "", "DateTickUnit[YEAR, -1]");
    var2.setSeriesURLGenerator(10, (org.jfree.chart.urls.CategoryURLGenerator)var8, false);
    var2.setSeriesShapesFilled(0, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test33"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
    org.jfree.chart.LegendItem var8 = null;
    var7.add(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test34"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    double var7 = var2.getItemMargin();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setLowerBound((-1.0d));
    java.text.DateFormat var13 = var10.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setUpperBound(1.0d);
    boolean var18 = var15.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var15, var19);
    var2.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
    var20.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var27 = null;
    var26.notifyListeners(var27);
    java.awt.Font var30 = null;
    java.awt.Paint var31 = null;
    org.jfree.chart.text.TextMeasurer var34 = null;
    org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, var31, 100.0f, 1, var34);
    java.util.List var36 = var35.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var43 = null;
    var41.setSeriesPositiveItemLabelPosition(100, var43);
    double var45 = var41.getItemMargin();
    java.awt.Font var47 = null;
    var41.setSeriesItemLabelFont(0, var47);
    java.awt.Font var51 = var41.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle("Polar Plot", var51);
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("hi!");
    var56.setLabel("");
    boolean var59 = var56.isAxisLineVisible();
    java.text.DateFormat var60 = var56.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var61 = null;
    org.jfree.chart.plot.PolarPlot var62 = new org.jfree.chart.plot.PolarPlot(var54, (org.jfree.chart.axis.ValueAxis)var56, var61);
    var62.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var62);
    var62.setRadiusGridlinesVisible(false);
    java.awt.Paint var68 = var62.getOutlinePaint();
    var35.addLine("Polar Plot", var51, var68);
    var26.setOutlinePaint(var68);
    org.jfree.chart.util.LengthAdjustmentType var71 = var26.getLabelOffsetType();
    var20.addRangeMarker((org.jfree.chart.plot.Marker)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test35"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("Polar Plot", var13);
    double var15 = var14.getHeight();
    var14.setID("Range[0.0,0.0]");
    var14.setText("Polar Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test36"); }


    java.awt.Color var3 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    java.lang.Object var11 = var6.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    var14.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var22 = var14.getItemOutlineStroke(0, (-1));
    var6.setBaseStroke(var22);
    java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var26 = var25.getBlue();
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setLabel("");
    boolean var34 = var31.isAxisLineVisible();
    java.text.DateFormat var35 = var31.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var36 = null;
    org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, var36);
    var37.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var37);
    var37.setRadiusGridlinesVisible(false);
    java.awt.Paint var43 = var37.getOutlinePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var48 = null;
    var46.setSeriesPositiveItemLabelPosition(100, var48);
    java.awt.Stroke var50 = var46.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryMarker var51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)0L, var43, var50);
    org.jfree.chart.plot.IntervalMarker var53 = new org.jfree.chart.plot.IntervalMarker(10.0d, 1.0d, (java.awt.Paint)var3, var22, (java.awt.Paint)var25, var50, 0.0f);
    org.jfree.data.general.SeriesChangeEvent var54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test37"); }


    java.text.DateFormat var4 = null;
    org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var4);
    int var6 = var5.getRollUnit();
    int var7 = var5.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var10 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var11 = var10.getStart();
    java.util.Date var12 = var5.rollDate(var11);
    int var13 = var5.getRollCount();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    boolean var18 = var5.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test38"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var6 = var5.getUpArrow();
    boolean var7 = var1.equals((java.lang.Object)var6);
    double var8 = var1.getLimit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test39"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    double var17 = var14.trimHeight((-1.0d));
    double var19 = var14.calculateLeftOutset(100.0d);
    double var20 = var14.getLeft();
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    org.jfree.chart.util.RectangleInsets var35 = var34.getMargin();
    var27.setItemLabelPadding(var35);
    java.awt.geom.Rectangle2D var37 = var27.getBounds();
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
    var52.setItemLabelPadding(var60);
    java.awt.geom.Rectangle2D var62 = var52.getBounds();
    java.awt.geom.Rectangle2D var65 = var45.createInsetRectangle(var62, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var68 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var71 = var68.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var72 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var68);
    org.jfree.chart.util.RectangleInsets var73 = var72.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var76 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var79 = var76.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var80 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var76);
    org.jfree.chart.renderer.category.BarRenderer3D var83 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var86 = var83.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var87 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var83);
    org.jfree.chart.util.RectangleInsets var88 = var87.getMargin();
    var80.setItemLabelPadding(var88);
    java.awt.geom.Rectangle2D var90 = var80.getBounds();
    java.awt.geom.Rectangle2D var93 = var73.createInsetRectangle(var90, false, false);
    boolean var94 = org.jfree.chart.util.ShapeUtilities.intersects(var65, var93);
    boolean var95 = org.jfree.chart.util.ShapeUtilities.intersects(var37, var65);
    org.jfree.chart.entity.ChartEntity var97 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var37, "Polar Plot");
    java.awt.geom.Rectangle2D var98 = var14.createOutsetRectangle(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test40"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.JFreeChart var4 = var1.getPieChart();
    org.jfree.chart.LegendItemCollection var5 = var1.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test41"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     boolean var8 = var2.isSeriesVisible(100);
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var14 = null;
//     var12.setSeriesPositiveItemLabelPosition(100, var14);
//     java.awt.Stroke var16 = var12.getBaseOutlineStroke();
//     double var17 = var12.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesNegativeItemLabelPosition(13);
//     var12.setBasePositiveItemLabelPosition(var22, true);
//     var2.setSeriesNegativeItemLabelPosition(10, var22, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var2.", var12.equals(var2) == var2.equals(var12));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var20 and var2.", var20.equals(var2) == var2.equals(var20));
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test42"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    java.awt.Font var4 = var1.getItemLabelFont(0, 1);
    double var5 = var1.getBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test43"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("(100.0, 10.0)", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test44"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setPositiveArrowVisible(true);
    boolean var4 = var1.isNegativeArrowVisible();
    java.util.EventListener var5 = null;
    boolean var6 = var1.hasListener(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test45"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var14 = null;
    var12.setSeriesPositiveItemLabelPosition(100, var14);
    double var16 = var12.getItemMargin();
    java.awt.Font var18 = null;
    var12.setSeriesItemLabelFont(0, var18);
    java.awt.Font var22 = var12.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("Polar Plot", var22);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
    var27.setLabel("");
    boolean var30 = var27.isAxisLineVisible();
    java.text.DateFormat var31 = var27.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
    var33.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var33);
    var33.setRadiusGridlinesVisible(false);
    java.awt.Paint var39 = var33.getOutlinePaint();
    var6.addLine("Polar Plot", var22, var39);
    org.jfree.chart.util.HorizontalAlignment var41 = var6.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var46 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var45);
    java.awt.Graphics2D var47 = null;
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("hi!");
    var49.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var54 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var56 = null;
    var54.setSeriesPositiveItemLabelPosition(100, var56);
    java.awt.Stroke var58 = var54.getBaseOutlineStroke();
    var49.setAxisLineStroke(var58);
    var49.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var64 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var67 = var64.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var64);
    org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var74 = var71.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var71);
    org.jfree.chart.util.RectangleInsets var76 = var75.getMargin();
    var68.setItemLabelPadding(var76);
    java.awt.geom.Rectangle2D var78 = var68.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var81 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var49, (java.awt.Shape)var78, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var83 = new org.jfree.chart.axis.DateAxis("hi!");
    var83.setLabel("");
    boolean var86 = var83.isAxisLineVisible();
    org.jfree.data.Range var89 = new org.jfree.data.Range(0.0d, 0.0d);
    var83.setRange(var89, true, true);
    var49.setRange(var89, false, false);
    org.jfree.chart.block.RectangleConstraint var97 = new org.jfree.chart.block.RectangleConstraint(var89, 1.0d);
    double var98 = var97.getWidth();
    org.jfree.chart.util.Size2D var99 = var46.arrange(var47, var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test46"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)100.0d, (java.lang.Number)10.0f);
    java.lang.Number var3 = var2.getValue();
    java.lang.Number var4 = null;
    var2.setValue(var4);
    java.lang.Number var6 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0f+ "'", var3.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test47"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    double var2 = var1.getFixedAutoRange();
    double var3 = var1.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test48"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setLabel("");
    boolean var13 = var10.isAxisLineVisible();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var16.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.LegendItemCollection var21 = var16.getLegendItems();
    boolean var22 = var10.equals((java.lang.Object)var21);
    var8.setAxis((org.jfree.chart.axis.ValueAxis)var10);
    var10.setFixedAutoRange((-9.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test49"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test50"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var20};
    var12.setRenderers(var21);
    var12.configureDomainAxes();
    org.jfree.data.xy.XYDataset var24 = null;
    int var25 = var12.indexOf(var24);
    org.jfree.chart.event.RendererChangeEvent var26 = null;
    var12.rendererChanged(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test51"); }


    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
    var12.setLabel("");
    boolean var15 = var12.isAxisLineVisible();
    java.text.DateFormat var16 = var12.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var17);
    var18.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var18);
    var21.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var29 = var26.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
    var21.addSubtitle((org.jfree.chart.title.Title)var30);
    java.awt.image.BufferedImage var34 = var21.createBufferedImage(10, 1);
    org.jfree.chart.ui.ProjectInfo var38 = new org.jfree.chart.ui.ProjectInfo("", "Polar Plot", "", (java.awt.Image)var34, "Polar Plot", "Polar Plot", "Polar Plot");
    org.jfree.chart.ui.ProjectInfo var42 = new org.jfree.chart.ui.ProjectInfo("", "", "org.jfree.data.time.TimePeriodFormatException: ", (java.awt.Image)var34, "(100.0, 10.0)", "Polar Plot", "org.jfree.data.time.TimePeriodFormatException: ");
    org.jfree.chart.ui.ProjectInfo var46 = new org.jfree.chart.ui.ProjectInfo("Range[0.0,0.0]", "", "#64000d", (java.awt.Image)var34, "DateTickUnit[YEAR, -1]", "Range[0.0,0.0]", "#64000d");
    java.util.List var47 = var46.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test52"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("Polar Plot", var13);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    org.jfree.chart.util.RectangleInsets var23 = var22.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var29 = var26.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
    org.jfree.chart.renderer.category.BarRenderer3D var33 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var36 = var33.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
    org.jfree.chart.util.RectangleInsets var38 = var37.getMargin();
    var30.setItemLabelPadding(var38);
    java.awt.geom.Rectangle2D var40 = var30.getBounds();
    java.awt.geom.Rectangle2D var43 = var23.createInsetRectangle(var40, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var49 = var46.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46);
    org.jfree.chart.util.RectangleInsets var51 = var50.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var54 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var57 = var54.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54);
    org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var64 = var61.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var61);
    org.jfree.chart.util.RectangleInsets var66 = var65.getMargin();
    var58.setItemLabelPadding(var66);
    java.awt.geom.Rectangle2D var68 = var58.getBounds();
    java.awt.geom.Rectangle2D var71 = var51.createInsetRectangle(var68, false, false);
    boolean var72 = org.jfree.chart.util.ShapeUtilities.intersects(var43, var71);
    var14.draw(var15, var43);
    java.awt.Paint var74 = null;
    var14.setBackgroundPaint(var74);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var78 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Stroke var81 = var78.getItemOutlineStroke((-1), (-1));
    java.awt.Paint var84 = var78.getItemLabelPaint(100, 0);
    var14.setPaint(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test53"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 10.0d, true);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test54"); }


    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var6 = null;
    var4.setSeriesPositiveItemLabelPosition(100, var6);
    double var8 = var4.getItemMargin();
    java.awt.Font var10 = null;
    var4.setSeriesItemLabelFont(0, var10);
    java.awt.Font var14 = var4.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var19 = null;
    var17.setSeriesPositiveItemLabelPosition(100, var19);
    java.awt.Stroke var21 = var17.getBaseOutlineStroke();
    double var22 = var17.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var27 = var25.getSeriesNegativeItemLabelPosition(13);
    var17.setBasePositiveItemLabelPosition(var27, true);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = null;
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("hi!");
    var34.setLabel("");
    boolean var37 = var34.isAxisLineVisible();
    java.text.DateFormat var38 = var34.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var39 = null;
    org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot(var32, (org.jfree.chart.axis.ValueAxis)var34, var39);
    org.jfree.chart.axis.ValueAxis var41 = var40.getAxis();
    org.jfree.chart.plot.IntervalMarker var44 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var45 = null;
    var44.notifyListeners(var45);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var57 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var60 = var57.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57);
    org.jfree.chart.renderer.category.BarRenderer3D var64 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var67 = var64.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var64);
    org.jfree.chart.util.RectangleInsets var69 = var68.getMargin();
    var61.setItemLabelPadding(var69);
    java.awt.geom.Rectangle2D var71 = var61.getBounds();
    java.awt.geom.Rectangle2D var74 = var54.createInsetRectangle(var71, false, false);
    var17.drawRangeMarker(var30, var31, var41, (org.jfree.chart.plot.Marker)var44, var74);
    java.lang.Object var76 = var44.clone();
    java.awt.Color var78 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var79 = var78.getBlue();
    var44.setOutlinePaint((java.awt.Paint)var78);
    org.jfree.chart.block.LabelBlock var81 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", var14, (java.awt.Paint)var78);
    org.jfree.chart.block.LabelBlock var82 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var14);
    var82.setURLText("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test55"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.awt.Stroke var13 = var12.getRangeCrosshairStroke();
    var12.setWeight((-1));
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    var18.setLabel("");
    boolean var21 = var18.isAxisLineVisible();
    java.text.DateFormat var22 = var18.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var23 = null;
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot(var16, (org.jfree.chart.axis.ValueAxis)var18, var23);
    var24.setAngleLabelsVisible(true);
    var24.setBackgroundImageAlignment(0);
    org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var34 = null;
    var32.setSeriesPositiveItemLabelPosition(100, var34);
    double var36 = var32.getItemMargin();
    java.awt.Font var38 = null;
    var32.setSeriesItemLabelFont(0, var38);
    java.awt.Font var42 = var32.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var47 = null;
    var45.setSeriesPositiveItemLabelPosition(100, var47);
    java.awt.Stroke var49 = var45.getBaseOutlineStroke();
    java.lang.Object var50 = var45.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
    var53.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var61 = var53.getItemOutlineStroke(0, (-1));
    var45.setBaseStroke(var61);
    java.awt.Paint var63 = var45.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("", var42, var63);
    boolean var65 = var24.equals((java.lang.Object)var64);
    org.jfree.chart.axis.ValueAxis var66 = var24.getAxis();
    int var67 = var12.getRangeAxisIndex(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == (-1));

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test56"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    double var17 = var6.getContentXOffset();
    java.lang.Object var18 = var6.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test57"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.renderer.category.BarRenderer3D var70 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var73 = var70.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var70);
    org.jfree.chart.util.RectangleInsets var75 = var74.getMargin();
    var67.setItemLabelPadding(var75);
    java.awt.Paint var77 = var67.getItemPaint();
    java.lang.Object var78 = var67.clone();
    java.awt.Paint var79 = var67.getItemPaint();
    var29.setPaint(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test58"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.util.RectangleEdge var14 = var12.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test59"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test60"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAutoRangeMinimumSize(10.0d, false);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var10 = var7.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    var11.setItemLabelPadding(var19);
    java.awt.geom.Rectangle2D var21 = var11.getBounds();
    var1.setLeftArrow((java.awt.Shape)var21);
    org.jfree.data.time.SimpleTimePeriod var26 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var27 = var26.getStart();
    org.jfree.data.time.SimpleTimePeriod var30 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var31 = var30.getEnd();
    org.jfree.data.gantt.Task var32 = new org.jfree.data.gantt.Task("", var27, var31);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
    org.jfree.chart.util.RectangleInsets var40 = var39.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
    org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var53 = var50.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
    org.jfree.chart.util.RectangleInsets var55 = var54.getMargin();
    var47.setItemLabelPadding(var55);
    java.awt.geom.Rectangle2D var57 = var47.getBounds();
    java.awt.geom.Rectangle2D var60 = var40.createInsetRectangle(var57, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
    org.jfree.chart.util.RectangleEdge var69 = var67.getLegendItemGraphicEdge();
    double var70 = var1.dateToJava2D(var31, var57, var69);
    java.awt.Shape var71 = var1.getUpArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test61"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.plot.DrawingSupplier var6 = var2.getDrawingSupplier();
    java.awt.Paint var7 = var2.getBasePaint();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = var2.getLegendItemToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test62"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    double var7 = var2.getBase();
    java.awt.Shape var10 = var2.getItemShape(1, 0);
    double var11 = var2.getXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test63"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.lang.Object var7 = var6.clone();
    var6.setBaseShapesFilled(false);
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var16 = var13.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    org.jfree.chart.util.RectangleInsets var18 = var17.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var24 = var21.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    org.jfree.chart.util.RectangleInsets var33 = var32.getMargin();
    var25.setItemLabelPadding(var33);
    java.awt.geom.Rectangle2D var35 = var25.getBounds();
    java.awt.geom.Rectangle2D var38 = var18.createInsetRectangle(var35, false, false);
    var6.setSeriesShape(1, (java.awt.Shape)var38, true);
    org.jfree.chart.util.RectangleEdge var41 = null;
    double var42 = var1.valueToJava2D(100.0d, var38, var41);
    double var43 = var1.getUpperMargin();
    org.jfree.data.xy.XYDataset var44 = null;
    org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis("hi!");
    var46.setLowerBound((-1.0d));
    java.text.DateFormat var49 = var46.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis("hi!");
    var51.setUpperBound(1.0d);
    boolean var54 = var51.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
    org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var44, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.chart.axis.ValueAxis)var51, var55);
    org.jfree.chart.LegendItemCollection var57 = null;
    var56.setFixedLegendItems(var57);
    org.jfree.chart.axis.ValueAxis var60 = var56.getRangeAxis(100);
    var56.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var65 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var64};
    var56.setRenderers(var65);
    var56.configureDomainAxes();
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test64"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    var1.setAutoRangeStickyZero(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test65"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker((-1.0d));

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test66"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    var18.setLabel("");
    boolean var21 = var18.isAxisLineVisible();
    org.jfree.data.Range var24 = new org.jfree.data.Range(0.0d, 0.0d);
    var18.setRange(var24, true, true);
    boolean var28 = var18.isAutoRange();
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setLabel("");
    boolean var34 = var31.isAxisLineVisible();
    java.text.DateFormat var35 = var31.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var36 = null;
    org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, var36);
    org.jfree.chart.axis.ValueAxis var38 = var37.getAxis();
    org.jfree.data.xy.XYDataset var39 = null;
    var37.setDataset(var39);
    org.jfree.chart.util.RectangleInsets var41 = var37.getInsets();
    double var43 = var41.trimHeight(10.0d);
    var18.setLabelInsets(var41);
    org.jfree.chart.axis.ValueAxis[] var45 = new org.jfree.chart.axis.ValueAxis[] { var18};
    var12.setRangeAxes(var45);
    var12.setRangeCrosshairValue((-9.223372036854776E18d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test67"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var7 = var2.lookupSeriesOutlineStroke(10);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
    var11.setLabel("");
    boolean var14 = var11.isAxisLineVisible();
    java.text.DateFormat var15 = var11.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var16);
    var17.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    org.jfree.chart.util.RectangleInsets var35 = var34.getMargin();
    var27.setItemLabelPadding(var35);
    java.awt.geom.Rectangle2D var37 = var27.getBounds();
    var20.addLegend(var27);
    org.jfree.chart.event.ChartChangeEventType var39 = null;
    org.jfree.chart.event.ChartChangeEvent var40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var20, var39);
    var20.clearSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test68"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var6 = var5.getUpArrow();
    boolean var7 = var1.equals((java.lang.Object)var6);
    java.lang.String var8 = var1.getPlotType();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var1.axisChanged(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Multiple Pie Plot"+ "'", var8.equals("Multiple Pie Plot"));

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test69"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    java.awt.Shape var34 = var33.getArea();
    org.jfree.chart.axis.Axis var35 = var33.getAxis();
    var33.setToolTipText("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test70"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    java.lang.String var15 = var12.getPlotType();
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    var21.setLowerBound((-1.0d));
    java.text.DateFormat var24 = var21.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("hi!");
    var26.setUpperBound(1.0d);
    boolean var29 = var26.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var26, var30);
    org.jfree.chart.LegendItemCollection var32 = null;
    var31.setFixedLegendItems(var32);
    var31.setForegroundAlpha(100.0f);
    java.awt.Paint var36 = var31.getDomainCrosshairPaint();
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleAnchor var38 = null;
    java.awt.geom.Point2D var39 = org.jfree.chart.util.RectangleAnchor.coordinates(var37, var38);
    var31.setQuadrantOrigin(var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.zoomRangeAxes(0.0d, (-9.223372036854776E18d), var18, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "XY Plot"+ "'", var15.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test71"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "hi!");
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    java.lang.String var7 = var4.getInfo();
    var4.setLicenceName("DateTickUnit[YEAR, -1]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test72"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setLabel("");
    boolean var10 = var7.isAxisLineVisible();
    java.text.DateFormat var11 = var7.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var12 = null;
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, var12);
    var13.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
    var13.setRadiusGridlinesVisible(false);
    java.awt.Paint var19 = var13.getOutlinePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var24 = null;
    var22.setSeriesPositiveItemLabelPosition(100, var24);
    java.awt.Stroke var26 = var22.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryMarker var27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)0L, var19, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
    var30.setLabel("");
    boolean var33 = var30.isAxisLineVisible();
    java.text.DateFormat var34 = var30.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var35 = null;
    org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, var35);
    org.jfree.chart.axis.ValueAxis var37 = var36.getAxis();
    org.jfree.data.xy.XYDataset var38 = null;
    var36.setDataset(var38);
    org.jfree.chart.util.RectangleInsets var40 = var36.getInsets();
    var36.setAngleGridlinesVisible(true);
    boolean var43 = var27.equals((java.lang.Object)var36);
    org.jfree.chart.text.TextAnchor var44 = var27.getLabelTextAnchor();
    java.lang.String var45 = var44.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var47 = new org.jfree.chart.axis.NumberTick((java.lang.Number)1, "(100.0, 10.0)", var2, var44, (-9.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "TextAnchor.CENTER"+ "'", var45.equals("TextAnchor.CENTER"));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test73"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var10 = null;
    var9.notifyListeners(var10);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    var9.setLabelPaint(var17);
    var6.setBackgroundPaint(var17);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var25 = null;
    var23.setSeriesPositiveItemLabelPosition(100, var25);
    double var27 = var23.getItemMargin();
    java.awt.Font var29 = null;
    var23.setSeriesItemLabelFont(0, var29);
    java.awt.Font var33 = var23.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var38 = null;
    var36.setSeriesPositiveItemLabelPosition(100, var38);
    java.awt.Stroke var40 = var36.getBaseOutlineStroke();
    java.lang.Object var41 = var36.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var44 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var47 = var44.getItemLabelPaint((-1), 100);
    var44.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var52 = var44.getItemOutlineStroke(0, (-1));
    var36.setBaseStroke(var52);
    java.awt.Paint var54 = var36.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("", var33, var54);
    var6.setItemPaint(var54);
    var6.setMargin(0.0d, (-1.0d), (-9.0d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test74"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.awt.Shape var7 = var3.getUpArrow();
    var1.setRightArrow(var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
    var11.setLabel("");
    boolean var14 = var11.isAxisLineVisible();
    java.text.DateFormat var15 = var11.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var16);
    var17.setAngleLabelsVisible(true);
    var17.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
    var22.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var7, var22, 10, 1);
    int var27 = var26.getType();
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setLabel("");
    boolean var34 = var31.isAxisLineVisible();
    java.text.DateFormat var35 = var31.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var36 = null;
    org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, var36);
    var37.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var37);
    var40.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
    var40.addSubtitle((org.jfree.chart.title.Title)var49);
    java.awt.image.BufferedImage var53 = var40.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
    var40.setBackgroundPaint(var59);
    var40.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var68 = null;
    var66.setSeriesPositiveItemLabelPosition(100, var68);
    double var70 = var66.getItemMargin();
    java.awt.Font var72 = null;
    var66.setSeriesItemLabelFont(0, var72);
    java.awt.Font var76 = var66.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var77 = new org.jfree.chart.title.TextTitle("Polar Plot", var76);
    double var78 = var77.getHeight();
    var77.setID("Range[0.0,0.0]");
    var40.setTitle(var77);
    var26.setChart(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test75"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    boolean var15 = var12.isDomainZoomable();
    org.jfree.chart.axis.AxisLocation var17 = var12.getDomainAxisLocation(0);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var20 = var19.getStandardTickUnits();
    var19.setFixedAutoRange((-1.0d));
    boolean var23 = var17.equals((java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test76"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.chart.block.LengthConstraintType var15 = var14.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var16 = var14.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var18 = var14.toFixedHeight(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test77"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    var2.setAutoPopulateSeriesFillPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test78"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.event.ChartChangeListener var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addChangeListener(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test79"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Nearest");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test80"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    double var16 = var6.getWidth();
    var6.setID("#64000d");
    java.awt.Font var28 = null;
    java.awt.Paint var29 = null;
    org.jfree.chart.text.TextMeasurer var32 = null;
    org.jfree.chart.text.TextBlock var33 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, var29, 100.0f, 1, var32);
    java.util.List var34 = var33.getLines();
    org.jfree.data.statistics.BoxAndWhiskerItem var35 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)(short)(-1), (java.lang.Number)(short)1, (java.lang.Number)0, (java.lang.Number)(-1.0d), (java.lang.Number)100, (java.lang.Number)(byte)(-1), (java.lang.Number)(byte)0, (java.lang.Number)16.0d, var34);
    java.lang.Number var36 = var35.getMaxRegularValue();
    boolean var37 = var6.equals((java.lang.Object)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (byte)(-1)+ "'", var36.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test81"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var14 = null;
    var12.setSeriesPositiveItemLabelPosition(100, var14);
    double var16 = var12.getItemMargin();
    java.awt.Font var18 = null;
    var12.setSeriesItemLabelFont(0, var18);
    java.awt.Font var22 = var12.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("Polar Plot", var22);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
    var27.setLabel("");
    boolean var30 = var27.isAxisLineVisible();
    java.text.DateFormat var31 = var27.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
    var33.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var33);
    var33.setRadiusGridlinesVisible(false);
    java.awt.Paint var39 = var33.getOutlinePaint();
    var6.addLine("Polar Plot", var22, var39);
    org.jfree.chart.util.HorizontalAlignment var41 = var6.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 0.0d);
    java.lang.String var46 = var41.toString();
    java.lang.String var47 = var41.toString();
    java.lang.String var48 = var41.toString();
    org.jfree.chart.util.VerticalAlignment var49 = null;
    org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement(var41, var49, 100.0d, (-9.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var46.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var47.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var48.equals("HorizontalAlignment.CENTER"));

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test82"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    java.awt.Font var27 = null;
    org.jfree.chart.axis.MarkerAxisBand var28 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var1, 100.0d, 10.0d, 16.0d, (-1.0d), var27);
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var31 = var30.getRangeType();
    var1.setRangeType(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test83"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    boolean var15 = var12.isNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test84"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setLowerBound((-1.0d));
//     java.text.DateFormat var5 = var2.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
//     var7.setUpperBound(1.0d);
//     boolean var10 = var7.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
//     java.lang.Object var13 = var12.clone();
//     int var14 = var12.getDomainAxisCount();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("hi!");
//     var17.setLowerBound((-1.0d));
//     java.text.DateFormat var20 = var17.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
//     var22.setUpperBound(1.0d);
//     boolean var25 = var22.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var22, var26);
//     java.lang.Object var28 = var27.clone();
//     org.jfree.data.xy.XYDataset var30 = var27.getDataset(10);
//     float var31 = var27.getBackgroundAlpha();
//     org.jfree.chart.axis.AxisLocation var33 = var27.getDomainAxisLocation(0);
//     java.lang.String var34 = var33.toString();
//     var12.setDomainAxisLocation(var33);
//     
//     // Checks the contract:  equals-hashcode on var12 and var27
//     assertTrue("Contract failed: equals-hashcode on var12 and var27", var12.equals(var27) ? var12.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var12
//     assertTrue("Contract failed: equals-hashcode on var27 and var12", var27.equals(var12) ? var27.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var28
//     assertTrue("Contract failed: equals-hashcode on var13 and var28", var13.equals(var28) ? var13.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var13
//     assertTrue("Contract failed: equals-hashcode on var28 and var13", var28.equals(var13) ? var28.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test85"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var12.setRenderer(10, var21, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test86"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.clearCategoryLabelToolTips();
    var1.setCategoryLabelPositionOffset(1);
    int var5 = var1.getMaximumCategoryLabelLines();
    java.lang.Object var6 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test87"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.annotations.XYAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.addAnnotation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test88"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 100.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test89"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.text.DateFormat var7 = null;
    org.jfree.chart.axis.DateTickUnit var8 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var7);
    var1.setTickUnit(var8, false, false);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("hi!");
    var13.setLabel("");
    boolean var16 = var13.isAxisLineVisible();
    org.jfree.data.Range var19 = new org.jfree.data.Range(0.0d, 0.0d);
    var13.setRange(var19, true, true);
    org.jfree.data.Range var25 = org.jfree.data.Range.expand(var19, 0.0d, 0.0d);
    java.lang.Object var26 = null;
    boolean var27 = var19.equals(var26);
    double var28 = var19.getLowerBound();
    var1.setRange(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test90"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLabel("");
    boolean var23 = var20.isAxisLineVisible();
    java.text.DateFormat var24 = var20.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var25);
    var26.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var29.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    var29.addSubtitle((org.jfree.chart.title.Title)var38);
    java.awt.image.BufferedImage var42 = var29.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    var29.setBackgroundPaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var16, var48);
    java.awt.Paint var51 = var50.getOutlinePaint();
    var50.setShapeFilled(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test91"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.awt.Shape var7 = var3.getUpArrow();
    var1.setRightArrow(var7);
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var7, "", "");
    var11.setToolTipText("org.jfree.data.time.TimePeriodFormatException: ");
    java.lang.String var14 = var11.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "poly"+ "'", var14.equals("poly"));

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test92"); }
// 
// 
//     org.jfree.data.time.SimpleTimePeriod var4 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var5 = var4.getStart();
//     org.jfree.data.time.SimpleTimePeriod var8 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var9 = var8.getEnd();
//     org.jfree.data.gantt.Task var10 = new org.jfree.data.gantt.Task("", var5, var9);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addMonths(100, var11);
//     java.lang.String var13 = var11.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "31-December-1969"+ "'", var13.equals("31-December-1969"));
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test93"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
    double var8 = var6.getContentXOffset();
    java.awt.Font var9 = var6.getItemFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test94"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLowerBound((-1.0d));
    java.text.DateFormat var28 = var25.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
    var30.setUpperBound(1.0d);
    boolean var33 = var30.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var30, var34);
    java.lang.Object var36 = var35.clone();
    int var37 = var35.getDomainAxisCount();
    boolean var38 = var35.isDomainZoomable();
    org.jfree.chart.axis.AxisLocation var40 = var35.getDomainAxisLocation(0);
    var15.setRangeAxisLocation(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test95"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
    var2.setBaseToolTipGenerator(var15);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var2.getLegendItemLabelGenerator();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    boolean var21 = var20.getUseFillPaint();
    org.jfree.chart.urls.StandardCategoryURLGenerator var26 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Range[0.0,0.0]", "", "DateTickUnit[YEAR, -1]");
    var20.setSeriesURLGenerator(10, (org.jfree.chart.urls.CategoryURLGenerator)var26, false);
    var2.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var26, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test96"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
    var35.setLabel("");
    boolean var38 = var35.isAxisLineVisible();
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 0.0d);
    var35.setRange(var41, true, true);
    var1.setRange(var41, false, false);
    org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(var41, 1.0d);
    double var50 = var49.getWidth();
    org.jfree.chart.block.RectangleConstraint var52 = var49.toFixedWidth((-9.223372036854776E18d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test97"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    boolean var3 = var2.getDrawOutlines();
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var8.setSeriesPositiveItemLabelPosition(100, var10);
    double var12 = var8.getItemMargin();
    java.awt.Font var14 = null;
    var8.setSeriesItemLabelFont(0, var14);
    java.awt.Font var18 = var8.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var23 = null;
    var21.setSeriesPositiveItemLabelPosition(100, var23);
    java.awt.Stroke var25 = var21.getBaseOutlineStroke();
    double var26 = var21.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var31 = var29.getSeriesNegativeItemLabelPosition(13);
    var21.setBasePositiveItemLabelPosition(var31, true);
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = null;
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("hi!");
    var38.setLabel("");
    boolean var41 = var38.isAxisLineVisible();
    java.text.DateFormat var42 = var38.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var43 = null;
    org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot(var36, (org.jfree.chart.axis.ValueAxis)var38, var43);
    org.jfree.chart.axis.ValueAxis var45 = var44.getAxis();
    org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var49 = null;
    var48.notifyListeners(var49);
    org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53);
    org.jfree.chart.util.RectangleInsets var58 = var57.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var64 = var61.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var61);
    org.jfree.chart.renderer.category.BarRenderer3D var68 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var71 = var68.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var72 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var68);
    org.jfree.chart.util.RectangleInsets var73 = var72.getMargin();
    var65.setItemLabelPadding(var73);
    java.awt.geom.Rectangle2D var75 = var65.getBounds();
    java.awt.geom.Rectangle2D var78 = var58.createInsetRectangle(var75, false, false);
    var21.drawRangeMarker(var34, var35, var45, (org.jfree.chart.plot.Marker)var48, var78);
    java.lang.Object var80 = var48.clone();
    java.awt.Color var82 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var83 = var82.getBlue();
    var48.setOutlinePaint((java.awt.Paint)var82);
    org.jfree.chart.block.LabelBlock var85 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", var18, (java.awt.Paint)var82);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelPaint((-1), (java.awt.Paint)var82);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test98"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var7.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.LegendItemCollection var12 = var7.getLegendItems();
    boolean var13 = var1.equals((java.lang.Object)var12);
    java.util.Iterator var14 = var12.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test99"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    boolean var15 = var12.isDomainZoomable();
    org.jfree.chart.axis.AxisLocation var17 = var12.getDomainAxisLocation(0);
    org.jfree.chart.event.AxisChangeEvent var18 = null;
    var12.axisChanged(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test100"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.text.DateFormat var5 = var1.getDateFormatOverride();
    org.jfree.chart.plot.Plot var6 = var1.getPlot();
    double var7 = var1.getFixedDimension();
    float var8 = var1.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test101"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    var12.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var17 = var12.getDomainAxisEdge();
    int var18 = var12.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var19 = null;
    var12.setFixedRangeAxisSpace(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test102"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(0.0d, 0.0d);
    java.util.Date var3 = var2.getUpperDate();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test103"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    var2.setAxisLineStroke(var11);
    var2.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.util.RectangleInsets var29 = var28.getMargin();
    var21.setItemLabelPadding(var29);
    java.awt.geom.Rectangle2D var31 = var21.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var31, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
    var36.setLabel("");
    boolean var39 = var36.isAxisLineVisible();
    org.jfree.data.Range var42 = new org.jfree.data.Range(0.0d, 0.0d);
    var36.setRange(var42, true, true);
    var2.setRange(var42, false, false);
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(var42, 1.0d);
    org.jfree.data.KeyedObject var51 = new org.jfree.data.KeyedObject((java.lang.Comparable)0.0f, (java.lang.Object)var42);
    java.awt.Font var53 = null;
    java.awt.Paint var54 = null;
    org.jfree.chart.text.TextMeasurer var57 = null;
    org.jfree.chart.text.TextBlock var58 = org.jfree.chart.text.TextUtilities.createTextBlock("", var53, var54, 100.0f, 1, var57);
    java.awt.Graphics2D var59 = null;
    org.jfree.chart.text.TextBlockAnchor var62 = null;
    var58.draw(var59, 0.0f, 10.0f, var62);
    boolean var64 = var51.equals((java.lang.Object)var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test104"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var2.setBaseToolTipGenerator(var7, true);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 13, 10);
    boolean var14 = var2.equals((java.lang.Object)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test105"); }
// 
// 
//     java.lang.Number[][] var0 = null;
//     java.lang.Number[] var1 = null;
//     java.lang.Number[][] var2 = new java.lang.Number[][] { var1};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
//     int var4 = var3.getRowCount();
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test106"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
    var6.setLabel("");
    boolean var9 = var6.isAxisLineVisible();
    java.text.DateFormat var10 = var6.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var11 = null;
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var11);
    var12.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var12);
    var15.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var23 = var20.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    var15.addSubtitle((org.jfree.chart.title.Title)var24);
    java.awt.image.BufferedImage var28 = var15.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
    var15.setBackgroundPaint(var34);
    org.jfree.chart.event.ChartProgressListener var36 = null;
    var15.removeProgressListener(var36);
    org.jfree.chart.event.ChartChangeEventType var38 = null;
    org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var15, var38);
    org.jfree.chart.event.ChartChangeEventType var40 = var39.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test107"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLowerBound((-1.0d));
    var1.setRange(0.0d, 1.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    var9.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var16 = null;
    var14.setSeriesPositiveItemLabelPosition(100, var16);
    java.awt.Stroke var18 = var14.getBaseOutlineStroke();
    var9.setAxisLineStroke(var18);
    var9.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
    org.jfree.chart.util.RectangleInsets var36 = var35.getMargin();
    var28.setItemLabelPadding(var36);
    java.awt.geom.Rectangle2D var38 = var28.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var9, (java.awt.Shape)var38, "hi!", "hi!");
    org.jfree.chart.renderer.category.BarRenderer3D var44 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var47 = var44.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var44);
    org.jfree.chart.util.RectangleInsets var49 = var48.getMargin();
    org.jfree.chart.util.RectangleEdge var50 = var48.getLegendItemGraphicEdge();
    double var51 = var1.java2DToValue((-1.0d), var38, var50);
    java.lang.String var52 = var50.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-9.223372036854776E18d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + "RectangleEdge.LEFT"+ "'", var52.equals("RectangleEdge.LEFT"));

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test108"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 16.0d, 1.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test109"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.ChartColor var24 = new org.jfree.chart.ChartColor(10, 13, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setQuadrantPaint(100, (java.awt.Paint)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test110"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    var2.setAutoPopulateSeriesShape(true);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.plot.CategoryPlot var11 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var13 = var2.getSeriesURLGenerator(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test111"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("#64000d");
    org.jfree.data.time.TimePeriod var3 = null;
    org.jfree.data.gantt.Task var4 = new org.jfree.data.gantt.Task("hi!", var3);
    var1.add(var4);
    java.lang.Object var6 = null;
    boolean var7 = var1.equals(var6);
    java.lang.Number[][] var8 = null;
    java.lang.Number[] var9 = null;
    java.lang.Number[][] var10 = new java.lang.Number[][] { var9};
    org.jfree.data.category.DefaultIntervalCategoryDataset var11 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var8, var10);
    var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var11);
    org.jfree.data.general.DatasetGroup var14 = new org.jfree.data.general.DatasetGroup("hi!");
    var11.setGroup(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test112"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.clearRangeMarkers();
    boolean var18 = var12.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test113"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    org.jfree.chart.urls.CategoryURLGenerator var3 = var1.getSeriesURLGenerator(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test114"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    int var8 = var2.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test115"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    int var15 = var12.getBackgroundImageAlignment();
    org.jfree.chart.title.TextTitle var16 = var12.getTitle();
    org.jfree.chart.util.RectangleInsets var17 = var16.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test116"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    boolean var34 = var1.isVerticalTickLabels();
    java.text.DateFormat var35 = var1.getDateFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test117"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    var12.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var17 = var12.getDomainAxisEdge();
    int var18 = var12.getDomainAxisCount();
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("hi!");
    var24.setLowerBound((-1.0d));
    java.text.DateFormat var27 = var24.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
    var29.setUpperBound(1.0d);
    boolean var32 = var29.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var29, var33);
    org.jfree.chart.LegendItemCollection var35 = null;
    var34.setFixedLegendItems(var35);
    org.jfree.chart.axis.ValueAxis var38 = var34.getRangeAxis(100);
    var34.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.event.RendererChangeEvent var42 = null;
    var34.rendererChanged(var42);
    var34.setRangeGridlinesVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var47 = null;
    org.jfree.data.xy.XYDataset var48 = null;
    org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis("hi!");
    var50.setLowerBound((-1.0d));
    java.text.DateFormat var53 = var50.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var55 = new org.jfree.chart.axis.DateAxis("hi!");
    var55.setUpperBound(1.0d);
    boolean var58 = var55.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
    org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var48, (org.jfree.chart.axis.ValueAxis)var50, (org.jfree.chart.axis.ValueAxis)var55, var59);
    org.jfree.chart.LegendItemCollection var61 = null;
    var60.setFixedLegendItems(var61);
    var60.setForegroundAlpha(100.0f);
    java.awt.Paint var65 = var60.getDomainCrosshairPaint();
    java.awt.geom.Rectangle2D var66 = null;
    org.jfree.chart.util.RectangleAnchor var67 = null;
    java.awt.geom.Point2D var68 = org.jfree.chart.util.RectangleAnchor.coordinates(var66, var67);
    var60.setQuadrantOrigin(var68);
    var34.zoomRangeAxes(16.0d, var47, var68);
    var12.zoomDomainAxes((-9.223372036854776E18d), 16.0d, var21, var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test118"); }


    java.awt.Font var9 = null;
    java.awt.Paint var10 = null;
    org.jfree.chart.text.TextMeasurer var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, var10, 100.0f, 1, var13);
    java.util.List var15 = var14.getLines();
    org.jfree.data.statistics.BoxAndWhiskerItem var16 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)(short)(-1), (java.lang.Number)(short)1, (java.lang.Number)0, (java.lang.Number)(-1.0d), (java.lang.Number)100, (java.lang.Number)(byte)(-1), (java.lang.Number)(byte)0, (java.lang.Number)16.0d, var15);
    java.lang.Number var17 = var16.getMaxRegularValue();
    java.lang.Number var18 = var16.getMaxRegularValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (byte)(-1)+ "'", var17.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (byte)(-1)+ "'", var18.equals((byte)(-1)));

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test119"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    var12.clearDomainMarkers();
    org.jfree.data.general.DatasetChangeEvent var14 = null;
    var12.datasetChanged(var14);
    var12.setRangeCrosshairVisible(false);
    org.jfree.chart.plot.SeriesRenderingOrder var18 = var12.getSeriesRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test120"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    boolean var2 = var1.getRenderAsPercentages();
    var1.setRenderAsPercentages(true);
    var1.setRenderAsPercentages(false);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    var9.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var17 = var9.getItemOutlineStroke(0, (-1));
    java.lang.Boolean var19 = var9.getSeriesCreateEntities(100);
    java.awt.Paint var21 = var9.lookupSeriesPaint(1);
    var1.setBaseOutlinePaint(var21, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test121"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    var2.setSeriesShapesFilled(13, false);
    org.jfree.chart.plot.CategoryPlot var6 = var2.getPlot();
    var2.setBaseSeriesVisibleInLegend(false, true);
    boolean var10 = var2.getUseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test122"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleAnchor var7 = var6.getLegendItemGraphicLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test123"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    java.awt.Paint var10 = var8.getNoDataMessagePaint();
    java.lang.Object var11 = var8.clone();
    var8.zoom(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test124"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
    var35.setLabel("");
    boolean var38 = var35.isAxisLineVisible();
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 0.0d);
    var35.setRange(var41, true, true);
    var1.setRange(var41, false, false);
    org.jfree.data.Range var50 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var53 = org.jfree.data.Range.shift(var50, 1.0d, false);
    java.lang.Object var54 = null;
    boolean var55 = var50.equals(var54);
    var1.setRangeWithMargins(var50);
    var1.setLabel("org.jfree.data.time.TimePeriodFormatException: ");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test125"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    org.jfree.chart.event.ChartProgressListener var23 = null;
    var12.addProgressListener(var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var26 = var12.getSubtitle((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test126"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    org.jfree.chart.axis.NumberTickUnit var23 = var1.getTickUnit();
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLabel("");
    boolean var28 = var25.isAxisLineVisible();
    org.jfree.data.Range var31 = new org.jfree.data.Range(0.0d, 0.0d);
    var25.setRange(var31, true, true);
    java.lang.String var35 = var31.toString();
    var1.setRangeWithMargins(var31, false, true);
    java.awt.Color var41 = java.awt.Color.getColor("#64000d", (-1));
    var1.setTickLabelPaint((java.awt.Paint)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "Range[0.0,0.0]"+ "'", var35.equals("Range[0.0,0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test127"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    java.awt.Shape var4 = var1.getUpArrow();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
    var6.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var13 = null;
    var11.setSeriesPositiveItemLabelPosition(100, var13);
    java.awt.Stroke var15 = var11.getBaseOutlineStroke();
    var6.setAxisLineStroke(var15);
    var6.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var24 = var21.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    org.jfree.chart.util.RectangleInsets var33 = var32.getMargin();
    var25.setItemLabelPadding(var33);
    java.awt.geom.Rectangle2D var35 = var25.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var38 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var6, (java.awt.Shape)var35, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis("hi!");
    var40.setLabel("");
    boolean var43 = var40.isAxisLineVisible();
    org.jfree.data.Range var46 = new org.jfree.data.Range(0.0d, 0.0d);
    var40.setRange(var46, true, true);
    var6.setRange(var46, false, false);
    org.jfree.data.Range var55 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var58 = org.jfree.data.Range.shift(var55, 1.0d, false);
    java.lang.Object var59 = null;
    boolean var60 = var55.equals(var59);
    var6.setRangeWithMargins(var55);
    org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("hi!");
    var63.setLabel("");
    boolean var66 = var63.isAxisLineVisible();
    org.jfree.data.Range var69 = new org.jfree.data.Range(0.0d, 0.0d);
    var63.setRange(var69, true, true);
    org.jfree.data.Range var73 = org.jfree.data.Range.combine(var55, var69);
    var1.setRange(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test128"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 10.0d, true);
//     org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var9 = null;
//     var7.setSeriesPositiveItemLabelPosition(100, var9);
//     java.awt.Stroke var11 = var7.getBaseOutlineStroke();
//     double var12 = var7.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(13);
//     var7.setBasePositiveItemLabelPosition(var17, true);
//     var3.setSeriesNegativeItemLabelPosition(100, var17, false);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = null;
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
//     var25.setAutoRangeMinimumSize(10.0d, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
//     org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var41 = var38.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
//     org.jfree.chart.util.RectangleInsets var43 = var42.getMargin();
//     var35.setItemLabelPadding(var43);
//     java.awt.geom.Rectangle2D var45 = var35.getBounds();
//     var25.setLeftArrow((java.awt.Shape)var45);
//     org.jfree.data.time.SimpleTimePeriod var50 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var51 = var50.getStart();
//     org.jfree.data.time.SimpleTimePeriod var54 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var55 = var54.getEnd();
//     org.jfree.data.gantt.Task var56 = new org.jfree.data.gantt.Task("", var51, var55);
//     org.jfree.chart.renderer.category.BarRenderer3D var59 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var62 = var59.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
//     org.jfree.chart.util.RectangleInsets var64 = var63.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var67 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var70 = var67.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var67);
//     org.jfree.chart.renderer.category.BarRenderer3D var74 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var77 = var74.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var78 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var74);
//     org.jfree.chart.util.RectangleInsets var79 = var78.getMargin();
//     var71.setItemLabelPadding(var79);
//     java.awt.geom.Rectangle2D var81 = var71.getBounds();
//     java.awt.geom.Rectangle2D var84 = var64.createInsetRectangle(var81, false, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var87 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var90 = var87.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var91 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var87);
//     org.jfree.chart.util.RectangleInsets var92 = var91.getMargin();
//     org.jfree.chart.util.RectangleEdge var93 = var91.getLegendItemGraphicEdge();
//     double var94 = var25.dateToJava2D(var55, var81, var93);
//     var3.drawBackground(var22, var23, var81);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test129"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    java.awt.Paint var13 = var8.getAngleLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test130"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    org.jfree.chart.plot.DatasetRenderingOrder var15 = var12.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test131"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
    var10.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var18 = var10.getItemOutlineStroke(0, (-1));
    var2.setBaseStroke(var18);
    java.awt.Paint var20 = var2.getBaseItemLabelPaint();
    double var21 = var2.getItemLabelAnchorOffset();
    org.jfree.chart.labels.ItemLabelPosition var23 = var2.getSeriesPositiveItemLabelPosition(0);
    var2.setBase(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test132"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    double var6 = var2.getItemMargin();
    org.jfree.chart.labels.CategoryItemLabelGenerator var7 = var2.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var10.setSeriesPositiveItemLabelPosition(100, var12);
    java.awt.Stroke var15 = var10.lookupSeriesOutlineStroke(10);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    var25.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var25);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
    org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var41 = var38.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
    org.jfree.chart.util.RectangleInsets var43 = var42.getMargin();
    var35.setItemLabelPadding(var43);
    java.awt.geom.Rectangle2D var45 = var35.getBounds();
    var28.addLegend(var35);
    org.jfree.chart.event.ChartChangeEventType var47 = null;
    org.jfree.chart.event.ChartChangeEvent var48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var28, var47);
    var2.setBaseStroke(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test133"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var7 = null;
    var5.setSeriesPositiveItemLabelPosition(100, var7);
    java.awt.Stroke var9 = var5.getBaseOutlineStroke();
    java.lang.Object var10 = var5.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var16 = var13.getItemLabelPaint((-1), 100);
    var13.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var21 = var13.getItemOutlineStroke(0, (-1));
    var5.setBaseStroke(var21);
    boolean var23 = var2.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test134"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.awt.Paint var61 = var2.getBaseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test135"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    java.util.List var8 = var6.getLines();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var6.calculateBounds(var9, 10.0f, 100.0f, var12, 1.0f, 100.0f, 0.0d);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var16, 16.0d, 0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test136"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     var2.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var10 = var2.getItemOutlineStroke(0, (-1));
//     org.jfree.chart.plot.DrawingSupplier var11 = var2.getDrawingSupplier();
//     org.jfree.chart.renderer.category.BarRenderer3D var15 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Stroke var17 = null;
//     var15.setSeriesOutlineStroke(100, var17);
//     org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var23 = null;
//     var21.setSeriesPositiveItemLabelPosition(100, var23);
//     java.awt.Stroke var25 = var21.getBaseOutlineStroke();
//     java.lang.Object var26 = var21.clone();
//     org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var32 = var29.getItemLabelPaint((-1), 100);
//     var29.setAutoPopulateSeriesShape(true);
//     java.awt.Stroke var37 = var29.getItemOutlineStroke(0, (-1));
//     var21.setBaseStroke(var37);
//     java.awt.Paint var39 = var21.getBaseItemLabelPaint();
//     double var40 = var21.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.ItemLabelPosition var42 = var21.getSeriesPositiveItemLabelPosition(0);
//     var15.setNegativeItemLabelPositionFallback(var42);
//     var2.setSeriesPositiveItemLabelPosition(10, var42);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var2.", var29.equals(var2) == var2.equals(var29));
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test137"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var6 = null;
    var4.setSeriesPositiveItemLabelPosition(100, var6);
    double var8 = var4.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var14 = var11.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    org.jfree.chart.util.RectangleInsets var23 = var22.getMargin();
    var15.setItemLabelPadding(var23);
    java.awt.geom.Rectangle2D var25 = var15.getBounds();
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
    var29.setLabel("");
    boolean var32 = var29.isAxisLineVisible();
    java.text.DateFormat var33 = var29.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var27, (org.jfree.chart.axis.ValueAxis)var29, var34);
    var35.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var35);
    var38.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
    var38.addSubtitle((org.jfree.chart.title.Title)var47);
    java.awt.image.BufferedImage var51 = var38.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var54 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var57 = var54.getItemLabelPaint((-1), 100);
    var38.setBackgroundPaint(var57);
    org.jfree.chart.title.LegendGraphic var59 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var25, var57);
    org.jfree.chart.renderer.category.BarRenderer3D var62 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var65 = var62.getItemLabelPaint((-1), 100);
    var59.setFillPaint(var65);
    var4.setBaseFillPaint(var65, true);
    var1.setBackgroundPaint(var65);
    java.awt.Graphics2D var70 = null;
    java.awt.geom.Rectangle2D var71 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var74 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var77 = var74.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var78 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var74);
    org.jfree.chart.renderer.category.BarRenderer3D var81 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var84 = var81.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var85 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var81);
    org.jfree.chart.util.RectangleInsets var86 = var85.getMargin();
    var78.setItemLabelPadding(var86);
    java.awt.Paint var88 = var78.getItemPaint();
    java.lang.Object var89 = var1.draw(var70, var71, (java.lang.Object)var78);
    java.awt.Color var92 = java.awt.Color.getColor("#64000d", (-1));
    var78.setItemPaint((java.awt.Paint)var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test138"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    org.jfree.chart.util.UnitType var16 = var14.getUnitType();
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var22 = var19.getItemLabelPaint((-1), 100);
    var19.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var27 = var19.getItemOutlineStroke(0, (-1));
    java.lang.Boolean var29 = var19.getSeriesCreateEntities(100);
    boolean var30 = var16.equals((java.lang.Object)100);
    java.text.DateFormat var35 = null;
    org.jfree.chart.axis.DateTickUnit var36 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var35);
    int var37 = var36.getRollUnit();
    int var38 = var36.getRollCount();
    java.text.DateFormat var43 = null;
    org.jfree.chart.axis.DateTickUnit var44 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var43);
    int var45 = var44.getRollUnit();
    int var46 = var44.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var49 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var50 = var49.getStart();
    java.util.Date var51 = var44.rollDate(var50);
    java.util.Date var52 = var36.rollDate(var51);
    boolean var53 = var16.equals((java.lang.Object)var36);
    org.jfree.chart.util.RectangleInsets var58 = new org.jfree.chart.util.RectangleInsets(var16, 1.0d, (-1.0d), 16.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test139"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.awt.Shape var7 = var3.getUpArrow();
    var1.setRightArrow(var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
    var11.setLabel("");
    boolean var14 = var11.isAxisLineVisible();
    java.text.DateFormat var15 = var11.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var16);
    var17.setAngleLabelsVisible(true);
    var17.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
    var22.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var7, var22, 10, 1);
    var26.setPercent((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test140"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.event.RendererChangeEvent var20 = null;
    var12.rendererChanged(var20);
    var12.setRangeGridlinesVisible(true);
    int var24 = var12.getDomainAxisCount();
    var12.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test141"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var12.getRenderer(100);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    java.awt.geom.Point2D var18 = null;
    var12.zoomRangeAxes(1.0d, 1.0d, var17, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test142"); }


    java.lang.Class var0 = null;
    java.lang.Class var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setAutoRangeMinimumSize(10.0d, false);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.util.RectangleInsets var21 = var20.getMargin();
    var13.setItemLabelPadding(var21);
    java.awt.geom.Rectangle2D var23 = var13.getBounds();
    var3.setLeftArrow((java.awt.Shape)var23);
    org.jfree.data.time.SimpleTimePeriod var28 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var29 = var28.getStart();
    org.jfree.data.time.SimpleTimePeriod var32 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var33 = var32.getEnd();
    org.jfree.data.gantt.Task var34 = new org.jfree.data.gantt.Task("", var29, var33);
    org.jfree.chart.renderer.category.BarRenderer3D var37 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var40 = var37.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
    org.jfree.chart.util.RectangleInsets var42 = var41.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var55 = var52.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
    org.jfree.chart.util.RectangleInsets var57 = var56.getMargin();
    var49.setItemLabelPadding(var57);
    java.awt.geom.Rectangle2D var59 = var49.getBounds();
    java.awt.geom.Rectangle2D var62 = var42.createInsetRectangle(var59, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var68 = var65.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var65);
    org.jfree.chart.util.RectangleInsets var70 = var69.getMargin();
    org.jfree.chart.util.RectangleEdge var71 = var69.getLegendItemGraphicEdge();
    double var72 = var3.dateToJava2D(var33, var59, var71);
    java.util.TimeZone var73 = null;
    org.jfree.data.time.RegularTimePeriod var74 = org.jfree.data.time.RegularTimePeriod.createInstance(var1, var33, var73);
    java.util.TimeZone var75 = null;
    org.jfree.data.time.RegularTimePeriod var76 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var33, var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test143"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.plot.PlotOrientation var13 = var12.getOrientation();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
    var16.setUpperBound(1.0d);
    var16.resizeRange((-1.0d), 100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var26 = null;
    var24.setSeriesPositiveItemLabelPosition(100, var26);
    double var28 = var24.getItemMargin();
    java.awt.Font var30 = null;
    var24.setSeriesItemLabelFont(0, var30);
    java.awt.Font var34 = var24.getItemLabelFont(0, (-1));
    var16.setTickLabelFont(var34);
    java.awt.Font var37 = null;
    java.awt.Paint var38 = null;
    org.jfree.chart.text.TextMeasurer var41 = null;
    org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var37, var38, 100.0f, 1, var41);
    java.util.List var43 = var42.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var50 = null;
    var48.setSeriesPositiveItemLabelPosition(100, var50);
    double var52 = var48.getItemMargin();
    java.awt.Font var54 = null;
    var48.setSeriesItemLabelFont(0, var54);
    java.awt.Font var58 = var48.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("Polar Plot", var58);
    org.jfree.data.xy.XYDataset var61 = null;
    org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("hi!");
    var63.setLabel("");
    boolean var66 = var63.isAxisLineVisible();
    java.text.DateFormat var67 = var63.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var68 = null;
    org.jfree.chart.plot.PolarPlot var69 = new org.jfree.chart.plot.PolarPlot(var61, (org.jfree.chart.axis.ValueAxis)var63, var68);
    var69.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var69);
    var69.setRadiusGridlinesVisible(false);
    java.awt.Paint var75 = var69.getOutlinePaint();
    var42.addLine("Polar Plot", var58, var75);
    org.jfree.chart.text.TextFragment var77 = new org.jfree.chart.text.TextFragment("", var34, var75);
    boolean var78 = var13.equals((java.lang.Object)var75);
    java.lang.String var79 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var79 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var79.equals("PlotOrientation.VERTICAL"));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test144"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test145"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    java.awt.Shape var34 = var33.getArea();
    org.jfree.chart.axis.Axis var35 = var33.getAxis();
    org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis("hi!");
    var39.setLabel("");
    boolean var42 = var39.isAxisLineVisible();
    java.awt.Shape var43 = var39.getUpArrow();
    var37.setRightArrow(var43);
    org.jfree.chart.entity.ChartEntity var47 = new org.jfree.chart.entity.ChartEntity(var43, "", "");
    var33.setArea(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test146"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateTickMarkPosition var34 = var1.getTickMarkPosition();
    org.jfree.chart.plot.IntervalMarker var37 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var38 = null;
    var37.notifyListeners(var38);
    double var40 = var37.getEndValue();
    org.jfree.chart.event.MarkerChangeListener var41 = null;
    var37.removeChangeListener(var41);
    java.awt.Paint var43 = var37.getOutlinePaint();
    java.awt.Paint var44 = var37.getLabelPaint();
    boolean var45 = var34.equals((java.lang.Object)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test147"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(13);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = var2.getBaseToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test148"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var13 = var10.getItemLabelPaint((-1), 100);
    var10.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var18 = var10.getItemOutlineStroke(0, (-1));
    var2.setBaseStroke(var18);
    int var20 = var2.getRowCount();
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.plot.DrawingSupplier var27 = var23.getDrawingSupplier();
    java.awt.Paint var28 = var23.getBasePaint();
    var2.setBaseItemLabelPaint(var28);
    double var30 = var2.getXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.0d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test149"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
    var35.setLabel("");
    boolean var38 = var35.isAxisLineVisible();
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 0.0d);
    var35.setRange(var41, true, true);
    var1.setRange(var41, false, false);
    org.jfree.data.Range var50 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var53 = org.jfree.data.Range.shift(var50, 1.0d, false);
    java.lang.Object var54 = null;
    boolean var55 = var50.equals(var54);
    var1.setRangeWithMargins(var50);
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis("hi!");
    var58.setLabel("");
    boolean var61 = var58.isAxisLineVisible();
    org.jfree.data.Range var64 = new org.jfree.data.Range(0.0d, 0.0d);
    var58.setRange(var64, true, true);
    org.jfree.data.Range var68 = org.jfree.data.Range.combine(var50, var64);
    double var69 = var68.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test150"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var20};
    var12.setRenderers(var21);
    var12.configureDomainAxes();
    org.jfree.data.xy.XYDataset var24 = null;
    int var25 = var12.indexOf(var24);
    org.jfree.chart.ChartColor var29 = new org.jfree.chart.ChartColor(10, 13, 10);
    java.awt.Color var30 = var29.darker();
    var12.setRangeCrosshairPaint((java.awt.Paint)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test151"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.chart.block.LengthConstraintType var15 = var14.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var16 = var14.toUnconstrainedHeight();
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    var18.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var25 = null;
    var23.setSeriesPositiveItemLabelPosition(100, var25);
    java.awt.Stroke var27 = var23.getBaseOutlineStroke();
    var18.setAxisLineStroke(var27);
    var18.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var33 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var36 = var33.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
    var37.setItemLabelPadding(var45);
    java.awt.geom.Rectangle2D var47 = var37.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var50 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, (java.awt.Shape)var47, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("hi!");
    var52.setLabel("");
    boolean var55 = var52.isAxisLineVisible();
    org.jfree.data.Range var58 = new org.jfree.data.Range(0.0d, 0.0d);
    var52.setRange(var58, true, true);
    var18.setRange(var58, false, false);
    org.jfree.chart.block.RectangleConstraint var66 = new org.jfree.chart.block.RectangleConstraint(var58, 1.0d);
    org.jfree.chart.block.RectangleConstraint var67 = var14.toRangeWidth(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test152"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.awt.Shape var7 = var3.getUpArrow();
    var1.setRightArrow(var7);
    org.jfree.chart.plot.Plot var9 = var1.getPlot();
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
    var11.setLabel("");
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange(0.0d, 0.0d);
    var11.setRangeWithMargins((org.jfree.data.Range)var16);
    var1.setDefaultAutoRange((org.jfree.data.Range)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test153"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    int var9 = var8.getSeriesCount();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    java.awt.Paint var12 = var8.getNoDataMessagePaint();
    org.jfree.chart.plot.Plot var13 = var8.getRootPlot();
    float var14 = var8.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test154"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var2.notifyListeners(var3);
    org.jfree.chart.util.RectangleInsets var5 = var2.getLabelOffset();
    double var7 = var5.calculateLeftInset(10.0d);
    double var9 = var5.calculateTopOutset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.0d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test155"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    double var17 = var14.trimHeight((-1.0d));
    double var19 = var14.calculateLeftOutset(100.0d);
    org.jfree.chart.plot.IntervalMarker var22 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    boolean var23 = var14.equals((java.lang.Object)var22);
    org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var29 = var26.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
    org.jfree.chart.util.RectangleInsets var31 = var30.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var44 = var41.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
    org.jfree.chart.util.RectangleInsets var46 = var45.getMargin();
    var38.setItemLabelPadding(var46);
    java.awt.geom.Rectangle2D var48 = var38.getBounds();
    java.awt.geom.Rectangle2D var51 = var31.createInsetRectangle(var48, false, false);
    java.awt.geom.Rectangle2D var54 = var14.createOutsetRectangle(var51, false, true);
    double var55 = var14.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test156"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    var2.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var10 = var2.getItemOutlineStroke(0, (-1));
    boolean var11 = var2.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test157"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setLowerBound((-1.0d));
//     java.text.DateFormat var5 = var2.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
//     var7.setUpperBound(1.0d);
//     boolean var10 = var7.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
//     java.lang.Object var13 = var12.clone();
//     int var14 = var12.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var15 = var12.getFixedDomainAxisSpace();
//     int var16 = var12.getRangeAxisCount();
//     java.util.List var17 = var12.getAnnotations();
//     org.jfree.chart.axis.AxisLocation var18 = var12.getDomainAxisLocation();
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
//     var21.setLowerBound((-1.0d));
//     java.text.DateFormat var24 = var21.getDateFormatOverride();
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("hi!");
//     var26.setUpperBound(1.0d);
//     boolean var29 = var26.isNegativeArrowVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var26, var30);
//     org.jfree.chart.axis.ValueAxis var32 = var31.getDomainAxis();
//     var12.setDomainAxis(var32);
//     
//     // Checks the contract:  equals-hashcode on var12 and var31
//     assertTrue("Contract failed: equals-hashcode on var12 and var31", var12.equals(var31) ? var12.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var12
//     assertTrue("Contract failed: equals-hashcode on var31 and var12", var31.equals(var12) ? var31.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test158"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.event.RendererChangeEvent var20 = null;
    var12.rendererChanged(var20);
    var12.setRangeGridlinesVisible(true);
    int var24 = var12.getDomainAxisCount();
    org.jfree.chart.LegendItemCollection var25 = var12.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test159"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    var2.setBaseItemLabelsVisible(true, false);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test160"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    org.jfree.chart.util.UnitType var16 = var14.getUnitType();
    org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets(var16, (-9.223372036854776E18d), 100.0d, 100.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test161"); }


    org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test162"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.chart.block.LengthConstraintType var15 = var14.getHeightConstraintType();
    double var16 = var14.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test163"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE12");

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test164"); }


    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var7 = null;
    var5.setSeriesPositiveItemLabelPosition(100, var7);
    double var9 = var5.getItemMargin();
    java.awt.Font var11 = null;
    var5.setSeriesItemLabelFont(0, var11);
    java.awt.Font var15 = var5.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var20 = null;
    var18.setSeriesPositiveItemLabelPosition(100, var20);
    java.awt.Stroke var22 = var18.getBaseOutlineStroke();
    java.lang.Object var23 = var18.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var29 = var26.getItemLabelPaint((-1), 100);
    var26.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var34 = var26.getItemOutlineStroke(0, (-1));
    var18.setBaseStroke(var34);
    java.awt.Paint var36 = var18.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("", var15, var36);
    java.awt.Color var39 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]", var15, (java.awt.Paint)var39);
    org.jfree.data.category.CategoryDataset var41 = null;
    org.jfree.chart.plot.MultiplePiePlot var42 = new org.jfree.chart.plot.MultiplePiePlot(var41);
    java.awt.Paint var43 = var42.getAggregatedItemsPaint();
    org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", var15, (org.jfree.chart.plot.Plot)var42, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test165"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test166"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
    var35.setLabel("");
    boolean var38 = var35.isAxisLineVisible();
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 0.0d);
    var35.setRange(var41, true, true);
    var1.setRange(var41, false, false);
    org.jfree.data.Range var50 = org.jfree.data.Range.shift(var41, (-9.223372036854776E18d), true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test167"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "January"+ "'", var1.equals("January"));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test168"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    org.jfree.chart.event.AxisChangeListener var4 = null;
    var1.addChangeListener(var4);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var8.setSeriesPositiveItemLabelPosition(100, var10);
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    double var13 = var8.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(13);
    var8.setBasePositiveItemLabelPosition(var18, true);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLabel("");
    boolean var28 = var25.isAxisLineVisible();
    java.text.DateFormat var29 = var25.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var30);
    org.jfree.chart.axis.ValueAxis var32 = var31.getAxis();
    org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var35.notifyListeners(var36);
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
    var52.setItemLabelPadding(var60);
    java.awt.geom.Rectangle2D var62 = var52.getBounds();
    java.awt.geom.Rectangle2D var65 = var45.createInsetRectangle(var62, false, false);
    var8.drawRangeMarker(var21, var22, var32, (org.jfree.chart.plot.Marker)var35, var65);
    var1.setRightArrow((java.awt.Shape)var65);
    org.jfree.chart.renderer.category.BarRenderer3D var70 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var72 = null;
    var70.setSeriesPositiveItemLabelPosition(100, var72);
    java.awt.Stroke var75 = var70.lookupSeriesOutlineStroke(10);
    var1.setTickMarkStroke(var75);
    java.text.DateFormat var81 = null;
    org.jfree.chart.axis.DateTickUnit var82 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var81);
    int var83 = var82.getRollUnit();
    int var84 = var82.getRollCount();
    var1.setTickUnit(var82, false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 1);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test169"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setLabel("");
    boolean var13 = var10.isAxisLineVisible();
    java.text.DateFormat var14 = var10.getDateFormatOverride();
    org.jfree.chart.plot.Plot var15 = var10.getPlot();
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var20 = null;
    var18.setSeriesPositiveItemLabelPosition(100, var20);
    double var22 = var18.getItemMargin();
    java.awt.Font var24 = null;
    var18.setSeriesItemLabelFont(0, var24);
    java.awt.Paint var26 = var18.getBaseOutlinePaint();
    var10.setLabelPaint(var26);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    org.jfree.chart.renderer.category.BarRenderer3D var37 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var40 = var37.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
    org.jfree.chart.util.RectangleInsets var42 = var41.getMargin();
    var34.setItemLabelPadding(var42);
    double var45 = var42.trimHeight((-1.0d));
    double var47 = var42.calculateLeftOutset(100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var53 = var50.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
    org.jfree.chart.renderer.category.BarRenderer3D var57 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var60 = var57.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57);
    org.jfree.chart.util.RectangleInsets var62 = var61.getMargin();
    var54.setItemLabelPadding(var62);
    java.awt.geom.Rectangle2D var64 = var54.getBounds();
    java.awt.geom.Rectangle2D var67 = var42.createInsetRectangle(var64, false, false);
    var2.drawRangeGridline(var7, var8, (org.jfree.chart.axis.ValueAxis)var10, var67, 100.0d);
    var10.resizeRange(10.0d, (-9.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test170"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("#64000d");
    org.jfree.data.time.TimePeriod var3 = null;
    org.jfree.data.gantt.Task var4 = new org.jfree.data.gantt.Task("hi!", var3);
    var1.add(var4);
    java.lang.Object var6 = null;
    boolean var7 = var1.equals(var6);
    var1.setDescription("31-December-1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test171"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    var12.clearSubtitles();
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var26 = null;
    var25.notifyListeners(var26);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    var25.setLabelPaint(var33);
    var22.setBackgroundPaint(var33);
    org.jfree.chart.renderer.category.BarRenderer3D var39 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var41 = null;
    var39.setSeriesPositiveItemLabelPosition(100, var41);
    double var43 = var39.getItemMargin();
    java.awt.Font var45 = null;
    var39.setSeriesItemLabelFont(0, var45);
    java.awt.Font var49 = var39.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var54 = null;
    var52.setSeriesPositiveItemLabelPosition(100, var54);
    java.awt.Stroke var56 = var52.getBaseOutlineStroke();
    java.lang.Object var57 = var52.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var60 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var63 = var60.getItemLabelPaint((-1), 100);
    var60.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var68 = var60.getItemOutlineStroke(0, (-1));
    var52.setBaseStroke(var68);
    java.awt.Paint var70 = var52.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var71 = new org.jfree.chart.text.TextFragment("", var49, var70);
    var22.setItemPaint(var70);
    org.jfree.chart.event.TitleChangeEvent var73 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var22);
    var12.titleChanged(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test172"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    var2.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var10 = var2.getItemOutlineStroke(0, (-1));
    org.jfree.chart.plot.DrawingSupplier var11 = var2.getDrawingSupplier();
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setLabel("");
    boolean var18 = var15.isAxisLineVisible();
    java.text.DateFormat var19 = var15.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, var20);
    var21.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var21);
    var24.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var32 = var29.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
    var24.addSubtitle((org.jfree.chart.title.Title)var33);
    java.awt.image.BufferedImage var37 = var24.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    var24.setBackgroundPaint(var43);
    boolean var45 = var24.isBorderVisible();
    boolean var46 = var2.hasListener((java.util.EventListener)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test173"); }


    java.lang.Number var0 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(var0, (java.lang.Number)100L);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test174"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var2.notifyListeners(var3);
    double var5 = var2.getEndValue();
    org.jfree.chart.event.MarkerChangeListener var6 = null;
    var2.removeChangeListener(var6);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var10.setSeriesPositiveItemLabelPosition(100, var12);
    double var14 = var10.getItemMargin();
    java.awt.Font var16 = null;
    var10.setSeriesItemLabelFont(0, var16);
    org.jfree.chart.labels.CategoryToolTipGenerator var18 = null;
    var10.setBaseToolTipGenerator(var18);
    java.awt.Stroke var21 = var10.lookupSeriesStroke(1);
    var2.setStroke(var21);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 10.0d, true);
    java.awt.Paint var28 = var26.lookupSeriesFillPaint(13);
    var2.setLabelPaint(var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
    var32.setLabel("");
    boolean var35 = var32.isAxisLineVisible();
    java.text.DateFormat var36 = var32.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var37 = null;
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var37);
    org.jfree.chart.axis.ValueAxis var39 = var38.getAxis();
    org.jfree.chart.event.RendererChangeEvent var40 = null;
    var38.rendererChanged(var40);
    org.jfree.chart.plot.DrawingSupplier var42 = var38.getDrawingSupplier();
    java.awt.Stroke var43 = var38.getRadiusGridlineStroke();
    var2.setOutlineStroke(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test175"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(100);
    var12.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var20};
    var12.setRenderers(var21);
    var12.configureDomainAxes();
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
    var27.setLabel("");
    boolean var30 = var27.isAxisLineVisible();
    java.text.DateFormat var31 = var27.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, var32);
    var33.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var33);
    var33.setRadiusGridlinesVisible(false);
    java.awt.Paint var39 = var33.getOutlinePaint();
    org.jfree.chart.plot.PlotOrientation var40 = var33.getOrientation();
    var12.setOrientation(var40);
    var12.clearRangeMarkers(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test176"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    java.awt.Font var27 = null;
    org.jfree.chart.axis.MarkerAxisBand var28 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var1, 100.0d, 10.0d, 16.0d, (-1.0d), var27);
    org.jfree.chart.axis.MarkerAxisBand var29 = var1.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test177"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedDomainAxisSpace();
    boolean var17 = var12.equals((java.lang.Object)100.0d);
    var12.setBackgroundImageAlignment(10);
    java.awt.Color var22 = java.awt.Color.getColor("(100.0, 10.0)", 0);
    var12.setDomainGridlinePaint((java.awt.Paint)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test178"); }


    org.jfree.data.time.TimePeriod var1 = null;
    org.jfree.data.gantt.Task var2 = new org.jfree.data.gantt.Task("hi!", var1);
    var2.setDescription("(100.0, 10.0)");
    org.jfree.data.time.SimpleTimePeriod var8 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var9 = var8.getStart();
    org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var13 = null;
    var12.notifyListeners(var13);
    org.jfree.chart.util.RectangleInsets var15 = var12.getLabelOffset();
    boolean var16 = var8.equals((java.lang.Object)var12);
    org.jfree.data.gantt.Task var17 = new org.jfree.data.gantt.Task("Polar Plot", (org.jfree.data.time.TimePeriod)var8);
    var2.addSubtask(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test179"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    java.awt.Shape var5 = var1.getUpArrow();
    java.text.DateFormat var10 = null;
    org.jfree.chart.axis.DateTickUnit var11 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var10);
    var1.setTickUnit(var11, true, false);
    org.jfree.chart.text.TextBlock var15 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    var21.setLabel("");
    boolean var24 = var21.isAxisLineVisible();
    java.text.DateFormat var25 = var21.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, var26);
    var27.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var27);
    var27.setRadiusGridlinesVisible(false);
    java.awt.Paint var33 = var27.getOutlinePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var38 = null;
    var36.setSeriesPositiveItemLabelPosition(100, var38);
    java.awt.Stroke var40 = var36.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryMarker var41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)0L, var33, var40);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis("hi!");
    var44.setLabel("");
    boolean var47 = var44.isAxisLineVisible();
    java.text.DateFormat var48 = var44.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var49 = null;
    org.jfree.chart.plot.PolarPlot var50 = new org.jfree.chart.plot.PolarPlot(var42, (org.jfree.chart.axis.ValueAxis)var44, var49);
    org.jfree.chart.axis.ValueAxis var51 = var50.getAxis();
    org.jfree.data.xy.XYDataset var52 = null;
    var50.setDataset(var52);
    org.jfree.chart.util.RectangleInsets var54 = var50.getInsets();
    var50.setAngleGridlinesVisible(true);
    boolean var57 = var41.equals((java.lang.Object)var50);
    org.jfree.chart.text.TextAnchor var58 = var41.getLabelTextAnchor();
    java.lang.String var59 = var58.toString();
    org.jfree.chart.axis.CategoryTick var61 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)true, var15, var16, var58, 16.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "TextAnchor.CENTER"+ "'", var59.equals("TextAnchor.CENTER"));

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test180"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     double var7 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var10.setSeriesPositiveItemLabelPosition(100, var12);
//     java.awt.Stroke var14 = var10.getBaseOutlineStroke();
//     var2.setBaseStroke(var14, true);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var2.getSeriesURLGenerator(13);
//     java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     var2.setSeriesItemLabelPaint(10, (java.awt.Paint)var21);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var2.", var10.equals(var2) == var2.equals(var10));
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test181"); }
// 
// 
//     org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("#64000d");
//     org.jfree.data.time.TimePeriod var3 = null;
//     org.jfree.data.gantt.Task var4 = new org.jfree.data.gantt.Task("hi!", var3);
//     var1.add(var4);
//     org.jfree.data.time.TimePeriod var7 = null;
//     org.jfree.data.gantt.Task var8 = new org.jfree.data.gantt.Task("hi!", var7);
//     var1.add(var8);
//     
//     // Checks the contract:  equals-hashcode on var4 and var8
//     assertTrue("Contract failed: equals-hashcode on var4 and var8", var4.equals(var8) ? var4.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var4
//     assertTrue("Contract failed: equals-hashcode on var8 and var4", var8.equals(var4) ? var8.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test182"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test183"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setLabel("");
    boolean var22 = var19.isAxisLineVisible();
    java.text.DateFormat var23 = var19.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
    org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
    org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
    var46.setItemLabelPadding(var54);
    java.awt.geom.Rectangle2D var56 = var46.getBounds();
    java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
    var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
    java.lang.Object var61 = var29.clone();
    float var62 = var29.getAlpha();
    var29.setLabel("Range[0.0,0.0]");
    java.awt.Stroke var65 = var29.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test184"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var5 = null;
//     var3.setSeriesPositiveItemLabelPosition(100, var5);
//     double var7 = var3.getItemMargin();
//     java.awt.Font var9 = null;
//     var3.setSeriesItemLabelFont(0, var9);
//     java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var18 = null;
//     var16.setSeriesPositiveItemLabelPosition(100, var18);
//     java.awt.Stroke var20 = var16.getBaseOutlineStroke();
//     double var21 = var16.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(13);
//     var16.setBasePositiveItemLabelPosition(var26, true);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = null;
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
//     var33.setLabel("");
//     boolean var36 = var33.isAxisLineVisible();
//     java.text.DateFormat var37 = var33.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var38);
//     org.jfree.chart.axis.ValueAxis var40 = var39.getAxis();
//     org.jfree.chart.plot.IntervalMarker var43 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var44 = null;
//     var43.notifyListeners(var44);
//     org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
//     org.jfree.chart.util.RectangleInsets var53 = var52.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
//     org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
//     org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
//     var60.setItemLabelPadding(var68);
//     java.awt.geom.Rectangle2D var70 = var60.getBounds();
//     java.awt.geom.Rectangle2D var73 = var53.createInsetRectangle(var70, false, false);
//     var16.drawRangeMarker(var29, var30, var40, (org.jfree.chart.plot.Marker)var43, var73);
//     java.lang.Object var75 = var43.clone();
//     java.awt.Color var77 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var78 = var77.getBlue();
//     var43.setOutlinePaint((java.awt.Paint)var77);
//     org.jfree.chart.block.LabelBlock var80 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", var13, (java.awt.Paint)var77);
//     java.awt.Graphics2D var81 = null;
//     org.jfree.chart.axis.DateAxis var83 = new org.jfree.chart.axis.DateAxis("hi!");
//     var83.setLabel("");
//     boolean var86 = var83.isAxisLineVisible();
//     org.jfree.data.Range var89 = new org.jfree.data.Range(0.0d, 0.0d);
//     var83.setRange(var89, true, true);
//     org.jfree.data.Range var95 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var96 = new org.jfree.chart.block.RectangleConstraint(var89, var95);
//     org.jfree.chart.util.Size2D var97 = var80.arrange(var81, var96);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test185"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     double var7 = var2.getBase();
//     java.awt.Paint var9 = var2.getSeriesPaint(100);
//     org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var15 = null;
//     var13.setSeriesPositiveItemLabelPosition(100, var15);
//     double var17 = var13.getItemMargin();
//     java.awt.Font var19 = null;
//     var13.setSeriesItemLabelFont(0, var19);
//     java.awt.Paint var21 = var13.getBaseOutlinePaint();
//     var2.setSeriesFillPaint(0, var21, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var2.", var13.equals(var2) == var2.equals(var13));
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test186"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
    var2.setDrawBarOutline(true);
    var2.setSeriesVisibleInLegend(1, (java.lang.Boolean)true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test187"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    var2.setAxisLineStroke(var11);
    var2.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.util.RectangleInsets var29 = var28.getMargin();
    var21.setItemLabelPadding(var29);
    java.awt.geom.Rectangle2D var31 = var21.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var31, "hi!", "hi!");
    org.jfree.chart.axis.DateTickMarkPosition var35 = var2.getTickMarkPosition();
    java.awt.Color var37 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var38 = var37.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var42 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var43 = var37.equals((java.lang.Object)"");
    var2.setTickLabelPaint((java.awt.Paint)var37);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    var47.setBaseSeriesVisible(false);
    java.awt.Stroke var55 = var47.getSeriesStroke(10);
    org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var60 = null;
    var58.setSeriesPositiveItemLabelPosition(100, var60);
    java.awt.Stroke var62 = var58.getBaseOutlineStroke();
    double var63 = var58.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var68 = var66.getSeriesNegativeItemLabelPosition(13);
    var58.setBasePositiveItemLabelPosition(var68, true);
    double var71 = var68.getAngle();
    org.jfree.chart.labels.ItemLabelAnchor var72 = var68.getItemLabelAnchor();
    var47.setPositiveItemLabelPositionFallback(var68);
    boolean var74 = var37.equals((java.lang.Object)var68);
    org.jfree.chart.renderer.category.BarRenderer3D var77 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var79 = null;
    var77.setSeriesPositiveItemLabelPosition(100, var79);
    java.awt.Stroke var82 = var77.lookupSeriesOutlineStroke(10);
    java.lang.Boolean var84 = null;
    var77.setSeriesVisibleInLegend(100, var84);
    java.awt.Stroke var86 = var77.getBaseOutlineStroke();
    org.jfree.chart.plot.ValueMarker var87 = new org.jfree.chart.plot.ValueMarker((-9.223372036854776E18d), (java.awt.Paint)var37, var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test188"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    var9.setSeriesPositiveItemLabelPosition(100, var11);
    double var13 = var9.getItemMargin();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var9.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var19 = null;
    var17.setSeriesPositiveItemLabelPosition(100, var19);
    java.awt.Stroke var22 = var17.lookupSeriesOutlineStroke(10);
    var9.setBaseStroke(var22, true);
    java.awt.Paint var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem(var0, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "31-December-1969", "Range[0.0,0.0]", var6, var22, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test189"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    org.jfree.chart.event.AxisChangeListener var4 = null;
    var1.addChangeListener(var4);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var8.setSeriesPositiveItemLabelPosition(100, var10);
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    double var13 = var8.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(13);
    var8.setBasePositiveItemLabelPosition(var18, true);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLabel("");
    boolean var28 = var25.isAxisLineVisible();
    java.text.DateFormat var29 = var25.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var30);
    org.jfree.chart.axis.ValueAxis var32 = var31.getAxis();
    org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var35.notifyListeners(var36);
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
    var52.setItemLabelPadding(var60);
    java.awt.geom.Rectangle2D var62 = var52.getBounds();
    java.awt.geom.Rectangle2D var65 = var45.createInsetRectangle(var62, false, false);
    var8.drawRangeMarker(var21, var22, var32, (org.jfree.chart.plot.Marker)var35, var65);
    var1.setRightArrow((java.awt.Shape)var65);
    java.awt.Paint var68 = var1.getAxisLinePaint();
    java.awt.Paint var69 = null;
    boolean var70 = org.jfree.chart.util.PaintUtilities.equal(var68, var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test190"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    java.awt.Shape var34 = var33.getArea();
    org.jfree.chart.axis.Axis var35 = var33.getAxis();
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("hi!");
    var38.setLabel("");
    boolean var41 = var38.isAxisLineVisible();
    java.text.DateFormat var42 = var38.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var43 = null;
    org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot(var36, (org.jfree.chart.axis.ValueAxis)var38, var43);
    org.jfree.chart.axis.ValueAxis var45 = var44.getAxis();
    boolean var46 = var33.equals((java.lang.Object)var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test191"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    java.awt.Font var27 = null;
    org.jfree.chart.axis.MarkerAxisBand var28 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var1, 100.0d, 10.0d, 16.0d, (-1.0d), var27);
    org.jfree.chart.axis.NumberTickUnit var29 = var1.getTickUnit();
    org.jfree.chart.axis.NumberTickUnit var30 = var1.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test192"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    java.awt.Paint var15 = var12.getDomainGridlinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    int var17 = var12.getIndexOf(var16);
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var22 = null;
    var20.setSeriesPositiveItemLabelPosition(100, var22);
    java.awt.Stroke var24 = var20.getBaseOutlineStroke();
    double var25 = var20.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var30 = var28.getSeriesNegativeItemLabelPosition(13);
    var20.setBasePositiveItemLabelPosition(var30, true);
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = null;
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis("hi!");
    var37.setLabel("");
    boolean var40 = var37.isAxisLineVisible();
    java.text.DateFormat var41 = var37.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var42 = null;
    org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot(var35, (org.jfree.chart.axis.ValueAxis)var37, var42);
    org.jfree.chart.axis.ValueAxis var44 = var43.getAxis();
    org.jfree.chart.plot.IntervalMarker var47 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var48 = null;
    var47.notifyListeners(var48);
    org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var55 = var52.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
    org.jfree.chart.util.RectangleInsets var57 = var56.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var60 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var63 = var60.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60);
    org.jfree.chart.renderer.category.BarRenderer3D var67 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var70 = var67.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var67);
    org.jfree.chart.util.RectangleInsets var72 = var71.getMargin();
    var64.setItemLabelPadding(var72);
    java.awt.geom.Rectangle2D var74 = var64.getBounds();
    java.awt.geom.Rectangle2D var77 = var57.createInsetRectangle(var74, false, false);
    var20.drawRangeMarker(var33, var34, var44, (org.jfree.chart.plot.Marker)var47, var77);
    org.jfree.chart.renderer.category.BarRenderer3D var81 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var84 = var81.getItemLabelPaint((-1), 100);
    org.jfree.chart.axis.DateAxis var86 = new org.jfree.chart.axis.DateAxis("hi!");
    var86.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var91 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var93 = null;
    var91.setSeriesPositiveItemLabelPosition(100, var93);
    java.awt.Stroke var95 = var91.getBaseOutlineStroke();
    var86.setAxisLineStroke(var95);
    var81.setBaseOutlineStroke(var95);
    var47.setStroke(var95);
    var12.setOutlineStroke(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test193"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var6 = null;
//     var4.setSeriesPositiveItemLabelPosition(100, var6);
//     double var8 = var4.getItemMargin();
//     java.awt.Font var10 = null;
//     var4.setSeriesItemLabelFont(0, var10);
//     java.awt.Font var14 = var4.getItemLabelFont(0, (-1));
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("Polar Plot", var14);
//     org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var20 = null;
//     var18.setSeriesPositiveItemLabelPosition(100, var20);
//     java.awt.Stroke var22 = var18.getBaseOutlineStroke();
//     double var23 = var18.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var26.getSeriesNegativeItemLabelPosition(13);
//     var18.setBasePositiveItemLabelPosition(var28, true);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = null;
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
//     var35.setLabel("");
//     boolean var38 = var35.isAxisLineVisible();
//     java.text.DateFormat var39 = var35.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, var40);
//     org.jfree.chart.axis.ValueAxis var42 = var41.getAxis();
//     org.jfree.chart.plot.IntervalMarker var45 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var46 = null;
//     var45.notifyListeners(var46);
//     org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var53 = var50.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
//     org.jfree.chart.util.RectangleInsets var55 = var54.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var61 = var58.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
//     org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var68 = var65.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var65);
//     org.jfree.chart.util.RectangleInsets var70 = var69.getMargin();
//     var62.setItemLabelPadding(var70);
//     java.awt.geom.Rectangle2D var72 = var62.getBounds();
//     java.awt.geom.Rectangle2D var75 = var55.createInsetRectangle(var72, false, false);
//     var18.drawRangeMarker(var31, var32, var42, (org.jfree.chart.plot.Marker)var45, var75);
//     java.lang.Object var77 = var45.clone();
//     java.awt.Color var79 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var80 = var79.getBlue();
//     var45.setOutlinePaint((java.awt.Paint)var79);
//     org.jfree.chart.text.TextBlock var82 = org.jfree.chart.text.TextUtilities.createTextBlock("Polar Plot", var14, (java.awt.Paint)var79);
//     java.util.List var83 = var82.getLines();
//     java.awt.Graphics2D var84 = null;
//     org.jfree.chart.util.Size2D var85 = var82.calculateDimensions(var84);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test194"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    org.jfree.chart.axis.NumberTickUnit var23 = var1.getTickUnit();
    java.lang.String var25 = var23.valueToString(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "1"+ "'", var25.equals("1"));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test195"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
    org.jfree.chart.axis.ValueAxis var16 = null;
    int var17 = var12.getRangeAxisIndex(var16);
    org.jfree.chart.plot.SeriesRenderingOrder var18 = var12.getSeriesRenderingOrder();
    var12.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test196"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    double var7 = var2.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
    var2.setBasePositiveItemLabelPosition(var12, true);
    double var15 = var12.getAngle();
    org.jfree.chart.labels.ItemLabelAnchor var16 = var12.getItemLabelAnchor();
    java.lang.String var17 = var16.toString();
    org.jfree.chart.text.TextAnchor var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var19 = new org.jfree.chart.labels.ItemLabelPosition(var16, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "ItemLabelAnchor.INSIDE12"+ "'", var17.equals("ItemLabelAnchor.INSIDE12"));

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test197"); }


    java.text.DateFormat var4 = null;
    org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var4);
    int var6 = var5.getRollUnit();
    int var7 = var5.getRollCount();
    int var8 = var5.getRollUnit();
    org.jfree.data.DefaultKeyedValue var10 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)var5, (java.lang.Number)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test198"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var20 = var17.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    var12.addSubtitle((org.jfree.chart.title.Title)var21);
    java.awt.image.BufferedImage var25 = var12.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var31 = var28.getItemLabelPaint((-1), 100);
    var12.setBackgroundPaint(var31);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
    org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var43 = null;
    var42.notifyListeners(var43);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    var42.setLabelPaint(var50);
    var39.setBackgroundPaint(var50);
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var58 = null;
    var56.setSeriesPositiveItemLabelPosition(100, var58);
    double var60 = var56.getItemMargin();
    java.awt.Font var62 = null;
    var56.setSeriesItemLabelFont(0, var62);
    java.awt.Font var66 = var56.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var69 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var71 = null;
    var69.setSeriesPositiveItemLabelPosition(100, var71);
    java.awt.Stroke var73 = var69.getBaseOutlineStroke();
    java.lang.Object var74 = var69.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var77 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var80 = var77.getItemLabelPaint((-1), 100);
    var77.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var85 = var77.getItemOutlineStroke(0, (-1));
    var69.setBaseStroke(var85);
    java.awt.Paint var87 = var69.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var88 = new org.jfree.chart.text.TextFragment("", var66, var87);
    var39.setItemPaint(var87);
    org.jfree.chart.event.TitleChangeEvent var90 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var39);
    var12.titleChanged(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test199"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    org.jfree.chart.event.TitleChangeListener var16 = null;
    var6.addChangeListener(var16);
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var23 = null;
    var21.setSeriesPositiveItemLabelPosition(100, var23);
    double var25 = var21.getItemMargin();
    java.awt.Font var27 = null;
    var21.setSeriesItemLabelFont(0, var27);
    java.awt.Font var31 = var21.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var36 = null;
    var34.setSeriesPositiveItemLabelPosition(100, var36);
    java.awt.Stroke var38 = var34.getBaseOutlineStroke();
    java.lang.Object var39 = var34.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
    var42.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var50 = var42.getItemOutlineStroke(0, (-1));
    var34.setBaseStroke(var50);
    java.awt.Paint var52 = var34.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var31, var52);
    var6.setBackgroundPaint(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test200"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "hi!");
    java.lang.String var5 = var4.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test201"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    java.awt.Paint var23 = var15.getDomainGridlinePaint();
    java.awt.Stroke var24 = var15.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test202"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("31-December-1969");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test203"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    org.jfree.chart.event.AxisChangeListener var4 = null;
    var1.addChangeListener(var4);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    var8.setSeriesPositiveItemLabelPosition(100, var10);
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    double var13 = var8.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(13);
    var8.setBasePositiveItemLabelPosition(var18, true);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLabel("");
    boolean var28 = var25.isAxisLineVisible();
    java.text.DateFormat var29 = var25.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var30);
    org.jfree.chart.axis.ValueAxis var32 = var31.getAxis();
    org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var35.notifyListeners(var36);
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var51 = var48.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.util.RectangleInsets var60 = var59.getMargin();
    var52.setItemLabelPadding(var60);
    java.awt.geom.Rectangle2D var62 = var52.getBounds();
    java.awt.geom.Rectangle2D var65 = var45.createInsetRectangle(var62, false, false);
    var8.drawRangeMarker(var21, var22, var32, (org.jfree.chart.plot.Marker)var35, var65);
    var1.setRightArrow((java.awt.Shape)var65);
    org.jfree.chart.renderer.category.BarRenderer3D var70 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var72 = null;
    var70.setSeriesPositiveItemLabelPosition(100, var72);
    java.awt.Stroke var75 = var70.lookupSeriesOutlineStroke(10);
    var1.setTickMarkStroke(var75);
    var1.setLabelToolTip("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test204"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.clearCategoryLabelToolTips();
    var1.setCategoryLabelPositionOffset(1);
    java.awt.Paint var6 = var1.getTickLabelPaint((java.lang.Comparable)1L);
    java.awt.Paint var8 = null;
    var1.setTickLabelPaint((java.lang.Comparable)"RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test205"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.data.general.SeriesChangeEvent var34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test206"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAutoRangeMinimumSize(10.0d, false);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var10 = var7.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    var11.setItemLabelPadding(var19);
    java.awt.geom.Rectangle2D var21 = var11.getBounds();
    var1.setLeftArrow((java.awt.Shape)var21);
    org.jfree.data.time.SimpleTimePeriod var26 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var27 = var26.getStart();
    org.jfree.data.time.SimpleTimePeriod var30 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var31 = var30.getEnd();
    org.jfree.data.gantt.Task var32 = new org.jfree.data.gantt.Task("", var27, var31);
    org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var38 = var35.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
    org.jfree.chart.util.RectangleInsets var40 = var39.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var46 = var43.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
    org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var53 = var50.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
    org.jfree.chart.util.RectangleInsets var55 = var54.getMargin();
    var47.setItemLabelPadding(var55);
    java.awt.geom.Rectangle2D var57 = var47.getBounds();
    java.awt.geom.Rectangle2D var60 = var40.createInsetRectangle(var57, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
    org.jfree.chart.util.RectangleInsets var68 = var67.getMargin();
    org.jfree.chart.util.RectangleEdge var69 = var67.getLegendItemGraphicEdge();
    double var70 = var1.dateToJava2D(var31, var57, var69);
    java.util.Date var71 = var1.getMaximumDate();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test207"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLabel("");
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.Range var7 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setRange(var7, true, true);
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var7, var13);
    org.jfree.chart.block.LengthConstraintType var15 = var14.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var16 = var14.toUnconstrainedHeight();
    org.jfree.data.Range var17 = var16.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test208"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    var1.setAutoRangeMinimumSize(100.0d, false);
    var1.setPositiveArrowVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test209"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var7 = var6.getMargin();
    double var8 = var6.getContentXOffset();
    org.jfree.chart.util.VerticalAlignment var9 = var6.getVerticalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test210"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.awt.Stroke var13 = var12.getRangeCrosshairStroke();
    java.awt.Stroke var14 = var12.getDomainCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test211"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("Polar Plot", var13);
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var20 = null;
    var18.setSeriesPositiveItemLabelPosition(100, var20);
    double var22 = var18.getItemMargin();
    java.awt.Font var24 = null;
    var18.setSeriesItemLabelFont(0, var24);
    java.awt.Font var28 = var18.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var33 = null;
    var31.setSeriesPositiveItemLabelPosition(100, var33);
    java.awt.Stroke var35 = var31.getBaseOutlineStroke();
    java.lang.Object var36 = var31.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var39 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var42 = var39.getItemLabelPaint((-1), 100);
    var39.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var47 = var39.getItemOutlineStroke(0, (-1));
    var31.setBaseStroke(var47);
    java.awt.Paint var49 = var31.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("", var28, var49);
    var14.setFont(var28);
    java.awt.geom.Rectangle2D var52 = var14.getBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test212"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    boolean var4 = var1.isNegativeArrowVisible();
    java.text.DateFormat var9 = null;
    org.jfree.chart.axis.DateTickUnit var10 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var9);
    int var11 = var10.getRollUnit();
    java.util.Date var12 = var1.calculateHighestVisibleTickValue(var10);
    org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test213"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    var2.setSeriesItemLabelsVisible(100, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var2.setBaseToolTipGenerator(var7, true);
    boolean var10 = var2.getAutoPopulateSeriesShape();
    var2.setBaseItemLabelsVisible(false);
    var2.setSeriesCreateEntities(13, (java.lang.Boolean)false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test214"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAutoRangeMinimumSize(10.0d, false);
    double var5 = var1.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test215"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateTickMarkPosition var34 = var1.getTickMarkPosition();
    java.lang.String var35 = var1.getLabelToolTip();
    java.awt.Paint var36 = var1.getTickMarkPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test216"); }


    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)(short)(-1));
    org.jfree.data.time.SimpleTimePeriod var5 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var6 = var5.getStart();
    org.jfree.data.time.SimpleTimePeriod var9 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var10 = var9.getEnd();
    org.jfree.data.gantt.Task var11 = new org.jfree.data.gantt.Task("", var6, var10);
    java.lang.Comparable var12 = var1.getGroup((java.lang.Comparable)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)(-1)+ "'", var12.equals((short)(-1)));

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test217"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 13);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.jfree.chart.ChartColor[r=100,g=0,b=13]"+ "'", var4.equals("org.jfree.chart.ChartColor[r=100,g=0,b=13]"));

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test218"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var2.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test219"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var2 = var1.getBlue();
    java.awt.Color var4 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var5 = var4.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var9 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var10 = var4.equals((java.lang.Object)"");
    float[] var14 = new float[] { 1.0f, 100.0f, 10.0f};
    float[] var15 = var4.getColorComponents(var14);
    float[] var16 = var1.getRGBColorComponents(var14);
    java.awt.Color var18 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var19 = var18.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var23 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var24 = var18.equals((java.lang.Object)"");
    float[] var28 = new float[] { 1.0f, 100.0f, 10.0f};
    float[] var29 = var18.getColorComponents(var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var30 = var1.getRGBComponents(var29);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test220"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("PlotOrientation.VERTICAL", "Nearest", "31-December-1969", var3, "#64000d", "ItemLabelAnchor.INSIDE12", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test221"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("31-December-1969");
    int var2 = var1.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test222"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
    var6.setLabel("");
    boolean var9 = var6.isAxisLineVisible();
    java.text.DateFormat var10 = var6.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var11 = null;
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var11);
    var12.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var12);
    var15.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var23 = var20.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    var15.addSubtitle((org.jfree.chart.title.Title)var24);
    java.awt.image.BufferedImage var28 = var15.createBufferedImage(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var34 = var31.getItemLabelPaint((-1), 100);
    var15.setBackgroundPaint(var34);
    org.jfree.chart.event.ChartProgressListener var36 = null;
    var15.removeProgressListener(var36);
    org.jfree.chart.event.ChartChangeEventType var38 = null;
    org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var15, var38);
    double var40 = var1.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test223"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    var2.clearCategoryLabelToolTips();
    double var4 = var2.getUpperMargin();
    java.awt.Font var6 = null;
    java.awt.Paint var7 = null;
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var7, 100.0f, 1, var10);
    java.util.List var12 = var11.getLines();
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var19 = null;
    var17.setSeriesPositiveItemLabelPosition(100, var19);
    double var21 = var17.getItemMargin();
    java.awt.Font var23 = null;
    var17.setSeriesItemLabelFont(0, var23);
    java.awt.Font var27 = var17.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("Polar Plot", var27);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
    var32.setLabel("");
    boolean var35 = var32.isAxisLineVisible();
    java.text.DateFormat var36 = var32.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var37 = null;
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var37);
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var38);
    var38.setRadiusGridlinesVisible(false);
    java.awt.Paint var44 = var38.getOutlinePaint();
    var11.addLine("Polar Plot", var27, var44);
    org.jfree.chart.util.HorizontalAlignment var46 = var11.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var47 = null;
    org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var46, var47, 10.0d, 0.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var53 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var56 = var53.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53);
    org.jfree.chart.renderer.category.BarRenderer3D var60 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var63 = var60.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60);
    org.jfree.chart.util.RectangleInsets var65 = var64.getMargin();
    var57.setItemLabelPadding(var65);
    org.jfree.chart.event.TitleChangeListener var67 = null;
    var57.addChangeListener(var67);
    org.jfree.chart.renderer.category.BarRenderer3D var72 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var74 = null;
    var72.setSeriesPositiveItemLabelPosition(100, var74);
    double var76 = var72.getItemMargin();
    java.awt.Font var78 = null;
    var72.setSeriesItemLabelFont(0, var78);
    java.awt.Font var82 = var72.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var83 = new org.jfree.chart.title.TextTitle("Polar Plot", var82);
    var57.setItemFont(var82);
    org.jfree.data.time.SimpleTimePeriod var87 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var88 = var87.getStart();
    org.jfree.chart.plot.IntervalMarker var91 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    org.jfree.chart.event.MarkerChangeEvent var92 = null;
    var91.notifyListeners(var92);
    org.jfree.chart.util.RectangleInsets var94 = var91.getLabelOffset();
    boolean var95 = var87.equals((java.lang.Object)var91);
    var50.add((org.jfree.chart.block.Block)var57, (java.lang.Object)var87);
    var2.removeCategoryLabelToolTip((java.lang.Comparable)var87);
    org.jfree.data.gantt.Task var98 = new org.jfree.data.gantt.Task("January", (org.jfree.data.time.TimePeriod)var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test224"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("#64000d");
    org.jfree.data.time.TimePeriod var3 = null;
    org.jfree.data.gantt.Task var4 = new org.jfree.data.gantt.Task("hi!", var3);
    var1.add(var4);
    java.lang.Object var6 = null;
    boolean var7 = var1.equals(var6);
    java.lang.Number[][] var8 = null;
    java.lang.Number[] var9 = null;
    java.lang.Number[][] var10 = new java.lang.Number[][] { var9};
    org.jfree.data.category.DefaultIntervalCategoryDataset var11 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var8, var10);
    var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var11);
    java.beans.PropertyChangeListener var13 = null;
    var1.addPropertyChangeListener(var13);
    org.jfree.data.gantt.Task var16 = var1.get("(100.0, 10.0)");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test225"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(10, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "October"+ "'", var2.equals("October"));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test226"); }


    java.text.DateFormat var2 = null;
    org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(1, 0, var2);
    java.text.DateFormat var8 = null;
    org.jfree.chart.axis.DateTickUnit var9 = new org.jfree.chart.axis.DateTickUnit(0, (-1), 100, 1, var8);
    int var10 = var9.getRollUnit();
    int var11 = var9.getRollCount();
    org.jfree.data.time.SimpleTimePeriod var14 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var15 = var14.getStart();
    java.util.Date var16 = var9.rollDate(var15);
    java.util.Date var17 = var3.addToDate(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test227"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, (-9.223372036854776E18d));
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
    var6.setLabel("");
    boolean var9 = var6.isAxisLineVisible();
    java.text.DateFormat var10 = var6.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var11 = null;
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var11);
    var12.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var12);
    var15.setNotify(false);
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var23 = var20.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    var15.addSubtitle((org.jfree.chart.title.Title)var24);
    java.awt.image.BufferedImage var28 = var15.createBufferedImage(10, 1);
    boolean var29 = var2.equals((java.lang.Object)10);
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setLowerBound((-1.0d));
    var31.setRange(0.0d, 1.0d);
    org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis("hi!");
    var39.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var44 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var46 = null;
    var44.setSeriesPositiveItemLabelPosition(100, var46);
    java.awt.Stroke var48 = var44.getBaseOutlineStroke();
    var39.setAxisLineStroke(var48);
    var39.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var54 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var57 = var54.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54);
    org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var64 = var61.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var61);
    org.jfree.chart.util.RectangleInsets var66 = var65.getMargin();
    var58.setItemLabelPadding(var66);
    java.awt.geom.Rectangle2D var68 = var58.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var71 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var39, (java.awt.Shape)var68, "hi!", "hi!");
    org.jfree.chart.renderer.category.BarRenderer3D var74 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var77 = var74.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var78 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var74);
    org.jfree.chart.util.RectangleInsets var79 = var78.getMargin();
    org.jfree.chart.util.RectangleEdge var80 = var78.getLegendItemGraphicEdge();
    double var81 = var31.java2DToValue((-1.0d), var68, var80);
    boolean var82 = var2.equals((java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == (-9.223372036854776E18d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test228"); }


    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.SimpleTimePeriod var7 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var8 = var7.getEnd();
    org.jfree.data.gantt.Task var9 = new org.jfree.data.gantt.Task("", var4, var8);
    var9.setDescription("Polar Plot");
    var9.setPercentComplete(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test229"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var2 = var1.getBlue();
    java.awt.Paint[] var3 = new java.awt.Paint[] { var1};
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Color var9 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var10 = var9.getBlue();
    var7.setBackgroundPaint((java.awt.Paint)var9);
    java.awt.Paint[] var12 = new java.awt.Paint[] { var9};
    java.awt.Color var14 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var15 = var14.getBlue();
    org.jfree.chart.urls.StandardCategoryURLGenerator var19 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
    boolean var20 = var14.equals((java.lang.Object)"");
    float[] var24 = new float[] { 1.0f, 100.0f, 10.0f};
    float[] var25 = var14.getColorComponents(var24);
    java.awt.Paint[] var26 = new java.awt.Paint[] { var14};
    java.awt.Stroke[] var27 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var32 = var30.getSeriesNegativeItemLabelPosition(13);
    java.awt.Stroke var34 = var30.lookupSeriesOutlineStroke(100);
    java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
    org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var41 = var38.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
    org.jfree.chart.util.RectangleInsets var50 = var49.getMargin();
    var42.setItemLabelPadding(var50);
    double var53 = var50.trimHeight((-1.0d));
    double var55 = var50.calculateLeftOutset(100.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var61 = var58.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58);
    org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var68 = var65.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var65);
    org.jfree.chart.util.RectangleInsets var70 = var69.getMargin();
    var62.setItemLabelPadding(var70);
    java.awt.geom.Rectangle2D var72 = var62.getBounds();
    java.awt.geom.Rectangle2D var75 = var50.createInsetRectangle(var72, false, false);
    java.awt.Shape[] var76 = new java.awt.Shape[] { var75};
    org.jfree.chart.plot.DefaultDrawingSupplier var77 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var12, var26, var27, var35, var76);
    java.lang.Object var78 = var77.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test230"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getPadding();
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var10 = var7.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    var11.setItemLabelPadding(var19);
    org.jfree.chart.event.TitleChangeListener var21 = null;
    var11.addChangeListener(var21);
    org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var28 = null;
    var26.setSeriesPositiveItemLabelPosition(100, var28);
    double var30 = var26.getItemMargin();
    java.awt.Font var32 = null;
    var26.setSeriesItemLabelFont(0, var32);
    java.awt.Font var36 = var26.getItemLabelFont(0, (-1));
    org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("Polar Plot", var36);
    var11.setItemFont(var36);
    org.jfree.chart.util.RectangleEdge var39 = var11.getLegendItemGraphicEdge();
    var3.setLegendItemGraphicEdge(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test231"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var2.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Stroke var6 = var2.getBaseOutlineStroke();
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var10.setSeriesPositiveItemLabelPosition(100, var12);
    java.awt.Stroke var14 = var10.getBaseOutlineStroke();
    java.lang.Object var15 = var10.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var21 = var18.getItemLabelPaint((-1), 100);
    var18.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var26 = var18.getItemOutlineStroke(0, (-1));
    var10.setBaseStroke(var26);
    int var28 = var10.getRowCount();
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var33 = null;
    var31.setSeriesPositiveItemLabelPosition(100, var33);
    java.awt.Stroke var35 = var31.getBaseOutlineStroke();
    double var36 = var31.getItemMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var39 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var41 = var39.getSeriesNegativeItemLabelPosition(13);
    var31.setBasePositiveItemLabelPosition(var41, true);
    double var44 = var41.getAngle();
    var10.setBasePositiveItemLabelPosition(var41, false);
    var2.setBasePositiveItemLabelPosition(var41, false);
    java.awt.Paint var49 = var2.getBaseItemLabelPaint();
    var2.setBaseSeriesVisibleInLegend(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test232"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
    org.jfree.chart.axis.ValueAxis var16 = null;
    int var17 = var12.getRangeAxisIndex(var16);
    java.util.List var18 = var12.getAnnotations();
    org.jfree.chart.plot.PlotOrientation var19 = var12.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test233"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    var1.setAxisLineStroke(var10);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var19 = var16.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var26 = var23.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.util.RectangleInsets var28 = var27.getMargin();
    var20.setItemLabelPadding(var28);
    java.awt.geom.Rectangle2D var30 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var30, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
    var35.setLabel("");
    boolean var38 = var35.isAxisLineVisible();
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 0.0d);
    var35.setRange(var41, true, true);
    var1.setRange(var41, false, false);
    org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(var41, 1.0d);
    double var50 = var49.getHeight();
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("hi!");
    var52.setLabel("");
    boolean var55 = var52.isAxisLineVisible();
    org.jfree.data.Range var58 = new org.jfree.data.Range(0.0d, 0.0d);
    var52.setRange(var58, true, true);
    org.jfree.data.Range var64 = org.jfree.data.Range.expand(var58, 0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var65 = var49.toRangeWidth(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test234"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    int var15 = var12.getBackgroundImageAlignment();
    org.jfree.chart.title.TextTitle var16 = var12.getTitle();
    java.util.List var17 = var12.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var18 = null;
    var12.removeProgressListener(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test235"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("DateTickUnit[YEAR, -1]");
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.axis.AxisState var3 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var9 = var6.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var16 = var13.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    org.jfree.chart.util.RectangleInsets var18 = var17.getMargin();
    var10.setItemLabelPadding(var18);
    double var21 = var18.trimHeight((-1.0d));
    double var23 = var18.calculateLeftOutset(100.0d);
    org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
    boolean var27 = var18.equals((java.lang.Object)var26);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var33 = var30.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    org.jfree.chart.util.RectangleInsets var35 = var34.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var41 = var38.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
    org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var48 = var45.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
    org.jfree.chart.util.RectangleInsets var50 = var49.getMargin();
    var42.setItemLabelPadding(var50);
    java.awt.geom.Rectangle2D var52 = var42.getBounds();
    java.awt.geom.Rectangle2D var55 = var35.createInsetRectangle(var52, false, false);
    java.awt.geom.Rectangle2D var58 = var18.createOutsetRectangle(var55, false, true);
    org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var64 = var61.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var61);
    org.jfree.chart.util.RectangleInsets var66 = var65.getMargin();
    org.jfree.chart.util.RectangleEdge var67 = var65.getLegendItemGraphicEdge();
    java.util.List var68 = var1.refreshTicks(var2, var3, var55, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test236"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.data.xy.XYDataset var15 = var12.getDataset(10);
    var12.setRangeCrosshairValue(0.0d, false);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    var21.setLabel("");
    boolean var24 = var21.isAxisLineVisible();
    java.text.DateFormat var25 = var21.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, var26);
    org.jfree.chart.axis.ValueAxis var28 = var27.getAxis();
    var27.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
    var32.setUpperBound(1.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var37 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var39 = null;
    var37.setSeriesPositiveItemLabelPosition(100, var39);
    java.awt.Stroke var41 = var37.getBaseOutlineStroke();
    var32.setAxisLineStroke(var41);
    var32.setTickMarkInsideLength(0.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    org.jfree.chart.renderer.category.BarRenderer3D var54 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var57 = var54.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54);
    org.jfree.chart.util.RectangleInsets var59 = var58.getMargin();
    var51.setItemLabelPadding(var59);
    java.awt.geom.Rectangle2D var61 = var51.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var64 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var32, (java.awt.Shape)var61, "hi!", "hi!");
    java.awt.Shape var65 = var64.getArea();
    boolean var66 = var27.equals((java.lang.Object)var64);
    org.jfree.chart.event.RendererChangeEvent var67 = null;
    var27.rendererChanged(var67);
    org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var73 = null;
    var71.setSeriesPositiveItemLabelPosition(100, var73);
    double var75 = var71.getItemMargin();
    boolean var76 = var71.getAutoPopulateSeriesOutlineStroke();
    java.awt.Stroke var77 = var71.getBaseStroke();
    var27.setAngleGridlineStroke(var77);
    var12.setDomainZeroBaselineStroke(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test237"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var3.setSeriesPositiveItemLabelPosition(100, var5);
    double var7 = var3.getItemMargin();
    java.awt.Font var9 = null;
    var3.setSeriesItemLabelFont(0, var9);
    java.awt.Font var13 = var3.getItemLabelFont(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var16.setSeriesPositiveItemLabelPosition(100, var18);
    java.awt.Stroke var20 = var16.getBaseOutlineStroke();
    java.lang.Object var21 = var16.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var27 = var24.getItemLabelPaint((-1), 100);
    var24.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var32 = var24.getItemOutlineStroke(0, (-1));
    var16.setBaseStroke(var32);
    java.awt.Paint var34 = var16.getBaseItemLabelPaint();
    org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("", var13, var34);
    float var36 = var35.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0f);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test238"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLowerBound((-1.0d));
    java.text.DateFormat var5 = var2.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    var7.setUpperBound(1.0d);
    boolean var10 = var7.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var7, var11);
    java.lang.Object var13 = var12.clone();
    int var14 = var12.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedDomainAxisSpace();
    int var16 = var12.getRangeAxisCount();
    java.util.List var17 = var12.getAnnotations();
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var23 = var20.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var30 = var27.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    org.jfree.chart.util.RectangleInsets var32 = var31.getMargin();
    var24.setItemLabelPadding(var32);
    org.jfree.chart.util.UnitType var34 = var32.getUnitType();
    double var35 = var32.getBottom();
    var12.setInsets(var32);
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    java.awt.geom.Point2D var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.zoomDomainAxes(1.0d, (-9.223372036854776E18d), var39, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test239"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    org.jfree.chart.axis.NumberTickUnit var23 = var1.getTickUnit();
    org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var29 = var26.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
    org.jfree.chart.util.RectangleInsets var31 = var30.getMargin();
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.util.Size2D var33 = var30.arrange(var32);
    org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var38 = null;
    var36.setSeriesPositiveItemLabelPosition(100, var38);
    double var40 = var36.getItemMargin();
    java.awt.Font var42 = null;
    var36.setSeriesItemLabelFont(0, var42);
    java.awt.Paint var44 = var36.getBaseOutlinePaint();
    java.awt.Paint var45 = var36.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var50 = null;
    var48.setSeriesPositiveItemLabelPosition(100, var50);
    java.awt.Stroke var52 = var48.getBaseOutlineStroke();
    java.lang.Object var53 = var48.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var59 = var56.getItemLabelPaint((-1), 100);
    var56.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var64 = var56.getItemOutlineStroke(0, (-1));
    var48.setBaseStroke(var64);
    java.awt.Paint var66 = var48.getBaseItemLabelPaint();
    double var67 = var48.getItemLabelAnchorOffset();
    org.jfree.chart.labels.ItemLabelPosition var69 = var48.getSeriesPositiveItemLabelPosition(0);
    var36.setBasePositiveItemLabelPosition(var69);
    java.awt.Font var71 = var36.getBaseItemLabelFont();
    org.jfree.chart.LegendItemSource[] var72 = new org.jfree.chart.LegendItemSource[] { var36};
    var30.setSources(var72);
    org.jfree.chart.util.RectangleInsets var78 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), (-1.0d), 10.0d);
    double var79 = var78.getRight();
    var30.setPadding(var78);
    org.jfree.chart.util.RectangleEdge var81 = var30.getLegendItemGraphicEdge();
    boolean var82 = var23.equals((java.lang.Object)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test240"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    var3.setLabel("");
    boolean var6 = var3.isAxisLineVisible();
    java.text.DateFormat var7 = var3.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var8);
    var9.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var12.setNotify(false);
    int var15 = var12.getBackgroundImageAlignment();
    org.jfree.chart.title.TextTitle var16 = var12.getTitle();
    java.util.List var17 = var12.getSubtitles();
    boolean var18 = var12.isNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test241"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, 1, var5);
    java.util.List var7 = var6.getLines();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    var9.setLabel("");
    boolean var12 = var9.isAxisLineVisible();
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    var9.setRange(var15, true, true);
    org.jfree.data.Range var21 = org.jfree.data.Range.expand(var15, 0.0d, 0.0d);
    boolean var22 = var6.equals((java.lang.Object)0.0d);
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.text.TextBlockAnchor var26 = null;
    java.awt.Shape var30 = var6.calculateBounds(var23, 1.0f, 100.0f, var26, 100.0f, 100.0f, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test242"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    var8.setAngleLabelsVisible(true);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("hi!");
    var13.setAutoRangeMinimumSize(10.0d, false);
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var22 = var19.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
    org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var29 = var26.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
    org.jfree.chart.util.RectangleInsets var31 = var30.getMargin();
    var23.setItemLabelPadding(var31);
    java.awt.geom.Rectangle2D var33 = var23.getBounds();
    var13.setLeftArrow((java.awt.Shape)var33);
    org.jfree.data.time.SimpleTimePeriod var38 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var39 = var38.getStart();
    org.jfree.data.time.SimpleTimePeriod var42 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var43 = var42.getEnd();
    org.jfree.data.gantt.Task var44 = new org.jfree.data.gantt.Task("", var39, var43);
    org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var50 = var47.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    org.jfree.chart.util.RectangleInsets var52 = var51.getMargin();
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var58 = var55.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
    org.jfree.chart.renderer.category.BarRenderer3D var62 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var65 = var62.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var62);
    org.jfree.chart.util.RectangleInsets var67 = var66.getMargin();
    var59.setItemLabelPadding(var67);
    java.awt.geom.Rectangle2D var69 = var59.getBounds();
    java.awt.geom.Rectangle2D var72 = var52.createInsetRectangle(var69, false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var75 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var78 = var75.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var79 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var75);
    org.jfree.chart.util.RectangleInsets var80 = var79.getMargin();
    org.jfree.chart.util.RectangleEdge var81 = var79.getLegendItemGraphicEdge();
    double var82 = var13.dateToJava2D(var43, var69, var81);
    var8.drawBackgroundImage(var11, var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.0d);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test243"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
//     org.jfree.data.gantt.TaskSeries var3 = new org.jfree.data.gantt.TaskSeries("#64000d");
//     org.jfree.data.time.TimePeriod var5 = null;
//     org.jfree.data.gantt.Task var6 = new org.jfree.data.gantt.Task("hi!", var5);
//     var3.add(var6);
//     java.lang.Object var8 = null;
//     boolean var9 = var3.equals(var8);
//     java.lang.Number[][] var10 = null;
//     java.lang.Number[] var11 = null;
//     java.lang.Number[][] var12 = new java.lang.Number[][] { var11};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var10, var12);
//     var3.addChangeListener((org.jfree.data.general.SeriesChangeListener)var13);
//     org.jfree.data.Range var15 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var13);
//     java.lang.Number var16 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var13);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test244"); }
// 
// 
//     org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SimpleTimePeriod var7 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
//     java.util.Date var8 = var7.getEnd();
//     org.jfree.data.gantt.Task var9 = new org.jfree.data.gantt.Task("", var4, var8);
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var8, var10);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test245"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(13);
//     org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var10 = null;
//     var8.setSeriesPositiveItemLabelPosition(100, var10);
//     double var12 = var8.getItemMargin();
//     java.awt.Font var14 = null;
//     var8.setSeriesItemLabelFont(0, var14);
//     double var16 = var8.getItemLabelAnchorOffset();
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
//     var18.setUpperBound(1.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var25 = null;
//     var23.setSeriesPositiveItemLabelPosition(100, var25);
//     java.awt.Stroke var27 = var23.getBaseOutlineStroke();
//     var18.setAxisLineStroke(var27);
//     var18.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var33 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var36 = var33.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
//     org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var43 = var40.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     org.jfree.chart.util.RectangleInsets var45 = var44.getMargin();
//     var37.setItemLabelPadding(var45);
//     java.awt.geom.Rectangle2D var47 = var37.getBounds();
//     org.jfree.chart.entity.AxisLabelEntity var50 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, (java.awt.Shape)var47, "hi!", "hi!");
//     org.jfree.chart.axis.DateTickMarkPosition var51 = var18.getTickMarkPosition();
//     java.awt.Color var53 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var54 = var53.getBlue();
//     org.jfree.chart.urls.StandardCategoryURLGenerator var58 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "", "hi!");
//     boolean var59 = var53.equals((java.lang.Object)"");
//     var18.setTickLabelPaint((java.awt.Paint)var53);
//     org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var66 = var63.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
//     var63.setBaseSeriesVisible(false);
//     java.awt.Stroke var71 = var63.getSeriesStroke(10);
//     org.jfree.chart.renderer.category.BarRenderer3D var74 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var76 = null;
//     var74.setSeriesPositiveItemLabelPosition(100, var76);
//     java.awt.Stroke var78 = var74.getBaseOutlineStroke();
//     double var79 = var74.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var82 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var84 = var82.getSeriesNegativeItemLabelPosition(13);
//     var74.setBasePositiveItemLabelPosition(var84, true);
//     double var87 = var84.getAngle();
//     org.jfree.chart.labels.ItemLabelAnchor var88 = var84.getItemLabelAnchor();
//     var63.setPositiveItemLabelPositionFallback(var84);
//     boolean var90 = var53.equals((java.lang.Object)var84);
//     var8.setNegativeItemLabelPositionFallback(var84);
//     var2.setSeriesPositiveItemLabelPosition(0, var84);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var33 and var2.", var33.equals(var2) == var2.equals(var33));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var40 and var2.", var40.equals(var2) == var2.equals(var40));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var82 and var2.", var82.equals(var2) == var2.equals(var82));
//     
//     // Checks the contract:  equals-hashcode on var4 and var84
//     assertTrue("Contract failed: equals-hashcode on var4 and var84", var4.equals(var84) ? var4.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var4
//     assertTrue("Contract failed: equals-hashcode on var84 and var4", var84.equals(var4) ? var84.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test246"); }


    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.SimpleTimePeriod var7 = new org.jfree.data.time.SimpleTimePeriod((-1L), 100L);
    java.util.Date var8 = var7.getEnd();
    org.jfree.data.gantt.Task var9 = new org.jfree.data.gantt.Task("", var4, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var8);
    org.jfree.data.DefaultKeyedValue var12 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)var10, (java.lang.Number)(short)1);
    java.lang.Number var13 = var12.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (short)1+ "'", var13.equals((short)1));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test247"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setLabel("");
    boolean var5 = var2.isAxisLineVisible();
    java.text.DateFormat var6 = var2.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getAxis();
    org.jfree.data.xy.XYDataset var10 = null;
    var8.setDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var8.getInsets();
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var8.addChangeListener(var13);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleAnchor var18 = null;
    java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
    var8.zoomRangeAxes(10.0d, var16, var19);
    org.jfree.chart.event.MarkerChangeEvent var21 = null;
    var8.markerChanged(var21);
    boolean var23 = var8.isAngleLabelsVisible();
    java.awt.Paint var24 = var8.getNoDataMessagePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test248"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    var7.setSeriesPositiveItemLabelPosition(100, var9);
    double var11 = var7.getItemMargin();
    java.awt.Font var13 = null;
    var7.setSeriesItemLabelFont(0, var13);
    java.awt.Font var17 = var7.getItemLabelFont(0, (-1));
    org.jfree.chart.axis.MarkerAxisBand var18 = new org.jfree.chart.axis.MarkerAxisBand(var0, 1.0d, 0.0d, 100.0d, 0.0d, var17);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    java.awt.Stroke var24 = var21.getItemOutlineStroke((-1), (-1));
    java.awt.Paint var27 = var21.getItemLabelPaint(100, 0);
    boolean var30 = var21.getItemShapeVisible(13, (-1));
    boolean var31 = var18.equals((java.lang.Object)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test249"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var4 = null;
//     var2.setSeriesPositiveItemLabelPosition(100, var4);
//     java.awt.Stroke var6 = var2.getBaseOutlineStroke();
//     double var7 = var2.getItemMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(13);
//     var2.setBasePositiveItemLabelPosition(var12, true);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
//     var19.setLabel("");
//     boolean var22 = var19.isAxisLineVisible();
//     java.text.DateFormat var23 = var19.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     org.jfree.chart.axis.ValueAxis var26 = var25.getAxis();
//     org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 10.0d);
//     org.jfree.chart.event.MarkerChangeEvent var30 = null;
//     var29.notifyListeners(var30);
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var37 = var34.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
//     org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var45 = var42.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
//     org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
//     java.awt.Paint var52 = var49.getItemLabelPaint((-1), 100);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
//     org.jfree.chart.util.RectangleInsets var54 = var53.getMargin();
//     var46.setItemLabelPadding(var54);
//     java.awt.geom.Rectangle2D var56 = var46.getBounds();
//     java.awt.geom.Rectangle2D var59 = var39.createInsetRectangle(var56, false, false);
//     var2.drawRangeMarker(var15, var16, var26, (org.jfree.chart.plot.Marker)var29, var59);
//     java.lang.Object var61 = var29.clone();
//     java.awt.Color var63 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var64 = var63.getBlue();
//     var29.setOutlinePaint((java.awt.Paint)var63);
//     org.jfree.chart.axis.DateAxis var67 = new org.jfree.chart.axis.DateAxis("hi!");
//     var67.setLabel("");
//     boolean var70 = var67.isAxisLineVisible();
//     org.jfree.data.Range var73 = new org.jfree.data.Range(0.0d, 0.0d);
//     var67.setRange(var73, true, true);
//     boolean var77 = var67.isAutoRange();
//     org.jfree.data.xy.XYDataset var78 = null;
//     org.jfree.chart.axis.DateAxis var80 = new org.jfree.chart.axis.DateAxis("hi!");
//     var80.setLabel("");
//     boolean var83 = var80.isAxisLineVisible();
//     java.text.DateFormat var84 = var80.getDateFormatOverride();
//     org.jfree.chart.renderer.PolarItemRenderer var85 = null;
//     org.jfree.chart.plot.PolarPlot var86 = new org.jfree.chart.plot.PolarPlot(var78, (org.jfree.chart.axis.ValueAxis)var80, var85);
//     org.jfree.chart.axis.ValueAxis var87 = var86.getAxis();
//     org.jfree.data.xy.XYDataset var88 = null;
//     var86.setDataset(var88);
//     org.jfree.chart.util.RectangleInsets var90 = var86.getInsets();
//     double var92 = var90.trimHeight(10.0d);
//     var67.setLabelInsets(var90);
//     double var95 = var90.extendHeight(0.0d);
//     double var97 = var90.trimHeight((-1.0d));
//     var29.setLabelOffset(var90);
//     
//     // Checks the contract:  equals-hashcode on var25 and var86
//     assertTrue("Contract failed: equals-hashcode on var25 and var86", var25.equals(var86) ? var25.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var25
//     assertTrue("Contract failed: equals-hashcode on var86 and var25", var86.equals(var25) ? var86.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test250"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var5 = var2.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var12 = var9.getItemLabelPaint((-1), 100);
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var14 = var13.getMargin();
    var6.setItemLabelPadding(var14);
    java.awt.geom.Rectangle2D var16 = var6.getBounds();
    org.jfree.chart.util.RectangleInsets var17 = var6.getLegendItemGraphicPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test251"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("DateTickUnit[YEAR, -1]");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setLowerBound((-1.0d));
    java.text.DateFormat var8 = var5.getDateFormatOverride();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    var10.setUpperBound(1.0d);
    boolean var13 = var10.isNegativeArrowVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
    int var21 = var15.getDomainAxisCount();
    boolean var22 = var1.equals((java.lang.Object)var15);
    org.jfree.chart.axis.NumberTickUnit var23 = var1.getTickUnit();
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLabel("");
    boolean var28 = var25.isAxisLineVisible();
    org.jfree.data.Range var31 = new org.jfree.data.Range(0.0d, 0.0d);
    var25.setRange(var31, true, true);
    java.lang.String var35 = var31.toString();
    var1.setRangeWithMargins(var31, false, true);
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var44 = org.jfree.data.Range.shift(var41, 1.0d, false);
    org.jfree.data.Range var45 = org.jfree.data.Range.combine(var31, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "Range[0.0,0.0]"+ "'", var35.equals("Range[0.0,0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test252"); }


    java.awt.Color var3 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var6.setSeriesPositiveItemLabelPosition(100, var8);
    java.awt.Stroke var10 = var6.getBaseOutlineStroke();
    java.lang.Object var11 = var6.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    java.awt.Paint var17 = var14.getItemLabelPaint((-1), 100);
    var14.setAutoPopulateSeriesShape(true);
    java.awt.Stroke var22 = var14.getItemOutlineStroke(0, (-1));
    var6.setBaseStroke(var22);
    java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var26 = var25.getBlue();
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    var31.setLabel("");
    boolean var34 = var31.isAxisLineVisible();
    java.text.DateFormat var35 = var31.getDateFormatOverride();
    org.jfree.chart.renderer.PolarItemRenderer var36 = null;
    org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, var36);
    var37.setAngleLabelsVisible(true);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var37);
    var37.setRadiusGridlinesVisible(false);
    java.awt.Paint var43 = var37.getOutlinePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var48 = null;
    var46.setSeriesPositiveItemLabelPosition(100, var48);
    java.awt.Stroke var50 = var46.getBaseOutlineStroke();
    org.jfree.chart.plot.CategoryMarker var51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)0L, var43, var50);
    org.jfree.chart.plot.IntervalMarker var53 = new org.jfree.chart.plot.IntervalMarker(10.0d, 1.0d, (java.awt.Paint)var3, var22, (java.awt.Paint)var25, var50, 0.0f);
    var53.setStartValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

}
