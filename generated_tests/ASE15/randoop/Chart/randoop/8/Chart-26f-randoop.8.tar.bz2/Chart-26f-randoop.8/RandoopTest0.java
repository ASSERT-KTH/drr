
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("hi!", var1, var2, var3, var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("hi!");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    var0.setSeriesItemLabelsVisible(0, false);
    java.awt.Shape var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-1), var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var1 = var0.getItemLabelAnchorOffset();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.data.category.CategoryDataset var11 = null;
//     var0.drawItem(var5, var6, var7, var8, var9, var10, var11, 0, 0, 10);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    var0.setSeriesItemLabelsVisible(0, false);
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(byte)0);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)100};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.awt.Stroke var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    java.awt.Stroke var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRangeCrosshairStroke(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setBaseToolTipGenerator(var2);
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlineStroke(var4, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var5 = var4.getBasePaint();
//     org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("", var1, var5);
//     
//     // Checks the contract:  var6.equals(var6)
//     assertTrue("Contract failed: var6.equals(var6)", var6.equals(var6));
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 2.0d, 10.0d);
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)1.0f);
//     org.jfree.chart.block.BlockContainer var8 = null;
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(1.0d, 2.0d);
//     org.jfree.chart.util.Size2D var13 = var4.arrange(var8, var9, var12);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.labels.ItemLabelPosition var3 = null;
//     var2.setNegativeItemLabelPositionFallback(var3);
//     var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var2.drawDomainGridline(var9, var10, var11, (-1.0d));
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.0d, 1.0d, 2.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    java.awt.Shape var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDownArrow(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.util.RectangleInsets var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setLabelInsets(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var1 = null;
//     var0.setBaseItemLabelGenerator(var1, true);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.plot.CategoryMarker var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var0.drawDomainMarker(var4, var5, var6, var7, var8);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    java.awt.Stroke var3 = var0.getSeriesOutlineStroke(100);
    double var4 = var0.getLowerClip();
    java.awt.Stroke var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-1), var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears((-1), var1);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    java.awt.Stroke var3 = var0.getSeriesOutlineStroke(100);
    double var4 = var0.getLowerClip();
    boolean var6 = var0.isSeriesVisible(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    boolean var2 = var0.getBaseCreateEntities();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var0.getItemLabelGenerator(100, (-1));
    org.jfree.chart.urls.StandardCategoryURLGenerator var8 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-1), (org.jfree.chart.urls.CategoryURLGenerator)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10, 100, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = null;
    var0.setBaseItemLabelGenerator(var1, true);
    boolean var4 = var0.getBaseSeriesVisible();
    var0.setIncludeBaseInRange(false);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var11 = var10.getBasePaint();
    var0.setSeriesFillPaint(10, var11, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-1), var15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 2.0d, 10.0d);
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)1.0f);
//     var7.setToolTipText("hi!");
//     double var10 = var7.getContentYOffset();
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 2.0d, 10.0d);
//     org.jfree.data.general.Dataset var16 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var15, var16, (java.lang.Comparable)1.0f);
//     double var19 = var18.getContentXOffset();
//     org.jfree.chart.urls.StandardCategoryURLGenerator var21 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
//     var7.add((org.jfree.chart.block.Block)var18, (java.lang.Object)var21);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var3 = var2.clone();
//     java.lang.Object var4 = var2.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var4
//     assertTrue("Contract failed: equals-hashcode on var3 and var4", var3.equals(var4) ? var3.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var3
//     assertTrue("Contract failed: equals-hashcode on var4 and var3", var4.equals(var3) ? var4.hashCode() == var3.hashCode() : true);
// 
//   }

//  public void test45() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var2);
//
//  }
//
  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     java.awt.Paint var14 = var12.getTickMarkPaint();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, var20, var21);
//     org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     int var25 = var22.getIndexOf(var24);
//     var12.addChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
//     
//     // Checks the contract:  equals-hashcode on var22 and var7
//     assertTrue("Contract failed: equals-hashcode on var22 and var7", var22.equals(var7) ? var22.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var7.", var22.equals(var7) == var7.equals(var22));
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    double var2 = var1.getLowerBound();
    java.awt.Shape var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setUpArrow(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 100.0d, var4, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.clone(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    var3.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var6, var7);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var8.setRenderer(var9);
    java.awt.Paint var11 = var8.getNoDataMessagePaint();
    java.awt.Stroke var12 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var16 = var15.getBasePaint();
    java.awt.Stroke var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d, var11, var12, var16, var17, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    java.awt.Shape var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var17 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var14, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    java.awt.Stroke var3 = var0.getSeriesOutlineStroke(100);
    var0.setBaseItemLabelsVisible(true);
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape(var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.drawBackground(var1, var2);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    float[] var3 = new float[] { 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var4 = var1.getRGBComponents(var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", var3);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.2d, 10.0d, 0, (java.lang.Comparable)0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTextAlignment(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var3 = var1.getSeriesPaint((-1));
//     java.awt.Font var6 = var1.getItemLabelFont(1, 1);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
//     var7.setBaseItemLabelGenerator(var8, true);
//     boolean var11 = var7.getBaseSeriesVisible();
//     var7.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var18 = var17.getBasePaint();
//     var7.setSeriesFillPaint(10, var18, false);
//     org.jfree.chart.text.TextLine var21 = new org.jfree.chart.text.TextLine("", var6, var18);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var7.", var1.equals(var7) == var7.equals(var1));
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var3 = null;
    java.awt.Rectangle var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.awt.geom.AffineTransform var6 = null;
    java.awt.RenderingHints var7 = null;
    java.awt.PaintContext var8 = var2.createContext(var3, var4, var5, var6, var7);
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var2);
    float[] var11 = new float[] { 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var12 = var2.getRGBColorComponents(var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    var12.resizeRange(100.0d);
    java.awt.Shape var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setUpArrow(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TickLabelEntity var3 = new org.jfree.chart.entity.TickLabelEntity(var0, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     var0.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var7 = var5.getSeriesPaint((-1));
//     java.awt.Font var10 = var5.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
//     var5.setBasePositiveItemLabelPosition(var11);
//     var0.setSeriesPositiveItemLabelPosition(0, var11, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var0.", var5.equals(var0) == var0.equals(var5));
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeEvent var8 = null;
    var7.notifyListeners(var8);
    java.awt.Stroke var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setDomainGridlineStroke(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.awt.geom.AffineTransform var10 = null;
    java.awt.RenderingHints var11 = null;
    java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
    var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
    int var14 = var4.getPieIndex();
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
    var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var28.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    org.jfree.chart.event.PlotChangeListener var34 = null;
    var33.removeChangeListener(var34);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
    java.awt.Paint var40 = var38.getTickMarkPaint();
    var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
    var4.setLabelShadowPaint(var40);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    java.awt.Stroke var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setStroke(var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var1 = null;
    var0.setLegendItemToolTipGenerator(var1);
    java.awt.Paint var4 = var0.getSeriesPaint((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     var16.setTextAntiAlias(false);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     var16.draw(var20, var21);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var3 = var2.clone();
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var7 = null;
//     java.awt.Rectangle var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.AffineTransform var10 = null;
//     java.awt.RenderingHints var11 = null;
//     java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
//     var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
//     int var14 = var4.getPieIndex();
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var18 = null;
//     java.awt.Rectangle var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     java.awt.geom.AffineTransform var21 = null;
//     java.awt.RenderingHints var22 = null;
//     java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
//     var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
//     java.awt.Paint var40 = var38.getTickMarkPaint();
//     var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
//     var4.setLabelShadowPaint(var40);
//     var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     var2.setStartValue(10.0d);
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     var47.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     var52.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var50, (org.jfree.chart.axis.ValueAxis)var52, var55, var56);
//     org.jfree.chart.plot.DrawingSupplier var58 = var57.getDrawingSupplier();
//     var47.addChangeListener((org.jfree.chart.event.AxisChangeListener)var57);
//     var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var57);
//     
//     // Checks the contract:  equals-hashcode on var57 and var33
//     assertTrue("Contract failed: equals-hashcode on var57 and var33", var57.equals(var33) ? var57.hashCode() == var33.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var57 and var33.", var57.equals(var33) == var33.equals(var57));
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var3 = null;
    java.awt.Rectangle var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.awt.geom.AffineTransform var6 = null;
    java.awt.RenderingHints var7 = null;
    java.awt.PaintContext var8 = var2.createContext(var3, var4, var5, var6, var7);
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var2);
    int var10 = var0.getPieIndex();
    org.jfree.chart.labels.PieToolTipGenerator var11 = null;
    var0.setToolTipGenerator(var11);
    org.jfree.chart.plot.AbstractPieLabelDistributor var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelDistributor(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 2.0d, 10.0d);
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)1.0f);
//     var7.setToolTipText("hi!");
//     java.lang.Object var10 = var7.clone();
//     java.util.List var11 = var7.getBlocks();
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 2.0d, 10.0d);
//     org.jfree.data.general.Dataset var17 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var17, (java.lang.Comparable)1.0f);
//     var7.setArrangement((org.jfree.chart.block.Arrangement)var16);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var19
//     assertTrue("Contract failed: equals-hashcode on var7 and var19", var7.equals(var19) ? var7.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var7
//     assertTrue("Contract failed: equals-hashcode on var19 and var7", var19.equals(var7) ? var19.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 2.0d, 10.0d);
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)1.0f);
    var7.setToolTipText("hi!");
    java.lang.Object var10 = var7.clone();
    java.util.List var11 = var7.getBlocks();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var12 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var11);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.VerticalAlignment var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setVerticalAlignment(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     var3.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var6, var7);
//     org.jfree.chart.event.PlotChangeListener var9 = null;
//     var8.removeChangeListener(var9);
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     var8.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var17 = var15.getSeriesPaint((-1));
//     java.awt.Font var20 = var15.getItemLabelFont(1, 1);
//     var13.setTickLabelFont(var20);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     var24.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, var27, var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     var29.setRenderer(var30);
//     java.awt.Paint var32 = var29.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var33 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var34 = var33.getItemLabelAnchorOffset();
//     var33.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var38 = var29.equals((java.lang.Object)var33);
//     org.jfree.chart.plot.SeriesRenderingOrder var39 = var29.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var41 = var29.getDataset(10);
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("XY Plot", var20, (org.jfree.chart.plot.Plot)var29, false);
//     
//     // Checks the contract:  equals-hashcode on var29 and var8
//     assertTrue("Contract failed: equals-hashcode on var29 and var8", var29.equals(var8) ? var29.hashCode() == var8.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var8.", var29.equals(var8) == var8.equals(var29));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var33.", var15.equals(var33) == var33.equals(var15));
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), 100.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-10289251));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getPercentComplete(68, 0, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.LegendTitle var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addLegend(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(10, 68);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.ChartRenderingInfo var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var21 = var16.createBufferedImage((-10289251), (-1), var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var4 = var2.getSubtitle((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)2);
//     org.jfree.data.gantt.TaskSeriesCollection var3 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetGroup var4 = var3.getGroup();
//     var0.setGroup(var4);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var1 = null;
//     var0.setBaseItemLabelGenerator(var1, true);
//     boolean var4 = var0.getBaseSeriesVisible();
//     var0.setIncludeBaseInRange(false);
//     boolean var7 = var0.getAutoPopulateSeriesOutlineStroke();
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = var0.getBaseToolTipGenerator();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.plot.CategoryMarker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var0.drawDomainMarker(var9, var10, var11, var12, var13);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    float[] var3 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var4 = var1.getRGBColorComponents(var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var1 = null;
//     var0.setBaseItemLabelGenerator(var1, true);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var14, var15);
//     org.jfree.chart.event.PlotChangeListener var17 = null;
//     var16.removeChangeListener(var17);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var21);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var25 = var23.getSeriesPaint((-1));
//     java.awt.Font var28 = var23.getItemLabelFont(1, 1);
//     var21.setTickLabelFont(var28);
//     java.text.NumberFormat var30 = null;
//     var21.setNumberFormatOverride(var30);
//     org.jfree.data.gantt.TaskSeriesCollection var32 = new org.jfree.data.gantt.TaskSeriesCollection();
//     var0.drawItem(var4, var5, var6, var7, var8, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.data.category.CategoryDataset)var32, 0, 2, 0);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    boolean var2 = var0.getBaseCreateEntities();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var0.getItemLabelGenerator(100, (-1));
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var14.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
    org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
    var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var19);
    java.awt.geom.Rectangle2D var22 = null;
    var0.drawRangeGridline(var6, var7, (org.jfree.chart.axis.ValueAxis)var9, var22, 1.0d);
    double var25 = var0.getItemMargin();
    java.awt.Color var28 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.color.ColorSpace var29 = var28.getColorSpace();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlinePaint((-10289251), (java.awt.Paint)var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     boolean var14 = var7.isDomainCrosshairVisible();
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var7.drawOutline(var15, var16);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var0.generateRowLabel((org.jfree.data.category.CategoryDataset)var1, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    int var3 = var0.getColumnIndex((java.lang.Comparable)1);
    int var5 = var0.getRowIndex((java.lang.Comparable)(byte)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var0.getRowKey(68);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.labels.ItemLabelPosition var3 = null;
//     var2.setNegativeItemLabelPositionFallback(var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var10 = var2.initialise(var5, var6, var7, (-1), var9);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == false);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 0);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var7.setRenderer(var8);
    java.awt.Paint var10 = var7.getNoDataMessagePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var12 = var11.getItemLabelAnchorOffset();
    var11.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
    boolean var16 = var7.equals((java.lang.Object)var11);
    boolean var17 = var7.isRangeZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("java.awt.Color[r=0,g=0,b=0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeEvent var8 = null;
    var7.notifyListeners(var8);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var12.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
    org.jfree.chart.event.PlotChangeListener var18 = null;
    var17.removeChangeListener(var18);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    var17.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var22);
    java.awt.Paint var24 = var22.getTickMarkPaint();
    boolean var25 = var22.isAutoRange();
    java.awt.Stroke var26 = var22.getTickMarkStroke();
    var7.setDomainCrosshairStroke(var26);
    var7.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2, 2, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var1);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.awt.geom.AffineTransform var10 = null;
    java.awt.RenderingHints var11 = null;
    java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
    var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
    int var14 = var4.getPieIndex();
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
    var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var28.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    org.jfree.chart.event.PlotChangeListener var34 = null;
    var33.removeChangeListener(var34);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
    java.awt.Paint var40 = var38.getTickMarkPaint();
    var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
    var4.setLabelShadowPaint(var40);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    org.jfree.chart.urls.PieURLGenerator var44 = null;
    var4.setURLGenerator(var44);
    java.awt.Graphics2D var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.plot.IntervalMarker var50 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var51 = var50.clone();
    org.jfree.chart.plot.RingPlot var52 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var54 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var55 = null;
    java.awt.Rectangle var56 = null;
    java.awt.geom.Rectangle2D var57 = null;
    java.awt.geom.AffineTransform var58 = null;
    java.awt.RenderingHints var59 = null;
    java.awt.PaintContext var60 = var54.createContext(var55, var56, var57, var58, var59);
    var52.setBaseSectionOutlinePaint((java.awt.Paint)var54);
    int var62 = var52.getPieIndex();
    org.jfree.chart.plot.RingPlot var63 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var65 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var66 = null;
    java.awt.Rectangle var67 = null;
    java.awt.geom.Rectangle2D var68 = null;
    java.awt.geom.AffineTransform var69 = null;
    java.awt.RenderingHints var70 = null;
    java.awt.PaintContext var71 = var65.createContext(var66, var67, var68, var69, var70);
    var63.setBaseSectionOutlinePaint((java.awt.Paint)var65);
    org.jfree.data.xy.XYDataset var74 = null;
    org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("");
    var76.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var79 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var80 = null;
    org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot(var74, (org.jfree.chart.axis.ValueAxis)var76, var79, var80);
    org.jfree.chart.event.PlotChangeListener var82 = null;
    var81.removeChangeListener(var82);
    org.jfree.chart.axis.NumberAxis var86 = new org.jfree.chart.axis.NumberAxis("");
    var81.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var86);
    java.awt.Paint var88 = var86.getTickMarkPaint();
    var63.setSectionOutlinePaint((java.lang.Comparable)1L, var88);
    var52.setLabelShadowPaint(var88);
    var50.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var52);
    org.jfree.chart.urls.PieURLGenerator var92 = null;
    var52.setURLGenerator(var92);
    org.jfree.chart.plot.PlotRenderingInfo var95 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var96 = var4.initialise(var46, var47, (org.jfree.chart.plot.PiePlot)var52, (java.lang.Integer)100, var95);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeEvent var8 = null;
    var7.notifyListeners(var8);
    boolean var10 = var7.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var4 = var3.clone();
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var7 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var8 = null;
//     java.awt.Rectangle var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     java.awt.geom.AffineTransform var11 = null;
//     java.awt.RenderingHints var12 = null;
//     java.awt.PaintContext var13 = var7.createContext(var8, var9, var10, var11, var12);
//     var5.setBaseSectionOutlinePaint((java.awt.Paint)var7);
//     int var15 = var5.getPieIndex();
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     java.awt.geom.AffineTransform var22 = null;
//     java.awt.RenderingHints var23 = null;
//     java.awt.PaintContext var24 = var18.createContext(var19, var20, var21, var22, var23);
//     var16.setBaseSectionOutlinePaint((java.awt.Paint)var18);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var29.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var29, var32, var33);
//     org.jfree.chart.event.PlotChangeListener var35 = null;
//     var34.removeChangeListener(var35);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     var34.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var39);
//     java.awt.Paint var41 = var39.getTickMarkPaint();
//     var16.setSectionOutlinePaint((java.lang.Comparable)1L, var41);
//     var5.setLabelShadowPaint(var41);
//     var3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var5);
//     java.awt.Font var45 = var3.getLabelFont();
//     org.jfree.chart.plot.RingPlot var46 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var48 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var49 = null;
//     java.awt.Rectangle var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     java.awt.geom.AffineTransform var52 = null;
//     java.awt.RenderingHints var53 = null;
//     java.awt.PaintContext var54 = var48.createContext(var49, var50, var51, var52, var53);
//     var46.setBaseSectionOutlinePaint((java.awt.Paint)var48);
//     int var56 = var46.getPieIndex();
//     org.jfree.chart.plot.RingPlot var57 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var59 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var60 = null;
//     java.awt.Rectangle var61 = null;
//     java.awt.geom.Rectangle2D var62 = null;
//     java.awt.geom.AffineTransform var63 = null;
//     java.awt.RenderingHints var64 = null;
//     java.awt.PaintContext var65 = var59.createContext(var60, var61, var62, var63, var64);
//     var57.setBaseSectionOutlinePaint((java.awt.Paint)var59);
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("");
//     var70.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var74 = null;
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot(var68, (org.jfree.chart.axis.ValueAxis)var70, var73, var74);
//     org.jfree.chart.event.PlotChangeListener var76 = null;
//     var75.removeChangeListener(var76);
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis("");
//     var75.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var80);
//     java.awt.Paint var82 = var80.getTickMarkPaint();
//     var57.setSectionOutlinePaint((java.lang.Comparable)1L, var82);
//     var46.setLabelShadowPaint(var82);
//     org.jfree.chart.text.TextLine var85 = new org.jfree.chart.text.TextLine("XY Plot", var45, var82);
//     
//     // Checks the contract:  equals-hashcode on var5 and var46
//     assertTrue("Contract failed: equals-hashcode on var5 and var46", var5.equals(var46) ? var5.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var57
//     assertTrue("Contract failed: equals-hashcode on var16 and var57", var16.equals(var57) ? var16.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var5
//     assertTrue("Contract failed: equals-hashcode on var46 and var5", var46.equals(var5) ? var46.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var16
//     assertTrue("Contract failed: equals-hashcode on var57 and var16", var57.equals(var16) ? var57.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var75
//     assertTrue("Contract failed: equals-hashcode on var34 and var75", var34.equals(var75) ? var34.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var34
//     assertTrue("Contract failed: equals-hashcode on var75 and var34", var75.equals(var34) ? var75.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = var7.getRendererForDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var7.getInsets();
    double var13 = var7.getDomainCrosshairValue();
    boolean var14 = var7.isRangeGridlinesVisible();
    boolean var15 = var7.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
    var7.mapDatasetToDomainAxis(15, 1);
    var7.configureDomainAxes();
    java.awt.geom.Point2D var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setQuadrantOrigin(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getMedianValue(0, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 0.5f, 0.0f, var4, 1.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.awt.geom.AffineTransform var10 = null;
    java.awt.RenderingHints var11 = null;
    java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
    var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
    int var14 = var4.getPieIndex();
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
    var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var28.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    org.jfree.chart.event.PlotChangeListener var34 = null;
    var33.removeChangeListener(var34);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
    java.awt.Paint var40 = var38.getTickMarkPaint();
    var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
    var4.setLabelShadowPaint(var40);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setInteriorGap(16.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     var16.setTextAntiAlias(false);
//     java.awt.Image var20 = null;
//     var16.setBackgroundImage(var20);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var16.draw(var22, var23);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     java.util.Date var1 = null;
//     org.jfree.chart.axis.SegmentedTimeline.Segment var2 = var0.getSegment(var1);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = null;
//     java.awt.Font var5 = null;
//     org.jfree.chart.axis.MarkerAxisBand var6 = new org.jfree.chart.axis.MarkerAxisBand(var0, 100.0d, 10.0d, 100.0d, 2.0d, var5);
//     org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     var6.addMarker(var9);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var6.draw(var11, var12, var13, 0.2d, 16.2d);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    java.awt.Paint var14 = var12.getTickMarkPaint();
    boolean var15 = var12.isAutoRange();
    var12.setVerticalTickLabels(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    int var3 = var0.getColumnIndex((java.lang.Comparable)1);
    int var5 = var0.getRowIndex((java.lang.Comparable)(byte)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.TaskSeries var7 = var0.getSeries(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var7.setRenderer(var8);
    java.awt.Paint var10 = var7.getNoDataMessagePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var12 = var11.getItemLabelAnchorOffset();
    var11.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
    boolean var16 = var7.equals((java.lang.Object)var11);
    org.jfree.chart.plot.SeriesRenderingOrder var17 = var7.getSeriesRenderingOrder();
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
    int var29 = var19.getPieIndex();
    org.jfree.chart.labels.PieToolTipGenerator var30 = null;
    var19.setToolTipGenerator(var30);
    java.awt.Paint var32 = var19.getShadowPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setQuadrantPaint((-10289251), var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.event.ChartChangeListener var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.addChangeListener(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var7.isRangeCrosshairVisible();
    java.awt.Paint var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRangeZeroBaselinePaint(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.IntervalMarker var10 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var14 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var15 = null;
//     java.awt.Rectangle var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     java.awt.geom.AffineTransform var18 = null;
//     java.awt.RenderingHints var19 = null;
//     java.awt.PaintContext var20 = var14.createContext(var15, var16, var17, var18, var19);
//     var12.setBaseSectionOutlinePaint((java.awt.Paint)var14);
//     int var22 = var12.getPieIndex();
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var25.createContext(var26, var27, var28, var29, var30);
//     var23.setBaseSectionOutlinePaint((java.awt.Paint)var25);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     var36.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, var39, var40);
//     org.jfree.chart.event.PlotChangeListener var42 = null;
//     var41.removeChangeListener(var42);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     var41.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var46);
//     java.awt.Paint var48 = var46.getTickMarkPaint();
//     var23.setSectionOutlinePaint((java.lang.Comparable)1L, var48);
//     var12.setLabelShadowPaint(var48);
//     var10.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var12);
//     org.jfree.chart.LegendItemCollection var52 = var12.getLegendItems();
//     boolean var53 = var7.equals((java.lang.Object)var12);
//     
//     // Checks the contract:  equals-hashcode on var7 and var41
//     assertTrue("Contract failed: equals-hashcode on var7 and var41", var7.equals(var41) ? var7.hashCode() == var41.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var41.", var7.equals(var41) == var41.equals(var7));
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.data.KeyToGroupMap var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToGroupMap(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var2 = var1.getObjectIcon();
    var0.setMinIcon(var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    var10.setUpperBound(0.0d);
    org.jfree.data.gantt.TaskSeriesCollection var13 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var4, var5, var6, var7, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.data.category.CategoryDataset)var13, (-1), (-10289251), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.labels.ItemLabelPosition var3 = null;
//     var2.setNegativeItemLabelPositionFallback(var3);
//     var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var12 = var11.getItemLabelAnchorOffset();
//     boolean var13 = var11.getBaseCreateEntities();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var16 = var11.getItemLabelGenerator(100, (-1));
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
//     var20.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var28, var29);
//     org.jfree.chart.plot.DrawingSupplier var31 = var30.getDrawingSupplier();
//     var20.addChangeListener((org.jfree.chart.event.AxisChangeListener)var30);
//     java.awt.geom.Rectangle2D var33 = null;
//     var11.drawRangeGridline(var17, var18, (org.jfree.chart.axis.ValueAxis)var20, var33, 1.0d);
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var38.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var36, (org.jfree.chart.axis.ValueAxis)var38, var41, var42);
//     org.jfree.chart.plot.DrawingSupplier var44 = var43.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var45 = var43.getDomainAxisLocation();
//     var43.mapDatasetToDomainAxis(15, 1);
//     org.jfree.chart.plot.IntervalMarker var51 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var52 = var51.clone();
//     org.jfree.chart.plot.RingPlot var53 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var55 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var56 = null;
//     java.awt.Rectangle var57 = null;
//     java.awt.geom.Rectangle2D var58 = null;
//     java.awt.geom.AffineTransform var59 = null;
//     java.awt.RenderingHints var60 = null;
//     java.awt.PaintContext var61 = var55.createContext(var56, var57, var58, var59, var60);
//     var53.setBaseSectionOutlinePaint((java.awt.Paint)var55);
//     int var63 = var53.getPieIndex();
//     org.jfree.chart.plot.RingPlot var64 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var66 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var67 = null;
//     java.awt.Rectangle var68 = null;
//     java.awt.geom.Rectangle2D var69 = null;
//     java.awt.geom.AffineTransform var70 = null;
//     java.awt.RenderingHints var71 = null;
//     java.awt.PaintContext var72 = var66.createContext(var67, var68, var69, var70, var71);
//     var64.setBaseSectionOutlinePaint((java.awt.Paint)var66);
//     org.jfree.data.xy.XYDataset var75 = null;
//     org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis("");
//     var77.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var80 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var81 = null;
//     org.jfree.chart.plot.XYPlot var82 = new org.jfree.chart.plot.XYPlot(var75, (org.jfree.chart.axis.ValueAxis)var77, var80, var81);
//     org.jfree.chart.event.PlotChangeListener var83 = null;
//     var82.removeChangeListener(var83);
//     org.jfree.chart.axis.NumberAxis var87 = new org.jfree.chart.axis.NumberAxis("");
//     var82.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var87);
//     java.awt.Paint var89 = var87.getTickMarkPaint();
//     var64.setSectionOutlinePaint((java.lang.Comparable)1L, var89);
//     var53.setLabelShadowPaint(var89);
//     var51.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var53);
//     var43.addDomainMarker((org.jfree.chart.plot.Marker)var51);
//     java.awt.geom.Rectangle2D var94 = null;
//     var2.drawRangeMarker(var9, var10, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.plot.Marker)var51, var94);
//     
//     // Checks the contract:  equals-hashcode on var30 and var82
//     assertTrue("Contract failed: equals-hashcode on var30 and var82", var30.equals(var82) ? var30.hashCode() == var82.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var30 and var82.", var30.equals(var82) == var82.equals(var30));
//     
//     // Checks the contract:  equals-hashcode on var31 and var44
//     assertTrue("Contract failed: equals-hashcode on var31 and var44", var31.equals(var44) ? var31.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var31
//     assertTrue("Contract failed: equals-hashcode on var44 and var31", var44.equals(var31) ? var44.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     var11.setRangeCrosshairLockedOnData(true);
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     var11.drawBackground(var16, var17);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 90.0d, var4, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var1 = var0.getInteriorGap();
    var0.setExplodePercent((java.lang.Comparable)16.25d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.25d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(16.2d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    int var3 = var0.getColumnIndex((java.lang.Comparable)1);
    int var5 = var0.getRowIndex((java.lang.Comparable)(byte)(-1));
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-10289251));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var0.getSeriesKey((-10289251));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var4 = var3.clone();
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var7 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var8 = null;
//     java.awt.Rectangle var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     java.awt.geom.AffineTransform var11 = null;
//     java.awt.RenderingHints var12 = null;
//     java.awt.PaintContext var13 = var7.createContext(var8, var9, var10, var11, var12);
//     var5.setBaseSectionOutlinePaint((java.awt.Paint)var7);
//     int var15 = var5.getPieIndex();
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     java.awt.geom.AffineTransform var22 = null;
//     java.awt.RenderingHints var23 = null;
//     java.awt.PaintContext var24 = var18.createContext(var19, var20, var21, var22, var23);
//     var16.setBaseSectionOutlinePaint((java.awt.Paint)var18);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var29.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var29, var32, var33);
//     org.jfree.chart.event.PlotChangeListener var35 = null;
//     var34.removeChangeListener(var35);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     var34.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var39);
//     java.awt.Paint var41 = var39.getTickMarkPaint();
//     var16.setSectionOutlinePaint((java.lang.Comparable)1L, var41);
//     var5.setLabelShadowPaint(var41);
//     var3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var5);
//     java.awt.Font var45 = var3.getLabelFont();
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var46 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var47 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     var46.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var47);
//     org.jfree.data.xy.XYDataset var49 = null;
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     var51.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var49, (org.jfree.chart.axis.ValueAxis)var51, var54, var55);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("");
//     var59.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var57, (org.jfree.chart.axis.ValueAxis)var59, var62, var63);
//     org.jfree.chart.event.PlotChangeListener var65 = null;
//     var64.removeChangeListener(var65);
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("");
//     var64.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var69);
//     java.awt.Paint var71 = var69.getTickMarkPaint();
//     var56.setRangeGridlinePaint(var71);
//     var46.setArtifactPaint(var71);
//     org.jfree.chart.block.LabelBlock var74 = new org.jfree.chart.block.LabelBlock("hi!", var45, var71);
//     
//     // Checks the contract:  equals-hashcode on var34 and var64
//     assertTrue("Contract failed: equals-hashcode on var34 and var64", var34.equals(var64) ? var34.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var34
//     assertTrue("Contract failed: equals-hashcode on var64 and var34", var64.equals(var34) ? var64.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(28, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var7.setRenderer(var8);
//     java.awt.Paint var10 = var7.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var12 = var11.getItemLabelAnchorOffset();
//     var11.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var16 = var7.equals((java.lang.Object)var11);
//     org.jfree.chart.plot.SeriesRenderingOrder var17 = var7.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var19 = var7.getDataset(10);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     var7.drawBackground(var20, var21);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    int var3 = var0.getColumnIndex((java.lang.Comparable)1);
    int var5 = var0.getRowIndex((java.lang.Comparable)(byte)(-1));
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-10289251));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var0.getPercentComplete(68, 28, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = var7.getFixedLegendItems();
    var7.setWeight(100);
    org.jfree.chart.plot.Plot var11 = var7.getRootPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setDatasetRenderingOrder(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
//     var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var11);
//     org.jfree.chart.axis.AxisLocation var26 = var7.getRangeAxisLocation((-10289251));
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var27 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     boolean var28 = var27.getFillBox();
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var31 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var32 = null;
//     java.awt.Rectangle var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     java.awt.geom.AffineTransform var35 = null;
//     java.awt.RenderingHints var36 = null;
//     java.awt.PaintContext var37 = var31.createContext(var32, var33, var34, var35, var36);
//     var29.setBaseSectionOutlinePaint((java.awt.Paint)var31);
//     int var39 = var29.getPieIndex();
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var42 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var43 = null;
//     java.awt.Rectangle var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     java.awt.geom.AffineTransform var46 = null;
//     java.awt.RenderingHints var47 = null;
//     java.awt.PaintContext var48 = var42.createContext(var43, var44, var45, var46, var47);
//     var40.setBaseSectionOutlinePaint((java.awt.Paint)var42);
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     var53.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var51, (org.jfree.chart.axis.ValueAxis)var53, var56, var57);
//     org.jfree.chart.event.PlotChangeListener var59 = null;
//     var58.removeChangeListener(var59);
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("");
//     var58.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var63);
//     java.awt.Paint var65 = var63.getTickMarkPaint();
//     var40.setSectionOutlinePaint((java.lang.Comparable)1L, var65);
//     var29.setLabelShadowPaint(var65);
//     var27.setArtifactPaint(var65);
//     var7.setDomainCrosshairPaint(var65);
//     
//     // Checks the contract:  equals-hashcode on var21 and var58
//     assertTrue("Contract failed: equals-hashcode on var21 and var58", var21.equals(var58) ? var21.hashCode() == var58.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var58.", var21.equals(var58) == var58.equals(var21));
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var4 = var2.getSeriesPaint((-1));
    boolean var6 = var2.equals((java.lang.Object)0.0d);
    java.lang.Boolean var8 = var2.getSeriesVisibleInLegend(2);
    boolean var9 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.urls.StandardCategoryURLGenerator var11 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
    java.lang.Object var12 = null;
    boolean var13 = var11.equals(var12);
    var2.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var11, false);
    java.awt.Stroke var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseStroke(var16, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = var7.getRendererForDataset(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var7.getInsets();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("");
//     boolean var15 = var12.equals((java.lang.Object)var14);
//     org.jfree.chart.util.UnitType var16 = var12.getUnitType();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     var18.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, var26, var27);
//     org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
//     var18.addChangeListener((org.jfree.chart.event.AxisChangeListener)var28);
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     double var33 = var32.getLowerBound();
//     float var34 = var32.getTickMarkOutsideLength();
//     boolean var35 = var32.isTickMarksVisible();
//     java.awt.Shape var36 = var32.getLeftArrow();
//     var18.setUpArrow(var36);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var39 = null;
//     var38.setBaseItemLabelGenerator(var39, true);
//     boolean var42 = var38.getBaseSeriesVisible();
//     var38.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var49 = var48.getBasePaint();
//     var38.setSeriesFillPaint(10, var49, false);
//     org.jfree.chart.title.LegendGraphic var52 = new org.jfree.chart.title.LegendGraphic(var36, var49);
//     boolean var53 = var16.equals((java.lang.Object)var36);
//     
//     // Checks the contract:  equals-hashcode on var7 and var28
//     assertTrue("Contract failed: equals-hashcode on var7 and var28", var7.equals(var28) ? var7.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var7
//     assertTrue("Contract failed: equals-hashcode on var28 and var7", var28.equals(var7) ? var28.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), (-1.0f), 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-524308));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    var12.resizeRange(100.0d);
    org.jfree.chart.event.AxisChangeEvent var16 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var12);
    java.util.EventListener var17 = null;
    boolean var18 = var12.hasListener(var17);
    boolean var19 = var12.isVerticalTickLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
//     var7.mapDatasetToDomainAxis(15, 1);
//     org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var19 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     java.awt.geom.AffineTransform var23 = null;
//     java.awt.RenderingHints var24 = null;
//     java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
//     var17.setBaseSectionOutlinePaint((java.awt.Paint)var19);
//     int var27 = var17.getPieIndex();
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var30 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var31 = null;
//     java.awt.Rectangle var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     java.awt.geom.AffineTransform var34 = null;
//     java.awt.RenderingHints var35 = null;
//     java.awt.PaintContext var36 = var30.createContext(var31, var32, var33, var34, var35);
//     var28.setBaseSectionOutlinePaint((java.awt.Paint)var30);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     var41.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var41, var44, var45);
//     org.jfree.chart.event.PlotChangeListener var47 = null;
//     var46.removeChangeListener(var47);
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     var46.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var51);
//     java.awt.Paint var53 = var51.getTickMarkPaint();
//     var28.setSectionOutlinePaint((java.lang.Comparable)1L, var53);
//     var17.setLabelShadowPaint(var53);
//     var15.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var17);
//     var7.addDomainMarker((org.jfree.chart.plot.Marker)var15);
//     org.jfree.data.xy.XYDataset var58 = null;
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("");
//     var60.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var58, (org.jfree.chart.axis.ValueAxis)var60, var63, var64);
//     org.jfree.chart.event.PlotChangeListener var66 = null;
//     var65.removeChangeListener(var66);
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("");
//     var65.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var70);
//     java.awt.Paint var72 = var70.getTickMarkPaint();
//     var7.setDomainAxis((org.jfree.chart.axis.ValueAxis)var70);
//     
//     // Checks the contract:  equals-hashcode on var46 and var65
//     assertTrue("Contract failed: equals-hashcode on var46 and var65", var46.equals(var65) ? var46.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var46
//     assertTrue("Contract failed: equals-hashcode on var65 and var46", var65.equals(var46) ? var65.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     java.util.Date var1 = null;
//     var0.addException(var1);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    var16.setTextAntiAlias(false);
    java.awt.Image var20 = null;
    var16.setBackgroundImage(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var24 = var16.createBufferedImage(68, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var7);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     boolean var1 = var0.getFillBox();
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var4 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var5 = null;
//     java.awt.Rectangle var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.AffineTransform var8 = null;
//     java.awt.RenderingHints var9 = null;
//     java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
//     var2.setBaseSectionOutlinePaint((java.awt.Paint)var4);
//     int var12 = var2.getPieIndex();
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var16 = null;
//     java.awt.Rectangle var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     java.awt.geom.AffineTransform var19 = null;
//     java.awt.RenderingHints var20 = null;
//     java.awt.PaintContext var21 = var15.createContext(var16, var17, var18, var19, var20);
//     var13.setBaseSectionOutlinePaint((java.awt.Paint)var15);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
//     var26.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, var29, var30);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var31.removeChangeListener(var32);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     var31.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var36);
//     java.awt.Paint var38 = var36.getTickMarkPaint();
//     var13.setSectionOutlinePaint((java.lang.Comparable)1L, var38);
//     var2.setLabelShadowPaint(var38);
//     var0.setArtifactPaint(var38);
//     java.awt.Paint var44 = var0.getItemPaint((-10289251), 68);
//     java.awt.Font var46 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var48 = null;
//     var47.setBaseItemLabelGenerator(var48, true);
//     boolean var51 = var47.getBaseSeriesVisible();
//     var47.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var57 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var58 = var57.getBasePaint();
//     var47.setSeriesFillPaint(10, var58, false);
//     org.jfree.chart.text.TextMeasurer var63 = null;
//     org.jfree.chart.text.TextBlock var64 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, var58, (-1.0f), 10, var63);
//     var0.setArtifactPaint(var58);
//     org.jfree.chart.axis.NumberAxis3D var67 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     var67.resizeRange(0.2d);
//     var67.setLabelToolTip("hi!");
//     org.jfree.chart.renderer.category.IntervalBarRenderer var72 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var74 = var72.getSeriesPaint((-1));
//     java.awt.Font var77 = var72.getItemLabelFont(1, 1);
//     var67.setLabelFont(var77);
//     var0.setBaseItemLabelFont(var77, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var72 and var47.", var72.equals(var47) == var47.equals(var72));
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     var16.setTextAntiAlias(false);
//     java.awt.Image var20 = null;
//     var16.setBackgroundImage(var20);
//     java.lang.Object var22 = var16.clone();
//     org.jfree.chart.title.LegendTitle var24 = var16.getLegend(10);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     int var27 = var26.getPassCount();
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, var33, var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var37 = var35.getDomainAxisLocation();
//     boolean var38 = var26.equals((java.lang.Object)var35);
//     boolean var39 = var16.equals((java.lang.Object)var35);
//     
//     // Checks the contract:  equals-hashcode on var11 and var35
//     assertTrue("Contract failed: equals-hashcode on var11 and var35", var11.equals(var35) ? var11.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var11
//     assertTrue("Contract failed: equals-hashcode on var35 and var11", var35.equals(var11) ? var35.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var36
//     assertTrue("Contract failed: equals-hashcode on var12 and var36", var12.equals(var36) ? var12.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var12
//     assertTrue("Contract failed: equals-hashcode on var36 and var12", var36.equals(var12) ? var36.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.awt.Paint var8 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var11 = var10.getItemLabelAnchorOffset();
    boolean var12 = var10.getBaseCreateEntities();
    org.jfree.chart.labels.CategoryItemLabelGenerator var15 = var10.getItemLabelGenerator(100, (-1));
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = null;
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
    var19.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    var24.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, var27, var28);
    org.jfree.chart.plot.DrawingSupplier var30 = var29.getDrawingSupplier();
    var19.addChangeListener((org.jfree.chart.event.AxisChangeListener)var29);
    java.awt.geom.Rectangle2D var32 = null;
    var10.drawRangeGridline(var16, var17, (org.jfree.chart.axis.ValueAxis)var19, var32, 1.0d);
    java.awt.Paint var36 = var10.lookupSeriesOutlinePaint(0);
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
    var39.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, var42, var43);
    org.jfree.chart.axis.AxisSpace var45 = var44.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var49 = var48.getBasePaint();
    var44.setDomainZeroBaselinePaint(var49);
    java.awt.Stroke var51 = var44.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
    var54.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var57 = null;
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("");
    var59.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
    org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var57, (org.jfree.chart.axis.ValueAxis)var59, var62, var63);
    org.jfree.chart.plot.DrawingSupplier var65 = var64.getDrawingSupplier();
    var54.addChangeListener((org.jfree.chart.event.AxisChangeListener)var64);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("");
    double var69 = var68.getLowerBound();
    float var70 = var68.getTickMarkOutsideLength();
    boolean var71 = var68.isTickMarksVisible();
    java.awt.Shape var72 = var68.getLeftArrow();
    var54.setUpArrow(var72);
    org.jfree.chart.renderer.category.IntervalBarRenderer var74 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var76 = var74.getSeriesPaint((-1));
    java.awt.Font var79 = var74.getItemLabelFont(1, 1);
    org.jfree.chart.labels.ItemLabelPosition var80 = new org.jfree.chart.labels.ItemLabelPosition();
    var74.setBasePositiveItemLabelPosition(var80);
    java.awt.Stroke var84 = var74.getItemOutlineStroke(28, 0);
    org.jfree.data.xy.XYDataset var85 = null;
    org.jfree.chart.axis.NumberAxis var87 = new org.jfree.chart.axis.NumberAxis("");
    var87.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var90 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var91 = null;
    org.jfree.chart.plot.XYPlot var92 = new org.jfree.chart.plot.XYPlot(var85, (org.jfree.chart.axis.ValueAxis)var87, var90, var91);
    org.jfree.chart.renderer.xy.XYItemRenderer var93 = null;
    var92.setRenderer(var93);
    java.awt.Paint var95 = var92.getDomainGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var96 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=0,b=0]", "java.awt.Color[r=0,g=0,b=0]", "", "XY Plot", true, var6, false, var8, true, var36, var51, false, var72, var84, var95);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeEvent var8 = null;
    var7.notifyListeners(var8);
    org.jfree.data.general.DatasetChangeEvent var10 = null;
    var7.datasetChanged(var10);
    var7.mapDatasetToRangeAxis((-1), 100);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.util.TableOrder var3 = var0.getDataExtractOrder();
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var5 = var4.getDataExtractOrder();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPieChart(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
//     org.jfree.chart.event.PlotChangeListener var18 = null;
//     var17.removeChangeListener(var18);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var22);
//     var22.resizeRange(100.0d);
//     boolean var26 = var22.isAutoTickUnitSelection();
//     var7.setDomainAxis((org.jfree.chart.axis.ValueAxis)var22);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, var33, var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     org.jfree.chart.axis.AxisSpace var37 = var35.getFixedDomainAxisSpace();
//     org.jfree.data.xy.XYDataset var38 = null;
//     var35.setDataset(var38);
//     int var40 = var35.getDatasetCount();
//     boolean var41 = var22.hasListener((java.util.EventListener)var35);
//     
//     // Checks the contract:  equals-hashcode on var35 and var17
//     assertTrue("Contract failed: equals-hashcode on var35 and var17", var35.equals(var17) ? var35.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var17.", var35.equals(var17) == var17.equals(var35));
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     var12.resizeRange(100.0d);
//     org.jfree.chart.axis.TickUnitSource var16 = null;
//     var12.setStandardTickUnits(var16);
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var22.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, var25, var26);
//     org.jfree.chart.event.PlotChangeListener var28 = null;
//     var27.removeChangeListener(var28);
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var27.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var32);
//     boolean var34 = var27.isDomainCrosshairVisible();
//     org.jfree.chart.util.RectangleEdge var36 = var27.getDomainAxisEdge(68);
//     double var37 = var12.valueToJava2D(0.0d, var19, var36);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    java.awt.Font var5 = null;
    org.jfree.chart.axis.MarkerAxisBand var6 = new org.jfree.chart.axis.MarkerAxisBand(var0, 100.0d, 10.0d, 100.0d, 2.0d, var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    var6.draw(var7, var8, var9, 1.0d, 16.25d);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     var0.setBaseCreateEntities(true, false);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var0.drawBackground(var4, var5, var6);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var16 = var14.getSeriesPaint((-1));
    java.awt.Font var19 = var14.getItemLabelFont(1, 1);
    var12.setTickLabelFont(var19);
    org.jfree.chart.util.RectangleInsets var21 = var12.getLabelInsets();
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.LengthAdjustmentType var23 = null;
    org.jfree.chart.util.LengthAdjustmentType var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var25 = var21.createAdjustedRectangle(var22, var23, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("java.awt.Color[r=0,g=0,b=0]", var1, 0.0f, 10.0f, var4);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     var3.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var6, var7);
//     org.jfree.chart.event.PlotChangeListener var9 = null;
//     var8.removeChangeListener(var9);
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     var8.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var13);
//     boolean var15 = var8.isDomainCrosshairVisible();
//     org.jfree.chart.util.RectangleEdge var17 = var8.getDomainAxisEdge(68);
//     double var18 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var17);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
//     var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
//     int var18 = var8.getPieIndex();
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.awt.geom.AffineTransform var25 = null;
//     java.awt.RenderingHints var26 = null;
//     java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
//     var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
//     java.awt.Paint var44 = var42.getTickMarkPaint();
//     var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
//     var8.setLabelShadowPaint(var44);
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var8.setLegendLabelURLGenerator(var47);
//     var8.setOuterSeparatorExtension(0.2d);
//     boolean var51 = var7.equals((java.lang.Object)var8);
//     java.lang.Number var54 = var7.getEndValue((java.lang.Comparable)(byte)(-1), (java.lang.Comparable)2.0f);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = var7.getRendererForDataset(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var7.getInsets();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var7.handleClick((-1), 0, var15);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var1);
//     org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.util.HorizontalAlignment var4 = null;
//     org.jfree.chart.util.VerticalAlignment var5 = null;
//     org.jfree.chart.block.FlowArrangement var8 = new org.jfree.chart.block.FlowArrangement(var4, var5, 2.0d, 10.0d);
//     org.jfree.data.general.Dataset var9 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var8, var9, (java.lang.Comparable)1.0f);
//     var11.setToolTipText("hi!");
//     java.lang.Object var14 = var11.clone();
//     java.util.List var15 = var11.getBlocks();
//     var3.setExceptionSegments(var15);
//     boolean var17 = var1.equals((java.lang.Object)var3);
//     java.util.Date var18 = null;
//     long var19 = var3.toTimelineValue(var18);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, var10, var11);
//     org.jfree.chart.event.PlotChangeListener var13 = null;
//     var12.removeChangeListener(var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var17);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var21 = var19.getSeriesPaint((-1));
//     java.awt.Font var24 = var19.getItemLabelFont(1, 1);
//     var17.setTickLabelFont(var24);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var17.valueToJava2D((-1.0d), var27, var28);
//     java.awt.geom.Rectangle2D var30 = null;
//     var2.drawRangeGridline(var3, var4, (org.jfree.chart.axis.ValueAxis)var17, var30, 0.0d);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     double var16 = var15.getLowerBound();
//     float var17 = var15.getTickMarkOutsideLength();
//     boolean var18 = var15.isTickMarksVisible();
//     java.awt.Shape var19 = var15.getLeftArrow();
//     var1.setUpArrow(var19);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = null;
//     var21.setBaseItemLabelGenerator(var22, true);
//     boolean var25 = var21.getBaseSeriesVisible();
//     var21.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var32 = var31.getBasePaint();
//     var21.setSeriesFillPaint(10, var32, false);
//     org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic(var19, var32);
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     java.awt.Shape var38 = var37.getRightArrow();
//     var35.setShape(var38);
//     java.awt.Graphics2D var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("");
//     var43.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var48.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var52 = null;
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot(var46, (org.jfree.chart.axis.ValueAxis)var48, var51, var52);
//     org.jfree.chart.plot.DrawingSupplier var54 = var53.getDrawingSupplier();
//     var43.addChangeListener((org.jfree.chart.event.AxisChangeListener)var53);
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     double var58 = var57.getLowerBound();
//     float var59 = var57.getTickMarkOutsideLength();
//     boolean var60 = var57.isTickMarksVisible();
//     java.awt.Shape var61 = var57.getLeftArrow();
//     var43.setUpArrow(var61);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var63 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var64 = null;
//     var63.setBaseItemLabelGenerator(var64, true);
//     boolean var67 = var63.getBaseSeriesVisible();
//     var63.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var73 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var74 = var73.getBasePaint();
//     var63.setSeriesFillPaint(10, var74, false);
//     org.jfree.chart.title.LegendGraphic var77 = new org.jfree.chart.title.LegendGraphic(var61, var74);
//     java.lang.Object var78 = var35.draw(var40, var41, (java.lang.Object)var61);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Other", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     var1.removeFragment(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.text.TextAnchor var8 = null;
//     var3.draw(var5, 0.0f, 0.0f, var8, (-1.0f), (-1.0f), 0.2d);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(var0, var1);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var2 = var0.getSeriesPaint((-1));
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    var7.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, var10, var11);
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    var12.setRenderer(var13);
    java.awt.Paint var15 = var12.getNoDataMessagePaint();
    var4.setLabelOutlinePaint(var15);
    java.awt.Stroke var17 = var4.getLabelLinkStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-524308), var17, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Paint var3 = var1.getSeriesItemLabelPaint(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 2.0d, 10.0d);
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)1.0f);
//     java.lang.String var8 = var7.getID();
//     double var9 = var7.getWidth();
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var19.removeChangeListener(var20);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = var19.getRendererForDataset(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var19.getInsets();
//     org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine("");
//     boolean var27 = var24.equals((java.lang.Object)var26);
//     double var29 = var24.trimWidth(0.2d);
//     java.lang.Object var30 = var7.draw(var10, var11, (java.lang.Object)var24);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
    var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
    int var18 = var8.getPieIndex();
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
    var32.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
    org.jfree.chart.event.PlotChangeListener var38 = null;
    var37.removeChangeListener(var38);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
    java.awt.Paint var44 = var42.getTickMarkPaint();
    var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
    var8.setLabelShadowPaint(var44);
    org.jfree.chart.urls.PieURLGenerator var47 = null;
    var8.setLegendLabelURLGenerator(var47);
    var8.setOuterSeparatorExtension(0.2d);
    boolean var51 = var7.equals((java.lang.Object)var8);
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
    var54.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var57 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
    org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, var57, var58);
    org.jfree.chart.event.PlotChangeListener var60 = null;
    var59.removeChangeListener(var60);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("");
    var59.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var64);
    var64.resizeRange(100.0d);
    org.jfree.chart.event.AxisChangeEvent var68 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var64);
    org.jfree.chart.event.ChartChangeEventType var69 = var68.getType();
    java.lang.Object var70 = var68.getSource();
    var8.axisChanged(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 10.0f, 100.0f, var4);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var3 = var1.getRowIndex((java.lang.Comparable)1);
    int var5 = var1.getRowIndex((java.lang.Comparable)false);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, 16.2d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var10 = var0.generateToolTip((org.jfree.data.category.CategoryDataset)var1, 100, 68);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var16 = var14.getSeriesPaint((-1));
    java.awt.Font var19 = var14.getItemLabelFont(1, 1);
    var12.setTickLabelFont(var19);
    org.jfree.chart.util.RectangleInsets var21 = var12.getLabelInsets();
    var12.resizeRange(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("");
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var5.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, var8, var9);
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     var10.setRenderer(var11);
//     java.awt.Paint var13 = var10.getNoDataMessagePaint();
//     var2.setLabelOutlinePaint(var13);
//     java.awt.Stroke var15 = var2.getLabelLinkStroke();
//     boolean var16 = var1.equals((java.lang.Object)var2);
//     double var17 = var2.getMaximumExplodePercent();
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var2 = var1.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
//     var1.setBaseToolTipGenerator(var3);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
//     var1.setLegendItemURLGenerator(var5);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var10 = var9.getBasePaint();
//     var1.setBasePaint(var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var19.removeChangeListener(var20);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     var19.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var24);
//     java.awt.Paint var26 = var24.getTickMarkPaint();
//     boolean var27 = var24.isAutoRange();
//     java.awt.Stroke var28 = var24.getTickMarkStroke();
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(32.2d, var10, var28);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var31 = var30.getItemLabelAnchorOffset();
//     boolean var32 = var30.getBaseCreateEntities();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var30.getItemLabelGenerator(100, (-1));
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var40 = var39.getBasePaint();
//     var30.setSeriesFillPaint(0, var40);
//     boolean var42 = var29.equals((java.lang.Object)var40);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var30.", var1.equals(var30) == var30.equals(var1));
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    java.awt.Font var2 = null;
    java.awt.Paint var3 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 100.0f, var5);
    java.util.List var7 = var6.getLines();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var7, (java.lang.Comparable)(short)10, (java.lang.Comparable)1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 2.0f, 10.0f, var4);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    double var3 = var0.getLimit();
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var5 = var4.getGroup();
    int var7 = var4.getColumnIndex((java.lang.Comparable)1);
    int var9 = var4.getRowIndex((java.lang.Comparable)(byte)(-1));
    var0.setDataset((org.jfree.data.category.CategoryDataset)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var4.getSubIntervalCount((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(var0, var1);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var2 = null;
    java.awt.Rectangle var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    java.awt.geom.AffineTransform var5 = null;
    java.awt.RenderingHints var6 = null;
    java.awt.PaintContext var7 = var1.createContext(var2, var3, var4, var5, var6);
    float[] var11 = new float[] { 0.0f, 0.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var12 = var1.getComponents(var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("XY Plot", var1, var2);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
//     var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
//     int var18 = var8.getPieIndex();
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.awt.geom.AffineTransform var25 = null;
//     java.awt.RenderingHints var26 = null;
//     java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
//     var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
//     java.awt.Paint var44 = var42.getTickMarkPaint();
//     var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
//     var8.setLabelShadowPaint(var44);
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var8.setLegendLabelURLGenerator(var47);
//     var8.setOuterSeparatorExtension(0.2d);
//     boolean var51 = var7.equals((java.lang.Object)var8);
//     int var53 = var7.getRowIndex((java.lang.Comparable)"black");
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var2 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    boolean var3 = var2.getFillBox();
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.awt.geom.AffineTransform var10 = null;
    java.awt.RenderingHints var11 = null;
    java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
    var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
    int var14 = var4.getPieIndex();
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
    var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var28.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    org.jfree.chart.event.PlotChangeListener var34 = null;
    var33.removeChangeListener(var34);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
    java.awt.Paint var40 = var38.getTickMarkPaint();
    var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
    var4.setLabelShadowPaint(var40);
    var2.setArtifactPaint(var40);
    java.awt.Paint var46 = var2.getItemPaint((-10289251), 68);
    var1.setGroupPaint(var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic(var0, var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var7, true);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.RendererChangeEvent var1 = new org.jfree.chart.event.RendererChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 32.2d, var4, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     double var16 = var15.getLowerBound();
//     float var17 = var15.getTickMarkOutsideLength();
//     boolean var18 = var15.isTickMarksVisible();
//     java.awt.Shape var19 = var15.getLeftArrow();
//     var1.setUpArrow(var19);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = null;
//     var21.setBaseItemLabelGenerator(var22, true);
//     boolean var25 = var21.getBaseSeriesVisible();
//     var21.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var32 = var31.getBasePaint();
//     var21.setSeriesFillPaint(10, var32, false);
//     org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic(var19, var32);
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     var39.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, var42, var43);
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     var44.setRenderer(var45);
//     java.awt.Paint var47 = var44.getNoDataMessagePaint();
//     var36.setLabelOutlinePaint(var47);
//     var35.setLinePaint(var47);
//     
//     // Checks the contract:  equals-hashcode on var11 and var44
//     assertTrue("Contract failed: equals-hashcode on var11 and var44", var11.equals(var44) ? var11.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var11
//     assertTrue("Contract failed: equals-hashcode on var44 and var11", var44.equals(var11) ? var44.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = var7.getRendererForDataset(var10);
    org.jfree.chart.util.RectangleInsets var12 = var7.getInsets();
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    var16.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
    org.jfree.chart.event.PlotChangeListener var22 = null;
    var21.removeChangeListener(var22);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    var21.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var26);
    var26.resizeRange(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRangeAxis((-10289251), (org.jfree.chart.axis.ValueAxis)var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var3 = var2.getDataExtractOrder();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Paint var5 = var4.getBorderPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("XY Plot", var1, var5, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.plot.CategoryMarker var6 = null;
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     var8.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     var13.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, var16, var17);
//     org.jfree.chart.plot.DrawingSupplier var19 = var18.getDrawingSupplier();
//     var8.addChangeListener((org.jfree.chart.event.AxisChangeListener)var18);
//     org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var22 = var21.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
//     var18.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var23);
//     var23.setTextAntiAlias(false);
//     java.awt.Image var27 = null;
//     var23.setBackgroundImage(var27);
//     java.lang.Object var29 = var23.clone();
//     org.jfree.chart.entity.EntityCollection var32 = null;
//     org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
//     var23.handleClick(0, 10, var33);
//     java.awt.geom.Rectangle2D var35 = var33.getChartArea();
//     var2.drawDomainMarker(var3, var4, var5, var6, var35);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
    org.jfree.chart.plot.PlotOrientation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var11 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var1 = var0.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
//     var0.setSeriesItemLabelGenerator(10, var3, false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var13 = var11.getSeriesPaint((-1));
//     java.awt.Font var16 = var11.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var17 = new org.jfree.chart.labels.ItemLabelPosition();
//     var11.setBasePositiveItemLabelPosition(var17);
//     var9.setSeriesPositiveItemLabelPosition(10, var17);
//     var0.setSeriesPositiveItemLabelPosition(0, var17);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var0.", var11.equals(var0) == var0.equals(var11));
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     boolean var18 = var16.getAntiAlias();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var19 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var21 = var19.equals((java.lang.Object)2);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 2.0d, false);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
//     var38.resizeRange(100.0d);
//     java.awt.Paint var42 = var38.getTickMarkPaint();
//     var25.setBaseFillPaint(var42, true);
//     var19.setBasePaint(var42, false);
//     var16.setBackgroundPaint(var42);
//     
//     // Checks the contract:  equals-hashcode on var11 and var33
//     assertTrue("Contract failed: equals-hashcode on var11 and var33", var11.equals(var33) ? var11.hashCode() == var33.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var33.", var11.equals(var33) == var33.equals(var11));
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var4 = null;
    org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 100.0f, var4);
    java.util.List var6 = var5.getLines();
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setLineAlignment(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.entity.EntityCollection var0 = null;
//     org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var3
//     assertTrue("Contract failed: equals-hashcode on var2 and var3", var2.equals(var3) ? var2.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var2
//     assertTrue("Contract failed: equals-hashcode on var3 and var2", var3.equals(var2) ? var3.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     var0.peg(var1);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var7.getDomainMarkers(var10);
//     float var12 = var7.getBackgroundImageAlpha();
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var15.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, var18, var19);
//     org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var22 = var20.getDomainAxisLocation();
//     var7.setRangeAxisLocation(var22);
//     
//     // Checks the contract:  equals-hashcode on var7 and var20
//     assertTrue("Contract failed: equals-hashcode on var7 and var20", var7.equals(var20) ? var7.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var7
//     assertTrue("Contract failed: equals-hashcode on var20 and var7", var20.equals(var7) ? var20.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     org.jfree.chart.util.RectangleInsets var9 = var7.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
//     org.jfree.chart.plot.MultiplePiePlot var24 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var25 = var24.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     var21.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
//     var26.setTextAntiAlias(false);
//     java.awt.Image var30 = null;
//     var26.setBackgroundImage(var30);
//     java.lang.Object var32 = var26.clone();
//     org.jfree.chart.entity.EntityCollection var35 = null;
//     org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo(var35);
//     var26.handleClick(0, 10, var36);
//     java.awt.geom.Rectangle2D var38 = var36.getChartArea();
//     org.jfree.chart.util.LengthAdjustmentType var39 = null;
//     org.jfree.chart.util.LengthAdjustmentType var40 = null;
//     java.awt.geom.Rectangle2D var41 = var9.createAdjustedRectangle(var38, var39, var40);
//     
//     // Checks the contract:  equals-hashcode on var7 and var21
//     assertTrue("Contract failed: equals-hashcode on var7 and var21", var7.equals(var21) ? var7.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var7
//     assertTrue("Contract failed: equals-hashcode on var21 and var7", var21.equals(var7) ? var21.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var22
//     assertTrue("Contract failed: equals-hashcode on var8 and var22", var8.equals(var22) ? var8.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var8
//     assertTrue("Contract failed: equals-hashcode on var22 and var8", var22.equals(var8) ? var22.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
    var7.mapDatasetToDomainAxis(15, 1);
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var19 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var20 = null;
    java.awt.Rectangle var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    java.awt.geom.AffineTransform var23 = null;
    java.awt.RenderingHints var24 = null;
    java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
    var17.setBaseSectionOutlinePaint((java.awt.Paint)var19);
    int var27 = var17.getPieIndex();
    org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var30 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var31 = null;
    java.awt.Rectangle var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    java.awt.geom.AffineTransform var34 = null;
    java.awt.RenderingHints var35 = null;
    java.awt.PaintContext var36 = var30.createContext(var31, var32, var33, var34, var35);
    var28.setBaseSectionOutlinePaint((java.awt.Paint)var30);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
    var41.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var41, var44, var45);
    org.jfree.chart.event.PlotChangeListener var47 = null;
    var46.removeChangeListener(var47);
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
    var46.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var51);
    java.awt.Paint var53 = var51.getTickMarkPaint();
    var28.setSectionOutlinePaint((java.lang.Comparable)1L, var53);
    var17.setLabelShadowPaint(var53);
    var15.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var17);
    var7.addDomainMarker((org.jfree.chart.plot.Marker)var15);
    org.jfree.chart.util.RectangleInsets var58 = var15.getLabelOffset();
    double var60 = var58.calculateBottomOutset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 3.0d);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var14, var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var6.addChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var20 = var19.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     var16.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var21);
//     var21.setTextAntiAlias(false);
//     java.awt.Image var25 = null;
//     var21.setBackgroundImage(var25);
//     java.lang.Object var27 = var21.clone();
//     org.jfree.chart.entity.EntityCollection var30 = null;
//     org.jfree.chart.ChartRenderingInfo var31 = new org.jfree.chart.ChartRenderingInfo(var30);
//     var21.handleClick(0, 10, var31);
//     java.awt.geom.Rectangle2D var33 = var31.getChartArea();
//     var2.drawDomainGridline(var3, var4, var33, 10.0d);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("black");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var7.setRenderer(var8);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    var13.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, var16, var17);
    org.jfree.chart.event.PlotChangeListener var19 = null;
    var18.removeChangeListener(var19);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    var18.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var23);
    org.jfree.chart.renderer.category.IntervalBarRenderer var25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var27 = var25.getSeriesPaint((-1));
    java.awt.Font var30 = var25.getItemLabelFont(1, 1);
    var23.setTickLabelFont(var30);
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var23.valueToJava2D((-1.0d), var33, var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRangeAxis((-10289251), (org.jfree.chart.axis.ValueAxis)var23, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, (-15.8d), 1.0f, 1.0f);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-10289251));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    boolean var2 = var0.getBaseCreateEntities();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var0.getItemLabelGenerator(100, (-1));
    org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var10 = var9.getBasePaint();
    var0.setSeriesFillPaint(0, var10);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getNegativeItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var7.getValue(2, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=0,b=0]", "Other", "", var3, "java.awt.Color[r=0,g=0,b=0]", "java.awt.Color[r=0,g=0,b=0]", "Other");

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, var20, var21);
//     org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
//     var12.addChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
//     org.jfree.chart.plot.MultiplePiePlot var25 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var26 = var25.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
//     var22.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var27);
//     var27.setTextAntiAlias(false);
//     java.awt.Image var31 = null;
//     var27.setBackgroundImage(var31);
//     java.lang.Object var33 = var27.clone();
//     org.jfree.chart.entity.EntityCollection var36 = null;
//     org.jfree.chart.ChartRenderingInfo var37 = new org.jfree.chart.ChartRenderingInfo(var36);
//     var27.handleClick(0, 10, var37);
//     java.awt.geom.Rectangle2D var39 = var37.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     var7.drawAnnotations(var10, var39, var40);
//     
//     // Checks the contract:  equals-hashcode on var7 and var22
//     assertTrue("Contract failed: equals-hashcode on var7 and var22", var7.equals(var22) ? var7.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var7
//     assertTrue("Contract failed: equals-hashcode on var22 and var7", var22.equals(var7) ? var22.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var6 = var4.getSeriesPaint((-1));
    java.awt.Font var9 = var4.getItemLabelFont(1, 1);
    org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
    var4.setBasePositiveItemLabelPosition(var10);
    var2.setSeriesPositiveItemLabelPosition(10, var10);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var15.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, var18, var19);
    org.jfree.chart.event.PlotChangeListener var21 = null;
    var20.removeChangeListener(var21);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    var20.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var27 = var25.getTickMarkPaint();
    boolean var28 = var25.isAutoRange();
    java.awt.Stroke var29 = var25.getTickMarkStroke();
    boolean var30 = var2.equals((java.lang.Object)var29);
    java.awt.Paint var32 = var2.lookupSeriesOutlinePaint(15);
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    var36.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
    var41.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var41, var44, var45);
    org.jfree.chart.plot.DrawingSupplier var47 = var46.getDrawingSupplier();
    var36.addChangeListener((org.jfree.chart.event.AxisChangeListener)var46);
    org.jfree.chart.plot.MultiplePiePlot var49 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var50 = var49.getDataExtractOrder();
    org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var49);
    var46.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var51);
    var51.setTextAntiAlias(false);
    java.awt.Image var55 = null;
    var51.setBackgroundImage(var55);
    java.lang.Object var57 = var51.clone();
    org.jfree.chart.entity.EntityCollection var60 = null;
    org.jfree.chart.ChartRenderingInfo var61 = new org.jfree.chart.ChartRenderingInfo(var60);
    var51.handleClick(0, 10, var61);
    java.awt.geom.Rectangle2D var63 = var61.getChartArea();
    org.jfree.chart.plot.CategoryPlot var64 = null;
    org.jfree.chart.axis.CategoryAxis var65 = null;
    org.jfree.data.xy.XYDataset var66 = null;
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("");
    var68.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var71 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
    org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var66, (org.jfree.chart.axis.ValueAxis)var68, var71, var72);
    org.jfree.chart.event.PlotChangeListener var74 = null;
    var73.removeChangeListener(var74);
    org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis("");
    var73.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var78);
    var78.resizeRange(100.0d);
    boolean var82 = var78.isAutoTickUnitSelection();
    org.jfree.data.gantt.TaskSeriesCollection var83 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var85 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var83, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.drawItem(var33, var34, var63, var64, var65, (org.jfree.chart.axis.ValueAxis)var78, (org.jfree.data.category.CategoryDataset)var83, 0, 10, (-524308));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     boolean var1 = var0.getFillBox();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
//     org.jfree.chart.event.PlotChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var19);
//     var19.resizeRange(100.0d);
//     java.awt.Paint var23 = var19.getTickMarkPaint();
//     org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 2.0d);
//     var19.setDefaultAutoRange(var26);
//     java.lang.String var28 = var19.getLabelToolTip();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     var0.drawVerticalItem(var2, var3, var4, var5, var6, (org.jfree.chart.axis.ValueAxis)var19, var29, 0, 68);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     boolean var14 = var7.isDomainCrosshairVisible();
//     var7.configureRangeAxes();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var22.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, var25, var26);
//     org.jfree.chart.plot.DrawingSupplier var28 = var27.getDrawingSupplier();
//     var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var27);
//     org.jfree.chart.plot.MultiplePiePlot var30 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var31 = var30.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var30);
//     var27.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var32);
//     var32.setTextAntiAlias(false);
//     java.awt.Image var36 = null;
//     var32.setBackgroundImage(var36);
//     float var38 = var32.getBackgroundImageAlpha();
//     org.jfree.chart.event.ChartProgressListener var39 = null;
//     var32.removeProgressListener(var39);
//     var7.addChangeListener((org.jfree.chart.event.PlotChangeListener)var32);
//     
//     // Checks the contract:  equals-hashcode on var27 and var7
//     assertTrue("Contract failed: equals-hashcode on var27 and var7", var27.equals(var7) ? var27.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var7.", var27.equals(var7) == var7.equals(var27));
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     int var2 = var1.getPassCount();
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var5.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, var8, var9);
//     org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var12 = var10.getDomainAxisLocation();
//     boolean var13 = var1.equals((java.lang.Object)var10);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var10.setDrawingSupplier(var22);
//     
//     // Checks the contract:  equals-hashcode on var10 and var21
//     assertTrue("Contract failed: equals-hashcode on var10 and var21", var10.equals(var21) ? var10.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var10
//     assertTrue("Contract failed: equals-hashcode on var21 and var10", var21.equals(var10) ? var21.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var22
//     assertTrue("Contract failed: equals-hashcode on var11 and var22", var11.equals(var22) ? var11.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var11
//     assertTrue("Contract failed: equals-hashcode on var22 and var11", var22.equals(var11) ? var22.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.toTimelineValue(100L);
//     var0.addException((-1L));
//     java.util.Date var5 = null;
//     long var6 = var0.getTime(var5);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 2.0d, false);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.event.PlotChangeListener var12 = null;
//     var11.removeChangeListener(var12);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var16);
//     var16.resizeRange(100.0d);
//     java.awt.Paint var20 = var16.getTickMarkPaint();
//     var3.setBaseFillPaint(var20, true);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = null;
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
//     var26.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     var31.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var29, (org.jfree.chart.axis.ValueAxis)var31, var34, var35);
//     org.jfree.chart.plot.DrawingSupplier var37 = var36.getDrawingSupplier();
//     var26.addChangeListener((org.jfree.chart.event.AxisChangeListener)var36);
//     org.jfree.chart.plot.MultiplePiePlot var39 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var40 = var39.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var39);
//     var36.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var41);
//     var41.setTextAntiAlias(false);
//     java.awt.Image var45 = null;
//     var41.setBackgroundImage(var45);
//     java.lang.Object var47 = var41.clone();
//     org.jfree.chart.entity.EntityCollection var50 = null;
//     org.jfree.chart.ChartRenderingInfo var51 = new org.jfree.chart.ChartRenderingInfo(var50);
//     var41.handleClick(0, 10, var51);
//     java.awt.geom.Rectangle2D var53 = var51.getChartArea();
//     var3.drawDomainGridline(var23, var24, var53, 0.0d);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     int var2 = var1.getRowCount();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var14, var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var6.addChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var20 = var19.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     var16.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var21);
//     var21.setTextAntiAlias(false);
//     java.awt.Image var25 = null;
//     var21.setBackgroundImage(var25);
//     java.lang.Object var27 = var21.clone();
//     org.jfree.chart.entity.EntityCollection var30 = null;
//     org.jfree.chart.ChartRenderingInfo var31 = new org.jfree.chart.ChartRenderingInfo(var30);
//     var21.handleClick(0, 10, var31);
//     java.awt.geom.Rectangle2D var33 = var31.getChartArea();
//     org.jfree.chart.plot.CategoryPlot var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     double var38 = var37.getLowerBound();
//     float var39 = var37.getTickMarkOutsideLength();
//     boolean var40 = var37.isTickMarksVisible();
//     java.awt.Shape var41 = var37.getLeftArrow();
//     float var42 = var37.getTickMarkInsideLength();
//     var37.setNegativeArrowVisible(false);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     var1.drawItem(var3, var4, var33, var34, var35, (org.jfree.chart.axis.ValueAxis)var37, var45, 0, 100, 0);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    var16.setTextAntiAlias(false);
    java.awt.Image var20 = null;
    var16.setBackgroundImage(var20);
    java.lang.Object var22 = var16.clone();
    org.jfree.chart.entity.EntityCollection var25 = null;
    org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo(var25);
    var16.handleClick(0, 10, var26);
    java.awt.Stroke var28 = var16.getBorderStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    boolean var1 = var0.getFillBox();
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var4 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    var2.setBaseSectionOutlinePaint((java.awt.Paint)var4);
    int var12 = var2.getPieIndex();
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var16 = null;
    java.awt.Rectangle var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    java.awt.geom.AffineTransform var19 = null;
    java.awt.RenderingHints var20 = null;
    java.awt.PaintContext var21 = var15.createContext(var16, var17, var18, var19, var20);
    var13.setBaseSectionOutlinePaint((java.awt.Paint)var15);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    var26.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, var29, var30);
    org.jfree.chart.event.PlotChangeListener var32 = null;
    var31.removeChangeListener(var32);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    var31.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var36);
    java.awt.Paint var38 = var36.getTickMarkPaint();
    var13.setSectionOutlinePaint((java.lang.Comparable)1L, var38);
    var2.setLabelShadowPaint(var38);
    var0.setArtifactPaint(var38);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var46 = var45.getBasePaint();
    var0.setSeriesPaint(100, var46, true);
    java.awt.Graphics2D var49 = null;
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
    var51.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    var56.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
    org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var54, (org.jfree.chart.axis.ValueAxis)var56, var59, var60);
    org.jfree.chart.plot.DrawingSupplier var62 = var61.getDrawingSupplier();
    var51.addChangeListener((org.jfree.chart.event.AxisChangeListener)var61);
    org.jfree.chart.plot.MultiplePiePlot var64 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var65 = var64.getDataExtractOrder();
    org.jfree.chart.JFreeChart var66 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var64);
    var61.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var66);
    var66.setTextAntiAlias(false);
    java.awt.Image var70 = null;
    var66.setBackgroundImage(var70);
    java.lang.Object var72 = var66.clone();
    org.jfree.chart.entity.EntityCollection var75 = null;
    org.jfree.chart.ChartRenderingInfo var76 = new org.jfree.chart.ChartRenderingInfo(var75);
    var66.handleClick(0, 10, var76);
    java.awt.geom.Rectangle2D var78 = var76.getChartArea();
    org.jfree.chart.plot.CategoryPlot var79 = null;
    org.jfree.chart.plot.PlotRenderingInfo var81 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var82 = var0.initialise(var49, var78, var79, 1, var81);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-524308), 1, (-10289251));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)1);
    int var4 = var0.getRowIndex((java.lang.Comparable)false);
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 16.2d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.statistics.BoxAndWhiskerItem var9 = var0.getItem(100, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getValue((-10289251), 15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var3 = var2.getItemLabelAnchorOffset();
    boolean var4 = var2.getBaseCreateEntities();
    org.jfree.chart.labels.CategoryItemLabelGenerator var7 = var2.getItemLabelGenerator(100, (-1));
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    var16.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
    org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
    var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    java.awt.geom.Rectangle2D var24 = null;
    var2.drawRangeGridline(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, var24, 1.0d);
    org.jfree.chart.event.AxisChangeEvent var27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var11);
    java.awt.Stroke var28 = var11.getAxisLineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-524308), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.axis.AxisSpace var9 = var7.getFixedDomainAxisSpace();
    var7.setBackgroundImageAlignment(0);
    org.jfree.chart.plot.DatasetRenderingOrder var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setDatasetRenderingOrder(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    boolean var2 = var0.getBaseCreateEntities();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var0.getItemLabelGenerator(100, (-1));
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    var9.setStartValue(0.25d);
    java.awt.Font var12 = var9.getLabelFont();
    var0.setSeriesItemLabelFont(28, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var3 = null;
    java.awt.Rectangle var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.awt.geom.AffineTransform var6 = null;
    java.awt.RenderingHints var7 = null;
    java.awt.PaintContext var8 = var2.createContext(var3, var4, var5, var6, var7);
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var2);
    double var10 = var0.getStartAngle();
    java.awt.Shape var11 = var0.getLegendItemShape();
    var0.setOuterSeparatorExtension(100.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelDistributor(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    var11.setRangeCrosshairLockedOnData(true);
    java.awt.Paint var16 = var11.getDomainTickBandPaint();
    org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(0);
    org.jfree.chart.plot.PlotOrientation var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.plot.Plot var18 = var16.getPlot();
    var18.setOutlineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     java.lang.Number var10 = var7.getStartValue((java.lang.Comparable)1.0d, (java.lang.Comparable)(short)100);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit((-1), 15, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getObjectIcon();
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var3 = var2.getItemLabelAnchorOffset();
    boolean var4 = var2.getBaseCreateEntities();
    org.jfree.chart.labels.CategoryItemLabelGenerator var7 = var2.getItemLabelGenerator(100, (-1));
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    var16.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
    org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
    var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    java.awt.geom.Rectangle2D var24 = null;
    var2.drawRangeGridline(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, var24, 1.0d);
    org.jfree.chart.event.AxisChangeEvent var27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var11);
    java.awt.Stroke var28 = var11.getAxisLineStroke();
    var0.setGroupStroke(var28);
    javax.swing.Icon var30 = var0.getObjectIcon();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var5.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    var10.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, var13, var14);
    org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
    var5.addChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
    double var20 = var19.getLowerBound();
    float var21 = var19.getTickMarkOutsideLength();
    boolean var22 = var19.isTickMarksVisible();
    java.awt.Shape var23 = var19.getLeftArrow();
    var5.setUpArrow(var23);
    org.jfree.chart.renderer.category.IntervalBarRenderer var25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var26 = null;
    var25.setBaseItemLabelGenerator(var26, true);
    boolean var29 = var25.getBaseSeriesVisible();
    var25.setIncludeBaseInRange(false);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var36 = var35.getBasePaint();
    var25.setSeriesFillPaint(10, var36, false);
    org.jfree.chart.title.LegendGraphic var39 = new org.jfree.chart.title.LegendGraphic(var23, var36);
    org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot();
    double var41 = var40.getInteriorGap();
    java.awt.Paint var42 = var40.getLabelBackgroundPaint();
    java.awt.Paint var43 = var40.getLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem(var0, "hi!", "0", "hi!", var23, var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2);
    int var2 = var1.toSerial();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var4 = var1.getFollowingDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var3 = var2.clone();
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var7 = null;
//     java.awt.Rectangle var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.AffineTransform var10 = null;
//     java.awt.RenderingHints var11 = null;
//     java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
//     var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
//     int var14 = var4.getPieIndex();
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var18 = null;
//     java.awt.Rectangle var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     java.awt.geom.AffineTransform var21 = null;
//     java.awt.RenderingHints var22 = null;
//     java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
//     var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
//     java.awt.Paint var40 = var38.getTickMarkPaint();
//     var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
//     var4.setLabelShadowPaint(var40);
//     var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     java.awt.Paint var44 = var4.getLabelShadowPaint();
//     org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var49 = var48.clone();
//     org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var52 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var53 = null;
//     java.awt.Rectangle var54 = null;
//     java.awt.geom.Rectangle2D var55 = null;
//     java.awt.geom.AffineTransform var56 = null;
//     java.awt.RenderingHints var57 = null;
//     java.awt.PaintContext var58 = var52.createContext(var53, var54, var55, var56, var57);
//     var50.setBaseSectionOutlinePaint((java.awt.Paint)var52);
//     int var60 = var50.getPieIndex();
//     org.jfree.chart.plot.RingPlot var61 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var63 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var64 = null;
//     java.awt.Rectangle var65 = null;
//     java.awt.geom.Rectangle2D var66 = null;
//     java.awt.geom.AffineTransform var67 = null;
//     java.awt.RenderingHints var68 = null;
//     java.awt.PaintContext var69 = var63.createContext(var64, var65, var66, var67, var68);
//     var61.setBaseSectionOutlinePaint((java.awt.Paint)var63);
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("");
//     var74.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var78 = null;
//     org.jfree.chart.plot.XYPlot var79 = new org.jfree.chart.plot.XYPlot(var72, (org.jfree.chart.axis.ValueAxis)var74, var77, var78);
//     org.jfree.chart.event.PlotChangeListener var80 = null;
//     var79.removeChangeListener(var80);
//     org.jfree.chart.axis.NumberAxis var84 = new org.jfree.chart.axis.NumberAxis("");
//     var79.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var84);
//     java.awt.Paint var86 = var84.getTickMarkPaint();
//     var61.setSectionOutlinePaint((java.lang.Comparable)1L, var86);
//     var50.setLabelShadowPaint(var86);
//     var48.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var50);
//     java.awt.Paint var90 = var50.getLabelShadowPaint();
//     var4.setSectionOutlinePaint((java.lang.Comparable)(byte)1, var90);
//     
//     // Checks the contract:  equals-hashcode on var2 and var48
//     assertTrue("Contract failed: equals-hashcode on var2 and var48", var2.equals(var48) ? var2.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var2
//     assertTrue("Contract failed: equals-hashcode on var48 and var2", var48.equals(var2) ? var48.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var49
//     assertTrue("Contract failed: equals-hashcode on var3 and var49", var3.equals(var49) ? var3.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var3
//     assertTrue("Contract failed: equals-hashcode on var49 and var3", var49.equals(var3) ? var49.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var61
//     assertTrue("Contract failed: equals-hashcode on var15 and var61", var15.equals(var61) ? var15.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var15
//     assertTrue("Contract failed: equals-hashcode on var61 and var15", var61.equals(var15) ? var61.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var79
//     assertTrue("Contract failed: equals-hashcode on var33 and var79", var33.equals(var79) ? var33.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var33
//     assertTrue("Contract failed: equals-hashcode on var79 and var33", var79.equals(var33) ? var79.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var3 = var2.clone();
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var7 = null;
//     java.awt.Rectangle var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.AffineTransform var10 = null;
//     java.awt.RenderingHints var11 = null;
//     java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
//     var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
//     int var14 = var4.getPieIndex();
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var18 = null;
//     java.awt.Rectangle var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     java.awt.geom.AffineTransform var21 = null;
//     java.awt.RenderingHints var22 = null;
//     java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
//     var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
//     java.awt.Paint var40 = var38.getTickMarkPaint();
//     var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
//     var4.setLabelShadowPaint(var40);
//     var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     org.jfree.chart.LegendItemCollection var44 = var4.getLegendItems();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var45 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var46 = var45.getItemLabelAnchorOffset();
//     boolean var47 = var45.getBaseCreateEntities();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var50 = var45.getItemLabelGenerator(100, (-1));
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.plot.CategoryPlot var52 = null;
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
//     var54.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("");
//     var59.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var57, (org.jfree.chart.axis.ValueAxis)var59, var62, var63);
//     org.jfree.chart.plot.DrawingSupplier var65 = var64.getDrawingSupplier();
//     var54.addChangeListener((org.jfree.chart.event.AxisChangeListener)var64);
//     java.awt.geom.Rectangle2D var67 = null;
//     var45.drawRangeGridline(var51, var52, (org.jfree.chart.axis.ValueAxis)var54, var67, 1.0d);
//     java.awt.Paint var71 = var45.lookupSeriesOutlinePaint(0);
//     var4.setLabelShadowPaint(var71);
//     
//     // Checks the contract:  equals-hashcode on var64 and var33
//     assertTrue("Contract failed: equals-hashcode on var64 and var33", var64.equals(var33) ? var64.hashCode() == var33.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var64 and var33.", var64.equals(var33) == var33.equals(var64));
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getPositiveItemLabelPosition((-1), 2);
    double var4 = var3.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
//     var7.mapDatasetToDomainAxis(15, 1);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.event.ChartProgressListener var14 = null;
//     var13.addProgressListener(var14);
//     org.jfree.chart.event.TitleChangeEvent var16 = null;
//     var13.titleChanged(var16);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.chart.text.TextAnchor var2 = null;
//     org.jfree.chart.text.TextAnchor var3 = null;
//     org.jfree.chart.axis.DateTick var5 = new org.jfree.chart.axis.DateTick(var0, "UnitType.ABSOLUTE", var2, var3, 0.2d);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var7.isRangeCrosshairVisible();
    java.lang.Object var15 = var7.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var7.isDomainCrosshairVisible();
    var7.configureRangeAxes();
    java.awt.Stroke var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setDomainZeroBaselineStroke(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("black", var1, var3);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     int var9 = var7.getRowIndex((java.lang.Comparable)(short)1);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     int var10 = var7.getIndexOf(var9);
//     var7.setRangeCrosshairLockedOnData(false);
//     java.awt.Stroke var13 = var7.getRangeGridlineStroke();
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.event.PlotChangeListener var22 = null;
//     var21.removeChangeListener(var22);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, var33, var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     var25.addChangeListener((org.jfree.chart.event.AxisChangeListener)var35);
//     var21.setRangeAxis((org.jfree.chart.axis.ValueAxis)var25);
//     org.jfree.chart.axis.AxisLocation var40 = var21.getRangeAxisLocation((-10289251));
//     var7.setDomainAxisLocation(var40, false);
//     
//     // Checks the contract:  equals-hashcode on var8 and var36
//     assertTrue("Contract failed: equals-hashcode on var8 and var36", var8.equals(var36) ? var8.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var8
//     assertTrue("Contract failed: equals-hashcode on var36 and var8", var36.equals(var8) ? var36.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     double[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Other", "", var2);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     java.lang.Number var10 = var7.getStartValue((java.lang.Comparable)"", (java.lang.Comparable)16.25d);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var3 = var1.getRowIndex((java.lang.Comparable)1);
    int var5 = var1.getRowIndex((java.lang.Comparable)false);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, 16.2d);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    java.util.List var9 = var1.getRowKeys();
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var1, 68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var1.getMaxRegularValue(0, 28);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     var1.removeFragment(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     float var7 = var3.calculateBaselineOffset(var5, var6);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = var7.getRendererForDataset(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var7.getInsets();
//     double var13 = var7.getDomainCrosshairValue();
//     boolean var14 = var7.isRangeGridlinesVisible();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, var20, var21);
//     org.jfree.chart.event.PlotChangeListener var23 = null;
//     var22.removeChangeListener(var23);
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     var22.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var27);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var31 = var29.getSeriesPaint((-1));
//     java.awt.Font var34 = var29.getItemLabelFont(1, 1);
//     var27.setTickLabelFont(var34);
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var27.valueToJava2D((-1.0d), var37, var38);
//     int var40 = var7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var27);
//     
//     // Checks the contract:  equals-hashcode on var7 and var22
//     assertTrue("Contract failed: equals-hashcode on var7 and var22", var7.equals(var22) ? var7.hashCode() == var22.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var22.", var7.equals(var22) == var22.equals(var7));
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.2d);
    org.jfree.chart.axis.CategoryLabelPosition var3 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var4 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var2, var3);
    org.jfree.chart.axis.CategoryLabelPositions var6 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.2d);
    org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var8 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var6, var7);
    org.jfree.chart.axis.CategoryLabelPosition var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var10 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var3, var7, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    var4.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
    org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
    var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
    org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var18 = var17.getDataExtractOrder();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
    var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
    java.awt.Color var22 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var23 = null;
    java.awt.Rectangle var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    java.awt.geom.AffineTransform var26 = null;
    java.awt.RenderingHints var27 = null;
    java.awt.PaintContext var28 = var22.createContext(var23, var24, var25, var26, var27);
    java.awt.color.ColorSpace var29 = var22.getColorSpace();
    var19.setBackgroundPaint((java.awt.Paint)var22);
    var19.fireChartChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPieChart(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var3 = null;
    java.awt.Rectangle var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.awt.geom.AffineTransform var6 = null;
    java.awt.RenderingHints var7 = null;
    java.awt.PaintContext var8 = var2.createContext(var3, var4, var5, var6, var7);
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var2);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    var16.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
    org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
    var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    java.awt.Paint var24 = var11.getAxisLinePaint();
    var0.setBaseSectionPaint(var24);
    org.jfree.chart.urls.PieURLGenerator var26 = null;
    var0.setLegendLabelURLGenerator(var26);
    java.awt.Stroke var28 = null;
    var0.setOutlineStroke(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
//     var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
//     int var18 = var8.getPieIndex();
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.awt.geom.AffineTransform var25 = null;
//     java.awt.RenderingHints var26 = null;
//     java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
//     var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
//     java.awt.Paint var44 = var42.getTickMarkPaint();
//     var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
//     var8.setLabelShadowPaint(var44);
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var8.setLegendLabelURLGenerator(var47);
//     var8.setOuterSeparatorExtension(0.2d);
//     boolean var51 = var7.equals((java.lang.Object)var8);
//     java.lang.String[] var53 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var55 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var56 = null;
//     java.lang.Number[] var57 = null;
//     java.lang.Number[][] var58 = new java.lang.Number[][] { var57};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var59 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var53, var55, var56, var58);
//     var7.setCategoryKeys((java.lang.Comparable[])var53);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     java.lang.String var3 = var0.generateColumnLabel(var1, 68);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.util.RectangleInsets var9 = var7.getAxisOffset();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRenderer((-1), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.List var1 = var0.getColumnKeys();
    org.jfree.data.gantt.TaskSeries var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     org.jfree.chart.plot.Plot var18 = var16.getPlot();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var22.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, var25, var26);
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     var27.setRenderer(var28);
//     java.awt.Paint var30 = var27.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var32 = var31.getItemLabelAnchorOffset();
//     var31.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var36 = var27.equals((java.lang.Object)var31);
//     org.jfree.chart.plot.SeriesRenderingOrder var37 = var27.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var39 = var27.getDataset(10);
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var42 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var43 = null;
//     java.awt.Rectangle var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     java.awt.geom.AffineTransform var46 = null;
//     java.awt.RenderingHints var47 = null;
//     java.awt.PaintContext var48 = var42.createContext(var43, var44, var45, var46, var47);
//     var40.setBaseSectionOutlinePaint((java.awt.Paint)var42);
//     int var50 = var40.getPieIndex();
//     org.jfree.chart.labels.PieToolTipGenerator var51 = null;
//     var40.setToolTipGenerator(var51);
//     java.awt.Paint var53 = var40.getShadowPaint();
//     var27.setDomainGridlinePaint(var53);
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     var57.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
//     var62.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var60, (org.jfree.chart.axis.ValueAxis)var62, var65, var66);
//     org.jfree.chart.plot.DrawingSupplier var68 = var67.getDrawingSupplier();
//     var57.addChangeListener((org.jfree.chart.event.AxisChangeListener)var67);
//     org.jfree.chart.plot.MultiplePiePlot var70 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var71 = var70.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var70);
//     var67.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var72);
//     var72.setTextAntiAlias(false);
//     java.awt.Image var76 = null;
//     var72.setBackgroundImage(var76);
//     java.lang.Object var78 = var72.clone();
//     org.jfree.chart.entity.EntityCollection var81 = null;
//     org.jfree.chart.ChartRenderingInfo var82 = new org.jfree.chart.ChartRenderingInfo(var81);
//     var72.handleClick(0, 10, var82);
//     java.awt.geom.Rectangle2D var84 = var82.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var85 = null;
//     var27.drawAnnotations(var55, var84, var85);
//     var18.drawBackgroundImage(var19, var84);
//     
//     // Checks the contract:  equals-hashcode on var11 and var67
//     assertTrue("Contract failed: equals-hashcode on var11 and var67", var11.equals(var67) ? var11.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var11
//     assertTrue("Contract failed: equals-hashcode on var67 and var11", var67.equals(var11) ? var67.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var68
//     assertTrue("Contract failed: equals-hashcode on var12 and var68", var12.equals(var68) ? var12.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var12
//     assertTrue("Contract failed: equals-hashcode on var68 and var12", var68.equals(var12) ? var68.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var70
//     assertTrue("Contract failed: equals-hashcode on var14 and var70", var14.equals(var70) ? var14.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var14
//     assertTrue("Contract failed: equals-hashcode on var70 and var14", var70.equals(var14) ? var70.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.setObject((java.lang.Object)15, (java.lang.Comparable)100.0d, (java.lang.Comparable)0.0f);
    java.util.List var5 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)4.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.zoom(16.25d);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getFollowingDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     var16.setTextAntiAlias(false);
//     java.awt.Image var20 = null;
//     var16.setBackgroundImage(var20);
//     float var22 = var16.getBackgroundImageAlpha();
//     org.jfree.chart.event.ChartProgressListener var23 = null;
//     var16.removeProgressListener(var23);
//     java.awt.Font var26 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var27 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var28 = null;
//     var27.setBaseItemLabelGenerator(var28, true);
//     boolean var31 = var27.getBaseSeriesVisible();
//     var27.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var38 = var37.getBasePaint();
//     var27.setSeriesFillPaint(10, var38, false);
//     org.jfree.chart.text.TextMeasurer var43 = null;
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, var38, (-1.0f), 10, var43);
//     java.util.List var45 = var44.getLines();
//     var16.setSubtitles(var45);
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var48.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     var53.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var51, (org.jfree.chart.axis.ValueAxis)var53, var56, var57);
//     org.jfree.chart.plot.DrawingSupplier var59 = var58.getDrawingSupplier();
//     var48.addChangeListener((org.jfree.chart.event.AxisChangeListener)var58);
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
//     double var63 = var62.getLowerBound();
//     float var64 = var62.getTickMarkOutsideLength();
//     boolean var65 = var62.isTickMarksVisible();
//     java.awt.Shape var66 = var62.getLeftArrow();
//     var48.setUpArrow(var66);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var68 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var69 = null;
//     var68.setBaseItemLabelGenerator(var69, true);
//     boolean var72 = var68.getBaseSeriesVisible();
//     var68.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var78 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var79 = var78.getBasePaint();
//     var68.setSeriesFillPaint(10, var79, false);
//     org.jfree.chart.title.LegendGraphic var82 = new org.jfree.chart.title.LegendGraphic(var66, var79);
//     var16.setBorderPaint(var79);
//     
//     // Checks the contract:  equals-hashcode on var11 and var58
//     assertTrue("Contract failed: equals-hashcode on var11 and var58", var11.equals(var58) ? var11.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var11
//     assertTrue("Contract failed: equals-hashcode on var58 and var11", var58.equals(var11) ? var58.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var59
//     assertTrue("Contract failed: equals-hashcode on var12 and var59", var12.equals(var59) ? var12.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var12
//     assertTrue("Contract failed: equals-hashcode on var59 and var12", var59.equals(var12) ? var59.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
//     org.jfree.chart.event.PlotChangeListener var18 = null;
//     var17.removeChangeListener(var18);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var22);
//     var22.resizeRange(100.0d);
//     boolean var26 = var22.isAutoTickUnitSelection();
//     var7.setDomainAxis((org.jfree.chart.axis.ValueAxis)var22);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, var33, var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     org.jfree.data.gantt.TaskSeriesCollection var37 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetGroup var38 = var37.getGroup();
//     org.jfree.data.general.DatasetChangeEvent var39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var36, (org.jfree.data.general.Dataset)var37);
//     var7.datasetChanged(var39);
//     
//     // Checks the contract:  equals-hashcode on var35 and var17
//     assertTrue("Contract failed: equals-hashcode on var35 and var17", var35.equals(var17) ? var35.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var17.", var35.equals(var17) == var17.equals(var35));
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     var4.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
//     org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
//     var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     double var19 = var18.getLowerBound();
//     float var20 = var18.getTickMarkOutsideLength();
//     boolean var21 = var18.isTickMarksVisible();
//     java.awt.Shape var22 = var18.getLeftArrow();
//     var4.setUpArrow(var22);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var25 = null;
//     var24.setBaseItemLabelGenerator(var25, true);
//     boolean var28 = var24.getBaseSeriesVisible();
//     var24.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var35 = var34.getBasePaint();
//     var24.setSeriesFillPaint(10, var35, false);
//     org.jfree.chart.title.LegendGraphic var38 = new org.jfree.chart.title.LegendGraphic(var22, var35);
//     org.jfree.chart.util.StandardGradientPaintTransformer var39 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var38.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var39);
//     java.lang.Object var41 = var38.clone();
//     org.jfree.chart.util.RectangleAnchor var42 = var38.getShapeAnchor();
//     java.awt.geom.Rectangle2D var43 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, (-15.8d), (-15.8d), var42);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
//     var2.setBaseItemLabelGenerator(var3, true);
//     org.jfree.chart.urls.StandardCategoryURLGenerator var7 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
//     var2.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var7, false);
//     org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
//     var2.setBasePositiveItemLabelPosition(var10, true);
//     org.jfree.chart.text.TextAnchor var13 = var10.getRotationAnchor();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var15 = null;
//     var14.setBaseItemLabelGenerator(var15, true);
//     org.jfree.chart.urls.StandardCategoryURLGenerator var19 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
//     var14.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var19, false);
//     org.jfree.chart.labels.ItemLabelPosition var22 = new org.jfree.chart.labels.ItemLabelPosition();
//     var14.setBasePositiveItemLabelPosition(var22, true);
//     org.jfree.chart.text.TextAnchor var25 = var22.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var27 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(short)1, "Other", var13, var25, (-1.0d));
//     
//     // Checks the contract:  equals-hashcode on var10 and var22
//     assertTrue("Contract failed: equals-hashcode on var10 and var22", var10.equals(var22) ? var10.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var10
//     assertTrue("Contract failed: equals-hashcode on var22 and var10", var22.equals(var10) ? var22.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     var16.setTextAntiAlias(false);
//     java.awt.Image var20 = null;
//     var16.setBackgroundImage(var20);
//     java.lang.Object var22 = var16.clone();
//     org.jfree.chart.title.LegendTitle var24 = var16.getLegend(10);
//     java.lang.Object var25 = var16.clone();
//     
//     // Checks the contract:  equals-hashcode on var22 and var25
//     assertTrue("Contract failed: equals-hashcode on var22 and var25", var22.equals(var25) ? var22.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var22
//     assertTrue("Contract failed: equals-hashcode on var25 and var22", var25.equals(var22) ? var25.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
    var7.mapDatasetToDomainAxis(15, 1);
    var7.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setDomainAxisLocation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeEvent var8 = null;
    var7.notifyListeners(var8);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var12.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
    org.jfree.chart.event.PlotChangeListener var18 = null;
    var17.removeChangeListener(var18);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    var17.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var22);
    java.awt.Paint var24 = var22.getTickMarkPaint();
    boolean var25 = var22.isAutoRange();
    java.awt.Stroke var26 = var22.getTickMarkStroke();
    var7.setDomainCrosshairStroke(var26);
    java.lang.String var28 = var7.getPlotType();
    java.awt.Paint var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRangeGridlinePaint(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "XY Plot"+ "'", var28.equals("XY Plot"));

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     var4.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
//     org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
//     var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     double var19 = var18.getLowerBound();
//     float var20 = var18.getTickMarkOutsideLength();
//     boolean var21 = var18.isTickMarksVisible();
//     java.awt.Shape var22 = var18.getLeftArrow();
//     var4.setUpArrow(var22);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var25 = null;
//     var24.setBaseItemLabelGenerator(var25, true);
//     boolean var28 = var24.getBaseSeriesVisible();
//     var24.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var35 = var34.getBasePaint();
//     var24.setSeriesFillPaint(10, var35, false);
//     org.jfree.chart.title.LegendGraphic var38 = new org.jfree.chart.title.LegendGraphic(var22, var35);
//     org.jfree.chart.util.StandardGradientPaintTransformer var39 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var38.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var39);
//     java.lang.Object var41 = var38.clone();
//     org.jfree.chart.util.RectangleAnchor var42 = var38.getShapeAnchor();
//     java.awt.geom.Rectangle2D var43 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 0.2d, (-15.8d), var42);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     java.lang.Number var10 = var7.getEndValue((java.lang.Comparable)10, (java.lang.Comparable)1);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getBase();
    var0.setBaseSeriesVisibleInLegend(true, true);
    double var5 = var0.getBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("");
//     java.awt.Paint var3 = var1.getTickLabelPaint((java.lang.Comparable)(short)1);
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     var8.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, var11, var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     var13.setRenderer(var14);
//     java.awt.Paint var16 = var13.getNoDataMessagePaint();
//     var5.setLabelOutlinePaint(var16);
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var16};
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var25 = var23.getSeriesPaint((-1));
//     java.awt.Font var28 = var23.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var29 = new org.jfree.chart.labels.ItemLabelPosition();
//     var23.setBasePositiveItemLabelPosition(var29);
//     var21.setSeriesPositiveItemLabelPosition(10, var29);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     var34.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var32, (org.jfree.chart.axis.ValueAxis)var34, var37, var38);
//     org.jfree.chart.event.PlotChangeListener var40 = null;
//     var39.removeChangeListener(var40);
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     var39.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var44);
//     java.awt.Paint var46 = var44.getTickMarkPaint();
//     boolean var47 = var44.isAutoRange();
//     java.awt.Stroke var48 = var44.getTickMarkStroke();
//     boolean var49 = var21.equals((java.lang.Object)var48);
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var48};
//     org.jfree.chart.renderer.category.IntervalBarRenderer var52 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var53 = var52.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
//     var52.setBaseToolTipGenerator(var54);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var56 = null;
//     var52.setLegendItemURLGenerator(var56);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var60 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var61 = var60.getBasePaint();
//     var52.setBasePaint(var61);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis("");
//     var65.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
//     org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var63, (org.jfree.chart.axis.ValueAxis)var65, var68, var69);
//     org.jfree.chart.event.PlotChangeListener var71 = null;
//     var70.removeChangeListener(var71);
//     org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis("");
//     var70.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var75);
//     java.awt.Paint var77 = var75.getTickMarkPaint();
//     boolean var78 = var75.isAutoRange();
//     java.awt.Stroke var79 = var75.getTickMarkStroke();
//     org.jfree.chart.plot.ValueMarker var80 = new org.jfree.chart.plot.ValueMarker(32.2d, var61, var79);
//     java.awt.Stroke[] var81 = new java.awt.Stroke[] { var79};
//     java.awt.Shape var84 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.5f, (-1.0f));
//     java.awt.Shape[] var85 = new java.awt.Shape[] { var84};
//     org.jfree.chart.plot.DefaultDrawingSupplier var86 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var18, var50, var81, var85);
//     
//     // Checks the contract:  equals-hashcode on var13 and var39
//     assertTrue("Contract failed: equals-hashcode on var13 and var39", var13.equals(var39) ? var13.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var70
//     assertTrue("Contract failed: equals-hashcode on var13 and var70", var13.equals(var70) ? var13.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var70
//     assertTrue("Contract failed: equals-hashcode on var39 and var70", var39.equals(var70) ? var39.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var39
//     assertTrue("Contract failed: equals-hashcode on var70 and var39", var70.equals(var39) ? var70.hashCode() == var39.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var39.", var13.equals(var39) == var39.equals(var13));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var70.", var13.equals(var70) == var70.equals(var13));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var60 and var21.", var60.equals(var21) == var21.equals(var60));
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     double var16 = var15.getLowerBound();
//     float var17 = var15.getTickMarkOutsideLength();
//     boolean var18 = var15.isTickMarksVisible();
//     java.awt.Shape var19 = var15.getLeftArrow();
//     var1.setUpArrow(var19);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = null;
//     var21.setBaseItemLabelGenerator(var22, true);
//     boolean var25 = var21.getBaseSeriesVisible();
//     var21.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var32 = var31.getBasePaint();
//     var21.setSeriesFillPaint(10, var32, false);
//     org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic(var19, var32);
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var42.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var40, (org.jfree.chart.axis.ValueAxis)var42, var45, var46);
//     org.jfree.chart.plot.DrawingSupplier var48 = var47.getDrawingSupplier();
//     var37.addChangeListener((org.jfree.chart.event.AxisChangeListener)var47);
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     double var52 = var51.getLowerBound();
//     float var53 = var51.getTickMarkOutsideLength();
//     boolean var54 = var51.isTickMarksVisible();
//     java.awt.Shape var55 = var51.getLeftArrow();
//     var37.setUpArrow(var55);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var57 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var58 = null;
//     var57.setBaseItemLabelGenerator(var58, true);
//     boolean var61 = var57.getBaseSeriesVisible();
//     var57.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var67 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var68 = var67.getBasePaint();
//     var57.setSeriesFillPaint(10, var68, false);
//     org.jfree.chart.title.LegendGraphic var71 = new org.jfree.chart.title.LegendGraphic(var55, var68);
//     org.jfree.chart.util.StandardGradientPaintTransformer var72 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var71.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var72);
//     java.lang.Object var74 = var71.clone();
//     org.jfree.chart.util.RectangleAnchor var75 = var71.getShapeAnchor();
//     java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, var75, 8.0d, 16.25d);
//     
//     // Checks the contract:  equals-hashcode on var11 and var47
//     assertTrue("Contract failed: equals-hashcode on var11 and var47", var11.equals(var47) ? var11.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var11
//     assertTrue("Contract failed: equals-hashcode on var47 and var11", var47.equals(var11) ? var47.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var48
//     assertTrue("Contract failed: equals-hashcode on var12 and var48", var12.equals(var48) ? var12.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var12
//     assertTrue("Contract failed: equals-hashcode on var48 and var12", var48.equals(var12) ? var48.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     java.util.Date var1 = null;
//     java.util.Date var2 = null;
//     org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("RectangleEdge.TOP", var1, var2);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    var0.setAutoPopulateSeriesStroke(false);
    var0.setDrawBarOutline(false);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    int var9 = var7.getBackgroundImageAlignment();
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var7.getDomainMarkers(var10);
    org.jfree.chart.annotations.XYAnnotation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var13 = var7.removeAnnotation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    double var3 = var0.getLimit();
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var5 = var4.getGroup();
    int var7 = var4.getColumnIndex((java.lang.Comparable)1);
    int var9 = var4.getRowIndex((java.lang.Comparable)(byte)(-1));
    var0.setDataset((org.jfree.data.category.CategoryDataset)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var4.getStartValue((java.lang.Comparable)1, (java.lang.Comparable)"", 2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.TaskSeries var4 = var0.getSeries((-524308));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.awt.geom.AffineTransform var10 = null;
    java.awt.RenderingHints var11 = null;
    java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
    var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
    int var14 = var4.getPieIndex();
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
    var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var28.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    org.jfree.chart.event.PlotChangeListener var34 = null;
    var33.removeChangeListener(var34);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
    java.awt.Paint var40 = var38.getTickMarkPaint();
    var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
    var4.setLabelShadowPaint(var40);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    org.jfree.chart.LegendItemCollection var44 = var4.getLegendItems();
    org.jfree.chart.LegendItem var45 = null;
    var44.add(var45);
    org.jfree.chart.plot.MultiplePiePlot var47 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var48 = var47.getDataExtractOrder();
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var47);
    org.jfree.chart.LegendItemCollection var50 = var47.getLegendItems();
    var44.addAll(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setMaxIcon(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
    var2.setSeriesShapesFilled(1, (java.lang.Boolean)false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelGenerator((-1), var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.setObject((java.lang.Object)15, (java.lang.Comparable)100.0d, (java.lang.Comparable)0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = var0.getObject(7, 28);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.axis.AxisSpace var9 = var7.getFixedDomainAxisSpace();
    var7.clearRangeMarkers((-1));
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var19 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var20 = null;
    java.awt.Rectangle var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    java.awt.geom.AffineTransform var23 = null;
    java.awt.RenderingHints var24 = null;
    java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
    var17.setBaseSectionOutlinePaint((java.awt.Paint)var19);
    int var27 = var17.getPieIndex();
    org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var30 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var31 = null;
    java.awt.Rectangle var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    java.awt.geom.AffineTransform var34 = null;
    java.awt.RenderingHints var35 = null;
    java.awt.PaintContext var36 = var30.createContext(var31, var32, var33, var34, var35);
    var28.setBaseSectionOutlinePaint((java.awt.Paint)var30);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
    var41.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var41, var44, var45);
    org.jfree.chart.event.PlotChangeListener var47 = null;
    var46.removeChangeListener(var47);
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
    var46.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var51);
    java.awt.Paint var53 = var51.getTickMarkPaint();
    var28.setSectionOutlinePaint((java.lang.Comparable)1L, var53);
    var17.setLabelShadowPaint(var53);
    var15.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var17);
    org.jfree.chart.util.GradientPaintTransformer var57 = null;
    var15.setGradientPaintTransformer(var57);
    org.jfree.chart.util.Layer var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addDomainMarker(2014, (org.jfree.chart.plot.Marker)var15, var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getPreviousDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = null;
    var0.setBaseItemLabelGenerator(var1, true);
    java.awt.Paint var4 = var0.getBaseItemLabelPaint();
    java.awt.Stroke var6 = var0.getSeriesStroke(1);
    double var7 = var0.getLowerClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var1 = var0.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setBaseToolTipGenerator(var2);
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var5 = null;
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var4, var5);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     var10.resizeRange(0.2d);
//     var10.setLabelToolTip("hi!");
//     org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var17 = var15.getSeriesPaint((-1));
//     java.awt.Font var20 = var15.getItemLabelFont(1, 1);
//     var10.setLabelFont(var20);
//     java.lang.String var22 = var10.getLabelToolTip();
//     java.awt.Paint var23 = var10.getTickLabelPaint();
//     var0.setSeriesItemLabelPaint(2014, var23, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var0.", var15.equals(var0) == var0.equals(var15));
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)10.0f);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     java.lang.String[] var9 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var11 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var12 = null;
//     java.lang.Number[] var13 = null;
//     java.lang.Number[][] var14 = new java.lang.Number[][] { var13};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var15 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var9, var11, var12, var14);
//     var7.setCategoryKeys((java.lang.Comparable[])var9);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    var0.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setSeriesItemLabelGenerator(10, var5, false);
    boolean var9 = var0.isSeriesVisible(1);
    java.lang.Object var10 = var0.clone();
    org.jfree.chart.renderer.category.LayeredBarRenderer var12 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.labels.StandardCategoryToolTipGenerator var13 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    java.text.DateFormat var14 = var13.getDateFormat();
    var12.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator)var13, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-10289251), (org.jfree.chart.labels.CategoryToolTipGenerator)var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     int var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    int var3 = var0.getColumnIndex((java.lang.Comparable)1);
    int var5 = var0.getRowIndex((java.lang.Comparable)(byte)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var0.getPercentComplete((java.lang.Comparable)0L, (java.lang.Comparable)61200000L, 7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var3 = null;
//     java.awt.Rectangle var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.AffineTransform var6 = null;
//     java.awt.RenderingHints var7 = null;
//     java.awt.PaintContext var8 = var2.createContext(var3, var4, var5, var6, var7);
//     var0.setBaseSectionOutlinePaint((java.awt.Paint)var2);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     var13.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, var16, var17);
//     org.jfree.chart.event.PlotChangeListener var19 = null;
//     var18.removeChangeListener(var19);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var18.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var23);
//     java.awt.Paint var25 = var23.getTickMarkPaint();
//     var0.setSectionOutlinePaint((java.lang.Comparable)1L, var25);
//     org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var29 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var30 = null;
//     java.awt.Rectangle var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     java.awt.geom.AffineTransform var33 = null;
//     java.awt.RenderingHints var34 = null;
//     java.awt.PaintContext var35 = var29.createContext(var30, var31, var32, var33, var34);
//     var27.setBaseSectionOutlinePaint((java.awt.Paint)var29);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     var40.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var40, var43, var44);
//     org.jfree.chart.event.PlotChangeListener var46 = null;
//     var45.removeChangeListener(var46);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("");
//     var45.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var50);
//     java.awt.Paint var52 = var50.getTickMarkPaint();
//     var27.setSectionOutlinePaint((java.lang.Comparable)1L, var52);
//     org.jfree.data.general.PieDataset var54 = var27.getDataset();
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("");
//     var58.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var58, var61, var62);
//     org.jfree.chart.event.PlotChangeListener var64 = null;
//     var63.removeChangeListener(var64);
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("");
//     var63.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var68);
//     var68.resizeRange(100.0d);
//     java.awt.Paint var72 = var68.getTickMarkPaint();
//     var27.setSectionPaint((java.lang.Comparable)"Other", var72);
//     var0.setOutlinePaint(var72);
//     
//     // Checks the contract:  equals-hashcode on var18 and var45
//     assertTrue("Contract failed: equals-hashcode on var18 and var45", var18.equals(var45) ? var18.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var18
//     assertTrue("Contract failed: equals-hashcode on var45 and var18", var45.equals(var18) ? var45.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var3 = var1.getRowIndex((java.lang.Comparable)1);
    int var5 = var1.getRowIndex((java.lang.Comparable)false);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, 16.2d);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var1.getMinRegularValue(68, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var7.removeChangeListener(var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
    java.awt.Paint var14 = var12.getTickMarkPaint();
    boolean var15 = var12.isInverted();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 2.0d);
    double var3 = var2.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var1 = var0.getAngleGridlinePaint();
//     var0.addCornerTextItem("Other");
//     var0.zoom(2.0d);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getBase();
    boolean var2 = var0.getAutoPopulateSeriesPaint();
    boolean var3 = var0.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    var4.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, var7, var8);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    var9.setRenderer(var10);
    java.awt.Paint var12 = var9.getNoDataMessagePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var14 = var13.getItemLabelAnchorOffset();
    var13.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
    boolean var18 = var9.equals((java.lang.Object)var13);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("black", var1, (org.jfree.chart.plot.Plot)var9, true);
    org.jfree.chart.plot.Marker var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.addDomainMarker(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.toTimelineValue(100L);
//     var0.addException((-1L));
//     long var5 = var0.getSegmentsExcludedSize();
//     java.util.Date var6 = null;
//     java.util.Date var7 = null;
//     boolean var8 = var0.containsDomainRange(var6, var7);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     int var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var6 = var4.getSeriesPaint((-1));
//     java.awt.Font var9 = var4.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
//     var4.setBasePositiveItemLabelPosition(var10);
//     var2.setSeriesPositiveItemLabelPosition(10, var10);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var15.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, var18, var19);
//     org.jfree.chart.event.PlotChangeListener var21 = null;
//     var20.removeChangeListener(var21);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     var20.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var25);
//     java.awt.Paint var27 = var25.getTickMarkPaint();
//     boolean var28 = var25.isAutoRange();
//     java.awt.Stroke var29 = var25.getTickMarkStroke();
//     boolean var30 = var2.equals((java.lang.Object)var29);
//     java.awt.Paint var32 = var2.lookupSeriesOutlinePaint(15);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = null;
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var37, var40, var41);
//     org.jfree.chart.event.PlotChangeListener var43 = null;
//     var42.removeChangeListener(var43);
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     var42.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var47);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var51 = var49.getSeriesPaint((-1));
//     java.awt.Font var54 = var49.getItemLabelFont(1, 1);
//     var47.setTickLabelFont(var54);
//     java.text.NumberFormat var56 = null;
//     var47.setNumberFormatOverride(var56);
//     boolean var58 = var47.isAutoRange();
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("");
//     var60.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis("");
//     var65.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
//     org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var63, (org.jfree.chart.axis.ValueAxis)var65, var68, var69);
//     org.jfree.chart.plot.DrawingSupplier var71 = var70.getDrawingSupplier();
//     var60.addChangeListener((org.jfree.chart.event.AxisChangeListener)var70);
//     org.jfree.chart.plot.MultiplePiePlot var73 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var74 = var73.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var73);
//     var70.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var75);
//     var75.setTextAntiAlias(false);
//     java.awt.Image var79 = null;
//     var75.setBackgroundImage(var79);
//     java.lang.Object var81 = var75.clone();
//     org.jfree.chart.entity.EntityCollection var84 = null;
//     org.jfree.chart.ChartRenderingInfo var85 = new org.jfree.chart.ChartRenderingInfo(var84);
//     var75.handleClick(0, 10, var85);
//     java.awt.geom.Rectangle2D var87 = var85.getChartArea();
//     var2.drawRangeGridline(var33, var34, (org.jfree.chart.axis.ValueAxis)var47, var87, 1.0d);
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     boolean var2 = var0.isHiddenValue((-1L));
//     java.util.Date var3 = null;
//     org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var6 = var4.toTimelineValue(100L);
//     var4.addException((-1L));
//     java.util.Date var10 = var4.getDate(61200000L);
//     var0.setRange(var3, var10);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var7.getEndValue((-10289251), 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 2.0d, 10.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetGroup var6 = var5.getGroup();
//     org.jfree.chart.title.LegendItemBlockContainer var8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)2);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
//     var10.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var15.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, var18, var19);
//     org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
//     var10.addChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
//     var20.setRangeCrosshairLockedOnData(true);
//     boolean var25 = var4.equals((java.lang.Object)var20);
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.FlowArrangement var30 = new org.jfree.chart.block.FlowArrangement(var26, var27, 2.0d, 10.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var31 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetGroup var32 = var31.getGroup();
//     org.jfree.chart.title.LegendItemBlockContainer var34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, (org.jfree.data.general.Dataset)var31, (java.lang.Comparable)2);
//     java.util.List var35 = var34.getBlocks();
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint(16.25d, 100.0d);
//     org.jfree.chart.util.Size2D var40 = var4.arrange((org.jfree.chart.block.BlockContainer)var34, var36, var39);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var31
//     assertTrue("Contract failed: equals-hashcode on var5 and var31", var5.equals(var31) ? var5.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var5
//     assertTrue("Contract failed: equals-hashcode on var31 and var5", var31.equals(var5) ? var31.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var34
//     assertTrue("Contract failed: equals-hashcode on var8 and var34", var8.equals(var34) ? var8.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var8
//     assertTrue("Contract failed: equals-hashcode on var34 and var8", var34.equals(var8) ? var34.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     boolean var14 = var7.isDomainCrosshairVisible();
//     org.jfree.chart.util.RectangleEdge var16 = var7.getDomainAxisEdge(68);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     var19.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var22, var23);
//     org.jfree.chart.event.PlotChangeListener var25 = null;
//     var24.removeChangeListener(var25);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var24.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var29);
//     boolean var31 = var24.isDomainCrosshairVisible();
//     org.jfree.chart.axis.ValueAxis var32 = var24.getRangeAxis();
//     boolean var33 = var16.equals((java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
    var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
    int var18 = var8.getPieIndex();
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
    var32.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
    org.jfree.chart.event.PlotChangeListener var38 = null;
    var37.removeChangeListener(var38);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
    java.awt.Paint var44 = var42.getTickMarkPaint();
    var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
    var8.setLabelShadowPaint(var44);
    org.jfree.chart.urls.PieURLGenerator var47 = null;
    var8.setLegendLabelURLGenerator(var47);
    var8.setOuterSeparatorExtension(0.2d);
    boolean var51 = var7.equals((java.lang.Object)var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var54 = var7.getEndValue((-1), 2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.labels.ItemLabelPosition var3 = null;
//     var2.setNegativeItemLabelPositionFallback(var3);
//     java.awt.Shape var5 = var2.getBaseShape();
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var7 = var6.clone();
//     boolean var8 = var6.getNotify();
//     boolean var9 = var2.equals((java.lang.Object)var6);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = null;
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     var19.setRenderer(var20);
//     java.awt.Paint var22 = var19.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var24 = var23.getItemLabelAnchorOffset();
//     var23.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var28 = var19.equals((java.lang.Object)var23);
//     org.jfree.chart.plot.SeriesRenderingOrder var29 = var19.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var31 = var19.getDataset(10);
//     org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var34 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var35 = null;
//     java.awt.Rectangle var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
//     var32.setBaseSectionOutlinePaint((java.awt.Paint)var34);
//     int var42 = var32.getPieIndex();
//     org.jfree.chart.labels.PieToolTipGenerator var43 = null;
//     var32.setToolTipGenerator(var43);
//     java.awt.Paint var45 = var32.getShadowPaint();
//     var19.setDomainGridlinePaint(var45);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
//     var49.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
//     var54.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, var57, var58);
//     org.jfree.chart.plot.DrawingSupplier var60 = var59.getDrawingSupplier();
//     var49.addChangeListener((org.jfree.chart.event.AxisChangeListener)var59);
//     org.jfree.chart.plot.MultiplePiePlot var62 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var63 = var62.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var64 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var62);
//     var59.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var64);
//     var64.setTextAntiAlias(false);
//     java.awt.Image var68 = null;
//     var64.setBackgroundImage(var68);
//     java.lang.Object var70 = var64.clone();
//     org.jfree.chart.entity.EntityCollection var73 = null;
//     org.jfree.chart.ChartRenderingInfo var74 = new org.jfree.chart.ChartRenderingInfo(var73);
//     var64.handleClick(0, 10, var74);
//     java.awt.geom.Rectangle2D var76 = var74.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     var19.drawAnnotations(var47, var76, var77);
//     var2.drawBackground(var10, var11, var76);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     int var2 = var0.getRowIndex((java.lang.Comparable)1);
//     int var4 = var0.getRowIndex((java.lang.Comparable)false);
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 16.2d);
//     java.lang.Comparable var8 = null;
//     java.lang.Number var9 = var0.getMaxOutlier((java.lang.Comparable)"XY Plot", var8);
//     double var11 = var0.getRangeLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var14 = var0.getMinOutlier(10, 0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var2 = var1.getDataExtractOrder();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var4 = var3.getBorderPaint();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    double var7 = var6.getLowerMargin();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var14 = var12.getSeriesPaint((-1));
    java.awt.Font var17 = var12.getItemLabelFont(1, 1);
    org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition();
    var12.setBasePositiveItemLabelPosition(var18);
    var10.setSeriesPositiveItemLabelPosition(10, var18);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    var23.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, var26, var27);
    org.jfree.chart.event.PlotChangeListener var29 = null;
    var28.removeChangeListener(var29);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    var28.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var33);
    java.awt.Paint var35 = var33.getTickMarkPaint();
    boolean var36 = var33.isAutoRange();
    java.awt.Stroke var37 = var33.getTickMarkStroke();
    boolean var38 = var10.equals((java.lang.Object)var37);
    var6.setTickMarkStroke(var37);
    org.jfree.chart.util.HorizontalAlignment var41 = null;
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.FlowArrangement var45 = new org.jfree.chart.block.FlowArrangement(var41, var42, 2.0d, 10.0d);
    org.jfree.data.gantt.TaskSeriesCollection var46 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var47 = var46.getGroup();
    org.jfree.chart.title.LegendItemBlockContainer var49 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var45, (org.jfree.data.general.Dataset)var46, (java.lang.Comparable)2);
    org.jfree.chart.plot.MultiplePiePlot var50 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var51 = var50.getDataExtractOrder();
    org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var50);
    java.awt.Paint var53 = var52.getBorderPaint();
    boolean var54 = var45.equals((java.lang.Object)var53);
    org.jfree.chart.plot.RingPlot var55 = new org.jfree.chart.plot.RingPlot();
    double var56 = var55.getInteriorGap();
    java.awt.Stroke var57 = var55.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("");
    var60.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
    org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var58, (org.jfree.chart.axis.ValueAxis)var60, var63, var64);
    org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
    var65.setRenderer(var66);
    java.awt.Paint var68 = var65.getNoDataMessagePaint();
    org.jfree.data.xy.XYDataset var69 = null;
    org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("");
    var71.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var74 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var75 = null;
    org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot(var69, (org.jfree.chart.axis.ValueAxis)var71, var74, var75);
    org.jfree.chart.axis.AxisSpace var77 = var76.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var80 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var81 = var80.getBasePaint();
    var76.setDomainZeroBaselinePaint(var81);
    java.awt.Stroke var83 = var76.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.ValueMarker var85 = new org.jfree.chart.plot.ValueMarker(2.0d, var53, var57, var68, var83, 0.5f);
    java.awt.Stroke var86 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryMarker var88 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)'#', var4, var37, var53, var86, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.data.gantt.TaskSeriesCollection var9 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var10 = var9.getGroup();
    org.jfree.data.general.DatasetChangeEvent var11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var8, (org.jfree.data.general.Dataset)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var9.getPercentComplete(1, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2);
    java.lang.String var2 = var1.toString();
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(2);
    int var5 = var4.toSerial();
    boolean var6 = var1.isAfter((org.jfree.data.time.SerialDate)var4);
    var1.setDescription("XY Plot");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var1.getNearestDayOfWeek((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "1-January-1900"+ "'", var2.equals("1-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var3);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    var2.setStartValue(0.25d);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.chart.util.GradientPaintTransformer var6 = var2.getGradientPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.axis.AxisSpace var9 = var7.getFixedDomainAxisSpace();
    var7.setBackgroundImageAlignment(0);
    org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var14 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var15 = null;
    java.awt.Rectangle var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    java.awt.geom.AffineTransform var18 = null;
    java.awt.RenderingHints var19 = null;
    java.awt.PaintContext var20 = var14.createContext(var15, var16, var17, var18, var19);
    var12.setBaseSectionOutlinePaint((java.awt.Paint)var14);
    var7.setDomainTickBandPaint((java.awt.Paint)var14);
    org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var27 = var26.clone();
    org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var30 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var31 = null;
    java.awt.Rectangle var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    java.awt.geom.AffineTransform var34 = null;
    java.awt.RenderingHints var35 = null;
    java.awt.PaintContext var36 = var30.createContext(var31, var32, var33, var34, var35);
    var28.setBaseSectionOutlinePaint((java.awt.Paint)var30);
    int var38 = var28.getPieIndex();
    org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var41 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var42 = null;
    java.awt.Rectangle var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    java.awt.geom.AffineTransform var45 = null;
    java.awt.RenderingHints var46 = null;
    java.awt.PaintContext var47 = var41.createContext(var42, var43, var44, var45, var46);
    var39.setBaseSectionOutlinePaint((java.awt.Paint)var41);
    org.jfree.data.xy.XYDataset var50 = null;
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
    var52.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var50, (org.jfree.chart.axis.ValueAxis)var52, var55, var56);
    org.jfree.chart.event.PlotChangeListener var58 = null;
    var57.removeChangeListener(var58);
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
    var57.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var62);
    java.awt.Paint var64 = var62.getTickMarkPaint();
    var39.setSectionOutlinePaint((java.lang.Comparable)1L, var64);
    var28.setLabelShadowPaint(var64);
    var26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var28);
    var26.setStartValue(10.0d);
    org.jfree.chart.util.Layer var70 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addDomainMarker(10, (org.jfree.chart.plot.Marker)var26, var70);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = var7.getRendererForDataset(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var7.getInsets();
//     double var14 = var12.extendWidth(16.2d);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, var20, var21);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     var22.setRenderer(var23);
//     java.awt.Paint var25 = var22.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var26 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var27 = var26.getItemLabelAnchorOffset();
//     var26.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var31 = var22.equals((java.lang.Object)var26);
//     org.jfree.chart.plot.SeriesRenderingOrder var32 = var22.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var34 = var22.getDataset(10);
//     org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var37 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var38 = null;
//     java.awt.Rectangle var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     java.awt.geom.AffineTransform var41 = null;
//     java.awt.RenderingHints var42 = null;
//     java.awt.PaintContext var43 = var37.createContext(var38, var39, var40, var41, var42);
//     var35.setBaseSectionOutlinePaint((java.awt.Paint)var37);
//     int var45 = var35.getPieIndex();
//     org.jfree.chart.labels.PieToolTipGenerator var46 = null;
//     var35.setToolTipGenerator(var46);
//     java.awt.Paint var48 = var35.getShadowPaint();
//     var22.setDomainGridlinePaint(var48);
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     var52.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     var57.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var55, (org.jfree.chart.axis.ValueAxis)var57, var60, var61);
//     org.jfree.chart.plot.DrawingSupplier var63 = var62.getDrawingSupplier();
//     var52.addChangeListener((org.jfree.chart.event.AxisChangeListener)var62);
//     org.jfree.chart.plot.MultiplePiePlot var65 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var66 = var65.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var65);
//     var62.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var67);
//     var67.setTextAntiAlias(false);
//     java.awt.Image var71 = null;
//     var67.setBackgroundImage(var71);
//     java.lang.Object var73 = var67.clone();
//     org.jfree.chart.entity.EntityCollection var76 = null;
//     org.jfree.chart.ChartRenderingInfo var77 = new org.jfree.chart.ChartRenderingInfo(var76);
//     var67.handleClick(0, 10, var77);
//     java.awt.geom.Rectangle2D var79 = var77.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var80 = null;
//     var22.drawAnnotations(var50, var79, var80);
//     java.awt.geom.Rectangle2D var82 = var12.createInsetRectangle(var79);
//     
//     // Checks the contract:  equals-hashcode on var7 and var62
//     assertTrue("Contract failed: equals-hashcode on var7 and var62", var7.equals(var62) ? var7.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var7
//     assertTrue("Contract failed: equals-hashcode on var62 and var7", var62.equals(var7) ? var62.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
    var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
    int var18 = var8.getPieIndex();
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
    var32.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
    org.jfree.chart.event.PlotChangeListener var38 = null;
    var37.removeChangeListener(var38);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
    java.awt.Paint var44 = var42.getTickMarkPaint();
    var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
    var8.setLabelShadowPaint(var44);
    org.jfree.chart.urls.PieURLGenerator var47 = null;
    var8.setLegendLabelURLGenerator(var47);
    var8.setOuterSeparatorExtension(0.2d);
    boolean var51 = var7.equals((java.lang.Object)var8);
    java.lang.String[] var53 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var55 = new java.lang.Comparable[] { 16.2d};
    java.lang.Number[][] var56 = null;
    java.lang.Number[] var57 = null;
    java.lang.Number[][] var58 = new java.lang.Number[][] { var57};
    org.jfree.data.category.DefaultIntervalCategoryDataset var59 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var53, var55, var56, var58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSeriesKeys((java.lang.Comparable[])var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("XY Plot");
//     java.lang.Object var2 = var1.clone();
//     java.lang.String var3 = var1.getToolTipText();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var14, var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var6.addChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var20 = var19.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     var16.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var21);
//     var21.setTextAntiAlias(false);
//     java.awt.Image var25 = null;
//     var21.setBackgroundImage(var25);
//     java.lang.Object var27 = var21.clone();
//     org.jfree.chart.entity.EntityCollection var30 = null;
//     org.jfree.chart.ChartRenderingInfo var31 = new org.jfree.chart.ChartRenderingInfo(var30);
//     var21.handleClick(0, 10, var31);
//     java.awt.geom.Rectangle2D var33 = var31.getChartArea();
//     var1.draw(var4, var33);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var3 = var2.getBasePaint();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.labels.ItemLabelPosition var10 = null;
//     var9.setNegativeItemLabelPositionFallback(var10);
//     java.awt.Shape var12 = var9.getBaseShape();
//     var2.setSeriesShape(28, var12, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var2.", var9.equals(var2) == var2.equals(var9));
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
//     var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
//     int var18 = var8.getPieIndex();
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.awt.geom.AffineTransform var25 = null;
//     java.awt.RenderingHints var26 = null;
//     java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
//     var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
//     java.awt.Paint var44 = var42.getTickMarkPaint();
//     var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
//     var8.setLabelShadowPaint(var44);
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var8.setLegendLabelURLGenerator(var47);
//     var8.setOuterSeparatorExtension(0.2d);
//     boolean var51 = var7.equals((java.lang.Object)var8);
//     java.lang.Comparable var53 = var7.getColumnKey(1);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     int var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getMiddleMillisecond(var3);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     java.awt.Paint var14 = var12.getTickMarkPaint();
//     boolean var15 = var12.isAutoRange();
//     boolean var16 = var12.isAutoRange();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     var18.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, var26, var27);
//     org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
//     var18.addChangeListener((org.jfree.chart.event.AxisChangeListener)var28);
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     double var33 = var32.getLowerBound();
//     float var34 = var32.getTickMarkOutsideLength();
//     boolean var35 = var32.isTickMarksVisible();
//     java.awt.Shape var36 = var32.getLeftArrow();
//     var18.setUpArrow(var36);
//     org.jfree.chart.entity.AxisLabelEntity var40 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var12, var36, "hi!", "Other");
//     
//     // Checks the contract:  equals-hashcode on var28 and var7
//     assertTrue("Contract failed: equals-hashcode on var28 and var7", var28.equals(var7) ? var28.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var7.", var28.equals(var7) == var7.equals(var28));
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.DateTickUnit var1 = var0.getTickUnit();
//     java.util.Date var2 = null;
//     java.lang.String var3 = var1.dateToString(var2);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.data.gantt.TaskSeriesCollection var9 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var10 = var9.getGroup();
    org.jfree.data.general.DatasetChangeEvent var11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var8, (org.jfree.data.general.Dataset)var9);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(100);
    java.lang.String var14 = var13.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var16 = var9.getPercentComplete((java.lang.Comparable)var13, (java.lang.Comparable)"1-January-1900");
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "9-April-1900"+ "'", var14.equals("9-April-1900"));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    org.jfree.chart.axis.Axis var1 = null;
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.2d);
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    var8.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, var11, var12);
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var13.removeChangeListener(var14);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    var13.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var18);
    boolean var20 = var13.isDomainCrosshairVisible();
    org.jfree.chart.util.RectangleEdge var22 = var13.getDomainAxisEdge(68);
    boolean var23 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var22);
    org.jfree.chart.axis.CategoryLabelPosition var24 = var5.getLabelPosition(var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var1, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var2 = var0.toTimelineValue(100L);
    int var3 = var0.getSegmentsExcluded();
    long var5 = var0.getTimeFromLong(1L);
    var0.addException(0L);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var14.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
    org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
    var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var19);
    org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var23 = var22.getDataExtractOrder();
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
    var19.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
    var24.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.event.ChartProgressEvent var30 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0L, var24, 10, (-524308));
    var24.setBackgroundImageAlignment((-1));
    org.jfree.chart.entity.EntityCollection var36 = null;
    org.jfree.chart.ChartRenderingInfo var37 = new org.jfree.chart.ChartRenderingInfo(var36);
    java.lang.Object var38 = var37.clone();
    org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var40 = var24.createBufferedImage(2014, 28, (-10289251), var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 644288400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     var12.resizeRange(100.0d);
//     org.jfree.chart.event.AxisChangeEvent var16 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var12);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     var18.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, var26, var27);
//     org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
//     var18.addChangeListener((org.jfree.chart.event.AxisChangeListener)var28);
//     org.jfree.chart.plot.MultiplePiePlot var31 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var32 = var31.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     var28.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var33);
//     var33.setTextAntiAlias(false);
//     java.awt.Image var37 = null;
//     var33.setBackgroundImage(var37);
//     java.lang.Object var39 = var33.clone();
//     org.jfree.chart.entity.EntityCollection var42 = null;
//     org.jfree.chart.ChartRenderingInfo var43 = new org.jfree.chart.ChartRenderingInfo(var42);
//     var33.handleClick(0, 10, var43);
//     var16.setChart(var33);
//     
//     // Checks the contract:  equals-hashcode on var28 and var7
//     assertTrue("Contract failed: equals-hashcode on var28 and var7", var28.equals(var7) ? var28.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var7.", var28.equals(var7) == var7.equals(var28));
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("UnitType.ABSOLUTE");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var1);
    int var4 = var3.getSubplotCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var6 = var3.getSubplotInfo(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("Other", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     int var10 = var7.getIndexOf(var9);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
//     var11.setBaseItemLabelGenerator(var12, true);
//     boolean var15 = var11.getBaseSeriesVisible();
//     var11.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var22 = var21.getBasePaint();
//     var11.setSeriesFillPaint(10, var22, false);
//     org.jfree.chart.plot.DrawingSupplier var25 = var11.getDrawingSupplier();
//     java.awt.Font var27 = var11.getSeriesItemLabelFont(10);
//     var11.setItemLabelAnchorOffset(90.0d);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = null;
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     var34.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var32, (org.jfree.chart.axis.ValueAxis)var34, var37, var38);
//     org.jfree.chart.event.PlotChangeListener var40 = null;
//     var39.removeChangeListener(var40);
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     var39.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var44);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var46 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var48 = var46.getSeriesPaint((-1));
//     java.awt.Font var51 = var46.getItemLabelFont(1, 1);
//     var44.setTickLabelFont(var51);
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.util.RectangleEdge var55 = null;
//     double var56 = var44.valueToJava2D((-1.0d), var54, var55);
//     java.awt.geom.Rectangle2D var57 = null;
//     var11.drawRangeGridline(var30, var31, (org.jfree.chart.axis.ValueAxis)var44, var57, 2.0d);
//     org.jfree.chart.plot.RingPlot var60 = new org.jfree.chart.plot.RingPlot();
//     double var61 = var60.getInteriorGap();
//     java.awt.Stroke var62 = var60.getBaseSectionOutlineStroke();
//     var11.setBaseOutlineStroke(var62);
//     var7.setDomainZeroBaselineStroke(var62);
//     
//     // Checks the contract:  equals-hashcode on var7 and var39
//     assertTrue("Contract failed: equals-hashcode on var7 and var39", var7.equals(var39) ? var7.hashCode() == var39.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var39.", var7.equals(var39) == var39.equals(var7));
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     boolean var14 = var1.isVerticalTickLabels();
//     var1.setLowerBound(0.0d);
//     var1.setAxisLineVisible(false);
//     org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var25.createContext(var26, var27, var28, var29, var30);
//     var23.setBaseSectionOutlinePaint((java.awt.Paint)var25);
//     int var33 = var23.getPieIndex();
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var36 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var37 = null;
//     java.awt.Rectangle var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     java.awt.geom.AffineTransform var40 = null;
//     java.awt.RenderingHints var41 = null;
//     java.awt.PaintContext var42 = var36.createContext(var37, var38, var39, var40, var41);
//     var34.setBaseSectionOutlinePaint((java.awt.Paint)var36);
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     var47.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var45, (org.jfree.chart.axis.ValueAxis)var47, var50, var51);
//     org.jfree.chart.event.PlotChangeListener var53 = null;
//     var52.removeChangeListener(var53);
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     var52.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var57);
//     java.awt.Paint var59 = var57.getTickMarkPaint();
//     var34.setSectionOutlinePaint((java.lang.Comparable)1L, var59);
//     var23.setLabelShadowPaint(var59);
//     var21.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var23);
//     org.jfree.chart.urls.PieURLGenerator var63 = null;
//     var23.setURLGenerator(var63);
//     boolean var65 = var1.hasListener((java.util.EventListener)var23);
//     
//     // Checks the contract:  equals-hashcode on var11 and var52
//     assertTrue("Contract failed: equals-hashcode on var11 and var52", var11.equals(var52) ? var11.hashCode() == var52.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var52.", var11.equals(var52) == var52.equals(var11));
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var6 = var4.getSeriesPaint((-1));
    java.awt.Font var9 = var4.getItemLabelFont(1, 1);
    org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
    var4.setBasePositiveItemLabelPosition(var10);
    var2.setSeriesPositiveItemLabelPosition(10, var10);
    var2.setBase(0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     java.lang.Number var0 = null;
//     org.jfree.chart.text.TextAnchor var2 = null;
//     org.jfree.chart.plot.IntervalMarker var5 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     var5.setStartValue(0.25d);
//     var5.setAlpha(0.0f);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
//     var10.setBaseItemLabelGenerator(var11, true);
//     org.jfree.chart.urls.StandardCategoryURLGenerator var15 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
//     var10.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var15, false);
//     org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition();
//     var10.setBasePositiveItemLabelPosition(var18, true);
//     org.jfree.chart.text.TextAnchor var21 = var18.getRotationAnchor();
//     var5.setLabelTextAnchor(var21);
//     org.jfree.chart.axis.NumberTick var24 = new org.jfree.chart.axis.NumberTick(var0, "", var2, var21, 0.05d);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var3 = null;
//     org.jfree.chart.ChartRenderingInfo var4 = new org.jfree.chart.ChartRenderingInfo(var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Point2D var7 = null;
//     var0.zoomDomainAxes(4.0d, 2.0d, var6, var7);
//     org.jfree.chart.entity.EntityCollection var11 = null;
//     org.jfree.chart.ChartRenderingInfo var12 = new org.jfree.chart.ChartRenderingInfo(var11);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     var21.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, var24, var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     var16.addChangeListener((org.jfree.chart.event.AxisChangeListener)var26);
//     java.awt.Paint var29 = var26.getRangeCrosshairPaint();
//     java.awt.geom.Point2D var30 = var26.getQuadrantOrigin();
//     var0.zoomDomainAxes(0.0d, 90.0d, var14, var30);
//     
//     // Checks the contract:  equals-hashcode on var4 and var12
//     assertTrue("Contract failed: equals-hashcode on var4 and var12", var4.equals(var12) ? var4.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var4
//     assertTrue("Contract failed: equals-hashcode on var12 and var4", var12.equals(var4) ? var12.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var13
//     assertTrue("Contract failed: equals-hashcode on var5 and var13", var5.equals(var13) ? var5.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var5
//     assertTrue("Contract failed: equals-hashcode on var13 and var5", var13.equals(var5) ? var13.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var14
//     assertTrue("Contract failed: equals-hashcode on var6 and var14", var6.equals(var14) ? var6.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var6
//     assertTrue("Contract failed: equals-hashcode on var14 and var6", var14.equals(var6) ? var14.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     var1.removeFragment(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var9 = null;
//     var8.setBaseItemLabelGenerator(var9, true);
//     org.jfree.chart.urls.StandardCategoryURLGenerator var13 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
//     var8.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var13, false);
//     org.jfree.chart.labels.ItemLabelPosition var16 = new org.jfree.chart.labels.ItemLabelPosition();
//     var8.setBasePositiveItemLabelPosition(var16, true);
//     org.jfree.chart.text.TextAnchor var19 = var16.getRotationAnchor();
//     var3.draw(var5, 100.0f, 2.0f, var19, 100.0f, 0.5f, 0.0d);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("9-April-1900", "RectangleEdge.TOP", var3);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.setObject((java.lang.Object)15, (java.lang.Comparable)100.0d, (java.lang.Comparable)0.0f);
    var0.removeObject((java.lang.Comparable)28, (java.lang.Comparable)true);
    org.jfree.chart.labels.StandardCategoryToolTipGenerator var8 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var12.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    var17.setRenderer(var18);
    java.awt.Paint var20 = var17.getNoDataMessagePaint();
    var9.setLabelOutlinePaint(var20);
    boolean var22 = var8.equals((java.lang.Object)var20);
    boolean var23 = var0.equals((java.lang.Object)var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((java.lang.Comparable)(short)10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextBlockAnchor var1 = var0.getLabelAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
//     var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var11);
//     org.jfree.chart.axis.AxisLocation var26 = var7.getRangeAxisLocation((-10289251));
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var27 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var28 = var27.getObjectIcon();
//     javax.swing.Icon var29 = var27.getMinIcon();
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
//     java.awt.Paint var44 = var42.getTickMarkPaint();
//     boolean var45 = var42.isAutoRange();
//     java.awt.Stroke var46 = var42.getTickMarkStroke();
//     var27.setGroupStroke(var46);
//     var7.setDomainCrosshairStroke(var46);
//     
//     // Checks the contract:  equals-hashcode on var21 and var37
//     assertTrue("Contract failed: equals-hashcode on var21 and var37", var21.equals(var37) ? var21.hashCode() == var37.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var37.", var21.equals(var37) == var37.equals(var21));
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    boolean var14 = var1.isVerticalTickLabels();
    var1.setLowerBound(0.0d);
    var1.setAxisLineVisible(false);
    org.jfree.chart.axis.NumberTickUnit var19 = var1.getTickUnit();
    var1.setTickLabelsVisible(false);
    boolean var22 = var1.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
//     var2.setBaseItemLabelGenerator(var3, true);
//     boolean var6 = var2.getBaseSeriesVisible();
//     var2.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var13 = var12.getBasePaint();
//     var2.setSeriesFillPaint(10, var13, false);
//     org.jfree.chart.plot.DrawingSupplier var16 = var2.getDrawingSupplier();
//     java.awt.Font var18 = var2.getSeriesItemLabelFont(10);
//     var2.setItemLabelAnchorOffset(90.0d);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var28, var29);
//     org.jfree.chart.event.PlotChangeListener var31 = null;
//     var30.removeChangeListener(var31);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var39 = var37.getSeriesPaint((-1));
//     java.awt.Font var42 = var37.getItemLabelFont(1, 1);
//     var35.setTickLabelFont(var42);
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var35.valueToJava2D((-1.0d), var45, var46);
//     java.awt.geom.Rectangle2D var48 = null;
//     var2.drawRangeGridline(var21, var22, (org.jfree.chart.axis.ValueAxis)var35, var48, 2.0d);
//     org.jfree.chart.plot.RingPlot var51 = new org.jfree.chart.plot.RingPlot();
//     double var52 = var51.getInteriorGap();
//     java.awt.Stroke var53 = var51.getBaseSectionOutlineStroke();
//     var2.setBaseOutlineStroke(var53);
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var53};
//     org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     var57.resizeRange(0.2d);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
//     var62.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var60, (org.jfree.chart.axis.ValueAxis)var62, var65, var66);
//     org.jfree.chart.event.PlotChangeListener var68 = null;
//     var67.removeChangeListener(var68);
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("");
//     var67.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var72);
//     java.awt.Paint var74 = var72.getTickMarkPaint();
//     boolean var75 = var72.isAutoRange();
//     java.awt.Stroke var76 = var72.getTickMarkStroke();
//     var57.setTickMarkStroke(var76);
//     java.awt.Stroke[] var78 = new java.awt.Stroke[] { var76};
//     java.awt.Shape[] var79 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var80 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var55, var78, var79);
//     
//     // Checks the contract:  equals-hashcode on var30 and var67
//     assertTrue("Contract failed: equals-hashcode on var30 and var67", var30.equals(var67) ? var30.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var30
//     assertTrue("Contract failed: equals-hashcode on var67 and var30", var67.equals(var30) ? var67.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    var3.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var6, var7);
    org.jfree.chart.event.PlotChangeListener var9 = null;
    var8.removeChangeListener(var9);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    var8.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var13);
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var17 = var15.getSeriesPaint((-1));
    java.awt.Font var20 = var15.getItemLabelFont(1, 1);
    var13.setTickLabelFont(var20);
    java.text.NumberFormat var22 = null;
    var13.setNumberFormatOverride(var22);
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
    var25.resizeRange(0.2d);
    var25.setLabelToolTip("hi!");
    org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var32 = var30.getSeriesPaint((-1));
    java.awt.Font var35 = var30.getItemLabelFont(1, 1);
    var25.setLabelFont(var35);
    java.lang.String var37 = var25.getLabelToolTip();
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var25, var38);
    java.awt.Color var41 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var42 = null;
    java.awt.Rectangle var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    java.awt.geom.AffineTransform var45 = null;
    java.awt.RenderingHints var46 = null;
    java.awt.PaintContext var47 = var41.createContext(var42, var43, var44, var45, var46);
    org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var41);
    int var49 = var41.getAlpha();
    var39.setDomainTickBandPaint((java.awt.Paint)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "hi!"+ "'", var37.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 255);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.toTimelineValue(100L);
//     int var3 = var0.getSegmentsExcluded();
//     long var5 = var0.getTimeFromLong(1L);
//     var0.addException(0L);
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
//     org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
//     var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var19);
//     org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var23 = var22.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
//     var19.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
//     var24.setBackgroundImageAlpha(1.0f);
//     org.jfree.chart.event.ChartProgressEvent var30 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0L, var24, 10, (-524308));
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var37, var40, var41);
//     org.jfree.chart.plot.DrawingSupplier var43 = var42.getDrawingSupplier();
//     var32.addChangeListener((org.jfree.chart.event.AxisChangeListener)var42);
//     org.jfree.chart.plot.MultiplePiePlot var45 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var46 = var45.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var45);
//     var42.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var47);
//     var47.setBackgroundImageAlpha(1.0f);
//     java.lang.Object var51 = var47.clone();
//     var30.setChart(var47);
//     
//     // Checks the contract:  equals-hashcode on var19 and var42
//     assertTrue("Contract failed: equals-hashcode on var19 and var42", var19.equals(var42) ? var19.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var19
//     assertTrue("Contract failed: equals-hashcode on var42 and var19", var42.equals(var19) ? var42.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var43
//     assertTrue("Contract failed: equals-hashcode on var20 and var43", var20.equals(var43) ? var20.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var20
//     assertTrue("Contract failed: equals-hashcode on var43 and var20", var43.equals(var20) ? var43.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var45
//     assertTrue("Contract failed: equals-hashcode on var22 and var45", var22.equals(var45) ? var22.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var22
//     assertTrue("Contract failed: equals-hashcode on var45 and var22", var45.equals(var22) ? var45.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var47
//     assertTrue("Contract failed: equals-hashcode on var24 and var47", var24.equals(var47) ? var24.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var24
//     assertTrue("Contract failed: equals-hashcode on var47 and var24", var47.equals(var24) ? var47.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     var2.resizeRange(0.2d);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, var10, var11);
//     org.jfree.chart.event.PlotChangeListener var13 = null;
//     var12.removeChangeListener(var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var17);
//     java.awt.Paint var19 = var17.getTickMarkPaint();
//     boolean var20 = var17.isAutoRange();
//     java.awt.Stroke var21 = var17.getTickMarkStroke();
//     var2.setTickMarkStroke(var21);
//     boolean var23 = var0.equals((java.lang.Object)var2);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     var27.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.plot.DrawingSupplier var38 = var37.getDrawingSupplier();
//     var27.addChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
//     org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var41 = var40.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var40);
//     var37.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var42);
//     var42.setTextAntiAlias(false);
//     java.awt.Image var46 = null;
//     var42.setBackgroundImage(var46);
//     java.lang.Object var48 = var42.clone();
//     org.jfree.chart.entity.EntityCollection var51 = null;
//     org.jfree.chart.ChartRenderingInfo var52 = new org.jfree.chart.ChartRenderingInfo(var51);
//     var42.handleClick(0, 10, var52);
//     java.awt.geom.Rectangle2D var54 = var52.getChartArea();
//     org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var58 = null;
//     org.jfree.chart.ChartRenderingInfo var59 = new org.jfree.chart.ChartRenderingInfo(var58);
//     java.lang.Object var60 = var59.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var61 = new org.jfree.chart.plot.PlotRenderingInfo(var59);
//     java.awt.geom.Point2D var62 = null;
//     var55.zoomDomainAxes(4.0d, 2.0d, var61, var62);
//     java.awt.geom.Rectangle2D var64 = var61.getDataArea();
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     var67.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var65, (org.jfree.chart.axis.ValueAxis)var67, var70, var71);
//     org.jfree.chart.event.PlotChangeListener var73 = null;
//     var72.removeChangeListener(var73);
//     org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis("");
//     var72.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var77);
//     boolean var79 = var72.isDomainCrosshairVisible();
//     org.jfree.chart.util.RectangleEdge var81 = var72.getDomainAxisEdge(68);
//     org.jfree.chart.plot.PolarPlot var82 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var85 = null;
//     org.jfree.chart.ChartRenderingInfo var86 = new org.jfree.chart.ChartRenderingInfo(var85);
//     java.lang.Object var87 = var86.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var88 = new org.jfree.chart.plot.PlotRenderingInfo(var86);
//     java.awt.geom.Point2D var89 = null;
//     var82.zoomDomainAxes(4.0d, 2.0d, var88, var89);
//     java.awt.geom.Rectangle2D var91 = var88.getDataArea();
//     org.jfree.chart.axis.AxisState var92 = var2.draw(var24, 32.2d, var54, var64, var81, var88);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    org.jfree.data.time.RegularTimePeriod var3 = var1.next();
    org.jfree.data.gantt.Task var4 = new org.jfree.data.gantt.Task("black", (org.jfree.data.time.TimePeriod)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var6 = var4.getSubtask(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    int var2 = var1.getPassCount();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var5.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, var8, var9);
    org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
    org.jfree.chart.axis.AxisLocation var12 = var10.getDomainAxisLocation();
    boolean var13 = var1.equals((java.lang.Object)var10);
    var10.zoom(0.0d);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var10.getRangeMarkers(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.awt.geom.AffineTransform var10 = null;
    java.awt.RenderingHints var11 = null;
    java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
    var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
    int var14 = var4.getPieIndex();
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
    var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var28.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    org.jfree.chart.event.PlotChangeListener var34 = null;
    var33.removeChangeListener(var34);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
    java.awt.Paint var40 = var38.getTickMarkPaint();
    var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
    var4.setLabelShadowPaint(var40);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    org.jfree.chart.LegendItemCollection var44 = var4.getLegendItems();
    org.jfree.chart.LegendItem var45 = null;
    var44.add(var45);
    java.util.Iterator var47 = var44.iterator();
    int var48 = var44.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.toTimelineValue(100L);
//     var0.addException((-1L));
//     java.util.Date var6 = var0.getDate(61200000L);
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(var6, var7);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
//     var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
//     int var18 = var8.getPieIndex();
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.awt.geom.AffineTransform var25 = null;
//     java.awt.RenderingHints var26 = null;
//     java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
//     var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
//     java.awt.Paint var44 = var42.getTickMarkPaint();
//     var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
//     var8.setLabelShadowPaint(var44);
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var8.setLegendLabelURLGenerator(var47);
//     var8.setOuterSeparatorExtension(0.2d);
//     boolean var51 = var7.equals((java.lang.Object)var8);
//     java.util.List var52 = var7.getColumnKeys();
//     int var54 = var7.getColumnIndex((java.lang.Comparable)2014);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    boolean var1 = var0.getFillBox();
    boolean var4 = var0.isItemLabelVisible(100, 0);
    java.awt.Paint var5 = var0.getArtifactPaint();
    var0.setItemMargin(1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-15.8d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)1);
    java.util.List var3 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getColumnKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeEvent var8 = null;
//     var7.notifyListeners(var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
//     boolean var24 = var11.isVerticalTickLabels();
//     var11.setLowerBound(0.0d);
//     var11.setAxisLineVisible(false);
//     org.jfree.chart.axis.NumberTickUnit var29 = var11.getTickUnit();
//     var11.setTickLabelsVisible(false);
//     org.jfree.data.Range var32 = var7.getDataRange((org.jfree.chart.axis.ValueAxis)var11);
//     
//     // Checks the contract:  equals-hashcode on var7 and var21
//     assertTrue("Contract failed: equals-hashcode on var7 and var21", var7.equals(var21) ? var7.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var7
//     assertTrue("Contract failed: equals-hashcode on var21 and var7", var21.equals(var7) ? var21.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    var16.setTextAntiAlias(false);
    java.awt.Image var20 = null;
    var16.setBackgroundImage(var20);
    java.lang.Object var22 = var16.clone();
    org.jfree.chart.entity.EntityCollection var25 = null;
    org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo(var25);
    var16.handleClick(0, 10, var26);
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var29 = var28.clone();
    boolean var30 = var28.getNotify();
    var16.addSubtitle((org.jfree.chart.title.Title)var28);
    org.jfree.chart.entity.EntityCollection var35 = null;
    org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo(var35);
    java.lang.Object var37 = var36.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var38 = var16.createBufferedImage(68, 2014, 0, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getSeriesKey(7);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    int var3 = var0.getColumnIndex((java.lang.Comparable)1);
    int var5 = var0.getRowIndex((java.lang.Comparable)(byte)(-1));
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-10289251));
    org.jfree.data.general.SeriesChangeEvent var8 = null;
    var0.seriesChanged(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var13 = var0.getEndValue((java.lang.Comparable)(-1.0f), (java.lang.Comparable)true, 2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    var0.setAutoPopulateSeriesStroke(false);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var5.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    var10.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, var13, var14);
    org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
    var5.addChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
    org.jfree.chart.plot.MultiplePiePlot var18 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var19 = var18.getDataExtractOrder();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
    var15.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var20);
    var20.setTextAntiAlias(false);
    java.awt.Image var24 = null;
    var20.setBackgroundImage(var24);
    java.lang.Object var26 = var20.clone();
    org.jfree.chart.entity.EntityCollection var29 = null;
    org.jfree.chart.ChartRenderingInfo var30 = new org.jfree.chart.ChartRenderingInfo(var29);
    var20.handleClick(0, 10, var30);
    java.awt.geom.Rectangle2D var32 = var30.getChartArea();
    org.jfree.chart.plot.CategoryPlot var33 = null;
    org.jfree.chart.entity.EntityCollection var35 = null;
    org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo(var35);
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var39 = var0.initialise(var3, var32, var33, (-1), var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var2 = var0.getSeriesPaint((-1));
//     java.awt.Font var5 = var0.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var6 = new org.jfree.chart.labels.ItemLabelPosition();
//     var0.setBasePositiveItemLabelPosition(var6);
//     org.jfree.chart.labels.ItemLabelAnchor var8 = var6.getItemLabelAnchor();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     var11.setStartValue(0.25d);
//     var11.setAlpha(0.0f);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var17 = null;
//     var16.setBaseItemLabelGenerator(var17, true);
//     org.jfree.chart.urls.StandardCategoryURLGenerator var21 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
//     var16.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var21, false);
//     org.jfree.chart.labels.ItemLabelPosition var24 = new org.jfree.chart.labels.ItemLabelPosition();
//     var16.setBasePositiveItemLabelPosition(var24, true);
//     org.jfree.chart.text.TextAnchor var27 = var24.getRotationAnchor();
//     var11.setLabelTextAnchor(var27);
//     org.jfree.chart.labels.ItemLabelPosition var29 = new org.jfree.chart.labels.ItemLabelPosition(var8, var27);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var5.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, var8, var9);
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    var10.setRenderer(var11);
    java.awt.Paint var13 = var10.getNoDataMessagePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var15 = var14.getItemLabelAnchorOffset();
    var14.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
    boolean var19 = var10.equals((java.lang.Object)var14);
    org.jfree.chart.plot.SeriesRenderingOrder var20 = var10.getSeriesRenderingOrder();
    org.jfree.data.xy.XYDataset var22 = var10.getDataset(10);
    org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var26 = null;
    java.awt.Rectangle var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    java.awt.geom.AffineTransform var29 = null;
    java.awt.RenderingHints var30 = null;
    java.awt.PaintContext var31 = var25.createContext(var26, var27, var28, var29, var30);
    var23.setBaseSectionOutlinePaint((java.awt.Paint)var25);
    int var33 = var23.getPieIndex();
    org.jfree.chart.labels.PieToolTipGenerator var34 = null;
    var23.setToolTipGenerator(var34);
    java.awt.Paint var36 = var23.getShadowPaint();
    var10.setDomainGridlinePaint(var36);
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    var40.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
    var45.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var43, (org.jfree.chart.axis.ValueAxis)var45, var48, var49);
    org.jfree.chart.plot.DrawingSupplier var51 = var50.getDrawingSupplier();
    var40.addChangeListener((org.jfree.chart.event.AxisChangeListener)var50);
    org.jfree.chart.plot.MultiplePiePlot var53 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var54 = var53.getDataExtractOrder();
    org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var53);
    var50.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var55);
    var55.setTextAntiAlias(false);
    java.awt.Image var59 = null;
    var55.setBackgroundImage(var59);
    java.lang.Object var61 = var55.clone();
    org.jfree.chart.entity.EntityCollection var64 = null;
    org.jfree.chart.ChartRenderingInfo var65 = new org.jfree.chart.ChartRenderingInfo(var64);
    var55.handleClick(0, 10, var65);
    java.awt.geom.Rectangle2D var67 = var65.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var68 = null;
    var10.drawAnnotations(var38, var67, var68);
    org.jfree.chart.plot.CategoryPlot var70 = null;
    org.jfree.chart.axis.CategoryAxis var72 = new org.jfree.chart.axis.CategoryAxis("");
    java.awt.Paint var74 = var72.getTickLabelPaint((java.lang.Comparable)(short)1);
    org.jfree.chart.axis.CategoryLabelPositions var75 = var72.getCategoryLabelPositions();
    org.jfree.chart.axis.ValueAxis var76 = null;
    org.jfree.data.xy.XYDataset var77 = null;
    org.jfree.chart.axis.NumberAxis var79 = new org.jfree.chart.axis.NumberAxis("");
    var79.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var82 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var83 = null;
    org.jfree.chart.plot.XYPlot var84 = new org.jfree.chart.plot.XYPlot(var77, (org.jfree.chart.axis.ValueAxis)var79, var82, var83);
    org.jfree.chart.plot.DrawingSupplier var85 = var84.getDrawingSupplier();
    org.jfree.data.gantt.TaskSeriesCollection var86 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var87 = var86.getGroup();
    org.jfree.data.general.DatasetChangeEvent var88 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var85, (org.jfree.data.general.Dataset)var86);
    org.jfree.chart.plot.MultiplePiePlot var89 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var67, var70, var72, var76, (org.jfree.data.category.CategoryDataset)var86, 1, 100, 28);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:java.awt.Color[r=0,g=0,b=0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nXY Plot", 0, 2014);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     var1.resizeRange(0.2d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.event.PlotChangeListener var12 = null;
//     var11.removeChangeListener(var12);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var16);
//     java.awt.Paint var18 = var16.getTickMarkPaint();
//     boolean var19 = var16.isAutoRange();
//     java.awt.Stroke var20 = var16.getTickMarkStroke();
//     var1.setTickMarkStroke(var20);
//     java.awt.Paint var22 = var1.getTickMarkPaint();
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var28, var29);
//     org.jfree.chart.plot.DrawingSupplier var31 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var32 = var30.getDomainAxisLocation();
//     var30.mapDatasetToDomainAxis(15, 1);
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var30);
//     org.jfree.chart.event.ChartProgressListener var37 = null;
//     var36.addProgressListener(var37);
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var42.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var40, (org.jfree.chart.axis.ValueAxis)var42, var45, var46);
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     var47.setRenderer(var48);
//     java.awt.Paint var50 = var47.getNoDataMessagePaint();
//     var39.setLabelOutlinePaint(var50);
//     java.awt.Stroke var52 = var39.getLabelLinkStroke();
//     var36.setBorderStroke(var52);
//     org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var36, 68, 68);
//     
//     // Checks the contract:  equals-hashcode on var47 and var11
//     assertTrue("Contract failed: equals-hashcode on var47 and var11", var47.equals(var11) ? var47.hashCode() == var11.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var47 and var11.", var47.equals(var11) == var11.equals(var47));
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var3 = null;
//     java.awt.Rectangle var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.AffineTransform var6 = null;
//     java.awt.RenderingHints var7 = null;
//     java.awt.PaintContext var8 = var2.createContext(var3, var4, var5, var6, var7);
//     var0.setBaseSectionOutlinePaint((java.awt.Paint)var2);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
//     java.awt.Paint var24 = var11.getAxisLinePaint();
//     var0.setBaseSectionPaint(var24);
//     org.jfree.chart.urls.PieURLGenerator var26 = null;
//     var0.setLegendLabelURLGenerator(var26);
//     var0.setCircular(false);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.plot.DrawingSupplier var38 = var37.getDrawingSupplier();
//     org.jfree.data.gantt.TaskSeriesCollection var39 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetGroup var40 = var39.getGroup();
//     org.jfree.data.general.DatasetChangeEvent var41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var38, (org.jfree.data.general.Dataset)var39);
//     var0.setDrawingSupplier(var38);
//     
//     // Checks the contract:  equals-hashcode on var21 and var37
//     assertTrue("Contract failed: equals-hashcode on var21 and var37", var21.equals(var37) ? var21.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var21
//     assertTrue("Contract failed: equals-hashcode on var37 and var21", var37.equals(var21) ? var37.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var38
//     assertTrue("Contract failed: equals-hashcode on var22 and var38", var22.equals(var38) ? var22.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var22
//     assertTrue("Contract failed: equals-hashcode on var38 and var22", var38.equals(var22) ? var38.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.addOptionalLibrary("");
    var0.setLicenceText("XY Plot");
    org.jfree.chart.ui.ProjectInfo var5 = new org.jfree.chart.ui.ProjectInfo();
    boolean var6 = var0.equals((java.lang.Object)var5);
    var0.setInfo("java.awt.Color[r=0,g=0,b=0]");
    java.lang.String var9 = var0.toString();
    org.jfree.data.gantt.TaskSeries var11 = new org.jfree.data.gantt.TaskSeries("");
    org.jfree.data.gantt.TaskSeriesCollection var12 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var12, false);
    var11.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var12);
    boolean var16 = var0.equals((java.lang.Object)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var18 = var12.getColumnKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:java.awt.Color[r=0,g=0,b=0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nXY Plot"+ "'", var9.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:java.awt.Color[r=0,g=0,b=0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nXY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(68, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    var4.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, var7, var8);
    org.jfree.chart.plot.DrawingSupplier var10 = var9.getDrawingSupplier();
    org.jfree.chart.axis.AxisSpace var11 = var9.getFixedDomainAxisSpace();
    var9.setBackgroundImageAlignment(0);
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var16 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    java.awt.geom.AffineTransform var20 = null;
    java.awt.RenderingHints var21 = null;
    java.awt.PaintContext var22 = var16.createContext(var17, var18, var19, var20, var21);
    var14.setBaseSectionOutlinePaint((java.awt.Paint)var16);
    var9.setDomainTickBandPaint((java.awt.Paint)var16);
    var0.setSectionPaint((java.lang.Comparable)true, (java.awt.Paint)var16);
    org.jfree.chart.util.Rotation var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDirection(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("");
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var5.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, var8, var9);
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    var10.setRenderer(var11);
    java.awt.Paint var13 = var10.getNoDataMessagePaint();
    var2.setLabelOutlinePaint(var13);
    java.awt.Stroke var15 = var2.getLabelLinkStroke();
    boolean var16 = var1.equals((java.lang.Object)var2);
    var1.removeAll();
    var1.setNotify(false);
    var1.setKey((java.lang.Comparable)24.200000000000003d);
    var1.removeAll();
    java.lang.Comparable var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setKey(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var3 = var2.getBasePaint();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getPositiveItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeEvent var8 = null;
//     var7.notifyListeners(var8);
//     org.jfree.data.general.DatasetChangeEvent var10 = null;
//     var7.datasetChanged(var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     var7.setRenderer(var12);
//     boolean var14 = var7.isDomainGridlinesVisible();
//     java.awt.Paint var16 = var7.getQuadrantPaint(0);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     var19.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var22, var23);
//     org.jfree.chart.event.PlotChangeListener var25 = null;
//     var24.removeChangeListener(var25);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = var24.getRendererForDataset(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var24.getInsets();
//     double var31 = var29.extendWidth(0.2d);
//     var7.setInsets(var29);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 2.0d);
    boolean var5 = var2.intersects(0.25d, 100.0d);
    boolean var8 = var2.intersects(32.2d, 1.0d);
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.combine(var2, var9);
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(var9, 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 2.0d, 10.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var6 = var5.getGroup();
    org.jfree.chart.title.LegendItemBlockContainer var8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)2);
    var8.setID("black");
    java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var13 = null;
    java.awt.Rectangle var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    java.awt.geom.AffineTransform var16 = null;
    java.awt.RenderingHints var17 = null;
    java.awt.PaintContext var18 = var12.createContext(var13, var14, var15, var16, var17);
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    boolean var20 = var8.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("Other", 7, (-10289251));
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("");
//     java.awt.Paint var3 = var1.getTickLabelPaint((java.lang.Comparable)(short)1);
//     org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var14.setRenderer(var15);
//     java.awt.Paint var17 = var14.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var19 = var18.getItemLabelAnchorOffset();
//     var18.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var23 = var14.equals((java.lang.Object)var18);
//     org.jfree.chart.plot.SeriesRenderingOrder var24 = var14.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var26 = var14.getDataset(10);
//     org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var29 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var30 = null;
//     java.awt.Rectangle var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     java.awt.geom.AffineTransform var33 = null;
//     java.awt.RenderingHints var34 = null;
//     java.awt.PaintContext var35 = var29.createContext(var30, var31, var32, var33, var34);
//     var27.setBaseSectionOutlinePaint((java.awt.Paint)var29);
//     int var37 = var27.getPieIndex();
//     org.jfree.chart.labels.PieToolTipGenerator var38 = null;
//     var27.setToolTipGenerator(var38);
//     java.awt.Paint var40 = var27.getShadowPaint();
//     var14.setDomainGridlinePaint(var40);
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     var44.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
//     var49.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var47, (org.jfree.chart.axis.ValueAxis)var49, var52, var53);
//     org.jfree.chart.plot.DrawingSupplier var55 = var54.getDrawingSupplier();
//     var44.addChangeListener((org.jfree.chart.event.AxisChangeListener)var54);
//     org.jfree.chart.plot.MultiplePiePlot var57 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var58 = var57.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var57);
//     var54.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var59);
//     var59.setTextAntiAlias(false);
//     java.awt.Image var63 = null;
//     var59.setBackgroundImage(var63);
//     java.lang.Object var65 = var59.clone();
//     org.jfree.chart.entity.EntityCollection var68 = null;
//     org.jfree.chart.ChartRenderingInfo var69 = new org.jfree.chart.ChartRenderingInfo(var68);
//     var59.handleClick(0, 10, var69);
//     java.awt.geom.Rectangle2D var71 = var69.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     var14.drawAnnotations(var42, var71, var72);
//     org.jfree.data.xy.XYDataset var74 = null;
//     org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("");
//     var76.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var79 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var80 = null;
//     org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot(var74, (org.jfree.chart.axis.ValueAxis)var76, var79, var80);
//     org.jfree.chart.plot.DrawingSupplier var82 = var81.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var83 = var81.getDomainAxisLocation();
//     var81.mapDatasetToDomainAxis(15, 1);
//     var81.configureDomainAxes();
//     java.lang.Object var88 = var81.clone();
//     org.jfree.chart.util.RectangleEdge var89 = var81.getDomainAxisEdge();
//     double var90 = var1.getCategoryEnd(0, 68, var71, var89);
//     
//     // Checks the contract:  equals-hashcode on var55 and var82
//     assertTrue("Contract failed: equals-hashcode on var55 and var82", var55.equals(var82) ? var55.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var55
//     assertTrue("Contract failed: equals-hashcode on var82 and var55", var82.equals(var55) ? var82.hashCode() == var55.hashCode() : true);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 2.0d, 10.0d);
    org.jfree.data.general.Dataset var6 = null;
    org.jfree.chart.title.LegendItemBlockContainer var8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var6, (java.lang.Comparable)1.0f);
    java.lang.String var9 = var8.getID();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(1.0d, 2.0d);
    org.jfree.chart.block.LengthConstraintType var14 = var13.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var16 = var13.toFixedWidth(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var17 = var0.arrange((org.jfree.chart.block.BlockContainer)var8, var10, var16);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("LegendItemEntity: seriesKey=null, dataset=null", "9-April-1900", "black", "Pie Plot");

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    double var2 = var1.getLowerBound();
    float var3 = var1.getTickMarkOutsideLength();
    boolean var4 = var1.isTickMarksVisible();
    java.awt.Shape var5 = var1.getLeftArrow();
    float var6 = var1.getTickMarkInsideLength();
    double var7 = var1.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = null;
    var0.setBaseItemLabelGenerator(var1, true);
    boolean var4 = var0.getBaseSeriesVisible();
    var0.setIncludeBaseInRange(false);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var11 = var10.getBasePaint();
    var0.setSeriesFillPaint(10, var11, false);
    org.jfree.chart.plot.DrawingSupplier var14 = var0.getDrawingSupplier();
    java.awt.Font var16 = var0.getSeriesItemLabelFont(10);
    var0.setItemLabelAnchorOffset(90.0d);
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = null;
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    var23.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, var26, var27);
    org.jfree.chart.event.PlotChangeListener var29 = null;
    var28.removeChangeListener(var29);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    var28.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var33);
    org.jfree.chart.renderer.category.IntervalBarRenderer var35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var37 = var35.getSeriesPaint((-1));
    java.awt.Font var40 = var35.getItemLabelFont(1, 1);
    var33.setTickLabelFont(var40);
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.chart.util.RectangleEdge var44 = null;
    double var45 = var33.valueToJava2D((-1.0d), var43, var44);
    java.awt.geom.Rectangle2D var46 = null;
    var0.drawRangeGridline(var19, var20, (org.jfree.chart.axis.ValueAxis)var33, var46, 2.0d);
    double var49 = var33.getFixedDimension();
    var33.setTickMarkInsideLength((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     var7.setStartValue(0.25d);
//     var7.setAlpha(0.0f);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var13 = null;
//     var12.setBaseItemLabelGenerator(var13, true);
//     org.jfree.chart.urls.StandardCategoryURLGenerator var17 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
//     var12.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var17, false);
//     org.jfree.chart.labels.ItemLabelPosition var20 = new org.jfree.chart.labels.ItemLabelPosition();
//     var12.setBasePositiveItemLabelPosition(var20, true);
//     org.jfree.chart.text.TextAnchor var23 = var20.getRotationAnchor();
//     var7.setLabelTextAnchor(var23);
//     var1.draw(var2, 10.0f, 0.5f, var23, 0.0f, 10.0f, 24.200000000000003d);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var3 = var1.getRowIndex((java.lang.Comparable)1);
    int var5 = var1.getRowIndex((java.lang.Comparable)false);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, 16.2d);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var1.getValue(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var1 = var0.getAngleGridlinePaint();
//     var0.addCornerTextItem("Other");
//     org.jfree.chart.entity.EntityCollection var5 = null;
//     org.jfree.chart.ChartRenderingInfo var6 = new org.jfree.chart.ChartRenderingInfo(var5);
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     int var9 = var8.getSubplotCount();
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     var17.setRenderer(var18);
//     java.awt.Paint var20 = var17.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var22 = var21.getItemLabelAnchorOffset();
//     var21.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var26 = var17.equals((java.lang.Object)var21);
//     org.jfree.chart.plot.SeriesRenderingOrder var27 = var17.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var29 = var17.getDataset(10);
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var32 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var33 = null;
//     java.awt.Rectangle var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     java.awt.geom.AffineTransform var36 = null;
//     java.awt.RenderingHints var37 = null;
//     java.awt.PaintContext var38 = var32.createContext(var33, var34, var35, var36, var37);
//     var30.setBaseSectionOutlinePaint((java.awt.Paint)var32);
//     int var40 = var30.getPieIndex();
//     org.jfree.chart.labels.PieToolTipGenerator var41 = null;
//     var30.setToolTipGenerator(var41);
//     java.awt.Paint var43 = var30.getShadowPaint();
//     var17.setDomainGridlinePaint(var43);
//     org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var49 = null;
//     org.jfree.chart.ChartRenderingInfo var50 = new org.jfree.chart.ChartRenderingInfo(var49);
//     java.lang.Object var51 = var50.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var52 = new org.jfree.chart.plot.PlotRenderingInfo(var50);
//     java.awt.geom.Point2D var53 = null;
//     var46.zoomDomainAxes(4.0d, 2.0d, var52, var53);
//     java.awt.geom.Rectangle2D var55 = var52.getDataArea();
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     var57.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
//     var62.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var60, (org.jfree.chart.axis.ValueAxis)var62, var65, var66);
//     org.jfree.chart.plot.DrawingSupplier var68 = var67.getDrawingSupplier();
//     var57.addChangeListener((org.jfree.chart.event.AxisChangeListener)var67);
//     java.awt.Paint var70 = var67.getRangeCrosshairPaint();
//     java.awt.geom.Point2D var71 = var67.getQuadrantOrigin();
//     var17.zoomRangeAxes(100.0d, var52, var71);
//     var0.zoomDomainAxes(16.2d, var8, var71);
//     
//     // Checks the contract:  equals-hashcode on var6 and var50
//     assertTrue("Contract failed: equals-hashcode on var6 and var50", var6.equals(var50) ? var6.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var6
//     assertTrue("Contract failed: equals-hashcode on var50 and var6", var50.equals(var6) ? var50.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var51
//     assertTrue("Contract failed: equals-hashcode on var7 and var51", var7.equals(var51) ? var7.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var7
//     assertTrue("Contract failed: equals-hashcode on var51 and var7", var51.equals(var7) ? var51.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var52
//     assertTrue("Contract failed: equals-hashcode on var8 and var52", var8.equals(var52) ? var8.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var8
//     assertTrue("Contract failed: equals-hashcode on var52 and var8", var52.equals(var8) ? var52.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-398));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var2 = var1.getObjectIcon();
    var0.setMinIcon(var2);
    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    var0.setBaseFillPaint((java.awt.Paint)var5);
    java.awt.Paint var7 = var0.getGroupPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    var4.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
    org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
    var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
    org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var18 = var17.getDataExtractOrder();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
    var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
    var19.setTextAntiAlias(false);
    java.awt.Image var23 = null;
    var19.setBackgroundImage(var23);
    java.lang.Object var25 = var19.clone();
    org.jfree.chart.entity.EntityCollection var28 = null;
    org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo(var28);
    var19.handleClick(0, 10, var29);
    java.awt.geom.Rectangle2D var31 = var29.getChartArea();
    org.jfree.chart.plot.CategoryPlot var32 = null;
    org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis("");
    double var35 = var34.getLowerMargin();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    var37.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var40 = null;
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    var42.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var40, (org.jfree.chart.axis.ValueAxis)var42, var45, var46);
    org.jfree.chart.plot.DrawingSupplier var48 = var47.getDrawingSupplier();
    var37.addChangeListener((org.jfree.chart.event.AxisChangeListener)var47);
    boolean var50 = var37.isVerticalTickLabels();
    var37.setLowerBound(0.0d);
    var37.setAxisLineVisible(false);
    org.jfree.chart.axis.NumberTickUnit var55 = var37.getTickUnit();
    java.awt.Paint var56 = null;
    var34.setTickLabelPaint((java.lang.Comparable)var55, var56);
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.data.xy.XYDataset var59 = null;
    org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("");
    var61.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var65 = null;
    org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot(var59, (org.jfree.chart.axis.ValueAxis)var61, var64, var65);
    org.jfree.chart.plot.DrawingSupplier var67 = var66.getDrawingSupplier();
    org.jfree.data.gantt.TaskSeriesCollection var68 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var69 = var68.getGroup();
    org.jfree.data.general.DatasetChangeEvent var70 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var67, (org.jfree.data.general.Dataset)var68);
    org.jfree.chart.plot.MultiplePiePlot var71 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var31, var32, var34, var58, (org.jfree.data.category.CategoryDataset)var68, 2, 7, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    boolean var14 = var1.isVisible();
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    var15.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var20 = null;
    var15.setSeriesItemLabelGenerator(10, var20, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var25 = var15.getToolTipGenerator(0, (-1));
    double var26 = var15.getMinimumBarLength();
    org.jfree.chart.event.RendererChangeEvent var27 = null;
    var15.notifyListeners(var27);
    java.awt.Stroke var31 = var15.getItemStroke(100, 2);
    var1.setTickMarkStroke(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var0.addBaseTimelineException(644288400000L);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.2d, 3.0d);
    java.io.ObjectOutputStream var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.axis.AxisSpace var8 = var7.getFixedDomainAxisSpace();
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var14, var15);
    org.jfree.chart.event.PlotChangeListener var17 = null;
    var16.removeChangeListener(var17);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = var16.getRendererForDataset(var19);
    org.jfree.chart.util.RectangleInsets var21 = var16.getInsets();
    org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine("");
    boolean var24 = var21.equals((java.lang.Object)var23);
    var7.setAxisOffset(var21);
    double var27 = var21.calculateTopOutset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4.0d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    boolean var1 = var0.getFillBox();
    boolean var4 = var0.isItemLabelVisible(100, 0);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var6 = null;
    java.awt.Color var8 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var9 = null;
    java.awt.Rectangle var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.awt.geom.AffineTransform var12 = null;
    java.awt.RenderingHints var13 = null;
    java.awt.PaintContext var14 = var8.createContext(var9, var10, var11, var12, var13);
    java.awt.color.ColorSpace var15 = var8.getColorSpace();
    java.lang.String var16 = org.jfree.chart.util.PaintUtilities.colorToString(var8);
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    var20.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    var25.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var28, var29);
    org.jfree.chart.plot.DrawingSupplier var31 = var30.getDrawingSupplier();
    var20.addChangeListener((org.jfree.chart.event.AxisChangeListener)var30);
    org.jfree.chart.plot.MultiplePiePlot var33 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var34 = var33.getDataExtractOrder();
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    var30.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var35);
    var35.setTextAntiAlias(false);
    java.awt.Image var39 = null;
    var35.setBackgroundImage(var39);
    java.lang.Object var41 = var35.clone();
    org.jfree.chart.entity.EntityCollection var44 = null;
    org.jfree.chart.ChartRenderingInfo var45 = new org.jfree.chart.ChartRenderingInfo(var44);
    var35.handleClick(0, 10, var45);
    java.awt.geom.Rectangle2D var47 = var45.getChartArea();
    java.awt.geom.AffineTransform var48 = null;
    java.awt.RenderingHints var49 = null;
    java.awt.PaintContext var50 = var8.createContext(var17, var18, var47, var48, var49);
    org.jfree.chart.plot.CategoryPlot var51 = null;
    org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis("");
    org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(100);
    var53.removeCategoryLabelToolTip((java.lang.Comparable)100);
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("");
    double var59 = var58.getLowerBound();
    org.jfree.chart.util.HorizontalAlignment var60 = null;
    org.jfree.chart.util.VerticalAlignment var61 = null;
    org.jfree.chart.block.FlowArrangement var64 = new org.jfree.chart.block.FlowArrangement(var60, var61, 2.0d, 10.0d);
    org.jfree.data.gantt.TaskSeriesCollection var65 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var66 = var65.getGroup();
    org.jfree.chart.title.LegendItemBlockContainer var68 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var64, (org.jfree.data.general.Dataset)var65, (java.lang.Comparable)2);
    org.jfree.data.general.PieDataset var70 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var65, (java.lang.Comparable)'4');
    int var71 = var65.getSeriesCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawHorizontalItem(var5, var6, var47, var51, var53, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.data.category.CategoryDataset)var65, (-524308), (-524308));
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "black"+ "'", var16.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)2);
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer(var0, (org.jfree.data.general.Dataset)var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var2 = var0.equals((java.lang.Object)2);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 2.0d, false);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
    org.jfree.chart.event.PlotChangeListener var15 = null;
    var14.removeChangeListener(var15);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
    var14.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var19);
    var19.resizeRange(100.0d);
    java.awt.Paint var23 = var19.getTickMarkPaint();
    var6.setBaseFillPaint(var23, true);
    var0.setBasePaint(var23, false);
    double var28 = var0.getBase();
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
    var32.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
    org.jfree.chart.event.PlotChangeListener var38 = null;
    var37.removeChangeListener(var38);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
    org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var46 = var44.getSeriesPaint((-1));
    java.awt.Font var49 = var44.getItemLabelFont(1, 1);
    var42.setTickLabelFont(var49);
    org.jfree.chart.util.RectangleInsets var51 = var42.getLabelInsets();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
    double var54 = var53.getLowerBound();
    float var55 = var53.getTickMarkOutsideLength();
    boolean var56 = var53.isTickMarksVisible();
    java.awt.Shape var57 = var53.getLeftArrow();
    var42.setLeftArrow(var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-1), var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    org.jfree.chart.labels.ItemLabelPosition var3 = null;
    var2.setNegativeItemLabelPositionFallback(var3);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseSeriesVisibleInLegend(false);
    double var11 = var2.getXOffset();
    java.awt.Paint var12 = var2.getWallPaint();
    var2.setBaseCreateEntities(false, true);
    double var16 = var2.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var16 = var14.getSeriesPaint((-1));
//     java.awt.Font var19 = var14.getItemLabelFont(1, 1);
//     var12.setTickLabelFont(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var12.getLabelInsets();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     double var24 = var23.getLowerBound();
//     float var25 = var23.getTickMarkOutsideLength();
//     boolean var26 = var23.isTickMarksVisible();
//     java.awt.Shape var27 = var23.getLeftArrow();
//     var12.setLeftArrow(var27);
//     org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity(var27);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     var31.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     var36.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, var39, var40);
//     org.jfree.chart.plot.DrawingSupplier var42 = var41.getDrawingSupplier();
//     var31.addChangeListener((org.jfree.chart.event.AxisChangeListener)var41);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
//     double var46 = var45.getLowerBound();
//     float var47 = var45.getTickMarkOutsideLength();
//     boolean var48 = var45.isTickMarksVisible();
//     java.awt.Shape var49 = var45.getLeftArrow();
//     var31.setUpArrow(var49);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var51 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var52 = null;
//     var51.setBaseItemLabelGenerator(var52, true);
//     boolean var55 = var51.getBaseSeriesVisible();
//     var51.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var61 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var62 = var61.getBasePaint();
//     var51.setSeriesFillPaint(10, var62, false);
//     org.jfree.chart.title.LegendGraphic var65 = new org.jfree.chart.title.LegendGraphic(var49, var62);
//     org.jfree.chart.axis.NumberAxis3D var67 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     java.awt.Shape var68 = var67.getRightArrow();
//     var65.setShape(var68);
//     java.awt.Shape var70 = var65.getShape();
//     var29.setArea(var70);
//     
//     // Checks the contract:  equals-hashcode on var41 and var7
//     assertTrue("Contract failed: equals-hashcode on var41 and var7", var41.equals(var7) ? var41.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var41 and var7.", var41.equals(var7) == var7.equals(var41));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var51.", var14.equals(var51) == var51.equals(var14));
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 2.0d, 10.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var6 = var5.getGroup();
    org.jfree.chart.title.LegendItemBlockContainer var8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)2);
    org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(2);
    int var12 = var11.toSerial();
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(2);
    int var15 = var14.toSerial();
    boolean var16 = var11.isAfter((org.jfree.data.time.SerialDate)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var18 = var5.getEndValue((java.lang.Comparable)"RectangleEdge.TOP", (java.lang.Comparable)var11, (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(10, 100, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var16 = var14.getSeriesPaint((-1));
//     java.awt.Font var19 = var14.getItemLabelFont(1, 1);
//     var12.setTickLabelFont(var19);
//     var12.setAutoRange(false);
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var25.createContext(var26, var27, var28, var29, var30);
//     var23.setBaseSectionOutlinePaint((java.awt.Paint)var25);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     var34.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     var39.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, var42, var43);
//     org.jfree.chart.plot.DrawingSupplier var45 = var44.getDrawingSupplier();
//     var34.addChangeListener((org.jfree.chart.event.AxisChangeListener)var44);
//     java.awt.Paint var47 = var34.getAxisLinePaint();
//     var23.setBaseSectionPaint(var47);
//     boolean var49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)false, (java.lang.Object)var47);
//     
//     // Checks the contract:  equals-hashcode on var44 and var7
//     assertTrue("Contract failed: equals-hashcode on var44 and var7", var44.equals(var7) ? var44.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var44 and var7.", var44.equals(var7) == var7.equals(var44));
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    var1.zoom(0.0d);
    org.jfree.data.general.WaferMapDataset var4 = null;
    var1.setDataset(var4);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
    var2.resizeRange(0.2d);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    var7.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, var10, var11);
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var12.removeChangeListener(var13);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    var12.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var17);
    java.awt.Paint var19 = var17.getTickMarkPaint();
    boolean var20 = var17.isAutoRange();
    java.awt.Stroke var21 = var17.getTickMarkStroke();
    var2.setTickMarkStroke(var21);
    boolean var23 = var0.equals((java.lang.Object)var2);
    java.lang.String var24 = var2.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "XY Plot"+ "'", var24.equals("XY Plot"));

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
//     var7.mapDatasetToDomainAxis(15, 1);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.event.ChartProgressListener var14 = null;
//     var13.addProgressListener(var14);
//     java.awt.Stroke var16 = null;
//     var13.setBorderStroke(var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
//     var20.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var20, var23, var24);
//     org.jfree.chart.event.PlotChangeListener var26 = null;
//     var25.removeChangeListener(var26);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var30);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var34 = var32.getSeriesPaint((-1));
//     java.awt.Font var37 = var32.getItemLabelFont(1, 1);
//     var30.setTickLabelFont(var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     var41.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var41, var44, var45);
//     org.jfree.chart.event.PlotChangeListener var47 = null;
//     var46.removeChangeListener(var47);
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     var46.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var51);
//     boolean var53 = var46.isDomainCrosshairVisible();
//     var46.configureRangeAxes();
//     java.awt.Paint var55 = var46.getRangeGridlinePaint();
//     org.jfree.chart.axis.AxisSpace var56 = null;
//     var46.setFixedDomainAxisSpace(var56);
//     java.awt.Paint var58 = var46.getRangeCrosshairPaint();
//     org.jfree.chart.plot.RingPlot var59 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.xy.XYDataset var61 = null;
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("");
//     var63.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var67 = null;
//     org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot(var61, (org.jfree.chart.axis.ValueAxis)var63, var66, var67);
//     org.jfree.chart.plot.DrawingSupplier var69 = var68.getDrawingSupplier();
//     org.jfree.chart.axis.AxisSpace var70 = var68.getFixedDomainAxisSpace();
//     var68.setBackgroundImageAlignment(0);
//     org.jfree.chart.plot.RingPlot var73 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var75 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var76 = null;
//     java.awt.Rectangle var77 = null;
//     java.awt.geom.Rectangle2D var78 = null;
//     java.awt.geom.AffineTransform var79 = null;
//     java.awt.RenderingHints var80 = null;
//     java.awt.PaintContext var81 = var75.createContext(var76, var77, var78, var79, var80);
//     var73.setBaseSectionOutlinePaint((java.awt.Paint)var75);
//     var68.setDomainTickBandPaint((java.awt.Paint)var75);
//     var59.setSectionPaint((java.lang.Comparable)true, (java.awt.Paint)var75);
//     var46.setRangeCrosshairPaint((java.awt.Paint)var75);
//     var30.setTickMarkPaint((java.awt.Paint)var75);
//     var13.setBorderPaint((java.awt.Paint)var75);
//     
//     // Checks the contract:  equals-hashcode on var8 and var69
//     assertTrue("Contract failed: equals-hashcode on var8 and var69", var8.equals(var69) ? var8.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var8
//     assertTrue("Contract failed: equals-hashcode on var69 and var8", var69.equals(var8) ? var69.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("XY Plot");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var6 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo(var6);
//     java.lang.Object var8 = var7.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Point2D var10 = null;
//     var3.zoomDomainAxes(4.0d, 2.0d, var9, var10);
//     java.awt.geom.Rectangle2D var12 = var9.getDataArea();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var13 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.KeyedObjects2D var14 = new org.jfree.data.KeyedObjects2D();
//     var14.setObject((java.lang.Object)15, (java.lang.Comparable)100.0d, (java.lang.Comparable)0.0f);
//     java.util.List var19 = var14.getColumnKeys();
//     var13.add(var19, (java.lang.Comparable)100.0f, (java.lang.Comparable)(byte)10);
//     boolean var23 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var13);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var13);
//     java.lang.Object var25 = var1.draw(var2, var12, (java.lang.Object)var24);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("LengthConstraintType.FIXED", var1, var2);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.data.gantt.TaskSeriesCollection var2 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var2, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var1.generateLabel((org.jfree.data.category.CategoryDataset)var2, 68);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     var16.setTextAntiAlias(false);
//     java.awt.Image var20 = null;
//     var16.setBackgroundImage(var20);
//     java.lang.Object var22 = var16.clone();
//     org.jfree.chart.title.LegendTitle var24 = var16.getLegend(10);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     var35.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, var38, var39);
//     org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
//     var30.addChangeListener((org.jfree.chart.event.AxisChangeListener)var40);
//     org.jfree.chart.plot.MultiplePiePlot var43 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var44 = var43.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var43);
//     var40.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var45);
//     var45.setTextAntiAlias(false);
//     java.awt.Image var49 = null;
//     var45.setBackgroundImage(var49);
//     java.lang.Object var51 = var45.clone();
//     org.jfree.chart.entity.EntityCollection var54 = null;
//     org.jfree.chart.ChartRenderingInfo var55 = new org.jfree.chart.ChartRenderingInfo(var54);
//     var45.handleClick(0, 10, var55);
//     java.awt.image.BufferedImage var57 = var16.createBufferedImage(15, 2, 0.2d, 0.05d, var55);
//     
//     // Checks the contract:  equals-hashcode on var11 and var40
//     assertTrue("Contract failed: equals-hashcode on var11 and var40", var11.equals(var40) ? var11.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var11
//     assertTrue("Contract failed: equals-hashcode on var40 and var11", var40.equals(var11) ? var40.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var41
//     assertTrue("Contract failed: equals-hashcode on var12 and var41", var12.equals(var41) ? var12.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var12
//     assertTrue("Contract failed: equals-hashcode on var41 and var12", var41.equals(var12) ? var41.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var43
//     assertTrue("Contract failed: equals-hashcode on var14 and var43", var14.equals(var43) ? var14.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var14
//     assertTrue("Contract failed: equals-hashcode on var43 and var14", var43.equals(var14) ? var43.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var45
//     assertTrue("Contract failed: equals-hashcode on var16 and var45", var16.equals(var45) ? var16.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var16
//     assertTrue("Contract failed: equals-hashcode on var45 and var16", var45.equals(var16) ? var45.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var51
//     assertTrue("Contract failed: equals-hashcode on var22 and var51", var22.equals(var51) ? var22.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var22
//     assertTrue("Contract failed: equals-hashcode on var51 and var22", var51.equals(var22) ? var51.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    org.jfree.data.time.RegularTimePeriod var3 = var1.next();
    org.jfree.data.gantt.Task var4 = new org.jfree.data.gantt.Task("black", (org.jfree.data.time.TimePeriod)var3);
    org.jfree.data.gantt.Task var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addSubtask(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var7 = null;
//     org.jfree.chart.ChartRenderingInfo var8 = new org.jfree.chart.ChartRenderingInfo(var7);
//     java.lang.Object var9 = var8.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     java.awt.geom.Point2D var11 = null;
//     var4.zoomDomainAxes(4.0d, 2.0d, var10, var11);
//     java.awt.geom.Rectangle2D var13 = var10.getDataArea();
//     java.awt.Color var15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var16 = null;
//     java.awt.Rectangle var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     java.awt.geom.AffineTransform var19 = null;
//     java.awt.RenderingHints var20 = null;
//     java.awt.PaintContext var21 = var15.createContext(var16, var17, var18, var19, var20);
//     java.awt.color.ColorSpace var22 = var15.getColorSpace();
//     java.lang.String var23 = org.jfree.chart.util.PaintUtilities.colorToString(var15);
//     java.awt.image.ColorModel var24 = null;
//     java.awt.Rectangle var25 = null;
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     var27.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.plot.DrawingSupplier var38 = var37.getDrawingSupplier();
//     var27.addChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
//     org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var41 = var40.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var40);
//     var37.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var42);
//     var42.setTextAntiAlias(false);
//     java.awt.Image var46 = null;
//     var42.setBackgroundImage(var46);
//     java.lang.Object var48 = var42.clone();
//     org.jfree.chart.entity.EntityCollection var51 = null;
//     org.jfree.chart.ChartRenderingInfo var52 = new org.jfree.chart.ChartRenderingInfo(var51);
//     var42.handleClick(0, 10, var52);
//     java.awt.geom.Rectangle2D var54 = var52.getChartArea();
//     java.awt.geom.AffineTransform var55 = null;
//     java.awt.RenderingHints var56 = null;
//     java.awt.PaintContext var57 = var15.createContext(var24, var25, var54, var55, var56);
//     org.jfree.chart.axis.CategoryLabelPositions var59 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.2d);
//     org.jfree.chart.axis.CategoryLabelPosition var60 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var61 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var59, var60);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("");
//     var64.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var62, (org.jfree.chart.axis.ValueAxis)var64, var67, var68);
//     org.jfree.chart.event.PlotChangeListener var70 = null;
//     var69.removeChangeListener(var70);
//     org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("");
//     var69.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var74);
//     boolean var76 = var69.isDomainCrosshairVisible();
//     org.jfree.chart.util.RectangleEdge var78 = var69.getDomainAxisEdge(68);
//     boolean var79 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var78);
//     org.jfree.chart.axis.CategoryLabelPosition var80 = var61.getLabelPosition(var78);
//     org.jfree.chart.entity.EntityCollection var81 = null;
//     org.jfree.chart.ChartRenderingInfo var82 = new org.jfree.chart.ChartRenderingInfo(var81);
//     java.lang.Object var83 = var82.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var84 = new org.jfree.chart.plot.PlotRenderingInfo(var82);
//     int var85 = var84.getSubplotCount();
//     org.jfree.chart.axis.AxisState var86 = var1.draw(var2, 24.200000000000003d, var13, var54, var78, var84);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.event.PlotChangeEvent var8 = null;
    var7.notifyListeners(var8);
    org.jfree.data.general.DatasetChangeEvent var10 = null;
    var7.datasetChanged(var10);
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var12 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    boolean var13 = var12.getFillBox();
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var16 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    java.awt.geom.AffineTransform var20 = null;
    java.awt.RenderingHints var21 = null;
    java.awt.PaintContext var22 = var16.createContext(var17, var18, var19, var20, var21);
    var14.setBaseSectionOutlinePaint((java.awt.Paint)var16);
    int var24 = var14.getPieIndex();
    org.jfree.chart.plot.RingPlot var25 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var27 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var28 = null;
    java.awt.Rectangle var29 = null;
    java.awt.geom.Rectangle2D var30 = null;
    java.awt.geom.AffineTransform var31 = null;
    java.awt.RenderingHints var32 = null;
    java.awt.PaintContext var33 = var27.createContext(var28, var29, var30, var31, var32);
    var25.setBaseSectionOutlinePaint((java.awt.Paint)var27);
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var38.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var36, (org.jfree.chart.axis.ValueAxis)var38, var41, var42);
    org.jfree.chart.event.PlotChangeListener var44 = null;
    var43.removeChangeListener(var44);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
    var43.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var48);
    java.awt.Paint var50 = var48.getTickMarkPaint();
    var25.setSectionOutlinePaint((java.lang.Comparable)1L, var50);
    var14.setLabelShadowPaint(var50);
    var12.setArtifactPaint(var50);
    var7.setDomainZeroBaselinePaint(var50);
    org.jfree.chart.plot.IntervalMarker var57 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    java.lang.Object var58 = var57.clone();
    var7.addDomainMarker((org.jfree.chart.plot.Marker)var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var57.setAlpha(2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.util.RectangleInsets var9 = var7.getAxisOffset();
    double var11 = var9.calculateBottomOutset(0.2d);
    double var12 = var9.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)false);
    org.jfree.data.Range var4 = var0.getRangeBounds(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var0.getStdDevValue(15, 7);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     var12.resizeRange(100.0d);
//     org.jfree.chart.event.AxisChangeEvent var16 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var12);
//     org.jfree.chart.event.ChartChangeEventType var17 = var16.getType();
//     org.jfree.chart.JFreeChart var18 = var16.getChart();
//     org.jfree.chart.JFreeChart var19 = null;
//     var16.setChart(var19);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, var26, var27);
//     org.jfree.chart.event.PlotChangeListener var29 = null;
//     var28.removeChangeListener(var29);
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var33);
//     var33.resizeRange(100.0d);
//     org.jfree.chart.event.AxisChangeEvent var37 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var33);
//     org.jfree.chart.event.ChartChangeEventType var38 = var37.getType();
//     var16.setType(var38);
//     
//     // Checks the contract:  equals-hashcode on var7 and var28
//     assertTrue("Contract failed: equals-hashcode on var7 and var28", var7.equals(var28) ? var7.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var7
//     assertTrue("Contract failed: equals-hashcode on var28 and var7", var28.equals(var7) ? var28.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    boolean var1 = var0.getFillBox();
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var4 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    var2.setBaseSectionOutlinePaint((java.awt.Paint)var4);
    int var12 = var2.getPieIndex();
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var16 = null;
    java.awt.Rectangle var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    java.awt.geom.AffineTransform var19 = null;
    java.awt.RenderingHints var20 = null;
    java.awt.PaintContext var21 = var15.createContext(var16, var17, var18, var19, var20);
    var13.setBaseSectionOutlinePaint((java.awt.Paint)var15);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    var26.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, var29, var30);
    org.jfree.chart.event.PlotChangeListener var32 = null;
    var31.removeChangeListener(var32);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    var31.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var36);
    java.awt.Paint var38 = var36.getTickMarkPaint();
    var13.setSectionOutlinePaint((java.lang.Comparable)1L, var38);
    var2.setLabelShadowPaint(var38);
    var0.setArtifactPaint(var38);
    java.awt.Paint var44 = var0.getItemPaint((-10289251), 68);
    java.awt.Font var46 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var48 = null;
    var47.setBaseItemLabelGenerator(var48, true);
    boolean var51 = var47.getBaseSeriesVisible();
    var47.setIncludeBaseInRange(false);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var57 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var58 = var57.getBasePaint();
    var47.setSeriesFillPaint(10, var58, false);
    org.jfree.chart.text.TextMeasurer var63 = null;
    org.jfree.chart.text.TextBlock var64 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, var58, (-1.0f), 10, var63);
    var0.setArtifactPaint(var58);
    var0.setFillBox(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 2.0d, 10.0d);
    org.jfree.data.general.Dataset var6 = null;
    org.jfree.chart.title.LegendItemBlockContainer var8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var6, (java.lang.Comparable)1.0f);
    var8.setToolTipText("hi!");
    java.lang.Object var11 = var8.clone();
    java.util.List var12 = var8.getBlocks();
    var0.setExceptionSegments(var12);
    var0.addException(10L, 644288400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getColumnCount();
    java.lang.Object var2 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.LegendItemCollection var3 = var0.getLegendItems();
    java.lang.Object var4 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     java.lang.String var3 = var0.generateRowLabel(var1, 0);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.HorizontalAlignment var3 = var0.getHorizontalAlignment();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var5.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    var10.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, var13, var14);
    org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
    var5.addChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
    boolean var18 = var5.isVerticalTickLabels();
    org.jfree.data.Range var21 = new org.jfree.data.Range(0.0d, 2.0d);
    double var22 = var21.getLength();
    var5.setRangeWithMargins(var21, false, false);
    boolean var26 = var0.equals((java.lang.Object)false);
    java.lang.String var27 = var0.getURLText();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    var30.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    var35.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, var38, var39);
    org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
    var30.addChangeListener((org.jfree.chart.event.AxisChangeListener)var40);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
    double var45 = var44.getLowerBound();
    float var46 = var44.getTickMarkOutsideLength();
    boolean var47 = var44.isTickMarksVisible();
    java.awt.Shape var48 = var44.getLeftArrow();
    var30.setUpArrow(var48);
    org.jfree.chart.renderer.category.IntervalBarRenderer var50 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var51 = null;
    var50.setBaseItemLabelGenerator(var51, true);
    boolean var54 = var50.getBaseSeriesVisible();
    var50.setIncludeBaseInRange(false);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var60 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var61 = var60.getBasePaint();
    var50.setSeriesFillPaint(10, var61, false);
    org.jfree.chart.title.LegendGraphic var64 = new org.jfree.chart.title.LegendGraphic(var48, var61);
    org.jfree.chart.util.StandardGradientPaintTransformer var65 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var64.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var65);
    java.lang.Object var67 = var64.clone();
    java.awt.Graphics2D var68 = null;
    org.jfree.chart.block.RectangleConstraint var71 = new org.jfree.chart.block.RectangleConstraint(0.25d, 32.2d);
    org.jfree.chart.util.Size2D var72 = var64.arrange(var68, var71);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var73 = var0.arrange(var28, var71);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     org.jfree.chart.util.RectangleInsets var9 = var7.getAxisOffset();
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
//     org.jfree.chart.event.PlotChangeListener var18 = null;
//     var17.removeChangeListener(var18);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var22);
//     java.awt.Paint var24 = var22.getTickMarkPaint();
//     boolean var25 = var22.isAutoRange();
//     org.jfree.data.Range var26 = var7.getDataRange((org.jfree.chart.axis.ValueAxis)var22);
//     
//     // Checks the contract:  equals-hashcode on var7 and var17
//     assertTrue("Contract failed: equals-hashcode on var7 and var17", var7.equals(var17) ? var7.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var17.", var7.equals(var17) == var17.equals(var7));
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var3 = var2.clone();
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var7 = null;
//     java.awt.Rectangle var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.AffineTransform var10 = null;
//     java.awt.RenderingHints var11 = null;
//     java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
//     var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
//     int var14 = var4.getPieIndex();
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var18 = null;
//     java.awt.Rectangle var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     java.awt.geom.AffineTransform var21 = null;
//     java.awt.RenderingHints var22 = null;
//     java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
//     var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
//     java.awt.Paint var40 = var38.getTickMarkPaint();
//     var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
//     var4.setLabelShadowPaint(var40);
//     var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     org.jfree.chart.urls.PieURLGenerator var44 = null;
//     var4.setURLGenerator(var44);
//     java.lang.String var46 = var4.getNoDataMessage();
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.FlowArrangement var52 = new org.jfree.chart.block.FlowArrangement(var48, var49, 2.0d, 10.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var53 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetGroup var54 = var53.getGroup();
//     org.jfree.chart.title.LegendItemBlockContainer var56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var52, (org.jfree.data.general.Dataset)var53, (java.lang.Comparable)2);
//     org.jfree.chart.plot.MultiplePiePlot var57 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var58 = var57.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var57);
//     java.awt.Paint var60 = var59.getBorderPaint();
//     boolean var61 = var52.equals((java.lang.Object)var60);
//     org.jfree.chart.plot.RingPlot var62 = new org.jfree.chart.plot.RingPlot();
//     double var63 = var62.getInteriorGap();
//     java.awt.Stroke var64 = var62.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     var67.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var65, (org.jfree.chart.axis.ValueAxis)var67, var70, var71);
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = null;
//     var72.setRenderer(var73);
//     java.awt.Paint var75 = var72.getNoDataMessagePaint();
//     org.jfree.data.xy.XYDataset var76 = null;
//     org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis("");
//     var78.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var82 = null;
//     org.jfree.chart.plot.XYPlot var83 = new org.jfree.chart.plot.XYPlot(var76, (org.jfree.chart.axis.ValueAxis)var78, var81, var82);
//     org.jfree.chart.axis.AxisSpace var84 = var83.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var87 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var88 = var87.getBasePaint();
//     var83.setDomainZeroBaselinePaint(var88);
//     java.awt.Stroke var90 = var83.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var92 = new org.jfree.chart.plot.ValueMarker(2.0d, var60, var64, var75, var90, 0.5f);
//     var4.setSeparatorStroke(var64);
//     
//     // Checks the contract:  equals-hashcode on var72 and var33
//     assertTrue("Contract failed: equals-hashcode on var72 and var33", var72.equals(var33) ? var72.hashCode() == var33.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var72 and var33.", var72.equals(var33) == var33.equals(var72));
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    java.awt.Paint var3 = var2.getBasePaint();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var7 = null;
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var9 = var8.clone();
    java.lang.Object var10 = var8.clone();
    org.jfree.chart.util.HorizontalAlignment var11 = var8.getHorizontalAlignment();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    var13.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    var18.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var18, var21, var22);
    org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
    var13.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    boolean var26 = var13.isVerticalTickLabels();
    org.jfree.data.Range var29 = new org.jfree.data.Range(0.0d, 2.0d);
    double var30 = var29.getLength();
    var13.setRangeWithMargins(var29, false, false);
    boolean var34 = var8.equals((java.lang.Object)false);
    var8.setToolTipText("");
    var8.setExpandToFitSpace(true);
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.entity.EntityCollection var43 = null;
    org.jfree.chart.ChartRenderingInfo var44 = new org.jfree.chart.ChartRenderingInfo(var43);
    java.lang.Object var45 = var44.clone();
    org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
    java.awt.geom.Point2D var47 = null;
    var40.zoomDomainAxes(4.0d, 2.0d, var46, var47);
    java.awt.geom.Rectangle2D var49 = var46.getDataArea();
    var8.draw(var39, var49);
    org.jfree.chart.plot.CategoryPlot var51 = null;
    org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D("0");
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
    var55.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("");
    var60.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
    org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var58, (org.jfree.chart.axis.ValueAxis)var60, var63, var64);
    org.jfree.chart.plot.DrawingSupplier var66 = var65.getDrawingSupplier();
    var55.addChangeListener((org.jfree.chart.event.AxisChangeListener)var65);
    boolean var68 = var55.isVisible();
    org.jfree.data.xy.XYDataset var69 = null;
    org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("");
    var71.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var74 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var75 = null;
    org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot(var69, (org.jfree.chart.axis.ValueAxis)var71, var74, var75);
    org.jfree.chart.plot.DrawingSupplier var77 = var76.getDrawingSupplier();
    org.jfree.data.gantt.TaskSeriesCollection var78 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var79 = var78.getGroup();
    org.jfree.data.general.DatasetChangeEvent var80 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var77, (org.jfree.data.general.Dataset)var78);
    org.jfree.chart.plot.MultiplePiePlot var81 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var78);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.drawItem(var6, var7, var49, var51, (org.jfree.chart.axis.CategoryAxis)var53, (org.jfree.chart.axis.ValueAxis)var55, (org.jfree.data.category.CategoryDataset)var78, 0, 0, 255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    java.awt.Color var19 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var20 = null;
    java.awt.Rectangle var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    java.awt.geom.AffineTransform var23 = null;
    java.awt.RenderingHints var24 = null;
    java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
    java.awt.color.ColorSpace var26 = var19.getColorSpace();
    var16.setBackgroundPaint((java.awt.Paint)var19);
    org.jfree.chart.title.LegendTitle var29 = var16.getLegend((-10289251));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    int var1 = var0.size();
    java.lang.Boolean var3 = var0.getBoolean((-398));
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = var7.getFixedLegendItems();
    var7.setWeight(100);
    java.awt.Font var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setNoDataMessageFont(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var1 = var0.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setBaseToolTipGenerator(var2);
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var5 = null;
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var4, var5);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
//     org.jfree.chart.plot.MultiplePiePlot var24 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var25 = var24.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     var21.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
//     var26.setTextAntiAlias(false);
//     java.awt.Image var30 = null;
//     var26.setBackgroundImage(var30);
//     java.lang.Object var32 = var26.clone();
//     org.jfree.chart.entity.EntityCollection var35 = null;
//     org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo(var35);
//     var26.handleClick(0, 10, var36);
//     java.awt.geom.Rectangle2D var38 = var36.getChartArea();
//     var0.drawOutline(var8, var9, var38);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = var7.getRendererForDataset(var10);
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     var19.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var22, var23);
//     org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
//     var14.addChangeListener((org.jfree.chart.event.AxisChangeListener)var24);
//     var24.setRangeCrosshairLockedOnData(true);
//     java.awt.Paint var29 = var24.getDomainTickBandPaint();
//     org.jfree.chart.axis.AxisLocation var31 = var24.getDomainAxisLocation(0);
//     org.jfree.chart.axis.AxisLocation var32 = var31.getOpposite();
//     var7.setDomainAxisLocation(4, var32);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var7.", var24.equals(var7) == var7.equals(var24));
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)1);
    int var4 = var0.getRowIndex((java.lang.Comparable)false);
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 16.2d);
    var0.validateObject();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var0.getMinRegularValue(1, 2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var15 = var14.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     var16.setTextAntiAlias(false);
//     java.awt.Image var20 = null;
//     var16.setBackgroundImage(var20);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, var28, var29);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     var30.setRenderer(var31);
//     java.awt.Paint var33 = var30.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var35 = var34.getItemLabelAnchorOffset();
//     var34.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     org.jfree.chart.plot.SeriesRenderingOrder var40 = var30.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var42 = var30.getDataset(10);
//     org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var45 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var46 = null;
//     java.awt.Rectangle var47 = null;
//     java.awt.geom.Rectangle2D var48 = null;
//     java.awt.geom.AffineTransform var49 = null;
//     java.awt.RenderingHints var50 = null;
//     java.awt.PaintContext var51 = var45.createContext(var46, var47, var48, var49, var50);
//     var43.setBaseSectionOutlinePaint((java.awt.Paint)var45);
//     int var53 = var43.getPieIndex();
//     org.jfree.chart.labels.PieToolTipGenerator var54 = null;
//     var43.setToolTipGenerator(var54);
//     java.awt.Paint var56 = var43.getShadowPaint();
//     var30.setDomainGridlinePaint(var56);
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("");
//     var60.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis("");
//     var65.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
//     org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var63, (org.jfree.chart.axis.ValueAxis)var65, var68, var69);
//     org.jfree.chart.plot.DrawingSupplier var71 = var70.getDrawingSupplier();
//     var60.addChangeListener((org.jfree.chart.event.AxisChangeListener)var70);
//     org.jfree.chart.plot.MultiplePiePlot var73 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var74 = var73.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var73);
//     var70.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var75);
//     var75.setTextAntiAlias(false);
//     java.awt.Image var79 = null;
//     var75.setBackgroundImage(var79);
//     java.lang.Object var81 = var75.clone();
//     org.jfree.chart.entity.EntityCollection var84 = null;
//     org.jfree.chart.ChartRenderingInfo var85 = new org.jfree.chart.ChartRenderingInfo(var84);
//     var75.handleClick(0, 10, var85);
//     java.awt.geom.Rectangle2D var87 = var85.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var88 = null;
//     var30.drawAnnotations(var58, var87, var88);
//     var16.draw(var22, var87);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("XY Plot");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     var4.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
//     org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
//     var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
//     org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var18 = var17.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
//     var19.setTextAntiAlias(false);
//     java.awt.Image var23 = null;
//     var19.setBackgroundImage(var23);
//     java.lang.Object var25 = var19.clone();
//     org.jfree.chart.entity.EntityCollection var28 = null;
//     org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo(var28);
//     var19.handleClick(0, 10, var29);
//     java.awt.geom.Rectangle2D var31 = var29.getChartArea();
//     org.jfree.chart.axis.SegmentedTimeline var32 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var34 = var32.toTimelineValue(100L);
//     int var35 = var32.getSegmentsExcluded();
//     long var37 = var32.getTimeFromLong(1L);
//     var32.addException(0L);
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     var41.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     var46.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var44, (org.jfree.chart.axis.ValueAxis)var46, var49, var50);
//     org.jfree.chart.plot.DrawingSupplier var52 = var51.getDrawingSupplier();
//     var41.addChangeListener((org.jfree.chart.event.AxisChangeListener)var51);
//     org.jfree.chart.plot.MultiplePiePlot var54 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var55 = var54.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var54);
//     var51.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var56);
//     var56.setBackgroundImageAlpha(1.0f);
//     org.jfree.chart.event.ChartProgressEvent var62 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0L, var56, 10, (-524308));
//     var56.setBackgroundImageAlignment((-1));
//     java.lang.Object var65 = var1.draw(var2, var31, (java.lang.Object)var56);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
//     var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
//     int var18 = var8.getPieIndex();
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.awt.geom.AffineTransform var25 = null;
//     java.awt.RenderingHints var26 = null;
//     java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
//     var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
//     java.awt.Paint var44 = var42.getTickMarkPaint();
//     var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
//     var8.setLabelShadowPaint(var44);
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var8.setLegendLabelURLGenerator(var47);
//     var8.setOuterSeparatorExtension(0.2d);
//     boolean var51 = var7.equals((java.lang.Object)var8);
//     java.lang.Comparable var53 = var7.getColumnKey(4);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.entity.EntityCollection var6 = null;
    org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo(var6);
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    java.awt.geom.Point2D var10 = null;
    var3.zoomDomainAxes(4.0d, 2.0d, var9, var10);
    java.awt.geom.Rectangle2D var12 = var9.getDataArea();
    org.jfree.chart.plot.CategoryPlot var13 = null;
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("");
    var15.setMaximumCategoryLabelLines(1);
    org.jfree.chart.axis.CategoryLabelPositions var19 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.2d);
    var15.setCategoryLabelPositions(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    double var23 = var22.getLowerBound();
    float var24 = var22.getTickMarkOutsideLength();
    org.jfree.chart.plot.MultiplePiePlot var25 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var26 = var25.getDataExtractOrder();
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
    double var28 = var25.getLimit();
    org.jfree.data.gantt.TaskSeriesCollection var29 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetGroup var30 = var29.getGroup();
    int var32 = var29.getColumnIndex((java.lang.Comparable)1);
    int var34 = var29.getRowIndex((java.lang.Comparable)(byte)(-1));
    var25.setDataset((org.jfree.data.category.CategoryDataset)var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var12, var13, var15, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.data.category.CategoryDataset)var29, 100, 0, 31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1));

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("LegendItemEntity: seriesKey=null, dataset=null", var1, Double.NaN, 10.0f, (-1.0f));
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    java.awt.Stroke var3 = var0.getSeriesOutlineStroke(100);
    var0.setBaseItemLabelsVisible(true);
    var0.setBaseSeriesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     var4.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
//     org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
//     var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
//     org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var18 = var17.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
//     var19.setTextAntiAlias(false);
//     java.awt.Image var23 = null;
//     var19.setBackgroundImage(var23);
//     float var25 = var19.getBackgroundImageAlpha();
//     boolean var26 = var0.hasListener((java.util.EventListener)var19);
//     var19.fireChartChanged();
//     java.awt.RenderingHints var28 = null;
//     var19.setRenderingHints(var28);
// 
//   }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeEvent var8 = null;
//     var7.notifyListeners(var8);
//     org.jfree.data.general.DatasetChangeEvent var10 = null;
//     var7.datasetChanged(var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     var7.setRenderer(var12);
//     java.awt.Graphics2D var14 = null;
//     java.awt.Color var16 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var17 = null;
//     java.awt.Rectangle var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     java.awt.geom.AffineTransform var20 = null;
//     java.awt.RenderingHints var21 = null;
//     java.awt.PaintContext var22 = var16.createContext(var17, var18, var19, var20, var21);
//     java.awt.color.ColorSpace var23 = var16.getColorSpace();
//     java.lang.String var24 = org.jfree.chart.util.PaintUtilities.colorToString(var16);
//     java.awt.image.ColorModel var25 = null;
//     java.awt.Rectangle var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var36, var37);
//     org.jfree.chart.plot.DrawingSupplier var39 = var38.getDrawingSupplier();
//     var28.addChangeListener((org.jfree.chart.event.AxisChangeListener)var38);
//     org.jfree.chart.plot.MultiplePiePlot var41 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var42 = var41.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var41);
//     var38.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var43);
//     var43.setTextAntiAlias(false);
//     java.awt.Image var47 = null;
//     var43.setBackgroundImage(var47);
//     java.lang.Object var49 = var43.clone();
//     org.jfree.chart.entity.EntityCollection var52 = null;
//     org.jfree.chart.ChartRenderingInfo var53 = new org.jfree.chart.ChartRenderingInfo(var52);
//     var43.handleClick(0, 10, var53);
//     java.awt.geom.Rectangle2D var55 = var53.getChartArea();
//     java.awt.geom.AffineTransform var56 = null;
//     java.awt.RenderingHints var57 = null;
//     java.awt.PaintContext var58 = var16.createContext(var25, var26, var55, var56, var57);
//     var7.drawBackgroundImage(var14, var55);
//     
//     // Checks the contract:  equals-hashcode on var7 and var38
//     assertTrue("Contract failed: equals-hashcode on var7 and var38", var7.equals(var38) ? var7.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var7
//     assertTrue("Contract failed: equals-hashcode on var38 and var7", var38.equals(var7) ? var38.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var1 = var0.getItemLabelAnchorOffset();
//     boolean var2 = var0.getBaseCreateEntities();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var0.getItemLabelGenerator(100, (-1));
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
//     org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
//     var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var19);
//     java.awt.geom.Rectangle2D var22 = null;
//     var0.drawRangeGridline(var6, var7, (org.jfree.chart.axis.ValueAxis)var9, var22, 1.0d);
//     org.jfree.chart.event.AxisChangeEvent var25 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var9);
//     org.jfree.chart.event.ChartChangeEventType var26 = var25.getType();
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var29.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var29, var32, var33);
//     org.jfree.chart.event.PlotChangeListener var35 = null;
//     var34.removeChangeListener(var35);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     var34.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var39);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var41 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var43 = var41.getSeriesPaint((-1));
//     java.awt.Font var46 = var41.getItemLabelFont(1, 1);
//     var39.setTickLabelFont(var46);
//     java.text.NumberFormat var48 = null;
//     var39.setNumberFormatOverride(var48);
//     boolean var50 = var39.isAutoRange();
//     java.lang.String var51 = var39.getLabelToolTip();
//     boolean var52 = var26.equals((java.lang.Object)var39);
//     
//     // Checks the contract:  equals-hashcode on var19 and var34
//     assertTrue("Contract failed: equals-hashcode on var19 and var34", var19.equals(var34) ? var19.hashCode() == var34.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var34.", var19.equals(var34) == var34.equals(var19));
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.renderer.OutlierListCollection var0 = new org.jfree.chart.renderer.OutlierListCollection();
    var0.setLowFarOut(true);
    java.util.Iterator var3 = var0.iterator();
    org.jfree.chart.renderer.Outlier var4 = null;
    boolean var5 = var0.add(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("XY Plot");
//     var2.resizeRange(0.2d);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, var10, var11);
//     org.jfree.chart.event.PlotChangeListener var13 = null;
//     var12.removeChangeListener(var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var17);
//     java.awt.Paint var19 = var17.getTickMarkPaint();
//     boolean var20 = var17.isAutoRange();
//     java.awt.Stroke var21 = var17.getTickMarkStroke();
//     var2.setTickMarkStroke(var21);
//     boolean var23 = var0.equals((java.lang.Object)var2);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
//     var26.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, var29, var30);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var31.removeChangeListener(var32);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     var31.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var36);
//     var36.resizeRange(100.0d);
//     java.awt.Paint var40 = var36.getTickMarkPaint();
//     org.jfree.data.Range var43 = new org.jfree.data.Range(0.0d, 2.0d);
//     var36.setDefaultAutoRange(var43);
//     var36.setUpperMargin((-15.8d));
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
//     var49.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var47, (org.jfree.chart.axis.ValueAxis)var49, var52, var53);
//     org.jfree.chart.event.PlotChangeListener var55 = null;
//     var54.removeChangeListener(var55);
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("");
//     var54.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var59);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var61 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var63 = var61.getSeriesPaint((-1));
//     java.awt.Font var66 = var61.getItemLabelFont(1, 1);
//     var59.setTickLabelFont(var66);
//     org.jfree.chart.util.RectangleInsets var68 = var59.getLabelInsets();
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("");
//     double var71 = var70.getLowerBound();
//     float var72 = var70.getTickMarkOutsideLength();
//     boolean var73 = var70.isTickMarksVisible();
//     java.awt.Shape var74 = var70.getLeftArrow();
//     var59.setLeftArrow(var74);
//     org.jfree.chart.entity.ChartEntity var76 = new org.jfree.chart.entity.ChartEntity(var74);
//     var36.setRightArrow(var74);
//     var0.setBaseShape(var74, true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var54
//     assertTrue("Contract failed: equals-hashcode on var12 and var54", var12.equals(var54) ? var12.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var12
//     assertTrue("Contract failed: equals-hashcode on var54 and var12", var54.equals(var12) ? var54.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var2 = var0.getSeriesPaint((-1));
    java.awt.Font var5 = var0.getItemLabelFont(1, 1);
    var0.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.entity.EntityCollection var14 = null;
    org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo(var14);
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
    java.awt.geom.Point2D var18 = null;
    var11.zoomDomainAxes(4.0d, 2.0d, var17, var18);
    java.awt.geom.Rectangle2D var20 = var17.getDataArea();
    org.jfree.chart.plot.CategoryPlot var21 = null;
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var23 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    var26.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, var29, var30);
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    var31.setRenderer(var32);
    java.awt.Paint var34 = var31.getNoDataMessagePaint();
    int var35 = var31.getWeight();
    var23.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.entity.EntityCollection var42 = null;
    org.jfree.chart.ChartRenderingInfo var43 = new org.jfree.chart.ChartRenderingInfo(var42);
    java.lang.Object var44 = var43.clone();
    org.jfree.chart.plot.PlotRenderingInfo var45 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
    java.awt.geom.Point2D var46 = null;
    var39.zoomDomainAxes(4.0d, 2.0d, var45, var46);
    var31.handleClick(7, 2014, var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var49 = var0.initialise(var10, var20, var21, 28, var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    boolean var1 = var0.getFillBox();
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var4 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    var2.setBaseSectionOutlinePaint((java.awt.Paint)var4);
    int var12 = var2.getPieIndex();
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var16 = null;
    java.awt.Rectangle var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    java.awt.geom.AffineTransform var19 = null;
    java.awt.RenderingHints var20 = null;
    java.awt.PaintContext var21 = var15.createContext(var16, var17, var18, var19, var20);
    var13.setBaseSectionOutlinePaint((java.awt.Paint)var15);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    var26.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, var29, var30);
    org.jfree.chart.event.PlotChangeListener var32 = null;
    var31.removeChangeListener(var32);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    var31.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var36);
    java.awt.Paint var38 = var36.getTickMarkPaint();
    var13.setSectionOutlinePaint((java.lang.Comparable)1L, var38);
    var2.setLabelShadowPaint(var38);
    var0.setArtifactPaint(var38);
    java.awt.Font var43 = null;
    var0.setSeriesItemLabelFont(1, var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = null;
//     java.awt.Font var5 = null;
//     org.jfree.chart.axis.MarkerAxisBand var6 = new org.jfree.chart.axis.MarkerAxisBand(var0, 100.0d, 10.0d, 100.0d, 2.0d, var5);
//     java.lang.Object var7 = null;
//     boolean var8 = var6.equals(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     var17.setRenderer(var18);
//     java.awt.Paint var20 = var17.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var22 = var21.getItemLabelAnchorOffset();
//     var21.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var26 = var17.equals((java.lang.Object)var21);
//     org.jfree.chart.plot.SeriesRenderingOrder var27 = var17.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var29 = var17.getDataset(10);
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var32 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var33 = null;
//     java.awt.Rectangle var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     java.awt.geom.AffineTransform var36 = null;
//     java.awt.RenderingHints var37 = null;
//     java.awt.PaintContext var38 = var32.createContext(var33, var34, var35, var36, var37);
//     var30.setBaseSectionOutlinePaint((java.awt.Paint)var32);
//     int var40 = var30.getPieIndex();
//     org.jfree.chart.labels.PieToolTipGenerator var41 = null;
//     var30.setToolTipGenerator(var41);
//     java.awt.Paint var43 = var30.getShadowPaint();
//     var17.setDomainGridlinePaint(var43);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     var47.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     var52.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var50, (org.jfree.chart.axis.ValueAxis)var52, var55, var56);
//     org.jfree.chart.plot.DrawingSupplier var58 = var57.getDrawingSupplier();
//     var47.addChangeListener((org.jfree.chart.event.AxisChangeListener)var57);
//     org.jfree.chart.plot.MultiplePiePlot var60 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var61 = var60.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var60);
//     var57.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var62);
//     var62.setTextAntiAlias(false);
//     java.awt.Image var66 = null;
//     var62.setBackgroundImage(var66);
//     java.lang.Object var68 = var62.clone();
//     org.jfree.chart.entity.EntityCollection var71 = null;
//     org.jfree.chart.ChartRenderingInfo var72 = new org.jfree.chart.ChartRenderingInfo(var71);
//     var62.handleClick(0, 10, var72);
//     java.awt.geom.Rectangle2D var74 = var72.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     var17.drawAnnotations(var45, var74, var75);
//     org.jfree.chart.plot.PolarPlot var77 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var80 = null;
//     org.jfree.chart.ChartRenderingInfo var81 = new org.jfree.chart.ChartRenderingInfo(var80);
//     java.lang.Object var82 = var81.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var83 = new org.jfree.chart.plot.PlotRenderingInfo(var81);
//     java.awt.geom.Point2D var84 = null;
//     var77.zoomDomainAxes(4.0d, 2.0d, var83, var84);
//     java.awt.geom.Rectangle2D var86 = var83.getDataArea();
//     var6.draw(var9, var74, var86, 4.0d, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var72 and var81
//     assertTrue("Contract failed: equals-hashcode on var72 and var81", var72.equals(var81) ? var72.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var72
//     assertTrue("Contract failed: equals-hashcode on var81 and var72", var81.equals(var72) ? var81.hashCode() == var72.hashCode() : true);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var3 = null;
//     org.jfree.chart.ChartRenderingInfo var4 = new org.jfree.chart.ChartRenderingInfo(var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Point2D var7 = null;
//     var0.zoomDomainAxes(4.0d, 2.0d, var6, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, var14, var15);
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     var16.setRenderer(var17);
//     java.awt.Paint var19 = var16.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var21 = var20.getItemLabelAnchorOffset();
//     var20.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     boolean var25 = var16.equals((java.lang.Object)var20);
//     org.jfree.chart.plot.SeriesRenderingOrder var26 = var16.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var28 = var16.getDataset(10);
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var31 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var32 = null;
//     java.awt.Rectangle var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     java.awt.geom.AffineTransform var35 = null;
//     java.awt.RenderingHints var36 = null;
//     java.awt.PaintContext var37 = var31.createContext(var32, var33, var34, var35, var36);
//     var29.setBaseSectionOutlinePaint((java.awt.Paint)var31);
//     int var39 = var29.getPieIndex();
//     org.jfree.chart.labels.PieToolTipGenerator var40 = null;
//     var29.setToolTipGenerator(var40);
//     java.awt.Paint var42 = var29.getShadowPaint();
//     var16.setDomainGridlinePaint(var42);
//     java.awt.Graphics2D var44 = null;
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     var46.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var49 = null;
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     var51.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var49, (org.jfree.chart.axis.ValueAxis)var51, var54, var55);
//     org.jfree.chart.plot.DrawingSupplier var57 = var56.getDrawingSupplier();
//     var46.addChangeListener((org.jfree.chart.event.AxisChangeListener)var56);
//     org.jfree.chart.plot.MultiplePiePlot var59 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var60 = var59.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var59);
//     var56.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var61);
//     var61.setTextAntiAlias(false);
//     java.awt.Image var65 = null;
//     var61.setBackgroundImage(var65);
//     java.lang.Object var67 = var61.clone();
//     org.jfree.chart.entity.EntityCollection var70 = null;
//     org.jfree.chart.ChartRenderingInfo var71 = new org.jfree.chart.ChartRenderingInfo(var70);
//     var61.handleClick(0, 10, var71);
//     java.awt.geom.Rectangle2D var73 = var71.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var74 = null;
//     var16.drawAnnotations(var44, var73, var74);
//     var6.setPlotArea(var73);
//     
//     // Checks the contract:  equals-hashcode on var4 and var71
//     assertTrue("Contract failed: equals-hashcode on var4 and var71", var4.equals(var71) ? var4.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var4
//     assertTrue("Contract failed: equals-hashcode on var71 and var4", var71.equals(var4) ? var71.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var3 = var1.getRowIndex((java.lang.Comparable)1);
    int var5 = var1.getRowIndex((java.lang.Comparable)false);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, 16.2d);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    java.util.List var9 = var1.getRowKeys();
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var1, 68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var13 = var1.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 1.0d, (-1.0d));

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     var4.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, var7, var8);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     var9.setRenderer(var10);
//     java.awt.Paint var12 = var9.getNoDataMessagePaint();
//     var1.setLabelOutlinePaint(var12);
//     var0.setBaseFillPaint(var12);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var17 = var15.getSeriesPaint((-1));
//     java.awt.Font var20 = var15.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var21 = new org.jfree.chart.labels.ItemLabelPosition();
//     var15.setBasePositiveItemLabelPosition(var21);
//     org.jfree.chart.labels.ItemLabelAnchor var23 = var21.getItemLabelAnchor();
//     var0.setBaseNegativeItemLabelPosition(var21, false);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var27 = null;
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var31 = null;
//     org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo(var31);
//     java.lang.Object var33 = var32.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var34 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
//     java.awt.geom.Point2D var35 = null;
//     var28.zoomDomainAxes(4.0d, 2.0d, var34, var35);
//     java.awt.geom.Rectangle2D var37 = var34.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var38 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("");
//     double var41 = var40.getLowerMargin();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("");
//     var43.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var48.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var52 = null;
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot(var46, (org.jfree.chart.axis.ValueAxis)var48, var51, var52);
//     org.jfree.chart.plot.DrawingSupplier var54 = var53.getDrawingSupplier();
//     var43.addChangeListener((org.jfree.chart.event.AxisChangeListener)var53);
//     boolean var56 = var43.isVerticalTickLabels();
//     var43.setLowerBound(0.0d);
//     var43.setAxisLineVisible(false);
//     org.jfree.chart.axis.NumberTickUnit var61 = var43.getTickUnit();
//     java.awt.Paint var62 = null;
//     var40.setTickLabelPaint((java.lang.Comparable)var61, var62);
//     boolean var64 = var40.isVisible();
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     var67.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var65, (org.jfree.chart.axis.ValueAxis)var67, var70, var71);
//     org.jfree.chart.event.PlotChangeListener var73 = null;
//     var72.removeChangeListener(var73);
//     org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis("");
//     var72.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var77);
//     java.awt.Paint var79 = var77.getTickMarkPaint();
//     boolean var80 = var77.isAutoRange();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var81 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     int var83 = var81.getRowIndex((java.lang.Comparable)1);
//     int var85 = var81.getRowIndex((java.lang.Comparable)false);
//     org.jfree.data.Range var87 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var81, 16.2d);
//     var81.validateObject();
//     java.lang.Number var91 = var81.getMinOutlier((java.lang.Comparable)2014, (java.lang.Comparable)10L);
//     var0.drawItem(var26, var27, var37, var38, var40, (org.jfree.chart.axis.ValueAxis)var77, (org.jfree.data.category.CategoryDataset)var81, 2, (-1), (-10289251));
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var1 = var0.getItemLabelAnchorOffset();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     java.awt.Font var6 = var0.getSeriesItemLabelFont(100);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var12 = null;
//     org.jfree.chart.ChartRenderingInfo var13 = new org.jfree.chart.ChartRenderingInfo(var12);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     java.awt.geom.Point2D var16 = null;
//     var9.zoomDomainAxes(4.0d, 2.0d, var15, var16);
//     java.awt.geom.Rectangle2D var18 = var15.getDataArea();
//     var0.drawOutline(var7, var8, var18);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.entity.EntityCollection var0 = null;
//     org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var1);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = var1.getPlotInfo();
//     
//     // Checks the contract:  equals-hashcode on var3 and var4
//     assertTrue("Contract failed: equals-hashcode on var3 and var4", var3.equals(var4) ? var3.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var3
//     assertTrue("Contract failed: equals-hashcode on var4 and var3", var4.equals(var3) ? var4.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeEvent var8 = null;
//     var7.notifyListeners(var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, var15, var16);
//     org.jfree.chart.event.PlotChangeListener var18 = null;
//     var17.removeChangeListener(var18);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var22);
//     java.awt.Paint var24 = var22.getTickMarkPaint();
//     boolean var25 = var22.isAutoRange();
//     java.awt.Stroke var26 = var22.getTickMarkStroke();
//     var7.setDomainCrosshairStroke(var26);
//     float var28 = var7.getBackgroundImageAlpha();
//     var7.setRangeGridlinesVisible(true);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, var36, var37);
//     org.jfree.chart.plot.DrawingSupplier var39 = var38.getDrawingSupplier();
//     org.jfree.data.gantt.TaskSeriesCollection var40 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetGroup var41 = var40.getGroup();
//     org.jfree.data.general.DatasetChangeEvent var42 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var39, (org.jfree.data.general.Dataset)var40);
//     var7.datasetChanged(var42);
//     
//     // Checks the contract:  equals-hashcode on var38 and var17
//     assertTrue("Contract failed: equals-hashcode on var38 and var17", var38.equals(var17) ? var38.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var38 and var17.", var38.equals(var17) == var17.equals(var38));
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, var9, var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     double var16 = var15.getLowerBound();
//     float var17 = var15.getTickMarkOutsideLength();
//     boolean var18 = var15.isTickMarksVisible();
//     java.awt.Shape var19 = var15.getLeftArrow();
//     var1.setUpArrow(var19);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = null;
//     var21.setBaseItemLabelGenerator(var22, true);
//     boolean var25 = var21.getBaseSeriesVisible();
//     var21.setIncludeBaseInRange(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var32 = var31.getBasePaint();
//     var21.setSeriesFillPaint(10, var32, false);
//     org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic(var19, var32);
//     org.jfree.chart.util.StandardGradientPaintTransformer var36 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var35.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var36);
//     java.lang.Object var38 = var35.clone();
//     org.jfree.chart.util.RectangleAnchor var39 = var35.getShapeAnchor();
//     org.jfree.chart.axis.CategoryLabelPosition var40 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextBlockAnchor var41 = var40.getLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPosition var42 = new org.jfree.chart.axis.CategoryLabelPosition(var39, var41);
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
//     var45.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var43, (org.jfree.chart.axis.ValueAxis)var45, var48, var49);
//     org.jfree.chart.event.PlotChangeListener var51 = null;
//     var50.removeChangeListener(var51);
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
//     var50.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var55);
//     boolean var57 = var50.isDomainCrosshairVisible();
//     org.jfree.chart.util.RectangleEdge var59 = var50.getDomainAxisEdge(68);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
//     var62.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var60, (org.jfree.chart.axis.ValueAxis)var62, var65, var66);
//     org.jfree.chart.event.PlotChangeListener var68 = null;
//     var67.removeChangeListener(var68);
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("");
//     var67.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var72);
//     var72.resizeRange(100.0d);
//     org.jfree.chart.event.AxisChangeEvent var76 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var72);
//     org.jfree.chart.axis.ValueAxis[] var77 = new org.jfree.chart.axis.ValueAxis[] { var72};
//     var50.setDomainAxes(var77);
//     boolean var79 = var41.equals((java.lang.Object)var77);
//     
//     // Checks the contract:  equals-hashcode on var11 and var67
//     assertTrue("Contract failed: equals-hashcode on var11 and var67", var11.equals(var67) ? var11.hashCode() == var67.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var67.", var11.equals(var67) == var67.equals(var11));
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var6 = var4.getSeriesPaint((-1));
//     java.awt.Font var9 = var4.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
//     var4.setBasePositiveItemLabelPosition(var10);
//     var2.setSeriesPositiveItemLabelPosition(10, var10);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var25.createContext(var26, var27, var28, var29, var30);
//     var23.setBaseSectionOutlinePaint((java.awt.Paint)var25);
//     int var33 = var23.getPieIndex();
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var36 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var37 = null;
//     java.awt.Rectangle var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     java.awt.geom.AffineTransform var40 = null;
//     java.awt.RenderingHints var41 = null;
//     java.awt.PaintContext var42 = var36.createContext(var37, var38, var39, var40, var41);
//     var34.setBaseSectionOutlinePaint((java.awt.Paint)var36);
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     var47.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var45, (org.jfree.chart.axis.ValueAxis)var47, var50, var51);
//     org.jfree.chart.event.PlotChangeListener var53 = null;
//     var52.removeChangeListener(var53);
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     var52.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var57);
//     java.awt.Paint var59 = var57.getTickMarkPaint();
//     var34.setSectionOutlinePaint((java.lang.Comparable)1L, var59);
//     var23.setLabelShadowPaint(var59);
//     var21.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var23);
//     org.jfree.chart.util.GradientPaintTransformer var63 = null;
//     var21.setGradientPaintTransformer(var63);
//     java.awt.geom.Rectangle2D var65 = null;
//     var2.drawRangeMarker(var13, var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.plot.Marker)var21, var65);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var69 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
//     var69.setSeriesShapesFilled(1, (java.lang.Boolean)false);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var73 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var74 = var73.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.CategoryToolTipGenerator var75 = null;
//     var73.setBaseToolTipGenerator(var75);
//     org.jfree.data.general.WaferMapDataset var77 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var78 = null;
//     org.jfree.chart.plot.WaferMapPlot var79 = new org.jfree.chart.plot.WaferMapPlot(var77, var78);
//     var73.addChangeListener((org.jfree.chart.event.RendererChangeListener)var79);
//     java.awt.Paint var81 = var79.getNoDataMessagePaint();
//     boolean var82 = var69.equals((java.lang.Object)var81);
//     var69.setUseFillPaint(false);
//     org.jfree.data.xy.XYDataset var85 = null;
//     org.jfree.chart.axis.NumberAxis var87 = new org.jfree.chart.axis.NumberAxis("");
//     var87.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var90 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var91 = null;
//     org.jfree.chart.plot.XYPlot var92 = new org.jfree.chart.plot.XYPlot(var85, (org.jfree.chart.axis.ValueAxis)var87, var90, var91);
//     org.jfree.chart.renderer.xy.XYItemRenderer var93 = null;
//     var92.setRenderer(var93);
//     java.awt.Paint var95 = var92.getNoDataMessagePaint();
//     boolean var96 = var69.equals((java.lang.Object)var95);
//     java.awt.Paint var97 = var69.getBaseFillPaint();
//     var2.setBaseItemLabelPaint(var97, false);
//     
//     // Checks the contract:  equals-hashcode on var92 and var52
//     assertTrue("Contract failed: equals-hashcode on var92 and var52", var92.equals(var52) ? var92.hashCode() == var52.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var92 and var52.", var92.equals(var52) == var52.equals(var92));
// 
//   }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.labels.ItemLabelPosition var3 = null;
//     var2.setNegativeItemLabelPositionFallback(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var8 = var7.clone();
//     java.lang.Object var9 = var7.clone();
//     org.jfree.chart.util.HorizontalAlignment var10 = var7.getHorizontalAlignment();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, var20, var21);
//     org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
//     var12.addChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
//     boolean var25 = var12.isVerticalTickLabels();
//     org.jfree.data.Range var28 = new org.jfree.data.Range(0.0d, 2.0d);
//     double var29 = var28.getLength();
//     var12.setRangeWithMargins(var28, false, false);
//     boolean var33 = var7.equals((java.lang.Object)false);
//     var7.setToolTipText("");
//     var7.setExpandToFitSpace(true);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var42 = null;
//     org.jfree.chart.ChartRenderingInfo var43 = new org.jfree.chart.ChartRenderingInfo(var42);
//     java.lang.Object var44 = var43.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var45 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     java.awt.geom.Point2D var46 = null;
//     var39.zoomDomainAxes(4.0d, 2.0d, var45, var46);
//     java.awt.geom.Rectangle2D var48 = var45.getDataArea();
//     var7.draw(var38, var48);
//     var2.drawDomainGridline(var5, var6, var48, 1.0E-8d);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var5 = var4.getTickUnit();
    var0.add(0.0d, 0.0d, (java.lang.Comparable)"LengthConstraintType.FIXED", (java.lang.Comparable)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var0.getMeanValue(2014, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var3 = var2.clone();
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var7 = null;
//     java.awt.Rectangle var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.AffineTransform var10 = null;
//     java.awt.RenderingHints var11 = null;
//     java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
//     var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
//     int var14 = var4.getPieIndex();
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var18 = null;
//     java.awt.Rectangle var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     java.awt.geom.AffineTransform var21 = null;
//     java.awt.RenderingHints var22 = null;
//     java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
//     var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
//     java.awt.Paint var40 = var38.getTickMarkPaint();
//     var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
//     var4.setLabelShadowPaint(var40);
//     var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     org.jfree.chart.urls.PieURLGenerator var44 = null;
//     var4.setURLGenerator(var44);
//     double var46 = var4.getMaximumLabelWidth();
//     double var47 = var4.getShadowYOffset();
//     var4.zoom(10.0d);
//     org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.plot.RingPlot var51 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var53 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var54 = null;
//     java.awt.Rectangle var55 = null;
//     java.awt.geom.Rectangle2D var56 = null;
//     java.awt.geom.AffineTransform var57 = null;
//     java.awt.RenderingHints var58 = null;
//     java.awt.PaintContext var59 = var53.createContext(var54, var55, var56, var57, var58);
//     var51.setBaseSectionOutlinePaint((java.awt.Paint)var53);
//     org.jfree.chart.plot.RingPlot var61 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var63 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var64 = null;
//     java.awt.Rectangle var65 = null;
//     java.awt.geom.Rectangle2D var66 = null;
//     java.awt.geom.AffineTransform var67 = null;
//     java.awt.RenderingHints var68 = null;
//     java.awt.PaintContext var69 = var63.createContext(var64, var65, var66, var67, var68);
//     var61.setBaseSectionOutlinePaint((java.awt.Paint)var63);
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("");
//     var74.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var78 = null;
//     org.jfree.chart.plot.XYPlot var79 = new org.jfree.chart.plot.XYPlot(var72, (org.jfree.chart.axis.ValueAxis)var74, var77, var78);
//     org.jfree.chart.event.PlotChangeListener var80 = null;
//     var79.removeChangeListener(var80);
//     org.jfree.chart.axis.NumberAxis var84 = new org.jfree.chart.axis.NumberAxis("");
//     var79.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var84);
//     java.awt.Paint var86 = var84.getTickMarkPaint();
//     var61.setSectionOutlinePaint((java.lang.Comparable)1L, var86);
//     org.jfree.chart.labels.PieSectionLabelGenerator var88 = var61.getLabelGenerator();
//     var51.setLegendLabelToolTipGenerator(var88);
//     var50.setLabelGenerator(var88);
//     var4.setLegendLabelGenerator(var88);
//     
//     // Checks the contract:  equals-hashcode on var15 and var61
//     assertTrue("Contract failed: equals-hashcode on var15 and var61", var15.equals(var61) ? var15.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var15
//     assertTrue("Contract failed: equals-hashcode on var61 and var15", var61.equals(var15) ? var61.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var79
//     assertTrue("Contract failed: equals-hashcode on var33 and var79", var33.equals(var79) ? var33.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var33
//     assertTrue("Contract failed: equals-hashcode on var79 and var33", var79.equals(var33) ? var79.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation();
    var7.mapDatasetToDomainAxis(15, 1);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.event.ChartProgressListener var14 = null;
    var13.addProgressListener(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var16 = var13.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    var0.addOptionalLibrary("hi!");
    org.jfree.chart.ui.ProjectInfo var3 = new org.jfree.chart.ui.ProjectInfo();
    var3.addOptionalLibrary("");
    var3.setLicenceText("XY Plot");
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var3);
    org.jfree.chart.ui.ProjectInfo var9 = new org.jfree.chart.ui.ProjectInfo();
    var9.addOptionalLibrary("");
    var9.setLicenceText("XY Plot");
    org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo();
    boolean var15 = var9.equals((java.lang.Object)var14);
    var9.setName("hi!");
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var9);
    java.awt.Image var19 = null;
    var9.setLogo(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(false);
    var1.removeColumn((java.lang.Comparable)(byte)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow((java.lang.Comparable)644288400000L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.axis.AxisSpace var8 = var7.getFixedDomainAxisSpace();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.entity.EntityCollection var13 = null;
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo(var13);
//     java.lang.Object var15 = var14.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var14);
//     java.awt.geom.Point2D var17 = null;
//     var10.zoomDomainAxes(4.0d, 2.0d, var16, var17);
//     java.awt.geom.Rectangle2D var19 = var16.getDataArea();
//     var7.drawBackground(var9, var19);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var1 = var0.getItemLabelAnchorOffset();
//     boolean var2 = var0.getBaseCreateEntities();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var0.getItemLabelGenerator(100, (-1));
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
//     org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
//     var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var19);
//     java.awt.geom.Rectangle2D var22 = null;
//     var0.drawRangeGridline(var6, var7, (org.jfree.chart.axis.ValueAxis)var9, var22, 1.0d);
//     org.jfree.chart.event.AxisChangeEvent var25 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var9);
//     org.jfree.chart.event.AxisChangeEvent var26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var9);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var29.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var29, var32, var33);
//     org.jfree.chart.event.PlotChangeListener var35 = null;
//     var34.removeChangeListener(var35);
//     org.jfree.chart.util.Layer var37 = null;
//     java.util.Collection var38 = var34.getDomainMarkers(var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     int var40 = var34.indexOf(var39);
//     java.awt.Paint var41 = var34.getDomainCrosshairPaint();
//     var9.setAxisLinePaint(var41);
//     
//     // Checks the contract:  equals-hashcode on var19 and var34
//     assertTrue("Contract failed: equals-hashcode on var19 and var34", var19.equals(var34) ? var19.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var19
//     assertTrue("Contract failed: equals-hashcode on var34 and var19", var34.equals(var19) ? var34.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10, 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var6 = var4.getSeriesPaint((-1));
//     java.awt.Font var9 = var4.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
//     var4.setBasePositiveItemLabelPosition(var10);
//     var2.setSeriesPositiveItemLabelPosition(10, var10);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setUpperBound(0.0d);
//     org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var25 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var25.createContext(var26, var27, var28, var29, var30);
//     var23.setBaseSectionOutlinePaint((java.awt.Paint)var25);
//     int var33 = var23.getPieIndex();
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var36 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var37 = null;
//     java.awt.Rectangle var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     java.awt.geom.AffineTransform var40 = null;
//     java.awt.RenderingHints var41 = null;
//     java.awt.PaintContext var42 = var36.createContext(var37, var38, var39, var40, var41);
//     var34.setBaseSectionOutlinePaint((java.awt.Paint)var36);
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     var47.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var45, (org.jfree.chart.axis.ValueAxis)var47, var50, var51);
//     org.jfree.chart.event.PlotChangeListener var53 = null;
//     var52.removeChangeListener(var53);
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     var52.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var57);
//     java.awt.Paint var59 = var57.getTickMarkPaint();
//     var34.setSectionOutlinePaint((java.lang.Comparable)1L, var59);
//     var23.setLabelShadowPaint(var59);
//     var21.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var23);
//     org.jfree.chart.util.GradientPaintTransformer var63 = null;
//     var21.setGradientPaintTransformer(var63);
//     java.awt.geom.Rectangle2D var65 = null;
//     var2.drawRangeMarker(var13, var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.plot.Marker)var21, var65);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var67 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     org.jfree.chart.plot.RingPlot var68 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.xy.XYDataset var69 = null;
//     org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("");
//     var71.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var75 = null;
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot(var69, (org.jfree.chart.axis.ValueAxis)var71, var74, var75);
//     org.jfree.chart.renderer.xy.XYItemRenderer var77 = null;
//     var76.setRenderer(var77);
//     java.awt.Paint var79 = var76.getNoDataMessagePaint();
//     var68.setLabelOutlinePaint(var79);
//     var67.setBaseFillPaint(var79);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var82 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Paint var84 = var82.getSeriesPaint((-1));
//     java.awt.Font var87 = var82.getItemLabelFont(1, 1);
//     org.jfree.chart.labels.ItemLabelPosition var88 = new org.jfree.chart.labels.ItemLabelPosition();
//     var82.setBasePositiveItemLabelPosition(var88);
//     org.jfree.chart.labels.ItemLabelAnchor var90 = var88.getItemLabelAnchor();
//     var67.setBaseNegativeItemLabelPosition(var88, false);
//     boolean var93 = var2.equals((java.lang.Object)false);
//     
//     // Checks the contract:  equals-hashcode on var10 and var88
//     assertTrue("Contract failed: equals-hashcode on var10 and var88", var10.equals(var88) ? var10.hashCode() == var88.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var88 and var10
//     assertTrue("Contract failed: equals-hashcode on var88 and var10", var88.equals(var10) ? var88.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var52
//     assertTrue("Contract failed: equals-hashcode on var76 and var52", var76.equals(var52) ? var76.hashCode() == var52.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var76 and var52.", var76.equals(var52) == var52.equals(var76));
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(2, 7, var2);
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     boolean var6 = var4.isHiddenValue((-1L));
//     org.jfree.chart.axis.DateTickUnit var7 = null;
//     var4.setTickUnit(var7);
//     org.jfree.chart.axis.SegmentedTimeline var9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.data.gantt.TaskSeriesCollection var10 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var10, false);
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     var19.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, var22, var23);
//     org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
//     var14.addChangeListener((org.jfree.chart.event.AxisChangeListener)var24);
//     org.jfree.chart.plot.MultiplePiePlot var27 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var28 = var27.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var27);
//     var24.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var29);
//     var29.setTextAntiAlias(false);
//     java.awt.Image var33 = null;
//     var29.setBackgroundImage(var33);
//     float var35 = var29.getBackgroundImageAlpha();
//     boolean var36 = var10.hasListener((java.util.EventListener)var29);
//     java.util.List var37 = var10.getColumnKeys();
//     var9.addExceptions(var37);
//     java.util.Date var40 = var9.getDate(100L);
//     org.jfree.chart.axis.SegmentedTimeline var41 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var43 = var41.toTimelineValue(100L);
//     var41.addException((-1L));
//     java.util.Date var47 = var41.getDate(61200000L);
//     org.jfree.chart.axis.SegmentedTimeline var48 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var50 = var48.toTimelineValue(100L);
//     var48.addException((-1L));
//     java.util.Date var54 = var48.getDate(61200000L);
//     org.jfree.data.time.SimpleTimePeriod var55 = new org.jfree.data.time.SimpleTimePeriod(var47, var54);
//     var4.setRange(var40, var54);
//     java.util.TimeZone var57 = null;
//     java.util.Date var58 = var3.rollDate(var40, var57);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     double var2 = var1.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
//     var1.setBaseToolTipGenerator(var3);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
//     var1.setLegendItemURLGenerator(var5);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
//     java.awt.Paint var10 = var9.getBasePaint();
//     var1.setBasePaint(var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var19.removeChangeListener(var20);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     var19.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var24);
//     java.awt.Paint var26 = var24.getTickMarkPaint();
//     boolean var27 = var24.isAutoRange();
//     java.awt.Stroke var28 = var24.getTickMarkStroke();
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(32.2d, var10, var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
//     org.jfree.chart.plot.DrawingSupplier var38 = var37.getDrawingSupplier();
//     org.jfree.chart.axis.AxisSpace var39 = var37.getFixedDomainAxisSpace();
//     var37.setBackgroundImageAlignment(0);
//     org.jfree.chart.plot.RingPlot var42 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var44 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var45 = null;
//     java.awt.Rectangle var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     java.awt.geom.AffineTransform var48 = null;
//     java.awt.RenderingHints var49 = null;
//     java.awt.PaintContext var50 = var44.createContext(var45, var46, var47, var48, var49);
//     var42.setBaseSectionOutlinePaint((java.awt.Paint)var44);
//     var37.setDomainTickBandPaint((java.awt.Paint)var44);
//     int var53 = var44.getRed();
//     var29.setPaint((java.awt.Paint)var44);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var55 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     var55.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var60 = null;
//     var55.setSeriesItemLabelGenerator(10, var60, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var65 = var55.getToolTipGenerator(0, (-1));
//     double var66 = var55.getMinimumBarLength();
//     org.jfree.chart.event.RendererChangeEvent var67 = null;
//     var55.notifyListeners(var67);
//     java.awt.Stroke var71 = var55.getItemStroke(100, 2);
//     var29.setStroke(var71);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var55.", var1.equals(var55) == var55.equals(var1));
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
//     java.lang.Object var3 = var2.clone();
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var7 = null;
//     java.awt.Rectangle var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.AffineTransform var10 = null;
//     java.awt.RenderingHints var11 = null;
//     java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
//     var4.setBaseSectionOutlinePaint((java.awt.Paint)var6);
//     int var14 = var4.getPieIndex();
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
//     java.awt.image.ColorModel var18 = null;
//     java.awt.Rectangle var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     java.awt.geom.AffineTransform var21 = null;
//     java.awt.RenderingHints var22 = null;
//     java.awt.PaintContext var23 = var17.createContext(var18, var19, var20, var21, var22);
//     var15.setBaseSectionOutlinePaint((java.awt.Paint)var17);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var38);
//     java.awt.Paint var40 = var38.getTickMarkPaint();
//     var15.setSectionOutlinePaint((java.lang.Comparable)1L, var40);
//     var4.setLabelShadowPaint(var40);
//     var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     org.jfree.chart.urls.PieURLGenerator var44 = null;
//     var4.setURLGenerator(var44);
//     double var46 = var4.getMaximumLabelWidth();
//     java.lang.Comparable var47 = null;
//     double var48 = var4.getExplodePercent(var47);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.2d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var2);
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextBlockAnchor var5 = var4.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var6 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var4);
    org.jfree.chart.axis.CategoryLabelWidthType var7 = var4.getWidthType();
    java.lang.String var8 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "CategoryLabelWidthType.CATEGORY"+ "'", var8.equals("CategoryLabelWidthType.CATEGORY"));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("");
    var1.setMaximumCategoryLabelLines(1);
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.2d);
    var1.setCategoryLabelPositions(var5);
    org.jfree.chart.axis.CategoryLabelPositions var8 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.2d);
    org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var10 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var8, var9);
    org.jfree.chart.axis.CategoryLabelPosition var11 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextBlockAnchor var12 = var11.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var8, var11);
    org.jfree.chart.axis.CategoryLabelPositions var14 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var5, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

//  public void test489() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 16.2d};
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var3, var4, var6);
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
    var8.setBaseSectionOutlinePaint((java.awt.Paint)var10);
    int var18 = var8.getPieIndex();
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var21 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    var19.setBaseSectionOutlinePaint((java.awt.Paint)var21);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
    var32.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, var35, var36);
    org.jfree.chart.event.PlotChangeListener var38 = null;
    var37.removeChangeListener(var38);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
    var37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var42);
    java.awt.Paint var44 = var42.getTickMarkPaint();
    var19.setSectionOutlinePaint((java.lang.Comparable)1L, var44);
    var8.setLabelShadowPaint(var44);
    org.jfree.chart.urls.PieURLGenerator var47 = null;
    var8.setLegendLabelURLGenerator(var47);
    var8.setOuterSeparatorExtension(0.2d);
    boolean var51 = var7.equals((java.lang.Object)var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var54 = var7.getEndValue(0, 7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("XY Plot");
    java.lang.Object var2 = var1.clone();
    java.lang.String var3 = var1.getToolTipText();
    java.awt.Font var4 = var1.getFont();
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, var12, var13);
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    var14.setRenderer(var15);
    java.awt.Paint var17 = var14.getNoDataMessagePaint();
    var6.setLabelOutlinePaint(var17);
    var5.setBaseFillPaint(var17);
    org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Paint var22 = var20.getSeriesPaint((-1));
    java.awt.Font var25 = var20.getItemLabelFont(1, 1);
    org.jfree.chart.labels.ItemLabelPosition var26 = new org.jfree.chart.labels.ItemLabelPosition();
    var20.setBasePositiveItemLabelPosition(var26);
    org.jfree.chart.labels.ItemLabelAnchor var28 = var26.getItemLabelAnchor();
    var5.setBaseNegativeItemLabelPosition(var26, false);
    boolean var31 = var1.equals((java.lang.Object)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.KeyedObjects2D var1 = new org.jfree.data.KeyedObjects2D();
    var1.setObject((java.lang.Object)15, (java.lang.Comparable)100.0d, (java.lang.Comparable)0.0f);
    java.util.List var6 = var1.getColumnKeys();
    var0.add(var6, (java.lang.Comparable)100.0f, (java.lang.Comparable)(byte)10);
    boolean var10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Number var13 = var0.getMedianValue((java.lang.Comparable)0.2d, (java.lang.Comparable)"0");
    java.lang.Number var16 = var0.getMedianValue((java.lang.Comparable)86400000L, (java.lang.Comparable)1388563200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.addOptionalLibrary("");
    var0.setLicenceText("XY Plot");
    org.jfree.chart.ui.ProjectInfo var5 = new org.jfree.chart.ui.ProjectInfo();
    boolean var6 = var0.equals((java.lang.Object)var5);
    var0.setInfo("java.awt.Color[r=0,g=0,b=0]");
    java.lang.String var9 = var0.toString();
    org.jfree.data.gantt.TaskSeries var11 = new org.jfree.data.gantt.TaskSeries("");
    org.jfree.data.gantt.TaskSeriesCollection var12 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var12, false);
    var11.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var12);
    boolean var16 = var0.equals((java.lang.Object)var12);
    java.awt.Image var17 = var0.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:java.awt.Color[r=0,g=0,b=0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nXY Plot"+ "'", var9.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:java.awt.Color[r=0,g=0,b=0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nXY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    int var2 = var1.getPassCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var1.getLegendItemURLGenerator();
    org.jfree.chart.renderer.AreaRendererEndType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setEndType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    double var1 = var0.getItemLabelAnchorOffset();
    boolean var2 = var0.getBaseCreateEntities();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var0.getItemLabelGenerator(100, (-1));
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(0.0d);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var14.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, var17, var18);
    org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
    var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var19);
    java.awt.geom.Rectangle2D var22 = null;
    var0.drawRangeGridline(var6, var7, (org.jfree.chart.axis.ValueAxis)var9, var22, 1.0d);
    org.jfree.data.RangeType var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setRangeType(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("");
//     org.jfree.data.gantt.TaskSeriesCollection var2 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var2, false);
//     var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var2);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 2.0d, 10.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var11 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetGroup var12 = var11.getGroup();
//     org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, (org.jfree.data.general.Dataset)var11, (java.lang.Comparable)2);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, var20, var21);
//     org.jfree.chart.event.PlotChangeEvent var23 = null;
//     var22.notifyListeners(var23);
//     org.jfree.data.general.DatasetChangeEvent var25 = null;
//     var22.datasetChanged(var25);
//     boolean var27 = var11.equals((java.lang.Object)var22);
//     org.jfree.data.gantt.TaskSeries var29 = var11.getSeries((java.lang.Comparable)'#');
//     var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var11);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    var3.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, var6, var7);
    org.jfree.chart.event.PlotChangeListener var9 = null;
    var8.removeChangeListener(var9);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    var8.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var13);
    var13.resizeRange(100.0d);
    java.awt.Paint var17 = var13.getTickMarkPaint();
    org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 2.0d);
    var13.setDefaultAutoRange(var20);
    var13.setFixedDimension(0.0d);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    var26.setUpperBound(0.0d);
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, var29, var30);
    org.jfree.chart.event.PlotChangeListener var32 = null;
    var31.removeChangeListener(var32);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    var31.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var36);
    boolean var38 = var31.isDomainCrosshairVisible();
    var31.configureRangeAxes();
    java.awt.Paint var40 = var31.getRangeGridlinePaint();
    var13.setAxisLinePaint(var40);
    java.awt.Stroke var42 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(2.0d, 0.0d);
    org.jfree.chart.labels.ItemLabelPosition var46 = null;
    var45.setNegativeItemLabelPositionFallback(var46);
    java.awt.Shape var48 = var45.getBaseShape();
    org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var50 = var49.clone();
    boolean var51 = var49.getNotify();
    boolean var52 = var45.equals((java.lang.Object)var49);
    java.awt.Paint var53 = var49.getPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
    var56.setUseFillPaint(false);
    boolean var59 = var56.getDrawOutlines();
    boolean var60 = var56.getBaseShapesVisible();
    org.jfree.chart.renderer.category.StackedAreaRenderer var63 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Stroke var65 = var63.lookupSeriesOutlineStroke(1);
    var56.setSeriesOutlineStroke(2014, var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var68 = new org.jfree.chart.plot.ValueMarker(24.200000000000003d, var40, var42, var53, var65, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d);
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot();
    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    java.awt.image.ColorModel var6 = null;
    java.awt.Rectangle var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    java.awt.geom.AffineTransform var9 = null;
    java.awt.RenderingHints var10 = null;
    java.awt.PaintContext var11 = var5.createContext(var6, var7, var8, var9, var10);
    var3.setBaseSectionOutlinePaint((java.awt.Paint)var5);
    int var13 = var3.getPieIndex();
    org.jfree.chart.labels.PieToolTipGenerator var14 = null;
    var3.setToolTipGenerator(var14);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var3);
    double var17 = var3.getLabelGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var5, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var12);
//     boolean var14 = var7.isDomainCrosshairVisible();
//     var7.configureRangeAxes();
//     java.awt.Paint var16 = var7.getRangeGridlinePaint();
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var7.setFixedDomainAxisSpace(var17);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     var21.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, var24, var25);
//     org.jfree.chart.event.PlotChangeListener var27 = null;
//     var26.removeChangeListener(var27);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     var26.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var31);
//     boolean var33 = var26.isDomainCrosshairVisible();
//     org.jfree.chart.util.RectangleEdge var35 = var26.getDomainAxisEdge(68);
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var38.setUpperBound(0.0d);
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var36, (org.jfree.chart.axis.ValueAxis)var38, var41, var42);
//     org.jfree.chart.event.PlotChangeListener var44 = null;
//     var43.removeChangeListener(var44);
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var43.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var48);
//     var48.resizeRange(100.0d);
//     org.jfree.chart.event.AxisChangeEvent var52 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var48);
//     org.jfree.chart.axis.ValueAxis[] var53 = new org.jfree.chart.axis.ValueAxis[] { var48};
//     var26.setDomainAxes(var53);
//     var7.setDomainAxes(var53);
//     
//     // Checks the contract:  equals-hashcode on var7 and var26
//     assertTrue("Contract failed: equals-hashcode on var7 and var26", var7.equals(var26) ? var7.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var7
//     assertTrue("Contract failed: equals-hashcode on var26 and var7", var26.equals(var7) ? var26.hashCode() == var7.hashCode() : true);
// 
//   }

}
