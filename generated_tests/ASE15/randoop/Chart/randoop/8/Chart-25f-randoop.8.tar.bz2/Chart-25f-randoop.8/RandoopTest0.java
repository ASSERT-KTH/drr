
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 1);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", var3);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("", var1);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(0, 100, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, (-1.0f), 10.0f, 100.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(-1.0d), 100.0d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 1.0f, 1.0f, var4, 100.0d, 0.0f, (-1.0f));
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)1.0d);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.block.Arrangement var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0d, (java.lang.Object)0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)false, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    float[] var5 = new float[] { 10.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(1, (-1), 1, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2, (-1.0f), 1, var5);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 100);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.CategoryMarker var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, (-1.0f));
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)0, var1, var2);
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    var3.setType(var4);
    java.lang.Object var6 = var3.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)0+ "'", var6.equals((short)0));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("hi!");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var5.setArea(var12);
    org.jfree.chart.util.RectangleAnchor var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, var14, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.axis.Axis var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.AxisChangeEvent var1 = new org.jfree.chart.event.AxisChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     var4.zoom(0.0d);
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var3 = null;
//     float[] var4 = null;
//     float[] var5 = var2.getComponents(var3, var4);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(short)(-1), 1.0d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var3 = null;
//     float var4 = var1.calculateBaselineOffset(var2, var3);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (-1.0d), var2);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     double var12 = var11.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var13 = var11.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var14 = var11.getRowRenderingOrder();
//     var4.setColumnRenderingOrder(var14);
//     
//     // Checks the contract:  equals-hashcode on var4 and var11
//     assertTrue("Contract failed: equals-hashcode on var4 and var11", var4.equals(var11) ? var4.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var4
//     assertTrue("Contract failed: equals-hashcode on var11 and var4", var11.equals(var4) ? var11.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var13
//     assertTrue("Contract failed: equals-hashcode on var6 and var13", var6.equals(var13) ? var6.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var6
//     assertTrue("Contract failed: equals-hashcode on var13 and var6", var13.equals(var6) ? var13.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
//     org.jfree.chart.util.Size2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    double var7 = var6.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var9 = null;
    java.util.List var10 = var6.getCategoriesForAxis(var9);
    double var11 = var6.getAnchorValue();
    java.awt.Color var14 = java.awt.Color.getColor("", 1);
    var6.setOutlinePaint((java.awt.Paint)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var16 = new org.jfree.chart.text.TextLine("hi!", var1, (java.awt.Paint)var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var4.drawBackground(var7, var8);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)1, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var4.rendererChanged(var9);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var4.handleClick(0, (-16777216), var13);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 'a'};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { "hi!"};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer(var0, var1, (java.lang.Comparable)(-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    org.jfree.chart.axis.Axis var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    org.jfree.chart.util.RectangleEdge var8 = var6.getDomainAxisEdge((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var1, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     double var17 = var16.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     int var20 = var16.getIndexOf(var19);
//     java.util.List var21 = var16.getCategories();
//     org.jfree.chart.LegendItemSource[] var22 = new org.jfree.chart.LegendItemSource[] { var16};
//     var10.setSources(var22);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
//     var1.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var7 = var1.getBounds();
//     org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("hi!");
//     var9.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var15 = var9.getBounds();
//     org.jfree.chart.util.RectangleAnchor var16 = null;
//     java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.intersects(var7, var15);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "hi!");
    java.awt.Paint var9 = null;
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    double var15 = var14.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var17 = var14.getRowRenderingOrder();
    java.awt.Stroke var18 = var14.getOutlineStroke();
    java.awt.Paint var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem(var0, "", "Size2D[width=-1.0, height=-1.0]", "SortOrder.ASCENDING", var6, var9, var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     org.jfree.chart.plot.Marker var8 = null;
//     org.jfree.chart.util.Layer var9 = null;
//     var4.addRangeMarker(var8, var9);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     int var8 = var4.getIndexOf(var7);
//     java.util.List var9 = var4.getCategories();
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var4.getRangeMarkers(var10);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     org.jfree.chart.util.RectangleEdge var18 = var16.getDomainAxisEdge((-1));
//     boolean var19 = var4.equals((java.lang.Object)(-1));
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     double var15 = var14.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     java.util.List var18 = var14.getCategoriesForAxis(var17);
//     double var19 = var14.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     java.awt.Paint var21 = var20.getBackgroundPaint();
//     java.awt.Font var22 = var20.getItemFont();
//     var4.setNoDataMessageFont(var22);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var16
//     assertTrue("Contract failed: equals-hashcode on var6 and var16", var6.equals(var16) ? var6.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var6
//     assertTrue("Contract failed: equals-hashcode on var16 and var6", var16.equals(var6) ? var16.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("");
    double var9 = var8.getHeight();
    java.awt.Paint var10 = var8.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem(var0, "Size2D[width=-1.0, height=-1.0]", "Size2D[width=-1.0, height=-1.0]", "hi!", var6, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 0.0d, "hi!", var3, var4, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 100.0d);
//     org.jfree.data.Range var5 = org.jfree.data.Range.shift(var0, (-1.0d), true);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
//     double var11 = var10.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var12 = var10.getDrawingSupplier();
//     var4.setDrawingSupplier(var12);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var4.rendererChanged(var9);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var18 = var15.getRowRenderingOrder();
//     java.awt.Stroke var19 = var15.getOutlineStroke();
//     var4.setRangeGridlineStroke(var19);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.RectangleEdge var6 = var4.getDomainAxisEdge((-1));
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     int var10 = var9.getSubplotCount();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     java.util.List var19 = var15.getCategoriesForAxis(var18);
//     var15.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("hi!");
//     var27.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var33 = var27.getBounds();
//     org.jfree.chart.util.RectangleAnchor var34 = null;
//     java.awt.geom.Point2D var35 = org.jfree.chart.util.RectangleAnchor.coordinates(var33, var34);
//     var15.zoomDomainAxes(100.0d, 10.0d, var25, var35);
//     var4.zoomRangeAxes(0.0d, var9, var35);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var25
//     assertTrue("Contract failed: equals-hashcode on var9 and var25", var9.equals(var25) ? var9.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var9
//     assertTrue("Contract failed: equals-hashcode on var25 and var9", var25.equals(var9) ? var25.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.DatasetRenderingOrder var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDatasetRenderingOrder(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     int var9 = var4.getDomainAxisCount();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     double var15 = var14.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     int var18 = var14.getIndexOf(var17);
//     java.util.List var19 = var14.getCategories();
//     org.jfree.chart.axis.AxisLocation var20 = var14.getDomainAxisLocation();
//     var4.setDomainAxisLocation(var20, false);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    var2.setHeight((-1.0d));
    double var5 = var2.getWidth();
    var2.setHeight(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.0d));

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    int var8 = var4.getIndexOf(var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var4.setFixedLegendItems(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
//     double var2 = var1.getHeight();
//     java.awt.Paint var3 = var1.getPaint();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("hi!");
//     var6.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var12 = var6.getBounds();
//     java.lang.Object var14 = var1.draw(var4, var12, (java.lang.Object)'#');
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 10.0f, 100.0f, var4, 0.0d, var6);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     java.util.List var19 = var15.getCategoriesForAxis(var18);
//     double var20 = var15.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     java.awt.Paint var22 = var21.getBackgroundPaint();
//     java.awt.Font var23 = var21.getItemFont();
//     var10.setItemFont(var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     var18.setOutlinePaint((java.awt.Paint)var26);
//     org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var26);
//     
//     // Checks the contract:  equals-hashcode on var7 and var20
//     assertTrue("Contract failed: equals-hashcode on var7 and var20", var7.equals(var20) ? var7.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var7
//     assertTrue("Contract failed: equals-hashcode on var20 and var7", var20.equals(var7) ? var20.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("hi!");
//     var16.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var22 = var16.getBounds();
//     org.jfree.chart.util.RectangleAnchor var23 = null;
//     java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
//     var4.zoomDomainAxes(100.0d, 10.0d, var14, var24);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var27, var28, var29, var30);
//     double var32 = var31.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var33 = var31.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     int var35 = var31.getIndexOf(var34);
//     java.util.List var36 = var31.getCategories();
//     org.jfree.chart.axis.AxisLocation var37 = var31.getDomainAxisLocation();
//     var4.setRangeAxisLocation(10, var37, false);
//     
//     // Checks the contract:  equals-hashcode on var31 and var4
//     assertTrue("Contract failed: equals-hashcode on var31 and var4", var31.equals(var4) ? var31.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var4.", var31.equals(var4) == var4.equals(var31));
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
//     java.awt.Paint var26 = var25.getBackgroundPaint();
//     java.awt.Font var27 = var25.getItemFont();
//     org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("hi!");
//     var29.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var35 = var29.getBounds();
//     java.awt.Paint var36 = var29.getPaint();
//     org.jfree.chart.block.LabelBlock var37 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var27, var36);
//     org.jfree.chart.text.TextMeasurer var39 = null;
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("SortOrder.ASCENDING", var13, var36, 100.0f, var39);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     double var18 = var17.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     java.util.List var21 = var17.getCategoriesForAxis(var20);
//     double var22 = var17.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     java.awt.Paint var24 = var23.getBackgroundPaint();
//     java.awt.Font var25 = var23.getItemFont();
//     org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("hi!");
//     var27.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var33 = var27.getBounds();
//     java.awt.Paint var34 = var27.getPaint();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var25, var34);
//     var10.setItemFont(var25);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     java.awt.Stroke var14 = var4.getDomainGridlineStroke();
//     java.awt.Color var17 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var18 = var17.getColorSpace();
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
//     var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var28 = var22.getBounds();
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
//     var4.setNoDataMessagePaint((java.awt.Paint)var17);
//     java.awt.image.ColorModel var33 = null;
//     java.awt.Rectangle var34 = null;
//     java.awt.Color var37 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var38 = var37.getColorSpace();
//     java.awt.image.ColorModel var39 = null;
//     java.awt.Rectangle var40 = null;
//     org.jfree.chart.block.LabelBlock var42 = new org.jfree.chart.block.LabelBlock("hi!");
//     var42.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var48 = var42.getBounds();
//     java.awt.geom.AffineTransform var49 = null;
//     java.awt.RenderingHints var50 = null;
//     java.awt.PaintContext var51 = var37.createContext(var39, var40, var48, var49, var50);
//     java.awt.geom.AffineTransform var52 = null;
//     java.awt.RenderingHints var53 = null;
//     java.awt.PaintContext var54 = var17.createContext(var33, var34, (java.awt.geom.Rectangle2D)var40, var52, var53);
//     
//     // Checks the contract:  equals-hashcode on var22 and var42
//     assertTrue("Contract failed: equals-hashcode on var22 and var42", var22.equals(var42) ? var22.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var22
//     assertTrue("Contract failed: equals-hashcode on var42 and var22", var42.equals(var22) ? var42.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     java.awt.Font var12 = var10.getItemFont();
//     org.jfree.chart.util.VerticalAlignment var13 = var10.getVerticalAlignment();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var20 = var18.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     int var22 = var18.getIndexOf(var21);
//     boolean var23 = var13.equals((java.lang.Object)var22);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var24 = var18.getOrientation();
//     var4.setOrientation(var24);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("hi!");
    var5.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var11 = var5.getBounds();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    double var17 = var16.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var19 = null;
    java.util.List var20 = var16.getCategoriesForAxis(var19);
    double var21 = var16.getAnchorValue();
    java.awt.Color var24 = java.awt.Color.getColor("", 1);
    var16.setOutlinePaint((java.awt.Paint)var24);
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
    double var31 = var30.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var33 = var30.getRowRenderingOrder();
    java.awt.Stroke var34 = var30.getOutlineStroke();
    java.awt.Paint var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem(var0, "", "hi!", "", (java.awt.Shape)var11, (java.awt.Paint)var24, var34, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, (-1.0f), (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-253));

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0f, 1.0f, 1.0d, 100.0f, 10.0f);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.RectangleEdge var6 = var4.getDomainAxisEdge((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
    var1.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var7 = var1.getBounds();
    org.jfree.chart.util.RectangleAnchor var8 = null;
    java.awt.geom.Point2D var9 = org.jfree.chart.util.RectangleAnchor.coordinates(var7, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     java.awt.Font var12 = var10.getItemFont();
//     org.jfree.chart.util.VerticalAlignment var13 = var10.getVerticalAlignment();
//     org.jfree.chart.event.TitleChangeListener var14 = null;
//     var10.addChangeListener(var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("hi!");
//     var18.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var24 = var18.getBounds();
//     org.jfree.chart.util.RectangleAnchor var25 = null;
//     java.awt.geom.Point2D var26 = org.jfree.chart.util.RectangleAnchor.coordinates(var24, var25);
//     var10.draw(var16, var24);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var5 = var4.getColorSpace();
    java.awt.image.ColorModel var6 = null;
    java.awt.Rectangle var7 = null;
    org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("hi!");
    var9.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var15 = var9.getBounds();
    java.awt.geom.AffineTransform var16 = null;
    java.awt.RenderingHints var17 = null;
    java.awt.PaintContext var18 = var4.createContext(var6, var7, var15, var16, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("SortOrder.ASCENDING", var1, (java.awt.Paint)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-16777216), 1, (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.Color var3 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var4 = var3.getColorSpace();
//     java.awt.image.ColorModel var5 = null;
//     java.awt.Rectangle var6 = null;
//     org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("hi!");
//     var8.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var14 = var8.getBounds();
//     java.awt.geom.AffineTransform var15 = null;
//     java.awt.RenderingHints var16 = null;
//     java.awt.PaintContext var17 = var3.createContext(var5, var6, var14, var15, var16);
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var14);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.RectangleEdge var6 = var4.getDomainAxisEdge((-1));
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     double var12 = var11.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var13 = var11.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     java.util.List var15 = var11.getCategoriesForAxis(var14);
//     double var16 = var11.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var17 = var11.getOrientation();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var18};
//     var11.setRenderers(var19);
//     boolean var21 = var6.equals((java.lang.Object)var19);
//     
//     // Checks the contract:  equals-hashcode on var4 and var11
//     assertTrue("Contract failed: equals-hashcode on var4 and var11", var4.equals(var11) ? var4.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var4
//     assertTrue("Contract failed: equals-hashcode on var11 and var4", var11.equals(var4) ? var11.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     java.awt.Font var12 = var10.getItemFont();
//     org.jfree.chart.util.VerticalAlignment var13 = var10.getVerticalAlignment();
//     org.jfree.chart.event.TitleChangeListener var14 = null;
//     var10.addChangeListener(var14);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     java.util.List var25 = var21.getCategoriesForAxis(var24);
//     double var26 = var21.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
//     java.awt.Paint var28 = var27.getBackgroundPaint();
//     java.awt.Font var29 = var27.getItemFont();
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("hi!", var29);
//     org.jfree.chart.util.RectangleEdge var31 = var30.getPosition();
//     var10.setPosition(var31);
//     
//     // Checks the contract:  equals-hashcode on var4 and var21
//     assertTrue("Contract failed: equals-hashcode on var4 and var21", var4.equals(var21) ? var4.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var4
//     assertTrue("Contract failed: equals-hashcode on var21 and var4", var21.equals(var4) ? var21.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var23
//     assertTrue("Contract failed: equals-hashcode on var6 and var23", var6.equals(var23) ? var6.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var6
//     assertTrue("Contract failed: equals-hashcode on var23 and var6", var23.equals(var6) ? var23.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleAnchor var11 = var10.getLegendItemGraphicLocation();
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    org.jfree.chart.text.TextAnchor var13 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var17 = new org.jfree.chart.axis.CategoryLabelPosition(var11, var12, var13, 10.0d, var15, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SortOrder.ASCENDING", var1);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     java.awt.Font var14 = var12.getItemFont();
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("hi!");
//     var16.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var22 = var16.getBounds();
//     java.awt.Paint var23 = var16.getPaint();
//     org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var14, var23);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var25, var26, var27, var28);
//     double var30 = var29.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var31 = var29.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     java.util.List var33 = var29.getCategoriesForAxis(var32);
//     double var34 = var29.getAnchorValue();
//     java.awt.Color var37 = java.awt.Color.getColor("", 1);
//     var29.setOutlinePaint((java.awt.Paint)var37);
//     float var39 = var29.getForegroundAlpha();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     var29.setRenderer(var40, false);
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("Size2D[width=-1.0, height=-1.0]", var14, (org.jfree.chart.plot.Plot)var29, true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Size2D[width=-1.0, height=-1.0]");

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-253), 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleAnchor var11 = var10.getLegendItemGraphicLocation();
    java.lang.String var12 = var10.getID();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setHorizontalAlignment(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=-1.0, height=-1.0]", var1, (-1.0f), (-1.0f), (-1.0d), 100.0f, 1.0f);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    java.lang.Object var0 = null;
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("PlotOrientation.VERTICAL", var1);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 0);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    int var8 = var4.getIndexOf(var7);
    java.util.List var9 = var4.getCategories();
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var4.getRangeMarkers(var10);
    org.jfree.chart.plot.DatasetRenderingOrder var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDatasetRenderingOrder(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.general.Dataset var1 = null;
    org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)(-1), var1);
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=-1]"+ "'", var3.equals("org.jfree.data.general.DatasetChangeEvent[source=-1]"));

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    java.awt.Stroke var8 = var4.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    double var15 = var14.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var17 = null;
    java.util.List var18 = var14.getCategoriesForAxis(var17);
    double var19 = var14.getAnchorValue();
    java.awt.Color var22 = java.awt.Color.getColor("", 1);
    var14.setOutlinePaint((java.awt.Paint)var22);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    double var29 = var28.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var30 = var28.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    int var32 = var28.getIndexOf(var31);
    java.util.List var33 = var28.getCategories();
    org.jfree.chart.axis.AxisLocation var34 = var28.getDomainAxisLocation();
    var14.setDomainAxisLocation(var34, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation((-253), var34, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     var4.mapDatasetToDomainAxis(0, 0);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var21 = var19.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     int var23 = var19.getIndexOf(var22);
//     java.util.List var24 = var19.getCategories();
//     org.jfree.chart.axis.AxisLocation var25 = var19.getDomainAxisLocation();
//     var4.setDomainAxisLocation(100, var25, false);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var4.", var19.equals(var4) == var4.equals(var19));
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, 100.0f, 0.0f);
//     java.awt.color.ColorSpace var4 = null;
//     float[] var7 = new float[] { 10.0f, 10.0f};
//     float[] var8 = var3.getComponents(var4, var7);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var10 = new org.jfree.chart.entity.TickLabelEntity(var7, "hi!", "hi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var12 = null;
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var11, var12);
    boolean var14 = var10.equals((java.lang.Object)var11);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var10.setArea(var17);
    org.jfree.chart.entity.CategoryLabelEntity var21 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)1, var17, "SortOrder.ASCENDING", "SortOrder.ASCENDING");
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
    double var27 = var26.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var28 = var26.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var29 = null;
    java.util.List var30 = var26.getCategoriesForAxis(var29);
    double var31 = var26.getAnchorValue();
    java.awt.Color var34 = java.awt.Color.getColor("", 1);
    var26.setOutlinePaint((java.awt.Paint)var34);
    java.awt.Stroke var36 = var26.getDomainGridlineStroke();
    org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("hi!");
    var38.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var44 = var38.getBounds();
    java.awt.Paint var45 = var38.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem(var0, "hi!", "RectangleAnchor.CENTER", "hi!", var17, var36, var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, (-1.0d), false);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "hi!", "hi!");
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var11 = null;
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(var10, var11);
    boolean var13 = var9.equals((java.lang.Object)var10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var9.setArea(var16);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    double var25 = var24.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    java.util.List var28 = var24.getCategoriesForAxis(var27);
    double var29 = var24.getAnchorValue();
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    java.awt.Paint var31 = var30.getBackgroundPaint();
    java.awt.Font var32 = var30.getItemFont();
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("hi!", var32);
    java.awt.Paint var34 = var33.getPaint();
    org.jfree.data.category.CategoryDataset var35 = null;
    org.jfree.chart.axis.CategoryAxis var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
    double var40 = var39.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var41 = var39.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var42 = var39.getRowRenderingOrder();
    java.awt.Stroke var43 = var39.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
    double var49 = var48.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var50 = var48.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var51 = null;
    java.util.List var52 = var48.getCategoriesForAxis(var51);
    double var53 = var48.getAnchorValue();
    var48.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var56 = new org.jfree.chart.block.LabelBlock("");
    double var57 = var56.getHeight();
    java.awt.Paint var58 = var56.getPaint();
    var48.setRangeCrosshairPaint(var58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem(var0, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "org.jfree.chart.event.ChartChangeEvent[source=0]", "RectangleAnchor.CENTER", var16, var34, var43, var58);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("PlotOrientation.VERTICAL", var1, var2, var3);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.Color var18 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var19 = var18.getColorSpace();
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
//     var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var29 = var23.getBounds();
//     java.awt.geom.AffineTransform var30 = null;
//     java.awt.RenderingHints var31 = null;
//     java.awt.PaintContext var32 = var18.createContext(var20, var21, var29, var30, var31);
//     var14.draw(var15, var29);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
//     double var41 = var40.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var42 = var40.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     java.util.List var44 = var40.getCategoriesForAxis(var43);
//     double var45 = var40.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     java.awt.Paint var47 = var46.getBackgroundPaint();
//     java.awt.Font var48 = var46.getItemFont();
//     org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("hi!", var48);
//     java.awt.Graphics2D var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     var49.draw(var50, var51);
//     java.awt.Paint var53 = var49.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var54 = var49.getBounds();
//     org.jfree.chart.ChartRenderingInfo var55 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var56 = new org.jfree.chart.plot.PlotRenderingInfo(var55);
//     java.lang.Object var57 = var14.draw(var34, var54, (java.lang.Object)var55);
//     
//     // Checks the contract:  equals-hashcode on var5 and var40
//     assertTrue("Contract failed: equals-hashcode on var5 and var40", var5.equals(var40) ? var5.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var5
//     assertTrue("Contract failed: equals-hashcode on var40 and var5", var40.equals(var5) ? var40.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var42
//     assertTrue("Contract failed: equals-hashcode on var7 and var42", var7.equals(var42) ? var7.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var7
//     assertTrue("Contract failed: equals-hashcode on var42 and var7", var42.equals(var7) ? var42.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Size2D[width=-1.0, height=-1.0]", var1, var2);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var7 = null;
    var4.setFixedDomainAxisSpace(var7);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var4.removeAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var2 = var1.getID();
    var1.setMargin(0.0d, 0.0d, (-1.0d), 1.0d);
    double var8 = var1.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    float var14 = var4.getForegroundAlpha();
    org.jfree.chart.axis.ValueAxis var16 = var4.getRangeAxis(0);
    org.jfree.chart.plot.CategoryMarker var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
//     double var9 = var8.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     java.util.List var12 = var8.getCategoriesForAxis(var11);
//     double var13 = var8.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     java.awt.Paint var15 = var14.getBackgroundPaint();
//     java.awt.Font var16 = var14.getItemFont();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("hi!", var16);
//     java.awt.Graphics2D var18 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var22 = var21.getColorSpace();
//     java.awt.image.ColorModel var23 = null;
//     java.awt.Rectangle var24 = null;
//     org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("hi!");
//     var26.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var32 = var26.getBounds();
//     java.awt.geom.AffineTransform var33 = null;
//     java.awt.RenderingHints var34 = null;
//     java.awt.PaintContext var35 = var21.createContext(var23, var24, var32, var33, var34);
//     var17.draw(var18, var32);
//     var0.draw(var2, var32);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var4.zoomRangeAxes((-1.0d), 1.0d, var16, var17);
//     org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("hi!");
//     var20.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var26 = var20.getBounds();
//     java.awt.Paint var27 = var20.getPaint();
//     var4.setRangeGridlinePaint(var27);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
//     double var34 = var33.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var35 = var33.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     int var37 = var33.getIndexOf(var36);
//     org.jfree.chart.LegendItemCollection var38 = null;
//     var33.setFixedLegendItems(var38);
//     org.jfree.chart.event.PlotChangeListener var40 = null;
//     var33.addChangeListener(var40);
//     var33.setAnchorValue((-1.0d), true);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
//     double var50 = var49.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var51 = var49.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var52 = var49.getRowRenderingOrder();
//     java.awt.Stroke var53 = var49.getOutlineStroke();
//     var33.setOutlineStroke(var53);
//     var4.setDomainGridlineStroke(var53);
//     
//     // Checks the contract:  equals-hashcode on var6 and var51
//     assertTrue("Contract failed: equals-hashcode on var6 and var51", var6.equals(var51) ? var6.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var6
//     assertTrue("Contract failed: equals-hashcode on var51 and var6", var51.equals(var6) ? var51.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
//     var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var10 = var4.getBounds();
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
//     var0.setTickMarkOutsideLength(0.0f);
//     float var17 = var0.getTickMarkOutsideLength();
//     java.awt.Color var22 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var23 = var22.getColorSpace();
//     java.awt.image.ColorModel var24 = null;
//     java.awt.Rectangle var25 = null;
//     org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("hi!");
//     var27.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var33 = var27.getBounds();
//     java.awt.geom.AffineTransform var34 = null;
//     java.awt.RenderingHints var35 = null;
//     java.awt.PaintContext var36 = var22.createContext(var24, var25, var33, var34, var35);
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
//     double var42 = var41.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var43 = var41.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var44 = null;
//     java.util.List var45 = var41.getCategoriesForAxis(var44);
//     double var46 = var41.getAnchorValue();
//     java.awt.Color var49 = java.awt.Color.getColor("", 1);
//     var41.setOutlinePaint((java.awt.Paint)var49);
//     org.jfree.chart.title.LegendGraphic var51 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var33, (java.awt.Paint)var49);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var53, var54, var55, var56);
//     double var58 = var57.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var59 = var57.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var60 = null;
//     java.util.List var61 = var57.getCategoriesForAxis(var60);
//     double var62 = var57.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57);
//     java.awt.Paint var64 = var63.getBackgroundPaint();
//     java.awt.Font var65 = var63.getItemFont();
//     org.jfree.chart.title.TextTitle var66 = new org.jfree.chart.title.TextTitle("hi!", var65);
//     org.jfree.chart.util.RectangleEdge var67 = var66.getPosition();
//     double var68 = var0.getCategoryStart(1, (-253), var33, var67);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var59
//     assertTrue("Contract failed: equals-hashcode on var43 and var59", var43.equals(var59) ? var43.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var43
//     assertTrue("Contract failed: equals-hashcode on var59 and var43", var59.equals(var43) ? var59.hashCode() == var43.hashCode() : true);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var6 = new org.jfree.chart.entity.TickLabelEntity(var3, "hi!", "hi!");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, var8);
    boolean var10 = var6.equals((java.lang.Object)var7);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var6.setArea(var13);
    org.jfree.chart.entity.CategoryLabelEntity var17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)1, var13, "SortOrder.ASCENDING", "SortOrder.ASCENDING");
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    double var23 = var22.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var25 = null;
    java.util.List var26 = var22.getCategoriesForAxis(var25);
    double var27 = var22.getAnchorValue();
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    java.awt.Paint var29 = var28.getBackgroundPaint();
    java.awt.Font var30 = var28.getItemFont();
    org.jfree.chart.util.VerticalAlignment var31 = var28.getVerticalAlignment();
    org.jfree.chart.event.TitleChangeListener var32 = null;
    var28.addChangeListener(var32);
    boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1, (java.lang.Object)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.awt.RenderingHints var12 = var11.getRenderingHints();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var15 = var11.createBufferedImage((-253), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("PlotOrientation.VERTICAL", var1);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var5.setArea(var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    java.awt.Color var26 = java.awt.Color.getColor("", 1);
    var18.setOutlinePaint((java.awt.Paint)var26);
    java.awt.Stroke var28 = var18.getDomainGridlineStroke();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
    var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var42 = var36.getBounds();
    java.awt.geom.AffineTransform var43 = null;
    java.awt.RenderingHints var44 = null;
    java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
    var18.setNoDataMessagePaint((java.awt.Paint)var31);
    org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
    java.awt.Graphics2D var48 = null;
    org.jfree.data.Range var49 = null;
    org.jfree.data.Range var50 = null;
    org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(var49, var50);
    org.jfree.chart.block.RectangleConstraint var52 = var51.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var54 = var51.toFixedWidth(1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var55 = var47.arrange(var48, var54);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     var4.clearAnnotations();
//     java.awt.Image var8 = null;
//     var4.setBackgroundImage(var8);
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     double var15 = var14.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     java.util.List var18 = var14.getCategoriesForAxis(var17);
//     double var19 = var14.getAnchorValue();
//     var14.clearDomainAxes();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     java.awt.RenderingHints var22 = var21.getRenderingHints();
//     java.awt.Stroke var23 = var21.getBorderStroke();
//     var4.setRangeGridlineStroke(var23);
//     
//     // Checks the contract:  equals-hashcode on var6 and var16
//     assertTrue("Contract failed: equals-hashcode on var6 and var16", var6.equals(var16) ? var6.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var6
//     assertTrue("Contract failed: equals-hashcode on var16 and var6", var16.equals(var6) ? var16.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
//     var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var10 = var4.getBounds();
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
//     var0.setTickMarkOutsideLength(0.0f);
//     float var17 = var0.getTickMarkOutsideLength();
//     java.awt.Color var20 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var21 = var20.getColorSpace();
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("hi!");
//     var25.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var31 = var25.getBounds();
//     java.awt.geom.AffineTransform var32 = null;
//     java.awt.RenderingHints var33 = null;
//     java.awt.PaintContext var34 = var20.createContext(var22, var23, var31, var32, var33);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     double var40 = var39.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var41 = var39.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     java.util.List var43 = var39.getCategoriesForAxis(var42);
//     double var44 = var39.getAnchorValue();
//     java.awt.Color var47 = java.awt.Color.getColor("", 1);
//     var39.setOutlinePaint((java.awt.Paint)var47);
//     org.jfree.chart.title.LegendGraphic var49 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var31, (java.awt.Paint)var47);
//     var0.setTickMarkPaint((java.awt.Paint)var47);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject("[size=1]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var4.setFixedRangeAxisSpace(var10);
//     org.jfree.chart.event.AxisChangeEvent var12 = null;
//     var4.axisChanged(var12);
//     org.jfree.chart.plot.Marker var14 = null;
//     var4.addRangeMarker(var14);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     double var12 = var10.getWidth();
//     org.jfree.chart.util.RectangleInsets var13 = var10.getLegendItemGraphicPadding();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var19 = new org.jfree.chart.entity.TickLabelEntity(var16, "hi!", "hi!");
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var21 = null;
//     org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(var20, var21);
//     boolean var23 = var19.equals((java.lang.Object)var20);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var19.setArea(var26);
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     double var33 = var32.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var34 = var32.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     java.util.List var36 = var32.getCategoriesForAxis(var35);
//     double var37 = var32.getAnchorValue();
//     java.awt.Color var40 = java.awt.Color.getColor("", 1);
//     var32.setOutlinePaint((java.awt.Paint)var40);
//     java.awt.Stroke var42 = var32.getDomainGridlineStroke();
//     java.awt.Color var45 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var46 = var45.getColorSpace();
//     java.awt.image.ColorModel var47 = null;
//     java.awt.Rectangle var48 = null;
//     org.jfree.chart.block.LabelBlock var50 = new org.jfree.chart.block.LabelBlock("hi!");
//     var50.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var56 = var50.getBounds();
//     java.awt.geom.AffineTransform var57 = null;
//     java.awt.RenderingHints var58 = null;
//     java.awt.PaintContext var59 = var45.createContext(var47, var48, var56, var57, var58);
//     var32.setNoDataMessagePaint((java.awt.Paint)var45);
//     org.jfree.chart.title.LegendGraphic var61 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var45);
//     org.jfree.chart.util.RectangleAnchor var62 = var61.getShapeAnchor();
//     var10.setLegendItemGraphicLocation(var62);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    double var12 = var11.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var13 = var11.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var14 = null;
    java.util.List var15 = var11.getCategoriesForAxis(var14);
    double var16 = var11.getAnchorValue();
    var11.clearDomainAxes();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    java.awt.Stroke var20 = null;
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
    double var27 = var26.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var28 = var26.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var29 = null;
    java.util.List var30 = var26.getCategoriesForAxis(var29);
    double var31 = var26.getAnchorValue();
    java.awt.Color var34 = java.awt.Color.getColor("", 1);
    var26.setOutlinePaint((java.awt.Paint)var34);
    java.awt.Stroke var36 = var26.getDomainGridlineStroke();
    java.awt.Color var39 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var40 = var39.getColorSpace();
    java.awt.image.ColorModel var41 = null;
    java.awt.Rectangle var42 = null;
    org.jfree.chart.block.LabelBlock var44 = new org.jfree.chart.block.LabelBlock("hi!");
    var44.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var50 = var44.getBounds();
    java.awt.geom.AffineTransform var51 = null;
    java.awt.RenderingHints var52 = null;
    java.awt.PaintContext var53 = var39.createContext(var41, var42, var50, var51, var52);
    var26.setNoDataMessagePaint((java.awt.Paint)var39);
    java.awt.Color var55 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=0]", var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem(var0, "[size=1]", "10", "", var6, var19, var20, (java.awt.Paint)var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     double var17 = var16.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var19 = null;
//     var16.setFixedLegendItems(var19);
//     boolean var21 = var16.isSubplot();
//     var16.configureDomainAxes();
//     org.jfree.chart.event.PlotChangeEvent var23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var16);
//     var11.plotChanged(var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var18
//     assertTrue("Contract failed: equals-hashcode on var6 and var18", var6.equals(var18) ? var6.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var6
//     assertTrue("Contract failed: equals-hashcode on var18 and var6", var18.equals(var6) ? var18.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
//     var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var10 = var4.getBounds();
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
//     var0.setMaximumCategoryLabelLines(10);
//     var0.setTickLabelsVisible(false);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("hi!");
//     var26.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var32 = var26.getBounds();
//     org.jfree.chart.util.RectangleAnchor var33 = null;
//     java.awt.geom.Point2D var34 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var33);
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var22.getCategoryStart((-16777216), (-16777216), var32, var35);
//     org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)100, (java.awt.Shape)var32, "hi!", "[size=1]");
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     double var46 = var45.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     java.util.List var49 = var45.getCategoriesForAxis(var48);
//     double var50 = var45.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
//     java.awt.Paint var52 = var51.getBackgroundPaint();
//     java.awt.Font var53 = var51.getItemFont();
//     org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle("hi!", var53);
//     org.jfree.chart.util.RectangleEdge var55 = var54.getPosition();
//     double var56 = var0.getCategoryEnd((-1), (-253), var32, var55);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    boolean var11 = var4.isOutlineVisible();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("hi!");
    var17.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var23 = var17.getBounds();
    org.jfree.chart.util.RectangleAnchor var24 = null;
    java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var13.getCategoryStart((-16777216), (-16777216), var23, var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxis((-16777216), var13, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    var4.clearAnnotations();
    java.awt.Image var8 = null;
    var4.setBackgroundImage(var8);
    org.jfree.chart.plot.DrawingSupplier var10 = null;
    var4.setDrawingSupplier(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    org.jfree.chart.util.Layer var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getMargin();
//     double var14 = var12.calculateRightInset(0.0d);
//     java.awt.Color var17 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var18 = var17.getColorSpace();
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
//     var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var28 = var22.getBounds();
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
//     double var37 = var36.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var38 = var36.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     java.util.List var40 = var36.getCategoriesForAxis(var39);
//     double var41 = var36.getAnchorValue();
//     java.awt.Color var44 = java.awt.Color.getColor("", 1);
//     var36.setOutlinePaint((java.awt.Paint)var44);
//     org.jfree.chart.title.LegendGraphic var46 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var28, (java.awt.Paint)var44);
//     java.awt.geom.Rectangle2D var47 = var12.createOutsetRectangle(var28);
//     
//     // Checks the contract:  equals-hashcode on var6 and var38
//     assertTrue("Contract failed: equals-hashcode on var6 and var38", var6.equals(var38) ? var6.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var6
//     assertTrue("Contract failed: equals-hashcode on var38 and var6", var38.equals(var6) ? var38.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.clearAnnotations();
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var10 = new org.jfree.chart.entity.TickLabelEntity(var7, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-253), var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     java.awt.Font var14 = var12.getItemFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("hi!", var14);
//     org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("", var14);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.text.TextAnchor var20 = null;
//     var16.draw(var17, 1.0f, 0.0f, var20, (-1.0f), 0.0f, (-1.0d));
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
//     boolean var9 = var5.equals((java.lang.Object)var6);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var5.setArea(var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     var18.setOutlinePaint((java.awt.Paint)var26);
//     java.awt.Stroke var28 = var18.getDomainGridlineStroke();
//     java.awt.Color var31 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var32 = var31.getColorSpace();
//     java.awt.image.ColorModel var33 = null;
//     java.awt.Rectangle var34 = null;
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
//     var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var42 = var36.getBounds();
//     java.awt.geom.AffineTransform var43 = null;
//     java.awt.RenderingHints var44 = null;
//     java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
//     var18.setNoDataMessagePaint((java.awt.Paint)var31);
//     org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
//     java.awt.Shape var48 = var47.getShape();
//     var47.setShapeOutlineVisible(true);
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var51, var52, var53, var54);
//     double var56 = var55.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var57 = var55.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var58 = var55.getRowRenderingOrder();
//     java.awt.Stroke var59 = var55.getOutlineStroke();
//     var47.setLineStroke(var59);
//     
//     // Checks the contract:  equals-hashcode on var20 and var57
//     assertTrue("Contract failed: equals-hashcode on var20 and var57", var20.equals(var57) ? var20.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var20
//     assertTrue("Contract failed: equals-hashcode on var57 and var20", var57.equals(var20) ? var57.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(short)100);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)'#', 0.0d, (-253));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     var5.setDomainGridlinesVisible(false);
//     var5.mapDatasetToDomainAxis(0, 0);
//     java.awt.Font var15 = var5.getNoDataMessageFont();
//     java.awt.Color var18 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var19 = var18.getColorSpace();
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
//     var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var29 = var23.getBounds();
//     java.awt.geom.AffineTransform var30 = null;
//     java.awt.RenderingHints var31 = null;
//     java.awt.PaintContext var32 = var18.createContext(var20, var21, var29, var30, var31);
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     double var38 = var37.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var39 = var37.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     java.util.List var41 = var37.getCategoriesForAxis(var40);
//     double var42 = var37.getAnchorValue();
//     java.awt.Color var45 = java.awt.Color.getColor("", 1);
//     var37.setOutlinePaint((java.awt.Paint)var45);
//     org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var29, (java.awt.Paint)var45);
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.text.G2TextMeasurer var50 = new org.jfree.chart.text.G2TextMeasurer(var49);
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("10", var15, (java.awt.Paint)var45, 0.0f, (org.jfree.chart.text.TextMeasurer)var50);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     java.awt.Font var12 = var10.getItemFont();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     java.awt.Paint var25 = var24.getBackgroundPaint();
//     java.awt.Font var26 = var24.getItemFont();
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("hi!", var26);
//     org.jfree.chart.util.RectangleEdge var28 = var27.getPosition();
//     var10.setLegendItemGraphicEdge(var28);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
    var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var10 = var4.getBounds();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
    var0.setMaximumCategoryLabelLines(10);
    float var17 = var0.getMaximumCategoryLabelWidthRatio();
    java.lang.String var18 = var0.getLabel();
    java.awt.Paint var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickMarkPaint(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     java.awt.Stroke var8 = var4.getOutlineStroke();
//     org.jfree.chart.axis.CategoryAxis var10 = var4.getDomainAxisForDataset((-253));
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
//     org.jfree.chart.util.RectangleInsets var13 = var11.getInsets();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     var18.clearDomainAxes();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var18);
//     java.awt.Paint var26 = var25.getBackgroundPaint();
//     org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder(var13, var26);
//     var4.setInsets(var13);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)0);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var4.zoomRangeAxes((-1.0d), 1.0d, var16, var17);
//     var4.clearDomainMarkers(10);
//     org.jfree.chart.event.PlotChangeListener var21 = null;
//     var4.addChangeListener(var21);
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
//     double var29 = var28.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var30 = var28.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var31 = var28.getRowRenderingOrder();
//     java.awt.Stroke var32 = var28.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var28.getRendererForDataset(var33);
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var28);
//     java.util.List var36 = var35.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var41 = null;
//     java.awt.image.BufferedImage var42 = var35.createBufferedImage(1, 10, (-1.0d), 1.0d, var41);
//     var4.setBackgroundImage((java.awt.Image)var42);
//     
//     // Checks the contract:  equals-hashcode on var6 and var30
//     assertTrue("Contract failed: equals-hashcode on var6 and var30", var6.equals(var30) ? var6.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var6
//     assertTrue("Contract failed: equals-hashcode on var30 and var6", var30.equals(var6) ? var30.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
    var1.setWidth((-1.0d));
    java.lang.String var4 = var1.getURLText();
    var1.setURLText("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var14.draw(var15, var16);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
//     double var23 = var22.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     java.util.List var26 = var22.getCategoriesForAxis(var25);
//     double var27 = var22.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
//     org.jfree.chart.util.HorizontalAlignment var29 = var28.getHorizontalAlignment();
//     var14.setHorizontalAlignment(var29);
//     
//     // Checks the contract:  equals-hashcode on var5 and var22
//     assertTrue("Contract failed: equals-hashcode on var5 and var22", var5.equals(var22) ? var5.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var5
//     assertTrue("Contract failed: equals-hashcode on var22 and var5", var22.equals(var5) ? var22.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     java.awt.Paint var2 = var0.getBasePaint();
//     java.awt.Stroke var4 = var0.getSeriesStroke(1);
//     var0.setAutoPopulateSeriesFillPaint(false);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = null;
//     var0.setBaseURLGenerator(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     double var15 = var14.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     java.util.List var18 = var14.getCategoriesForAxis(var17);
//     double var19 = var14.getAnchorValue();
//     java.awt.Color var22 = java.awt.Color.getColor("", 1);
//     var14.setOutlinePaint((java.awt.Paint)var22);
//     java.awt.Stroke var24 = var14.getDomainGridlineStroke();
//     java.awt.Color var27 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var28 = var27.getColorSpace();
//     java.awt.image.ColorModel var29 = null;
//     java.awt.Rectangle var30 = null;
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("hi!");
//     var32.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var38 = var32.getBounds();
//     java.awt.geom.AffineTransform var39 = null;
//     java.awt.RenderingHints var40 = null;
//     java.awt.PaintContext var41 = var27.createContext(var29, var30, var38, var39, var40);
//     var14.setNoDataMessagePaint((java.awt.Paint)var27);
//     var14.setNoDataMessage("");
//     float var45 = var14.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var50 = new org.jfree.chart.block.LabelBlock("hi!");
//     var50.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var56 = var50.getBounds();
//     org.jfree.chart.util.RectangleAnchor var57 = null;
//     java.awt.geom.Point2D var58 = org.jfree.chart.util.RectangleAnchor.coordinates(var56, var57);
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var46.getCategoryStart((-16777216), (-16777216), var56, var59);
//     var46.setMaximumCategoryLabelLines(10);
//     var46.setTickLabelsVisible(false);
//     var46.clearCategoryLabelToolTips();
//     org.jfree.chart.plot.CategoryMarker var66 = null;
//     org.jfree.chart.axis.CategoryAxis var68 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var72 = new org.jfree.chart.block.LabelBlock("hi!");
//     var72.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var78 = var72.getBounds();
//     org.jfree.chart.util.RectangleAnchor var79 = null;
//     java.awt.geom.Point2D var80 = org.jfree.chart.util.RectangleAnchor.coordinates(var78, var79);
//     org.jfree.chart.util.RectangleEdge var81 = null;
//     double var82 = var68.getCategoryStart((-16777216), (-16777216), var78, var81);
//     org.jfree.chart.entity.CategoryLabelEntity var85 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)100, (java.awt.Shape)var78, "hi!", "[size=1]");
//     var0.drawDomainMarker(var9, var14, var46, var66, var78);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    boolean var11 = var4.isOutlineVisible();
    org.jfree.chart.plot.CategoryMarker var13 = null;
    org.jfree.chart.util.Layer var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(10, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
    var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var10 = var4.getBounds();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
    var0.setMaximumCategoryLabelLines(10);
    float var17 = var0.getMaximumCategoryLabelWidthRatio();
    java.awt.Font var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelFont(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0f);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var12 = var11.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
//     java.awt.Shape var15 = var11.lookupSeriesShape(0);
//     int var16 = var4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
//     org.jfree.chart.labels.CategoryToolTipGenerator var18 = null;
//     var11.setSeriesToolTipGenerator(1, var18);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     double var25 = var24.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var27 = null;
//     var24.setFixedLegendItems(var27);
//     var11.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var24
//     assertTrue("Contract failed: equals-hashcode on var4 and var24", var4.equals(var24) ? var4.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var4
//     assertTrue("Contract failed: equals-hashcode on var24 and var4", var24.equals(var4) ? var24.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var26
//     assertTrue("Contract failed: equals-hashcode on var6 and var26", var6.equals(var26) ? var6.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var6
//     assertTrue("Contract failed: equals-hashcode on var26 and var6", var26.equals(var6) ? var26.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == false);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
//     org.jfree.data.Range var3 = null;
//     org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var5);
//     org.jfree.chart.util.Size2D var9 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
//     var9.setHeight((-1.0d));
//     var9.setWidth((-1.0d));
//     var9.setWidth(0.0d);
//     org.jfree.chart.util.Size2D var16 = var6.calculateConstrainedSize(var9);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
//     org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.text.TextAnchor var10 = var9.getLabelTextAnchor();
//     java.awt.Shape var11 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", var1, 0.0f, 100.0f, var6, 1.0d, var10);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Set var2 = var0.keySet();
    java.util.Enumeration var3 = var0.getKeys();
    java.util.Locale var4 = var0.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var6 = var0.getStringArray("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    org.jfree.chart.plot.CategoryMarker var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var4 = var3.getID();
//     int var5 = var1.compareTo((java.lang.Object)var3);
//     java.lang.Comparable[] var6 = new java.lang.Comparable[] { var1};
//     java.lang.Comparable[] var8 = new java.lang.Comparable[] { (byte)(-1)};
//     double[] var9 = null;
//     double[][] var10 = new double[][] { var9};
//     org.jfree.data.category.CategoryDataset var11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var6, var8, var10);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var5);
    org.jfree.chart.block.LengthConstraintType var7 = var2.getWidthConstraintType();
    boolean var9 = var7.equals((java.lang.Object)(-16777216));
    java.lang.String var10 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var10.equals("RectangleConstraintType.RANGE"));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var12 = var10.getMargin();
    double var14 = var12.calculateRightInset(0.0d);
    double var16 = var12.calculateTopOutset(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
//     var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var10 = var4.getBounds();
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
//     java.awt.Paint var26 = var25.getBackgroundPaint();
//     java.awt.Font var27 = var25.getItemFont();
//     var0.setTickLabelFont(var27);
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
//     double var37 = var36.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var38 = var36.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     java.util.List var40 = var36.getCategoriesForAxis(var39);
//     double var41 = var36.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
//     java.awt.Paint var43 = var42.getBackgroundPaint();
//     java.awt.Font var44 = var42.getItemFont();
//     org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("hi!", var44);
//     java.awt.Graphics2D var46 = null;
//     java.awt.Color var49 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var50 = var49.getColorSpace();
//     java.awt.image.ColorModel var51 = null;
//     java.awt.Rectangle var52 = null;
//     org.jfree.chart.block.LabelBlock var54 = new org.jfree.chart.block.LabelBlock("hi!");
//     var54.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var60 = var54.getBounds();
//     java.awt.geom.AffineTransform var61 = null;
//     java.awt.RenderingHints var62 = null;
//     java.awt.PaintContext var63 = var49.createContext(var51, var52, var60, var61, var62);
//     var45.draw(var46, var60);
//     org.jfree.data.category.CategoryDataset var65 = null;
//     org.jfree.chart.axis.CategoryAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var68 = null;
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var65, var66, var67, var68);
//     org.jfree.chart.util.RectangleEdge var71 = var69.getDomainAxisEdge((-1));
//     double var72 = var0.getCategoryEnd((-16777216), 0, var60, var71);
//     
//     // Checks the contract:  equals-hashcode on var4 and var54
//     assertTrue("Contract failed: equals-hashcode on var4 and var54", var4.equals(var54) ? var4.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var4
//     assertTrue("Contract failed: equals-hashcode on var54 and var4", var54.equals(var4) ? var54.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var36
//     assertTrue("Contract failed: equals-hashcode on var19 and var36", var19.equals(var36) ? var19.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var69
//     assertTrue("Contract failed: equals-hashcode on var19 and var69", var19.equals(var69) ? var19.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var19
//     assertTrue("Contract failed: equals-hashcode on var36 and var19", var36.equals(var19) ? var36.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var69
//     assertTrue("Contract failed: equals-hashcode on var36 and var69", var36.equals(var69) ? var36.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var19
//     assertTrue("Contract failed: equals-hashcode on var69 and var19", var69.equals(var19) ? var69.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var36
//     assertTrue("Contract failed: equals-hashcode on var69 and var36", var69.equals(var36) ? var69.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var38
//     assertTrue("Contract failed: equals-hashcode on var21 and var38", var21.equals(var38) ? var21.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var21
//     assertTrue("Contract failed: equals-hashcode on var38 and var21", var38.equals(var21) ? var38.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var0.setBaseURLGenerator(var7);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-253), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var7 = null;
//     var4.setFixedLegendItems(var7);
//     boolean var9 = var4.isSubplot();
//     var4.configureDomainAxes();
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     double var17 = var16.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     java.util.List var20 = var16.getCategoriesForAxis(var19);
//     double var21 = var16.getAnchorValue();
//     java.awt.Color var24 = java.awt.Color.getColor("", 1);
//     var16.setOutlinePaint((java.awt.Paint)var24);
//     java.awt.Stroke var26 = var16.getDomainGridlineStroke();
//     org.jfree.chart.axis.AxisLocation var28 = var16.getDomainAxisLocation(1);
//     var4.setDomainAxisLocation(10, var28, true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var18
//     assertTrue("Contract failed: equals-hashcode on var6 and var18", var6.equals(var18) ? var6.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var6
//     assertTrue("Contract failed: equals-hashcode on var18 and var6", var18.equals(var6) ? var18.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleAnchor.CENTER", var1);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    int var3 = java.awt.Color.HSBtoRGB(10.0f, (-1.0f), 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-8323073));

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    float[] var5 = new float[] { 0.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(10, 0, 0, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var7 = var5.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     int var9 = var5.getIndexOf(var8);
//     java.util.List var10 = var5.getCategories();
//     org.jfree.chart.axis.AxisLocation var11 = var5.getDomainAxisLocation();
//     boolean var12 = var5.isRangeGridlinesVisible();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     double var18 = var17.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     java.util.List var21 = var17.getCategoriesForAxis(var20);
//     double var22 = var17.getAnchorValue();
//     java.awt.Color var25 = java.awt.Color.getColor("", 1);
//     var17.setOutlinePaint((java.awt.Paint)var25);
//     var5.setBackgroundPaint((java.awt.Paint)var25);
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     double var33 = var32.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var34 = var32.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var35 = var32.getRowRenderingOrder();
//     java.awt.Stroke var36 = var32.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var25, var36);
//     
//     // Checks the contract:  equals-hashcode on var19 and var34
//     assertTrue("Contract failed: equals-hashcode on var19 and var34", var19.equals(var34) ? var19.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var19
//     assertTrue("Contract failed: equals-hashcode on var34 and var19", var34.equals(var19) ? var34.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setBounds(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var3 = var2.clone();
//     var0.ensureAtLeast(var2);
//     org.jfree.chart.axis.AxisSpace var5 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var6 = var5.clone();
//     org.jfree.chart.axis.AxisSpace var7 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var8 = var7.clone();
//     var5.ensureAtLeast(var7);
//     var0.ensureAtLeast(var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("hi!");
//     var13.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var19 = var13.getBounds();
//     java.awt.geom.Rectangle2D var20 = var7.expand(var11, var19);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
//     var1.setWidth((-1.0d));
//     java.lang.String var4 = var1.getURLText();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
//     org.jfree.chart.block.RectangleConstraint var9 = var8.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var11 = var8.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var12 = var1.arrange(var5, var11);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var20 = var18.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     int var22 = var18.getIndexOf(var21);
//     java.util.List var23 = var18.getCategories();
//     org.jfree.chart.axis.AxisLocation var24 = var18.getDomainAxisLocation();
//     var4.setDomainAxisLocation(var24, true);
//     var4.setWeight(0);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
//     double var34 = var33.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var35 = var33.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var36 = var33.getRowRenderingOrder();
//     java.lang.String var37 = var36.toString();
//     var4.setRowRenderingOrder(var36);
//     
//     // Checks the contract:  equals-hashcode on var18 and var33
//     assertTrue("Contract failed: equals-hashcode on var18 and var33", var18.equals(var33) ? var18.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var18
//     assertTrue("Contract failed: equals-hashcode on var33 and var18", var33.equals(var18) ? var33.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var35
//     assertTrue("Contract failed: equals-hashcode on var6 and var35", var6.equals(var35) ? var6.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var6
//     assertTrue("Contract failed: equals-hashcode on var35 and var6", var35.equals(var6) ? var35.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    double var7 = var6.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var9 = var6.getRowRenderingOrder();
    java.awt.Stroke var10 = var6.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var6.getRendererForDataset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var6);
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    double var22 = var21.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    int var25 = var21.getIndexOf(var24);
    java.util.List var26 = var21.getCategories();
    org.jfree.chart.axis.AxisLocation var27 = var21.getDomainAxisLocation();
    boolean var28 = var21.isRangeGridlinesVisible();
    org.jfree.data.category.CategoryDataset var29 = null;
    org.jfree.chart.axis.CategoryAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
    double var34 = var33.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var35 = var33.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var36 = null;
    java.util.List var37 = var33.getCategoriesForAxis(var36);
    double var38 = var33.getAnchorValue();
    java.awt.Color var41 = java.awt.Color.getColor("", 1);
    var33.setOutlinePaint((java.awt.Paint)var41);
    var21.setBackgroundPaint((java.awt.Paint)var41);
    java.awt.Color var44 = java.awt.Color.getColor("hi!", var41);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-8323073), (java.awt.Paint)var44, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getPlotArea();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     var19.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("hi!");
//     var31.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var37 = var31.getBounds();
//     org.jfree.chart.util.RectangleAnchor var38 = null;
//     java.awt.geom.Point2D var39 = org.jfree.chart.util.RectangleAnchor.coordinates(var37, var38);
//     var19.zoomDomainAxes(100.0d, 10.0d, var29, var39);
//     var4.zoomDomainAxes(1.0d, var13, var39);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var29
//     assertTrue("Contract failed: equals-hashcode on var13 and var29", var13.equals(var29) ? var13.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var13
//     assertTrue("Contract failed: equals-hashcode on var29 and var13", var29.equals(var13) ? var29.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 0.5f, 0.0f);
    float[] var6 = new float[] { (-1.0f), 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getRGBColorComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.awt.GradientPaint var1 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var8 = new org.jfree.chart.entity.TickLabelEntity(var5, "hi!", "hi!");
//     org.jfree.data.Range var9 = null;
//     org.jfree.data.Range var10 = null;
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var9, var10);
//     boolean var12 = var8.equals((java.lang.Object)var9);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var8.setArea(var15);
//     org.jfree.chart.entity.CategoryLabelEntity var19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)1, var15, "SortOrder.ASCENDING", "SortOrder.ASCENDING");
//     java.awt.GradientPaint var20 = var0.transform(var1, var15);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     java.awt.Paint var2 = var0.getBasePaint();
//     java.awt.Stroke var4 = var0.getSeriesStroke(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
//     var0.setLegendItemToolTipGenerator(var5);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var9 = var8.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = var8.getLegendItemToolTipGenerator();
//     java.awt.Shape var12 = var8.lookupSeriesShape(0);
//     var8.setAutoPopulateSeriesFillPaint(true);
//     var8.setAutoPopulateSeriesStroke(true);
//     java.awt.Paint var19 = var8.getItemFillPaint(100, 100);
//     var0.setSeriesFillPaint(10, var19, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    java.awt.Paint var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var10, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var3 = var2.getLabelTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.chart.block.RectangleConstraint var3 = new org.jfree.chart.block.RectangleConstraint(var1, var2);
    org.jfree.chart.block.LengthConstraintType var4 = var3.getHeightConstraintType();
    org.jfree.data.Range var5 = var3.getWidthRange();
    org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var9 = var3.toRangeWidth(var8);
    boolean var12 = var8.intersects(100.0d, 0.0d);
    org.jfree.chart.block.LengthConstraintType var13 = null;
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var17 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, var17);
    org.jfree.chart.block.LengthConstraintType var19 = var18.getHeightConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(10.0d, var8, var13, 0.05d, var15, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     org.jfree.chart.util.RectangleInsets var12 = var4.getInsets();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     var19.clearDomainMarkers();
//     java.awt.Paint var26 = var19.getRangeGridlinePaint();
//     var13.setSeriesOutlinePaint(1, var26, false);
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(var12, var26);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var4 = var3.getColorSpace();
//     java.awt.image.ColorModel var5 = null;
//     java.awt.Rectangle var6 = null;
//     org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("hi!");
//     var8.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var14 = var8.getBounds();
//     java.awt.geom.AffineTransform var15 = null;
//     java.awt.RenderingHints var16 = null;
//     java.awt.PaintContext var17 = var3.createContext(var5, var6, var14, var15, var16);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
//     double var23 = var22.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     java.util.List var26 = var22.getCategoriesForAxis(var25);
//     double var27 = var22.getAnchorValue();
//     java.awt.Color var30 = java.awt.Color.getColor("", 1);
//     var22.setOutlinePaint((java.awt.Paint)var30);
//     org.jfree.chart.title.LegendGraphic var32 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var14, (java.awt.Paint)var30);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var34 = var33.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var33.getLegendItemToolTipGenerator();
//     java.awt.Shape var37 = var33.lookupSeriesShape(0);
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var38, var39, var40, var41);
//     double var43 = var42.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var44 = var42.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     java.util.List var46 = var42.getCategoriesForAxis(var45);
//     double var47 = var42.getAnchorValue();
//     var42.clearDomainAxes();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var42);
//     org.jfree.chart.title.LegendTitle var51 = var49.getLegend(10);
//     java.awt.Stroke var52 = var49.getBorderStroke();
//     var33.setBaseStroke(var52);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     double var59 = var58.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var60 = var58.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var61 = null;
//     java.util.List var62 = var58.getCategoriesForAxis(var61);
//     double var63 = var58.getAnchorValue();
//     var58.clearDomainMarkers();
//     java.awt.Paint var65 = var58.getRangeGridlinePaint();
//     org.jfree.data.category.CategoryDataset var66 = null;
//     org.jfree.chart.axis.CategoryAxis var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot(var66, var67, var68, var69);
//     double var71 = var70.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var72 = var70.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var73 = null;
//     java.util.List var74 = var70.getCategoriesForAxis(var73);
//     double var75 = var70.getAnchorValue();
//     java.awt.Color var78 = java.awt.Color.getColor("", 1);
//     var70.setOutlinePaint((java.awt.Paint)var78);
//     java.awt.Stroke var80 = var70.getDomainGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var30, var52, var65, var80, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var22 and var70
//     assertTrue("Contract failed: equals-hashcode on var22 and var70", var22.equals(var70) ? var22.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var58
//     assertTrue("Contract failed: equals-hashcode on var42 and var58", var42.equals(var58) ? var42.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var42
//     assertTrue("Contract failed: equals-hashcode on var58 and var42", var58.equals(var42) ? var58.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var22
//     assertTrue("Contract failed: equals-hashcode on var70 and var22", var70.equals(var22) ? var70.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var44
//     assertTrue("Contract failed: equals-hashcode on var24 and var44", var24.equals(var44) ? var24.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var60
//     assertTrue("Contract failed: equals-hashcode on var24 and var60", var24.equals(var60) ? var24.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var72
//     assertTrue("Contract failed: equals-hashcode on var24 and var72", var24.equals(var72) ? var24.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var24
//     assertTrue("Contract failed: equals-hashcode on var44 and var24", var44.equals(var24) ? var44.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var60
//     assertTrue("Contract failed: equals-hashcode on var44 and var60", var44.equals(var60) ? var44.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var72
//     assertTrue("Contract failed: equals-hashcode on var44 and var72", var44.equals(var72) ? var44.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var24
//     assertTrue("Contract failed: equals-hashcode on var60 and var24", var60.equals(var24) ? var60.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var44
//     assertTrue("Contract failed: equals-hashcode on var60 and var44", var60.equals(var44) ? var60.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var72
//     assertTrue("Contract failed: equals-hashcode on var60 and var72", var60.equals(var72) ? var60.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var24
//     assertTrue("Contract failed: equals-hashcode on var72 and var24", var72.equals(var24) ? var72.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var44
//     assertTrue("Contract failed: equals-hashcode on var72 and var44", var72.equals(var44) ? var72.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var60
//     assertTrue("Contract failed: equals-hashcode on var72 and var60", var72.equals(var60) ? var72.hashCode() == var60.hashCode() : true);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
    java.awt.Stroke var9 = var5.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var5.getRendererForDataset(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var5);
    java.util.List var13 = var12.getSubtitles();
    java.util.Collection var14 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Set var2 = var0.keySet();
    java.util.Enumeration var3 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var0.getString("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var4.rendererChanged(var9);
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     int var12 = var4.getDomainAxisIndex(var11);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     double var18 = var17.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var20 = null;
//     var17.setFixedLegendItems(var20);
//     boolean var22 = var17.isSubplot();
//     var17.configureDomainAxes();
//     org.jfree.chart.event.PlotChangeEvent var24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var17);
//     var4.notifyListeners(var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.RenderingHints var12 = var11.getRenderingHints();
//     java.awt.Stroke var13 = var11.getBorderStroke();
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     var11.handleClick(0, 10, var16);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("VerticalAlignment.CENTER", var1);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.RectangleEdge var6 = var4.getDomainAxisEdge((-1));
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("hi!");
//     var11.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var17 = var11.getBounds();
//     org.jfree.chart.util.RectangleAnchor var18 = null;
//     java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var7.getCategoryStart((-16777216), (-16777216), var17, var20);
//     var7.setMaximumCategoryLabelLines(10);
//     float var24 = var7.getMaximumCategoryLabelWidthRatio();
//     java.util.List var25 = var4.getCategoriesForAxis(var7);
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     double var33 = var32.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var34 = var32.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     java.util.List var36 = var32.getCategoriesForAxis(var35);
//     double var37 = var32.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var32);
//     java.awt.Paint var39 = var38.getBackgroundPaint();
//     java.awt.Font var40 = var38.getItemFont();
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("hi!", var40);
//     var7.setTickLabelFont((java.lang.Comparable)(short)1, var40);
//     
//     // Checks the contract:  equals-hashcode on var4 and var32
//     assertTrue("Contract failed: equals-hashcode on var4 and var32", var4.equals(var32) ? var4.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var4
//     assertTrue("Contract failed: equals-hashcode on var32 and var4", var32.equals(var4) ? var32.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("1", var1);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var5 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setPositiveItemLabelPositionFallback(var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var0.setSeriesToolTipGenerator(0, var8, false);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.urls.CategoryURLGenerator var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-8323073), var13, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.lang.String var10 = var5.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "hi!"+ "'", var10.equals("hi!"));

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    java.util.List var9 = var5.getCategoriesForAxis(var8);
    double var10 = var5.getAnchorValue();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    java.awt.Paint var12 = var11.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var13 = var11.getMargin();
    java.awt.Color var16 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var17 = var16.getColorSpace();
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("hi!");
    var21.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var27 = var21.getBounds();
    java.awt.geom.AffineTransform var28 = null;
    java.awt.RenderingHints var29 = null;
    java.awt.PaintContext var30 = var16.createContext(var18, var19, var27, var28, var29);
    var11.setItemPaint((java.awt.Paint)var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder(var0, (java.awt.Paint)var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     var11.setBackgroundImageAlignment(0);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     org.jfree.chart.util.RectangleAnchor var25 = var24.getLegendItemGraphicLocation();
//     java.lang.String var26 = var24.getID();
//     org.jfree.chart.util.RectangleInsets var27 = var24.getItemLabelPadding();
//     var11.addLegend(var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.image.BufferedImage var15 = var11.createBufferedImage(1, 255);
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     double var21 = var20.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var22 = var20.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     java.util.List var24 = var20.getCategoriesForAxis(var23);
//     double var25 = var20.getAnchorValue();
//     var20.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("");
//     double var29 = var28.getHeight();
//     java.awt.Paint var30 = var28.getPaint();
//     var20.setRangeCrosshairPaint(var30);
//     int var32 = var20.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
//     var11.removeSubtitle((org.jfree.chart.title.Title)var33);
//     
//     // Checks the contract:  equals-hashcode on var6 and var22
//     assertTrue("Contract failed: equals-hashcode on var6 and var22", var6.equals(var22) ? var6.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var6
//     assertTrue("Contract failed: equals-hashcode on var22 and var6", var22.equals(var6) ? var22.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.Color var18 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var19 = var18.getColorSpace();
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
//     var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var29 = var23.getBounds();
//     java.awt.geom.AffineTransform var30 = null;
//     java.awt.RenderingHints var31 = null;
//     java.awt.PaintContext var32 = var18.createContext(var20, var21, var29, var30, var31);
//     var14.draw(var15, var29);
//     org.jfree.chart.block.BlockFrame var34 = var14.getFrame();
//     java.lang.String var35 = var14.getText();
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
//     double var42 = var41.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var43 = var41.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var44 = null;
//     java.util.List var45 = var41.getCategoriesForAxis(var44);
//     double var46 = var41.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
//     java.awt.Paint var48 = var47.getBackgroundPaint();
//     java.awt.Font var49 = var47.getItemFont();
//     org.jfree.chart.block.LabelBlock var51 = new org.jfree.chart.block.LabelBlock("hi!");
//     var51.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var57 = var51.getBounds();
//     java.awt.Paint var58 = var51.getPaint();
//     org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var49, var58);
//     var14.setBackgroundPaint(var58);
//     
//     // Checks the contract:  equals-hashcode on var5 and var41
//     assertTrue("Contract failed: equals-hashcode on var5 and var41", var5.equals(var41) ? var5.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var5
//     assertTrue("Contract failed: equals-hashcode on var41 and var5", var41.equals(var5) ? var41.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var43
//     assertTrue("Contract failed: equals-hashcode on var7 and var43", var7.equals(var43) ? var7.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var7
//     assertTrue("Contract failed: equals-hashcode on var43 and var7", var43.equals(var7) ? var43.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var51
//     assertTrue("Contract failed: equals-hashcode on var23 and var51", var23.equals(var51) ? var23.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var23
//     assertTrue("Contract failed: equals-hashcode on var51 and var23", var51.equals(var23) ? var51.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setNegativeArrowVisible(false);
    var0.setInverted(true);
    org.jfree.data.Range var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var5, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var3 = var2.getColorSpace();
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("hi!");
//     var7.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var13 = var7.getBounds();
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var2.createContext(var4, var5, var13, var14, var15);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     java.util.List var25 = var21.getCategoriesForAxis(var24);
//     double var26 = var21.getAnchorValue();
//     java.awt.Color var29 = java.awt.Color.getColor("", 1);
//     var21.setOutlinePaint((java.awt.Paint)var29);
//     org.jfree.chart.title.LegendGraphic var31 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var13, (java.awt.Paint)var29);
//     java.awt.Color var34 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var35 = var34.getColorSpace();
//     java.awt.image.ColorModel var36 = null;
//     java.awt.Rectangle var37 = null;
//     org.jfree.chart.block.LabelBlock var39 = new org.jfree.chart.block.LabelBlock("hi!");
//     var39.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var45 = var39.getBounds();
//     java.awt.geom.AffineTransform var46 = null;
//     java.awt.RenderingHints var47 = null;
//     java.awt.PaintContext var48 = var34.createContext(var36, var37, var45, var46, var47);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
//     double var54 = var53.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var55 = var53.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     java.util.List var57 = var53.getCategoriesForAxis(var56);
//     double var58 = var53.getAnchorValue();
//     java.awt.Color var61 = java.awt.Color.getColor("", 1);
//     var53.setOutlinePaint((java.awt.Paint)var61);
//     org.jfree.chart.title.LegendGraphic var63 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var45, (java.awt.Paint)var61);
//     boolean var64 = org.jfree.chart.util.ShapeUtilities.intersects(var13, var45);
//     
//     // Checks the contract:  equals-hashcode on var7 and var39
//     assertTrue("Contract failed: equals-hashcode on var7 and var39", var7.equals(var39) ? var7.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var7
//     assertTrue("Contract failed: equals-hashcode on var39 and var7", var39.equals(var7) ? var39.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var53
//     assertTrue("Contract failed: equals-hashcode on var21 and var53", var21.equals(var53) ? var21.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var21
//     assertTrue("Contract failed: equals-hashcode on var53 and var21", var53.equals(var21) ? var53.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var55
//     assertTrue("Contract failed: equals-hashcode on var23 and var55", var23.equals(var55) ? var23.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var23
//     assertTrue("Contract failed: equals-hashcode on var55 and var23", var55.equals(var23) ? var55.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var4.zoomRangeAxes((-1.0d), 1.0d, var16, var17);
//     org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("hi!");
//     var20.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var26 = var20.getBounds();
//     java.awt.Paint var27 = var20.getPaint();
//     var4.setRangeGridlinePaint(var27);
//     org.jfree.chart.ChartRenderingInfo var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
//     int var32 = var31.getSubplotCount();
//     org.jfree.chart.renderer.RendererState var33 = new org.jfree.chart.renderer.RendererState(var31);
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("hi!");
//     var35.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var41 = var35.getBounds();
//     org.jfree.chart.util.RectangleAnchor var42 = null;
//     java.awt.geom.Point2D var43 = org.jfree.chart.util.RectangleAnchor.coordinates(var41, var42);
//     var4.zoomDomainAxes((-1.0d), var31, var43);
//     
//     // Checks the contract:  equals-hashcode on var20 and var35
//     assertTrue("Contract failed: equals-hashcode on var20 and var35", var20.equals(var35) ? var20.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var20
//     assertTrue("Contract failed: equals-hashcode on var35 and var20", var35.equals(var20) ? var35.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, (-16777216), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    java.awt.Font var12 = var10.getItemFont();
    org.jfree.chart.util.VerticalAlignment var13 = var10.getVerticalAlignment();
    org.jfree.chart.event.TitleChangeListener var14 = null;
    var10.addChangeListener(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = null;
    var0.setLegendItemToolTipGenerator(var7);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
//     boolean var9 = var5.equals((java.lang.Object)var6);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var5.setArea(var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     var18.setOutlinePaint((java.awt.Paint)var26);
//     java.awt.Stroke var28 = var18.getDomainGridlineStroke();
//     java.awt.Color var31 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var32 = var31.getColorSpace();
//     java.awt.image.ColorModel var33 = null;
//     java.awt.Rectangle var34 = null;
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
//     var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var42 = var36.getBounds();
//     java.awt.geom.AffineTransform var43 = null;
//     java.awt.RenderingHints var44 = null;
//     java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
//     var18.setNoDataMessagePaint((java.awt.Paint)var31);
//     org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
//     java.awt.Shape var48 = var47.getShape();
//     var47.setShapeOutlineVisible(true);
//     org.jfree.chart.util.GradientPaintTransformer var51 = var47.getFillPaintTransformer();
//     boolean var52 = var47.isShapeVisible();
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     double var59 = var58.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var60 = var58.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     int var62 = var58.getIndexOf(var61);
//     java.util.List var63 = var58.getCategories();
//     org.jfree.chart.axis.AxisLocation var64 = var58.getDomainAxisLocation();
//     boolean var65 = var58.isRangeGridlinesVisible();
//     org.jfree.data.category.CategoryDataset var66 = null;
//     org.jfree.chart.axis.CategoryAxis var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot(var66, var67, var68, var69);
//     double var71 = var70.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var72 = var70.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var73 = null;
//     java.util.List var74 = var70.getCategoriesForAxis(var73);
//     double var75 = var70.getAnchorValue();
//     java.awt.Color var78 = java.awt.Color.getColor("", 1);
//     var70.setOutlinePaint((java.awt.Paint)var78);
//     var58.setBackgroundPaint((java.awt.Paint)var78);
//     java.awt.Color var81 = java.awt.Color.getColor("hi!", var78);
//     var47.setFillPaint((java.awt.Paint)var78);
//     
//     // Checks the contract:  equals-hashcode on var20 and var72
//     assertTrue("Contract failed: equals-hashcode on var20 and var72", var20.equals(var72) ? var20.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var20
//     assertTrue("Contract failed: equals-hashcode on var72 and var20", var72.equals(var20) ? var72.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var2);
    java.lang.String var7 = var6.getURLText();
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var8 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var9 = null;
    java.lang.String var10 = var6.getImageMapAreaTag(var8, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.05d, 0.0d, 0, (java.lang.Comparable)(-253));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-165));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    int var2 = var1.getSubplotCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var4 = var1.getSubplotInfo(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.util.LengthAdjustmentType var3 = var1.getLabelOffsetType();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.lang.Object var6 = var5.clone();
//     org.jfree.chart.util.LengthAdjustmentType var7 = var5.getLabelOffsetType();
//     var1.setLabelOffsetType(var7);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var6
//     assertTrue("Contract failed: equals-hashcode on var2 and var6", var2.equals(var6) ? var2.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var2
//     assertTrue("Contract failed: equals-hashcode on var6 and var2", var6.equals(var2) ? var6.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-8323073), 100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var1 = var0.getColumnCount();
//     org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
//     java.lang.Number var6 = var0.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.KeyToGroupMap var7 = null;
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var7);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.util.RectangleEdge var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = var1.getLabelPosition(var2);
    org.jfree.chart.axis.CategoryLabelPosition var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("PlotOrientation.VERTICAL", var1, var2);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.RenderingHints var12 = var11.getRenderingHints();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("hi!");
//     var15.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var21 = var15.getBounds();
//     org.jfree.chart.util.RectangleAnchor var22 = null;
//     java.awt.geom.Point2D var23 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var22);
//     var11.draw(var13, var21);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setNegativeArrowVisible(false);
    var0.setInverted(true);
    org.jfree.data.RangeType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 100.0d);
//     org.jfree.data.Range var4 = org.jfree.data.Range.shift(var0, 4.0d);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("hi!");
//     var16.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var22 = var16.getBounds();
//     org.jfree.chart.util.RectangleAnchor var23 = null;
//     java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
//     var4.zoomDomainAxes(100.0d, 10.0d, var14, var24);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var33 = var30.getRowRenderingOrder();
//     java.lang.String var34 = var33.toString();
//     var4.setColumnRenderingOrder(var33);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
    boolean var9 = var5.equals((java.lang.Object)var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var5.setArea(var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    java.awt.Color var26 = java.awt.Color.getColor("", 1);
    var18.setOutlinePaint((java.awt.Paint)var26);
    java.awt.Stroke var28 = var18.getDomainGridlineStroke();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
    var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var42 = var36.getBounds();
    java.awt.geom.AffineTransform var43 = null;
    java.awt.RenderingHints var44 = null;
    java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
    var18.setNoDataMessagePaint((java.awt.Paint)var31);
    org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
    org.jfree.chart.util.RectangleAnchor var48 = var47.getShapeAnchor();
    org.jfree.chart.text.TextBlockAnchor var49 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var52 = new org.jfree.chart.axis.CategoryLabelPosition(var48, var49, var50, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.setAutoTickUnitSelection(false);
    var0.setLabelAngle(10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(0.05d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
//     double var9 = var8.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
//     java.awt.Stroke var12 = var8.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var8.getRendererForDataset(var13);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var8);
//     java.util.List var16 = var15.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     java.awt.image.BufferedImage var22 = var15.createBufferedImage(1, 10, (-1.0d), 1.0d, var21);
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "", (java.awt.Image)var22, "org.jfree.chart.event.ChartChangeEvent[source=0]", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "10");
//     var26.setName("");
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
//     double var34 = var33.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var35 = var33.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     java.util.List var37 = var33.getCategoriesForAxis(var36);
//     double var38 = var33.getAnchorValue();
//     var33.clearDomainAxes();
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
//     java.awt.Paint var41 = var40.getBackgroundPaint();
//     java.awt.image.BufferedImage var44 = var40.createBufferedImage(1, 255);
//     var26.setLogo((java.awt.Image)var44);
//     
//     // Checks the contract:  equals-hashcode on var8 and var33
//     assertTrue("Contract failed: equals-hashcode on var8 and var33", var8.equals(var33) ? var8.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var8
//     assertTrue("Contract failed: equals-hashcode on var33 and var8", var33.equals(var8) ? var33.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var35
//     assertTrue("Contract failed: equals-hashcode on var10 and var35", var10.equals(var35) ? var10.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var10
//     assertTrue("Contract failed: equals-hashcode on var35 and var10", var35.equals(var10) ? var35.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     double var12 = var11.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var13 = var11.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     java.util.List var15 = var11.getCategoriesForAxis(var14);
//     double var16 = var11.getAnchorValue();
//     java.awt.Color var19 = java.awt.Color.getColor("", 1);
//     var11.setOutlinePaint((java.awt.Paint)var19);
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
//     double var26 = var25.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var27 = var25.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     int var29 = var25.getIndexOf(var28);
//     java.util.List var30 = var25.getCategories();
//     org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation();
//     var11.setDomainAxisLocation(var31, true);
//     var4.setDomainAxisLocation(var31);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var13
//     assertTrue("Contract failed: equals-hashcode on var6 and var13", var6.equals(var13) ? var6.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var6
//     assertTrue("Contract failed: equals-hashcode on var13 and var6", var13.equals(var6) ? var13.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(byte)0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.title.LegendTitle var13 = var11.getLegend(10);
    org.jfree.chart.ChartRenderingInfo var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var19 = var11.createBufferedImage(10, 0, 100.0d, 100.0d, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
//     double var13 = var12.getHeight();
//     java.awt.Paint var14 = var12.getPaint();
//     var4.setRangeCrosshairPaint(var14);
//     int var16 = var4.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.data.Range var19 = null;
//     org.jfree.data.Range var20 = null;
//     org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, var20);
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var25 = var21.toRangeHeight(var24);
//     org.jfree.chart.block.LengthConstraintType var26 = var21.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var27 = var17.arrange(var18, var21);
//     org.jfree.chart.LegendItemSource[] var28 = var17.getSources();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
//     double var34 = var33.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var35 = var33.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     java.util.List var37 = var33.getCategoriesForAxis(var36);
//     double var38 = var33.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
//     org.jfree.chart.util.HorizontalAlignment var40 = var39.getHorizontalAlignment();
//     var17.setHorizontalAlignment(var40);
//     
//     // Checks the contract:  equals-hashcode on var6 and var35
//     assertTrue("Contract failed: equals-hashcode on var6 and var35", var6.equals(var35) ? var6.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var6
//     assertTrue("Contract failed: equals-hashcode on var35 and var6", var35.equals(var6) ? var35.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var2 = var1.getID();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     double var8 = var7.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     java.util.List var11 = var7.getCategoriesForAxis(var10);
//     var7.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("hi!");
//     var19.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var25 = var19.getBounds();
//     org.jfree.chart.util.RectangleAnchor var26 = null;
//     java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var26);
//     var7.zoomDomainAxes(100.0d, 10.0d, var17, var27);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var17);
//     boolean var30 = var1.equals((java.lang.Object)var17);
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
//     double var37 = var36.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var38 = var36.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     java.util.List var40 = var36.getCategoriesForAxis(var39);
//     double var41 = var36.getAnchorValue();
//     java.awt.Color var44 = java.awt.Color.getColor("", 1);
//     var36.setOutlinePaint((java.awt.Paint)var44);
//     java.awt.Stroke var46 = var36.getDomainGridlineStroke();
//     java.awt.Color var49 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var50 = var49.getColorSpace();
//     java.awt.image.ColorModel var51 = null;
//     java.awt.Rectangle var52 = null;
//     org.jfree.chart.block.LabelBlock var54 = new org.jfree.chart.block.LabelBlock("hi!");
//     var54.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var60 = var54.getBounds();
//     java.awt.geom.AffineTransform var61 = null;
//     java.awt.RenderingHints var62 = null;
//     java.awt.PaintContext var63 = var49.createContext(var51, var52, var60, var61, var62);
//     var36.setNoDataMessagePaint((java.awt.Paint)var49);
//     java.awt.Color var65 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=0]", var49);
//     var1.setPaint((java.awt.Paint)var65);
//     
//     // Checks the contract:  equals-hashcode on var19 and var54
//     assertTrue("Contract failed: equals-hashcode on var19 and var54", var19.equals(var54) ? var19.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var19
//     assertTrue("Contract failed: equals-hashcode on var54 and var19", var54.equals(var19) ? var54.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var38
//     assertTrue("Contract failed: equals-hashcode on var9 and var38", var9.equals(var38) ? var9.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var9
//     assertTrue("Contract failed: equals-hashcode on var38 and var9", var38.equals(var9) ? var38.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("hi!");
//     var3.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var9 = var3.getBounds();
//     org.jfree.chart.util.RectangleAnchor var10 = null;
//     java.awt.geom.Point2D var11 = org.jfree.chart.util.RectangleAnchor.coordinates(var9, var10);
//     var0.draw(var1, var9);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     var18.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("hi!");
//     var30.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var36 = var30.getBounds();
//     org.jfree.chart.util.RectangleAnchor var37 = null;
//     java.awt.geom.Point2D var38 = org.jfree.chart.util.RectangleAnchor.coordinates(var36, var37);
//     var18.zoomDomainAxes(100.0d, 10.0d, var28, var38);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var41 = var40.getInsets();
//     org.jfree.chart.util.UnitType var42 = var41.getUnitType();
//     java.awt.Color var45 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var46 = var45.getColorSpace();
//     java.awt.image.ColorModel var47 = null;
//     java.awt.Rectangle var48 = null;
//     org.jfree.chart.block.LabelBlock var50 = new org.jfree.chart.block.LabelBlock("hi!");
//     var50.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var56 = var50.getBounds();
//     java.awt.geom.AffineTransform var57 = null;
//     java.awt.RenderingHints var58 = null;
//     java.awt.PaintContext var59 = var45.createContext(var47, var48, var56, var57, var58);
//     var41.trim(var56);
//     var28.setDataArea(var56);
//     var0.draw(var13, var56);
//     
//     // Checks the contract:  equals-hashcode on var3 and var30
//     assertTrue("Contract failed: equals-hashcode on var3 and var30", var3.equals(var30) ? var3.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var3
//     assertTrue("Contract failed: equals-hashcode on var30 and var3", var30.equals(var3) ? var30.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     java.awt.Stroke var8 = var4.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var4.getRendererForDataset(var9);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     java.util.List var19 = var15.getCategoriesForAxis(var18);
//     double var20 = var15.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var21 = var15.getOrientation();
//     var4.setOrientation(var21);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var5);
    org.jfree.data.Range var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var8 = var6.toRangeWidth(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var4.setFixedRangeAxisSpace(var10);
//     org.jfree.chart.event.AxisChangeEvent var12 = null;
//     var4.axisChanged(var12);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
//     double var23 = var22.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var25 = var22.getRowRenderingOrder();
//     java.awt.Stroke var26 = var22.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = var22.getRendererForDataset(var27);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var22);
//     java.util.List var30 = var29.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     java.awt.image.BufferedImage var36 = var29.createBufferedImage(1, 10, (-1.0d), 1.0d, var35);
//     org.jfree.chart.ui.ProjectInfo var40 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "", (java.awt.Image)var36, "org.jfree.chart.event.ChartChangeEvent[source=0]", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "10");
//     var4.setBackgroundImage((java.awt.Image)var36);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedWidth();
    double var5 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     java.lang.Number var0 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var3 = var2.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = var2.getLegendItemToolTipGenerator();
//     java.awt.Shape var6 = var2.lookupSeriesShape(0);
//     org.jfree.chart.labels.ItemLabelPosition var7 = new org.jfree.chart.labels.ItemLabelPosition();
//     var2.setPositiveItemLabelPositionFallback(var7);
//     org.jfree.chart.text.TextAnchor var9 = var7.getTextAnchor();
//     org.jfree.chart.text.TextAnchor var10 = null;
//     org.jfree.chart.axis.NumberTick var12 = new org.jfree.chart.axis.NumberTick(var0, "", var9, var10, 2.0d);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.title.LegendTitle var13 = var11.getLegend(10);
    java.awt.Stroke var14 = var11.getBorderStroke();
    org.jfree.chart.title.LegendTitle var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addLegend(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     java.awt.Shape var4 = var0.lookupSeriesShape(0);
//     org.jfree.chart.labels.ItemLabelPosition var5 = new org.jfree.chart.labels.ItemLabelPosition();
//     var0.setPositiveItemLabelPositionFallback(var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(0, var8, false);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     java.util.List var19 = var15.getCategoriesForAxis(var18);
//     double var20 = var15.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     java.awt.Paint var22 = var21.getBackgroundPaint();
//     java.awt.Font var23 = var21.getItemFont();
//     var0.setBaseItemLabelFont(var23, false);
//     org.jfree.chart.labels.ItemLabelPosition var26 = var0.getPositiveItemLabelPositionFallback();
//     java.awt.Graphics2D var27 = null;
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     double var33 = var32.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var34 = var32.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     java.util.List var36 = var32.getCategoriesForAxis(var35);
//     double var37 = var32.getAnchorValue();
//     java.awt.Color var40 = java.awt.Color.getColor("", 1);
//     var32.setOutlinePaint((java.awt.Paint)var40);
//     float var42 = var32.getForegroundAlpha();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     var32.setRenderer(var43, false);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     double var47 = var46.getLowerMargin();
//     org.jfree.data.Range var48 = var32.getDataRange((org.jfree.chart.axis.ValueAxis)var46);
//     org.jfree.chart.util.RectangleInsets var49 = var32.getInsets();
//     org.jfree.chart.block.LabelBlock var51 = new org.jfree.chart.block.LabelBlock("hi!");
//     var51.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var57 = var51.getBounds();
//     var0.drawOutline(var27, var32, var57);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var7 = null;
//     var4.setFixedLegendItems(var7);
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
//     double var14 = var13.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var15 = var13.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var16 = null;
//     var13.setFixedLegendItems(var16);
//     boolean var18 = var4.equals((java.lang.Object)var13);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("hi!");
//     var9.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var15 = var9.getBounds();
//     org.jfree.chart.util.RectangleAnchor var16 = null;
//     java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var5.getCategoryStart((-16777216), (-16777216), var15, var18);
//     org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)100, (java.awt.Shape)var15, "hi!", "[size=1]");
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.Object var24 = var23.clone();
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("hi!");
//     var31.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var37 = var31.getBounds();
//     org.jfree.chart.util.RectangleAnchor var38 = null;
//     java.awt.geom.Point2D var39 = org.jfree.chart.util.RectangleAnchor.coordinates(var37, var38);
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var27.getCategoryStart((-16777216), (-16777216), var37, var40);
//     org.jfree.chart.axis.AxisSpace var42 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
//     double var50 = var49.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var51 = var49.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     java.util.List var53 = var49.getCategoriesForAxis(var52);
//     double var54 = var49.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49);
//     java.awt.Paint var56 = var55.getBackgroundPaint();
//     java.awt.Font var57 = var55.getItemFont();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle("hi!", var57);
//     org.jfree.chart.util.RectangleEdge var59 = var58.getPosition();
//     var42.add(100.0d, var59);
//     double var61 = var23.getCategoryMiddle(0, 100, var37, var59);
//     double var62 = var0.getCategoryMiddle(100, 100, var15, var59);
//     
//     // Checks the contract:  equals-hashcode on var9 and var31
//     assertTrue("Contract failed: equals-hashcode on var9 and var31", var9.equals(var31) ? var9.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var9
//     assertTrue("Contract failed: equals-hashcode on var31 and var9", var31.equals(var9) ? var31.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = null;
    var0.setLegendItemToolTipGenerator(var7);
    org.jfree.chart.labels.ItemLabelPosition var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseNegativeItemLabelPosition(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.zoomRange(0.0d, 0.0d);
    org.jfree.data.RangeType var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    double var8 = var7.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    java.util.List var11 = var7.getCategoriesForAxis(var10);
    double var12 = var7.getAnchorValue();
    var7.clearDomainMarkers();
    java.awt.Paint var14 = var7.getRangeGridlinePaint();
    var1.setSeriesOutlinePaint(1, var14, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var0, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     var4.mapDatasetToDomainAxis(0, 0);
//     java.awt.Font var14 = var4.getNoDataMessageFont();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     var19.clearDomainMarkers();
//     var19.mapDatasetToRangeAxis(1, (-253));
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     double var30 = var29.getLowerMargin();
//     org.jfree.chart.axis.NumberTickUnit var31 = var29.getTickUnit();
//     org.jfree.data.Range var32 = var19.getDataRange((org.jfree.chart.axis.ValueAxis)var29);
//     boolean var33 = var29.isAutoRange();
//     org.jfree.chart.axis.NumberTickUnit var35 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     org.jfree.chart.block.LabelBlock var37 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var38 = var37.getID();
//     int var39 = var35.compareTo((java.lang.Object)var37);
//     java.lang.String var41 = var35.valueToString(1.0d);
//     var29.setTickUnit(var35, false, false);
//     org.jfree.data.Range var45 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var29);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var19.", var4.equals(var19) == var19.equals(var4));
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var14.draw(var15, var16);
//     boolean var18 = var14.getExpandToFitSpace();
//     org.jfree.data.category.CategoryDataset var19 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var19, var20, var21, var22);
//     double var24 = var23.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var25 = var23.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     java.util.List var27 = var23.getCategoriesForAxis(var26);
//     double var28 = var23.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
//     org.jfree.chart.util.HorizontalAlignment var30 = var29.getHorizontalAlignment();
//     org.jfree.chart.axis.AxisCollection var31 = new org.jfree.chart.axis.AxisCollection();
//     java.util.List var32 = var31.getAxesAtRight();
//     boolean var33 = var30.equals((java.lang.Object)var31);
//     var14.setHorizontalAlignment(var30);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var25
//     assertTrue("Contract failed: equals-hashcode on var7 and var25", var7.equals(var25) ? var7.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var7
//     assertTrue("Contract failed: equals-hashcode on var25 and var7", var25.equals(var7) ? var25.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("hi!", var5);
    boolean var7 = var6.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     java.awt.Font var14 = var12.getItemFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("hi!", var14);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     int var25 = var21.getIndexOf(var24);
//     java.util.List var26 = var21.getCategories();
//     org.jfree.chart.axis.AxisLocation var27 = var21.getDomainAxisLocation();
//     boolean var28 = var21.isRangeGridlinesVisible();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
//     double var34 = var33.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var35 = var33.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     java.util.List var37 = var33.getCategoriesForAxis(var36);
//     double var38 = var33.getAnchorValue();
//     java.awt.Color var41 = java.awt.Color.getColor("", 1);
//     var33.setOutlinePaint((java.awt.Paint)var41);
//     var21.setBackgroundPaint((java.awt.Paint)var41);
//     java.awt.Color var44 = java.awt.Color.getColor("hi!", var41);
//     org.jfree.chart.text.TextLine var45 = new org.jfree.chart.text.TextLine("RectangleEdge.TOP", var14, (java.awt.Paint)var44);
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
//     java.awt.Stroke var9 = var5.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var5.getRendererForDataset(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var5);
//     java.util.List var13 = var12.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     java.awt.image.BufferedImage var19 = var12.createBufferedImage(1, 10, (-1.0d), 1.0d, var18);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     var12.draw(var20, var21, var22);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 100.0d, 4.0d, 1, (java.lang.Comparable)(-165));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     java.awt.Stroke var14 = var4.getDomainGridlineStroke();
//     java.awt.Color var17 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var18 = var17.getColorSpace();
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
//     var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var28 = var22.getBounds();
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
//     var4.setNoDataMessagePaint((java.awt.Paint)var17);
//     var4.setNoDataMessage("");
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     double var40 = var39.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var41 = var39.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     java.util.List var43 = var39.getCategoriesForAxis(var42);
//     double var44 = var39.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var45 = var39.getOrientation();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var47 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var46};
//     var39.setRenderers(var47);
//     var4.setRenderers(var47);
//     
//     // Checks the contract:  equals-hashcode on var6 and var41
//     assertTrue("Contract failed: equals-hashcode on var6 and var41", var6.equals(var41) ? var6.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var6
//     assertTrue("Contract failed: equals-hashcode on var41 and var6", var41.equals(var6) ? var41.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    double var12 = var10.getWidth();
    org.jfree.chart.util.RectangleInsets var13 = var10.getLegendItemGraphicPadding();
    java.awt.Color var16 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var17 = var16.getColorSpace();
    java.awt.image.ColorModel var18 = null;
    java.awt.Rectangle var19 = null;
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("hi!");
    var21.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var27 = var21.getBounds();
    java.awt.geom.AffineTransform var28 = null;
    java.awt.RenderingHints var29 = null;
    java.awt.PaintContext var30 = var16.createContext(var18, var19, var27, var28, var29);
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.lang.Object var33 = var32.clone();
    org.jfree.chart.util.LengthAdjustmentType var34 = var32.getLabelOffsetType();
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var36.setAlpha(0.0f);
    org.jfree.chart.util.LengthAdjustmentType var39 = var36.getLabelOffsetType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var40 = var13.createAdjustedRectangle((java.awt.geom.Rectangle2D)var19, var34, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
//     double var13 = var12.getHeight();
//     java.awt.Paint var14 = var12.getPaint();
//     var4.setRangeCrosshairPaint(var14);
//     int var16 = var4.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
//     var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var28 = var22.getBounds();
//     org.jfree.chart.util.RectangleAnchor var29 = null;
//     java.awt.geom.Point2D var30 = org.jfree.chart.util.RectangleAnchor.coordinates(var28, var29);
//     var19.draw(var20, var28);
//     java.lang.Object var32 = null;
//     java.lang.Object var33 = var17.draw(var18, var28, var32);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
//     var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var10 = var4.getBounds();
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
//     var0.setMaximumCategoryLabelLines(10);
//     float var17 = var0.getMaximumCategoryLabelWidthRatio();
//     var0.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var21 = var20.getRowCount();
//     java.awt.Paint var22 = var20.getBasePaint();
//     java.awt.Stroke var24 = var20.getSeriesStroke(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var25 = null;
//     var20.setLegendItemToolTipGenerator(var25);
//     java.awt.Color var29 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var30 = var29.getColorSpace();
//     java.awt.image.ColorModel var31 = null;
//     java.awt.Rectangle var32 = null;
//     org.jfree.chart.block.LabelBlock var34 = new org.jfree.chart.block.LabelBlock("hi!");
//     var34.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var40 = var34.getBounds();
//     java.awt.geom.AffineTransform var41 = null;
//     java.awt.RenderingHints var42 = null;
//     java.awt.PaintContext var43 = var29.createContext(var31, var32, var40, var41, var42);
//     boolean var44 = var20.equals((java.lang.Object)var29);
//     var0.setTickMarkPaint((java.awt.Paint)var29);
//     
//     // Checks the contract:  equals-hashcode on var4 and var34
//     assertTrue("Contract failed: equals-hashcode on var4 and var34", var4.equals(var34) ? var4.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var4
//     assertTrue("Contract failed: equals-hashcode on var34 and var4", var34.equals(var4) ? var34.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var14.draw(var15, var16);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
//     double var23 = var22.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     java.util.List var26 = var22.getCategoriesForAxis(var25);
//     double var27 = var22.getAnchorValue();
//     var22.clearDomainAxes();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.title.LegendTitle var31 = var29.getLegend(10);
//     var14.addChangeListener((org.jfree.chart.event.TitleChangeListener)var29);
//     
//     // Checks the contract:  equals-hashcode on var5 and var22
//     assertTrue("Contract failed: equals-hashcode on var5 and var22", var5.equals(var22) ? var5.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var5
//     assertTrue("Contract failed: equals-hashcode on var22 and var5", var22.equals(var5) ? var22.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
//     double var9 = var8.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
//     java.awt.Stroke var12 = var8.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var8.getRendererForDataset(var13);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var8);
//     java.util.List var16 = var15.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     java.awt.image.BufferedImage var22 = var15.createBufferedImage(1, 10, (-1.0d), 1.0d, var21);
//     org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "", (java.awt.Image)var22, "org.jfree.chart.event.ChartChangeEvent[source=0]", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "10");
//     var26.setName("");
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
//     double var35 = var34.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var36 = var34.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var37 = var34.getRowRenderingOrder();
//     java.awt.Stroke var38 = var34.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = var34.getRendererForDataset(var39);
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var34);
//     java.util.List var42 = var41.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var47 = null;
//     java.awt.image.BufferedImage var48 = var41.createBufferedImage(1, 10, (-1.0d), 1.0d, var47);
//     var26.setLogo((java.awt.Image)var48);
//     
//     // Checks the contract:  equals-hashcode on var8 and var34
//     assertTrue("Contract failed: equals-hashcode on var8 and var34", var8.equals(var34) ? var8.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var8
//     assertTrue("Contract failed: equals-hashcode on var34 and var8", var34.equals(var8) ? var34.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var36
//     assertTrue("Contract failed: equals-hashcode on var10 and var36", var10.equals(var36) ? var10.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var10
//     assertTrue("Contract failed: equals-hashcode on var36 and var10", var36.equals(var10) ? var36.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var41
//     assertTrue("Contract failed: equals-hashcode on var15 and var41", var15.equals(var41) ? var15.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var15
//     assertTrue("Contract failed: equals-hashcode on var41 and var15", var41.equals(var15) ? var41.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateX(2.0d);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var3 = var2.getColorSpace();
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     double var12 = var11.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var13 = var11.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     java.util.List var15 = var11.getCategoriesForAxis(var14);
//     double var16 = var11.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
//     java.awt.Paint var18 = var17.getBackgroundPaint();
//     java.awt.Font var19 = var17.getItemFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("hi!", var19);
//     java.awt.Graphics2D var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var25 = var24.getColorSpace();
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("hi!");
//     var29.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var35 = var29.getBounds();
//     java.awt.geom.AffineTransform var36 = null;
//     java.awt.RenderingHints var37 = null;
//     java.awt.PaintContext var38 = var24.createContext(var26, var27, var35, var36, var37);
//     var20.draw(var21, var35);
//     java.awt.geom.AffineTransform var40 = null;
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     double var46 = var45.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     java.util.List var49 = var45.getCategoriesForAxis(var48);
//     double var50 = var45.getAnchorValue();
//     var45.clearDomainAxes();
//     org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var45);
//     java.awt.RenderingHints var53 = var52.getRenderingHints();
//     java.awt.PaintContext var54 = var2.createContext(var4, var5, var35, var40, var53);
//     
//     // Checks the contract:  equals-hashcode on var11 and var45
//     assertTrue("Contract failed: equals-hashcode on var11 and var45", var11.equals(var45) ? var11.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var11
//     assertTrue("Contract failed: equals-hashcode on var45 and var11", var45.equals(var11) ? var45.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var47
//     assertTrue("Contract failed: equals-hashcode on var13 and var47", var13.equals(var47) ? var13.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var13
//     assertTrue("Contract failed: equals-hashcode on var47 and var13", var47.equals(var13) ? var47.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    int var9 = var4.getDomainAxisIndex(var8);
    int var10 = var4.getWeight();
    int var11 = var4.getDatasetCount();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var4.getRendererForDataset(var12);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
    double var20 = var19.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var22 = null;
    java.util.List var23 = var19.getCategoriesForAxis(var22);
    double var24 = var19.getAnchorValue();
    java.awt.Color var27 = java.awt.Color.getColor("", 1);
    var19.setOutlinePaint((java.awt.Paint)var27);
    java.awt.Stroke var29 = var19.getDomainGridlineStroke();
    org.jfree.chart.axis.AxisLocation var31 = var19.getDomainAxisLocation(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation((-165), var31, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     double var8 = var7.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     java.util.List var11 = var7.getCategoriesForAxis(var10);
//     double var12 = var7.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     java.awt.Font var15 = var13.getItemFont();
//     org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("hi!");
//     var17.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var23 = var17.getBounds();
//     java.awt.Paint var24 = var17.getPaint();
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var15, var24);
//     org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("10", var15);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var32 = new org.jfree.chart.entity.TickLabelEntity(var29, "hi!", "hi!");
//     org.jfree.data.Range var33 = null;
//     org.jfree.data.Range var34 = null;
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(var33, var34);
//     boolean var36 = var32.equals((java.lang.Object)var33);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var32.setArea(var39);
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     double var46 = var45.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     java.util.List var49 = var45.getCategoriesForAxis(var48);
//     double var50 = var45.getAnchorValue();
//     java.awt.Color var53 = java.awt.Color.getColor("", 1);
//     var45.setOutlinePaint((java.awt.Paint)var53);
//     java.awt.Stroke var55 = var45.getDomainGridlineStroke();
//     java.awt.Color var58 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var59 = var58.getColorSpace();
//     java.awt.image.ColorModel var60 = null;
//     java.awt.Rectangle var61 = null;
//     org.jfree.chart.block.LabelBlock var63 = new org.jfree.chart.block.LabelBlock("hi!");
//     var63.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var69 = var63.getBounds();
//     java.awt.geom.AffineTransform var70 = null;
//     java.awt.RenderingHints var71 = null;
//     java.awt.PaintContext var72 = var58.createContext(var60, var61, var69, var70, var71);
//     var45.setNoDataMessagePaint((java.awt.Paint)var58);
//     org.jfree.chart.title.LegendGraphic var74 = new org.jfree.chart.title.LegendGraphic(var39, (java.awt.Paint)var58);
//     org.jfree.chart.util.RectangleAnchor var75 = var74.getShapeAnchor();
//     org.jfree.chart.util.RectangleAnchor var76 = var74.getShapeLocation();
//     java.awt.Paint var77 = var74.getFillPaint();
//     java.awt.Graphics2D var80 = null;
//     org.jfree.chart.text.G2TextMeasurer var81 = new org.jfree.chart.text.G2TextMeasurer(var80);
//     org.jfree.chart.text.TextBlock var82 = org.jfree.chart.text.TextUtilities.createTextBlock("", var15, var77, 100.0f, (-16777215), (org.jfree.chart.text.TextMeasurer)var81);
//     
//     // Checks the contract:  equals-hashcode on var9 and var47
//     assertTrue("Contract failed: equals-hashcode on var9 and var47", var9.equals(var47) ? var9.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var9
//     assertTrue("Contract failed: equals-hashcode on var47 and var9", var47.equals(var9) ? var47.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var63
//     assertTrue("Contract failed: equals-hashcode on var17 and var63", var17.equals(var63) ? var17.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var17
//     assertTrue("Contract failed: equals-hashcode on var63 and var17", var63.equals(var17) ? var63.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     double var12 = var10.getWidth();
//     org.jfree.chart.util.RectangleAnchor var13 = var10.getLegendItemGraphicAnchor();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemSource[] var15 = new org.jfree.chart.LegendItemSource[] { var14};
//     var10.setSources(var15);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.lang.String var2 = var1.getText();
//     java.awt.Paint var3 = var1.getPaint();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.text.TextAnchor var5 = null;
//     float var6 = var1.calculateBaselineOffset(var4, var5);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     java.awt.Stroke var8 = var4.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var4.getRendererForDataset(var9);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     java.util.List var19 = var15.getCategoriesForAxis(var18);
//     double var20 = var15.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     java.awt.Paint var22 = var21.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var23 = var21.getMargin();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var27 = var26.getColorSpace();
//     java.awt.image.ColorModel var28 = null;
//     java.awt.Rectangle var29 = null;
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("hi!");
//     var31.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var37 = var31.getBounds();
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var26.createContext(var28, var29, var37, var38, var39);
//     var21.setItemPaint((java.awt.Paint)var26);
//     boolean var42 = var4.equals((java.lang.Object)var21);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING", var1);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var12 = var11.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
//     java.awt.Shape var15 = var11.lookupSeriesShape(0);
//     int var16 = var4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
//     var11.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Shape var20 = var11.lookupSeriesShape(100);
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.FlowArrangement var22 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var23 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var22, var23, (java.lang.Comparable)1L);
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var22);
//     
//     // Checks the contract:  equals-hashcode on var21 and var22
//     assertTrue("Contract failed: equals-hashcode on var21 and var22", var21.equals(var22) ? var21.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var21
//     assertTrue("Contract failed: equals-hashcode on var22 and var21", var22.equals(var21) ? var22.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     double var18 = var17.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     java.util.List var21 = var17.getCategoriesForAxis(var20);
//     var17.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("hi!");
//     var29.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var35 = var29.getBounds();
//     org.jfree.chart.util.RectangleAnchor var36 = null;
//     java.awt.geom.Point2D var37 = org.jfree.chart.util.RectangleAnchor.coordinates(var35, var36);
//     var17.zoomDomainAxes(100.0d, 10.0d, var27, var37);
//     org.jfree.chart.block.BlockBorder var39 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var40 = var39.getInsets();
//     org.jfree.chart.util.UnitType var41 = var40.getUnitType();
//     java.awt.Color var44 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var45 = var44.getColorSpace();
//     java.awt.image.ColorModel var46 = null;
//     java.awt.Rectangle var47 = null;
//     org.jfree.chart.block.LabelBlock var49 = new org.jfree.chart.block.LabelBlock("hi!");
//     var49.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var55 = var49.getBounds();
//     java.awt.geom.AffineTransform var56 = null;
//     java.awt.RenderingHints var57 = null;
//     java.awt.PaintContext var58 = var44.createContext(var46, var47, var55, var56, var57);
//     var40.trim(var55);
//     var27.setDataArea(var55);
//     org.jfree.chart.entity.ChartEntity var62 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var55, "SortOrder.ASCENDING");
//     var11.draw(var12, var55);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    java.lang.Comparable var1 = null;
    org.jfree.chart.text.TextBlock var2 = null;
    org.jfree.chart.text.TextBlockAnchor var3 = null;
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var8 = new org.jfree.chart.axis.CategoryTick(var1, var2, var3, var6, (-1.0d));
    org.jfree.chart.text.TextAnchor var9 = var8.getRotationAnchor();
    org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.text.TextAnchor var12 = var11.getLabelTextAnchor();
    java.awt.Color var15 = java.awt.Color.getColor("", 1);
    boolean var16 = var12.equals((java.lang.Object)"");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition(var0, var9, var12, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.RectangleEdge var6 = var4.getDomainAxisEdge((-1));
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     double var12 = var11.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var13 = var11.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var14 = var11.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     int var16 = var11.getDomainAxisIndex(var15);
//     var11.setRangeCrosshairVisible(false);
//     boolean var19 = var6.equals((java.lang.Object)var11);
//     
//     // Checks the contract:  equals-hashcode on var4 and var11
//     assertTrue("Contract failed: equals-hashcode on var4 and var11", var4.equals(var11) ? var4.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var4
//     assertTrue("Contract failed: equals-hashcode on var11 and var4", var11.equals(var4) ? var11.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     java.awt.Stroke var8 = var4.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var4.getRendererForDataset(var9);
//     var4.zoom(100.0d);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, (-1.0f), 10.0f, var4, 4.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 6.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(1);
//     java.lang.Object var2 = var1.clone();
//     var1.clear();
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
//     double var9 = var8.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
//     java.lang.String var12 = var11.toString();
//     boolean var13 = var1.equals((java.lang.Object)var11);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
//     java.awt.Paint var26 = var25.getBackgroundPaint();
//     java.awt.Font var27 = var25.getItemFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("hi!", var27);
//     java.awt.Graphics2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     var28.draw(var29, var30);
//     java.awt.Paint var32 = var28.getBackgroundPaint();
//     boolean var33 = var11.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var8 and var19
//     assertTrue("Contract failed: equals-hashcode on var8 and var19", var8.equals(var19) ? var8.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var8
//     assertTrue("Contract failed: equals-hashcode on var19 and var8", var19.equals(var8) ? var19.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var21
//     assertTrue("Contract failed: equals-hashcode on var10 and var21", var10.equals(var21) ? var10.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var10
//     assertTrue("Contract failed: equals-hashcode on var21 and var10", var21.equals(var10) ? var21.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     java.awt.Color var14 = java.awt.Color.getColor("", 1);
//     var6.setOutlinePaint((java.awt.Paint)var14);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.text.G2TextMeasurer var18 = new org.jfree.chart.text.G2TextMeasurer(var17);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("PlotOrientation.VERTICAL", var1, (java.awt.Paint)var14, 2.0f, (org.jfree.chart.text.TextMeasurer)var18);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-16777215), 0, 15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.FlowArrangement var1 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var2 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var4 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var1, var2, (java.lang.Comparable)1L);
//     java.lang.String var5 = var4.getToolTipText();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = null;
//     org.jfree.chart.util.Size2D var8 = var0.arrange((org.jfree.chart.block.BlockContainer)var4, var6, var7);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var8 = var4.getDomainAxisLocation(0);
    var4.setBackgroundImageAlpha(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var14.draw(var15, var16);
//     boolean var18 = var14.getExpandToFitSpace();
//     java.lang.String var19 = var14.getToolTipText();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("hi!");
//     var24.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var30 = var24.getBounds();
//     org.jfree.chart.util.RectangleAnchor var31 = null;
//     java.awt.geom.Point2D var32 = org.jfree.chart.util.RectangleAnchor.coordinates(var30, var31);
//     var21.draw(var22, var30);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
//     double var41 = var40.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var42 = var40.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     java.util.List var44 = var40.getCategoriesForAxis(var43);
//     double var45 = var40.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     java.awt.Paint var47 = var46.getBackgroundPaint();
//     java.awt.Font var48 = var46.getItemFont();
//     org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("hi!", var48);
//     java.awt.Graphics2D var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     var49.draw(var50, var51);
//     java.awt.Paint var53 = var49.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var54 = var49.getBounds();
//     var21.draw(var34, var54);
//     org.jfree.chart.block.BlockParams var56 = new org.jfree.chart.block.BlockParams();
//     double var57 = var56.getTranslateY();
//     java.lang.Object var58 = var14.draw(var20, var54, (java.lang.Object)var57);
//     
//     // Checks the contract:  equals-hashcode on var5 and var40
//     assertTrue("Contract failed: equals-hashcode on var5 and var40", var5.equals(var40) ? var5.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var5
//     assertTrue("Contract failed: equals-hashcode on var40 and var5", var40.equals(var5) ? var40.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var42
//     assertTrue("Contract failed: equals-hashcode on var7 and var42", var7.equals(var42) ? var7.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var7
//     assertTrue("Contract failed: equals-hashcode on var42 and var7", var42.equals(var7) ? var42.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
//     double var13 = var12.getHeight();
//     java.awt.Paint var14 = var12.getPaint();
//     var4.setRangeCrosshairPaint(var14);
//     int var16 = var4.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
//     var17.setPadding(var19);
//     org.jfree.chart.util.RectangleAnchor var21 = var17.getLegendItemGraphicLocation();
//     java.awt.Paint var22 = var17.getItemPaint();
//     org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.FlowArrangement var24 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var25 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var27 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var24, var25, (java.lang.Comparable)1L);
//     java.lang.Object var28 = var27.clone();
//     var27.setToolTipText("Size2D[width=-1.0, height=-1.0]");
//     org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("");
//     double var34 = var33.getHeight();
//     java.awt.Paint var35 = var33.getPaint();
//     java.awt.Font var36 = var33.getFont();
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("hi!", var36);
//     var23.add((org.jfree.chart.block.Block)var27, (java.lang.Object)"hi!");
//     var17.setWrapper((org.jfree.chart.block.BlockContainer)var27);
//     
//     // Checks the contract:  equals-hashcode on var12 and var33
//     assertTrue("Contract failed: equals-hashcode on var12 and var33", var12.equals(var33) ? var12.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var12
//     assertTrue("Contract failed: equals-hashcode on var33 and var12", var33.equals(var12) ? var33.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    double var3 = var1.calculateLeftInset(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    var2.setHeight((-1.0d));
    double var5 = var2.getWidth();
    java.lang.String var6 = var2.toString();
    java.lang.String var7 = var2.toString();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    boolean var11 = var2.equals((java.lang.Object)var10);
    double var13 = var10.constrain(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Size2D[width=-1.0, height=-1.0]"+ "'", var6.equals("Size2D[width=-1.0, height=-1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Size2D[width=-1.0, height=-1.0]"+ "'", var7.equals("Size2D[width=-1.0, height=-1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("hi!");
//     var9.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var15 = var9.getBounds();
//     org.jfree.chart.util.RectangleAnchor var16 = null;
//     java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var5.getCategoryStart((-16777216), (-16777216), var15, var18);
//     org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var15, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
//     java.lang.String var23 = var22.toString();
//     java.awt.Shape var24 = var22.getArea();
//     org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var24);
//     java.awt.Color var28 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var29 = var28.getColorSpace();
//     java.awt.image.ColorModel var30 = null;
//     java.awt.Rectangle var31 = null;
//     org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("hi!");
//     var33.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var39 = var33.getBounds();
//     java.awt.geom.AffineTransform var40 = null;
//     java.awt.RenderingHints var41 = null;
//     java.awt.PaintContext var42 = var28.createContext(var30, var31, var39, var40, var41);
//     org.jfree.data.category.CategoryDataset var43 = null;
//     org.jfree.chart.axis.CategoryAxis var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var43, var44, var45, var46);
//     double var48 = var47.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var49 = var47.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     java.util.List var51 = var47.getCategoriesForAxis(var50);
//     double var52 = var47.getAnchorValue();
//     java.awt.Color var55 = java.awt.Color.getColor("", 1);
//     var47.setOutlinePaint((java.awt.Paint)var55);
//     org.jfree.chart.title.LegendGraphic var57 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var39, (java.awt.Paint)var55);
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var58, var59, var60, var61);
//     double var63 = var62.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var64 = var62.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var65 = null;
//     java.util.List var66 = var62.getCategoriesForAxis(var65);
//     double var67 = var62.getAnchorValue();
//     var62.clearDomainAxes();
//     org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var62);
//     org.jfree.chart.title.LegendTitle var71 = var69.getLegend(10);
//     java.awt.Stroke var72 = var69.getBorderStroke();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var73 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.data.category.CategoryDataset var75 = null;
//     org.jfree.chart.axis.CategoryAxis var76 = null;
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var78 = null;
//     org.jfree.chart.plot.CategoryPlot var79 = new org.jfree.chart.plot.CategoryPlot(var75, var76, var77, var78);
//     double var80 = var79.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var81 = var79.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var82 = null;
//     java.util.List var83 = var79.getCategoriesForAxis(var82);
//     double var84 = var79.getAnchorValue();
//     var79.clearDomainMarkers();
//     java.awt.Paint var86 = var79.getRangeGridlinePaint();
//     var73.setSeriesOutlinePaint(1, var86, false);
//     org.jfree.chart.LegendItem var89 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=0]", "10", "org.jfree.data.general.DatasetChangeEvent[source=-1]", "1", var24, (java.awt.Paint)var55, var72, var86);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var79
//     assertTrue("Contract failed: equals-hashcode on var62 and var79", var62.equals(var79) ? var62.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var62
//     assertTrue("Contract failed: equals-hashcode on var79 and var62", var79.equals(var62) ? var79.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var64
//     assertTrue("Contract failed: equals-hashcode on var49 and var64", var49.equals(var64) ? var49.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var81
//     assertTrue("Contract failed: equals-hashcode on var49 and var81", var49.equals(var81) ? var49.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var49
//     assertTrue("Contract failed: equals-hashcode on var64 and var49", var64.equals(var49) ? var64.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var81
//     assertTrue("Contract failed: equals-hashcode on var64 and var81", var64.equals(var81) ? var64.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var49
//     assertTrue("Contract failed: equals-hashcode on var81 and var49", var81.equals(var49) ? var81.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var64
//     assertTrue("Contract failed: equals-hashcode on var81 and var64", var81.equals(var64) ? var81.hashCode() == var64.hashCode() : true);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
    double var10 = var9.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var9.getCategoriesForAxis(var12);
    double var14 = var9.getAnchorValue();
    var9.clearDomainAxes();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.title.LegendTitle var18 = var16.getLegend(10);
    java.awt.Stroke var19 = var16.getBorderStroke();
    var0.setBaseStroke(var19);
    var0.setMinimumBarLength(4.0d);
    java.awt.Color var26 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-8323073), (java.awt.Paint)var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(0.05d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     java.awt.Paint var2 = var0.getBasePaint();
//     java.awt.Stroke var4 = var0.getSeriesStroke(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
//     var0.setLegendItemToolTipGenerator(var5);
//     java.awt.Color var9 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var10 = var9.getColorSpace();
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
//     var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var20 = var14.getBounds();
//     java.awt.geom.AffineTransform var21 = null;
//     java.awt.RenderingHints var22 = null;
//     java.awt.PaintContext var23 = var9.createContext(var11, var12, var20, var21, var22);
//     boolean var24 = var0.equals((java.lang.Object)var9);
//     boolean var25 = var0.getAutoPopulateSeriesOutlinePaint();
//     java.awt.Graphics2D var26 = null;
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var27, var28, var29, var30);
//     double var32 = var31.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var33 = var31.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     java.util.List var35 = var31.getCategoriesForAxis(var34);
//     double var36 = var31.getAnchorValue();
//     var31.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var39 = new org.jfree.chart.block.LabelBlock("");
//     double var40 = var39.getHeight();
//     java.awt.Paint var41 = var39.getPaint();
//     var31.setRangeCrosshairPaint(var41);
//     int var43 = var31.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
//     java.awt.Color var47 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
//     var31.setRangeCrosshairPaint((java.awt.Paint)var47);
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var53 = new org.jfree.chart.block.LabelBlock("hi!");
//     var53.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var59 = var53.getBounds();
//     org.jfree.chart.util.RectangleAnchor var60 = null;
//     java.awt.geom.Point2D var61 = org.jfree.chart.util.RectangleAnchor.coordinates(var59, var60);
//     org.jfree.chart.util.RectangleEdge var62 = null;
//     double var63 = var49.getCategoryStart((-16777216), (-16777216), var59, var62);
//     var0.drawDomainGridline(var26, var31, var59, 0.0d);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    var0.setAutoPopulateSeriesStroke(true);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    double var15 = var14.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var17 = null;
    java.util.List var18 = var14.getCategoriesForAxis(var17);
    org.jfree.chart.event.RendererChangeEvent var19 = null;
    var14.rendererChanged(var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    int var22 = var14.getRangeAxisIndex(var21);
    java.awt.Stroke var23 = var14.getRangeGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-8323073), var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.lang.Object var11 = var10.clone();
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var17 = new org.jfree.chart.entity.TickLabelEntity(var14, "hi!", "hi!");
//     org.jfree.data.Range var18 = null;
//     org.jfree.data.Range var19 = null;
//     org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(var18, var19);
//     boolean var21 = var17.equals((java.lang.Object)var18);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var17.setArea(var24);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     java.util.List var34 = var30.getCategoriesForAxis(var33);
//     double var35 = var30.getAnchorValue();
//     java.awt.Color var38 = java.awt.Color.getColor("", 1);
//     var30.setOutlinePaint((java.awt.Paint)var38);
//     java.awt.Stroke var40 = var30.getDomainGridlineStroke();
//     java.awt.Color var43 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var44 = var43.getColorSpace();
//     java.awt.image.ColorModel var45 = null;
//     java.awt.Rectangle var46 = null;
//     org.jfree.chart.block.LabelBlock var48 = new org.jfree.chart.block.LabelBlock("hi!");
//     var48.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var54 = var48.getBounds();
//     java.awt.geom.AffineTransform var55 = null;
//     java.awt.RenderingHints var56 = null;
//     java.awt.PaintContext var57 = var43.createContext(var45, var46, var54, var55, var56);
//     var30.setNoDataMessagePaint((java.awt.Paint)var43);
//     org.jfree.chart.title.LegendGraphic var59 = new org.jfree.chart.title.LegendGraphic(var24, (java.awt.Paint)var43);
//     java.awt.color.ColorSpace var60 = var43.getColorSpace();
//     float[] var61 = null;
//     float[] var62 = var43.getRGBComponents(var61);
//     var10.setBackgroundPaint((java.awt.Paint)var43);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(1);
    int var2 = var1.size();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    double var8 = var7.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    java.util.List var11 = var7.getCategoriesForAxis(var10);
    org.jfree.chart.event.RendererChangeEvent var12 = null;
    var7.rendererChanged(var12);
    float var14 = var7.getForegroundAlpha();
    boolean var15 = var1.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     var1.addFragment(var3);
//     org.jfree.chart.text.TextFragment var5 = var1.getFirstTextFragment();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.util.Size2D var7 = var1.calculateDimensions(var6);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    java.lang.String var8 = var7.toString();
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var10 = null;
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var9, var10);
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
    org.jfree.chart.block.RectangleConstraint var15 = var11.toRangeHeight(var14);
    double var16 = var14.getLength();
    boolean var17 = var7.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "SortOrder.ASCENDING"+ "'", var8.equals("SortOrder.ASCENDING"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.DatasetChangeEvent[source=-1]");

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
//     double var13 = var12.getHeight();
//     java.awt.Paint var14 = var12.getPaint();
//     var4.setRangeCrosshairPaint(var14);
//     int var16 = var4.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
//     var17.setPadding(var19);
//     org.jfree.chart.util.RectangleAnchor var21 = var17.getLegendItemGraphicLocation();
//     java.awt.Paint var22 = var17.getItemPaint();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var27.getCategoriesForAxis(var30);
//     double var32 = var27.getAnchorValue();
//     var27.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("");
//     double var36 = var35.getHeight();
//     java.awt.Paint var37 = var35.getPaint();
//     var27.setRangeCrosshairPaint(var37);
//     int var39 = var27.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     org.jfree.chart.block.LineBorder var41 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var42 = var41.getInsets();
//     var40.setPadding(var42);
//     org.jfree.chart.util.RectangleAnchor var44 = var40.getLegendItemGraphicLocation();
//     var17.setLegendItemGraphicLocation(var44);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var35
//     assertTrue("Contract failed: equals-hashcode on var12 and var35", var12.equals(var35) ? var12.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var12
//     assertTrue("Contract failed: equals-hashcode on var35 and var12", var35.equals(var12) ? var35.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var41
//     assertTrue("Contract failed: equals-hashcode on var18 and var41", var18.equals(var41) ? var18.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var18
//     assertTrue("Contract failed: equals-hashcode on var41 and var18", var41.equals(var18) ? var41.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var14.draw(var15, var16);
//     java.awt.Paint var18 = var14.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var19 = var14.getBounds();
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     double var25 = var24.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var26 = var24.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     int var28 = var24.getIndexOf(var27);
//     java.util.List var29 = var24.getCategories();
//     org.jfree.chart.axis.AxisLocation var30 = var24.getDomainAxisLocation();
//     boolean var31 = var24.isRangeGridlinesVisible();
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
//     double var37 = var36.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var38 = var36.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     java.util.List var40 = var36.getCategoriesForAxis(var39);
//     double var41 = var36.getAnchorValue();
//     java.awt.Color var44 = java.awt.Color.getColor("", 1);
//     var36.setOutlinePaint((java.awt.Paint)var44);
//     var24.setBackgroundPaint((java.awt.Paint)var44);
//     int var47 = var44.getGreen();
//     org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var19, (java.awt.Paint)var44);
//     
//     // Checks the contract:  equals-hashcode on var7 and var38
//     assertTrue("Contract failed: equals-hashcode on var7 and var38", var7.equals(var38) ? var7.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var7
//     assertTrue("Contract failed: equals-hashcode on var38 and var7", var38.equals(var7) ? var38.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "hi!");
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
    double var10 = var9.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var9.getCategoriesForAxis(var12);
    double var14 = var9.getAnchorValue();
    java.awt.Color var17 = java.awt.Color.getColor("", 1);
    var9.setOutlinePaint((java.awt.Paint)var17);
    java.awt.Stroke var19 = var9.getDomainGridlineStroke();
    org.jfree.chart.axis.ValueAxis var20 = var9.getRangeAxis();
    var9.clearDomainAxes();
    boolean var22 = var4.equals((java.lang.Object)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    org.jfree.chart.axis.AxisCollection var2 = new org.jfree.chart.axis.AxisCollection();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2);
    boolean var4 = var0.equals((java.lang.Object)var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var10 = new org.jfree.chart.entity.TickLabelEntity(var7, "hi!", "hi!");
    java.lang.Object var11 = var10.clone();
    boolean var12 = var0.equals((java.lang.Object)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     int var10 = var4.getWeight();
//     int var11 = var4.getDatasetCount();
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var4.getRendererForDataset(var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     var18.setOutlinePaint((java.awt.Paint)var26);
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     double var33 = var32.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var34 = var32.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     int var36 = var32.getIndexOf(var35);
//     java.util.List var37 = var32.getCategories();
//     org.jfree.chart.axis.AxisLocation var38 = var32.getDomainAxisLocation();
//     var18.setDomainAxisLocation(var38, true);
//     var4.setDomainAxisLocation(var38, true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var32
//     assertTrue("Contract failed: equals-hashcode on var4 and var32", var4.equals(var32) ? var4.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var4
//     assertTrue("Contract failed: equals-hashcode on var32 and var4", var32.equals(var4) ? var32.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var0.setLegendItemToolTipGenerator(var5);
    java.awt.Color var9 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var10 = var9.getColorSpace();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
    var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var20 = var14.getBounds();
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var9.createContext(var11, var12, var20, var21, var22);
    boolean var24 = var0.equals((java.lang.Object)var9);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var27 = var26.getBackgroundPaint();
    java.awt.Color var31 = java.awt.Color.getHSBColor((-1.0f), 0.5f, 0.0f);
    var26.setPaint((java.awt.Paint)var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-165), (java.awt.Paint)var31, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var0.setLegendItemToolTipGenerator(var5);
    java.awt.Color var9 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var10 = var9.getColorSpace();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
    var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var20 = var14.getBounds();
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var9.createContext(var11, var12, var20, var21, var22);
    boolean var24 = var0.equals((java.lang.Object)var9);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var0.setBaseURLGenerator(var25, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    int var5 = var0.getRowCount();
    java.lang.Boolean var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-16777215), var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    int var9 = var4.getDomainAxisIndex(var8);
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var9 = var6.getRowRenderingOrder();
//     java.awt.Stroke var10 = var6.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var6.getRendererForDataset(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var6);
//     boolean var14 = var0.hasListener((java.util.EventListener)var13);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     var19.clearDomainAxes();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     org.jfree.chart.title.LegendTitle var28 = var26.getLegend(10);
//     java.awt.Stroke var29 = var26.getBorderStroke();
//     var13.setBorderStroke(var29);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(1);
    java.lang.Object var2 = var1.clone();
    var1.clear();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
    java.lang.String var12 = var11.toString();
    boolean var13 = var1.equals((java.lang.Object)var11);
    java.lang.String var14 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "SortOrder.ASCENDING"+ "'", var12.equals("SortOrder.ASCENDING"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "SortOrder.ASCENDING"+ "'", var14.equals("SortOrder.ASCENDING"));

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var10 = var4.getOrientation();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     java.util.List var19 = var15.getCategoriesForAxis(var18);
//     double var20 = var15.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     java.awt.Paint var22 = var21.getBackgroundPaint();
//     double var23 = var21.getWidth();
//     java.lang.Object var24 = var21.clone();
//     org.jfree.chart.util.RectangleAnchor var25 = var21.getLegendItemGraphicLocation();
//     boolean var26 = var10.equals((java.lang.Object)var21);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    java.lang.Boolean var6 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBasePositiveItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-16777215), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getColumnKey(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     double var6 = var5.getLowerMargin();
//     org.jfree.chart.axis.NumberTickUnit var7 = var5.getTickUnit();
//     var5.zoomRange(0.0d, 0.0d);
//     java.awt.Shape var11 = var5.getDownArrow();
//     org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
//     var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var20 = var14.getBounds();
//     java.awt.Paint var21 = var14.getPaint();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var27.getCategoriesForAxis(var30);
//     double var32 = var27.getAnchorValue();
//     var27.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("");
//     double var36 = var35.getHeight();
//     java.awt.Paint var37 = var35.getPaint();
//     var27.setRangeCrosshairPaint(var37);
//     int var39 = var27.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     java.awt.Color var43 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
//     var27.setRangeCrosshairPaint((java.awt.Paint)var43);
//     org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Stroke var46 = var45.getNextOutlineStroke();
//     java.awt.Shape var48 = null;
//     org.jfree.chart.util.StrokeList var49 = new org.jfree.chart.util.StrokeList();
//     java.lang.Object var50 = var49.clone();
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
//     double var57 = var56.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var58 = var56.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     java.util.List var60 = var56.getCategoriesForAxis(var59);
//     double var61 = var56.getAnchorValue();
//     var56.clearDomainAxes();
//     org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var56);
//     java.awt.RenderingHints var64 = var63.getRenderingHints();
//     java.awt.Stroke var65 = var63.getBorderStroke();
//     var49.setStroke(15, var65);
//     org.jfree.chart.block.LabelBlock var68 = new org.jfree.chart.block.LabelBlock("");
//     double var69 = var68.getHeight();
//     java.awt.Paint var70 = var68.getPaint();
//     org.jfree.chart.LegendItem var71 = new org.jfree.chart.LegendItem("10", "", "RectangleAnchor.CENTER", "", false, var11, true, var21, true, (java.awt.Paint)var43, var46, false, var48, var65, var70);
//     
//     // Checks the contract:  equals-hashcode on var35 and var68
//     assertTrue("Contract failed: equals-hashcode on var35 and var68", var35.equals(var68) ? var35.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var35
//     assertTrue("Contract failed: equals-hashcode on var68 and var35", var68.equals(var35) ? var68.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var58
//     assertTrue("Contract failed: equals-hashcode on var29 and var58", var29.equals(var58) ? var29.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var29
//     assertTrue("Contract failed: equals-hashcode on var58 and var29", var58.equals(var29) ? var58.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, 10.0d);
//     double var5 = var2.getLowerBound();
//     org.jfree.data.Range var7 = org.jfree.data.Range.shift(var2, Double.NaN);
//     
//     // Checks the contract:  var7.equals(var7)
//     assertTrue("Contract failed: var7.equals(var7)", var7.equals(var7));
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.RenderingHints var12 = var11.getRenderingHints();
//     var11.setBackgroundImageAlpha(0.0f);
//     org.jfree.chart.plot.CategoryPlot var15 = var11.getCategoryPlot();
//     org.jfree.chart.title.LegendTitle var17 = var11.getLegend(10);
//     org.jfree.chart.event.PlotChangeEvent var18 = null;
//     var11.plotChanged(var18);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.HorizontalAlignment var11 = var10.getHorizontalAlignment();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var13 = var12.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var12.getLegendItemToolTipGenerator();
    java.awt.Shape var16 = var12.lookupSeriesShape(0);
    var12.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var20 = null;
    var12.setSeriesURLGenerator(0, var20);
    var12.setItemMargin(6.0d);
    boolean var24 = var11.equals((java.lang.Object)var12);
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setSeriesURLGenerator((-16777216), var26, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("HorizontalAlignment.CENTER", var1, 0.0f, 0.5f, 100.0d, 0.0f, 0.5f);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("");
//     double var18 = var17.getHeight();
//     java.awt.Paint var19 = var17.getPaint();
//     java.awt.Font var20 = var17.getFont();
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("hi!", var20);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
//     double var27 = var26.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var28 = var26.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     java.util.List var30 = var26.getCategoriesForAxis(var29);
//     double var31 = var26.getAnchorValue();
//     java.awt.Color var34 = java.awt.Color.getColor("", 1);
//     var26.setOutlinePaint((java.awt.Paint)var34);
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", var20, (java.awt.Paint)var34);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.text.G2TextMeasurer var39 = new org.jfree.chart.text.G2TextMeasurer(var38);
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.chart.event.ChartChangeEvent[source=0]", var13, (java.awt.Paint)var34, 10.0f, (org.jfree.chart.text.TextMeasurer)var39);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     java.awt.Shape var4 = var0.lookupSeriesShape(0);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     double var10 = var9.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     java.util.List var13 = var9.getCategoriesForAxis(var12);
//     double var14 = var9.getAnchorValue();
//     var9.clearDomainAxes();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.title.LegendTitle var18 = var16.getLegend(10);
//     java.awt.Stroke var19 = var16.getBorderStroke();
//     var0.setBaseStroke(var19);
//     boolean var23 = var0.isItemLabelVisible(0, (-165));
//     var0.setSeriesVisible(15, (java.lang.Boolean)true, true);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
//     double var34 = var33.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var35 = var33.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     java.util.List var37 = var33.getCategoriesForAxis(var36);
//     org.jfree.chart.event.RendererChangeEvent var38 = null;
//     var33.rendererChanged(var38);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     int var41 = var33.getRangeAxisIndex(var40);
//     java.awt.Stroke var42 = var33.getRangeGridlineStroke();
//     var0.setSeriesOutlineStroke(15, var42);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var35
//     assertTrue("Contract failed: equals-hashcode on var11 and var35", var11.equals(var35) ? var11.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var11
//     assertTrue("Contract failed: equals-hashcode on var35 and var11", var35.equals(var11) ? var35.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("HorizontalAlignment.CENTER");

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getMargin();
//     double var14 = var12.calculateRightInset(0.0d);
//     double var16 = var12.calculateRightInset(0.0d);
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("hi!");
//     var21.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var27 = var21.getBounds();
//     org.jfree.chart.util.RectangleAnchor var28 = null;
//     java.awt.geom.Point2D var29 = org.jfree.chart.util.RectangleAnchor.coordinates(var27, var28);
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var17.getCategoryStart((-16777216), (-16777216), var27, var30);
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     double var38 = var37.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var39 = var37.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     java.util.List var41 = var37.getCategoriesForAxis(var40);
//     double var42 = var37.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
//     java.awt.Paint var44 = var43.getBackgroundPaint();
//     java.awt.Font var45 = var43.getItemFont();
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("hi!", var45);
//     org.jfree.chart.util.RectangleEdge var47 = var46.getPosition();
//     double var48 = org.jfree.chart.util.RectangleEdge.coordinate(var27, var47);
//     var12.trim(var27);
//     
//     // Checks the contract:  equals-hashcode on var4 and var37
//     assertTrue("Contract failed: equals-hashcode on var4 and var37", var4.equals(var37) ? var4.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var4
//     assertTrue("Contract failed: equals-hashcode on var37 and var4", var37.equals(var4) ? var37.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var39
//     assertTrue("Contract failed: equals-hashcode on var6 and var39", var6.equals(var39) ? var6.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var6
//     assertTrue("Contract failed: equals-hashcode on var39 and var6", var39.equals(var6) ? var39.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    java.lang.Number var4 = var0.getMeanValue((java.lang.Comparable)"[size=1]", (java.lang.Comparable)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var0.getValue(15, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var4.rendererChanged(var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     int var12 = var4.getRangeAxisIndex(var11);
//     org.jfree.chart.block.LineBorder var13 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var14 = var13.getPaint();
//     var4.setOutlinePaint(var14);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var24 = var21.getRowRenderingOrder();
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     int var28 = var27.getSubplotCount();
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("hi!");
//     var30.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var36 = var30.getBounds();
//     org.jfree.chart.util.RectangleAnchor var37 = null;
//     java.awt.geom.Point2D var38 = org.jfree.chart.util.RectangleAnchor.coordinates(var36, var37);
//     var21.zoomRangeAxes(4.0d, var27, var38);
//     org.jfree.data.category.CategoryDataset var40 = null;
//     org.jfree.chart.axis.CategoryAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
//     double var45 = var44.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var46 = var44.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var47 = var44.getRowRenderingOrder();
//     org.jfree.chart.ChartRenderingInfo var49 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var50 = new org.jfree.chart.plot.PlotRenderingInfo(var49);
//     int var51 = var50.getSubplotCount();
//     org.jfree.chart.block.LabelBlock var53 = new org.jfree.chart.block.LabelBlock("hi!");
//     var53.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var59 = var53.getBounds();
//     org.jfree.chart.util.RectangleAnchor var60 = null;
//     java.awt.geom.Point2D var61 = org.jfree.chart.util.RectangleAnchor.coordinates(var59, var60);
//     var44.zoomRangeAxes(4.0d, var50, var61);
//     var4.zoomDomainAxes(2.0d, var27, var61);
//     
//     // Checks the contract:  equals-hashcode on var21 and var44
//     assertTrue("Contract failed: equals-hashcode on var21 and var44", var21.equals(var44) ? var21.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var21
//     assertTrue("Contract failed: equals-hashcode on var44 and var21", var44.equals(var21) ? var44.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var23
//     assertTrue("Contract failed: equals-hashcode on var6 and var23", var6.equals(var23) ? var6.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var46
//     assertTrue("Contract failed: equals-hashcode on var6 and var46", var6.equals(var46) ? var6.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var6
//     assertTrue("Contract failed: equals-hashcode on var23 and var6", var23.equals(var6) ? var23.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var46
//     assertTrue("Contract failed: equals-hashcode on var23 and var46", var23.equals(var46) ? var23.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var6
//     assertTrue("Contract failed: equals-hashcode on var46 and var6", var46.equals(var6) ? var46.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var23
//     assertTrue("Contract failed: equals-hashcode on var46 and var23", var46.equals(var23) ? var46.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var50
//     assertTrue("Contract failed: equals-hashcode on var27 and var50", var27.equals(var50) ? var27.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var27
//     assertTrue("Contract failed: equals-hashcode on var50 and var27", var50.equals(var27) ? var50.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var53
//     assertTrue("Contract failed: equals-hashcode on var30 and var53", var30.equals(var53) ? var30.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var30
//     assertTrue("Contract failed: equals-hashcode on var53 and var30", var53.equals(var30) ? var53.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("", 255, (-8323073));
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     java.awt.Font var12 = var10.getItemFont();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("hi!");
//     var21.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var27 = var21.getBounds();
//     org.jfree.chart.util.RectangleAnchor var28 = null;
//     java.awt.geom.Point2D var29 = org.jfree.chart.util.RectangleAnchor.coordinates(var27, var28);
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var17.getCategoryStart((-16777216), (-16777216), var27, var30);
//     org.jfree.chart.axis.AxisSpace var32 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     double var40 = var39.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var41 = var39.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     java.util.List var43 = var39.getCategoriesForAxis(var42);
//     double var44 = var39.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     java.awt.Paint var46 = var45.getBackgroundPaint();
//     java.awt.Font var47 = var45.getItemFont();
//     org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle("hi!", var47);
//     org.jfree.chart.util.RectangleEdge var49 = var48.getPosition();
//     var32.add(100.0d, var49);
//     double var51 = var13.getCategoryMiddle(0, 100, var27, var49);
//     var10.setPosition(var49);
//     
//     // Checks the contract:  equals-hashcode on var4 and var39
//     assertTrue("Contract failed: equals-hashcode on var4 and var39", var4.equals(var39) ? var4.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var4
//     assertTrue("Contract failed: equals-hashcode on var39 and var4", var39.equals(var4) ? var39.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var41
//     assertTrue("Contract failed: equals-hashcode on var6 and var41", var6.equals(var41) ? var6.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var6
//     assertTrue("Contract failed: equals-hashcode on var41 and var6", var41.equals(var6) ? var41.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
//     java.awt.Stroke var9 = var5.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var5.getRendererForDataset(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var5);
//     java.util.List var13 = var12.getSubtitles();
//     org.jfree.chart.event.TitleChangeEvent var14 = null;
//     var12.titleChanged(var14);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    java.awt.Color var1 = java.awt.Color.getColor("1");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     double var16 = var15.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var17 = var15.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var15.setFixedLegendItems(var18);
//     boolean var20 = var15.isSubplot();
//     var15.configureDomainAxes();
//     org.jfree.chart.event.PlotChangeEvent var22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
//     org.jfree.chart.plot.Plot var23 = var22.getPlot();
//     var4.notifyListeners(var22);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
//     double var3 = var2.getHeight();
//     java.awt.Paint var4 = var2.getPaint();
//     java.awt.Font var5 = var2.getFont();
//     org.jfree.chart.plot.Plot var6 = null;
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", var5, var6, true);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     float var14 = var4.getForegroundAlpha();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     var4.setRenderer(var15, false);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     double var19 = var18.getLowerMargin();
//     org.jfree.data.Range var20 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.chart.util.RectangleInsets var21 = var4.getInsets();
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
//     var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var29 = var23.getBounds();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     double var36 = var35.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var37 = var35.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     java.util.List var39 = var35.getCategoriesForAxis(var38);
//     double var40 = var35.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
//     java.awt.Paint var42 = var41.getBackgroundPaint();
//     java.awt.Font var43 = var41.getItemFont();
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("hi!", var43);
//     java.awt.Graphics2D var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     var44.draw(var45, var46);
//     java.awt.Paint var48 = var44.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var49 = var44.getBounds();
//     boolean var50 = org.jfree.chart.util.ShapeUtilities.intersects(var29, var49);
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     var52.setAlpha(0.0f);
//     org.jfree.chart.util.LengthAdjustmentType var55 = var52.getLabelOffsetType();
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//     org.jfree.chart.util.LengthAdjustmentType var58 = var57.getLabelOffsetType();
//     java.awt.geom.Rectangle2D var59 = var21.createAdjustedRectangle(var49, var55, var58);
//     
//     // Checks the contract:  equals-hashcode on var6 and var37
//     assertTrue("Contract failed: equals-hashcode on var6 and var37", var6.equals(var37) ? var6.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var6
//     assertTrue("Contract failed: equals-hashcode on var37 and var6", var37.equals(var6) ? var37.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.axis.TickType var0 = null;
//     java.lang.Comparable var3 = null;
//     org.jfree.chart.text.TextBlock var4 = null;
//     org.jfree.chart.text.TextBlockAnchor var5 = null;
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.text.TextAnchor var8 = var7.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var10 = new org.jfree.chart.axis.CategoryTick(var3, var4, var5, var8, (-1.0d));
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     var12.setAlpha(0.0f);
//     org.jfree.chart.util.LengthAdjustmentType var15 = var12.getLabelOffsetType();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.text.TextAnchor var18 = var17.getLabelTextAnchor();
//     var12.setLabelTextAnchor(var18);
//     org.jfree.chart.axis.NumberTick var21 = new org.jfree.chart.axis.NumberTick(var0, 10.0d, "DatasetRenderingOrder.REVERSE", var8, var18, 4.0d);
//     
//     // Checks the contract:  equals-hashcode on var7 and var17
//     assertTrue("Contract failed: equals-hashcode on var7 and var17", var7.equals(var17) ? var7.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var7
//     assertTrue("Contract failed: equals-hashcode on var17 and var7", var17.equals(var7) ? var17.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.title.LegendTitle var13 = var11.getLegend(10);
    var11.setBackgroundImageAlignment(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var17 = var11.getSubtitle(15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.CENTER", var1, 10.0d, 10.0f, 100.0f);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
    java.lang.Number var6 = var0.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var8 = var0.getColumnKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
//     org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     var6.clearDomainMarkers();
//     var6.mapDatasetToRangeAxis(1, (-253));
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     double var17 = var16.getLowerMargin();
//     org.jfree.chart.axis.NumberTickUnit var18 = var16.getTickUnit();
//     org.jfree.data.Range var19 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var16);
//     boolean var20 = var16.isAutoRange();
//     org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var25 = var24.getID();
//     int var26 = var22.compareTo((java.lang.Object)var24);
//     java.lang.String var28 = var22.valueToString(1.0d);
//     var16.setTickUnit(var22, false, false);
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     double var38 = var37.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var39 = var37.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     java.util.List var41 = var37.getCategoriesForAxis(var40);
//     double var42 = var37.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
//     java.awt.Paint var44 = var43.getBackgroundPaint();
//     java.awt.Font var45 = var43.getItemFont();
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("hi!", var45);
//     org.jfree.chart.util.RectangleEdge var47 = var46.getPosition();
//     var0.add((org.jfree.chart.axis.Axis)var16, var47);
//     
//     // Checks the contract:  equals-hashcode on var37 and var6
//     assertTrue("Contract failed: equals-hashcode on var37 and var6", var37.equals(var6) ? var37.hashCode() == var6.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var37 and var6.", var37.equals(var6) == var6.equals(var37));
//     
//     // Checks the contract:  equals-hashcode on var8 and var39
//     assertTrue("Contract failed: equals-hashcode on var8 and var39", var8.equals(var39) ? var8.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var8
//     assertTrue("Contract failed: equals-hashcode on var39 and var8", var39.equals(var8) ? var39.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(6.0d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-8323073), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
//     var2.setHeight((-1.0d));
//     double var5 = var2.getWidth();
//     org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
//     var8.setHeight((-1.0d));
//     double var11 = var8.getWidth();
//     java.lang.String var12 = var8.toString();
//     java.lang.String var13 = var8.toString();
//     org.jfree.data.Range var14 = null;
//     org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
//     boolean var17 = var8.equals((java.lang.Object)var16);
//     boolean var18 = var2.equals((java.lang.Object)var16);
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var2
//     assertTrue("Contract failed: equals-hashcode on var8 and var2", var8.equals(var2) ? var8.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, (-8323073), (-253));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var5 = var4.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var4.getLegendItemToolTipGenerator();
//     java.awt.Shape var8 = var4.lookupSeriesShape(0);
//     org.jfree.chart.labels.ItemLabelPosition var9 = new org.jfree.chart.labels.ItemLabelPosition();
//     var4.setPositiveItemLabelPositionFallback(var9);
//     org.jfree.chart.text.TextAnchor var11 = var9.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("10", var1, 1.0f, 0.5f, var11, 6.0d, 2.0f, 10.0f);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
    double var13 = var12.getHeight();
    java.awt.Paint var14 = var12.getPaint();
    var4.setRangeCrosshairPaint(var14);
    int var16 = var4.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Graphics2D var18 = null;
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var20 = null;
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, var20);
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 100.0d);
    org.jfree.chart.block.RectangleConstraint var25 = var21.toRangeHeight(var24);
    org.jfree.chart.block.LengthConstraintType var26 = var21.getWidthConstraintType();
    org.jfree.chart.util.Size2D var27 = var17.arrange(var18, var21);
    org.jfree.chart.LegendItemSource[] var28 = var17.getSources();
    org.jfree.chart.util.RectangleInsets var33 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-1.0d), (-1.0d), (-1.0d));
    double var34 = var33.getLeft();
    var17.setLegendItemGraphicPadding(var33);
    double var37 = var33.trimHeight(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 8.0d);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     java.awt.Font var14 = var12.getItemFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("hi!", var14);
//     org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("", var14);
//     org.jfree.chart.axis.AxisSpace var17 = new org.jfree.chart.axis.AxisSpace();
//     double var18 = var17.getTop();
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     org.jfree.chart.util.RectangleEdge var26 = var24.getDomainAxisEdge((-1));
//     java.lang.String var27 = var26.toString();
//     var17.ensureAtLeast(2.0d, var26);
//     boolean var29 = var16.equals((java.lang.Object)2.0d);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.util.HorizontalAlignment var11 = var10.getHorizontalAlignment();
//     org.jfree.chart.axis.AxisCollection var12 = new org.jfree.chart.axis.AxisCollection();
//     java.util.List var13 = var12.getAxesAtRight();
//     boolean var14 = var11.equals((java.lang.Object)var12);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     java.awt.Color var27 = java.awt.Color.getColor("", 1);
//     var19.setOutlinePaint((java.awt.Paint)var27);
//     float var29 = var19.getForegroundAlpha();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     var19.setRenderer(var30, false);
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     double var34 = var33.getLowerMargin();
//     org.jfree.data.Range var35 = var19.getDataRange((org.jfree.chart.axis.ValueAxis)var33);
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var41 = new org.jfree.chart.block.LabelBlock("hi!");
//     var41.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var47 = var41.getBounds();
//     org.jfree.chart.util.RectangleAnchor var48 = null;
//     java.awt.geom.Point2D var49 = org.jfree.chart.util.RectangleAnchor.coordinates(var47, var48);
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var37.getCategoryStart((-16777216), (-16777216), var47, var50);
//     org.jfree.chart.entity.CategoryLabelEntity var54 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var47, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
//     org.jfree.chart.entity.AxisLabelEntity var57 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var33, (java.awt.Shape)var47, "org.jfree.chart.event.ChartChangeEvent[source=0]", "org.jfree.data.general.DatasetChangeEvent[source=-1]");
//     org.jfree.chart.axis.Axis var58 = var57.getAxis();
//     boolean var59 = var58.isAxisLineVisible();
//     org.jfree.data.category.CategoryDataset var60 = null;
//     org.jfree.chart.axis.CategoryAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var60, var61, var62, var63);
//     org.jfree.chart.util.RectangleEdge var66 = var64.getDomainAxisEdge((-1));
//     java.lang.String var67 = var66.toString();
//     var12.add(var58, var66);
//     
//     // Checks the contract:  equals-hashcode on var4 and var64
//     assertTrue("Contract failed: equals-hashcode on var4 and var64", var4.equals(var64) ? var4.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var4
//     assertTrue("Contract failed: equals-hashcode on var64 and var4", var64.equals(var4) ? var64.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     java.awt.Stroke var14 = var4.getDomainGridlineStroke();
//     org.jfree.chart.axis.AxisLocation var16 = var4.getDomainAxisLocation(1);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     java.util.List var25 = var21.getCategoriesForAxis(var24);
//     double var26 = var21.getAnchorValue();
//     var21.clearDomainAxes();
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
//     java.awt.Paint var29 = var28.getBackgroundPaint();
//     java.awt.image.BufferedImage var32 = var28.createBufferedImage(1, 255);
//     var4.setBackgroundImage((java.awt.Image)var32);
//     
//     // Checks the contract:  equals-hashcode on var6 and var23
//     assertTrue("Contract failed: equals-hashcode on var6 and var23", var6.equals(var23) ? var6.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var6
//     assertTrue("Contract failed: equals-hashcode on var23 and var6", var23.equals(var6) ? var23.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateY(0.0d);
    boolean var3 = var0.getGenerateEntities();
    var0.setGenerateEntities(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var1 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)1L);
//     java.lang.Object var4 = var3.clone();
//     java.awt.Graphics2D var5 = null;
//     java.awt.Color var8 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var9 = var8.getColorSpace();
//     java.awt.image.ColorModel var10 = null;
//     java.awt.Rectangle var11 = null;
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("hi!");
//     var13.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var19 = var13.getBounds();
//     java.awt.geom.AffineTransform var20 = null;
//     java.awt.RenderingHints var21 = null;
//     java.awt.PaintContext var22 = var8.createContext(var10, var11, var19, var20, var21);
//     org.jfree.data.Range var23 = null;
//     org.jfree.data.Range var24 = null;
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var23, var24);
//     org.jfree.data.Range var26 = null;
//     org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var26, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var29 = var25.toRangeHeight(var28);
//     org.jfree.data.Range var32 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var33 = var25.toRangeHeight(var32);
//     java.lang.Object var34 = var3.draw(var5, (java.awt.geom.Rectangle2D)var11, (java.lang.Object)var33);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var2 = var1.getID();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    double var8 = var7.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    java.util.List var11 = var7.getCategoriesForAxis(var10);
    var7.setDomainGridlinesVisible(false);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("hi!");
    var19.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var25 = var19.getBounds();
    org.jfree.chart.util.RectangleAnchor var26 = null;
    java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var26);
    var7.zoomDomainAxes(100.0d, 10.0d, var17, var27);
    org.jfree.chart.renderer.category.CategoryItemRendererState var29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var17);
    boolean var30 = var1.equals((java.lang.Object)var17);
    org.jfree.chart.renderer.RendererState var31 = new org.jfree.chart.renderer.RendererState(var17);
    int var32 = var17.getSubplotCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     float var14 = var4.getForegroundAlpha();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     var4.setRenderer(var15, false);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     double var19 = var18.getLowerMargin();
//     org.jfree.data.Range var20 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.chart.util.RectangleInsets var21 = var4.getInsets();
//     int var22 = var4.getRangeAxisCount();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var29 = var27.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     int var31 = var27.getIndexOf(var30);
//     org.jfree.chart.LegendItemCollection var32 = null;
//     var27.setFixedLegendItems(var32);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var27.addChangeListener(var34);
//     var27.setAnchorValue((-1.0d), true);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
//     double var44 = var43.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var45 = var43.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var46 = var43.getRowRenderingOrder();
//     java.awt.Stroke var47 = var43.getOutlineStroke();
//     var27.setOutlineStroke(var47);
//     var4.setOutlineStroke(var47);
//     
//     // Checks the contract:  equals-hashcode on var6 and var45
//     assertTrue("Contract failed: equals-hashcode on var6 and var45", var6.equals(var45) ? var6.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var6
//     assertTrue("Contract failed: equals-hashcode on var45 and var6", var45.equals(var6) ? var45.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!");
//     var4.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var10 = var4.getBounds();
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var0.getCategoryStart((-16777216), (-16777216), var10, var13);
//     var0.setTickMarkOutsideLength(0.0f);
//     org.jfree.chart.util.RectangleInsets var17 = var0.getLabelInsets();
//     float var18 = var0.getTickMarkOutsideLength();
//     float var19 = var0.getTickMarkOutsideLength();
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.axis.AxisSpace var23 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     java.util.List var34 = var30.getCategoriesForAxis(var33);
//     double var35 = var30.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     java.awt.Paint var37 = var36.getBackgroundPaint();
//     java.awt.Font var38 = var36.getItemFont();
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("hi!", var38);
//     org.jfree.chart.util.RectangleEdge var40 = var39.getPosition();
//     var23.add(100.0d, var40);
//     double var42 = var0.getCategoryEnd(15, 0, var22, var40);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getInsets();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     double var8 = var7.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     java.util.List var11 = var7.getCategoriesForAxis(var10);
//     double var12 = var7.getAnchorValue();
//     var7.clearDomainAxes();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     java.awt.Paint var15 = var14.getBackgroundPaint();
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var2, var15);
//     org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("hi!");
//     var18.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var24 = var18.getBounds();
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     java.util.List var34 = var30.getCategoriesForAxis(var33);
//     double var35 = var30.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     java.awt.Paint var37 = var36.getBackgroundPaint();
//     java.awt.Font var38 = var36.getItemFont();
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("hi!", var38);
//     java.awt.Graphics2D var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     var39.draw(var40, var41);
//     java.awt.Paint var43 = var39.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var44 = var39.getBounds();
//     boolean var45 = org.jfree.chart.util.ShapeUtilities.intersects(var24, var44);
//     var2.trim(var24);
//     
//     // Checks the contract:  equals-hashcode on var7 and var30
//     assertTrue("Contract failed: equals-hashcode on var7 and var30", var7.equals(var30) ? var7.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var7
//     assertTrue("Contract failed: equals-hashcode on var30 and var7", var30.equals(var7) ? var30.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var32
//     assertTrue("Contract failed: equals-hashcode on var9 and var32", var9.equals(var32) ? var9.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var9
//     assertTrue("Contract failed: equals-hashcode on var32 and var9", var32.equals(var9) ? var32.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
//     double var13 = var12.getHeight();
//     java.awt.Paint var14 = var12.getPaint();
//     var4.setRangeCrosshairPaint(var14);
//     int var16 = var4.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
//     var17.setPadding(var19);
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var22 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var21, var22, (java.lang.Comparable)1L);
//     java.lang.Object var25 = var24.clone();
//     var17.setWrapper((org.jfree.chart.block.BlockContainer)var24);
//     java.lang.Object var27 = var24.clone();
//     
//     // Checks the contract:  equals-hashcode on var25 and var27
//     assertTrue("Contract failed: equals-hashcode on var25 and var27", var25.equals(var27) ? var25.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var25
//     assertTrue("Contract failed: equals-hashcode on var27 and var25", var27.equals(var25) ? var27.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)1L);
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)1L);
    java.lang.String var8 = var7.getToolTipText();
    java.awt.Graphics2D var9 = null;
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var12 = null;
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var11, var12);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    org.jfree.chart.block.RectangleConstraint var17 = var13.toRangeHeight(var16);
    double var18 = var16.getLength();
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var16);
    org.jfree.chart.util.Size2D var20 = var7.arrange(var9, var19);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("hi!");
    var7.add((org.jfree.chart.block.Block)var22);
    java.awt.Graphics2D var24 = null;
    org.jfree.data.Range var25 = null;
    org.jfree.data.Range var26 = null;
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var25, var26);
    org.jfree.data.Range var28 = null;
    org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 100.0d);
    org.jfree.chart.block.RectangleConstraint var31 = var27.toRangeHeight(var30);
    org.jfree.chart.block.RectangleConstraint var32 = var31.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var33 = var0.arrange((org.jfree.chart.block.BlockContainer)var7, var24, var31);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var10 = var4.getOrientation();
//     boolean var12 = var10.equals((java.lang.Object)100.0d);
//     java.lang.String var13 = var10.toString();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     var18.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var26 = var25.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var27 = var25.getLegendItemToolTipGenerator();
//     java.awt.Shape var29 = var25.lookupSeriesShape(0);
//     int var30 = var18.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     var25.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Shape var34 = var25.lookupSeriesShape(100);
//     java.awt.Stroke var37 = var25.getItemOutlineStroke(100, (-253));
//     boolean var38 = var10.equals((java.lang.Object)100);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    java.awt.Color var8 = java.awt.Color.getColor("", 1);
    var4.setDomainGridlinePaint((java.awt.Paint)var8);
    float[] var12 = new float[] { 1.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var13 = var8.getColorComponents(var12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     var4.mapDatasetToDomainAxis(0, 0);
//     java.awt.Font var14 = var4.getNoDataMessageFont();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     java.awt.Color var27 = java.awt.Color.getColor("", 1);
//     var19.setOutlinePaint((java.awt.Paint)var27);
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     java.awt.geom.Point2D var32 = null;
//     var19.zoomRangeAxes((-1.0d), 1.0d, var31, var32);
//     var19.clearDomainMarkers(10);
//     org.jfree.chart.event.PlotChangeListener var36 = null;
//     var19.addChangeListener(var36);
//     org.jfree.chart.axis.AxisLocation var39 = var19.getRangeAxisLocation((-253));
//     var4.setRangeAxisLocation(var39);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.ui.Library var6 = new org.jfree.chart.ui.Library("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "RectangleAnchor.CENTER", "Size2D[width=-1.0, height=-1.0]");
    java.lang.String var7 = var6.getVersion();
    boolean var8 = var1.equals((java.lang.Object)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="+ "'", var7.equals("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
//     java.awt.Stroke var9 = var5.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var5.getRendererForDataset(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var5);
//     java.util.List var13 = var12.getSubtitles();
//     var12.setNotify(false);
//     org.jfree.chart.title.LegendTitle var16 = var12.getLegend();
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     int var21 = var20.getSubplotCount();
//     org.jfree.chart.renderer.RendererState var22 = new org.jfree.chart.renderer.RendererState(var20);
//     org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("hi!");
//     var24.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var30 = var24.getBounds();
//     org.jfree.chart.util.RectangleAnchor var31 = null;
//     java.awt.geom.Point2D var32 = org.jfree.chart.util.RectangleAnchor.coordinates(var30, var31);
//     int var33 = var20.getSubplotIndex(var32);
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     var12.draw(var17, var18, var32, var34);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    var0.setItemMargin(0.05d);
    var0.setBaseItemLabelsVisible(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     java.awt.Color var13 = java.awt.Color.getColor("", 1);
//     var5.setOutlinePaint((java.awt.Paint)var13);
//     java.awt.Stroke var15 = var5.getDomainGridlineStroke();
//     java.awt.Color var18 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var19 = var18.getColorSpace();
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
//     var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var29 = var23.getBounds();
//     java.awt.geom.AffineTransform var30 = null;
//     java.awt.RenderingHints var31 = null;
//     java.awt.PaintContext var32 = var18.createContext(var20, var21, var29, var30, var31);
//     var5.setNoDataMessagePaint((java.awt.Paint)var18);
//     java.awt.Color var34 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=0]", var18);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var43 = new org.jfree.chart.entity.TickLabelEntity(var40, "hi!", "hi!");
//     org.jfree.data.Range var44 = null;
//     org.jfree.data.Range var45 = null;
//     org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint(var44, var45);
//     boolean var47 = var43.equals((java.lang.Object)var44);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var43.setArea(var50);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
//     double var57 = var56.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var58 = var56.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     java.util.List var60 = var56.getCategoriesForAxis(var59);
//     double var61 = var56.getAnchorValue();
//     java.awt.Color var64 = java.awt.Color.getColor("", 1);
//     var56.setOutlinePaint((java.awt.Paint)var64);
//     java.awt.Stroke var66 = var56.getDomainGridlineStroke();
//     java.awt.Color var69 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var70 = var69.getColorSpace();
//     java.awt.image.ColorModel var71 = null;
//     java.awt.Rectangle var72 = null;
//     org.jfree.chart.block.LabelBlock var74 = new org.jfree.chart.block.LabelBlock("hi!");
//     var74.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var80 = var74.getBounds();
//     java.awt.geom.AffineTransform var81 = null;
//     java.awt.RenderingHints var82 = null;
//     java.awt.PaintContext var83 = var69.createContext(var71, var72, var80, var81, var82);
//     var56.setNoDataMessagePaint((java.awt.Paint)var69);
//     org.jfree.chart.title.LegendGraphic var85 = new org.jfree.chart.title.LegendGraphic(var50, (java.awt.Paint)var69);
//     java.awt.color.ColorSpace var86 = var69.getColorSpace();
//     float[] var87 = null;
//     float[] var88 = var69.getRGBComponents(var87);
//     float[] var89 = java.awt.Color.RGBtoHSB(0, (-8323073), 10, var88);
//     float[] var90 = var34.getRGBComponents(var88);
//     
//     // Checks the contract:  equals-hashcode on var5 and var56
//     assertTrue("Contract failed: equals-hashcode on var5 and var56", var5.equals(var56) ? var5.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var5
//     assertTrue("Contract failed: equals-hashcode on var56 and var5", var56.equals(var5) ? var56.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var58
//     assertTrue("Contract failed: equals-hashcode on var7 and var58", var7.equals(var58) ? var7.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var7
//     assertTrue("Contract failed: equals-hashcode on var58 and var7", var58.equals(var7) ? var58.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var74
//     assertTrue("Contract failed: equals-hashcode on var23 and var74", var23.equals(var74) ? var23.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var23
//     assertTrue("Contract failed: equals-hashcode on var74 and var23", var74.equals(var23) ? var74.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.FlowArrangement var1 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var2 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var4 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var1, var2, (java.lang.Comparable)1L);
//     java.lang.Object var5 = var4.clone();
//     var4.setToolTipText("Size2D[width=-1.0, height=-1.0]");
//     org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("");
//     double var11 = var10.getHeight();
//     java.awt.Paint var12 = var10.getPaint();
//     java.awt.Font var13 = var10.getFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("hi!", var13);
//     var0.add((org.jfree.chart.block.Block)var4, (java.lang.Object)"hi!");
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     double var21 = var20.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var22 = var20.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     int var24 = var20.getIndexOf(var23);
//     java.util.List var25 = var20.getCategories();
//     org.jfree.chart.axis.AxisLocation var26 = var20.getDomainAxisLocation();
//     org.jfree.chart.plot.DatasetRenderingOrder var27 = var20.getDatasetRenderingOrder();
//     org.jfree.chart.block.FlowArrangement var28 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var29 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var31 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var28, var29, (java.lang.Comparable)1L);
//     boolean var32 = var31.isEmpty();
//     boolean var33 = var27.equals((java.lang.Object)var31);
//     java.lang.String var34 = var31.getURLText();
//     java.awt.Graphics2D var35 = null;
//     org.jfree.data.Range var36 = null;
//     org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var36, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(var38, 10.0d);
//     org.jfree.chart.block.RectangleConstraint var41 = var40.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var42 = var0.arrange((org.jfree.chart.block.BlockContainer)var31, var35, var40);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var31
//     assertTrue("Contract failed: equals-hashcode on var4 and var31", var4.equals(var31) ? var4.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var4
//     assertTrue("Contract failed: equals-hashcode on var31 and var4", var31.equals(var4) ? var31.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setNegativeArrowVisible(false);
    org.jfree.chart.util.RectangleInsets var3 = var0.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.clearAnnotations();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    double var11 = var10.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var12 = var10.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var13 = null;
    java.util.List var14 = var10.getCategoriesForAxis(var13);
    var10.setDomainGridlinesVisible(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var18 = var17.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var17.getLegendItemToolTipGenerator();
    java.awt.Shape var21 = var17.lookupSeriesShape(0);
    int var22 = var10.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
    var17.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var25 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var17};
    var4.setRenderers(var25);
    org.jfree.chart.util.RectangleInsets var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setAxisOffset(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     java.awt.Font var14 = var12.getItemFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("hi!", var14);
//     java.awt.Color var19 = java.awt.Color.getHSBColor((-1.0f), 0.5f, 0.0f);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.text.G2TextMeasurer var23 = new org.jfree.chart.text.G2TextMeasurer(var22);
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var14, (java.awt.Paint)var19, 1.0f, 0, (org.jfree.chart.text.TextMeasurer)var23);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    double var3 = var2.getHeight();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    var0.setLabelFont(var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)(byte)10);
    double var9 = var0.getUpperMargin();
    var0.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("");
//     double var18 = var17.getHeight();
//     java.awt.Paint var19 = var17.getPaint();
//     java.awt.Font var20 = var17.getFont();
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("hi!", var20);
//     java.awt.Color var24 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("", var20, (java.awt.Paint)var24);
//     float[] var26 = null;
//     float[] var27 = var24.getComponents(var26);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.text.G2TextMeasurer var30 = new org.jfree.chart.text.G2TextMeasurer(var29);
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("ChartEntity: tooltip = hi!", var13, (java.awt.Paint)var24, 0.5f, (org.jfree.chart.text.TextMeasurer)var30);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
//     var1.setWidth((-1.0d));
//     java.lang.String var4 = var1.getURLText();
//     java.lang.String var5 = var1.getToolTipText();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("hi!");
//     var11.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var17 = var11.getBounds();
//     org.jfree.chart.util.RectangleAnchor var18 = null;
//     java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var7.getCategoryStart((-16777216), (-16777216), var17, var20);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var27.getCategoriesForAxis(var30);
//     double var32 = var27.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     java.awt.Paint var34 = var33.getBackgroundPaint();
//     java.awt.Font var35 = var33.getItemFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("hi!", var35);
//     org.jfree.chart.util.RectangleEdge var37 = var36.getPosition();
//     double var38 = org.jfree.chart.util.RectangleEdge.coordinate(var17, var37);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var17, 2.0d, 2.0f, 2.0f);
//     var1.draw(var6, var17);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     var4.clearAnnotations();
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
//     double var11 = var10.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var12 = var10.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     java.util.List var14 = var10.getCategoriesForAxis(var13);
//     double var15 = var10.getAnchorValue();
//     var10.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("");
//     double var19 = var18.getHeight();
//     java.awt.Paint var20 = var18.getPaint();
//     var10.setRangeCrosshairPaint(var20);
//     int var22 = var10.getDomainAxisCount();
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
//     java.awt.Color var26 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
//     var10.setRangeCrosshairPaint((java.awt.Paint)var26);
//     int var28 = var26.getRed();
//     var4.setDomainGridlinePaint((java.awt.Paint)var26);
//     org.jfree.data.general.DatasetGroup var30 = var4.getDatasetGroup();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var32 = var31.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var33 = var31.getLegendItemToolTipGenerator();
//     java.awt.Shape var35 = var31.lookupSeriesShape(0);
//     org.jfree.chart.labels.ItemLabelPosition var36 = new org.jfree.chart.labels.ItemLabelPosition();
//     var31.setPositiveItemLabelPositionFallback(var36);
//     org.jfree.chart.labels.CategoryToolTipGenerator var39 = null;
//     var31.setSeriesToolTipGenerator(0, var39, false);
//     org.jfree.data.category.CategoryDataset var42 = null;
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot(var42, var43, var44, var45);
//     double var47 = var46.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var48 = var46.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var49 = null;
//     java.util.List var50 = var46.getCategoriesForAxis(var49);
//     double var51 = var46.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46);
//     java.awt.Paint var53 = var52.getBackgroundPaint();
//     java.awt.Font var54 = var52.getItemFont();
//     var31.setBaseItemLabelFont(var54, false);
//     var4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var31, false);
//     
//     // Checks the contract:  equals-hashcode on var12 and var48
//     assertTrue("Contract failed: equals-hashcode on var12 and var48", var12.equals(var48) ? var12.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var12
//     assertTrue("Contract failed: equals-hashcode on var48 and var12", var48.equals(var12) ? var48.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    java.text.AttributedString var0 = null;
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
    double var10 = var9.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var9.getCategoriesForAxis(var12);
    double var14 = var9.getAnchorValue();
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    java.awt.Paint var16 = var15.getBackgroundPaint();
    java.awt.Font var17 = var15.getItemFont();
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("hi!", var17);
    java.awt.Graphics2D var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    var18.draw(var19, var20);
    java.awt.Paint var22 = var18.getBackgroundPaint();
    java.awt.geom.Rectangle2D var23 = var18.getBounds();
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var29 = new org.jfree.chart.entity.TickLabelEntity(var26, "hi!", "hi!");
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var31 = null;
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(var30, var31);
    boolean var33 = var29.equals((java.lang.Object)var30);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    var29.setArea(var36);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape)var23, var36);
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
    double var44 = var43.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var45 = var43.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var46 = null;
    java.util.List var47 = var43.getCategoriesForAxis(var46);
    double var48 = var43.getAnchorValue();
    var43.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var51 = new org.jfree.chart.block.LabelBlock("");
    double var52 = var51.getHeight();
    java.awt.Paint var53 = var51.getPaint();
    var43.setRangeCrosshairPaint(var53);
    int var55 = var43.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
    java.awt.Color var59 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    var43.setRangeCrosshairPaint((java.awt.Paint)var59);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem(var0, "RectangleAnchor.CENTER", "DatasetRenderingOrder.REVERSE", "[size=1]", var36, (java.awt.Paint)var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setToolTipText("CONTRACT");

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     double var15 = var14.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var14.setFixedLegendItems(var17);
//     boolean var19 = var14.isSubplot();
//     var14.configureDomainAxes();
//     org.jfree.chart.event.PlotChangeEvent var21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var14);
//     org.jfree.chart.event.ChartChangeEventType var22 = null;
//     var21.setType(var22);
//     var4.notifyListeners(var21);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var16
//     assertTrue("Contract failed: equals-hashcode on var6 and var16", var6.equals(var16) ? var6.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var6
//     assertTrue("Contract failed: equals-hashcode on var16 and var6", var16.equals(var6) ? var16.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getRowKey((-165));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     java.util.List var10 = var6.getCategoriesForAxis(var9);
//     double var11 = var6.getAnchorValue();
//     var6.clearDomainMarkers();
//     java.awt.Paint var13 = var6.getRangeGridlinePaint();
//     var0.setSeriesOutlinePaint(1, var13, false);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     java.util.List var25 = var21.getCategoriesForAxis(var24);
//     org.jfree.chart.event.RendererChangeEvent var26 = null;
//     var21.rendererChanged(var26);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     int var29 = var21.getRangeAxisIndex(var28);
//     java.awt.Stroke var30 = var21.getRangeGridlineStroke();
//     var0.setSeriesStroke(10, var30, false);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var0.setLegendItemToolTipGenerator(var5);
    java.awt.Color var10 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var11 = var10.getColorSpace();
    java.awt.image.ColorModel var12 = null;
    java.awt.Rectangle var13 = null;
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("hi!");
    var15.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var21 = var15.getBounds();
    java.awt.geom.AffineTransform var22 = null;
    java.awt.RenderingHints var23 = null;
    java.awt.PaintContext var24 = var10.createContext(var12, var13, var21, var22, var23);
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var25, var26, var27, var28);
    double var30 = var29.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var31 = var29.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var32 = null;
    java.util.List var33 = var29.getCategoriesForAxis(var32);
    double var34 = var29.getAnchorValue();
    java.awt.Color var37 = java.awt.Color.getColor("", 1);
    var29.setOutlinePaint((java.awt.Paint)var37);
    org.jfree.chart.title.LegendGraphic var39 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var21, (java.awt.Paint)var37);
    int var40 = var37.getGreen();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlinePaint((-253), (java.awt.Paint)var37, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     double var18 = var17.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var19 = var17.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     java.util.List var21 = var17.getCategoriesForAxis(var20);
//     double var22 = var17.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     java.awt.Paint var24 = var23.getBackgroundPaint();
//     java.awt.Font var25 = var23.getItemFont();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("hi!", var25);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var26.draw(var27, var28);
//     java.awt.Paint var30 = var26.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var31 = var26.getBounds();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var37 = new org.jfree.chart.entity.TickLabelEntity(var34, "hi!", "hi!");
//     org.jfree.data.Range var38 = null;
//     org.jfree.data.Range var39 = null;
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(var38, var39);
//     boolean var41 = var37.equals((java.lang.Object)var38);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var37.setArea(var44);
//     boolean var46 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape)var31, var44);
//     var4.drawBackgroundImage(var11, var31);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, 8.0d, (-253), (java.lang.Comparable)"PlotOrientation.VERTICAL");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var3 = var2.clone();
    var0.ensureAtLeast(var2);
    org.jfree.chart.axis.AxisSpace var5 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var6 = var5.clone();
    org.jfree.chart.axis.AxisSpace var7 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var8 = var7.clone();
    var5.ensureAtLeast(var7);
    var0.ensureAtLeast(var7);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.util.RectangleEdge var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(8.0d, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Set var2 = var0.keySet();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var4 = var0.getStringArray("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    var4.setDomainGridlinesVisible(false);
    org.jfree.chart.ChartRenderingInfo var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
    org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("hi!");
    var16.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var22 = var16.getBounds();
    org.jfree.chart.util.RectangleAnchor var23 = null;
    java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
    var4.zoomDomainAxes(100.0d, 10.0d, var14, var24);
    org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var27 = var26.getInsets();
    org.jfree.chart.util.UnitType var28 = var27.getUnitType();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
    var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var42 = var36.getBounds();
    java.awt.geom.AffineTransform var43 = null;
    java.awt.RenderingHints var44 = null;
    java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
    var27.trim(var42);
    var14.setDataArea(var42);
    org.jfree.chart.util.RectangleAnchor var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var42, var48, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)4.0d, (java.lang.Number)100);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
//     double var13 = var12.getHeight();
//     java.awt.Paint var14 = var12.getPaint();
//     var4.setRangeCrosshairPaint(var14);
//     int var16 = var4.getDomainAxisCount();
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
//     double var23 = var22.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var24 = var22.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var25 = var22.getRowRenderingOrder();
//     java.awt.Stroke var26 = var22.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = var22.getRendererForDataset(var27);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var22);
//     java.util.List var30 = var29.getSubtitles();
//     var29.setNotify(false);
//     org.jfree.chart.title.LegendTitle var33 = var29.getLegend();
//     var29.removeLegend();
//     org.jfree.chart.event.ChartChangeEvent var35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16, var29);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var1 = var0.getColumnCount();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
    java.lang.Number var6 = var0.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 6.0d);
    org.jfree.data.Range var11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    java.lang.Number var12 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + Double.NaN+ "'", var12.equals(Double.NaN));

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.Object var1 = var0.clone();
    var0.setLabelAngle(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, var7);
//     boolean var9 = var5.equals((java.lang.Object)var6);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var5.setArea(var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     var18.setOutlinePaint((java.awt.Paint)var26);
//     java.awt.Stroke var28 = var18.getDomainGridlineStroke();
//     java.awt.Color var31 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var32 = var31.getColorSpace();
//     java.awt.image.ColorModel var33 = null;
//     java.awt.Rectangle var34 = null;
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("hi!");
//     var36.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var42 = var36.getBounds();
//     java.awt.geom.AffineTransform var43 = null;
//     java.awt.RenderingHints var44 = null;
//     java.awt.PaintContext var45 = var31.createContext(var33, var34, var42, var43, var44);
//     var18.setNoDataMessagePaint((java.awt.Paint)var31);
//     org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic(var12, (java.awt.Paint)var31);
//     java.awt.Shape var48 = var47.getShape();
//     var47.setShapeOutlineVisible(true);
//     var47.setShapeFilled(true);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     double var59 = var58.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var60 = var58.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     int var62 = var58.getIndexOf(var61);
//     java.util.List var63 = var58.getCategories();
//     org.jfree.chart.axis.AxisLocation var64 = var58.getDomainAxisLocation();
//     boolean var65 = var58.isRangeGridlinesVisible();
//     org.jfree.data.category.CategoryDataset var66 = null;
//     org.jfree.chart.axis.CategoryAxis var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot(var66, var67, var68, var69);
//     double var71 = var70.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var72 = var70.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var73 = null;
//     java.util.List var74 = var70.getCategoriesForAxis(var73);
//     double var75 = var70.getAnchorValue();
//     java.awt.Color var78 = java.awt.Color.getColor("", 1);
//     var70.setOutlinePaint((java.awt.Paint)var78);
//     var58.setBackgroundPaint((java.awt.Paint)var78);
//     java.awt.Color var81 = java.awt.Color.getColor("hi!", var78);
//     var47.setFillPaint((java.awt.Paint)var78);
//     
//     // Checks the contract:  equals-hashcode on var20 and var72
//     assertTrue("Contract failed: equals-hashcode on var20 and var72", var20.equals(var72) ? var20.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var20
//     assertTrue("Contract failed: equals-hashcode on var72 and var20", var72.equals(var20) ? var72.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var0.setLegendItemToolTipGenerator(var5);
    org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("");
    double var12 = var11.getHeight();
    java.awt.Paint var13 = var11.getPaint();
    java.awt.Font var14 = var11.getFont();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("hi!", var14);
    java.awt.Color var18 = java.awt.Color.getColor("SortOrder.ASCENDING", (-253));
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("", var14, (java.awt.Paint)var18);
    float[] var20 = null;
    float[] var21 = var18.getComponents(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-8323073), (java.awt.Paint)var18, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var12 = var11.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var11.getLegendItemToolTipGenerator();
//     java.awt.Shape var15 = var11.lookupSeriesShape(0);
//     int var16 = var4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var11.getLegendItemLabelGenerator();
//     var11.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     double var25 = var24.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var26 = var24.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     java.util.List var28 = var24.getCategoriesForAxis(var27);
//     double var29 = var24.getAnchorValue();
//     java.awt.Color var32 = java.awt.Color.getColor("", 1);
//     var24.setOutlinePaint((java.awt.Paint)var32);
//     float var34 = var24.getForegroundAlpha();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     var24.setRenderer(var35, false);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     double var39 = var38.getLowerMargin();
//     org.jfree.data.Range var40 = var24.getDataRange((org.jfree.chart.axis.ValueAxis)var38);
//     org.jfree.chart.util.RectangleInsets var41 = var24.getInsets();
//     var11.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
//     
//     // Checks the contract:  equals-hashcode on var6 and var26
//     assertTrue("Contract failed: equals-hashcode on var6 and var26", var6.equals(var26) ? var6.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var6
//     assertTrue("Contract failed: equals-hashcode on var26 and var6", var26.equals(var6) ? var26.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getInsets();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     double var8 = var7.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     java.util.List var11 = var7.getCategoriesForAxis(var10);
//     double var12 = var7.getAnchorValue();
//     var7.clearDomainAxes();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     java.awt.Paint var15 = var14.getBackgroundPaint();
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var2, var15);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.block.LineBorder var20 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!");
//     var23.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var29 = var23.getBounds();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     double var36 = var35.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var37 = var35.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     java.util.List var39 = var35.getCategoriesForAxis(var38);
//     double var40 = var35.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
//     java.awt.Paint var42 = var41.getBackgroundPaint();
//     java.awt.Font var43 = var41.getItemFont();
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("hi!", var43);
//     java.awt.Graphics2D var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     var44.draw(var45, var46);
//     java.awt.Paint var48 = var44.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var49 = var44.getBounds();
//     boolean var50 = org.jfree.chart.util.ShapeUtilities.intersects(var29, var49);
//     var20.draw(var21, var29);
//     java.awt.geom.Point2D var52 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(2.0d, 2.0d, var29);
//     var16.draw(var17, var29);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("ChartEntity: tooltip = hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     java.lang.Class var2 = null;
//     java.util.EventListener[] var3 = var1.getListeners(var2);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var11.setBackgroundImageAlignment(0);
    var11.clearSubtitles();
    java.lang.Object var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setTextAntiAlias(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     java.awt.Shape var4 = var0.lookupSeriesShape(0);
//     var0.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = null;
//     var0.setSeriesURLGenerator(0, var8);
//     var0.setItemMargin(6.0d);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     double var17 = var16.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
//     var16.clearAnnotations();
//     var0.setPlot(var16);
//     java.lang.Object var21 = var16.clone();
//     java.lang.String var22 = var16.getNoDataMessage();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var27.getCategoriesForAxis(var30);
//     double var32 = var27.getAnchorValue();
//     java.awt.Color var35 = java.awt.Color.getColor("", 1);
//     var27.setOutlinePaint((java.awt.Paint)var35);
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     java.awt.geom.Point2D var40 = null;
//     var27.zoomRangeAxes((-1.0d), 1.0d, var39, var40);
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("hi!");
//     var47.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var53 = var47.getBounds();
//     org.jfree.chart.util.RectangleAnchor var54 = null;
//     java.awt.geom.Point2D var55 = org.jfree.chart.util.RectangleAnchor.coordinates(var53, var54);
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var43.getCategoryStart((-16777216), (-16777216), var53, var56);
//     var43.setMaximumCategoryLabelLines(10);
//     var27.setDomainAxis(0, var43);
//     java.awt.Font var62 = var43.getTickLabelFont((java.lang.Comparable)(byte)1);
//     java.util.List var63 = var16.getCategoriesForAxis(var43);
//     
//     // Checks the contract:  equals-hashcode on var18 and var29
//     assertTrue("Contract failed: equals-hashcode on var18 and var29", var18.equals(var29) ? var18.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var18
//     assertTrue("Contract failed: equals-hashcode on var29 and var18", var29.equals(var18) ? var29.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     int var8 = var4.getIndexOf(var7);
//     org.jfree.chart.LegendItemCollection var9 = null;
//     var4.setFixedLegendItems(var9);
//     org.jfree.chart.event.PlotChangeListener var11 = null;
//     var4.addChangeListener(var11);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     int var14 = var4.getRangeAxisIndex(var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("hi!");
//     var19.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var25 = var19.getBounds();
//     org.jfree.chart.util.RectangleAnchor var26 = null;
//     java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var26);
//     var16.draw(var17, var25);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     double var36 = var35.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var37 = var35.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     java.util.List var39 = var35.getCategoriesForAxis(var38);
//     double var40 = var35.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
//     java.awt.Paint var42 = var41.getBackgroundPaint();
//     java.awt.Font var43 = var41.getItemFont();
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("hi!", var43);
//     java.awt.Graphics2D var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     var44.draw(var45, var46);
//     java.awt.Paint var48 = var44.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var49 = var44.getBounds();
//     var16.draw(var29, var49);
//     java.awt.geom.Point2D var51 = null;
//     org.jfree.chart.plot.PlotState var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     var4.draw(var15, var49, var51, var52, var53);
//     
//     // Checks the contract:  equals-hashcode on var4 and var35
//     assertTrue("Contract failed: equals-hashcode on var4 and var35", var4.equals(var35) ? var4.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var4
//     assertTrue("Contract failed: equals-hashcode on var35 and var4", var35.equals(var4) ? var35.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     int var11 = var10.getSubplotCount();
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("hi!");
//     var13.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var19 = var13.getBounds();
//     org.jfree.chart.util.RectangleAnchor var20 = null;
//     java.awt.geom.Point2D var21 = org.jfree.chart.util.RectangleAnchor.coordinates(var19, var20);
//     var4.zoomRangeAxes(4.0d, var10, var21);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     double var28 = var27.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var29 = var27.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var27.getCategoriesForAxis(var30);
//     var27.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     org.jfree.chart.block.LabelBlock var39 = new org.jfree.chart.block.LabelBlock("hi!");
//     var39.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var45 = var39.getBounds();
//     org.jfree.chart.util.RectangleAnchor var46 = null;
//     java.awt.geom.Point2D var47 = org.jfree.chart.util.RectangleAnchor.coordinates(var45, var46);
//     var27.zoomDomainAxes(100.0d, 10.0d, var37, var47);
//     int var49 = var10.getSubplotIndex(var47);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var39
//     assertTrue("Contract failed: equals-hashcode on var13 and var39", var13.equals(var39) ? var13.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var13
//     assertTrue("Contract failed: equals-hashcode on var39 and var13", var39.equals(var13) ? var39.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    double var6 = var5.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
    java.awt.Stroke var9 = var5.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var5.getRendererForDataset(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var5);
    java.util.List var13 = var12.getSubtitles();
    var12.setNotify(false);
    org.jfree.chart.title.LegendTitle var16 = var12.getLegend();
    var12.removeLegend();
    org.jfree.chart.ChartRenderingInfo var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var21 = var12.createBufferedImage(10, (-165), var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(100.0d, 0.0d);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
    double var10 = var9.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var9.getCategoriesForAxis(var12);
    double var14 = var9.getAnchorValue();
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleAnchor var16 = var15.getLegendItemGraphicLocation();
    java.awt.geom.Rectangle2D var17 = org.jfree.chart.util.RectangleAnchor.createRectangle(var2, (-1.0d), (-1.0d), var16);
    java.lang.Object var18 = null;
    boolean var19 = var2.equals(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.util.UnitType var2 = var1.getUnitType();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     double var8 = var7.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     java.util.List var11 = var7.getCategoriesForAxis(var10);
//     double var12 = var7.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
//     boolean var14 = var2.equals((java.lang.Object)var7);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var19.setFixedLegendItems(var22);
//     boolean var24 = var19.isSubplot();
//     var19.configureDomainAxes();
//     org.jfree.chart.event.PlotChangeEvent var26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var19);
//     var7.notifyListeners(var26);
//     
//     // Checks the contract:  equals-hashcode on var7 and var19
//     assertTrue("Contract failed: equals-hashcode on var7 and var19", var7.equals(var19) ? var7.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var7
//     assertTrue("Contract failed: equals-hashcode on var19 and var7", var19.equals(var7) ? var19.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var21
//     assertTrue("Contract failed: equals-hashcode on var9 and var21", var9.equals(var21) ? var9.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var9
//     assertTrue("Contract failed: equals-hashcode on var21 and var9", var21.equals(var9) ? var21.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     java.awt.Paint var14 = var4.getRangeCrosshairPaint();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     java.awt.Color var27 = java.awt.Color.getColor("", 1);
//     var19.setOutlinePaint((java.awt.Paint)var27);
//     java.awt.Stroke var29 = var19.getDomainGridlineStroke();
//     org.jfree.chart.axis.AxisLocation var31 = var19.getDomainAxisLocation(1);
//     var4.setRangeAxisLocation(var31, false);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
    java.util.List var2 = var0.getLines();
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLineAlignment(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     double var10 = var9.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     java.util.List var13 = var9.getCategoriesForAxis(var12);
//     double var14 = var9.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     java.awt.Paint var16 = var15.getBackgroundPaint();
//     java.awt.Font var17 = var15.getItemFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("hi!", var17);
//     org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("", var17);
//     var1.removeFragment(var19);
//     org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("");
//     var22.addFragment(var24);
//     org.jfree.chart.text.TextFragment var26 = var22.getFirstTextFragment();
//     org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("");
//     var22.addFragment(var28);
//     var1.addFragment(var28);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.util.Size2D var32 = var28.calculateDimensions(var31);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     double var8 = var7.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     java.util.List var11 = var7.getCategoriesForAxis(var10);
//     double var12 = var7.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     java.awt.Font var15 = var13.getItemFont();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("hi!", var15);
//     org.jfree.chart.util.RectangleEdge var17 = var16.getPosition();
//     var0.add(100.0d, var17);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("hi!");
//     var24.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var30 = var24.getBounds();
//     org.jfree.chart.util.RectangleAnchor var31 = null;
//     java.awt.geom.Point2D var32 = org.jfree.chart.util.RectangleAnchor.coordinates(var30, var31);
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var20.getCategoryStart((-16777216), (-16777216), var30, var33);
//     org.jfree.chart.entity.CategoryLabelEntity var37 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var30, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var38, var39, var40, var41);
//     double var43 = var42.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var44 = var42.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     java.util.List var46 = var42.getCategoriesForAxis(var45);
//     double var47 = var42.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
//     java.awt.Paint var49 = var48.getBackgroundPaint();
//     double var50 = var48.getWidth();
//     java.lang.Object var51 = var48.clone();
//     org.jfree.chart.util.RectangleAnchor var52 = var48.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var53 = org.jfree.chart.util.RectangleAnchor.coordinates(var30, var52);
//     org.jfree.chart.util.Size2D var56 = new org.jfree.chart.util.Size2D(100.0d, 0.0d);
//     org.jfree.data.category.CategoryDataset var59 = null;
//     org.jfree.chart.axis.CategoryAxis var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var59, var60, var61, var62);
//     double var64 = var63.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var65 = var63.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var66 = null;
//     java.util.List var67 = var63.getCategoriesForAxis(var66);
//     double var68 = var63.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
//     org.jfree.chart.util.RectangleAnchor var70 = var69.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var71 = org.jfree.chart.util.RectangleAnchor.createRectangle(var56, (-1.0d), (-1.0d), var70);
//     java.awt.geom.Rectangle2D var72 = var0.expand(var30, var71);
//     
//     // Checks the contract:  equals-hashcode on var7 and var42
//     assertTrue("Contract failed: equals-hashcode on var7 and var42", var7.equals(var42) ? var7.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var63
//     assertTrue("Contract failed: equals-hashcode on var7 and var63", var7.equals(var63) ? var7.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var7
//     assertTrue("Contract failed: equals-hashcode on var42 and var7", var42.equals(var7) ? var42.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var63
//     assertTrue("Contract failed: equals-hashcode on var42 and var63", var42.equals(var63) ? var42.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var7
//     assertTrue("Contract failed: equals-hashcode on var63 and var7", var63.equals(var7) ? var63.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var42
//     assertTrue("Contract failed: equals-hashcode on var63 and var42", var63.equals(var42) ? var63.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var44
//     assertTrue("Contract failed: equals-hashcode on var9 and var44", var9.equals(var44) ? var9.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var65
//     assertTrue("Contract failed: equals-hashcode on var9 and var65", var9.equals(var65) ? var9.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var9
//     assertTrue("Contract failed: equals-hashcode on var44 and var9", var44.equals(var9) ? var44.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var65
//     assertTrue("Contract failed: equals-hashcode on var44 and var65", var44.equals(var65) ? var44.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var9
//     assertTrue("Contract failed: equals-hashcode on var65 and var9", var65.equals(var9) ? var65.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var44
//     assertTrue("Contract failed: equals-hashcode on var65 and var44", var65.equals(var44) ? var65.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainMarkers();
//     boolean var11 = var4.isOutlineVisible();
//     org.jfree.chart.block.FlowArrangement var12 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.FlowArrangement var13 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var14 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var13, var14, (java.lang.Comparable)1L);
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4, (org.jfree.chart.block.Arrangement)var12, (org.jfree.chart.block.Arrangement)var13);
//     
//     // Checks the contract:  equals-hashcode on var12 and var13
//     assertTrue("Contract failed: equals-hashcode on var12 and var13", var12.equals(var13) ? var12.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var12
//     assertTrue("Contract failed: equals-hashcode on var13 and var12", var13.equals(var12) ? var13.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
    java.awt.Stroke var12 = var8.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var8.getRendererForDataset(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var8);
    java.util.List var16 = var15.getSubtitles();
    org.jfree.chart.ChartRenderingInfo var21 = null;
    java.awt.image.BufferedImage var22 = var15.createBufferedImage(1, 10, (-1.0d), 1.0d, var21);
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "", (java.awt.Image)var22, "org.jfree.chart.event.ChartChangeEvent[source=0]", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "10");
    var26.setInfo("");
    var26.setLicenceText("PlotOrientation.VERTICAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var7 = var5.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var5.getCategoriesForAxis(var8);
//     double var10 = var5.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Font var13 = var11.getItemFont();
//     org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("hi!");
//     var15.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var21 = var15.getBounds();
//     java.awt.Paint var22 = var15.getPaint();
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING", var13, var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("hi!");
//     var30.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var36 = var30.getBounds();
//     org.jfree.chart.util.RectangleAnchor var37 = null;
//     java.awt.geom.Point2D var38 = org.jfree.chart.util.RectangleAnchor.coordinates(var36, var37);
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var26.getCategoryStart((-16777216), (-16777216), var36, var39);
//     org.jfree.chart.entity.CategoryLabelEntity var43 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var36, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     double var49 = var48.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var50 = var48.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     java.util.List var52 = var48.getCategoriesForAxis(var51);
//     double var53 = var48.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var48);
//     java.awt.Paint var55 = var54.getBackgroundPaint();
//     double var56 = var54.getWidth();
//     java.lang.Object var57 = var54.clone();
//     org.jfree.chart.util.RectangleAnchor var58 = var54.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var59 = org.jfree.chart.util.RectangleAnchor.coordinates(var36, var58);
//     var23.draw(var24, var36);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    double var9 = var8.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var10 = var8.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var11 = var8.getRowRenderingOrder();
    java.awt.Stroke var12 = var8.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var8.getRendererForDataset(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var8);
    java.util.List var16 = var15.getSubtitles();
    org.jfree.chart.ChartRenderingInfo var21 = null;
    java.awt.image.BufferedImage var22 = var15.createBufferedImage(1, 10, (-1.0d), 1.0d, var21);
    org.jfree.chart.ui.ProjectInfo var26 = new org.jfree.chart.ui.ProjectInfo("hi!", "VerticalAlignment.CENTER", "", (java.awt.Image)var22, "org.jfree.chart.event.ChartChangeEvent[source=0]", "CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", "10");
    var26.setName("");
    org.jfree.chart.ui.Library[] var29 = var26.getLibraries();
    java.lang.String var30 = var26.getLicenceText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "10"+ "'", var30.equals("10"));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var5 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setPositiveItemLabelPositionFallback(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var4 = var3.getID();
    int var5 = var1.compareTo((java.lang.Object)var3);
    java.lang.String var6 = var3.getURLText();
    java.lang.String var7 = var3.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainMarkers();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("");
    double var13 = var12.getHeight();
    java.awt.Paint var14 = var12.getPaint();
    var4.setRangeCrosshairPaint(var14);
    int var16 = var4.getDomainAxisCount();
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
    var17.setPadding(var19);
    org.jfree.chart.util.RectangleAnchor var21 = var17.getLegendItemGraphicLocation();
    org.jfree.chart.text.TextBlockAnchor var22 = null;
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
    double var28 = var27.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var29 = var27.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    int var31 = var27.getIndexOf(var30);
    java.util.List var32 = var27.getCategories();
    var27.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var35.setAlpha(0.0f);
    java.awt.Stroke var38 = var35.getOutlineStroke();
    var27.addRangeMarker((org.jfree.chart.plot.Marker)var35);
    org.jfree.chart.text.TextAnchor var40 = var35.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition(var21, var22, var40, (-2.0d), var42, 0.5f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("");
//     double var4 = var3.getHeight();
//     java.awt.Paint var5 = var3.getPaint();
//     java.awt.Font var6 = var3.getFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("hi!", var6);
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
//     double var13 = var12.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var14 = var12.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     java.util.List var16 = var12.getCategoriesForAxis(var15);
//     double var17 = var12.getAnchorValue();
//     java.awt.Color var20 = java.awt.Color.getColor("", 1);
//     var12.setOutlinePaint((java.awt.Paint)var20);
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=", var6, (java.awt.Paint)var20);
//     int var23 = var20.getRGB();
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var32 = new org.jfree.chart.entity.TickLabelEntity(var29, "hi!", "hi!");
//     org.jfree.data.Range var33 = null;
//     org.jfree.data.Range var34 = null;
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(var33, var34);
//     boolean var36 = var32.equals((java.lang.Object)var33);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var32.setArea(var39);
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     double var46 = var45.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var47 = var45.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     java.util.List var49 = var45.getCategoriesForAxis(var48);
//     double var50 = var45.getAnchorValue();
//     java.awt.Color var53 = java.awt.Color.getColor("", 1);
//     var45.setOutlinePaint((java.awt.Paint)var53);
//     java.awt.Stroke var55 = var45.getDomainGridlineStroke();
//     java.awt.Color var58 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var59 = var58.getColorSpace();
//     java.awt.image.ColorModel var60 = null;
//     java.awt.Rectangle var61 = null;
//     org.jfree.chart.block.LabelBlock var63 = new org.jfree.chart.block.LabelBlock("hi!");
//     var63.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var69 = var63.getBounds();
//     java.awt.geom.AffineTransform var70 = null;
//     java.awt.RenderingHints var71 = null;
//     java.awt.PaintContext var72 = var58.createContext(var60, var61, var69, var70, var71);
//     var45.setNoDataMessagePaint((java.awt.Paint)var58);
//     org.jfree.chart.title.LegendGraphic var74 = new org.jfree.chart.title.LegendGraphic(var39, (java.awt.Paint)var58);
//     java.awt.color.ColorSpace var75 = var58.getColorSpace();
//     float[] var76 = null;
//     float[] var77 = var58.getRGBComponents(var76);
//     float[] var78 = java.awt.Color.RGBtoHSB(0, (-8323073), 10, var77);
//     float[] var79 = var20.getRGBComponents(var78);
//     
//     // Checks the contract:  equals-hashcode on var14 and var47
//     assertTrue("Contract failed: equals-hashcode on var14 and var47", var14.equals(var47) ? var14.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var14
//     assertTrue("Contract failed: equals-hashcode on var47 and var14", var47.equals(var14) ? var47.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.NumberTickUnit var2 = var0.getTickUnit();
    var0.setAutoTickUnitSelection(false);
    var0.setLabelAngle(10.0d);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    double var8 = var7.getLowerMargin();
    org.jfree.chart.axis.TickUnitSource var9 = var7.getStandardTickUnits();
    var0.setStandardTickUnits(var9);
    boolean var11 = var0.isNegativeArrowVisible();
    boolean var12 = var0.isTickLabelsVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(100.0d, 8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     double var12 = var10.getWidth();
//     org.jfree.chart.util.RectangleAnchor var13 = var10.getLegendItemGraphicAnchor();
//     java.lang.Object var14 = var10.clone();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var19.getCategoriesForAxis(var22);
//     double var24 = var19.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
//     java.awt.Paint var26 = var25.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var27 = var25.getMargin();
//     double var29 = var27.calculateRightInset(0.0d);
//     double var31 = var27.calculateRightInset(0.0d);
//     var10.setLegendItemGraphicPadding(var27);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
//     double var14 = var13.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var15 = var13.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     java.util.List var17 = var13.getCategoriesForAxis(var16);
//     double var18 = var13.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     java.awt.Font var21 = var19.getItemFont();
//     org.jfree.chart.LegendItemSource[] var22 = var19.getSources();
//     boolean var23 = var7.equals((java.lang.Object)var19);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     java.awt.Stroke var14 = var4.getDomainGridlineStroke();
//     java.awt.Color var17 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var18 = var17.getColorSpace();
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
//     var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var28 = var22.getBounds();
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
//     var4.setNoDataMessagePaint((java.awt.Paint)var17);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     double var40 = var39.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var41 = var39.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var42 = var39.getRowRenderingOrder();
//     java.awt.Stroke var43 = var39.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var45 = var39.getRendererForDataset(var44);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var39);
//     boolean var47 = var33.hasListener((java.util.EventListener)var46);
//     var33.setMaximumBarWidth(8.0d);
//     int var50 = var4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
//     
//     // Checks the contract:  equals-hashcode on var6 and var41
//     assertTrue("Contract failed: equals-hashcode on var6 and var41", var6.equals(var41) ? var6.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var6
//     assertTrue("Contract failed: equals-hashcode on var41 and var6", var41.equals(var6) ? var41.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     java.awt.Paint var2 = var0.getBasePaint();
//     java.awt.Stroke var4 = var0.getSeriesStroke(1);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
//     var0.setLegendItemToolTipGenerator(var5);
//     java.awt.Color var9 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var10 = var9.getColorSpace();
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
//     var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var20 = var14.getBounds();
//     java.awt.geom.AffineTransform var21 = null;
//     java.awt.RenderingHints var22 = null;
//     java.awt.PaintContext var23 = var9.createContext(var11, var12, var20, var21, var22);
//     boolean var24 = var0.equals((java.lang.Object)var9);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     java.util.List var34 = var30.getCategoriesForAxis(var33);
//     double var35 = var30.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     java.awt.Paint var37 = var36.getBackgroundPaint();
//     java.awt.Font var38 = var36.getItemFont();
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("hi!", var38);
//     java.awt.Graphics2D var40 = null;
//     java.awt.Color var43 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var44 = var43.getColorSpace();
//     java.awt.image.ColorModel var45 = null;
//     java.awt.Rectangle var46 = null;
//     org.jfree.chart.block.LabelBlock var48 = new org.jfree.chart.block.LabelBlock("hi!");
//     var48.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var54 = var48.getBounds();
//     java.awt.geom.AffineTransform var55 = null;
//     java.awt.RenderingHints var56 = null;
//     java.awt.PaintContext var57 = var43.createContext(var45, var46, var54, var55, var56);
//     var39.draw(var40, var54);
//     boolean var59 = var0.equals((java.lang.Object)var39);
//     
//     // Checks the contract:  equals-hashcode on var14 and var48
//     assertTrue("Contract failed: equals-hashcode on var14 and var48", var14.equals(var48) ? var14.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var14
//     assertTrue("Contract failed: equals-hashcode on var48 and var14", var48.equals(var14) ? var48.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("");
    double var4 = var3.getHeight();
    java.awt.Paint var5 = var3.getPaint();
    java.awt.Font var6 = var3.getFont();
    var1.setLabelFont(var6);
    var1.setUpperMargin(100.0d);
    org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    var1.setCategoryLabelPositions(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    java.util.List var22 = var18.getCategoriesForAxis(var21);
    double var23 = var18.getAnchorValue();
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    java.awt.Paint var25 = var24.getBackgroundPaint();
    java.awt.Font var26 = var24.getItemFont();
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("hi!", var26);
    org.jfree.chart.util.RectangleEdge var28 = var27.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var29 = var11.getLabelPosition(var28);
    double var30 = var29.getAngle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1.0d));

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var1, Double.NaN, 10.0f, (-1.0f));
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var12 = var10.getMargin();
    double var14 = var12.calculateRightInset(0.0d);
    double var16 = var12.calculateLeftOutset(0.0d);
    double var18 = var12.calculateLeftInset((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.RenderingHints var12 = var11.getRenderingHints();
//     java.awt.Stroke var13 = var11.getBorderStroke();
//     int var14 = var11.getBackgroundImageAlignment();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     double var20 = var19.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var21 = var19.getDrawingSupplier();
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var19.setFixedLegendItems(var22);
//     boolean var24 = var19.isSubplot();
//     var19.configureDomainAxes();
//     org.jfree.chart.event.PlotChangeEvent var26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var19);
//     var11.plotChanged(var26);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    double var2 = var1.getHeight();
    java.awt.Paint var3 = var1.getPaint();
    java.lang.String var4 = var1.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("org.jfree.data.general.DatasetChangeEvent[source=-1]");
    var1.setExpandToFitSpace(false);
    java.lang.String var4 = var1.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     var11.setBackgroundImageAlignment(0);
//     var11.clearSubtitles();
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var21 = new org.jfree.chart.entity.TickLabelEntity(var18, "hi!", "hi!");
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var23 = null;
//     org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(var22, var23);
//     boolean var25 = var21.equals((java.lang.Object)var22);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var21.setArea(var28);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
//     double var35 = var34.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var36 = var34.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     java.util.List var38 = var34.getCategoriesForAxis(var37);
//     double var39 = var34.getAnchorValue();
//     java.awt.Color var42 = java.awt.Color.getColor("", 1);
//     var34.setOutlinePaint((java.awt.Paint)var42);
//     java.awt.Stroke var44 = var34.getDomainGridlineStroke();
//     java.awt.Color var47 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var48 = var47.getColorSpace();
//     java.awt.image.ColorModel var49 = null;
//     java.awt.Rectangle var50 = null;
//     org.jfree.chart.block.LabelBlock var52 = new org.jfree.chart.block.LabelBlock("hi!");
//     var52.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var58 = var52.getBounds();
//     java.awt.geom.AffineTransform var59 = null;
//     java.awt.RenderingHints var60 = null;
//     java.awt.PaintContext var61 = var47.createContext(var49, var50, var58, var59, var60);
//     var34.setNoDataMessagePaint((java.awt.Paint)var47);
//     org.jfree.chart.title.LegendGraphic var63 = new org.jfree.chart.title.LegendGraphic(var28, (java.awt.Paint)var47);
//     java.awt.color.ColorSpace var64 = var47.getColorSpace();
//     java.awt.Color var65 = java.awt.Color.getColor("[size=1]", var47);
//     var11.setBackgroundPaint((java.awt.Paint)var47);
//     
//     // Checks the contract:  equals-hashcode on var6 and var36
//     assertTrue("Contract failed: equals-hashcode on var6 and var36", var6.equals(var36) ? var6.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var6
//     assertTrue("Contract failed: equals-hashcode on var36 and var6", var36.equals(var6) ? var36.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Set var2 = var0.keySet();
    java.util.Enumeration var3 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var0.getString("RectangleConstraintType.RANGE");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=0]");
    java.text.NumberFormat var2 = null;
    var1.setNumberFormatOverride(var2);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    double var8 = var7.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    java.util.List var11 = var7.getCategoriesForAxis(var10);
    double var12 = var7.getAnchorValue();
    var7.clearDomainAxes();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    java.awt.RenderingHints var15 = var14.getRenderingHints();
    java.awt.Stroke var16 = var14.getBorderStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlineStroke((-16777215), var16, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     java.awt.Shape var4 = var0.lookupSeriesShape(0);
//     org.jfree.chart.labels.ItemLabelPosition var5 = new org.jfree.chart.labels.ItemLabelPosition();
//     var0.setPositiveItemLabelPositionFallback(var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(0, var8, false);
//     java.lang.Object var11 = var0.clone();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true);
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     double var21 = var20.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var22 = var20.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     java.util.List var24 = var20.getCategoriesForAxis(var23);
//     double var25 = var20.getAnchorValue();
//     var20.clearDomainAxes();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.title.LegendTitle var29 = var27.getLegend(10);
//     java.awt.Stroke var30 = var27.getBorderStroke();
//     var0.setSeriesOutlineStroke(15, var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     double var38 = var37.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var39 = var37.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     java.util.List var41 = var37.getCategoriesForAxis(var40);
//     org.jfree.chart.axis.AxisSpace var42 = var37.getFixedDomainAxisSpace();
//     var37.setOutlineVisible(false);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
//     double var50 = var49.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var51 = var49.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     java.util.List var53 = var49.getCategoriesForAxis(var52);
//     var49.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var58 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var59 = new org.jfree.chart.plot.PlotRenderingInfo(var58);
//     org.jfree.chart.block.LabelBlock var61 = new org.jfree.chart.block.LabelBlock("hi!");
//     var61.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var67 = var61.getBounds();
//     org.jfree.chart.util.RectangleAnchor var68 = null;
//     java.awt.geom.Point2D var69 = org.jfree.chart.util.RectangleAnchor.coordinates(var67, var68);
//     var49.zoomDomainAxes(100.0d, 10.0d, var59, var69);
//     org.jfree.chart.block.BlockBorder var71 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var72 = var71.getInsets();
//     org.jfree.chart.util.UnitType var73 = var72.getUnitType();
//     java.awt.Color var76 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var77 = var76.getColorSpace();
//     java.awt.image.ColorModel var78 = null;
//     java.awt.Rectangle var79 = null;
//     org.jfree.chart.block.LabelBlock var81 = new org.jfree.chart.block.LabelBlock("hi!");
//     var81.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var87 = var81.getBounds();
//     java.awt.geom.AffineTransform var88 = null;
//     java.awt.RenderingHints var89 = null;
//     java.awt.PaintContext var90 = var76.createContext(var78, var79, var87, var88, var89);
//     var72.trim(var87);
//     var59.setDataArea(var87);
//     org.jfree.chart.entity.ChartEntity var94 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var87, "SortOrder.ASCENDING");
//     var0.drawOutline(var32, var37, var87);
//     
//     // Checks the contract:  equals-hashcode on var20 and var49
//     assertTrue("Contract failed: equals-hashcode on var20 and var49", var20.equals(var49) ? var20.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var20
//     assertTrue("Contract failed: equals-hashcode on var49 and var20", var49.equals(var20) ? var49.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var39
//     assertTrue("Contract failed: equals-hashcode on var22 and var39", var22.equals(var39) ? var22.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var51
//     assertTrue("Contract failed: equals-hashcode on var22 and var51", var22.equals(var51) ? var22.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var22
//     assertTrue("Contract failed: equals-hashcode on var39 and var22", var39.equals(var22) ? var39.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var51
//     assertTrue("Contract failed: equals-hashcode on var39 and var51", var39.equals(var51) ? var39.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var22
//     assertTrue("Contract failed: equals-hashcode on var51 and var22", var51.equals(var22) ? var51.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var39
//     assertTrue("Contract failed: equals-hashcode on var51 and var39", var51.equals(var39) ? var51.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    java.awt.Paint var2 = var0.getBasePaint();
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var0.setLegendItemToolTipGenerator(var5);
    java.awt.Color var9 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var10 = var9.getColorSpace();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!");
    var14.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var20 = var14.getBounds();
    java.awt.geom.AffineTransform var21 = null;
    java.awt.RenderingHints var22 = null;
    java.awt.PaintContext var23 = var9.createContext(var11, var12, var20, var21, var22);
    boolean var24 = var0.equals((java.lang.Object)var9);
    boolean var25 = var0.getAutoPopulateSeriesOutlinePaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var28 = var27.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var29 = var27.getLegendItemToolTipGenerator();
    java.awt.Shape var31 = var27.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var32 = new org.jfree.chart.labels.ItemLabelPosition();
    var27.setPositiveItemLabelPositionFallback(var32);
    org.jfree.chart.labels.CategoryToolTipGenerator var35 = null;
    var27.setSeriesToolTipGenerator(0, var35, false);
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var38, var39, var40, var41);
    double var43 = var42.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var44 = var42.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var45 = null;
    java.util.List var46 = var42.getCategoriesForAxis(var45);
    double var47 = var42.getAnchorValue();
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
    java.awt.Paint var49 = var48.getBackgroundPaint();
    java.awt.Font var50 = var48.getItemFont();
    var27.setBaseItemLabelFont(var50, false);
    org.jfree.chart.labels.ItemLabelPosition var53 = var27.getPositiveItemLabelPositionFallback();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-16777215), var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    org.jfree.chart.util.RectangleInsets var2 = var0.getInsets();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    double var8 = var7.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var9 = var7.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    java.util.List var11 = var7.getCategoriesForAxis(var10);
    double var12 = var7.getAnchorValue();
    var7.clearDomainAxes();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    java.awt.Paint var15 = var14.getBackgroundPaint();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var2, var15);
    java.awt.Color var19 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var20 = var19.getColorSpace();
    java.awt.image.ColorModel var21 = null;
    java.awt.Rectangle var22 = null;
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("hi!");
    var24.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var30 = var24.getBounds();
    java.awt.geom.AffineTransform var31 = null;
    java.awt.RenderingHints var32 = null;
    java.awt.PaintContext var33 = var19.createContext(var21, var22, var30, var31, var32);
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var35.setAlpha(0.0f);
    org.jfree.chart.util.LengthAdjustmentType var38 = var35.getLabelOffsetType();
    java.lang.String var39 = var38.toString();
    java.lang.String var40 = var38.toString();
    org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.lang.Object var43 = var42.clone();
    org.jfree.chart.util.LengthAdjustmentType var44 = var42.getLabelOffsetType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var45 = var2.createAdjustedRectangle((java.awt.geom.Rectangle2D)var22, var38, var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "CONTRACT"+ "'", var39.equals("CONTRACT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "CONTRACT"+ "'", var40.equals("CONTRACT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var1 = var0.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     java.awt.Shape var4 = var0.lookupSeriesShape(0);
//     int var5 = var0.getRowCount();
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(1);
//     var0.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var0.getNegativeItemLabelPosition(0, (-16777216));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var14 = var13.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var15 = var13.getLegendItemToolTipGenerator();
//     java.awt.Shape var17 = var13.lookupSeriesShape(0);
//     org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition();
//     var13.setPositiveItemLabelPositionFallback(var18);
//     org.jfree.chart.text.TextAnchor var20 = var18.getTextAnchor();
//     var0.setPositiveItemLabelPositionFallback(var18);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var24 = var23.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var25 = var23.getLegendItemToolTipGenerator();
//     java.awt.Shape var27 = var23.lookupSeriesShape(0);
//     var23.setAutoPopulateSeriesFillPaint(true);
//     boolean var31 = var23.isSeriesItemLabelsVisible(0);
//     org.jfree.chart.labels.ItemLabelPosition var32 = new org.jfree.chart.labels.ItemLabelPosition();
//     var23.setNegativeItemLabelPositionFallback(var32);
//     var0.setSeriesNegativeItemLabelPosition(15, var32, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var0.", var13.equals(var0) == var0.equals(var13));
//     
//     // Checks the contract:  equals-hashcode on var18 and var32
//     assertTrue("Contract failed: equals-hashcode on var18 and var32", var18.equals(var32) ? var18.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var18
//     assertTrue("Contract failed: equals-hashcode on var32 and var18", var32.equals(var18) ? var32.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     double var1 = var0.getTop();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     org.jfree.chart.util.RectangleEdge var9 = var7.getDomainAxisEdge((-1));
//     java.lang.String var10 = var9.toString();
//     var0.ensureAtLeast(2.0d, var9);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     double var17 = var16.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     java.util.List var20 = var16.getCategoriesForAxis(var19);
//     double var21 = var16.getAnchorValue();
//     java.awt.Color var24 = java.awt.Color.getColor("", 1);
//     var16.setOutlinePaint((java.awt.Paint)var24);
//     float var26 = var16.getForegroundAlpha();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var16.setRenderer(var27, false);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     double var31 = var30.getLowerMargin();
//     org.jfree.data.Range var32 = var16.getDataRange((org.jfree.chart.axis.ValueAxis)var30);
//     org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("hi!");
//     var38.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var44 = var38.getBounds();
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     org.jfree.chart.util.RectangleEdge var47 = null;
//     double var48 = var34.getCategoryStart((-16777216), (-16777216), var44, var47);
//     org.jfree.chart.entity.CategoryLabelEntity var51 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)true, (java.awt.Shape)var44, "org.jfree.data.general.DatasetChangeEvent[source=-1]", "");
//     org.jfree.chart.entity.AxisLabelEntity var54 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var30, (java.awt.Shape)var44, "org.jfree.chart.event.ChartChangeEvent[source=0]", "org.jfree.data.general.DatasetChangeEvent[source=-1]");
//     org.jfree.data.category.CategoryDataset var55 = null;
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var55, var56, var57, var58);
//     org.jfree.chart.util.RectangleEdge var61 = var59.getDomainAxisEdge((-1));
//     java.lang.String var62 = var61.toString();
//     java.awt.geom.Rectangle2D var63 = var0.reserved(var44, var61);
//     
//     // Checks the contract:  equals-hashcode on var7 and var59
//     assertTrue("Contract failed: equals-hashcode on var7 and var59", var7.equals(var59) ? var7.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var7
//     assertTrue("Contract failed: equals-hashcode on var59 and var7", var59.equals(var7) ? var59.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("hi!");
    var2.setWidth((-1.0d));
    java.lang.String var5 = var2.getURLText();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    var10.clearAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var2, (java.lang.Object)var10);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     var4.clearAnnotations();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     java.util.List var9 = var4.getCategoriesForAxis(var8);
//     int var10 = var4.getBackgroundImageAlignment();
//     var4.clearAnnotations();
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     org.jfree.chart.plot.PlotOrientation var24 = var18.getOrientation();
//     org.jfree.chart.LegendItemCollection var25 = var18.getLegendItems();
//     var4.setFixedLegendItems(var25);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)1L);
    java.lang.String var4 = var3.getToolTipText();
    java.awt.Graphics2D var5 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, var8);
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 100.0d);
    org.jfree.chart.block.RectangleConstraint var13 = var9.toRangeHeight(var12);
    double var14 = var12.getLength();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var12);
    org.jfree.chart.util.Size2D var16 = var3.arrange(var5, var15);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("hi!");
    var3.add((org.jfree.chart.block.Block)var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.data.Range var21 = null;
    org.jfree.data.Range var22 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(var21, var22);
    org.jfree.chart.block.RectangleConstraint var24 = var23.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var25 = var23.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var26 = var3.arrange(var20, var25);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    org.jfree.chart.labels.ItemLabelPosition var5 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setPositiveItemLabelPositionFallback(var5);
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     double var10 = var9.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var11 = var9.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     java.util.List var13 = var9.getCategoriesForAxis(var12);
//     double var14 = var9.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     java.awt.Paint var16 = var15.getBackgroundPaint();
//     java.awt.Font var17 = var15.getItemFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("hi!", var17);
//     org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("", var17);
//     var1.removeFragment(var19);
//     org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("");
//     var22.addFragment(var24);
//     org.jfree.chart.text.TextFragment var26 = var22.getFirstTextFragment();
//     org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("");
//     var22.addFragment(var28);
//     var1.addFragment(var28);
//     java.awt.Graphics2D var31 = null;
//     java.lang.Comparable var34 = null;
//     org.jfree.chart.text.TextBlock var35 = null;
//     org.jfree.chart.text.TextBlockAnchor var36 = null;
//     org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.text.TextAnchor var39 = var38.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var41 = new org.jfree.chart.axis.CategoryTick(var34, var35, var36, var39, (-1.0d));
//     org.jfree.chart.text.TextAnchor var42 = var41.getRotationAnchor();
//     var1.draw(var31, 100.0f, 0.5f, var42, 2.0f, 2.0f, 0.0d);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 8.0d, 0.05d, (-8323073), (java.lang.Comparable)255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    java.awt.Stroke var8 = var4.getOutlineStroke();
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var4.getRendererForDataset(var9);
    org.jfree.chart.annotations.CategoryAnnotation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    org.jfree.chart.axis.ValueAxis var15 = null;
    var4.setRangeAxis(0, var15, false);
    java.awt.Paint var18 = var4.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setBackgroundImageAlpha(2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     var4.clearDomainAxes();
//     org.jfree.chart.util.RectangleInsets var11 = var4.getInsets();
//     java.awt.Paint var12 = var4.getRangeCrosshairPaint();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var20 = var18.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.util.List var22 = var18.getCategoriesForAxis(var21);
//     double var23 = var18.getAnchorValue();
//     java.awt.Color var26 = java.awt.Color.getColor("", 1);
//     var18.setOutlinePaint((java.awt.Paint)var26);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     java.awt.geom.Point2D var31 = null;
//     var18.zoomRangeAxes((-1.0d), 1.0d, var30, var31);
//     var18.clearDomainMarkers(10);
//     org.jfree.chart.event.PlotChangeListener var35 = null;
//     var18.addChangeListener(var35);
//     org.jfree.chart.axis.AxisLocation var38 = var18.getRangeAxisLocation((-253));
//     var4.setDomainAxisLocation(100, var38);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-2.0d), Double.NaN, var2);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     double var7 = var6.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var8 = var6.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var9 = var6.getRowRenderingOrder();
//     java.awt.Stroke var10 = var6.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var6.getRendererForDataset(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=0]", (org.jfree.chart.plot.Plot)var6);
//     boolean var14 = var0.hasListener((java.util.EventListener)var13);
//     var0.setMaximumBarWidth(8.0d);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     double var22 = var21.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var23 = var21.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     java.util.List var25 = var21.getCategoriesForAxis(var24);
//     var21.setDomainGridlinesVisible(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     int var29 = var28.getRowCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var28.getLegendItemToolTipGenerator();
//     java.awt.Shape var32 = var28.lookupSeriesShape(0);
//     int var33 = var21.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var34 = var28.getLegendItemLabelGenerator();
//     var0.setLegendItemURLGenerator(var34);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.awt.RenderingHints var12 = var11.getRenderingHints();
    java.awt.Stroke var13 = var11.getBorderStroke();
    var11.setBorderVisible(false);
    org.jfree.chart.event.ChartChangeListener var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.removeChangeListener(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    double var13 = var12.getAnchorValue();
    org.jfree.chart.axis.CategoryAxis var14 = var12.getDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    int var16 = var12.getIndexOf(var15);
    java.util.List var17 = var12.getCategories();
    var12.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var20.setAlpha(0.0f);
    java.awt.Stroke var23 = var20.getOutlineStroke();
    var12.addRangeMarker((org.jfree.chart.plot.Marker)var20);
    org.jfree.chart.util.Layer var25 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var20, var25);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.ChartRenderingInfo var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var33 = var27.createBufferedImage((-165), 100, Double.NaN, 0.0d, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    java.awt.Color var12 = java.awt.Color.getColor("", 1);
    var4.setOutlinePaint((java.awt.Paint)var12);
    java.awt.Stroke var14 = var4.getDomainGridlineStroke();
    java.awt.Color var17 = java.awt.Color.getColor("", 1);
    java.awt.color.ColorSpace var18 = var17.getColorSpace();
    java.awt.image.ColorModel var19 = null;
    java.awt.Rectangle var20 = null;
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
    var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
    java.awt.geom.Rectangle2D var28 = var22.getBounds();
    java.awt.geom.AffineTransform var29 = null;
    java.awt.RenderingHints var30 = null;
    java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
    var4.setNoDataMessagePaint((java.awt.Paint)var17);
    var4.setNoDataMessage("");
    int var35 = var4.getDomainAxisCount();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
    var4.setRenderer(10, var37, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setBackgroundImageAlpha(2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var1 = var0.getColumnCount();
//     org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 10.0d);
//     java.lang.Number var6 = var0.getStdDevValue((java.lang.Comparable)(byte)0, (java.lang.Comparable)(byte)0);
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 6.0d);
//     double var11 = var0.getRangeUpperBound(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Comparable var13 = var0.getColumnKey((-165));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     double var6 = var5.getAnchorValue();
//     org.jfree.chart.util.Layer var7 = null;
//     java.util.Collection var8 = var5.getRangeMarkers(var7);
//     org.jfree.chart.axis.CategoryAnchor var9 = var5.getDomainGridlinePosition();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.axis.AxisSpace var13 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     double var21 = var20.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var22 = var20.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     java.util.List var24 = var20.getCategoriesForAxis(var23);
//     double var25 = var20.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
//     java.awt.Paint var27 = var26.getBackgroundPaint();
//     java.awt.Font var28 = var26.getItemFont();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("hi!", var28);
//     org.jfree.chart.util.RectangleEdge var30 = var29.getPosition();
//     var13.add(100.0d, var30);
//     double var32 = var0.getCategoryJava2DCoordinate(var9, (-16777216), 1, var12, var30);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { (byte)(-1)};
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("1", var1, 10.0f, 0.5f, var6, 0.05d, 10.0f, 10.0f);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     double var12 = var10.getWidth();
//     java.lang.Object var13 = var10.clone();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.data.Range var15 = null;
//     org.jfree.data.Range var16 = null;
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, var16);
//     org.jfree.data.Range var18 = null;
//     org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var21 = var17.toRangeHeight(var20);
//     org.jfree.chart.util.Size2D var22 = var10.arrange(var14, var17);
//     org.jfree.chart.block.BlockContainer var23 = null;
//     var10.setWrapper(var23);
//     org.jfree.chart.util.VerticalAlignment var25 = var10.getVerticalAlignment();
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     double var31 = var30.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var32 = var30.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     java.util.List var34 = var30.getCategoriesForAxis(var33);
//     double var35 = var30.getAnchorValue();
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     java.awt.Paint var37 = var36.getBackgroundPaint();
//     double var38 = var36.getWidth();
//     java.lang.Object var39 = var36.clone();
//     org.jfree.chart.util.RectangleAnchor var40 = var36.getLegendItemGraphicLocation();
//     var10.setLegendItemGraphicLocation(var40);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(0, var8);
    var0.setItemMargin(6.0d);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    double var17 = var16.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var18 = var16.getDrawingSupplier();
    var16.clearAnnotations();
    var0.setPlot(var16);
    java.lang.Object var21 = var16.clone();
    java.lang.String var22 = var16.getNoDataMessage();
    org.jfree.chart.plot.CategoryMarker var23 = null;
    org.jfree.chart.util.Layer var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.addDomainMarker(var23, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), 0.5f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-589829));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    int var1 = var0.getRowCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Shape var4 = var0.lookupSeriesShape(0);
    var0.setAutoPopulateSeriesFillPaint(true);
    var0.setAutoPopulateSeriesStroke(true);
    java.awt.Paint var11 = var0.getItemFillPaint(100, 100);
    java.awt.Paint var14 = var0.getItemOutlinePaint((-8323073), (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-253), (java.lang.Boolean)false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     java.util.List var8 = var4.getCategoriesForAxis(var7);
//     double var9 = var4.getAnchorValue();
//     java.awt.Color var12 = java.awt.Color.getColor("", 1);
//     var4.setOutlinePaint((java.awt.Paint)var12);
//     java.awt.Stroke var14 = var4.getDomainGridlineStroke();
//     java.awt.Color var17 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var18 = var17.getColorSpace();
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("hi!");
//     var22.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var28 = var22.getBounds();
//     java.awt.geom.AffineTransform var29 = null;
//     java.awt.RenderingHints var30 = null;
//     java.awt.PaintContext var31 = var17.createContext(var19, var20, var28, var29, var30);
//     var4.setNoDataMessagePaint((java.awt.Paint)var17);
//     var4.setNoDataMessage("");
//     float var35 = var4.getBackgroundImageAlpha();
//     int var36 = var4.getRangeAxisCount();
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
//     org.jfree.chart.entity.TickLabelEntity var42 = new org.jfree.chart.entity.TickLabelEntity(var39, "hi!", "hi!");
//     org.jfree.data.Range var43 = null;
//     org.jfree.data.Range var44 = null;
//     org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint(var43, var44);
//     boolean var46 = var42.equals((java.lang.Object)var43);
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     var42.setArea(var49);
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var51, var52, var53, var54);
//     double var56 = var55.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var57 = var55.getDrawingSupplier();
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     java.util.List var59 = var55.getCategoriesForAxis(var58);
//     double var60 = var55.getAnchorValue();
//     java.awt.Color var63 = java.awt.Color.getColor("", 1);
//     var55.setOutlinePaint((java.awt.Paint)var63);
//     java.awt.Stroke var65 = var55.getDomainGridlineStroke();
//     java.awt.Color var68 = java.awt.Color.getColor("", 1);
//     java.awt.color.ColorSpace var69 = var68.getColorSpace();
//     java.awt.image.ColorModel var70 = null;
//     java.awt.Rectangle var71 = null;
//     org.jfree.chart.block.LabelBlock var73 = new org.jfree.chart.block.LabelBlock("hi!");
//     var73.setPadding(0.0d, 0.0d, (-1.0d), 1.0d);
//     java.awt.geom.Rectangle2D var79 = var73.getBounds();
//     java.awt.geom.AffineTransform var80 = null;
//     java.awt.RenderingHints var81 = null;
//     java.awt.PaintContext var82 = var68.createContext(var70, var71, var79, var80, var81);
//     var55.setNoDataMessagePaint((java.awt.Paint)var68);
//     org.jfree.chart.title.LegendGraphic var84 = new org.jfree.chart.title.LegendGraphic(var49, (java.awt.Paint)var68);
//     java.awt.color.ColorSpace var85 = var68.getColorSpace();
//     float[] var86 = null;
//     float[] var87 = var68.getRGBComponents(var86);
//     var4.setOutlinePaint((java.awt.Paint)var68);
//     
//     // Checks the contract:  equals-hashcode on var6 and var57
//     assertTrue("Contract failed: equals-hashcode on var6 and var57", var6.equals(var57) ? var6.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var6
//     assertTrue("Contract failed: equals-hashcode on var57 and var6", var57.equals(var6) ? var57.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var73
//     assertTrue("Contract failed: equals-hashcode on var22 and var73", var22.equals(var73) ? var22.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var22
//     assertTrue("Contract failed: equals-hashcode on var73 and var22", var73.equals(var22) ? var73.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Set var2 = var0.keySet();
    java.lang.Object var4 = var0.handleGetObject("CategoryLabelEntity: category=true, tooltip=org.jfree.data.general.DatasetChangeEvent[source=-1], url=");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var0.getString("RectangleEdge.TOP");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "hi!", "hi!");
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setArea(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(8.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     var1.setAlpha(0.0f);
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     var5.setAlpha(0.0f);
//     org.jfree.chart.util.LengthAdjustmentType var8 = var5.getLabelOffsetType();
//     var1.setLabelOffsetType(var8);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    var2.setHeight((-1.0d));
    var2.setWidth((-1.0d));
    var2.setWidth(1.0d);
    var2.setWidth(6.0d);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     double var5 = var4.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
//     var4.clearAnnotations();
//     var4.setRangeCrosshairLockedOnData(false);
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     double var15 = var14.getAnchorValue();
//     org.jfree.chart.plot.DrawingSupplier var16 = var14.getDrawingSupplier();
//     org.jfree.chart.util.SortOrder var17 = var14.getRowRenderingOrder();
//     java.lang.String var18 = var17.toString();
//     var4.setColumnRenderingOrder(var17);
//     
//     // Checks the contract:  equals-hashcode on var6 and var16
//     assertTrue("Contract failed: equals-hashcode on var6 and var16", var6.equals(var16) ? var6.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var6
//     assertTrue("Contract failed: equals-hashcode on var16 and var6", var16.equals(var6) ? var16.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    org.jfree.chart.plot.DrawingSupplier var6 = var4.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    java.util.List var8 = var4.getCategoriesForAxis(var7);
    double var9 = var4.getAnchorValue();
    var4.clearDomainAxes();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.title.LegendTitle var13 = var11.getLegend(10);
    java.lang.Object var14 = var11.clone();
    org.jfree.chart.ChartRenderingInfo var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var20 = var11.createBufferedImage(0, 10, 6.0d, 100.0d, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

}
