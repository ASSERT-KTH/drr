
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setBackgroundAlpha(0.8f);
    java.awt.Stroke var12 = var7.getBaseSectionOutlineStroke();
    boolean var13 = var7.getSectionOutlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    java.lang.Comparable var3 = var0.getDomainCrosshairRowKey();
    org.jfree.chart.plot.DatasetRenderingOrder var4 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var7.setSeriesURLGenerator(10, var9);
    org.jfree.chart.urls.CategoryURLGenerator var12 = null;
    var7.setSeriesURLGenerator(3, var12, true);
    int var15 = var7.getPassCount();
    org.jfree.chart.renderer.category.BarPainter var16 = var7.getBarPainter();
    var7.setBaseSeriesVisible(true, true);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var7, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.data.Range var23 = var7.findRangeBounds(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     java.lang.String var1 = var0.getPlotType();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.XYURLGenerator var11 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
    org.jfree.chart.urls.XYURLGenerator var16 = var12.getURLGenerator(0, 1, true);
    var12.setBaseSeriesVisibleInLegend(false);
    int var19 = var0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
    org.jfree.chart.plot.CombinedDomainXYPlot var21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var22 = var21.getRangeAxis();
    java.awt.Paint var23 = var21.getDomainGridlinePaint();
    var12.setSeriesFillPaint(0, var23);
    java.awt.Stroke var28 = var12.getItemOutlineStroke(10, 68, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
    var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
    java.awt.Paint var10 = null;
    var9.setLabelBackgroundPaint(var10);
    var9.setInnerSeparatorExtension(0.0d);
    boolean var14 = var9.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var15 = var9.getDataset();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var9, true);
    var17.setBorderVisible(false);
    org.jfree.chart.util.RectangleInsets var20 = var17.getPadding();
    double var21 = var20.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var9.getStartYValue(96, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setAxisLineVisible(false);
    var1.setNegativeArrowVisible(false);
    java.awt.Paint var8 = var1.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var3 = var2.getFont();
    org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
    org.jfree.chart.text.TextFragment var5 = var4.getFirstTextFragment();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.RenderingSource var11 = null;
    var6.select(10.0d, 100.0d, var10, var11);
    var6.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var16 = null;
    org.jfree.chart.urls.XYURLGenerator var17 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var16, var17);
    org.jfree.chart.urls.XYURLGenerator var22 = var18.getURLGenerator(0, 1, true);
    var18.setBaseSeriesVisibleInLegend(false);
    int var25 = var6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var18);
    org.jfree.chart.labels.XYToolTipGenerator var27 = null;
    org.jfree.chart.urls.XYURLGenerator var28 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var27, var28);
    org.jfree.chart.urls.XYURLGenerator var33 = var29.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var34 = null;
    var29.setBaseURLGenerator(var34, false);
    java.awt.Paint var40 = var29.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var41 = var29.getBaseNegativeItemLabelPosition();
    var18.setBasePositiveItemLabelPosition(var41, true);
    var18.setBaseSeriesVisibleInLegend(true);
    boolean var46 = var5.equals((java.lang.Object)var18);
    org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var51 = var50.getFont();
    org.jfree.chart.text.TextLine var52 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var51);
    org.jfree.chart.axis.PeriodAxis var54 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var55 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var54);
    double var56 = var55.getGap();
    var55.setOutlineVisible(true);
    var55.setRangeCrosshairVisible(true);
    java.lang.String var61 = var55.getPlotType();
    org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart("TextAnchor.TOP_CENTER", var51, (org.jfree.chart.plot.Plot)var55, true);
    boolean var64 = var5.equals((java.lang.Object)"TextAnchor.TOP_CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "Combined Range XYPlot"+ "'", var61.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)false, 5.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue((-435), (java.lang.Comparable)(-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var3.getTimePeriod(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var11 = var10.getMaximumItemCount();
    java.beans.PropertyChangeListener var12 = null;
    var10.removePropertyChangeListener(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var18 = var17.getRangeDescription();
    org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
    boolean var24 = var21.isAxisLineVisible();
    var21.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
    var19.delete(var27);
    org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var31 = var30.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isAxisLineVisible();
    var30.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
    org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
    org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var42 = var41.getMaximumItemCount();
    java.beans.PropertyChangeListener var43 = null;
    var41.removePropertyChangeListener(var43);
    org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var41);
    var37.addChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
    org.jfree.data.time.TimePeriodAnchor var47 = var45.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var45.setSelected(10, (-435), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var9);
    double var12 = var9.getDomainUpperBound(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var15 = var9.getEndX((-435), 68);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5d);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     org.jfree.chart.renderer.PolarItemRenderer var40 = var39.getRenderer();
//     org.jfree.chart.event.RendererChangeEvent var41 = null;
//     var39.rendererChanged(var41);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var47 = var46.getRangeAxis();
//     java.awt.Paint var48 = var46.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var46);
//     java.awt.Image var50 = var46.getBackgroundImage();
//     java.awt.geom.Point2D var51 = var46.getQuadrantOrigin();
//     var39.zoomDomainAxes(0.0d, (-5.76E7d), var45, var51);
//     
//     // Checks the contract:  equals-hashcode on var30 and var46
//     assertTrue("Contract failed: equals-hashcode on var30 and var46", var30.equals(var46) ? var30.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var30
//     assertTrue("Contract failed: equals-hashcode on var46 and var30", var46.equals(var30) ? var46.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setAxisLineVisible(false);
    var1.setMinorTickMarkInsideLength((-1.0f));
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    int var9 = var8.getRendererCount();
    org.jfree.chart.axis.AxisLocation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setDomainAxisLocation((-435), var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var1 = var0.getDatasetRenderingOrder();
    int var2 = var0.getWeight();
    org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis(68);
    org.jfree.chart.util.RectangleInsets var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisOffset(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(70, 70);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(68, 100, 2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    java.lang.String var4 = var3.toString();
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var3.createInsetRectangle(var5, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var4.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setSeriesURLGenerator(3, var7, true);
    int var10 = var2.getPassCount();
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.LegendItemCollection var13 = var2.getLegendItems();
    java.awt.Paint var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlinePaint(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = null;
//     var2.setSeriesURLGenerator(3, var7, true);
//     int var10 = var2.getPassCount();
//     var2.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var15 = var14.getDomainAxisEdge();
//     org.jfree.chart.axis.ValueAxis var17 = var14.getRangeAxisForDataset(2147483647);
//     java.awt.geom.Rectangle2D var18 = null;
//     var2.drawBackground(var13, var14, var18);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    boolean var1 = var0.isDomainCrosshairLockedOnData();
    boolean var3 = var0.equals((java.lang.Object)(-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var3, (org.jfree.chart.urls.XYURLGenerator)var5);
    var6.setSeriesShapesVisible(3, false);
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setSeriesNegativeItemLabelPosition((-435), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var4.setAutoPopulateSeriesShape(true);
    var4.setDrawOutlines(false);
    java.awt.Shape var9 = var4.getLegendLine();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var12 = var11.getTickLabelPaint();
    var11.setUpperMargin(0.0d);
    java.awt.Paint var15 = var11.getLabelPaint();
    org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var16.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var16.setBaseLinesVisible(true);
    java.awt.Stroke var23 = var16.lookupSeriesStroke(0);
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var25 = var24.getDomainMinorGridlineStroke();
    var24.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var24.drawBackgroundImage(var28, var29);
    java.awt.Paint var31 = var24.getRangeZeroBaselinePaint();
    java.awt.Color var34 = java.awt.Color.getColor("hi!", 100);
    int var35 = var34.getBlue();
    var24.setRangeMinorGridlinePaint((java.awt.Paint)var34);
    float[] var46 = new float[] { 0.0f, 10.0f, 100.0f};
    float[] var47 = java.awt.Color.RGBtoHSB((-1), 0, 10, var46);
    float[] var48 = java.awt.Color.RGBtoHSB(1, 3, (-435), var46);
    float[] var49 = var34.getColorComponents(var48);
    org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("WMAP_Plot", "TextAnchor.TOP_CENTER", "Polar Plot", "RectangleAnchor.CENTER", var9, var15, var23, (java.awt.Paint)var34);
    org.jfree.chart.util.GradientPaintTransformer var51 = var50.getFillPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(true);
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var2);
//     var3.setAutoTickUnitSelection(true);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.AxisState var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     int var11 = var10.getMaximumCategoryLabelLines();
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.axis.AxisSpace var15 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.axis.AxisSpace var17 = new org.jfree.chart.axis.AxisSpace();
//     var17.setTop(10.0d);
//     var15.ensureAtLeast(var17);
//     org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var23 = var22.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var24 = null;
//     var22.setDrawingSupplier(var24);
//     float var26 = var22.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var30 = null;
//     org.jfree.chart.urls.XYURLGenerator var31 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var30, var31);
//     org.jfree.chart.urls.XYURLGenerator var36 = var32.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var37 = null;
//     var32.setBaseURLGenerator(var37, false);
//     java.awt.Paint var43 = var32.getItemFillPaint(10, 100, false);
//     var28.setLabelPaint(var43);
//     float var45 = var28.getAlpha();
//     org.jfree.chart.util.Layer var46 = null;
//     boolean var47 = var22.removeDomainMarker((org.jfree.chart.plot.Marker)var28, var46);
//     org.jfree.chart.util.RectangleEdge var48 = var22.getRangeAxisEdge();
//     var17.add(0.05d, var48);
//     org.jfree.chart.axis.AxisState var50 = null;
//     var10.drawTickMarks(var12, 1.0E-5d, var14, var48, var50);
//     java.util.List var52 = var3.refreshTicks(var6, var7, var8, var48);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     boolean var6 = var2.isDrawBarOutline();
//     int var7 = var2.getRowCount();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var11 = var10.getDomainAxisEdge();
//     org.jfree.chart.axis.ValueAxis var13 = var10.getRangeAxisForDataset(2147483647);
//     java.awt.Font var15 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("", var15, (org.jfree.chart.plot.Plot)var16, false);
//     java.lang.Object var19 = var18.getTextAntiAlias();
//     var18.setBackgroundImageAlignment(2147483647);
//     java.awt.RenderingHints var22 = var18.getRenderingHints();
//     var18.clearSubtitles();
//     java.awt.Paint var24 = var18.getBackgroundPaint();
//     var10.setRangeGridlinePaint(var24);
//     org.jfree.chart.LegendItemCollection var26 = var10.getFixedLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var29 = var2.initialise(var8, var9, var10, 0, var28);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
    var2.setFixedLegendItems(var6);
    int var8 = var2.getRendererCount();
    org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.event.MarkerChangeEvent var11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var10);
    var2.markerChanged(var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var17 = var16.getRangeAxis();
    java.awt.Paint var18 = var16.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16);
    java.awt.Image var20 = var16.getBackgroundImage();
    java.awt.geom.Point2D var21 = var16.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.zoomDomainAxes(0.08d, 0.0d, var15, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var4 = var3.getFont();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("Combined Range XYPlot", var4);
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 100);
    int var9 = var8.getBlue();
    java.awt.Color var10 = var8.darker();
    java.awt.Color var11 = var10.brighter();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var4, (java.awt.Paint)var11);
    float[] var19 = new float[] { 0.0f, 10.0f, 100.0f};
    float[] var20 = java.awt.Color.RGBtoHSB((-1), 0, 10, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var21 = var11.getComponents(var20);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Value", var1, var2);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.add((org.jfree.chart.plot.XYPlot)var6, 100);
    java.awt.Stroke var9 = var0.getDomainCrosshairStroke();
    org.jfree.chart.event.PlotChangeEvent var10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var11 = var10.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    boolean var9 = var0.isRangePannable();
    boolean var10 = var0.isOutlineVisible();
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var12);
    double var14 = var13.getGap();
    var13.setOutlineVisible(true);
    var13.setRangeCrosshairVisible(true);
    java.lang.String var19 = var13.getPlotType();
    var0.remove((org.jfree.chart.plot.XYPlot)var13);
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.Layer var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(2, (org.jfree.chart.plot.Marker)var23, var24, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Combined Range XYPlot"+ "'", var19.equals("Combined Range XYPlot"));

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     java.awt.geom.Point2D var43 = null;
//     var39.zoomRangeAxes(3.0d, 0.025d, var42, var43);
//     java.lang.String var45 = var39.getPlotType();
//     var39.addCornerTextItem("");
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var51 = var50.getRangeAxis();
//     java.awt.Paint var52 = var50.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var50);
//     java.awt.Image var54 = var50.getBackgroundImage();
//     java.awt.geom.Point2D var55 = var50.getQuadrantOrigin();
//     var39.zoomRangeAxes(100.0d, var49, var55, true);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.axis.AxisSpace var4 = var0.getFixedDomainAxisSpace();
    java.awt.Font var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var7, false);
    var9.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var13 = var12.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var9.setPadding(var14);
    double var17 = var14.calculateLeftInset(100.0d);
    var0.setInsets(var14);
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var20 = var19.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.RenderingSource var24 = null;
    var19.select(10.0d, 100.0d, var23, var24);
    var19.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var28 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var29 = new org.jfree.chart.block.BlockContainer();
    var28.add((org.jfree.chart.block.Block)var29);
    org.jfree.chart.block.Arrangement var31 = var28.getArrangement();
    org.jfree.chart.block.BorderArrangement var32 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19, var31, (org.jfree.chart.block.Arrangement)var32);
    java.awt.Paint var34 = var33.getItemPaint();
    var0.setDomainTickBandPaint(var34);
    java.awt.Paint var36 = var0.getDomainCrosshairPaint();
    org.jfree.chart.axis.ValueAxis var37 = var0.getDomainAxis();
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var42 = null;
    org.jfree.chart.urls.XYURLGenerator var43 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var42, var43);
    org.jfree.chart.urls.XYURLGenerator var48 = var44.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var49 = null;
    var44.setBaseURLGenerator(var49, false);
    java.awt.Paint var55 = var44.getItemFillPaint(10, 100, false);
    var40.setLabelPaint(var55);
    float var57 = var40.getAlpha();
    java.awt.Paint var58 = var40.getOutlinePaint();
    org.jfree.chart.util.Layer var59 = null;
    var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var40, var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }
// 
// 
//     java.text.DateFormat var2 = null;
//     java.text.NumberFormat var3 = java.text.NumberFormat.getInstance();
//     java.math.RoundingMode var4 = var3.getRoundingMode();
//     boolean var5 = var3.isGroupingUsed();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("100", var2, var3);
//     org.jfree.chart.urls.XYURLGenerator var7 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(68, (org.jfree.chart.labels.XYToolTipGenerator)var6, var7);
//     boolean var9 = var8.getPlotShapes();
//     boolean var10 = var8.getPlotShapes();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var13 = var12.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.RenderingSource var17 = null;
//     var12.select(10.0d, 100.0d, var16, var17);
//     var12.setOutlineVisible(false);
//     boolean var21 = var12.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var23);
//     double var25 = var24.getGap();
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var27 = var26.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var28 = var26.getLegendItems();
//     var24.setFixedLegendItems(var28);
//     var12.setFixedLegendItems(var28);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.PeriodAxis var33 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.event.AxisChangeEvent var34 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var33);
//     org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var37 = var36.getTickLabelPaint();
//     var36.zoomRange(1.0d, 100.0d);
//     double var41 = var36.getLowerMargin();
//     org.jfree.chart.plot.CombinedRangeXYPlot var42 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var36);
//     org.jfree.chart.labels.XYToolTipGenerator var44 = null;
//     org.jfree.chart.urls.XYURLGenerator var45 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var46 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var44, var45);
//     org.jfree.chart.event.RendererChangeEvent var47 = null;
//     var46.notifyListeners(var47);
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var51 = var50.getDomainMinorGridlineStroke();
//     var50.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.plot.Marker var55 = null;
//     java.awt.geom.Rectangle2D var56 = null;
//     var46.drawDomainMarker(var49, (org.jfree.chart.plot.XYPlot)var50, var54, var55, var56);
//     java.awt.Stroke var59 = var46.getSeriesStroke((-435));
//     org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.renderer.xy.XYItemRenderer)var46);
//     java.awt.geom.Rectangle2D var61 = null;
//     var8.fillDomainGridBand(var11, (org.jfree.chart.plot.XYPlot)var12, (org.jfree.chart.axis.ValueAxis)var36, var61, Double.NaN, (-5.99999d));
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    var6.setDomainCrosshairVisible(false);
    java.awt.Paint var10 = var6.getRangeCrosshairPaint();
    float var11 = var6.getBackgroundImageAlpha();
    var0.add((org.jfree.chart.plot.XYPlot)var6);
    org.jfree.chart.labels.XYToolTipGenerator var14 = null;
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var14, var15);
    org.jfree.chart.urls.XYURLGenerator var20 = var16.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var21 = null;
    var16.setBaseURLGenerator(var21, false);
    java.awt.Paint var27 = var16.getItemFillPaint(10, 100, false);
    int var28 = var0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var16);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var32 = var31.getRangeAxis();
    java.awt.Paint var33 = var31.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31);
    java.awt.Image var35 = var31.getBackgroundImage();
    java.awt.geom.Point2D var36 = var31.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes((-1.0d), var30, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var12 = var11.getMaximumItemCount();
    java.beans.PropertyChangeListener var13 = null;
    var11.removePropertyChangeListener(var13);
    org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var11);
    org.jfree.data.time.TimeSeries var17 = var15.getSeries((java.lang.Comparable)2);
    org.jfree.data.Range var18 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var15);
    var7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var15);
    
    // Checks the contract:  equals-hashcode on var7 and var15
    assertTrue("Contract failed: equals-hashcode on var7 and var15", var7.equals(var15) ? var7.hashCode() == var15.hashCode() : true);
    
    // Checks the contract:  equals-hashcode on var15 and var7
    assertTrue("Contract failed: equals-hashcode on var15 and var7", var15.equals(var7) ? var15.hashCode() == var7.hashCode() : true);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     var2.setRenderer(var3);
//     org.jfree.chart.LegendItemCollection var5 = var2.getLegendItems();
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "TextAnchor.TOP_CENTER");
    java.lang.String var5 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "TextAnchor.TOP_CENTER"+ "'", var5.equals("TextAnchor.TOP_CENTER"));

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
//     org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
//     var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
//     java.awt.Paint var10 = null;
//     var9.setLabelBackgroundPaint(var10);
//     var9.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var15 = null;
//     org.jfree.chart.urls.XYURLGenerator var16 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
//     org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var22 = null;
//     var17.setBaseURLGenerator(var22, false);
//     java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var17.getBaseNegativeItemLabelPosition();
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", 100);
//     int var33 = var32.getBlue();
//     var17.setBaseLegendTextPaint((java.awt.Paint)var32);
//     var9.setLabelOutlinePaint((java.awt.Paint)var32);
//     var1.setTickLabelPaint((java.awt.Paint)var32);
//     java.awt.Font var37 = var1.getLargeFont();
//     org.jfree.data.general.DefaultPieDataset var38 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var41 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var38, (java.lang.Comparable)"hi!", 10.0d);
//     var38.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var45 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var38);
//     java.awt.Paint var46 = null;
//     var45.setLabelBackgroundPaint(var46);
//     var45.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var51 = null;
//     org.jfree.chart.urls.XYURLGenerator var52 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var51, var52);
//     org.jfree.chart.urls.XYURLGenerator var57 = var53.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var58 = null;
//     var53.setBaseURLGenerator(var58, false);
//     java.awt.Paint var64 = var53.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var65 = var53.getBaseNegativeItemLabelPosition();
//     java.awt.Color var68 = java.awt.Color.getColor("hi!", 100);
//     int var69 = var68.getBlue();
//     var53.setBaseLegendTextPaint((java.awt.Paint)var68);
//     var45.setLabelOutlinePaint((java.awt.Paint)var68);
//     var45.setAutoPopulateSectionOutlinePaint(true);
//     var45.setIgnoreZeroValues(true);
//     java.awt.Paint var76 = var45.getBaseSectionOutlinePaint();
//     var1.setTitlePaint(var76);
//     
//     // Checks the contract:  equals-hashcode on var29 and var65
//     assertTrue("Contract failed: equals-hashcode on var29 and var65", var29.equals(var65) ? var29.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var29
//     assertTrue("Contract failed: equals-hashcode on var65 and var29", var65.equals(var29) ? var65.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(10.0d, "hi!", "TextAnchor.TOP_CENTER", true);
    java.text.ParsePosition var6 = null;
    java.lang.Object var7 = var4.parseObject("hi!", var6);
    java.text.NumberFormat var9 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var10 = var9.getRoundingMode();
    boolean var11 = var9.isGroupingUsed();
    org.jfree.chart.axis.NumberTickUnit var13 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var9, 0);
    java.util.Currency var14 = var9.getCurrency();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setCurrency(var14);
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var27 = var26.getTickLabelPaint();
    java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
    java.awt.Paint var29 = var26.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
    org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
    java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
    var26.setMinorTickMarkStroke(var33);
    var26.setRangeAboutValue(0.05d, 1.0E-5d);
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
    org.jfree.chart.renderer.PolarItemRenderer var40 = var39.getRenderer();
    java.awt.Stroke var41 = null;
    var39.setAngleGridlineStroke(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var8 = null;
//     var6.setDrawingSupplier(var8);
//     var3.setPlot((org.jfree.chart.plot.XYPlot)var6);
//     org.jfree.chart.labels.XYToolTipGenerator var14 = var3.getToolTipGenerator(1, 100, false);
//     org.jfree.chart.labels.XYToolTipGenerator var17 = null;
//     org.jfree.chart.urls.XYURLGenerator var18 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var17, var18);
//     org.jfree.chart.urls.XYURLGenerator var23 = var19.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var24 = null;
//     var19.setBaseURLGenerator(var24, false);
//     java.awt.Paint var30 = var19.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var32 = null;
//     var19.setSeriesItemLabelGenerator(70, var32);
//     org.jfree.chart.labels.XYToolTipGenerator var35 = null;
//     org.jfree.chart.urls.XYURLGenerator var36 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var35, var36);
//     org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var42 = null;
//     var37.setBaseURLGenerator(var42, false);
//     java.awt.Paint var48 = var37.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var49 = var37.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var50 = var49.getTextAnchor();
//     var19.setBasePositiveItemLabelPosition(var49, false);
//     var3.setSeriesPositiveItemLabelPosition(0, var49);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var37 and var3.", var37.equals(var3) == var3.equals(var37));
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     java.awt.Paint var15 = var14.getItemPaint();
//     org.jfree.chart.block.BlockContainer var16 = var14.getItemContainer();
//     boolean var17 = var16.isEmpty();
//     var16.setPadding(0.2d, 1.0E-5d, 1.0E-5d, 1.0E-5d);
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var26 = null;
//     org.jfree.chart.urls.XYURLGenerator var27 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var26, var27);
//     org.jfree.chart.urls.XYURLGenerator var32 = var28.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var33 = null;
//     var28.setBaseURLGenerator(var33, false);
//     java.awt.Paint var39 = var28.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var40 = var28.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var42 = null;
//     var28.setSeriesOutlinePaint(0, var42, false);
//     boolean var45 = var28.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var48 = var47.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var49 = var47.getLegendItems();
//     java.awt.Stroke var50 = var47.getDomainCrosshairStroke();
//     var28.setSeriesOutlineStroke(1, var50);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var53 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
//     var28.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var53);
//     java.lang.String var55 = var53.getFormatString();
//     java.lang.Object var56 = var16.draw(var23, var24, (java.lang.Object)var55);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
//     org.jfree.data.xy.XYDataItem var21 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-435), (java.lang.Number)10.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer(var12, (org.jfree.data.general.Dataset)var15, (java.lang.Comparable)(-435));
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var27 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var26);
//     double var28 = var27.getGap();
//     org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var30 = var29.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var31 = var29.getLegendItems();
//     var27.setFixedLegendItems(var31);
//     int var33 = var27.getRendererCount();
//     org.jfree.chart.axis.AxisLocation var34 = var27.getRangeAxisLocation();
//     java.awt.Graphics2D var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.data.xy.XYSeries var40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.lang.Object var41 = var40.clone();
//     var40.add(0.0d, 100.0d, true);
//     java.util.List var46 = var40.getItems();
//     var27.drawDomainTickBands(var35, var36, var46);
//     java.lang.Object var48 = var27.clone();
//     java.lang.Object var49 = var22.draw(var23, var24, (java.lang.Object)var27);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    var2.setOutlineVisible(true);
    org.jfree.chart.LegendItemCollection var6 = var2.getFixedLegendItems();
    org.jfree.chart.axis.ValueAxis var8 = null;
    var2.setRangeAxis(68, var8, true);
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    java.awt.Font var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
    java.lang.Object var17 = var16.getTextAntiAlias();
    var16.setBackgroundImageAlignment(2147483647);
    java.awt.RenderingHints var20 = var16.getRenderingHints();
    var16.clearSubtitles();
    java.awt.Paint var22 = var16.getBackgroundPaint();
    var2.setOutlinePaint(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.axis.AxisSpace var5 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var6 = var5.clone();
//     org.jfree.chart.axis.AxisSpace var7 = new org.jfree.chart.axis.AxisSpace();
//     var7.setTop(10.0d);
//     var5.ensureAtLeast(var7);
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var13 = var12.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var14 = null;
//     var12.setDrawingSupplier(var14);
//     float var16 = var12.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var20 = null;
//     org.jfree.chart.urls.XYURLGenerator var21 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var20, var21);
//     org.jfree.chart.urls.XYURLGenerator var26 = var22.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var27 = null;
//     var22.setBaseURLGenerator(var27, false);
//     java.awt.Paint var33 = var22.getItemFillPaint(10, 100, false);
//     var18.setLabelPaint(var33);
//     float var35 = var18.getAlpha();
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var12.removeDomainMarker((org.jfree.chart.plot.Marker)var18, var36);
//     org.jfree.chart.util.RectangleEdge var38 = var12.getRangeAxisEdge();
//     var7.add(0.05d, var38);
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     org.jfree.chart.axis.AxisState var41 = var0.draw(var1, 1.0E-100d, var3, var4, var38, var40);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    java.awt.Color var2 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     org.jfree.chart.renderer.PolarItemRenderer var40 = var39.getRenderer();
//     org.jfree.chart.event.RendererChangeEvent var41 = null;
//     var39.rendererChanged(var41);
//     java.awt.geom.Rectangle2D var45 = null;
//     java.awt.Point var46 = var39.translateValueThetaRadiusToJava2D(0.025d, 1.0d, var45);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
    var0.clear();
    org.jfree.chart.RenderingSource var2 = var0.getRenderingSource();
    org.jfree.chart.RenderingSource var3 = var0.getRenderingSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.zoomRange(1.0d, 100.0d);
    double var6 = var1.getLowerMargin();
    java.awt.Stroke var7 = var1.getMinorTickMarkStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    var3.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
    var3.setBaseItemLabelGenerator(var10);
    java.awt.Font var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
    var16.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var20 = var19.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
    var16.setPadding(var21);
    org.jfree.chart.event.ChartChangeEventType var23 = null;
    org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var16, var23);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("100");
    boolean var27 = var26.getNotify();
    int var28 = var26.getMaximumLinesToDisplay();
    var16.addSubtitle((org.jfree.chart.title.Title)var26);
    var26.setID("WMAP_Plot");
    java.awt.Paint var32 = var26.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(true);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var2);
    var3.setAutoTickUnitSelection(true);
    org.jfree.data.xy.XYDataItem var8 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
    boolean var9 = var8.isSelected();
    boolean var10 = var3.equals((java.lang.Object)var9);
    var3.setGridBandsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
//     var2.setFixedLegendItems(var6);
//     int var8 = var2.getRendererCount();
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.event.MarkerChangeEvent var11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var10);
//     var2.markerChanged(var11);
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", 100);
//     int var16 = var15.getBlue();
//     java.awt.Color var17 = var15.darker();
//     java.awt.Color var18 = var17.brighter();
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.event.AxisChangeEvent var22 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var21);
//     org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var25 = var24.getTickLabelPaint();
//     var24.zoomRange(1.0d, 100.0d);
//     double var29 = var24.getLowerMargin();
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var24);
//     org.jfree.chart.labels.XYToolTipGenerator var32 = null;
//     org.jfree.chart.urls.XYURLGenerator var33 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var32, var33);
//     org.jfree.chart.event.RendererChangeEvent var35 = null;
//     var34.notifyListeners(var35);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var39 = var38.getDomainMinorGridlineStroke();
//     var38.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.plot.Marker var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     var34.drawDomainMarker(var37, (org.jfree.chart.plot.XYPlot)var38, var42, var43, var44);
//     java.awt.Stroke var47 = var34.getSeriesStroke((-435));
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.xy.XYItemRenderer)var34);
//     boolean var49 = var17.equals((java.lang.Object)var21);
//     org.jfree.chart.plot.CombinedRangeXYPlot var50 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var21);
//     org.jfree.data.Range var52 = null;
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var52);
//     org.jfree.chart.block.RectangleConstraint var54 = var53.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var55 = var54.toUnconstrainedWidth();
//     double var56 = var54.getHeight();
//     org.jfree.chart.text.TextFragment var59 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var60 = var59.getFont();
//     org.jfree.chart.text.TextLine var61 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var60);
//     org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
//     boolean var63 = var61.equals((java.lang.Object)var62);
//     org.jfree.data.Range var66 = new org.jfree.data.Range(0.2d, 0.2d);
//     var62.setRange(var66, true, false);
//     org.jfree.chart.block.RectangleConstraint var70 = var54.toRangeHeight(var66);
//     var21.setDefaultAutoRange(var66);
//     org.jfree.data.Range var72 = var2.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
//     
//     // Checks the contract:  equals-hashcode on var4 and var38
//     assertTrue("Contract failed: equals-hashcode on var4 and var38", var4.equals(var38) ? var4.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var4
//     assertTrue("Contract failed: equals-hashcode on var38 and var4", var38.equals(var4) ? var38.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     java.awt.geom.Point2D var43 = null;
//     var39.zoomRangeAxes(3.0d, 0.025d, var42, var43);
//     java.lang.String var45 = var39.getPlotType();
//     var39.addCornerTextItem("");
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var51 = var50.getRangeAxis();
//     java.awt.Paint var52 = var50.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var50);
//     java.awt.Image var54 = var50.getBackgroundImage();
//     java.awt.geom.Point2D var55 = var50.getQuadrantOrigin();
//     var39.zoomRangeAxes(Double.NaN, var49, var55);
//     
//     // Checks the contract:  equals-hashcode on var30 and var50
//     assertTrue("Contract failed: equals-hashcode on var30 and var50", var30.equals(var50) ? var30.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var30
//     assertTrue("Contract failed: equals-hashcode on var50 and var30", var50.equals(var30) ? var50.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("Category Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxis();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var12 = var11.getRangeAxis();
    java.awt.Paint var13 = var11.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var11);
    java.awt.Image var15 = var11.getBackgroundImage();
    java.awt.geom.Point2D var16 = var11.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(1.0d, 0.0d, var10, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    java.lang.Object var3 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    java.lang.Comparable var3 = var0.getDomainCrosshairRowKey();
    org.jfree.chart.plot.CategoryMarker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var2 = null;
//     org.jfree.chart.urls.XYURLGenerator var3 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var2, var3);
//     org.jfree.chart.event.RendererChangeEvent var5 = null;
//     var4.notifyListeners(var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var9 = var8.getDomainMinorGridlineStroke();
//     var8.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.Marker var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var4.drawDomainMarker(var7, (org.jfree.chart.plot.XYPlot)var8, var12, var13, var14);
//     var4.setAutoPopulateSeriesOutlinePaint(true);
//     var4.setBaseSeriesVisible(true);
//     var4.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     java.awt.Font var26 = var4.getItemLabelFont(70, 10, true);
//     org.jfree.chart.labels.XYToolTipGenerator var28 = null;
//     org.jfree.chart.urls.XYURLGenerator var29 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var28, var29);
//     org.jfree.chart.event.RendererChangeEvent var31 = null;
//     var30.notifyListeners(var31);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var35 = var34.getDomainMinorGridlineStroke();
//     var34.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.plot.Marker var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     var30.drawDomainMarker(var33, (org.jfree.chart.plot.XYPlot)var34, var38, var39, var40);
//     org.jfree.chart.axis.PeriodAxis var43 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var44 = var43.getTickLabelPaint();
//     java.lang.Class var45 = var43.getMajorTickTimePeriodClass();
//     java.awt.Paint var46 = var43.getTickMarkPaint();
//     var34.setRangeGridlinePaint(var46);
//     org.jfree.chart.text.TextBlock var48 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var26, var46);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var30 and var4.", var30.equals(var4) == var4.equals(var30));
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     org.jfree.chart.renderer.PolarItemRenderer var40 = var39.getRenderer();
//     org.jfree.chart.event.RendererChangeEvent var41 = null;
//     var39.rendererChanged(var41);
//     java.awt.geom.Rectangle2D var45 = null;
//     java.awt.Point var46 = var39.translateValueThetaRadiusToJava2D(4.0d, 0.5d, var45);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var2.equals((java.lang.Object)var9);
//     double var12 = var2.getLowerClip();
//     boolean var13 = var2.getAutoPopulateSeriesPaint();
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
//     int var18 = var17.getBlue();
//     var2.setSeriesOutlinePaint(0, (java.awt.Paint)var17, true);
//     java.lang.Boolean var22 = var2.getSeriesItemLabelsVisible(2147483647);
//     int var23 = var2.getColumnCount();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var26 = var25.getDomainAxisEdge();
//     var25.clearRangeMarkers(0);
//     java.awt.Stroke var29 = var25.getDomainCrosshairStroke();
//     java.lang.String[] var33 = org.jfree.data.time.SerialDate.getMonths(true);
//     org.jfree.chart.axis.SymbolAxis var34 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var33);
//     var34.setAutoTickUnitSelection(true);
//     org.jfree.data.xy.XYDataItem var39 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
//     boolean var40 = var39.isSelected();
//     boolean var41 = var34.equals((java.lang.Object)var40);
//     var25.setRangeAxis(3, (org.jfree.chart.axis.ValueAxis)var34);
//     org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var45 = var44.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var46 = var44.getLabelInsets();
//     var44.setMinorTickMarksVisible(false);
//     boolean var49 = var44.isMinorTickMarksVisible();
//     boolean var50 = var44.isMinorTickMarksVisible();
//     java.awt.geom.Rectangle2D var51 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var54 = null;
//     org.jfree.chart.urls.XYURLGenerator var55 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var56 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var54, var55);
//     org.jfree.chart.event.RendererChangeEvent var57 = null;
//     var56.notifyListeners(var57);
//     double var59 = var56.getRangeBase();
//     java.awt.Paint var60 = var56.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var62 = var61.getDomainAxisEdge();
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var66 = null;
//     org.jfree.chart.urls.XYURLGenerator var67 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var68 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var66, var67);
//     org.jfree.chart.urls.XYURLGenerator var72 = var68.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var73 = null;
//     var68.setBaseURLGenerator(var73, false);
//     java.awt.Paint var79 = var68.getItemFillPaint(10, 100, false);
//     var64.setLabelPaint(var79);
//     float var81 = var64.getAlpha();
//     java.awt.Paint var82 = var64.getOutlinePaint();
//     java.awt.Paint var83 = var64.getOutlinePaint();
//     java.awt.Paint var84 = var64.getOutlinePaint();
//     org.jfree.chart.util.Layer var85 = null;
//     var61.addRangeMarker((org.jfree.chart.plot.Marker)var64, var85);
//     org.jfree.data.category.CategoryDataset var87 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var88 = var61.getRendererForDataset(var87);
//     java.awt.Stroke var89 = var61.getRangeZeroBaselineStroke();
//     var2.drawRangeLine(var24, var25, (org.jfree.chart.axis.ValueAxis)var44, var51, (-1.0d), var60, var89);
//     
//     // Checks the contract:  equals-hashcode on var61 and var25
//     assertTrue("Contract failed: equals-hashcode on var61 and var25", var61.equals(var25) ? var61.hashCode() == var25.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var61 and var25.", var61.equals(var25) == var25.equals(var61));
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var6 = var5.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var7 = var5.getLabelInsets();
    var5.setLowerMargin(0.08d);
    java.awt.Shape var10 = var5.getLeftArrow();
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("100", "January", "null", "ERROR : Relative To String", var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(10);
//     java.lang.String var2 = var1.toString();
//     java.util.Calendar var3 = null;
//     var1.peg(var3);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.awt.Font var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedRangeAxisSpace(var9);
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var12 = var11.getOpposite();
    boolean var13 = var3.equals((java.lang.Object)var11);
    boolean var14 = var3.getAllowDuplicateXValues();
    var3.add((java.lang.Number)1.0f, (java.lang.Number)2.0d);
    java.lang.Object var18 = var3.clone();
    double var19 = var3.getMinX();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
//     org.jfree.data.xy.XYDataItem var21 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-435), (java.lang.Number)10.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer(var12, (org.jfree.data.general.Dataset)var15, (java.lang.Comparable)(-435));
//     java.lang.Comparable var23 = var22.getSeriesKey();
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var29 = var28.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.RenderingSource var33 = null;
//     var28.select(10.0d, 100.0d, var32, var33);
//     var28.setOutlineVisible(false);
//     java.awt.Color var39 = java.awt.Color.getColor("hi!", 100);
//     var28.setNoDataMessagePaint((java.awt.Paint)var39);
//     boolean var41 = var27.equals((java.lang.Object)var39);
//     java.lang.Object var42 = var22.draw(var24, var25, (java.lang.Object)var41);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    var3.setMaximumItemCount(70);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var12 = var3.remove(70);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("TextAnchor.TOP_CENTER");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)100);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("rect", "100", "TextAnchor.TOP_CENTER");

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var43 = var42.getRangeAxis();
//     java.awt.Paint var44 = var42.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var42);
//     java.awt.Image var46 = var42.getBackgroundImage();
//     java.awt.geom.Point2D var47 = var42.getQuadrantOrigin();
//     var39.zoomDomainAxes(0.05d, var41, var47, false);
//     
//     // Checks the contract:  equals-hashcode on var30 and var42
//     assertTrue("Contract failed: equals-hashcode on var30 and var42", var30.equals(var42) ? var30.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var30
//     assertTrue("Contract failed: equals-hashcode on var42 and var30", var42.equals(var30) ? var42.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var2.equals((java.lang.Object)var9);
//     double var12 = var2.getLowerClip();
//     boolean var13 = var2.getAutoPopulateSeriesPaint();
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
//     int var18 = var17.getBlue();
//     var2.setSeriesOutlinePaint(0, (java.awt.Paint)var17, true);
//     java.lang.Boolean var22 = var2.getSeriesItemLabelsVisible(2147483647);
//     org.jfree.chart.labels.XYToolTipGenerator var24 = null;
//     org.jfree.chart.urls.XYURLGenerator var25 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var24, var25);
//     org.jfree.chart.urls.XYURLGenerator var30 = var26.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var31 = null;
//     var26.setBaseURLGenerator(var31, false);
//     java.awt.Paint var37 = var26.getItemFillPaint(10, 100, false);
//     org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var40 = var39.getTickLabelPaint();
//     var26.setBasePaint(var40);
//     var2.setBaseOutlinePaint(var40);
//     var2.setBaseCreateEntities(true);
//     double var45 = var2.getYOffset();
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var48 = var47.getDomainAxisEdge();
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var52 = null;
//     org.jfree.chart.urls.XYURLGenerator var53 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var52, var53);
//     org.jfree.chart.urls.XYURLGenerator var58 = var54.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var59 = null;
//     var54.setBaseURLGenerator(var59, false);
//     java.awt.Paint var65 = var54.getItemFillPaint(10, 100, false);
//     var50.setLabelPaint(var65);
//     float var67 = var50.getAlpha();
//     java.awt.Paint var68 = var50.getOutlinePaint();
//     java.awt.Paint var69 = var50.getOutlinePaint();
//     java.awt.Paint var70 = var50.getOutlinePaint();
//     org.jfree.chart.util.Layer var71 = null;
//     var47.addRangeMarker((org.jfree.chart.plot.Marker)var50, var71);
//     org.jfree.data.category.CategoryDataset var73 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var74 = var47.getRendererForDataset(var73);
//     java.awt.geom.Rectangle2D var75 = null;
//     var2.drawBackground(var46, var47, var75);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var2 = var1.getRoundingMode();
    boolean var3 = var1.isGroupingUsed();
    org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, 0);
    java.util.Currency var6 = var1.getCurrency();
    var1.setGroupingUsed(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    var0.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    var0.drawBackgroundImage(var4, var5);
    var0.setDomainCrosshairLockedOnData(true);
    boolean var9 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(100);
    float var12 = var0.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
    var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
    java.awt.Paint var10 = null;
    var9.setLabelBackgroundPaint(var10);
    var9.setInnerSeparatorExtension(0.0d);
    boolean var14 = var9.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var15 = var9.getDataset();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var9, true);
    var17.setBorderVisible(false);
    org.jfree.chart.entity.EntityCollection var22 = null;
    org.jfree.chart.ChartRenderingInfo var23 = new org.jfree.chart.ChartRenderingInfo(var22);
    java.lang.Object var24 = var23.clone();
    var17.handleClick(3, 2, var23);
    java.awt.Font var29 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("", var29, (org.jfree.chart.plot.Plot)var30, false);
    java.lang.Object var33 = var32.getTextAntiAlias();
    var32.setBackgroundImageAlignment(2147483647);
    org.jfree.chart.ChartRenderingInfo var38 = new org.jfree.chart.ChartRenderingInfo();
    var38.clear();
    var32.handleClick(3, 10, var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var41 = var17.createBufferedImage(2, 2147483647, var38);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var1 = var0.getPercentFormat();
    java.text.NumberFormat var2 = var0.getNumberFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.lang.String var2 = var1.getText();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var7 = null;
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var7, var8);
//     org.jfree.chart.urls.XYURLGenerator var13 = var9.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var14 = null;
//     var9.setBaseURLGenerator(var14, false);
//     java.awt.Paint var20 = var9.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var21 = var9.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var22 = var21.getTextAnchor();
//     var1.draw(var3, 10.0f, 100.0f, var22, 10.0f, 0.0f, 1.0E-8d);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var17 = var16.getRangeAxis();
    java.awt.Paint var18 = var16.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16);
    java.awt.Image var20 = var16.getBackgroundImage();
    java.awt.geom.Point2D var21 = var16.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomDomainAxes(90.0d, 0.08d, var15, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    java.text.NumberFormat var5 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var6 = var5.getRoundingMode();
    boolean var7 = var5.isGroupingUsed();
    java.text.NumberFormat var8 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var9 = var8.getRoundingMode();
    var5.setRoundingMode(var9);
    var4.setExponentFormat(var5);
    int var12 = var5.getMinimumFractionDigits();
    org.jfree.chart.event.RendererChangeEvent var14 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var5, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.14d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var3 = var2.getFont();
    org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    boolean var6 = var4.equals((java.lang.Object)var5);
    var5.zoomRange(0.2d, 2.0d);
    org.jfree.chart.axis.DateTickUnit var10 = null;
    var5.setTickUnit(var10, true, true);
    java.util.Date var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setMinimumDate(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var2 = null;
//     org.jfree.chart.urls.XYURLGenerator var3 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var2, var3);
//     org.jfree.chart.urls.XYURLGenerator var8 = var4.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var9 = null;
//     var4.setBaseURLGenerator(var9, false);
//     boolean var12 = var4.getPlotArea();
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var15);
//     double var17 = var16.getGap();
//     var16.setOutlineVisible(true);
//     java.awt.Stroke var20 = var16.getRangeCrosshairStroke();
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var24 = var23.getFont();
//     org.jfree.chart.text.TextLine var25 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var24);
//     var16.setNoDataMessageFont(var24);
//     var4.setSeriesItemLabelFont(10, var24);
//     org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("ERROR : Relative To String", var24);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var33 = null;
//     org.jfree.chart.urls.XYURLGenerator var34 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var33, var34);
//     org.jfree.chart.urls.XYURLGenerator var39 = var35.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var40 = null;
//     var35.setBaseURLGenerator(var40, false);
//     java.awt.Paint var46 = var35.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var47 = var35.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var48 = var47.getTextAnchor();
//     java.lang.String var49 = var48.toString();
//     java.lang.String var50 = var48.toString();
//     var28.draw(var29, 0.0f, 0.0f, var48, 100.0f, 0.0f, 0.08d);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
//     var2.setFixedLegendItems(var6);
//     org.jfree.chart.LegendItemCollection var8 = null;
//     var6.addAll(var8);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    java.text.DateFormat var2 = null;
    java.text.NumberFormat var3 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var4 = var3.getRoundingMode();
    boolean var5 = var3.isGroupingUsed();
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("100", var2, var3);
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(68, (org.jfree.chart.labels.XYToolTipGenerator)var6, var7);
    boolean var9 = var8.getPlotShapes();
    org.jfree.chart.LegendItem var12 = var8.getLegendItem(3, 2147483647);
    boolean var13 = var8.getBaseSeriesVisibleInLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var4 = var3.getFrame();
    org.jfree.chart.util.RectangleInsets var5 = var3.getPadding();
    var1.setLabelInsets(var5);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var5.createOutsetRectangle(var7, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     java.awt.geom.Point2D var42 = null;
//     var39.zoomRangeAxes(0.14d, var41, var42, true);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }
// 
// 
//     org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
//     var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
//     java.awt.Paint var8 = null;
//     var7.setLabelBackgroundPaint(var8);
//     var7.setInnerSeparatorExtension(0.0d);
//     boolean var12 = var7.getAutoPopulateSectionOutlinePaint();
//     org.jfree.data.general.PieDataset var13 = var7.getDataset();
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var15);
//     double var17 = var16.getGap();
//     var16.setOutlineVisible(true);
//     var16.clearRangeMarkers();
//     org.jfree.chart.labels.XYToolTipGenerator var22 = null;
//     org.jfree.chart.urls.XYURLGenerator var23 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var22, var23);
//     org.jfree.chart.event.RendererChangeEvent var25 = null;
//     var24.notifyListeners(var25);
//     var16.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var24);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var28 = var24.getLegendItemLabelGenerator();
//     java.awt.Stroke var29 = var24.getBaseOutlineStroke();
//     var7.setSeparatorStroke(var29);
//     boolean var31 = var7.getAutoPopulateSectionOutlinePaint();
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var35 = var34.getRangeAxis();
//     java.awt.Paint var36 = var34.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var34);
//     java.awt.Image var38 = var34.getBackgroundImage();
//     java.awt.geom.Point2D var39 = var34.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var40 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     var7.draw(var32, var33, var39, var40, var41);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    java.util.TimeZone var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getX(2147483647, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var4 = var3.getFont();
    org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var4);
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var7);
    double var9 = var8.getGap();
    var8.setOutlineVisible(true);
    var8.setRangeCrosshairVisible(true);
    java.lang.String var14 = var8.getPlotType();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("TextAnchor.TOP_CENTER", var4, (org.jfree.chart.plot.Plot)var8, true);
    org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var18 = var17.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.RenderingSource var22 = null;
    var17.select(10.0d, 100.0d, var21, var22);
    var17.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var26 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer();
    var26.add((org.jfree.chart.block.Block)var27);
    org.jfree.chart.block.Arrangement var29 = var26.getArrangement();
    org.jfree.chart.block.BorderArrangement var30 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, var29, (org.jfree.chart.block.Arrangement)var30);
    java.awt.Paint var32 = var31.getItemPaint();
    org.jfree.chart.util.RectangleAnchor var33 = var31.getLegendItemGraphicAnchor();
    java.awt.Paint var34 = var31.getItemPaint();
    org.jfree.chart.util.HorizontalAlignment var35 = var31.getHorizontalAlignment();
    var31.setNotify(false);
    org.jfree.chart.util.VerticalAlignment var38 = var31.getVerticalAlignment();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setTextAntiAlias((java.lang.Object)var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "Combined Range XYPlot"+ "'", var14.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var5 = var4.getStroke();
    double var6 = var4.getValue();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var4);
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var9 = var8.getDomainMinorGridlineStroke();
    var8.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var8.drawBackgroundImage(var12, var13);
    var8.setDomainCrosshairLockedOnData(true);
    var4.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var8);
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var20 = var19.getFrame();
    org.jfree.chart.util.RectangleInsets var21 = var19.getPadding();
    double var22 = var21.getRight();
    var8.setInsets(var21, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.event.AxisChangeEvent var12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var11);
    var7.axisChanged(var12);
    org.jfree.chart.axis.Axis var14 = var12.getAxis();
    java.lang.Object var15 = var12.getSource();
    org.jfree.chart.axis.Axis var16 = var12.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
    var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
    java.awt.Paint var10 = null;
    var9.setLabelBackgroundPaint(var10);
    var9.setInnerSeparatorExtension(0.0d);
    boolean var14 = var9.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var15 = var9.getDataset();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var9, true);
    var17.setBorderVisible(false);
    boolean var20 = var17.isBorderVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var21 = var17.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var4 = var3.getFrame();
    org.jfree.chart.util.RectangleInsets var5 = var3.getPadding();
    var1.setLabelInsets(var5);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var5.createInsetRectangle(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var2.setFixedRangeAxisSpace(var5);
//     org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var2.handleClick(2147483647, 255, var10);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    var0.setDomainCrosshairVisible(false);
    java.awt.Paint var4 = var0.getRangeCrosshairPaint();
    float var5 = var0.getBackgroundImageAlpha();
    var0.setGap(0.0d);
    var0.setOutlineVisible(false);
    java.awt.Paint var10 = var0.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    var0.setDomainCrosshairVisible(false);
    java.awt.Paint var4 = var0.getRangeCrosshairPaint();
    float var5 = var0.getBackgroundImageAlpha();
    var0.setGap(0.0d);
    var0.setOutlineVisible(false);
    org.jfree.chart.StandardChartTheme var12 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var13 = var12.getTitlePaint();
    java.awt.Paint var14 = var12.getLegendBackgroundPaint();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
    int var18 = var17.getBlue();
    java.awt.Color var19 = var17.darker();
    var12.setWallPaint((java.awt.Paint)var19);
    int var21 = var19.getTransparency();
    var0.setQuadrantPaint(0, (java.awt.Paint)var19);
    java.awt.Color var25 = java.awt.Color.getColor("hi!", 100);
    java.awt.color.ColorSpace var26 = var25.getColorSpace();
    float[] var36 = new float[] { 0.0f, 10.0f, 100.0f};
    float[] var37 = java.awt.Color.RGBtoHSB((-1), 0, 10, var36);
    float[] var38 = java.awt.Color.RGBtoHSB(1, 3, (-435), var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var39 = var19.getComponents(var26, var38);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
    int var18 = var17.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var23 = var22.getSize();
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity(var16, (org.jfree.data.general.PieDataset)var17, 100, (-1), (java.lang.Comparable)var22, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var26.setSectionKey((java.lang.Comparable)(byte)(-1));
    org.jfree.data.general.DefaultPieDataset var29 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var32 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var29, (java.lang.Comparable)"hi!", 10.0d);
    var29.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var29);
    java.awt.Paint var37 = null;
    var36.setLabelBackgroundPaint(var37);
    var36.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var42 = null;
    org.jfree.chart.urls.XYURLGenerator var43 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var42, var43);
    org.jfree.chart.urls.XYURLGenerator var48 = var44.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var49 = null;
    var44.setBaseURLGenerator(var49, false);
    java.awt.Paint var55 = var44.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var56 = var44.getBaseNegativeItemLabelPosition();
    java.awt.Color var59 = java.awt.Color.getColor("hi!", 100);
    int var60 = var59.getBlue();
    var44.setBaseLegendTextPaint((java.awt.Paint)var59);
    var36.setLabelOutlinePaint((java.awt.Paint)var59);
    org.jfree.chart.labels.PieSectionLabelGenerator var63 = var36.getLabelGenerator();
    java.awt.Shape var64 = var36.getLegendItemShape();
    java.awt.Shape var65 = null;
    boolean var66 = org.jfree.chart.util.ShapeUtilities.equal(var64, var65);
    var26.setArea(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getUpperMargin();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var6);
//     double var8 = var7.getGap();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getDomainAxisEdge(0);
//     double var11 = var0.getCategoryStart((-435), 1, var4, var10);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.util.TableOrder var2 = var1.getDataExtractOrder();
//     org.jfree.chart.JFreeChart var3 = var1.getPieChart();
//     org.jfree.data.category.CategoryDataset var4 = var1.getDataset();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var7.getRangeAxis();
//     java.awt.Paint var9 = var7.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7);
//     java.awt.Image var11 = var7.getBackgroundImage();
//     java.awt.geom.Point2D var12 = var7.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var13 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     var1.draw(var5, var6, var12, var13, var14);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var1 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    java.lang.Comparable var3 = var0.getDomainCrosshairRowKey();
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 100);
    int var7 = var6.getBlue();
    java.awt.Color var8 = var6.darker();
    java.awt.Color var9 = var8.brighter();
    var0.setRangeZeroBaselinePaint((java.awt.Paint)var8);
    java.io.ObjectOutputStream var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint)var8, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesShape(true);
    var0.setDrawOutlines(false);
    var0.setSeriesShapesFilled(0, false);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var2.equals((java.lang.Object)var9);
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var13 = var12.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var14 = null;
//     var12.setDrawingSupplier(var14);
//     float var16 = var12.getForegroundAlpha();
//     boolean var17 = var2.equals((java.lang.Object)var12);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.setAnchorValue(Double.NaN);
//     java.lang.Comparable var22 = var19.getDomainCrosshairRowKey();
//     java.awt.geom.Rectangle2D var23 = null;
//     var2.drawOutline(var18, var19, var23);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    var9.add((org.jfree.chart.block.Block)var10);
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
    java.awt.Paint var15 = var14.getItemPaint();
    org.jfree.chart.util.RectangleAnchor var16 = var14.getLegendItemGraphicAnchor();
    org.jfree.chart.util.RectangleInsets var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setItemLabelPadding(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("100");
    org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var4 = var3.getTickLabelPaint();
    var3.zoomRange(1.0d, 100.0d);
    double var8 = var3.getLowerMargin();
    org.jfree.chart.plot.CombinedRangeXYPlot var9 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var3);
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var11 = var10.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.RenderingSource var15 = null;
    var10.select(10.0d, 100.0d, var14, var15);
    var10.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var20 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var21 = var20.getTickLabelPaint();
    var10.setOutlinePaint(var21);
    var3.setMinorTickMarkPaint(var21);
    var1.setPaint(var21);
    org.jfree.chart.util.RectangleAnchor var25 = var1.getTextAnchor();
    org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var28 = var27.getFont();
    var1.setFont(var28);
    java.awt.Font var30 = var1.getFont();
    var1.setToolTipText("TextAnchor.TOP_CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var2.setFixedRangeAxisSpace(var5);
    org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
    boolean var8 = var2.isDomainPannable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    org.jfree.chart.util.Rotation var10 = var7.getDirection();
    boolean var11 = var7.getLabelLinksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(true);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var2);
    var3.setAutoTickUnitSelection(true);
    org.jfree.data.xy.XYDataItem var8 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
    boolean var9 = var8.isSelected();
    boolean var10 = var3.equals((java.lang.Object)var9);
    double var11 = var3.getLowerMargin();
    java.awt.Paint var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setGridBandPaint(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var7.getStartY(100, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
//     java.awt.Paint var4 = var1.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var6 = var5.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var7 = var5.getLegendItems();
//     java.awt.Stroke var8 = var5.getDomainCrosshairStroke();
//     var1.setMinorTickMarkStroke(var8);
//     boolean var10 = var1.isInverted();
//     org.jfree.chart.renderer.xy.XYStepRenderer var11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var11.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var11.setBaseLinesVisible(true);
//     boolean var19 = var11.getItemShapeFilled(0, 1);
//     java.awt.Shape var21 = var11.lookupSeriesShape((-1));
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 3.0d, 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var27 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var24, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "AxisLocation.TOP_OR_RIGHT");
//     org.jfree.chart.axis.Axis var28 = var27.getAxis();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var29 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var30 = null;
//     java.lang.String var31 = var27.getImageMapAreaTag(var29, var30);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.awt.Font var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedRangeAxisSpace(var9);
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var12 = var11.getOpposite();
    boolean var13 = var3.equals((java.lang.Object)var11);
    boolean var14 = var3.getAllowDuplicateXValues();
    var3.add((java.lang.Number)1.0f, (java.lang.Number)2.0d);
    var3.setMaximumItemCount(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.setValue((java.lang.Comparable)0.2d, (java.lang.Number)(byte)0);
    org.jfree.chart.util.SortOrder var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByKeys(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.arrange(var1);
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var3.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }
// 
// 
//     boolean var0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == false);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var3 = null;
    org.jfree.chart.urls.XYURLGenerator var4 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var3, var4);
    org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    java.awt.Paint var16 = var5.getItemFillPaint(10, 100, false);
    var1.setLabelPaint(var16);
    float var18 = var1.getAlpha();
    java.awt.Paint var19 = var1.getOutlinePaint();
    java.awt.Paint var20 = var1.getOutlinePaint();
    java.awt.Paint var21 = var1.getOutlinePaint();
    org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var24 = var23.getTickLabelPaint();
    java.lang.Class var25 = var23.getMajorTickTimePeriodClass();
    java.lang.Class var26 = org.jfree.data.time.RegularTimePeriod.downsize(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.EventListener[] var27 = var1.getListeners(var26);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     int var2 = var1.getMaximumCategoryLabelLines();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var12.setCategoryLabelPositionOffset(2147483647);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var19 = var18.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var20 = null;
//     var18.setDrawingSupplier(var20);
//     float var22 = var18.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var26 = null;
//     org.jfree.chart.urls.XYURLGenerator var27 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var26, var27);
//     org.jfree.chart.urls.XYURLGenerator var32 = var28.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var33 = null;
//     var28.setBaseURLGenerator(var33, false);
//     java.awt.Paint var39 = var28.getItemFillPaint(10, 100, false);
//     var24.setLabelPaint(var39);
//     float var41 = var24.getAlpha();
//     org.jfree.chart.util.Layer var42 = null;
//     boolean var43 = var18.removeDomainMarker((org.jfree.chart.plot.Marker)var24, var42);
//     org.jfree.chart.util.RectangleEdge var44 = var18.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisState var45 = null;
//     var12.drawTickMarks(var15, 10.0d, var17, var44, var45);
//     org.jfree.chart.axis.AxisState var47 = null;
//     var7.drawTickMarks(var8, 1.0d, var10, var44, var47);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     org.jfree.chart.axis.AxisState var50 = var1.draw(var3, 0.05d, var5, var6, var44, var49);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.util.List var4 = var3.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var3.getY(70);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
    java.awt.Paint var17 = null;
    var3.setSeriesOutlinePaint(0, var17, false);
    java.awt.Paint var21 = var3.getLegendTextPaint((-1));
    double var22 = var3.getRangeBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     org.jfree.chart.labels.XYToolTipGenerator var9 = null;
//     org.jfree.chart.urls.XYURLGenerator var10 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var9, var10);
//     org.jfree.chart.urls.XYURLGenerator var15 = var11.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var16 = null;
//     var11.setBaseURLGenerator(var16, false);
//     java.awt.Paint var22 = var11.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var24 = null;
//     var11.setSeriesItemLabelGenerator(70, var24);
//     org.jfree.data.xy.DefaultXYDataset var26 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var28 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var29 = var28.getSize();
//     int var30 = var26.indexOf((java.lang.Comparable)var29);
//     org.jfree.data.Range var31 = var11.findRangeBounds((org.jfree.data.xy.XYDataset)var26);
//     org.jfree.data.DomainOrder var32 = var26.getDomainOrder();
//     var0.setDataset(1, (org.jfree.data.xy.XYDataset)var26);
//     java.awt.Font var35 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("", var35, (org.jfree.chart.plot.Plot)var36, false);
//     org.jfree.chart.axis.AxisSpace var39 = null;
//     var36.setFixedRangeAxisSpace(var39);
//     org.jfree.chart.axis.AxisLocation var41 = var36.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var42 = org.jfree.chart.axis.AxisLocation.getOpposite(var41);
//     org.jfree.chart.plot.CombinedDomainXYPlot var43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var44 = var43.getDomainMinorGridlineStroke();
//     var43.setDomainCrosshairVisible(false);
//     java.awt.Paint var47 = var43.getRangeCrosshairPaint();
//     float var48 = var43.getBackgroundImageAlpha();
//     var43.setGap(0.0d);
//     var43.clearDomainAxes();
//     org.jfree.chart.plot.PlotOrientation var52 = var43.getOrientation();
//     org.jfree.chart.util.RectangleEdge var53 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var41, var52);
//     var0.setOrientation(var52);
//     
//     // Checks the contract:  equals-hashcode on var0 and var36
//     assertTrue("Contract failed: equals-hashcode on var0 and var36", var0.equals(var36) ? var0.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var0
//     assertTrue("Contract failed: equals-hashcode on var36 and var0", var36.equals(var0) ? var36.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-5.99999d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound(var0, 10, (-1.0d), 90.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
    org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxisForDataset(2147483647);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.AxisSpace var5 = null;
    var4.setFixedDomainAxisSpace(var5, true);
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.util.List var10 = null;
    var4.drawRangeTickBands(var8, var9, var10);
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var15 = null;
    var13.setDrawingSupplier(var15);
    float var17 = var13.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var21 = null;
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
    org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var28 = null;
    var23.setBaseURLGenerator(var28, false);
    java.awt.Paint var34 = var23.getItemFillPaint(10, 100, false);
    var19.setLabelPaint(var34);
    float var36 = var19.getAlpha();
    org.jfree.chart.util.Layer var37 = null;
    boolean var38 = var13.removeDomainMarker((org.jfree.chart.plot.Marker)var19, var37);
    org.jfree.chart.util.Layer var39 = null;
    boolean var40 = var4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker)var19, var39);
    boolean var41 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var19);
    org.jfree.chart.axis.PeriodAxis var43 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var44 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var43);
    double var45 = var44.getGap();
    var44.setOutlineVisible(true);
    java.awt.Stroke var48 = var44.getRangeCrosshairStroke();
    java.awt.Stroke var49 = var44.getDomainGridlineStroke();
    var19.setOutlineStroke(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.setValue((java.lang.Comparable)0.2d, (java.lang.Number)(byte)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)(short)100);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    var2.setTop(10.0d);
    var0.ensureAtLeast(var2);
    var2.setRight(0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    org.jfree.chart.util.Rotation var10 = var7.getDirection();
    java.awt.Paint var11 = var7.getLabelLinkPaint();
    java.awt.Paint var12 = var7.getBaseSectionPaint();
    int var13 = var7.getPieIndex();
    double var14 = var7.getInnerSeparatorExtension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    java.lang.Comparable var3 = var0.getDomainCrosshairRowKey();
    var0.clearDomainMarkers();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 100);
    int var8 = var7.getBlue();
    java.awt.Color var9 = var7.darker();
    int var10 = var9.getBlue();
    var0.setRangeCrosshairPaint((java.awt.Paint)var9);
    java.lang.String var12 = var0.getPlotType();
    java.util.List var13 = var0.getAnnotations();
    org.jfree.chart.annotations.CategoryAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Category Plot"+ "'", var12.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     java.awt.Stroke var40 = var39.getRadiusGridlineStroke();
//     org.jfree.chart.LegendItemCollection var41 = var39.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var32 and var41
//     assertTrue("Contract failed: equals-hashcode on var32 and var41", var32.equals(var41) ? var32.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var32
//     assertTrue("Contract failed: equals-hashcode on var41 and var32", var41.equals(var32) ? var41.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var4.setSeriesURLGenerator(10, var6);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var4.setSeriesURLGenerator(3, var9, true);
    int var12 = var4.getPassCount();
    org.jfree.chart.renderer.category.BarPainter var13 = var4.getBarPainter();
    var4.setBaseSeriesVisible(true, true);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var4);
    org.jfree.data.general.DatasetGroup var20 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.event.AxisChangeEvent var24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var23);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var27 = var26.getTickLabelPaint();
    var26.zoomRange(1.0d, 100.0d);
    double var31 = var26.getLowerMargin();
    org.jfree.chart.plot.CombinedRangeXYPlot var32 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var26);
    org.jfree.chart.labels.XYToolTipGenerator var34 = null;
    org.jfree.chart.urls.XYURLGenerator var35 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var34, var35);
    org.jfree.chart.event.RendererChangeEvent var37 = null;
    var36.notifyListeners(var37);
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var41 = var40.getDomainMinorGridlineStroke();
    var40.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.plot.Marker var45 = null;
    java.awt.geom.Rectangle2D var46 = null;
    var36.drawDomainMarker(var39, (org.jfree.chart.plot.XYPlot)var40, var44, var45, var46);
    java.awt.Stroke var49 = var36.getSeriesStroke((-435));
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.renderer.xy.XYItemRenderer)var36);
    java.awt.Stroke var52 = var36.getSeriesOutlineStroke(255);
    boolean var53 = var20.equals((java.lang.Object)var36);
    org.jfree.chart.axis.PeriodAxis var56 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var57 = var56.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var58 = var56.getLabelInsets();
    var56.setAxisLineVisible(false);
    var56.setMinorTickMarkInsideLength((-1.0f));
    org.jfree.chart.plot.CombinedDomainXYPlot var63 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var56);
    java.awt.Shape var64 = var56.getDownArrow();
    var36.setLegendShape(0, var64);
    org.jfree.chart.labels.ItemLabelPosition var67 = var36.getSeriesPositiveItemLabelPosition(70);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSeriesPositiveItemLabelPosition(2147483647, var67);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.RenderingSource var18 = null;
    var13.select(10.0d, 100.0d, var17, var18);
    var13.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var23 = null;
    org.jfree.chart.urls.XYURLGenerator var24 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var23, var24);
    org.jfree.chart.urls.XYURLGenerator var29 = var25.getURLGenerator(0, 1, true);
    var25.setBaseSeriesVisibleInLegend(false);
    int var32 = var13.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var25);
    org.jfree.chart.plot.CombinedDomainXYPlot var34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var35 = var34.getRangeAxis();
    java.awt.Paint var36 = var34.getDomainGridlinePaint();
    var25.setSeriesFillPaint(0, var36);
    org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var39);
    double var41 = var40.getGap();
    var40.setOutlineVisible(true);
    java.awt.Stroke var44 = var40.getRangeCrosshairStroke();
    org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d, var36, var44);
    var7.setSeparatorPaint(var36);
    double var47 = var7.getMinimumArcAngleToDraw();
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    var48.setAnchorValue(Double.NaN);
    java.lang.Comparable var51 = var48.getDomainCrosshairRowKey();
    var48.clearDomainMarkers();
    java.awt.Color var55 = java.awt.Color.getColor("hi!", 100);
    int var56 = var55.getBlue();
    java.awt.Color var57 = var55.darker();
    int var58 = var57.getBlue();
    var48.setRangeCrosshairPaint((java.awt.Paint)var57);
    var7.setLabelOutlinePaint((java.awt.Paint)var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 70);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.setValue((java.lang.Comparable)0.2d, (java.lang.Number)(byte)0);
    int var5 = var0.getIndex((java.lang.Comparable)644288400000L);
    java.text.NumberFormat var7 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var8 = var7.getRoundingMode();
    boolean var9 = var7.isGroupingUsed();
    org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var7, 0);
    var0.addValue((java.lang.Comparable)(-1.0d), 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var15 = var0.getValue((java.lang.Comparable)1.0E-100d);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var5.getRangeAxis();
    org.jfree.chart.LegendItemCollection var7 = var5.getLegendItems();
    java.awt.Stroke var8 = var5.getDomainCrosshairStroke();
    var1.setMinorTickMarkStroke(var8);
    var1.setTickLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    var2.setOutlineVisible(true);
    var2.clearRangeMarkers();
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var10 = var9.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var11 = var9.getLabelInsets();
    var9.setAxisLineVisible(false);
    var9.setMinorTickMarkInsideLength((-1.0f));
    java.lang.Object var16 = var9.clone();
    double var17 = var9.getUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setRangeAxis((-435), (org.jfree.chart.axis.ValueAxis)var9, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.setTickMarkInsideLength(0.8f);
    var1.setLabelURL("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var4 = var3.getRangeDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var6 = var3.getDataItem(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + ""+ "'", var4.equals(""));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "WMAP_Plot", "WMAP_Plot", "TextAnchor.TOP_CENTER", "DatasetRenderingOrder.REVERSE");
    var5.setLicenceName("Polar Plot");

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var11 = var10.getRangeDescription();
    org.jfree.data.time.TimeSeries var12 = var3.addAndOrUpdate(var10);
    java.lang.String var13 = var10.getDescription();
    java.lang.String var14 = var10.getRangeDescription();
    var10.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + ""+ "'", var14.equals(""));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var2 = var1.getTitlePaint();
    java.awt.Paint var3 = var1.getLegendBackgroundPaint();
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 100);
    int var7 = var6.getBlue();
    java.awt.Color var8 = var6.darker();
    var1.setWallPaint((java.awt.Paint)var8);
    java.awt.Paint var10 = var1.getLabelLinkPaint();
    java.lang.String var11 = var1.getName();
    java.awt.Font var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLargeFont(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var11.equals("AxisLocation.TOP_OR_RIGHT"));

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    java.lang.String[] var9 = org.jfree.data.time.SerialDate.getMonths(true);
    org.jfree.chart.axis.SymbolAxis var10 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var9);
    var10.setAutoTickUnitSelection(true);
    org.jfree.data.xy.XYDataItem var15 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
    boolean var16 = var15.isSelected();
    boolean var17 = var10.equals((java.lang.Object)var16);
    double var18 = var10.getLowerMargin();
    org.jfree.chart.util.LogFormat var23 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    java.text.NumberFormat var24 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var25 = var24.getRoundingMode();
    boolean var26 = var24.isGroupingUsed();
    java.text.NumberFormat var27 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var28 = var27.getRoundingMode();
    var24.setRoundingMode(var28);
    var23.setExponentFormat(var24);
    var10.setNumberFormatOverride(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var10, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var4 = null;
    org.jfree.chart.urls.XYURLGenerator var5 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var4, var5);
    org.jfree.chart.urls.XYURLGenerator var10 = var6.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var11 = null;
    var6.setBaseURLGenerator(var11, false);
    java.awt.Paint var17 = var6.getItemFillPaint(10, 100, false);
    var2.setLabelPaint(var17);
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var20 = var19.getDomainMinorGridlineStroke();
    var2.setStroke(var20);
    org.jfree.data.general.DefaultPieDataset var22 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var25 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var22, (java.lang.Comparable)"hi!", 10.0d);
    var22.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var22);
    java.awt.Paint var30 = null;
    var29.setLabelBackgroundPaint(var30);
    var29.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var35 = null;
    org.jfree.chart.urls.XYURLGenerator var36 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var35, var36);
    org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var42 = null;
    var37.setBaseURLGenerator(var42, false);
    java.awt.Paint var48 = var37.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var49 = var37.getBaseNegativeItemLabelPosition();
    java.awt.Color var52 = java.awt.Color.getColor("hi!", 100);
    int var53 = var52.getBlue();
    var37.setBaseLegendTextPaint((java.awt.Paint)var52);
    var29.setLabelOutlinePaint((java.awt.Paint)var52);
    var29.setAutoPopulateSectionOutlinePaint(true);
    var29.setIgnoreZeroValues(true);
    org.jfree.chart.plot.AbstractPieLabelDistributor var60 = var29.getLabelDistributor();
    org.jfree.chart.plot.CombinedDomainXYPlot var61 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var62 = var61.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var65 = null;
    org.jfree.chart.RenderingSource var66 = null;
    var61.select(10.0d, 100.0d, var65, var66);
    var61.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var71 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var72 = var71.getTickLabelPaint();
    var61.setOutlinePaint(var72);
    var29.setBaseSectionOutlinePaint(var72);
    var2.setPaint(var72);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var76 = new org.jfree.chart.title.LegendGraphic(var0, var72);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var8 = null;
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
    org.jfree.chart.urls.XYURLGenerator var14 = var10.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    var10.setBaseURLGenerator(var15, false);
    java.awt.Paint var21 = var10.getItemFillPaint(10, 100, false);
    var6.setLabelPaint(var21);
    float var23 = var6.getAlpha();
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var6, var24);
    org.jfree.chart.text.TextAnchor var26 = var6.getLabelTextAnchor();
    var6.setAlpha(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    float var2 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var4 = var3.getBackgroundPaint();
    org.jfree.chart.event.ChartProgressListener var5 = null;
    var3.addProgressListener(var5);
    java.awt.Image var7 = var3.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    float[] var5 = new float[] { 1.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(1, 100, 3, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue(70, (java.lang.Comparable)"Jan", (java.lang.Number)(short)(-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    boolean var13 = var2.getAutoPopulateSeriesPaint();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
    int var18 = var17.getBlue();
    var2.setSeriesOutlinePaint(0, (java.awt.Paint)var17, true);
    java.lang.Boolean var22 = var2.getSeriesItemLabelsVisible(2147483647);
    org.jfree.chart.urls.CategoryURLGenerator var23 = var2.getBaseURLGenerator();
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = var2.getBaseToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var9);
    double var12 = var9.getDomainUpperBound(true);
    org.jfree.data.xy.IntervalXYDelegate var14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var9, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var17 = var14.getStartX(100, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.data.general.DefaultPieDataset var3 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var3, (java.lang.Comparable)"hi!", 10.0d);
    var3.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var3);
    java.awt.Paint var11 = null;
    var10.setLabelBackgroundPaint(var11);
    org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.event.AxisChangeEvent var15 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var14);
    var10.axisChanged(var15);
    boolean var17 = var0.equals((java.lang.Object)var15);
    org.jfree.chart.axis.Axis var18 = var15.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }
// 
// 
//     org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
//     var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
//     java.awt.Paint var8 = null;
//     var7.setLabelBackgroundPaint(var8);
//     org.jfree.chart.util.Rotation var10 = var7.getDirection();
//     java.awt.Paint var11 = var7.getLabelLinkPaint();
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var7.drawOutline(var12, var13);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    org.jfree.chart.plot.CrosshairState var0 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var7 = null;
    var0.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var7);
    double var9 = var0.getCrosshairY();
    var0.setCrosshairX(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var5.setSeriesURLGenerator(10, var7);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var5.setSeriesURLGenerator(3, var10, true);
    boolean var13 = var0.equals((java.lang.Object)var5);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.data.Range var15 = var5.findRangeBounds(var14);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var5.setBaseURLGenerator(var16, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
//     java.awt.Paint var4 = var1.getTickMarkPaint();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.general.DefaultPieDataset var6 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var6, (java.lang.Comparable)"hi!", 10.0d);
//     var6.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var6);
//     java.awt.Paint var14 = null;
//     var13.setLabelBackgroundPaint(var14);
//     var13.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var19 = null;
//     org.jfree.chart.urls.XYURLGenerator var20 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var19, var20);
//     org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var26 = null;
//     var21.setBaseURLGenerator(var26, false);
//     java.awt.Paint var32 = var21.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var33 = var21.getBaseNegativeItemLabelPosition();
//     java.awt.Color var36 = java.awt.Color.getColor("hi!", 100);
//     int var37 = var36.getBlue();
//     var21.setBaseLegendTextPaint((java.awt.Paint)var36);
//     var13.setLabelOutlinePaint((java.awt.Paint)var36);
//     var13.setAutoPopulateSectionOutlinePaint(true);
//     java.awt.Paint var42 = var13.getLabelBackgroundPaint();
//     org.jfree.chart.urls.PieURLGenerator var43 = var13.getLegendLabelURLGenerator();
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     org.jfree.chart.axis.AxisSpace var46 = new org.jfree.chart.axis.AxisSpace();
//     var46.setBottom(2.0d);
//     org.jfree.chart.axis.AxisSpace var49 = var1.reserveSpace(var5, (org.jfree.chart.plot.Plot)var13, var44, var45, var46);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var2 = var1.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var3 = null;
//     var1.setDrawingSupplier(var3);
//     float var5 = var1.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var9 = null;
//     org.jfree.chart.urls.XYURLGenerator var10 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var9, var10);
//     org.jfree.chart.urls.XYURLGenerator var15 = var11.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var16 = null;
//     var11.setBaseURLGenerator(var16, false);
//     java.awt.Paint var22 = var11.getItemFillPaint(10, 100, false);
//     var7.setLabelPaint(var22);
//     float var24 = var7.getAlpha();
//     org.jfree.chart.util.Layer var25 = null;
//     boolean var26 = var1.removeDomainMarker((org.jfree.chart.plot.Marker)var7, var25);
//     org.jfree.chart.util.RectangleEdge var27 = var1.getRangeAxisEdge();
//     double var28 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var27);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
    var2.setFixedLegendItems(var6);
    int var8 = var2.getRendererCount();
    org.jfree.chart.axis.AxisLocation var9 = var2.getRangeAxisLocation();
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.xy.XYSeries var15 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var16 = var15.clone();
    var15.add(0.0d, 100.0d, true);
    java.util.List var21 = var15.getItems();
    var2.drawDomainTickBands(var10, var11, var21);
    java.lang.Object var23 = var2.clone();
    var2.setBackgroundImageAlignment(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var3, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "100", "hi!");
    org.jfree.chart.ui.Library[] var8 = var7.getOptionalLibraries();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "100", "hi!");
    java.util.List var17 = var16.getContributors();
    var7.addLibrary((org.jfree.chart.ui.Library)var16);
    var7.addOptionalLibrary("TextAnchor.TOP_CENTER");
    var7.setInfo("PieSection: 100, -1(-1)");
    var7.setLicenceName("10");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    var0.add((org.jfree.chart.block.Block)var1);
    boolean var3 = var0.isEmpty();
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement();
    var0.setArrangement((org.jfree.chart.block.Arrangement)var4);
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("100");
    boolean var8 = var7.getNotify();
    int var9 = var7.getMaximumLinesToDisplay();
    java.lang.String var10 = var7.getToolTipText();
    org.jfree.chart.util.RectangleInsets var11 = var7.getPadding();
    java.awt.Font var13 = null;
    org.jfree.data.general.DefaultPieDataset var14 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var14, (java.lang.Comparable)"hi!", 10.0d);
    var14.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var14);
    java.awt.Paint var22 = null;
    var21.setLabelBackgroundPaint(var22);
    var21.setInnerSeparatorExtension(0.0d);
    boolean var26 = var21.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var27 = var21.getDataset();
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var21, true);
    var29.setBorderVisible(false);
    org.jfree.chart.title.LegendTitle var32 = var29.getLegend();
    org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d);
    var32.setFrame((org.jfree.chart.block.BlockFrame)var37);
    var4.add((org.jfree.chart.block.Block)var7, (java.lang.Object)var37);
    org.jfree.chart.axis.PeriodAxis var41 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var42 = var41.getTickLabelPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var44 = var43.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var45 = null;
    var43.setDrawingSupplier(var45);
    var41.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var43);
    org.jfree.chart.axis.AxisLocation var48 = var43.getRangeAxisLocation();
    boolean var49 = var37.equals((java.lang.Object)var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var2 = var0.getSegment((-1L));
//     org.jfree.chart.axis.SegmentedTimeline var3 = var0.getBaseTimeline();
//     org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var7 = var6.getFont();
//     org.jfree.chart.text.TextLine var8 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var7);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     boolean var10 = var8.equals((java.lang.Object)var9);
//     var9.zoomRange(0.2d, 2.0d);
//     org.jfree.chart.axis.DateTickUnit var14 = null;
//     var9.setTickUnit(var14, true, true);
//     org.jfree.chart.axis.SegmentedTimeline var18 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var20 = var19.getMinimumDate();
//     boolean var21 = var18.containsDomainValue(var20);
//     var9.setMaximumDate(var20);
//     org.jfree.chart.axis.SegmentedTimeline var23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var25 = var23.getSegment((-1L));
//     org.jfree.chart.axis.SegmentedTimeline var26 = var23.getBaseTimeline();
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var28 = var27.getMinimumDate();
//     long var29 = var23.toTimelineValue(var28);
//     boolean var30 = var3.containsDomainRange(var20, var28);
//     
//     // Checks the contract:  equals-hashcode on var2 and var25
//     assertTrue("Contract failed: equals-hashcode on var2 and var25", var2.equals(var25) ? var2.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var2
//     assertTrue("Contract failed: equals-hashcode on var25 and var2", var25.equals(var2) ? var25.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    boolean var9 = var0.isRangePannable();
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var12 = var11.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.RenderingSource var16 = null;
    var11.select(10.0d, 100.0d, var15, var16);
    var11.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    var11.setOutlinePaint(var22);
    boolean var24 = var11.isDomainZeroBaselineVisible();
    java.awt.Font var26 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("", var26, (org.jfree.chart.plot.Plot)var27, false);
    org.jfree.chart.axis.AxisSpace var30 = null;
    var27.setFixedRangeAxisSpace(var30);
    org.jfree.chart.axis.AxisLocation var32 = var27.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var33 = var32.getOpposite();
    var11.setDomainAxisLocation(var33, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(2147483647, var33);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setSeriesURLGenerator(3, var7, true);
    int var10 = var2.getPassCount();
    java.awt.Shape var12 = var2.lookupSeriesShape(2);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 4.0d, 0.8f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     var0.setDomainCrosshairVisible(false);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var0.drawBackgroundImage(var4, var5);
//     var0.setDomainCrosshairLockedOnData(true);
//     boolean var9 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation(100);
//     org.jfree.data.general.DefaultPieDataset var14 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var14, (java.lang.Comparable)"hi!", 10.0d);
//     var14.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var14);
//     java.awt.Paint var22 = null;
//     var21.setLabelBackgroundPaint(var22);
//     org.jfree.chart.util.Rotation var24 = var21.getDirection();
//     java.awt.Paint var25 = var21.getLabelLinkPaint();
//     java.awt.Paint var26 = var21.getBaseSectionPaint();
//     org.jfree.data.general.DefaultPieDataset var27 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var30 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var27, (java.lang.Comparable)"hi!", 10.0d);
//     var27.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var27);
//     java.awt.Paint var35 = null;
//     var34.setLabelBackgroundPaint(var35);
//     var34.setInnerSeparatorExtension(0.0d);
//     java.awt.Stroke var39 = var34.getLabelLinkStroke();
//     org.jfree.chart.StandardChartTheme var41 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
//     java.awt.Paint var42 = var41.getTitlePaint();
//     java.awt.Paint var43 = var41.getLegendBackgroundPaint();
//     java.awt.Color var46 = java.awt.Color.getColor("hi!", 100);
//     int var47 = var46.getBlue();
//     java.awt.Color var48 = var46.darker();
//     var41.setWallPaint((java.awt.Paint)var48);
//     java.awt.Paint var50 = var41.getShadowPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var52 = null;
//     org.jfree.chart.urls.XYURLGenerator var53 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var52, var53);
//     org.jfree.chart.urls.XYURLGenerator var58 = var54.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var59 = null;
//     var54.setBaseURLGenerator(var59, false);
//     java.awt.Paint var65 = var54.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var66 = var54.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var68 = null;
//     var54.setSeriesOutlinePaint(0, var68, false);
//     boolean var71 = var54.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var73 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var74 = var73.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var75 = var73.getLegendItems();
//     java.awt.Stroke var76 = var73.getDomainCrosshairStroke();
//     var54.setSeriesOutlineStroke(1, var76);
//     java.awt.Stroke var81 = var54.getItemStroke(0, (-1), false);
//     org.jfree.chart.plot.IntervalMarker var83 = new org.jfree.chart.plot.IntervalMarker((-1.0d), Double.NaN, var26, var39, var50, var81, 0.8f);
//     var83.setEndValue(2.0d);
//     java.awt.Stroke var86 = var83.getOutlineStroke();
//     java.awt.Stroke var87 = var83.getStroke();
//     boolean var88 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var83);
//     
//     // Checks the contract:  equals-hashcode on var0 and var73
//     assertTrue("Contract failed: equals-hashcode on var0 and var73", var0.equals(var73) ? var0.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var0
//     assertTrue("Contract failed: equals-hashcode on var73 and var0", var73.equals(var0) ? var73.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    org.jfree.chart.util.Rotation var10 = var7.getDirection();
    java.awt.Paint var11 = var7.getLabelLinkPaint();
    java.awt.Paint var12 = var7.getBaseSectionPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var14 = var13.getRangeAxis();
    org.jfree.chart.LegendItemCollection var15 = var13.getLegendItems();
    java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
    var7.setLabelLinkStroke(var16);
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("100");
    org.jfree.chart.axis.PeriodAxis var22 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var23 = var22.getTickLabelPaint();
    var22.zoomRange(1.0d, 100.0d);
    double var27 = var22.getLowerMargin();
    org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var22);
    org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var30 = var29.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.RenderingSource var34 = null;
    var29.select(10.0d, 100.0d, var33, var34);
    var29.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var40 = var39.getTickLabelPaint();
    var29.setOutlinePaint(var40);
    var22.setMinorTickMarkPaint(var40);
    var20.setPaint(var40);
    org.jfree.chart.util.RectangleAnchor var44 = var20.getTextAnchor();
    org.jfree.chart.text.TextFragment var46 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var47 = var46.getFont();
    var20.setFont(var47);
    java.awt.Font var49 = var20.getFont();
    java.text.DateFormat var51 = null;
    java.text.DateFormat var52 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var53 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var51, var52);
    org.jfree.chart.urls.StandardXYURLGenerator var55 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYStepRenderer var56 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var53, (org.jfree.chart.urls.XYURLGenerator)var55);
    var56.setSeriesShapesVisible(3, false);
    boolean var60 = var56.getBaseShapesFilled();
    java.awt.Paint var64 = var56.getItemOutlinePaint(0, (-1), false);
    org.jfree.chart.text.TextFragment var65 = new org.jfree.chart.text.TextFragment("RectangleAnchor.CENTER", var49, var64);
    var7.setLabelBackgroundPaint(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var5 = var4.getStroke();
    double var6 = var4.getValue();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var4);
    var0.mapDatasetToRangeAxis(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    var2.setOutlineVisible(true);
    var2.clearRangeMarkers();
    org.jfree.chart.StandardChartTheme var8 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var9 = var8.getTitlePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var12.setSeriesURLGenerator(10, var14);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setSeriesURLGenerator(3, var17, true);
    int var20 = var12.getPassCount();
    org.jfree.chart.renderer.category.BarPainter var21 = var12.getBarPainter();
    var8.setBarPainter(var21);
    java.awt.Font var24 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("", var24, (org.jfree.chart.plot.Plot)var25, false);
    org.jfree.chart.axis.AxisSpace var28 = null;
    var25.setFixedRangeAxisSpace(var28);
    org.jfree.chart.axis.AxisLocation var30 = var25.getDomainAxisLocation();
    java.awt.Paint var31 = var25.getDomainGridlinePaint();
    var8.setItemLabelPaint(var31);
    var2.setDomainZeroBaselinePaint(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)2.0d);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     java.awt.Paint var15 = var14.getItemPaint();
//     org.jfree.chart.util.RectangleAnchor var16 = var14.getLegendItemGraphicAnchor();
//     org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var19 = var18.getTickLabelPaint();
//     var18.zoomRange(1.0d, 100.0d);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
//     org.jfree.chart.entity.AxisLabelEntity var28 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, var25, "ERROR : Relative To String", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     org.jfree.chart.axis.Axis var29 = var28.getAxis();
//     boolean var30 = var14.equals((java.lang.Object)var29);
//     org.jfree.chart.util.PaintList var31 = new org.jfree.chart.util.PaintList();
//     org.jfree.data.general.DefaultPieDataset var32 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var35 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var32, (java.lang.Comparable)"hi!", 10.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var32.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var36);
//     boolean var38 = var31.equals((java.lang.Object)var36);
//     org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var40 = var39.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.RenderingSource var44 = null;
//     var39.select(10.0d, 100.0d, var43, var44);
//     var39.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var48 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var49 = new org.jfree.chart.block.BlockContainer();
//     var48.add((org.jfree.chart.block.Block)var49);
//     org.jfree.chart.block.Arrangement var51 = var48.getArrangement();
//     org.jfree.chart.block.BorderArrangement var52 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39, var51, (org.jfree.chart.block.Arrangement)var52);
//     java.awt.Paint var54 = var53.getItemPaint();
//     org.jfree.chart.block.BlockContainer var55 = var53.getItemContainer();
//     org.jfree.chart.util.RectangleAnchor var56 = var53.getLegendItemGraphicLocation();
//     boolean var57 = var31.equals((java.lang.Object)var56);
//     var14.setLegendItemGraphicAnchor(var56);
//     
//     // Checks the contract:  equals-hashcode on var0 and var39
//     assertTrue("Contract failed: equals-hashcode on var0 and var39", var0.equals(var39) ? var0.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var0
//     assertTrue("Contract failed: equals-hashcode on var39 and var0", var39.equals(var0) ? var39.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var48
//     assertTrue("Contract failed: equals-hashcode on var9 and var48", var9.equals(var48) ? var9.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var49
//     assertTrue("Contract failed: equals-hashcode on var10 and var49", var10.equals(var49) ? var10.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var9
//     assertTrue("Contract failed: equals-hashcode on var48 and var9", var48.equals(var9) ? var48.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var10
//     assertTrue("Contract failed: equals-hashcode on var49 and var10", var49.equals(var10) ? var49.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var51
//     assertTrue("Contract failed: equals-hashcode on var12 and var51", var12.equals(var51) ? var12.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var12
//     assertTrue("Contract failed: equals-hashcode on var51 and var12", var51.equals(var12) ? var51.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var52
//     assertTrue("Contract failed: equals-hashcode on var13 and var52", var13.equals(var52) ? var13.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var13
//     assertTrue("Contract failed: equals-hashcode on var52 and var13", var52.equals(var13) ? var52.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.xy.XYSeries var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeSeries(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
    java.awt.Paint var17 = null;
    var3.setSeriesOutlinePaint(0, var17, false);
    boolean var20 = var3.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var23 = var22.getRangeAxis();
    org.jfree.chart.LegendItemCollection var24 = var22.getLegendItems();
    java.awt.Stroke var25 = var22.getDomainCrosshairStroke();
    var3.setSeriesOutlineStroke(1, var25);
    java.awt.Stroke var28 = var3.getSeriesOutlineStroke(1);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var3.setBaseShape(var30, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var0.setBaseLinesVisible(true);
    int var6 = var0.getPassCount();
    var0.setBaseSeriesVisibleInLegend(true, true);
    boolean var10 = var0.getDrawSeriesLineAsPath();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
    int var18 = var17.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var23 = var22.getSize();
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity(var16, (org.jfree.data.general.PieDataset)var17, 100, (-1), (java.lang.Comparable)var22, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var26.setSectionKey((java.lang.Comparable)(byte)(-1));
    var26.setPieIndex((-1));
    java.awt.Shape var31 = var26.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    java.lang.String var4 = var3.toString();
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var3.createOutsetRectangle(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var4.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    java.lang.Comparable var3 = var0.getDomainCrosshairRowKey();
    var0.clearDomainMarkers();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 100);
    int var8 = var7.getBlue();
    java.awt.Color var9 = var7.darker();
    int var10 = var9.getBlue();
    var0.setRangeCrosshairPaint((java.awt.Paint)var9);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.plot.CategoryCrosshairState var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var17 = var0.render(var12, var13, (-435), var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 70);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Image var1 = org.jfree.chart.util.SerialUtilities.readImage(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var3 = var0.getQuadrantPaint(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var4.setAutoPopulateSeriesShape(true);
    var4.setDrawOutlines(false);
    java.awt.Shape var9 = var4.getLegendLine();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var12 = var11.getTickLabelPaint();
    var11.setUpperMargin(0.0d);
    java.awt.Paint var15 = var11.getLabelPaint();
    org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var16.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var16.setBaseLinesVisible(true);
    java.awt.Stroke var23 = var16.lookupSeriesStroke(0);
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var25 = var24.getDomainMinorGridlineStroke();
    var24.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var24.drawBackgroundImage(var28, var29);
    java.awt.Paint var31 = var24.getRangeZeroBaselinePaint();
    java.awt.Color var34 = java.awt.Color.getColor("hi!", 100);
    int var35 = var34.getBlue();
    var24.setRangeMinorGridlinePaint((java.awt.Paint)var34);
    float[] var46 = new float[] { 0.0f, 10.0f, 100.0f};
    float[] var47 = java.awt.Color.RGBtoHSB((-1), 0, 10, var46);
    float[] var48 = java.awt.Color.RGBtoHSB(1, 3, (-435), var46);
    float[] var49 = var34.getColorComponents(var48);
    org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("WMAP_Plot", "TextAnchor.TOP_CENTER", "Polar Plot", "RectangleAnchor.CENTER", var9, var15, var23, (java.awt.Paint)var34);
    var50.setDatasetIndex(70);
    java.awt.Stroke var53 = var50.getLineStroke();
    java.awt.Stroke var54 = var50.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var1 = var0.getMinimumDate();
//     org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var5 = var4.getFont();
//     org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var5);
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
//     boolean var8 = var6.equals((java.lang.Object)var7);
//     org.jfree.data.Range var11 = new org.jfree.data.Range(0.2d, 0.2d);
//     var7.setRange(var11, false, true);
//     java.util.TimeZone var15 = var7.getTimeZone();
//     java.util.Locale var16 = null;
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year(var1, var15, var16);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    boolean var9 = var0.isRangePannable();
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var11 = var10.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.RenderingSource var15 = null;
    var10.select(10.0d, 100.0d, var14, var15);
    var10.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var20 = null;
    org.jfree.chart.urls.XYURLGenerator var21 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var20, var21);
    org.jfree.chart.urls.XYURLGenerator var26 = var22.getURLGenerator(0, 1, true);
    var22.setBaseSeriesVisibleInLegend(false);
    int var29 = var10.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var22);
    var0.add((org.jfree.chart.plot.XYPlot)var10);
    var10.setRangeCrosshairValue(0.2d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var4 = var3.getRangeAxis();
    java.awt.Paint var5 = var3.getDomainGridlinePaint();
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var8 = var7.getStroke();
    double var9 = var7.getValue();
    var3.addDomainMarker((org.jfree.chart.plot.Marker)var7);
    org.jfree.chart.entity.PlotEntity var13 = new org.jfree.chart.entity.PlotEntity(var2, (org.jfree.chart.plot.Plot)var3, "NOID", "Polar Plot");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var16 = new org.jfree.chart.entity.AxisLabelEntity(var0, var2, "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]", "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     int var4 = var3.getMaximumItemCount();
//     java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
//     boolean var6 = var3.equals((java.lang.Object)var5);
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     int var11 = var10.getMaximumItemCount();
//     java.beans.PropertyChangeListener var12 = null;
//     var10.removePropertyChangeListener(var12);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     java.lang.String var18 = var17.getRangeDescription();
//     org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
//     org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var22 = var21.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
//     boolean var24 = var21.isAxisLineVisible();
//     var21.setPositiveArrowVisible(false);
//     org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
//     var19.delete(var27);
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var31 = var30.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
//     boolean var33 = var30.isAxisLineVisible();
//     var30.setPositiveArrowVisible(false);
//     org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
//     org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
//     java.util.Calendar var38 = null;
//     long var39 = var27.getMiddleMillisecond(var38);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var3, (org.jfree.chart.urls.XYURLGenerator)var5);
    org.jfree.chart.labels.XYItemLabelGenerator var7 = null;
    var6.setBaseItemLabelGenerator(var7, false);
    double var10 = var6.getStepPoint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getLowerClip();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var2 = var0.getTimeFromLong(1L);
    var0.setAdjustForDaylightSaving(true);
    long var5 = var0.getSegmentsIncludedSize();
    long var7 = var0.toTimelineValue(0L);
    int var8 = var0.getSegmentsExcluded();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 644288400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 68);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    java.util.List var8 = var7.getSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSelected((-1), (-435), false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.setTickMarkInsideLength(0.8f);
    org.jfree.chart.axis.PeriodAxisLabelInfo[] var5 = var1.getLabelInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var3, (org.jfree.chart.urls.XYURLGenerator)var5);
    var6.setSeriesShapesVisible(3, false);
    boolean var12 = var6.getItemLineVisible(1, 2147483647);
    java.lang.Boolean var14 = var6.getSeriesShapesFilled(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var3 = var2.getRangeAxis();
//     java.awt.Paint var4 = var2.getDomainGridlinePaint();
//     var0.setRangeTickBandPaint(var4);
//     java.awt.Paint[] var6 = new java.awt.Paint[] { var4};
//     org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var10 = var9.getFont();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var13 = var12.getTickLabelPaint();
//     java.lang.Class var14 = var12.getMajorTickTimePeriodClass();
//     java.awt.Paint var15 = var12.getTickMarkPaint();
//     org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("AxisLocation.TOP_OR_RIGHT", var10, var15);
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var15};
//     org.jfree.chart.labels.XYToolTipGenerator var19 = null;
//     org.jfree.chart.urls.XYURLGenerator var20 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var19, var20);
//     org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var26 = null;
//     var21.setBaseURLGenerator(var26, false);
//     java.awt.Paint var32 = var21.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var33 = var21.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var35 = null;
//     var21.setSeriesOutlinePaint(0, var35, false);
//     boolean var38 = var21.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var41 = var40.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var42 = var40.getLegendItems();
//     java.awt.Stroke var43 = var40.getDomainCrosshairStroke();
//     var21.setSeriesOutlineStroke(1, var43);
//     java.awt.Stroke var46 = var21.getSeriesOutlineStroke(1);
//     java.awt.Stroke[] var47 = new java.awt.Stroke[] { var46};
//     org.jfree.chart.plot.CombinedDomainXYPlot var48 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var49 = var48.getDomainMinorGridlineStroke();
//     var48.setDomainCrosshairVisible(false);
//     java.awt.Paint var52 = var48.getRangeCrosshairPaint();
//     float var53 = var48.getBackgroundImageAlpha();
//     var48.setGap(0.0d);
//     var48.clearDomainAxes();
//     org.jfree.chart.plot.PlotOrientation var57 = var48.getOrientation();
//     java.awt.Stroke var58 = var48.getDomainZeroBaselineStroke();
//     java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
//     org.jfree.chart.axis.PeriodAxis var61 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var62 = var61.getTickLabelPaint();
//     java.lang.Class var63 = var61.getMajorTickTimePeriodClass();
//     java.awt.Paint var64 = var61.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var66 = null;
//     org.jfree.chart.urls.XYURLGenerator var67 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var68 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var66, var67);
//     org.jfree.chart.event.RendererChangeEvent var69 = null;
//     var68.notifyListeners(var69);
//     var68.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var74 = var68.getBaseShape();
//     var61.setLeftArrow(var74);
//     org.jfree.chart.entity.ChartEntity var76 = new org.jfree.chart.entity.ChartEntity(var74);
//     java.awt.Shape[] var77 = new java.awt.Shape[] { var74};
//     org.jfree.chart.plot.DefaultDrawingSupplier var78 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var17, var47, var59, var77);
//     
//     // Checks the contract:  equals-hashcode on var2 and var40
//     assertTrue("Contract failed: equals-hashcode on var2 and var40", var2.equals(var40) ? var2.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var2
//     assertTrue("Contract failed: equals-hashcode on var40 and var2", var40.equals(var2) ? var40.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.AbstractPieLabelDistributor var38 = var7.getLabelDistributor();
    org.jfree.chart.plot.PieLabelRecord var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var38.addPieLabelRecord(var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    org.jfree.chart.renderer.category.GradientBarPainter var3 = new org.jfree.chart.renderer.category.GradientBarPainter(Double.NaN, 0.08d, 100.0d);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var7.setSeriesURLGenerator(10, var9);
    org.jfree.data.xy.XYSeries var14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var15 = var14.clone();
    boolean var16 = var7.equals((java.lang.Object)var14);
    double var17 = var7.getLowerClip();
    boolean var18 = var7.getAutoPopulateSeriesPaint();
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 100);
    int var23 = var22.getBlue();
    var7.setSeriesOutlinePaint(0, (java.awt.Paint)var22, true);
    java.lang.Boolean var27 = var7.getSeriesItemLabelsVisible(2147483647);
    java.awt.geom.RectangularShape var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    var3.paintBar(var4, (org.jfree.chart.renderer.category.BarRenderer)var7, 0, 0, false, var31, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }
// 
// 
//     org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var3 = var2.getFont();
//     org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
//     org.jfree.chart.text.TextFragment var5 = var4.getFirstTextFragment();
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.RenderingSource var11 = null;
//     var6.select(10.0d, 100.0d, var10, var11);
//     var6.setOutlineVisible(false);
//     org.jfree.chart.labels.XYToolTipGenerator var16 = null;
//     org.jfree.chart.urls.XYURLGenerator var17 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var16, var17);
//     org.jfree.chart.urls.XYURLGenerator var22 = var18.getURLGenerator(0, 1, true);
//     var18.setBaseSeriesVisibleInLegend(false);
//     int var25 = var6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var18);
//     org.jfree.chart.labels.XYToolTipGenerator var27 = null;
//     org.jfree.chart.urls.XYURLGenerator var28 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var27, var28);
//     org.jfree.chart.urls.XYURLGenerator var33 = var29.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var34 = null;
//     var29.setBaseURLGenerator(var34, false);
//     java.awt.Paint var40 = var29.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var41 = var29.getBaseNegativeItemLabelPosition();
//     var18.setBasePositiveItemLabelPosition(var41, true);
//     var18.setBaseSeriesVisibleInLegend(true);
//     boolean var46 = var5.equals((java.lang.Object)var18);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.util.Size2D var48 = var5.calculateDimensions(var47);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var11 = var10.getMaximumItemCount();
    java.beans.PropertyChangeListener var12 = null;
    var10.removePropertyChangeListener(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var18 = var17.getRangeDescription();
    org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
    boolean var24 = var21.isAxisLineVisible();
    var21.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
    var19.delete(var27);
    org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var31 = var30.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isAxisLineVisible();
    var30.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
    org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
    org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var42 = var41.getMaximumItemCount();
    java.beans.PropertyChangeListener var43 = null;
    var41.removePropertyChangeListener(var43);
    org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var41);
    var37.addChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
    org.jfree.data.time.TimePeriodAnchor var47 = var45.getXPosition();
    java.lang.Object var48 = null;
    boolean var49 = var47.equals(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var27 = var26.getTickLabelPaint();
    java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
    java.awt.Paint var29 = var26.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
    org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
    java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
    var26.setMinorTickMarkStroke(var33);
    var26.setRangeAboutValue(0.05d, 1.0E-5d);
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
    boolean var40 = var39.isDomainZoomable();
    var39.removeCornerTextItem("NOID");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.AbstractPieLabelDistributor var38 = var7.getLabelDistributor();
    boolean var39 = var7.getSimpleLabels();
    org.jfree.chart.util.RectangleInsets var40 = var7.getLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
//     java.awt.Paint var4 = var1.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var6 = null;
//     org.jfree.chart.urls.XYURLGenerator var7 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var8.notifyListeners(var9);
//     var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var14 = var8.getBaseShape();
//     var1.setLeftArrow(var14);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
//     int var18 = var17.getItemCount();
//     org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var23 = var22.getSize();
//     org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity(var16, (org.jfree.data.general.PieDataset)var17, 100, (-1), (java.lang.Comparable)var22, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var26.setSectionKey((java.lang.Comparable)(byte)(-1));
//     java.awt.Shape var29 = var26.getArea();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var31 = var30.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.RenderingSource var35 = null;
//     var30.select(10.0d, 100.0d, var34, var35);
//     var30.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var39 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var40 = new org.jfree.chart.block.BlockContainer();
//     var39.add((org.jfree.chart.block.Block)var40);
//     org.jfree.chart.block.Arrangement var42 = var39.getArrangement();
//     org.jfree.chart.block.BorderArrangement var43 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30, var42, (org.jfree.chart.block.Arrangement)var43);
//     java.awt.Paint var45 = var44.getItemPaint();
//     org.jfree.chart.block.BlockContainer var46 = var44.getItemContainer();
//     org.jfree.chart.util.RectangleAnchor var47 = var44.getLegendItemGraphicLocation();
//     org.jfree.chart.block.BlockContainer var48 = var44.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var49 = var44.getItemLabelPadding();
//     org.jfree.chart.entity.TitleEntity var51 = new org.jfree.chart.entity.TitleEntity(var29, (org.jfree.chart.title.Title)var44, "January");
//     org.jfree.chart.block.BlockContainer var52 = new org.jfree.chart.block.BlockContainer();
//     var44.setWrapper(var52);
//     
//     // Checks the contract:  equals-hashcode on var40 and var52
//     assertTrue("Contract failed: equals-hashcode on var40 and var52", var40.equals(var52) ? var40.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var40
//     assertTrue("Contract failed: equals-hashcode on var52 and var40", var52.equals(var40) ? var52.hashCode() == var40.hashCode() : true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    var3.add(4.0d, (java.lang.Number)(byte)1, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(true);
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var2);
//     var3.setAutoTickUnitSelection(true);
//     org.jfree.data.xy.XYDataItem var8 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
//     boolean var9 = var8.isSelected();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     java.awt.Paint var11 = var3.getGridBandPaint();
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var17 = var16.getDomainAxisEdge();
//     org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var22 = null;
//     var20.setSeriesURLGenerator(10, var22);
//     org.jfree.chart.urls.CategoryURLGenerator var25 = null;
//     var20.setSeriesURLGenerator(3, var25, true);
//     int var28 = var20.getPassCount();
//     org.jfree.chart.renderer.category.BarPainter var29 = var20.getBarPainter();
//     var20.setBaseSeriesVisible(true, true);
//     var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     org.jfree.chart.util.Layer var35 = null;
//     java.util.Collection var36 = var16.getDomainMarkers(0, var35);
//     org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
//     var37.setBottom(2.0d);
//     var16.setFixedRangeAxisSpace(var37, true);
//     org.jfree.chart.axis.AxisSpace var43 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var44 = var43.clone();
//     org.jfree.chart.axis.AxisSpace var45 = new org.jfree.chart.axis.AxisSpace();
//     var45.setTop(10.0d);
//     var43.ensureAtLeast(var45);
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var51 = var50.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var52 = null;
//     var50.setDrawingSupplier(var52);
//     float var54 = var50.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var58 = null;
//     org.jfree.chart.urls.XYURLGenerator var59 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var60 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var58, var59);
//     org.jfree.chart.urls.XYURLGenerator var64 = var60.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var65 = null;
//     var60.setBaseURLGenerator(var65, false);
//     java.awt.Paint var71 = var60.getItemFillPaint(10, 100, false);
//     var56.setLabelPaint(var71);
//     float var73 = var56.getAlpha();
//     org.jfree.chart.util.Layer var74 = null;
//     boolean var75 = var50.removeDomainMarker((org.jfree.chart.plot.Marker)var56, var74);
//     org.jfree.chart.util.RectangleEdge var76 = var50.getRangeAxisEdge();
//     var45.add(0.05d, var76);
//     var37.add(3.0d, var76);
//     org.jfree.chart.plot.PlotRenderingInfo var79 = null;
//     org.jfree.chart.axis.AxisState var80 = var3.draw(var12, (-5.99999d), var14, var15, var76, var79);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var8 = null;
//     var6.setDrawingSupplier(var8);
//     var3.setPlot((org.jfree.chart.plot.XYPlot)var6);
//     org.jfree.chart.axis.AxisSpace var11 = new org.jfree.chart.axis.AxisSpace();
//     var6.setFixedRangeAxisSpace(var11, false);
//     org.jfree.chart.labels.XYToolTipGenerator var15 = null;
//     org.jfree.chart.urls.XYURLGenerator var16 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
//     org.jfree.chart.event.RendererChangeEvent var18 = null;
//     var17.notifyListeners(var18);
//     org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var21 = var20.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var22 = null;
//     var20.setDrawingSupplier(var22);
//     var17.setPlot((org.jfree.chart.plot.XYPlot)var20);
//     java.awt.geom.GeneralPath var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.RenderingSource var27 = null;
//     var20.select(var25, var26, var27);
//     java.awt.Stroke var29 = var20.getRangeMinorGridlineStroke();
//     boolean var30 = var6.equals((java.lang.Object)var20);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var5.getRangeAxis();
    org.jfree.chart.LegendItemCollection var7 = var5.getLegendItems();
    java.awt.Stroke var8 = var5.getDomainCrosshairStroke();
    var1.setMinorTickMarkStroke(var8);
    boolean var10 = var1.isInverted();
    org.jfree.chart.renderer.xy.XYStepRenderer var11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var11.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var11.setBaseLinesVisible(true);
    boolean var19 = var11.getItemShapeFilled(0, 1);
    java.awt.Shape var21 = var11.lookupSeriesShape((-1));
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 3.0d, 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var27 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var24, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "AxisLocation.TOP_OR_RIGHT");
    org.jfree.chart.axis.Axis var28 = var27.getAxis();
    java.lang.String var29 = var27.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "poly"+ "'", var29.equals("poly"));

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    var0.addBaseTimelineExclusions(0L, 1L);
    var0.setStartTime((-2208960000000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    java.lang.Comparable var3 = var0.getDomainCrosshairRowKey();
    var0.clearDomainMarkers();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 100);
    int var8 = var7.getBlue();
    java.awt.Color var9 = var7.darker();
    int var10 = var9.getBlue();
    var0.setRangeCrosshairPaint((java.awt.Paint)var9);
    java.lang.String var12 = var0.getPlotType();
    java.util.List var13 = var0.getAnnotations();
    var0.setRangeCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Category Plot"+ "'", var12.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    var3.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
    var3.setBaseItemLabelGenerator(var10);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var13 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
    java.lang.Object var14 = var13.clone();
    var3.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var13);
    java.lang.Object var16 = var13.clone();
    org.jfree.data.general.SeriesChangeInfo var17 = null;
    org.jfree.data.general.SeriesChangeEvent var18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var13, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.zoomRange(1.0d, 100.0d);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    org.jfree.chart.entity.AxisLabelEntity var11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var8, "ERROR : Relative To String", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    org.jfree.chart.axis.Axis var12 = var11.getAxis();
    java.lang.String var13 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AxisLabelEntity: label = "+ "'", var13.equals("AxisLabelEntity: label = "));

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var1 = var0.getMinimumDate();
//     boolean var3 = var0.isHiddenValue(1L);
//     java.awt.Paint var4 = var0.getTickMarkPaint();
//     org.jfree.chart.axis.DateTickUnit var5 = null;
//     java.util.Date var6 = var0.calculateLowestVisibleTickValue(var5);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    boolean var6 = var2.isDrawBarOutline();
    double var7 = var2.getBase();
    var2.setSeriesVisibleInLegend(255, (java.lang.Boolean)false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     java.awt.Paint var15 = var14.getItemPaint();
//     org.jfree.chart.block.BlockContainer var16 = var14.getItemContainer();
//     boolean var17 = var16.isEmpty();
//     var16.setPadding(0.2d, 1.0E-5d, 1.0E-5d, 1.0E-5d);
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     var16.draw(var23, var24);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }
// 
// 
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var4 = var3.getFont();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var7 = var6.getTickLabelPaint();
//     java.lang.Class var8 = var6.getMajorTickTimePeriodClass();
//     java.awt.Paint var9 = var6.getTickMarkPaint();
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("AxisLocation.TOP_OR_RIGHT", var4, var9);
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("Combined Range XYPlot", var4);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var18 = var17.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var19 = null;
//     var17.setDrawingSupplier(var19);
//     float var21 = var17.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var25 = null;
//     org.jfree.chart.urls.XYURLGenerator var26 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var25, var26);
//     org.jfree.chart.urls.XYURLGenerator var31 = var27.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var32 = null;
//     var27.setBaseURLGenerator(var32, false);
//     java.awt.Paint var38 = var27.getItemFillPaint(10, 100, false);
//     var23.setLabelPaint(var38);
//     float var40 = var23.getAlpha();
//     org.jfree.chart.util.Layer var41 = null;
//     boolean var42 = var17.removeDomainMarker((org.jfree.chart.plot.Marker)var23, var41);
//     org.jfree.chart.text.TextAnchor var43 = var23.getLabelTextAnchor();
//     org.jfree.chart.labels.XYToolTipGenerator var45 = null;
//     org.jfree.chart.urls.XYURLGenerator var46 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var47 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var45, var46);
//     org.jfree.chart.urls.XYURLGenerator var51 = var47.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var52 = null;
//     var47.setBaseURLGenerator(var52, false);
//     java.awt.Paint var58 = var47.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var59 = var47.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var60 = var59.getTextAnchor();
//     java.lang.String var61 = var60.toString();
//     org.jfree.chart.axis.NumberTick var63 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)1, "Polar Plot", var43, var60, 0.14d);
//     var11.draw(var12, 100.0f, 10.0f, var43, 10.0f, 0.8f, 1.0d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    var6.setDomainCrosshairVisible(false);
    java.awt.Paint var10 = var6.getRangeCrosshairPaint();
    float var11 = var6.getBackgroundImageAlpha();
    var0.add((org.jfree.chart.plot.XYPlot)var6);
    org.jfree.chart.labels.XYToolTipGenerator var14 = null;
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var14, var15);
    org.jfree.chart.urls.XYURLGenerator var20 = var16.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var21 = null;
    var16.setBaseURLGenerator(var21, false);
    java.awt.Paint var27 = var16.getItemFillPaint(10, 100, false);
    int var28 = var0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var29 = var0.clone();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    var2.setOutlineVisible(true);
    org.jfree.chart.LegendItemCollection var6 = var2.getFixedLegendItems();
    var2.setDomainGridlinesVisible(false);
    boolean var9 = var2.isRangeGridlinesVisible();
    boolean var10 = var2.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("100");
//     java.lang.String var2 = var1.getToolTipText();
//     java.awt.Paint var3 = var1.getPaint();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var1.draw(var4, var5);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    boolean var13 = var0.isDomainZeroBaselineVisible();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var25 = null;
    var18.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var25);
    double var27 = var18.getCrosshairY();
    boolean var28 = var0.render(var14, var15, 10, var17, var18);
    var18.setDatasetIndex(70);
    double var31 = var18.getAnchorY();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths();
//     org.jfree.chart.axis.SymbolAxis var2 = new org.jfree.chart.axis.SymbolAxis("Jan", var1);
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var6);
//     double var8 = var7.getGap();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getDomainAxisEdge(0);
//     double var11 = var2.java2DToValue(10.0d, var4, var10);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }
// 
// 
//     org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var6 = var5.getFont();
//     org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var6);
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var9);
//     double var11 = var10.getGap();
//     var10.setOutlineVisible(true);
//     var10.setRangeCrosshairVisible(true);
//     java.lang.String var16 = var10.getPlotType();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("TextAnchor.TOP_CENTER", var6, (org.jfree.chart.plot.Plot)var10, true);
//     org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.AxisSpace var20 = null;
//     var19.setFixedDomainAxisSpace(var20, true);
//     java.awt.Font var24 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("", var24, (org.jfree.chart.plot.Plot)var25, false);
//     org.jfree.chart.axis.AxisSpace var28 = null;
//     var25.setFixedRangeAxisSpace(var28);
//     org.jfree.chart.axis.AxisLocation var30 = var25.getDomainAxisLocation();
//     java.awt.Paint var31 = var25.getDomainGridlinePaint();
//     var19.setRangeTickBandPaint(var31);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.text.G2TextMeasurer var35 = new org.jfree.chart.text.G2TextMeasurer(var34);
//     org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var31, 0.5f, (org.jfree.chart.text.TextMeasurer)var35);
//     org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var38 = var37.getDomainMinorGridlineStroke();
//     java.awt.Font var40 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var41 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("", var40, (org.jfree.chart.plot.Plot)var41, false);
//     org.jfree.chart.axis.AxisSpace var44 = null;
//     var41.setFixedRangeAxisSpace(var44);
//     org.jfree.chart.axis.AxisLocation var46 = var41.getDomainAxisLocation();
//     java.awt.Paint var47 = var41.getDomainGridlinePaint();
//     var37.setRangeZeroBaselinePaint(var47);
//     org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var56 = var55.getFont();
//     org.jfree.chart.text.TextLine var57 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var56);
//     org.jfree.chart.axis.PeriodAxis var59 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var60 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var59);
//     double var61 = var60.getGap();
//     var60.setOutlineVisible(true);
//     var60.setRangeCrosshairVisible(true);
//     java.lang.String var66 = var60.getPlotType();
//     org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart("TextAnchor.TOP_CENTER", var56, (org.jfree.chart.plot.Plot)var60, true);
//     org.jfree.chart.plot.CombinedDomainXYPlot var69 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.AxisSpace var70 = null;
//     var69.setFixedDomainAxisSpace(var70, true);
//     java.awt.Font var74 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var75 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var77 = new org.jfree.chart.JFreeChart("", var74, (org.jfree.chart.plot.Plot)var75, false);
//     org.jfree.chart.axis.AxisSpace var78 = null;
//     var75.setFixedRangeAxisSpace(var78);
//     org.jfree.chart.axis.AxisLocation var80 = var75.getDomainAxisLocation();
//     java.awt.Paint var81 = var75.getDomainGridlinePaint();
//     var69.setRangeTickBandPaint(var81);
//     java.awt.Graphics2D var84 = null;
//     org.jfree.chart.text.G2TextMeasurer var85 = new org.jfree.chart.text.G2TextMeasurer(var84);
//     org.jfree.chart.text.TextBlock var86 = org.jfree.chart.text.TextUtilities.createTextBlock("", var56, var81, 0.5f, (org.jfree.chart.text.TextMeasurer)var85);
//     org.jfree.chart.text.TextBlock var87 = org.jfree.chart.text.TextUtilities.createTextBlock("10", var6, var47, 0.8f, 0, (org.jfree.chart.text.TextMeasurer)var85);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var8 = null;
    var6.setDrawingSupplier(var8);
    var3.setPlot((org.jfree.chart.plot.XYPlot)var6);
    org.jfree.chart.axis.AxisSpace var11 = new org.jfree.chart.axis.AxisSpace();
    var6.setFixedRangeAxisSpace(var11, false);
    double var14 = var11.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var11 = var10.getMaximumItemCount();
    java.beans.PropertyChangeListener var12 = null;
    var10.removePropertyChangeListener(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var18 = var17.getRangeDescription();
    org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
    boolean var24 = var21.isAxisLineVisible();
    var21.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
    var19.delete(var27);
    org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var31 = var30.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isAxisLineVisible();
    var30.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
    org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
    org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var42 = var41.getMaximumItemCount();
    java.beans.PropertyChangeListener var43 = null;
    var41.removePropertyChangeListener(var43);
    org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var41);
    var37.addChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var49 = var45.getStartY(2147483647, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2147483647);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var2 = var1.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(10.0d, 100.0d, var5, var6);
    var1.setOutlineVisible(false);
    boolean var10 = var1.isRangePannable();
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var12 = var11.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.RenderingSource var16 = null;
    var11.select(10.0d, 100.0d, var15, var16);
    var11.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var21 = null;
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
    org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
    var23.setBaseSeriesVisibleInLegend(false);
    int var30 = var11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var23);
    var1.add((org.jfree.chart.plot.XYPlot)var11);
    java.awt.Paint var32 = var1.getRangeZeroBaselinePaint();
    var1.setRangeMinorGridlinesVisible(true);
    java.util.List var35 = var1.getAnnotations();
    var0.setTicks(var35);
    double var37 = var0.getCursor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(10.0d, "hi!", "TextAnchor.TOP_CENTER", true);
    java.text.NumberFormat var6 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("100", (java.text.NumberFormat)var5, var6);
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var10 = var9.getTickLabelPaint();
    java.lang.Class var11 = var9.getMajorTickTimePeriodClass();
    java.awt.Paint var12 = var9.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var14 = null;
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var14, var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.notifyListeners(var17);
    var16.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var22 = var16.getBaseShape();
    var9.setLeftArrow(var22);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    org.jfree.data.general.DefaultPieDataset var25 = new org.jfree.data.general.DefaultPieDataset();
    int var26 = var25.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var30 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var31 = var30.getSize();
    org.jfree.chart.entity.PieSectionEntity var34 = new org.jfree.chart.entity.PieSectionEntity(var24, (org.jfree.data.general.PieDataset)var25, 100, (-1), (java.lang.Comparable)var30, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var34.setSectionKey((java.lang.Comparable)(byte)(-1));
    java.awt.Shape var37 = var34.getArea();
    org.jfree.data.general.PieDataset var38 = var34.getDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var40 = var7.generateSectionLabel(var38, (java.lang.Comparable)(short)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.setValue((java.lang.Comparable)0.2d, (java.lang.Number)(byte)0);
    int var5 = var0.getIndex((java.lang.Comparable)644288400000L);
    java.text.NumberFormat var7 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var8 = var7.getRoundingMode();
    boolean var9 = var7.isGroupingUsed();
    org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var7, 0);
    var0.addValue((java.lang.Comparable)(-1.0d), 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var15 = var0.getValue((java.lang.Comparable)(short)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("null");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var1 = null;
//     var0.setChartArea(var1);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    org.jfree.chart.renderer.category.GradientBarPainter var0 = new org.jfree.chart.renderer.category.GradientBarPainter();
    org.jfree.chart.StandardChartTheme var2 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var3 = var2.getTitlePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var6.setSeriesURLGenerator(10, var8);
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var6.setSeriesURLGenerator(3, var11, true);
    int var14 = var6.getPassCount();
    org.jfree.chart.renderer.category.BarPainter var15 = var6.getBarPainter();
    var2.setBarPainter(var15);
    java.awt.Font var18 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("", var18, (org.jfree.chart.plot.Plot)var19, false);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var19.setFixedRangeAxisSpace(var22);
    org.jfree.chart.axis.AxisLocation var24 = var19.getDomainAxisLocation();
    java.awt.Paint var25 = var19.getDomainGridlinePaint();
    var2.setItemLabelPaint(var25);
    boolean var27 = var0.equals((java.lang.Object)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    boolean var4 = var0.isDomainPannable();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var13 = null;
    var8.setBaseURLGenerator(var13, false);
    java.awt.Paint var19 = var8.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var20 = var8.getBaseNegativeItemLabelPosition();
    java.awt.Paint var22 = null;
    var8.setSeriesOutlinePaint(0, var22, false);
    boolean var25 = var8.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var28 = var27.getRangeAxis();
    org.jfree.chart.LegendItemCollection var29 = var27.getLegendItems();
    java.awt.Stroke var30 = var27.getDomainCrosshairStroke();
    var8.setSeriesOutlineStroke(1, var30);
    java.awt.Stroke var33 = var8.getSeriesOutlineStroke(1);
    var0.setRangeGridlineStroke(var33);
    java.awt.Graphics2D var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    var0.drawAnnotations(var35, var36, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.05d, (java.lang.Number)2147483647);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var3.getX((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    var0.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    var0.drawBackgroundImage(var4, var5);
    double var7 = var0.getDomainCrosshairValue();
    int var8 = var0.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
    int var18 = var17.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var23 = var22.getSize();
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity(var16, (org.jfree.data.general.PieDataset)var17, 100, (-1), (java.lang.Comparable)var22, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var26.setSectionKey((java.lang.Comparable)(byte)(-1));
    java.awt.Shape var29 = var26.getArea();
    org.jfree.data.general.PieDataset var30 = var26.getDataset();
    java.lang.String var31 = var26.toString();
    int var32 = var26.getSectionIndex();
    org.jfree.data.general.PieDataset var33 = var26.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "PieSection: 100, -1(-1)"+ "'", var31.equals("PieSection: 100, -1(-1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    var0.clear();

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(5.0d, 0.14d);
    var2.setEndValue(1.0d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("10", "10", "", "Size2D[width=0.0, height=0.0]");

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var4 = var3.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.RenderingSource var8 = null;
    var3.select(10.0d, 100.0d, var7, var8);
    var3.setOutlineVisible(false);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", 100);
    var3.setNoDataMessagePaint((java.awt.Paint)var14);
    boolean var16 = var2.equals((java.lang.Object)var14);
    java.awt.Stroke var17 = null;
    java.awt.Paint var18 = null;
    java.awt.Font var20 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", var20, (org.jfree.chart.plot.Plot)var21, false);
    java.lang.Object var24 = var23.getTextAntiAlias();
    var23.setBackgroundImageAlignment(2147483647);
    java.awt.Stroke var27 = var23.getBorderStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.05d, (java.awt.Paint)var14, var17, var18, var27, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var2 = var1.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.RenderingSource var6 = null;
//     var1.select(10.0d, 100.0d, var5, var6);
//     var1.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
//     var10.add((org.jfree.chart.block.Block)var11);
//     org.jfree.chart.block.Arrangement var13 = var10.getArrangement();
//     org.jfree.chart.block.BorderArrangement var14 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, var13, (org.jfree.chart.block.Arrangement)var14);
//     java.awt.Paint var16 = var15.getItemPaint();
//     org.jfree.chart.block.BlockContainer var17 = var15.getItemContainer();
//     org.jfree.chart.util.RectangleAnchor var18 = var15.getLegendItemGraphicLocation();
//     java.lang.String var19 = var18.toString();
//     java.awt.geom.Point2D var20 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var18);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    int var2 = var1.getMaximumCategoryLabelLines();
    org.jfree.data.general.DefaultPieDataset var3 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var3, (java.lang.Comparable)"hi!", 10.0d);
    var3.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var3);
    java.awt.Paint var11 = null;
    var10.setLabelBackgroundPaint(var11);
    var10.setInnerSeparatorExtension(0.0d);
    boolean var15 = var1.hasListener((java.util.EventListener)var10);
    var10.setCircular(true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomRangeAxes(0.0d, 10.0d, var3, var4);
    org.jfree.chart.axis.AxisSpace var6 = new org.jfree.chart.axis.AxisSpace();
    var0.setFixedDomainAxisSpace(var6, false);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var0.zoomDomainAxes((-5.76E7d), var10, var11);
    org.jfree.chart.annotations.CategoryAnnotation var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var15 = var0.removeAnnotation(var13, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.awt.Font var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedRangeAxisSpace(var9);
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var12 = var11.getOpposite();
    boolean var13 = var3.equals((java.lang.Object)var11);
    org.jfree.data.xy.XYDataItem var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add(var14, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    int var2 = var1.getMaximumCategoryLabelLines();
    org.jfree.data.general.DefaultPieDataset var3 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var3, (java.lang.Comparable)"hi!", 10.0d);
    var3.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var3);
    java.awt.Paint var11 = null;
    var10.setLabelBackgroundPaint(var11);
    var10.setInnerSeparatorExtension(0.0d);
    boolean var15 = var1.hasListener((java.util.EventListener)var10);
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setSeparatorPaint(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)0.2d);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    var2.setTop(10.0d);
    var0.ensureAtLeast(var2);
    double var6 = var0.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(10);
//     java.lang.String var2 = var1.toString();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getLastMillisecond(var3);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }
// 
// 
//     org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
//     var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
//     java.awt.Paint var10 = null;
//     var9.setLabelBackgroundPaint(var10);
//     org.jfree.chart.util.Rotation var12 = var9.getDirection();
//     java.awt.Paint var13 = var9.getLabelLinkPaint();
//     java.awt.Paint var14 = var9.getBaseSectionPaint();
//     org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
//     var15.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var15);
//     java.awt.Paint var23 = null;
//     var22.setLabelBackgroundPaint(var23);
//     var22.setInnerSeparatorExtension(0.0d);
//     java.awt.Stroke var27 = var22.getLabelLinkStroke();
//     org.jfree.chart.StandardChartTheme var29 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
//     java.awt.Paint var30 = var29.getTitlePaint();
//     java.awt.Paint var31 = var29.getLegendBackgroundPaint();
//     java.awt.Color var34 = java.awt.Color.getColor("hi!", 100);
//     int var35 = var34.getBlue();
//     java.awt.Color var36 = var34.darker();
//     var29.setWallPaint((java.awt.Paint)var36);
//     java.awt.Paint var38 = var29.getShadowPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var40 = null;
//     org.jfree.chart.urls.XYURLGenerator var41 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var40, var41);
//     org.jfree.chart.urls.XYURLGenerator var46 = var42.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var47 = null;
//     var42.setBaseURLGenerator(var47, false);
//     java.awt.Paint var53 = var42.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var54 = var42.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var56 = null;
//     var42.setSeriesOutlinePaint(0, var56, false);
//     boolean var59 = var42.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var61 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var62 = var61.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var63 = var61.getLegendItems();
//     java.awt.Stroke var64 = var61.getDomainCrosshairStroke();
//     var42.setSeriesOutlineStroke(1, var64);
//     java.awt.Stroke var69 = var42.getItemStroke(0, (-1), false);
//     org.jfree.chart.plot.IntervalMarker var71 = new org.jfree.chart.plot.IntervalMarker((-1.0d), Double.NaN, var14, var27, var38, var69, 0.8f);
//     java.lang.Class var72 = null;
//     java.util.EventListener[] var73 = var71.getListeners(var72);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("rect");
    var1.pan(4.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(2.0d, 1.0E-5d, 1.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = null;
//     java.awt.geom.RectangularShape var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     var3.paintBar(var4, var5, 0, 0, false, var9, var10);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var0);
    org.jfree.data.xy.XYDatasetSelectionState var2 = var0.getSelectionState();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getYValue((-435), 2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    boolean var13 = var2.getAutoPopulateSeriesPaint();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
    int var18 = var17.getBlue();
    var2.setSeriesOutlinePaint(0, (java.awt.Paint)var17, true);
    java.lang.Boolean var22 = var2.getSeriesItemLabelsVisible(2147483647);
    org.jfree.chart.labels.XYToolTipGenerator var24 = null;
    org.jfree.chart.urls.XYURLGenerator var25 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var24, var25);
    org.jfree.chart.urls.XYURLGenerator var30 = var26.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var31 = null;
    var26.setBaseURLGenerator(var31, false);
    java.awt.Paint var37 = var26.getItemFillPaint(10, 100, false);
    org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var40 = var39.getTickLabelPaint();
    var26.setBasePaint(var40);
    var2.setBaseOutlinePaint(var40);
    var2.setBaseCreateEntities(true);
    double var45 = var2.getYOffset();
    org.jfree.chart.urls.CategoryURLGenerator var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesURLGenerator(2147483647, var47);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 2.0d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
    org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxisForDataset(2147483647);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getRangeMarkers(70, var5);
    org.jfree.data.category.CategoryDataset var8 = null;
    var0.setDataset(2, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
//     var7.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.Marker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var3.drawDomainMarker(var6, (org.jfree.chart.plot.XYPlot)var7, var11, var12, var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
//     boolean var19 = var18.isInverted();
//     var18.setAutoRangeMinimumSize(0.025d);
//     org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var24 = var23.getTickLabelPaint();
//     java.lang.Class var25 = var23.getMajorTickTimePeriodClass();
//     java.awt.Paint var26 = var23.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var28 = var27.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var29 = var27.getLegendItems();
//     java.awt.Stroke var30 = var27.getDomainCrosshairStroke();
//     var23.setMinorTickMarkStroke(var30);
//     var23.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var37 = var36.getTickLabelPaint();
//     java.lang.Class var38 = var36.getMajorTickTimePeriodClass();
//     java.lang.Class var39 = org.jfree.data.time.RegularTimePeriod.downsize(var38);
//     java.lang.ClassLoader var40 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var39);
//     var23.setMinorTickTimePeriodClass(var39);
//     org.jfree.chart.util.Layer var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     var3.drawAnnotations(var15, var16, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var23, var42, var43);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var4.setAutoPopulateSeriesShape(true);
    var4.setDrawOutlines(false);
    java.awt.Shape var9 = var4.getLegendLine();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var12 = var11.getTickLabelPaint();
    var11.setUpperMargin(0.0d);
    java.awt.Paint var15 = var11.getLabelPaint();
    org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var16.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var16.setBaseLinesVisible(true);
    java.awt.Stroke var23 = var16.lookupSeriesStroke(0);
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var25 = var24.getDomainMinorGridlineStroke();
    var24.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var24.drawBackgroundImage(var28, var29);
    java.awt.Paint var31 = var24.getRangeZeroBaselinePaint();
    java.awt.Color var34 = java.awt.Color.getColor("hi!", 100);
    int var35 = var34.getBlue();
    var24.setRangeMinorGridlinePaint((java.awt.Paint)var34);
    float[] var46 = new float[] { 0.0f, 10.0f, 100.0f};
    float[] var47 = java.awt.Color.RGBtoHSB((-1), 0, 10, var46);
    float[] var48 = java.awt.Color.RGBtoHSB(1, 3, (-435), var46);
    float[] var49 = var34.getColorComponents(var48);
    org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("WMAP_Plot", "TextAnchor.TOP_CENTER", "Polar Plot", "RectangleAnchor.CENTER", var9, var15, var23, (java.awt.Paint)var34);
    var50.setDatasetIndex(70);
    java.awt.Stroke var53 = var50.getLineStroke();
    java.io.ObjectOutputStream var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var53, var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    java.text.NumberFormat var1 = null;
    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Category Plot", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.labels.XYToolTipGenerator var4 = null;
    org.jfree.chart.urls.XYURLGenerator var5 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var4, var5);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var6.notifyListeners(var7);
    org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var10 = var9.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var11 = null;
    var9.setDrawingSupplier(var11);
    var6.setPlot((org.jfree.chart.plot.XYPlot)var9);
    var0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var6);
    org.jfree.chart.axis.AxisSpace var15 = var0.getFixedRangeAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    boolean var9 = var0.isRangePannable();
    boolean var10 = var0.isOutlineVisible();
    boolean var11 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var14 = var13.getRangeAxis();
    java.awt.Paint var15 = var13.getDomainGridlinePaint();
    org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var18 = var17.getStroke();
    double var19 = var17.getValue();
    var13.addDomainMarker((org.jfree.chart.plot.Marker)var17);
    java.awt.Paint var21 = var17.getPaint();
    org.jfree.chart.util.Layer var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, (org.jfree.chart.plot.Marker)var17, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }
// 
// 
//     java.text.DateFormat var1 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
//     org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
//     org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var3, (org.jfree.chart.urls.XYURLGenerator)var5);
//     var6.setSeriesShapesVisible(3, false);
//     boolean var10 = var6.getBaseShapesFilled();
//     java.awt.Paint var14 = var6.getItemOutlinePaint(0, (-1), false);
//     org.jfree.chart.labels.XYToolTipGenerator var17 = null;
//     org.jfree.chart.urls.XYURLGenerator var18 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var17, var18);
//     org.jfree.chart.urls.XYURLGenerator var23 = var19.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var24 = null;
//     var19.setBaseURLGenerator(var24, false);
//     java.awt.Paint var30 = var19.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var31 = var19.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var33 = null;
//     var19.setSeriesOutlinePaint(0, var33, false);
//     boolean var36 = var19.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var39 = var38.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var40 = var38.getLegendItems();
//     java.awt.Stroke var41 = var38.getDomainCrosshairStroke();
//     var19.setSeriesOutlineStroke(1, var41);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var44 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
//     var19.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var44);
//     java.lang.String var46 = var44.getFormatString();
//     org.jfree.chart.urls.StandardXYURLGenerator var48 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1, (org.jfree.chart.labels.XYToolTipGenerator)var44, (org.jfree.chart.urls.XYURLGenerator)var48);
//     var6.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var44);
//     
//     // Checks the contract:  equals-hashcode on var5 and var48
//     assertTrue("Contract failed: equals-hashcode on var5 and var48", var5.equals(var48) ? var5.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var5
//     assertTrue("Contract failed: equals-hashcode on var48 and var5", var48.equals(var5) ? var48.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    java.awt.Paint var36 = var7.getLabelBackgroundPaint();
    java.awt.Color var40 = java.awt.Color.getColor("hi!", 100);
    int var41 = var40.getBlue();
    java.awt.Color var42 = var40.darker();
    int var43 = var42.getBlue();
    java.awt.color.ColorSpace var44 = var42.getColorSpace();
    var7.setSectionOutlinePaint((java.lang.Comparable)644288400000L, (java.awt.Paint)var42);
    org.jfree.chart.labels.StandardPieToolTipGenerator var46 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var47 = var46.getPercentFormat();
    var7.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator)var46);
    org.jfree.chart.axis.PeriodAxis var50 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var51 = var50.getTickLabelPaint();
    java.lang.Class var52 = var50.getMajorTickTimePeriodClass();
    java.awt.Paint var53 = var50.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var55 = null;
    org.jfree.chart.urls.XYURLGenerator var56 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var57 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var55, var56);
    org.jfree.chart.event.RendererChangeEvent var58 = null;
    var57.notifyListeners(var58);
    var57.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var63 = var57.getBaseShape();
    var50.setLeftArrow(var63);
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.clone(var63);
    org.jfree.data.general.DefaultPieDataset var66 = new org.jfree.data.general.DefaultPieDataset();
    int var67 = var66.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var71 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var72 = var71.getSize();
    org.jfree.chart.entity.PieSectionEntity var75 = new org.jfree.chart.entity.PieSectionEntity(var65, (org.jfree.data.general.PieDataset)var66, 100, (-1), (java.lang.Comparable)var71, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var75.setSectionKey((java.lang.Comparable)(byte)(-1));
    java.awt.Shape var78 = var75.getArea();
    var7.setLegendItemShape(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
//     org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var6 = null;
//     var4.setSeriesURLGenerator(10, var6);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = null;
//     var4.setSeriesURLGenerator(3, var9, true);
//     int var12 = var4.getPassCount();
//     org.jfree.chart.renderer.category.BarPainter var13 = var4.getBarPainter();
//     var4.setBaseSeriesVisible(true, true);
//     var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var4);
//     boolean var18 = var0.isRangeCrosshairLockedOnData();
//     var0.zoom(1.0E-5d);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var2 = var1.getRoundingMode();
    boolean var3 = var1.isGroupingUsed();
    org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, 0);
    java.math.RoundingMode var6 = var1.getRoundingMode();
    int var7 = var1.getMaximumFractionDigits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     float var2 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.event.TitleChangeEvent var4 = null;
//     var3.titleChanged(var4);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
//     org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
//     var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
//     java.awt.Paint var10 = null;
//     var9.setLabelBackgroundPaint(var10);
//     var9.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var15 = null;
//     org.jfree.chart.urls.XYURLGenerator var16 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
//     org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var22 = null;
//     var17.setBaseURLGenerator(var22, false);
//     java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var17.getBaseNegativeItemLabelPosition();
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", 100);
//     int var33 = var32.getBlue();
//     var17.setBaseLegendTextPaint((java.awt.Paint)var32);
//     var9.setLabelOutlinePaint((java.awt.Paint)var32);
//     var1.setTickLabelPaint((java.awt.Paint)var32);
//     java.awt.Font var38 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("", var38, (org.jfree.chart.plot.Plot)var39, false);
//     java.lang.Object var42 = var41.getTextAntiAlias();
//     java.awt.Paint var43 = var41.getBackgroundPaint();
//     var1.setGridBandAlternatePaint(var43);
//     java.awt.Paint var45 = var1.getRangeGridlinePaint();
//     org.jfree.chart.StandardChartTheme var47 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
//     java.awt.Paint var48 = var47.getTitlePaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var51 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var53 = null;
//     var51.setSeriesURLGenerator(10, var53);
//     org.jfree.chart.urls.CategoryURLGenerator var56 = null;
//     var51.setSeriesURLGenerator(3, var56, true);
//     int var59 = var51.getPassCount();
//     org.jfree.chart.renderer.category.BarPainter var60 = var51.getBarPainter();
//     var47.setBarPainter(var60);
//     java.awt.Font var63 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var64 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var66 = new org.jfree.chart.JFreeChart("", var63, (org.jfree.chart.plot.Plot)var64, false);
//     org.jfree.chart.axis.AxisSpace var67 = null;
//     var64.setFixedRangeAxisSpace(var67);
//     org.jfree.chart.axis.AxisLocation var69 = var64.getDomainAxisLocation();
//     java.awt.Paint var70 = var64.getDomainGridlinePaint();
//     var47.setItemLabelPaint(var70);
//     org.jfree.chart.plot.PieLabelLinkStyle var72 = var47.getLabelLinkStyle();
//     var1.setLabelLinkStyle(var72);
//     
//     // Checks the contract:  equals-hashcode on var39 and var64
//     assertTrue("Contract failed: equals-hashcode on var39 and var64", var39.equals(var64) ? var39.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var39
//     assertTrue("Contract failed: equals-hashcode on var64 and var39", var64.equals(var39) ? var64.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var66
//     assertTrue("Contract failed: equals-hashcode on var41 and var66", var41.equals(var66) ? var41.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var41
//     assertTrue("Contract failed: equals-hashcode on var66 and var41", var66.equals(var41) ? var66.hashCode() == var41.hashCode() : true);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
    var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
    java.awt.Paint var10 = null;
    var9.setLabelBackgroundPaint(var10);
    org.jfree.chart.util.Rotation var12 = var9.getDirection();
    java.awt.Paint var13 = var9.getLabelLinkPaint();
    java.awt.Paint var14 = var9.getBaseSectionPaint();
    org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
    var15.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var15);
    java.awt.Paint var23 = null;
    var22.setLabelBackgroundPaint(var23);
    var22.setInnerSeparatorExtension(0.0d);
    java.awt.Stroke var27 = var22.getLabelLinkStroke();
    org.jfree.chart.StandardChartTheme var29 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var30 = var29.getTitlePaint();
    java.awt.Paint var31 = var29.getLegendBackgroundPaint();
    java.awt.Color var34 = java.awt.Color.getColor("hi!", 100);
    int var35 = var34.getBlue();
    java.awt.Color var36 = var34.darker();
    var29.setWallPaint((java.awt.Paint)var36);
    java.awt.Paint var38 = var29.getShadowPaint();
    org.jfree.chart.labels.XYToolTipGenerator var40 = null;
    org.jfree.chart.urls.XYURLGenerator var41 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var40, var41);
    org.jfree.chart.urls.XYURLGenerator var46 = var42.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var47 = null;
    var42.setBaseURLGenerator(var47, false);
    java.awt.Paint var53 = var42.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var54 = var42.getBaseNegativeItemLabelPosition();
    java.awt.Paint var56 = null;
    var42.setSeriesOutlinePaint(0, var56, false);
    boolean var59 = var42.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var61 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var62 = var61.getRangeAxis();
    org.jfree.chart.LegendItemCollection var63 = var61.getLegendItems();
    java.awt.Stroke var64 = var61.getDomainCrosshairStroke();
    var42.setSeriesOutlineStroke(1, var64);
    java.awt.Stroke var69 = var42.getItemStroke(0, (-1), false);
    org.jfree.chart.plot.IntervalMarker var71 = new org.jfree.chart.plot.IntervalMarker((-1.0d), Double.NaN, var14, var27, var38, var69, 0.8f);
    var71.setEndValue(2.0d);
    double var74 = var71.getEndValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 2.0d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var3, (org.jfree.chart.urls.XYURLGenerator)var5);
    org.jfree.chart.labels.XYToolTipGenerator var8 = null;
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var10.notifyListeners(var11);
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var15 = null;
    var13.setDrawingSupplier(var15);
    var10.setPlot((org.jfree.chart.plot.XYPlot)var13);
    java.awt.Shape var19 = var10.lookupSeriesShape(2147483647);
    var6.setLegendLine(var19);
    java.lang.Object var21 = var6.clone();
    org.jfree.chart.plot.XYPlot var22 = var6.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }
// 
// 
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     java.lang.String var5 = var4.getRangeDescription();
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     int var10 = var9.getMaximumItemCount();
//     java.text.NumberFormat var11 = java.text.NumberFormat.getNumberInstance();
//     boolean var12 = var9.equals((java.lang.Object)var11);
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     int var17 = var16.getMaximumItemCount();
//     java.beans.PropertyChangeListener var18 = null;
//     var16.removePropertyChangeListener(var18);
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     java.lang.String var24 = var23.getRangeDescription();
//     org.jfree.data.time.TimeSeries var25 = var16.addAndOrUpdate(var23);
//     org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var28 = var27.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var29 = var27.getLabelInsets();
//     boolean var30 = var27.isAxisLineVisible();
//     var27.setPositiveArrowVisible(false);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.getFirst();
//     var25.delete(var33);
//     org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var37 = var36.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getLabelInsets();
//     boolean var39 = var36.isAxisLineVisible();
//     var36.setPositiveArrowVisible(false);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.getFirst();
//     org.jfree.data.time.TimeSeries var43 = var9.createCopy(var33, var42);
//     var4.add(var42, (java.lang.Number)(short)100, true);
//     long var47 = var42.getMiddleMillisecond();
//     org.jfree.data.time.Year var49 = new org.jfree.data.time.Year(10);
//     java.lang.String var50 = var49.toString();
//     java.lang.String var51 = var49.toString();
//     org.jfree.chart.axis.PeriodAxis var53 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var54 = var53.getTickLabelPaint();
//     java.lang.Class var55 = var53.getMajorTickTimePeriodClass();
//     java.awt.Paint var56 = var53.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var58 = null;
//     org.jfree.chart.urls.XYURLGenerator var59 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var60 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var58, var59);
//     org.jfree.chart.event.RendererChangeEvent var61 = null;
//     var60.notifyListeners(var61);
//     var60.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var66 = var60.getBaseShape();
//     var53.setLeftArrow(var66);
//     var53.setRangeWithMargins(0.025d, 4.0d);
//     java.util.TimeZone var71 = var53.getTimeZone();
//     java.util.Locale var72 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.axis.PeriodAxis var73 = new org.jfree.chart.axis.PeriodAxis("Value", var42, (org.jfree.data.time.RegularTimePeriod)var49, var71, var72);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + ""+ "'", var24.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419191999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "10"+ "'", var50.equals("10"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + "10"+ "'", var51.equals("10"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var9);
    double var12 = var9.getDomainUpperBound(true);
    org.jfree.data.xy.IntervalXYDelegate var14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var9, false);
    double var16 = var14.getDomainLowerBound(false);
    org.jfree.data.Range var18 = var14.getDomainBounds(true);
    org.jfree.data.Range var20 = var14.getDomainBounds(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance(var0);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesShape(true);
    var0.setDrawOutlines(false);
    java.awt.Font var6 = var0.getLegendTextFont(0);
    double var7 = var0.getStepPoint();
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var12 = var11.getMaximumItemCount();
    java.text.NumberFormat var13 = java.text.NumberFormat.getNumberInstance();
    boolean var14 = var11.equals((java.lang.Object)var13);
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var19 = var18.getMaximumItemCount();
    java.beans.PropertyChangeListener var20 = null;
    var18.removePropertyChangeListener(var20);
    org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var26 = var25.getRangeDescription();
    org.jfree.data.time.TimeSeries var27 = var18.addAndOrUpdate(var25);
    org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var30 = var29.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var31 = var29.getLabelInsets();
    boolean var32 = var29.isAxisLineVisible();
    var29.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var35 = var29.getFirst();
    var27.delete(var35);
    org.jfree.chart.axis.PeriodAxis var38 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var39 = var38.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var40 = var38.getLabelInsets();
    boolean var41 = var38.isAxisLineVisible();
    var38.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var44 = var38.getFirst();
    org.jfree.data.time.TimeSeries var45 = var11.createCopy(var35, var44);
    boolean var46 = var0.equals((java.lang.Object)var45);
    java.lang.Class var47 = var45.getTimePeriodClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + ""+ "'", var26.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
//     org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
//     var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
//     java.awt.Paint var10 = null;
//     var9.setLabelBackgroundPaint(var10);
//     var9.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var15 = null;
//     org.jfree.chart.urls.XYURLGenerator var16 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
//     org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var22 = null;
//     var17.setBaseURLGenerator(var22, false);
//     java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var17.getBaseNegativeItemLabelPosition();
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", 100);
//     int var33 = var32.getBlue();
//     var17.setBaseLegendTextPaint((java.awt.Paint)var32);
//     var9.setLabelOutlinePaint((java.awt.Paint)var32);
//     var1.setTickLabelPaint((java.awt.Paint)var32);
//     java.awt.Font var38 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("", var38, (org.jfree.chart.plot.Plot)var39, false);
//     java.lang.Object var42 = var41.getTextAntiAlias();
//     java.awt.Paint var43 = var41.getBackgroundPaint();
//     var1.setGridBandAlternatePaint(var43);
//     org.jfree.chart.plot.CombinedDomainXYPlot var45 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var46 = var45.getDomainMinorGridlineStroke();
//     var45.setDomainCrosshairVisible(false);
//     java.awt.Paint var49 = var45.getRangeCrosshairPaint();
//     var1.setChartBackgroundPaint(var49);
//     
//     // Checks the contract:  equals-hashcode on var39 and var45
//     assertTrue("Contract failed: equals-hashcode on var39 and var45", var39.equals(var45) ? var39.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var39
//     assertTrue("Contract failed: equals-hashcode on var45 and var39", var45.equals(var39) ? var45.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var1);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var2 = var1.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(10.0d, 100.0d, var5, var6);
    var1.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var11 = null;
    org.jfree.chart.urls.XYURLGenerator var12 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var11, var12);
    org.jfree.chart.urls.XYURLGenerator var17 = var13.getURLGenerator(0, 1, true);
    var13.setBaseSeriesVisibleInLegend(false);
    int var20 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var13);
    org.jfree.chart.plot.CombinedDomainXYPlot var21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var22 = var21.getDomainMinorGridlineStroke();
    var21.setDomainCrosshairVisible(false);
    java.awt.Paint var25 = var21.getRangeCrosshairPaint();
    var13.setBaseLegendTextPaint(var25);
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("900,000", var25);
    boolean var28 = var27.isShapeVisible();
    org.jfree.data.general.DefaultPieDataset var29 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var32 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var29, (java.lang.Comparable)"hi!", 10.0d);
    var29.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var29);
    java.awt.Paint var37 = null;
    var36.setLabelBackgroundPaint(var37);
    var36.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var42 = null;
    org.jfree.chart.urls.XYURLGenerator var43 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var42, var43);
    org.jfree.chart.urls.XYURLGenerator var48 = var44.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var49 = null;
    var44.setBaseURLGenerator(var49, false);
    java.awt.Paint var55 = var44.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var56 = var44.getBaseNegativeItemLabelPosition();
    java.awt.Color var59 = java.awt.Color.getColor("hi!", 100);
    int var60 = var59.getBlue();
    var44.setBaseLegendTextPaint((java.awt.Paint)var59);
    var36.setLabelOutlinePaint((java.awt.Paint)var59);
    org.jfree.chart.labels.PieSectionLabelGenerator var63 = var36.getLabelGenerator();
    java.awt.Shape var64 = var36.getLegendItemShape();
    java.awt.Shape var65 = null;
    boolean var66 = org.jfree.chart.util.ShapeUtilities.equal(var64, var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var27.setShape(var65);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    var9.setKey((java.lang.Comparable)2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.update((java.lang.Number)0.025d, (java.lang.Number)0.8f);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var2 = var1.getTitlePaint();
    java.awt.Paint var3 = var1.getLegendBackgroundPaint();
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 100);
    int var7 = var6.getBlue();
    java.awt.Color var8 = var6.darker();
    var1.setLegendBackgroundPaint((java.awt.Paint)var8);
    float[] var19 = new float[] { 0.0f, 10.0f, 100.0f};
    float[] var20 = java.awt.Color.RGBtoHSB((-1), 0, 10, var19);
    float[] var21 = java.awt.Color.RGBtoHSB(1, 3, (-435), var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var22 = var8.getRGBComponents(var21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    org.jfree.chart.labels.XYToolTipGenerator var5 = null;
    org.jfree.chart.urls.XYURLGenerator var6 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var5, var6);
    org.jfree.chart.event.RendererChangeEvent var8 = null;
    var7.notifyListeners(var8);
    var7.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var13 = var7.getBaseShape();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setAnchorValue(Double.NaN);
    java.lang.Comparable var17 = var14.getDomainCrosshairRowKey();
    var14.clearDomainMarkers();
    java.awt.Paint var19 = var14.getNoDataMessagePaint();
    org.jfree.chart.labels.XYToolTipGenerator var21 = null;
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
    org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var28 = null;
    var23.setBaseURLGenerator(var28, false);
    java.awt.Paint var34 = var23.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var35 = var23.getBaseNegativeItemLabelPosition();
    java.awt.Paint var37 = null;
    var23.setSeriesOutlinePaint(0, var37, false);
    boolean var40 = var23.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var43 = var42.getRangeAxis();
    org.jfree.chart.LegendItemCollection var44 = var42.getLegendItems();
    java.awt.Stroke var45 = var42.getDomainCrosshairStroke();
    var23.setSeriesOutlineStroke(1, var45);
    java.awt.Stroke var50 = var23.getItemStroke(0, (-1), false);
    org.jfree.chart.StandardChartTheme var52 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var53 = var52.getTitlePaint();
    java.awt.Paint var54 = var52.getLegendBackgroundPaint();
    java.awt.Color var57 = java.awt.Color.getColor("hi!", 100);
    int var58 = var57.getBlue();
    java.awt.Color var59 = var57.darker();
    var52.setWallPaint((java.awt.Paint)var59);
    int var61 = var59.getTransparency();
    org.jfree.chart.LegendItem var62 = new org.jfree.chart.LegendItem("{0}: ({1}, {2})", "Jan", "Combined Range XYPlot", "{0}: ({1}, {2})", var13, var19, var50, (java.awt.Paint)var59);
    var62.setSeriesIndex(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    var3.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
    var3.setBaseItemLabelGenerator(var10);
    java.awt.Font var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
    var16.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var20 = var19.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
    var16.setPadding(var21);
    org.jfree.chart.event.ChartChangeEventType var23 = null;
    org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var16, var23);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("100");
    boolean var27 = var26.getNotify();
    int var28 = var26.getMaximumLinesToDisplay();
    var16.addSubtitle((org.jfree.chart.title.Title)var26);
    var26.setURLText("Jan");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2147483647);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    boolean var13 = var2.getAutoPopulateSeriesPaint();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
    int var18 = var17.getBlue();
    var2.setSeriesOutlinePaint(0, (java.awt.Paint)var17, true);
    java.lang.Boolean var22 = var2.getSeriesItemLabelsVisible(2147483647);
    org.jfree.chart.labels.XYToolTipGenerator var24 = null;
    org.jfree.chart.urls.XYURLGenerator var25 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var24, var25);
    org.jfree.chart.urls.XYURLGenerator var30 = var26.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var31 = null;
    var26.setBaseURLGenerator(var31, false);
    java.awt.Paint var37 = var26.getItemFillPaint(10, 100, false);
    org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var40 = var39.getTickLabelPaint();
    var26.setBasePaint(var40);
    var2.setBaseOutlinePaint(var40);
    var2.setBaseCreateEntities(true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var45 = var2.getLegendItemURLGenerator();
    double var46 = var2.getYOffset();
    java.awt.Font var50 = var2.getItemLabelFont(10, (-435), false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    java.lang.Comparable var3 = var0.getDomainCrosshairRowKey();
    var0.clearDomainMarkers();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 100);
    int var8 = var7.getBlue();
    java.awt.Color var9 = var7.darker();
    int var10 = var9.getBlue();
    var0.setRangeCrosshairPaint((java.awt.Paint)var9);
    org.jfree.chart.annotations.CategoryAnnotation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 70);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }
// 
// 
//     org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var3 = var2.getFont();
//     org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
//     boolean var6 = var4.equals((java.lang.Object)var5);
//     org.jfree.data.Range var9 = new org.jfree.data.Range(0.2d, 0.2d);
//     var5.setRange(var9, true, false);
//     org.jfree.data.Range var14 = org.jfree.data.Range.scale(var9, 0.0d);
//     org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange(var14);
//     java.util.Date var16 = var15.getUpperDate();
//     org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var20 = var19.getFont();
//     org.jfree.chart.text.TextLine var21 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var20);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     boolean var23 = var21.equals((java.lang.Object)var22);
//     org.jfree.data.Range var26 = new org.jfree.data.Range(0.2d, 0.2d);
//     var22.setRange(var26, false, true);
//     java.util.TimeZone var30 = var22.getTimeZone();
//     java.util.Locale var31 = null;
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year(var16, var30, var31);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    java.awt.Stroke var12 = var7.getLabelLinkStroke();
    java.lang.String var13 = var7.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    var1.setCategoryLabelPositionOffset(2147483647);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var7.setDrawingSupplier(var9);
    float var11 = var7.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var15 = null;
    org.jfree.chart.urls.XYURLGenerator var16 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
    org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    var17.setBaseURLGenerator(var22, false);
    java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
    var13.setLabelPaint(var28);
    float var30 = var13.getAlpha();
    org.jfree.chart.util.Layer var31 = null;
    boolean var32 = var7.removeDomainMarker((org.jfree.chart.plot.Marker)var13, var31);
    org.jfree.chart.util.RectangleEdge var33 = var7.getRangeAxisEdge();
    org.jfree.chart.axis.AxisState var34 = null;
    var1.drawTickMarks(var4, 10.0d, var6, var33, var34);
    var1.setTickLabelsVisible(false);
    org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var40 = var39.getCategoryLabelPositions();
    var1.setCategoryLabelPositions(var40);
    java.lang.String var42 = var1.getLabel();
    var1.setLowerMargin(5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "hi!"+ "'", var42.equals("hi!"));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    java.lang.Class var2 = null;
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var5 = var4.getTickLabelPaint();
    java.lang.Class var6 = var4.getMajorTickTimePeriodClass();
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var2, var6);
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var10 = var9.getTickLabelPaint();
    var9.zoomRange(1.0d, 100.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var15 = var14.getDomainMinorGridlineStroke();
    var9.setAxisLineStroke(var15);
    boolean var17 = var9.isTickMarksVisible();
    boolean var18 = var9.isAutoTickUnitSelection();
    var9.setAutoTickUnitSelection(true, true);
    org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var24 = var23.getTickLabelPaint();
    java.lang.Class var25 = var23.getMajorTickTimePeriodClass();
    java.lang.Class var26 = org.jfree.data.time.RegularTimePeriod.downsize(var25);
    java.lang.ClassLoader var27 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var26);
    var9.setMinorTickTimePeriodClass(var26);
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("{0}: ({1}, {2})", var2, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.setUpperMargin(0.0d);
    var1.setRange(10.0d, 10.0d);
    java.awt.Paint var8 = var1.getTickLabelPaint();
    var1.resizeRange2(0.2d, 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var4 = var3.getFont();
    org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var4);
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var7);
    double var9 = var8.getGap();
    var8.setOutlineVisible(true);
    var8.setRangeCrosshairVisible(true);
    java.lang.String var14 = var8.getPlotType();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("TextAnchor.TOP_CENTER", var4, (org.jfree.chart.plot.Plot)var8, true);
    org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var18 = var17.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.RenderingSource var22 = null;
    var17.select(10.0d, 100.0d, var21, var22);
    var17.setOutlineVisible(false);
    boolean var26 = var17.isRangePannable();
    var17.setGap(3.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var30 = var29.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var31 = null;
    var29.setDrawingSupplier(var31);
    float var33 = var29.getForegroundAlpha();
    boolean var34 = var29.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var35 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var29.add((org.jfree.chart.plot.XYPlot)var35, 100);
    java.awt.Stroke var38 = var29.getDomainCrosshairStroke();
    org.jfree.chart.event.PlotChangeEvent var39 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var29);
    var17.plotChanged(var39);
    org.jfree.chart.JFreeChart var41 = var39.getChart();
    var16.plotChanged(var39);
    var16.setTextAntiAlias(false);
    org.jfree.chart.plot.Plot var45 = var16.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "Combined Range XYPlot"+ "'", var14.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
    java.awt.Paint var17 = null;
    var3.setSeriesOutlinePaint(0, var17, false);
    java.awt.Paint var21 = var3.getLegendTextPaint((-1));
    org.jfree.chart.labels.XYItemLabelGenerator var22 = null;
    var3.setBaseItemLabelGenerator(var22);
    java.awt.Shape var25 = null;
    var3.setSeriesShape(100, var25, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelTextAnchor(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    java.lang.String var1 = var0.getPlotType();
    org.jfree.chart.renderer.WaferMapRenderer var2 = null;
    var0.setRenderer(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "WMAP_Plot"+ "'", var1.equals("WMAP_Plot"));

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
    org.jfree.data.xy.XYSeries var6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var7 = var6.clone();
    var6.add(0.0d, 100.0d, true);
    java.util.List var12 = var6.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxes((-435), var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    java.lang.String var1 = var0.getGPL();
    java.lang.String var2 = var0.getGPL();

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    java.util.List var8 = var7.getSeries();
    var7.clearSelection();
    java.util.List var10 = null;
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    boolean var13 = var12.isInverted();
    org.jfree.data.general.WaferMapDataset var14 = null;
    org.jfree.chart.renderer.WaferMapRenderer var15 = null;
    org.jfree.chart.plot.WaferMapPlot var16 = new org.jfree.chart.plot.WaferMapPlot(var14, var15);
    var12.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var19 = var18.getMinimumDate();
    org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var23 = var22.getFont();
    org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var23);
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
    boolean var26 = var24.equals((java.lang.Object)var25);
    org.jfree.data.Range var29 = new org.jfree.data.Range(0.2d, 0.2d);
    var25.setRange(var29, true, false);
    org.jfree.data.Range var34 = org.jfree.data.Range.scale(var29, 0.0d);
    var18.setRange(var29, false, false);
    double var38 = var29.getCentralValue();
    var12.setDefaultAutoRange(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var41 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset)var7, var10, var29, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.2d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(10);
    java.lang.String var3 = var2.toString();
    java.lang.String var4 = var2.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(255, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "10"+ "'", var3.equals("10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "10"+ "'", var4.equals("10"));

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     var3.fireSeriesChanged();
//     double var5 = var3.getMaxY();
//     var3.setMaximumItemAge(1L);
//     java.util.Collection var8 = var3.getTimePeriods();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var9 = var3.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var5.getRangeAxis();
    org.jfree.chart.LegendItemCollection var7 = var5.getLegendItems();
    java.awt.Stroke var8 = var5.getDomainCrosshairStroke();
    var1.setMinorTickMarkStroke(var8);
    var1.setRangeAboutValue(0.05d, 1.0E-5d);
    org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var15 = var14.getTickLabelPaint();
    java.lang.Class var16 = var14.getMajorTickTimePeriodClass();
    java.lang.Class var17 = org.jfree.data.time.RegularTimePeriod.downsize(var16);
    java.lang.ClassLoader var18 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var17);
    var1.setMinorTickTimePeriodClass(var17);
    org.jfree.chart.axis.PeriodAxisLabelInfo[] var20 = var1.getLabelInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    var0.configureDomainAxes();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var6 = var5.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var7 = var5.getLabelInsets();
    java.lang.String var8 = var7.toString();
    var0.setAxisOffset(var7);
    double var10 = var7.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.0d);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = null;
//     var2.setSeriesURLGenerator(3, var7, true);
//     int var10 = var2.getPassCount();
//     var2.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var2.getLegendItemLabelGenerator();
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var16 = var15.getTickLabelPaint();
//     java.lang.Class var17 = var15.getMajorTickTimePeriodClass();
//     java.awt.Paint var18 = var15.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var20 = null;
//     org.jfree.chart.urls.XYURLGenerator var21 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var20, var21);
//     org.jfree.chart.event.RendererChangeEvent var23 = null;
//     var22.notifyListeners(var23);
//     var22.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var28 = var22.getBaseShape();
//     var15.setLeftArrow(var28);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var28);
//     org.jfree.data.general.DefaultPieDataset var31 = new org.jfree.data.general.DefaultPieDataset();
//     int var32 = var31.getItemCount();
//     org.jfree.chart.axis.NumberTickUnit var36 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var37 = var36.getSize();
//     org.jfree.chart.entity.PieSectionEntity var40 = new org.jfree.chart.entity.PieSectionEntity(var30, (org.jfree.data.general.PieDataset)var31, 100, (-1), (java.lang.Comparable)var36, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var2.setBaseLegendShape(var30);
//     java.awt.Font var43 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var44 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", var43, (org.jfree.chart.plot.Plot)var44, false);
//     java.lang.Object var47 = var46.getTextAntiAlias();
//     java.awt.Paint var48 = var46.getBackgroundPaint();
//     org.jfree.chart.entity.JFreeChartEntity var51 = new org.jfree.chart.entity.JFreeChartEntity(var30, var46, "", "DatasetRenderingOrder.REVERSE");
//     org.jfree.chart.axis.PeriodAxis var53 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var54 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var53);
//     double var55 = var54.getGap();
//     var54.setOutlineVisible(true);
//     var54.clearRangeMarkers();
//     org.jfree.chart.labels.XYToolTipGenerator var60 = null;
//     org.jfree.chart.urls.XYURLGenerator var61 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var62 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var60, var61);
//     org.jfree.chart.event.RendererChangeEvent var63 = null;
//     var62.notifyListeners(var63);
//     var54.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var62);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var66 = var62.getLegendItemLabelGenerator();
//     java.awt.Stroke var67 = var62.getBaseOutlineStroke();
//     var46.setBorderStroke(var67);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var62 and var22.", var62.equals(var22) == var22.equals(var62));
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var3 = var2.getFont();
//     org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
//     boolean var6 = var4.equals((java.lang.Object)var5);
//     org.jfree.data.Range var9 = new org.jfree.data.Range(0.2d, 0.2d);
//     var5.setRange(var9, true, false);
//     org.jfree.data.Range var14 = org.jfree.data.Range.scale(var9, 0.0d);
//     org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange(var14);
//     java.lang.String var16 = var15.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var16.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.lang.Boolean var4 = var2.getSeriesShapesFilled(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.event.PlotChangeEvent var3 = null;
    var2.plotChanged(var3);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.setAnchorValue(Double.NaN);
    var7.configureDomainAxes();
    org.jfree.data.general.DefaultPieDataset var11 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var14 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var11, (java.lang.Comparable)"hi!", 10.0d);
    var11.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var11);
    java.awt.Paint var19 = null;
    var18.setLabelBackgroundPaint(var19);
    var18.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var24 = null;
    org.jfree.chart.urls.XYURLGenerator var25 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var24, var25);
    org.jfree.chart.urls.XYURLGenerator var30 = var26.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var31 = null;
    var26.setBaseURLGenerator(var31, false);
    java.awt.Paint var37 = var26.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var38 = var26.getBaseNegativeItemLabelPosition();
    java.awt.Color var41 = java.awt.Color.getColor("hi!", 100);
    int var42 = var41.getBlue();
    var26.setBaseLegendTextPaint((java.awt.Paint)var41);
    var18.setLabelOutlinePaint((java.awt.Paint)var41);
    var18.setAutoPopulateSectionOutlinePaint(true);
    var18.setIgnoreZeroValues(true);
    java.awt.Paint var49 = var18.getBaseSectionOutlinePaint();
    var7.setRangeMinorGridlinePaint(var49);
    org.jfree.chart.util.RectangleEdge var51 = var7.getDomainAxisEdge();
    org.jfree.chart.plot.PlotRenderingInfo var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var55 = var54.getDomainAxisEdge();
    var54.clearRangeMarkers(0);
    java.awt.Stroke var58 = var54.getDomainCrosshairStroke();
    org.jfree.chart.plot.PlotRenderingInfo var60 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var61 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var62 = var61.getRangeAxis();
    java.awt.Paint var63 = var61.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var64 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var61);
    java.awt.Image var65 = var61.getBackgroundImage();
    java.awt.geom.Point2D var66 = var61.getQuadrantOrigin();
    var54.panDomainAxes(0.0d, var60, var66);
    var7.zoomRangeAxes(0.08d, var53, var66, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.zoomDomainAxes(10.0d, var6, var66, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     double var4 = var3.getMinY();
//     var3.setMaximumItemCount(1);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(10);
//     java.lang.String var9 = var8.toString();
//     java.lang.String var10 = var8.toString();
//     org.jfree.data.time.TimeSeriesDataItem var11 = var3.getDataItem((org.jfree.data.time.RegularTimePeriod)var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.delete(10, 3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "10"+ "'", var9.equals("10"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "10"+ "'", var10.equals("10"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    boolean var12 = var7.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var13 = var7.getDataset();
    var7.setAutoPopulateSectionPaint(true);
    var7.setSectionOutlinesVisible(false);
    org.jfree.data.general.DefaultPieDataset var18 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var21 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var18, (java.lang.Comparable)"hi!", 10.0d);
    var18.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var25 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var18);
    java.awt.Paint var26 = null;
    var25.setLabelBackgroundPaint(var26);
    var25.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var31 = null;
    org.jfree.chart.urls.XYURLGenerator var32 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var31, var32);
    org.jfree.chart.urls.XYURLGenerator var37 = var33.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var38 = null;
    var33.setBaseURLGenerator(var38, false);
    java.awt.Paint var44 = var33.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var45 = var33.getBaseNegativeItemLabelPosition();
    java.awt.Color var48 = java.awt.Color.getColor("hi!", 100);
    int var49 = var48.getBlue();
    var33.setBaseLegendTextPaint((java.awt.Paint)var48);
    var25.setLabelOutlinePaint((java.awt.Paint)var48);
    org.jfree.chart.labels.PieSectionLabelGenerator var52 = var25.getLabelGenerator();
    var7.setLabelGenerator(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.add((org.jfree.chart.plot.XYPlot)var6, 100);
    java.awt.Stroke var9 = var0.getDomainCrosshairStroke();
    org.jfree.chart.event.PlotChangeEvent var10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    boolean var11 = var0.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    var4.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var8 = var7.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var9 = var7.getLabelInsets();
    var4.setPadding(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var13 = var4.createBufferedImage((-1), 255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    int var1 = var0.getItemCount();
    int var2 = var0.getItemCount();
    org.jfree.chart.util.SortOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByKeys(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var1, (java.lang.Comparable)"hi!", 10.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var1.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
    boolean var7 = var0.equals((java.lang.Object)var5);
    boolean var8 = var5.isSubplot();
    java.awt.Paint var9 = var5.getRangeTickBandPaint();
    var5.clearRangeMarkers(68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(2, var1);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var27 = var26.getTickLabelPaint();
    java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
    java.awt.Paint var29 = var26.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
    org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
    java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
    var26.setMinorTickMarkStroke(var33);
    var26.setRangeAboutValue(0.05d, 1.0E-5d);
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
    boolean var40 = var26.isAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    org.jfree.chart.labels.PieSectionLabelGenerator var34 = var7.getLabelGenerator();
    java.awt.Shape var35 = var7.getLegendItemShape();
    org.jfree.data.general.DefaultPieDataset var37 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var40 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var37, (java.lang.Comparable)"hi!", 10.0d);
    var37.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var44 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var37);
    java.awt.Paint var45 = null;
    var44.setLabelBackgroundPaint(var45);
    var44.setInnerSeparatorExtension(0.0d);
    boolean var49 = var44.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var50 = var44.getDataset();
    org.jfree.chart.axis.PeriodAxis var52 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var53 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var52);
    double var54 = var53.getGap();
    var53.setOutlineVisible(true);
    var53.clearRangeMarkers();
    org.jfree.chart.labels.XYToolTipGenerator var59 = null;
    org.jfree.chart.urls.XYURLGenerator var60 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var59, var60);
    org.jfree.chart.event.RendererChangeEvent var62 = null;
    var61.notifyListeners(var62);
    var53.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var61);
    org.jfree.chart.labels.XYSeriesLabelGenerator var65 = var61.getLegendItemLabelGenerator();
    java.awt.Stroke var66 = var61.getBaseOutlineStroke();
    var44.setSeparatorStroke(var66);
    var7.setSectionOutlineStroke((java.lang.Comparable)70, var66);
    boolean var69 = var7.getIgnoreNullValues();
    java.awt.Paint var70 = var7.getLabelPaint();
    double var71 = var7.getMaximumLabelWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.14d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("Polar Plot");

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var2 = var0.getSegment((-1L));
//     org.jfree.chart.axis.SegmentedTimeline var3 = var0.getBaseTimeline();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var5 = var3.getSegment(100L);
//     java.util.Date var6 = null;
//     var3.addBaseTimelineException(var6);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    boolean var13 = var0.isDomainZeroBaselineVisible();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var25 = null;
    var18.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var25);
    double var27 = var18.getCrosshairY();
    boolean var28 = var0.render(var14, var15, 10, var17, var18);
    var18.updateCrosshairY(0.05d);
    double var31 = var18.getCrosshairX();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var8 = null;
//     var6.setDrawingSupplier(var8);
//     var3.setPlot((org.jfree.chart.plot.XYPlot)var6);
//     java.awt.geom.GeneralPath var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.RenderingSource var13 = null;
//     var6.select(var11, var12, var13);
//     java.awt.Stroke var15 = var6.getRangeMinorGridlineStroke();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.setAnchorValue(Double.NaN);
//     var19.configureDomainAxes();
//     org.jfree.data.general.DefaultPieDataset var23 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var23, (java.lang.Comparable)"hi!", 10.0d);
//     var23.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var23);
//     java.awt.Paint var31 = null;
//     var30.setLabelBackgroundPaint(var31);
//     var30.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var36 = null;
//     org.jfree.chart.urls.XYURLGenerator var37 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var36, var37);
//     org.jfree.chart.urls.XYURLGenerator var42 = var38.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var43 = null;
//     var38.setBaseURLGenerator(var43, false);
//     java.awt.Paint var49 = var38.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var50 = var38.getBaseNegativeItemLabelPosition();
//     java.awt.Color var53 = java.awt.Color.getColor("hi!", 100);
//     int var54 = var53.getBlue();
//     var38.setBaseLegendTextPaint((java.awt.Paint)var53);
//     var30.setLabelOutlinePaint((java.awt.Paint)var53);
//     var30.setAutoPopulateSectionOutlinePaint(true);
//     var30.setIgnoreZeroValues(true);
//     java.awt.Paint var61 = var30.getBaseSectionOutlinePaint();
//     var19.setRangeMinorGridlinePaint(var61);
//     org.jfree.chart.util.RectangleEdge var63 = var19.getDomainAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var67 = var66.getDomainAxisEdge();
//     var66.clearRangeMarkers(0);
//     java.awt.Stroke var70 = var66.getDomainCrosshairStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var73 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var74 = var73.getRangeAxis();
//     java.awt.Paint var75 = var73.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var76 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var73);
//     java.awt.Image var77 = var73.getBackgroundImage();
//     java.awt.geom.Point2D var78 = var73.getQuadrantOrigin();
//     var66.panDomainAxes(0.0d, var72, var78);
//     var19.zoomRangeAxes(0.08d, var65, var78, true);
//     var18.setAnchor(var78);
//     org.jfree.chart.plot.PlotState var83 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var84 = null;
//     var6.draw(var16, var17, var78, var83, var84);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    org.jfree.data.general.WaferMapDataset var2 = var1.getDataset();
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    var1.setRenderer(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    var0.setBottom(2.0d);
    double var3 = var0.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    boolean var13 = var0.isDomainZeroBaselineVisible();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var25 = null;
    var18.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var25);
    double var27 = var18.getCrosshairY();
    boolean var28 = var0.render(var14, var15, 10, var17, var18);
    double var29 = var18.getCrosshairY();
    var18.setAnchorX((-5.76E7d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.general.DefaultPieDataset var26 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var26, (java.lang.Comparable)"hi!", 10.0d);
    java.util.List var30 = var26.getKeys();
    org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var34 = var33.getFont();
    org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var34);
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
    boolean var37 = var35.equals((java.lang.Object)var36);
    org.jfree.data.Range var40 = new org.jfree.data.Range(0.2d, 0.2d);
    var36.setRange(var40, true, false);
    org.jfree.data.Range var45 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset)var18, var30, var40, true);
    int var46 = var18.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    var9.add((org.jfree.chart.block.Block)var10);
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
    java.awt.Graphics2D var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    var0.drawAnnotations(var15, var16, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var17 = null;
//     var3.setSeriesOutlinePaint(0, var17, false);
//     boolean var20 = var3.isShapesFilled();
//     org.jfree.data.general.DefaultPieDataset var22 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var25 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var22, (java.lang.Comparable)"hi!", 10.0d);
//     var22.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var22);
//     java.awt.Paint var30 = null;
//     var29.setLabelBackgroundPaint(var30);
//     var29.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var35 = null;
//     org.jfree.chart.urls.XYURLGenerator var36 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var35, var36);
//     org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var42 = null;
//     var37.setBaseURLGenerator(var42, false);
//     java.awt.Paint var48 = var37.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var49 = var37.getBaseNegativeItemLabelPosition();
//     java.awt.Color var52 = java.awt.Color.getColor("hi!", 100);
//     int var53 = var52.getBlue();
//     var37.setBaseLegendTextPaint((java.awt.Paint)var52);
//     var29.setLabelOutlinePaint((java.awt.Paint)var52);
//     var29.setAutoPopulateSectionOutlinePaint(true);
//     var29.setIgnoreZeroValues(true);
//     java.awt.Paint var60 = var29.getBaseSectionOutlinePaint();
//     var3.setSeriesPaint(2, var60);
//     
//     // Checks the contract:  equals-hashcode on var15 and var49
//     assertTrue("Contract failed: equals-hashcode on var15 and var49", var15.equals(var49) ? var15.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var15
//     assertTrue("Contract failed: equals-hashcode on var49 and var15", var49.equals(var15) ? var49.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var8 = null;
    var6.setDrawingSupplier(var8);
    var3.setPlot((org.jfree.chart.plot.XYPlot)var6);
    java.awt.geom.GeneralPath var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.RenderingSource var13 = null;
    var6.select(var11, var12, var13);
    java.awt.Stroke var15 = var6.getRangeMinorGridlineStroke();
    org.jfree.data.xy.XYDataset var16 = var6.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.data.time.TimeSeries var9 = var7.getSeries((java.lang.Comparable)2);
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.removeSeries(70);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
    org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
    boolean var3 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var5 = var4.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.RenderingSource var9 = null;
    var4.select(10.0d, 100.0d, var8, var9);
    var4.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer();
    var13.add((org.jfree.chart.block.Block)var14);
    org.jfree.chart.block.Arrangement var16 = var13.getArrangement();
    org.jfree.chart.block.BorderArrangement var17 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4, var16, (org.jfree.chart.block.Arrangement)var17);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    org.jfree.chart.util.HorizontalAlignment var3 = var1.getHorizontalAlignment();
    var1.setToolTipText("hi!");
    org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("");
    boolean var8 = var1.equals((java.lang.Object)"");
    java.lang.Object var9 = var1.clone();
    boolean var10 = var1.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//     boolean var1 = var0.getUseFillPaint();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.Color var6 = java.awt.Color.getColor("hi!", 100);
//     int var7 = var6.getBlue();
//     java.awt.Color var8 = var6.darker();
//     java.awt.Color var9 = var8.brighter();
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.event.AxisChangeEvent var13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var12);
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var16 = var15.getTickLabelPaint();
//     var15.zoomRange(1.0d, 100.0d);
//     double var20 = var15.getLowerMargin();
//     org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var15);
//     org.jfree.chart.labels.XYToolTipGenerator var23 = null;
//     org.jfree.chart.urls.XYURLGenerator var24 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var23, var24);
//     org.jfree.chart.event.RendererChangeEvent var26 = null;
//     var25.notifyListeners(var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var30 = var29.getDomainMinorGridlineStroke();
//     var29.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.plot.Marker var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     var25.drawDomainMarker(var28, (org.jfree.chart.plot.XYPlot)var29, var33, var34, var35);
//     java.awt.Stroke var38 = var25.getSeriesStroke((-435));
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.xy.XYItemRenderer)var25);
//     boolean var40 = var8.equals((java.lang.Object)var12);
//     org.jfree.chart.axis.PeriodAxis var42 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var43 = var42.getTickLabelPaint();
//     var42.zoomRange(1.0d, 100.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var48 = var47.getDomainMinorGridlineStroke();
//     var42.setAxisLineStroke(var48);
//     boolean var50 = var42.isTickMarksVisible();
//     boolean var51 = var42.isTickLabelsVisible();
//     org.jfree.chart.util.Layer var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     var0.drawAnnotations(var2, var3, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var42, var52, var53);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = null;
    var0.setTickUnit(var1, true, true);
    org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var8 = var7.getFont();
    org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var8);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    boolean var11 = var9.equals((java.lang.Object)var10);
    var10.zoomRange(0.2d, 2.0d);
    org.jfree.chart.axis.DateTickUnit var15 = null;
    var10.setTickUnit(var15, true, true);
    org.jfree.chart.axis.SegmentedTimeline var19 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var21 = var20.getMinimumDate();
    boolean var22 = var19.containsDomainValue(var21);
    var10.setMaximumDate(var21);
    var0.setMaximumDate(var21);
    org.jfree.data.time.Year var25 = new org.jfree.data.time.Year(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var2 = var1.getMinimumDate();
    boolean var3 = var0.containsDomainValue(var2);
    var0.addException((-2208927600000L), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var2 = var1.getTitlePaint();
    java.awt.Paint var3 = var1.getLegendBackgroundPaint();
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 100);
    int var7 = var6.getBlue();
    java.awt.Color var8 = var6.darker();
    var1.setWallPaint((java.awt.Paint)var8);
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var13 = var12.getFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("Combined Range XYPlot", var13);
    var1.setRegularFont(var13);
    org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var17 = var16.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.RenderingSource var21 = null;
    var16.select(10.0d, 100.0d, var20, var21);
    var16.setOutlineVisible(false);
    boolean var25 = var16.isRangePannable();
    boolean var26 = var16.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var27 = var16.getLegendItems();
    java.awt.Paint var28 = var16.getOutlinePaint();
    var1.setSubtitlePaint(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.setUpperMargin(0.0d);
    java.awt.Paint var5 = var1.getLabelPaint();
    var1.resizeRange(5.0d);
    java.awt.Stroke var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkStroke(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var4 = var3.toUnconstrainedWidth();
    double var5 = var3.getWidth();
    org.jfree.chart.block.RectangleConstraint var6 = var3.toUnconstrainedHeight();
    double var7 = var6.getHeight();
    org.jfree.data.Range var8 = var6.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    var2.setOutlineVisible(true);
    var2.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var10 = var9.getDomainMinorGridlineStroke();
    org.jfree.chart.axis.AxisLocation var11 = var9.getRangeAxisLocation();
    var2.setRangeAxisLocation(68, var11, false);
    java.awt.Paint var14 = var2.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.awt.Image var4 = null;
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var4, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "100", "hi!");
    org.jfree.chart.ui.Library[] var9 = var8.getOptionalLibraries();
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var13, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "100", "hi!");
    java.util.List var18 = var17.getContributors();
    var8.addLibrary((org.jfree.chart.ui.Library)var17);
    var17.setLicenceText("hi!");
    org.jfree.chart.labels.XYToolTipGenerator var23 = null;
    org.jfree.chart.urls.XYURLGenerator var24 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var23, var24);
    org.jfree.chart.urls.XYURLGenerator var29 = var25.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var30 = null;
    var25.setBaseURLGenerator(var30, false);
    java.awt.Paint var36 = var25.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var38 = null;
    var25.setSeriesItemLabelGenerator(70, var38);
    org.jfree.data.xy.DefaultXYDataset var40 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var42 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var43 = var42.getSize();
    int var44 = var40.indexOf((java.lang.Comparable)var43);
    org.jfree.data.Range var45 = var25.findRangeBounds((org.jfree.data.xy.XYDataset)var40);
    org.jfree.data.Range var46 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var40);
    org.jfree.data.Range var47 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var40);
    org.jfree.data.general.DefaultPieDataset var48 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var51 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var48, (java.lang.Comparable)"hi!", 10.0d);
    java.util.List var52 = var48.getKeys();
    org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var56 = var55.getFont();
    org.jfree.chart.text.TextLine var57 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var56);
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
    boolean var59 = var57.equals((java.lang.Object)var58);
    org.jfree.data.Range var62 = new org.jfree.data.Range(0.2d, 0.2d);
    var58.setRange(var62, true, false);
    org.jfree.data.Range var67 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset)var40, var52, var62, true);
    var17.setContributors(var52);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var70 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var52, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    float var2 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var4 = var3.getBackgroundPaint();
    org.jfree.chart.event.ChartProgressListener var5 = null;
    var3.addProgressListener(var5);
    var3.setTextAntiAlias(true);
    var3.clearSubtitles();
    org.jfree.chart.title.LegendTitle var10 = var3.getLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var11 = var10.getRangeDescription();
    org.jfree.data.time.TimeSeries var12 = var3.addAndOrUpdate(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var10.getValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var2 = null;
//     var0.setDrawingSupplier(var2);
//     float var4 = var0.getForegroundAlpha();
//     boolean var5 = var0.isDomainZoomable();
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
//     var6.setDomainCrosshairVisible(false);
//     java.awt.Paint var10 = var6.getRangeCrosshairPaint();
//     float var11 = var6.getBackgroundImageAlpha();
//     var0.add((org.jfree.chart.plot.XYPlot)var6);
//     double var13 = var6.getGap();
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var6.drawOutline(var14, var15);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(2147483647, (-435), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setSeriesURLGenerator(3, var7, true);
    int var10 = var2.getRowCount();
    org.jfree.chart.StandardChartTheme var12 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var13 = var12.getTitlePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var16.setSeriesURLGenerator(10, var18);
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    var16.setSeriesURLGenerator(3, var21, true);
    int var24 = var16.getPassCount();
    org.jfree.chart.renderer.category.BarPainter var25 = var16.getBarPainter();
    var12.setBarPainter(var25);
    var2.setBarPainter(var25);
    org.jfree.chart.util.GradientPaintTransformer var28 = null;
    var2.setGradientPaintTransformer(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("AxisLocation.TOP_OR_RIGHT", var1, var2);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    java.lang.Object var5 = var4.getTextAntiAlias();
    var4.setBackgroundImageAlignment(2147483647);
    boolean var8 = var4.getAntiAlias();
    var4.setBackgroundImageAlpha(0.5f);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("100");
    java.lang.String var14 = var13.getText();
    java.lang.String var15 = var13.getURLText();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addSubtitle(15, (org.jfree.chart.title.Title)var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "100"+ "'", var14.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    double var1 = var0.getItemLabelAnchorOffset();
    var0.setIncludeBaseInRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }
// 
// 
//     org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
//     var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
//     java.awt.Paint var8 = null;
//     var7.setLabelBackgroundPaint(var8);
//     var7.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var13 = null;
//     org.jfree.chart.urls.XYURLGenerator var14 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
//     org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var20 = null;
//     var15.setBaseURLGenerator(var20, false);
//     java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
//     java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
//     int var31 = var30.getBlue();
//     var15.setBaseLegendTextPaint((java.awt.Paint)var30);
//     var7.setLabelOutlinePaint((java.awt.Paint)var30);
//     org.jfree.chart.labels.PieSectionLabelGenerator var34 = var7.getLabelGenerator();
//     java.awt.Shape var35 = var7.getLegendItemShape();
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var7.markerChanged(var36);
//     org.jfree.chart.util.Rotation var38 = var7.getDirection();
//     org.jfree.data.general.DefaultPieDataset var39 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var42 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var39, (java.lang.Comparable)"hi!", 10.0d);
//     var39.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var46 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var39);
//     java.awt.Paint var47 = null;
//     var46.setLabelBackgroundPaint(var47);
//     org.jfree.chart.util.Rotation var49 = var46.getDirection();
//     boolean var50 = var7.equals((java.lang.Object)var46);
//     org.jfree.data.general.DefaultPieDataset var51 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var54 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var51, (java.lang.Comparable)"hi!", 10.0d);
//     var51.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var58 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var51);
//     java.awt.Paint var59 = null;
//     var58.setLabelBackgroundPaint(var59);
//     org.jfree.chart.util.Rotation var61 = var58.getDirection();
//     java.awt.Paint var62 = var58.getLabelLinkPaint();
//     java.awt.Paint var63 = var58.getBaseSectionPaint();
//     org.jfree.chart.labels.PieSectionLabelGenerator var64 = var58.getLabelGenerator();
//     var7.setLegendLabelGenerator(var64);
//     
//     // Checks the contract:  equals-hashcode on var46 and var58
//     assertTrue("Contract failed: equals-hashcode on var46 and var58", var46.equals(var58) ? var46.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var46
//     assertTrue("Contract failed: equals-hashcode on var58 and var46", var58.equals(var46) ? var58.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    java.awt.Paint var5 = var3.lookupSeriesOutlinePaint(10);
    var3.setAutoPopulateSeriesOutlineStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.data.time.TimeSeries var9 = var7.getSeries((java.lang.Comparable)2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSelected((-1), 28, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    float var3 = var1.getMinorTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
//     java.awt.GradientPaint var2 = null;
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var5 = var4.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getLabelInsets();
//     var4.setMinorTickMarksVisible(false);
//     java.awt.Shape var9 = var4.getRightArrow();
//     java.awt.GradientPaint var10 = var0.transform(var2, var9);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-5.76E7d), 0.05d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    java.awt.Stroke var9 = var3.lookupSeriesStroke(0);
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var13 = var12.getTickLabelPaint();
    java.lang.Class var14 = var12.getMajorTickTimePeriodClass();
    java.awt.Paint var15 = var12.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var17 = null;
    org.jfree.chart.urls.XYURLGenerator var18 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var17, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = null;
    var19.notifyListeners(var20);
    var19.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var25 = var19.getBaseShape();
    var12.setLeftArrow(var25);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var25);
    var3.setLegendShape(100, var25);
    var3.setDataBoundsIncludesVisibleSeriesOnly(false);
    var3.clearSeriesPaints(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    java.lang.Object var4 = var3.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    boolean var6 = var2.isDrawBarOutline();
    org.jfree.chart.labels.XYToolTipGenerator var8 = null;
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var10.notifyListeners(var11);
    boolean var13 = var2.equals((java.lang.Object)var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.data.Range var16 = var2.findRangeBounds(var14, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
    int var18 = var17.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var23 = var22.getSize();
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity(var16, (org.jfree.data.general.PieDataset)var17, 100, (-1), (java.lang.Comparable)var22, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    java.lang.String var27 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "[size=1]"+ "'", var27.equals("[size=1]"));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    org.jfree.chart.axis.PeriodAxis var35 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var36 = var35.getTickLabelPaint();
    java.lang.Class var37 = var35.getMajorTickTimePeriodClass();
    java.awt.Paint var38 = var35.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var40 = null;
    org.jfree.chart.urls.XYURLGenerator var41 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var40, var41);
    org.jfree.chart.event.RendererChangeEvent var43 = null;
    var42.notifyListeners(var43);
    var42.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var48 = var42.getBaseShape();
    var35.setLeftArrow(var48);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.clone(var48);
    org.jfree.data.general.DefaultPieDataset var51 = new org.jfree.data.general.DefaultPieDataset();
    int var52 = var51.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var56 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var57 = var56.getSize();
    org.jfree.chart.entity.PieSectionEntity var60 = new org.jfree.chart.entity.PieSectionEntity(var50, (org.jfree.data.general.PieDataset)var51, 100, (-1), (java.lang.Comparable)var56, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    org.jfree.data.general.DefaultPieDataset var61 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var64 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var61, (java.lang.Comparable)"hi!", 10.0d);
    var61.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var68 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var61);
    java.awt.Paint var69 = null;
    var68.setLabelBackgroundPaint(var69);
    org.jfree.chart.util.Rotation var71 = var68.getDirection();
    int var72 = var56.compareTo((java.lang.Object)var71);
    var7.setDirection(var71);
    org.jfree.chart.renderer.xy.XYStepRenderer var74 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var74.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var74.setBaseLinesVisible(true);
    boolean var82 = var74.getItemShapeFilled(0, 1);
    java.awt.Shape var84 = var74.lookupSeriesShape((-1));
    java.awt.Shape var87 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var84, 3.0d, 1.0d);
    boolean var88 = var7.equals((java.lang.Object)var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(10.0d, "hi!", "TextAnchor.TOP_CENTER", true);
    java.text.NumberFormat var6 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("100", (java.text.NumberFormat)var5, var6);
    org.jfree.data.general.DefaultPieDataset var8 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var8, (java.lang.Comparable)"hi!", 10.0d);
    var8.setValue((java.lang.Comparable)"hi!", (-1.0d));
    java.text.AttributedString var16 = var7.generateAttributedSectionLabel((org.jfree.data.general.PieDataset)var8, (java.lang.Comparable)2);
    org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
    int var18 = var17.getItemCount();
    org.jfree.data.xy.XYDataItem var21 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
    boolean var22 = var21.isSelected();
    double var23 = var21.getXValue();
    var17.setValue((java.lang.Comparable)var23, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var27 = var7.generateSectionLabel((org.jfree.data.general.PieDataset)var17, (java.lang.Comparable)"java.awt.Color[r=0,g=0,b=100]");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100.0d);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     double var6 = var3.getItemLabelAnchorOffset();
//     var3.setBaseCreateEntities(false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var11 = var10.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.RenderingSource var15 = null;
//     var10.select(10.0d, 100.0d, var14, var15);
//     var10.clearDomainMarkers();
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.data.general.DefaultPieDataset var21 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var21, (java.lang.Comparable)"hi!", 10.0d);
//     var21.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var21);
//     java.awt.Paint var29 = null;
//     var28.setLabelBackgroundPaint(var29);
//     org.jfree.chart.util.Rotation var31 = var28.getDirection();
//     java.awt.Paint var32 = var28.getLabelLinkPaint();
//     java.awt.Paint var33 = var28.getBaseSectionPaint();
//     org.jfree.data.general.DefaultPieDataset var34 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var37 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var34, (java.lang.Comparable)"hi!", 10.0d);
//     var34.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var41 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var34);
//     java.awt.Paint var42 = null;
//     var41.setLabelBackgroundPaint(var42);
//     var41.setInnerSeparatorExtension(0.0d);
//     java.awt.Stroke var46 = var41.getLabelLinkStroke();
//     org.jfree.chart.StandardChartTheme var48 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
//     java.awt.Paint var49 = var48.getTitlePaint();
//     java.awt.Paint var50 = var48.getLegendBackgroundPaint();
//     java.awt.Color var53 = java.awt.Color.getColor("hi!", 100);
//     int var54 = var53.getBlue();
//     java.awt.Color var55 = var53.darker();
//     var48.setWallPaint((java.awt.Paint)var55);
//     java.awt.Paint var57 = var48.getShadowPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var59 = null;
//     org.jfree.chart.urls.XYURLGenerator var60 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var59, var60);
//     org.jfree.chart.urls.XYURLGenerator var65 = var61.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var66 = null;
//     var61.setBaseURLGenerator(var66, false);
//     java.awt.Paint var72 = var61.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var73 = var61.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var75 = null;
//     var61.setSeriesOutlinePaint(0, var75, false);
//     boolean var78 = var61.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var80 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var81 = var80.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var82 = var80.getLegendItems();
//     java.awt.Stroke var83 = var80.getDomainCrosshairStroke();
//     var61.setSeriesOutlineStroke(1, var83);
//     java.awt.Stroke var88 = var61.getItemStroke(0, (-1), false);
//     org.jfree.chart.plot.IntervalMarker var90 = new org.jfree.chart.plot.IntervalMarker((-1.0d), Double.NaN, var33, var46, var57, var88, 0.8f);
//     var90.setEndValue(2.0d);
//     java.awt.Stroke var93 = var90.getOutlineStroke();
//     java.awt.Stroke var94 = var90.getStroke();
//     java.awt.geom.Rectangle2D var95 = null;
//     var3.drawRangeMarker(var9, (org.jfree.chart.plot.XYPlot)var10, var18, (org.jfree.chart.plot.Marker)var90, var95);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(true);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var2);
    var3.setAutoTickUnitSelection(true);
    org.jfree.data.xy.XYDataItem var8 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
    boolean var9 = var8.isSelected();
    boolean var10 = var3.equals((java.lang.Object)var9);
    double var11 = var3.getLowerMargin();
    org.jfree.chart.util.LogFormat var16 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    java.text.NumberFormat var17 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var18 = var17.getRoundingMode();
    boolean var19 = var17.isGroupingUsed();
    java.text.NumberFormat var20 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var21 = var20.getRoundingMode();
    var17.setRoundingMode(var21);
    var16.setExponentFormat(var17);
    var3.setNumberFormatOverride(var17);
    boolean var25 = var3.isGridBandsVisible();
    java.lang.String var26 = var3.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    var9.add((org.jfree.chart.block.Block)var10);
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
    java.lang.Object var15 = null;
    boolean var16 = var14.equals(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)false, 5.0d);
    int var5 = var0.getItemCount();
    org.jfree.chart.util.SortOrder var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByValues(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var5 = var4.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.RenderingSource var9 = null;
    var4.select(10.0d, 100.0d, var8, var9);
    var4.setOutlineVisible(false);
    boolean var13 = var4.isRangePannable();
    boolean var14 = var4.isOutlineVisible();
    org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var16);
    double var18 = var17.getGap();
    var17.setOutlineVisible(true);
    var17.setRangeCrosshairVisible(true);
    java.lang.String var23 = var17.getPlotType();
    var4.remove((org.jfree.chart.plot.XYPlot)var17);
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var26 = var25.getMinimumDate();
    boolean var28 = var25.isHiddenValue(1L);
    org.jfree.chart.axis.LogAxis var30 = new org.jfree.chart.axis.LogAxis("rect");
    double var31 = var30.getSmallestValue();
    org.jfree.data.xy.DefaultXYDataset var32 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var34 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var35 = var34.getSize();
    int var36 = var32.indexOf((java.lang.Comparable)var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var3, (org.jfree.chart.plot.XYPlot)var4, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.data.xy.XYDataset)var32, 28, 1, true, 255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Combined Range XYPlot"+ "'", var23.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0E-100d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-1));

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
//     java.lang.Object var1 = null;
//     boolean var2 = var0.equals(var1);
//     org.jfree.data.general.DefaultPieDataset var3 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var3, (java.lang.Comparable)"hi!", 10.0d);
//     var3.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var3);
//     java.awt.Paint var11 = null;
//     var10.setLabelBackgroundPaint(var11);
//     org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.event.AxisChangeEvent var15 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var14);
//     var10.axisChanged(var15);
//     boolean var17 = var0.equals((java.lang.Object)var15);
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var19 = var18.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var20 = null;
//     var18.setDrawingSupplier(var20);
//     org.jfree.chart.axis.AxisSpace var22 = var18.getFixedDomainAxisSpace();
//     java.awt.Font var24 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("", var24, (org.jfree.chart.plot.Plot)var25, false);
//     var27.clearSubtitles();
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var31 = var30.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
//     var27.setPadding(var32);
//     double var35 = var32.calculateLeftInset(100.0d);
//     var18.setInsets(var32);
//     org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var38 = var37.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.RenderingSource var42 = null;
//     var37.select(10.0d, 100.0d, var41, var42);
//     var37.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var46 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var47 = new org.jfree.chart.block.BlockContainer();
//     var46.add((org.jfree.chart.block.Block)var47);
//     org.jfree.chart.block.Arrangement var49 = var46.getArrangement();
//     org.jfree.chart.block.BorderArrangement var50 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37, var49, (org.jfree.chart.block.Arrangement)var50);
//     java.awt.Paint var52 = var51.getItemPaint();
//     var18.setDomainTickBandPaint(var52);
//     java.awt.Paint var54 = var18.getDomainCrosshairPaint();
//     org.jfree.chart.axis.ValueAxis var55 = var18.getDomainAxis();
//     double var56 = var18.getGap();
//     boolean var57 = var0.equals((java.lang.Object)var56);
//     
//     // Checks the contract:  equals-hashcode on var0 and var50
//     assertTrue("Contract failed: equals-hashcode on var0 and var50", var0.equals(var50) ? var0.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var0
//     assertTrue("Contract failed: equals-hashcode on var50 and var0", var50.equals(var0) ? var50.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var11 = var10.getRangeDescription();
    org.jfree.data.time.TimeSeries var12 = var3.addAndOrUpdate(var10);
    org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var15 = var14.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var16 = var14.getLabelInsets();
    boolean var17 = var14.isAxisLineVisible();
    var14.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var20 = var14.getFirst();
    var12.delete(var20);
    java.lang.String var22 = var12.getRangeDescription();
    java.lang.String var23 = var12.getRangeDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Value"+ "'", var22.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Value"+ "'", var23.equals("Value"));

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var2.setFixedRangeAxisSpace(var5);
    org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var8 = org.jfree.chart.axis.AxisLocation.getOpposite(var7);
    org.jfree.chart.plot.PlotOrientation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var10 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var7, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.data.time.TimePeriodAnchor var8 = var7.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSelected(2147483647, 0, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    org.jfree.chart.util.PaintMap var0 = new org.jfree.chart.util.PaintMap();
    java.awt.Paint var2 = var0.getPaint((java.lang.Comparable)(-1));
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var7 = var6.getMaximumItemCount();
    java.text.NumberFormat var8 = java.text.NumberFormat.getNumberInstance();
    boolean var9 = var6.equals((java.lang.Object)var8);
    org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var14 = var13.getMaximumItemCount();
    java.beans.PropertyChangeListener var15 = null;
    var13.removePropertyChangeListener(var15);
    org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var21 = var20.getRangeDescription();
    org.jfree.data.time.TimeSeries var22 = var13.addAndOrUpdate(var20);
    org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var25 = var24.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var26 = var24.getLabelInsets();
    boolean var27 = var24.isAxisLineVisible();
    var24.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var30 = var24.getFirst();
    var22.delete(var30);
    org.jfree.chart.axis.PeriodAxis var33 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var34 = var33.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var35 = var33.getLabelInsets();
    boolean var36 = var33.isAxisLineVisible();
    var33.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var39 = var33.getFirst();
    org.jfree.data.time.TimeSeries var40 = var6.createCopy(var30, var39);
    java.awt.Paint var41 = var0.getPaint((java.lang.Comparable)var39);
    boolean var43 = var0.containsKey((java.lang.Comparable)"RectangleAnchor.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + ""+ "'", var21.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }
// 
// 
//     java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(true);
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var2);
//     var3.setAutoTickUnitSelection(true);
//     org.jfree.data.xy.XYDataItem var8 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
//     boolean var9 = var8.isSelected();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.AxisState var12 = new org.jfree.chart.axis.AxisState();
//     org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.RenderingSource var18 = null;
//     var13.select(10.0d, 100.0d, var17, var18);
//     var13.setOutlineVisible(false);
//     boolean var22 = var13.isRangePannable();
//     org.jfree.chart.plot.CombinedDomainXYPlot var23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var24 = var23.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.RenderingSource var28 = null;
//     var23.select(10.0d, 100.0d, var27, var28);
//     var23.setOutlineVisible(false);
//     org.jfree.chart.labels.XYToolTipGenerator var33 = null;
//     org.jfree.chart.urls.XYURLGenerator var34 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var33, var34);
//     org.jfree.chart.urls.XYURLGenerator var39 = var35.getURLGenerator(0, 1, true);
//     var35.setBaseSeriesVisibleInLegend(false);
//     int var42 = var23.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var35);
//     var13.add((org.jfree.chart.plot.XYPlot)var23);
//     java.awt.Paint var44 = var13.getRangeZeroBaselinePaint();
//     var13.setRangeMinorGridlinesVisible(true);
//     java.util.List var47 = var13.getAnnotations();
//     var12.setTicks(var47);
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.setAnchorValue(Double.NaN);
//     var50.configureDomainAxes();
//     org.jfree.data.general.DefaultPieDataset var54 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var57 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var54, (java.lang.Comparable)"hi!", 10.0d);
//     var54.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var61 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var54);
//     java.awt.Paint var62 = null;
//     var61.setLabelBackgroundPaint(var62);
//     var61.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var67 = null;
//     org.jfree.chart.urls.XYURLGenerator var68 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var69 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var67, var68);
//     org.jfree.chart.urls.XYURLGenerator var73 = var69.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var74 = null;
//     var69.setBaseURLGenerator(var74, false);
//     java.awt.Paint var80 = var69.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var81 = var69.getBaseNegativeItemLabelPosition();
//     java.awt.Color var84 = java.awt.Color.getColor("hi!", 100);
//     int var85 = var84.getBlue();
//     var69.setBaseLegendTextPaint((java.awt.Paint)var84);
//     var61.setLabelOutlinePaint((java.awt.Paint)var84);
//     var61.setAutoPopulateSectionOutlinePaint(true);
//     var61.setIgnoreZeroValues(true);
//     java.awt.Paint var92 = var61.getBaseSectionOutlinePaint();
//     var50.setRangeMinorGridlinePaint(var92);
//     org.jfree.chart.util.RectangleEdge var94 = var50.getDomainAxisEdge();
//     java.util.List var95 = var3.refreshTicks(var11, var12, var49, var94);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.event.AxisChangeEvent var3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var2);
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var6 = var5.getTickLabelPaint();
    var5.zoomRange(1.0d, 100.0d);
    double var10 = var5.getLowerMargin();
    org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.notifyListeners(var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var20 = var19.getDomainMinorGridlineStroke();
    var19.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var15.drawDomainMarker(var18, (org.jfree.chart.plot.XYPlot)var19, var23, var24, var25);
    java.awt.Stroke var28 = var15.getSeriesStroke((-435));
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.xy.XYItemRenderer)var15);
    float var30 = var2.getMinorTickMarkInsideLength();
    boolean var31 = var2.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     double var6 = var3.getItemLabelAnchorOffset();
//     var3.setBaseCreateEntities(false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var11 = var10.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.RenderingSource var15 = null;
//     var10.select(10.0d, 100.0d, var14, var15);
//     var10.setOutlineVisible(false);
//     org.jfree.chart.axis.PeriodAxis var20 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var21 = var20.getTickLabelPaint();
//     var10.setOutlinePaint(var21);
//     boolean var23 = var10.isDomainZeroBaselineVisible();
//     boolean var24 = var10.canSelectByPoint();
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     var26.zoomRange(1.0d, 100.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var32 = var31.getDomainMinorGridlineStroke();
//     var26.setAxisLineStroke(var32);
//     boolean var34 = var26.isTickMarksVisible();
//     boolean var35 = var26.isAutoTickUnitSelection();
//     java.lang.Object var36 = var26.clone();
//     var26.resizeRange(0.2d);
//     java.awt.geom.Rectangle2D var39 = null;
//     var3.drawDomainGridLine(var9, (org.jfree.chart.plot.XYPlot)var10, (org.jfree.chart.axis.ValueAxis)var26, var39, 2.0d);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    java.text.DateFormat var2 = null;
    java.text.NumberFormat var3 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var4 = var3.getRoundingMode();
    boolean var5 = var3.isGroupingUsed();
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("100", var2, var3);
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(68, (org.jfree.chart.labels.XYToolTipGenerator)var6, var7);
    boolean var9 = var8.getPlotShapes();
    org.jfree.chart.LegendItem var12 = var8.getLegendItem(3, 2147483647);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var13.zoomRangeAxes(0.0d, 10.0d, var16, var17);
    org.jfree.chart.axis.AxisSpace var19 = new org.jfree.chart.axis.AxisSpace();
    var13.setFixedDomainAxisSpace(var19, false);
    boolean var22 = var8.hasListener((java.util.EventListener)var13);
    boolean var23 = var8.getPlotShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setAxisLineVisible(false);
    var1.setMinorTickMarkInsideLength((-1.0f));
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.data.xy.XYSeries var13 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.awt.Font var15 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("", var15, (org.jfree.chart.plot.Plot)var16, false);
    org.jfree.chart.axis.AxisSpace var19 = null;
    var16.setFixedRangeAxisSpace(var19);
    org.jfree.chart.axis.AxisLocation var21 = var16.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var22 = var21.getOpposite();
    boolean var23 = var13.equals((java.lang.Object)var21);
    var8.setDomainAxisLocation(1, var21, true);
    org.jfree.chart.axis.AxisSpace var26 = null;
    var8.setFixedDomainAxisSpace(var26);
    org.jfree.chart.axis.AxisLocation var28 = var8.getRangeAxisLocation();
    org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var28);
    java.lang.String var30 = var29.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=AxisLocation.BOTTOM_OR_LEFT]"+ "'", var30.equals("org.jfree.chart.event.ChartChangeEvent[source=AxisLocation.BOTTOM_OR_LEFT]"));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var4 = var3.getFrame();
    org.jfree.chart.util.RectangleInsets var5 = var3.getPadding();
    var1.setLabelInsets(var5);
    org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var9 = var8.getCategoryLabelPositions();
    var1.setCategoryLabelPositions(var9);
    var1.setLabel("WMAP_Plot");
    var1.setMaximumCategoryLabelWidthRatio(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    java.util.List var4 = var0.getKeys();
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset)var0);
    java.awt.Stroke var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setLabelLinkStroke(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("PieSection: 100, -1(-1)");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(255);
    java.lang.Object var3 = var1.get(100);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
    var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
    java.awt.Paint var10 = null;
    var9.setLabelBackgroundPaint(var10);
    var9.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var15 = null;
    org.jfree.chart.urls.XYURLGenerator var16 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
    org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    var17.setBaseURLGenerator(var22, false);
    java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var29 = var17.getBaseNegativeItemLabelPosition();
    java.awt.Color var32 = java.awt.Color.getColor("hi!", 100);
    int var33 = var32.getBlue();
    var17.setBaseLegendTextPaint((java.awt.Paint)var32);
    var9.setLabelOutlinePaint((java.awt.Paint)var32);
    var1.setTickLabelPaint((java.awt.Paint)var32);
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var40 = null;
    org.jfree.chart.urls.XYURLGenerator var41 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var40, var41);
    org.jfree.chart.urls.XYURLGenerator var46 = var42.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var47 = null;
    var42.setBaseURLGenerator(var47, false);
    java.awt.Paint var53 = var42.getItemFillPaint(10, 100, false);
    var38.setLabelPaint(var53);
    float var55 = var38.getAlpha();
    java.awt.Paint var56 = var38.getOutlinePaint();
    java.awt.Paint var57 = var38.getOutlinePaint();
    var1.setLegendBackgroundPaint(var57);
    java.awt.Font var59 = var1.getSmallFont();
    java.awt.Font var61 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var62 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var64 = new org.jfree.chart.JFreeChart("", var61, (org.jfree.chart.plot.Plot)var62, false);
    java.lang.Object var65 = var64.getTextAntiAlias();
    var64.setBackgroundImageAlignment(2147483647);
    java.awt.RenderingHints var68 = var64.getRenderingHints();
    var64.clearSubtitles();
    org.jfree.chart.util.RectangleInsets var70 = var64.getPadding();
    var1.setAxisOffset(var70);
    java.awt.geom.Rectangle2D var72 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var73 = var70.createOutsetRectangle(var72);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    java.util.List var9 = var3.getItems();
    java.lang.Object var10 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var2 = var1.getTitlePaint();
    java.awt.Paint var3 = var1.getLegendBackgroundPaint();
    java.awt.Font var4 = var1.getSmallFont();
    org.jfree.chart.renderer.category.GradientBarPainter var8 = new org.jfree.chart.renderer.category.GradientBarPainter(Double.NaN, 0.08d, 100.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var10 = var9.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.RenderingSource var14 = null;
    var9.select(10.0d, 100.0d, var13, var14);
    var9.setOutlineVisible(false);
    boolean var18 = var9.isRangePannable();
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var20 = var19.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.RenderingSource var24 = null;
    var19.select(10.0d, 100.0d, var23, var24);
    var19.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var29 = null;
    org.jfree.chart.urls.XYURLGenerator var30 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var29, var30);
    org.jfree.chart.urls.XYURLGenerator var35 = var31.getURLGenerator(0, 1, true);
    var31.setBaseSeriesVisibleInLegend(false);
    int var38 = var19.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var31);
    var9.add((org.jfree.chart.plot.XYPlot)var19);
    java.awt.Color var42 = java.awt.Color.getColor("hi!", 100);
    int var43 = var42.getBlue();
    java.awt.Color var44 = var42.darker();
    java.awt.Color var45 = var44.brighter();
    org.jfree.data.xy.XYDataset var46 = null;
    org.jfree.chart.axis.PeriodAxis var48 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.event.AxisChangeEvent var49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var48);
    org.jfree.chart.axis.PeriodAxis var51 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var52 = var51.getTickLabelPaint();
    var51.zoomRange(1.0d, 100.0d);
    double var56 = var51.getLowerMargin();
    org.jfree.chart.plot.CombinedRangeXYPlot var57 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var51);
    org.jfree.chart.labels.XYToolTipGenerator var59 = null;
    org.jfree.chart.urls.XYURLGenerator var60 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var59, var60);
    org.jfree.chart.event.RendererChangeEvent var62 = null;
    var61.notifyListeners(var62);
    java.awt.Graphics2D var64 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var65 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var66 = var65.getDomainMinorGridlineStroke();
    var65.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.ValueAxis var69 = null;
    org.jfree.chart.plot.Marker var70 = null;
    java.awt.geom.Rectangle2D var71 = null;
    var61.drawDomainMarker(var64, (org.jfree.chart.plot.XYPlot)var65, var69, var70, var71);
    java.awt.Stroke var74 = var61.getSeriesStroke((-435));
    org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot(var46, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.chart.renderer.xy.XYItemRenderer)var61);
    boolean var76 = var44.equals((java.lang.Object)var48);
    int var77 = var19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var48);
    boolean var78 = var8.equals((java.lang.Object)var77);
    var1.setBarPainter((org.jfree.chart.renderer.category.BarPainter)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.add((org.jfree.chart.plot.XYPlot)var6, 100);
    var6.setDomainMinorGridlinesVisible(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var12 = var11.getRangeAxis();
    java.awt.Paint var13 = var11.getDomainGridlinePaint();
    var6.setParent((org.jfree.chart.plot.Plot)var11);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getRangeMarkers(var15);
    boolean var17 = var11.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(2.0d, 1.0E-5d, 1.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = null;
//     java.awt.geom.RectangularShape var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var11 = var10.getDomainAxisEdge();
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var14.setSeriesURLGenerator(10, var16);
//     org.jfree.chart.urls.CategoryURLGenerator var19 = null;
//     var14.setSeriesURLGenerator(3, var19, true);
//     int var22 = var14.getPassCount();
//     org.jfree.chart.renderer.category.BarPainter var23 = var14.getBarPainter();
//     var14.setBaseSeriesVisible(true, true);
//     var10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var10.getDomainMarkers(0, var29);
//     double var31 = var10.getRangeCrosshairValue();
//     org.jfree.chart.util.RectangleEdge var33 = var10.getRangeAxisEdge((-1));
//     var3.paintBar(var4, var5, 10, 70, false, var9, var33);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setSeriesURLGenerator(3, var7, true);
    int var10 = var2.getRowCount();
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
    var2.setBaseItemLabelGenerator(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.setValue((java.lang.Comparable)0.2d, (java.lang.Number)(byte)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)"Value");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(255);
    org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var6 = var5.getFont();
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var9 = var8.getTickLabelPaint();
    java.lang.Class var10 = var8.getMajorTickTimePeriodClass();
    java.awt.Paint var11 = var8.getTickMarkPaint();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("AxisLocation.TOP_OR_RIGHT", var6, var11);
    var1.set(3, (java.lang.Object)var6);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var16 = var15.getDomainAxisEdge();
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    var19.setSeriesURLGenerator(10, var21);
    org.jfree.chart.urls.CategoryURLGenerator var24 = null;
    var19.setSeriesURLGenerator(3, var24, true);
    int var27 = var19.getPassCount();
    org.jfree.chart.renderer.category.BarPainter var28 = var19.getBarPainter();
    var19.setBaseSeriesVisible(true, true);
    var15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.util.Layer var34 = null;
    java.util.Collection var35 = var15.getDomainMarkers(0, var34);
    var1.set(0, (java.lang.Object)var15);
    org.jfree.chart.axis.ValueAxis var38 = var15.getRangeAxisForDataset(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(10);
    java.lang.String var3 = var2.toString();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)100L);
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var10 = var9.getMaximumItemCount();
    java.text.NumberFormat var11 = java.text.NumberFormat.getNumberInstance();
    boolean var12 = var9.equals((java.lang.Object)var11);
    org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var17 = var16.getMaximumItemCount();
    java.beans.PropertyChangeListener var18 = null;
    var16.removePropertyChangeListener(var18);
    org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var24 = var23.getRangeDescription();
    org.jfree.data.time.TimeSeries var25 = var16.addAndOrUpdate(var23);
    org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var28 = var27.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var29 = var27.getLabelInsets();
    boolean var30 = var27.isAxisLineVisible();
    var27.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var33 = var27.getFirst();
    var25.delete(var33);
    org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var37 = var36.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var38 = var36.getLabelInsets();
    boolean var39 = var36.isAxisLineVisible();
    var36.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var42 = var36.getFirst();
    org.jfree.data.time.TimeSeries var43 = var9.createCopy(var33, var42);
    org.jfree.chart.axis.PeriodAxis var45 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var46 = var45.getTickLabelPaint();
    java.lang.Class var47 = var45.getMajorTickTimePeriodClass();
    java.awt.Paint var48 = var45.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var50 = null;
    org.jfree.chart.urls.XYURLGenerator var51 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var50, var51);
    org.jfree.chart.event.RendererChangeEvent var53 = null;
    var52.notifyListeners(var53);
    var52.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var58 = var52.getBaseShape();
    var45.setLeftArrow(var58);
    var45.setRangeWithMargins(0.025d, 4.0d);
    java.util.TimeZone var63 = var45.getTimeZone();
    java.util.Locale var64 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.PeriodAxis var65 = new org.jfree.chart.axis.PeriodAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (org.jfree.data.time.RegularTimePeriod)var2, var42, var63, var64);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "10"+ "'", var3.equals("10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + ""+ "'", var24.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     var0.add((org.jfree.chart.block.Block)var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.block.ColumnArrangement var5 = new org.jfree.chart.block.ColumnArrangement();
//     java.lang.Object var6 = var1.draw(var3, var4, (java.lang.Object)var5);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths();
    org.jfree.chart.axis.SymbolAxis var2 = new org.jfree.chart.axis.SymbolAxis("Jan", var1);
    java.awt.Shape var3 = var2.getRightArrow();
    var2.setLowerBound(1.0E-100d);
    boolean var6 = var2.getAutoRangeStickyZero();
    java.lang.Object var7 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    java.text.DateFormat var2 = null;
    java.text.NumberFormat var3 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var4 = var3.getRoundingMode();
    boolean var5 = var3.isGroupingUsed();
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("100", var2, var3);
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(68, (org.jfree.chart.labels.XYToolTipGenerator)var6, var7);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var10.setUpperMargin(0.0d);
    java.awt.Paint var14 = var10.getLabelPaint();
    boolean var15 = var6.equals((java.lang.Object)var10);
    java.text.DateFormat var16 = var6.getYDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var11 = var10.getMaximumItemCount();
    java.text.NumberFormat var12 = java.text.NumberFormat.getNumberInstance();
    boolean var13 = var10.equals((java.lang.Object)var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var18 = var17.getMaximumItemCount();
    java.beans.PropertyChangeListener var19 = null;
    var17.removePropertyChangeListener(var19);
    org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var25 = var24.getRangeDescription();
    org.jfree.data.time.TimeSeries var26 = var17.addAndOrUpdate(var24);
    org.jfree.chart.axis.PeriodAxis var28 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var29 = var28.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var30 = var28.getLabelInsets();
    boolean var31 = var28.isAxisLineVisible();
    var28.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var34 = var28.getFirst();
    var26.delete(var34);
    org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var38 = var37.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var39 = var37.getLabelInsets();
    boolean var40 = var37.isAxisLineVisible();
    var37.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var43 = var37.getFirst();
    org.jfree.data.time.TimeSeries var44 = var10.createCopy(var34, var43);
    var3.add(var34, (java.lang.Number)(-5.99999d));
    int var47 = var3.getMaximumItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + ""+ "'", var25.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2147483647);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    boolean var4 = var0.isDomainPannable();
    org.jfree.chart.annotations.XYAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    boolean var13 = var2.getAutoPopulateSeriesPaint();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
    int var18 = var17.getBlue();
    var2.setSeriesOutlinePaint(0, (java.awt.Paint)var17, true);
    java.lang.Boolean var22 = var2.getSeriesItemLabelsVisible(2147483647);
    org.jfree.chart.labels.XYToolTipGenerator var24 = null;
    org.jfree.chart.urls.XYURLGenerator var25 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var24, var25);
    org.jfree.chart.urls.XYURLGenerator var30 = var26.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var31 = null;
    var26.setBaseURLGenerator(var31, false);
    java.awt.Paint var37 = var26.getItemFillPaint(10, 100, false);
    org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var40 = var39.getTickLabelPaint();
    var26.setBasePaint(var40);
    var2.setBaseOutlinePaint(var40);
    var2.setBaseCreateEntities(true);
    double var45 = var2.getYOffset();
    var2.removeAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 2.0d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    int var2 = var1.getMaximumCategoryLabelLines();
    org.jfree.data.general.DefaultPieDataset var3 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var3, (java.lang.Comparable)"hi!", 10.0d);
    var3.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var3);
    java.awt.Paint var11 = null;
    var10.setLabelBackgroundPaint(var11);
    var10.setInnerSeparatorExtension(0.0d);
    boolean var15 = var1.hasListener((java.util.EventListener)var10);
    org.jfree.chart.urls.PieURLGenerator var16 = null;
    var10.setURLGenerator(var16);
    org.jfree.data.general.DefaultPieDataset var18 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var21 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var18, (java.lang.Comparable)"hi!", 10.0d);
    var18.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var25 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var18);
    java.awt.Paint var26 = null;
    var25.setLabelBackgroundPaint(var26);
    org.jfree.chart.util.Rotation var28 = var25.getDirection();
    java.awt.Paint var29 = var25.getLabelLinkPaint();
    java.awt.Paint var30 = var25.getBaseSectionPaint();
    var10.setParent((org.jfree.chart.plot.Plot)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline.Segment var2 = var0.getSegment((-1L));
    org.jfree.chart.axis.SegmentedTimeline var3 = var0.getBaseTimeline();
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var5 = var4.getMinimumDate();
    long var6 = var0.toTimelineValue(var5);
    var0.setStartTime(1419191999999L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 644288400000L);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(true);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var2);
    java.awt.Paint var4 = var3.getGridBandPaint();
    boolean var5 = var3.getAutoRangeStickyZero();
    boolean var6 = var3.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var9 = var8.getSize();
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var11 = var10.getRangeAxis();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var15 = var14.getStroke();
    double var16 = var14.getValue();
    var10.addDomainMarker((org.jfree.chart.plot.Marker)var14);
    var10.setDomainCrosshairValue(0.0d, true);
    java.lang.Object var21 = var10.clone();
    int var22 = var8.compareTo(var21);
    var3.setTickUnit(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    boolean var4 = var1.isAxisLineVisible();
    var1.setPositiveArrowVisible(false);
    java.awt.Shape var7 = var1.getDownArrow();
    var1.setAutoRangeMinimumSize(4.0d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("java.awt.Color[r=0,g=0,b=100]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    java.lang.String var1 = var0.getLGPL();
    java.lang.String var2 = var0.getLGPL();
    java.lang.String var3 = var0.getGPL();

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    org.jfree.chart.LegendItemCollection var3 = var0.getLegendItems();
    java.lang.String[] var6 = org.jfree.data.time.SerialDate.getMonths(true);
    org.jfree.chart.axis.SymbolAxis var7 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var6);
    java.awt.Paint var8 = var7.getGridBandPaint();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var7);
    org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var15 = var14.getFrame();
    org.jfree.chart.util.RectangleInsets var16 = var14.getPadding();
    var12.setLabelInsets(var16);
    var0.setDomainAxis(2, (org.jfree.chart.axis.CategoryAxis)var12, false);
    java.awt.Font var21 = var12.getTickLabelFont((java.lang.Comparable)"[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var2);
//     double var4 = var3.getGap();
//     org.jfree.chart.util.RectangleEdge var6 = var3.getDomainAxisEdge(0);
//     double var7 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var6);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    org.jfree.chart.util.Rotation var10 = var7.getDirection();
    var7.setOuterSeparatorExtension((-8.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    var1.setHeight(90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(5.0d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var11 = var10.getMaximumItemCount();
    java.beans.PropertyChangeListener var12 = null;
    var10.removePropertyChangeListener(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var18 = var17.getRangeDescription();
    org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
    boolean var24 = var21.isAxisLineVisible();
    var21.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
    var19.delete(var27);
    org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var31 = var30.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isAxisLineVisible();
    var30.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
    org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
    org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var42 = var41.getMaximumItemCount();
    java.beans.PropertyChangeListener var43 = null;
    var41.removePropertyChangeListener(var43);
    org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var41);
    var37.addChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
    org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var51 = var50.getMaximumItemCount();
    java.text.NumberFormat var52 = java.text.NumberFormat.getNumberInstance();
    boolean var53 = var50.equals((java.lang.Object)var52);
    org.jfree.data.time.TimeSeries var57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var58 = var57.getMaximumItemCount();
    java.beans.PropertyChangeListener var59 = null;
    var57.removePropertyChangeListener(var59);
    org.jfree.data.time.TimeSeries var64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var65 = var64.getRangeDescription();
    org.jfree.data.time.TimeSeries var66 = var57.addAndOrUpdate(var64);
    org.jfree.chart.axis.PeriodAxis var68 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var69 = var68.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var70 = var68.getLabelInsets();
    boolean var71 = var68.isAxisLineVisible();
    var68.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var74 = var68.getFirst();
    var66.delete(var74);
    org.jfree.chart.axis.PeriodAxis var77 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var78 = var77.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var79 = var77.getLabelInsets();
    boolean var80 = var77.isAxisLineVisible();
    var77.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var83 = var77.getFirst();
    org.jfree.data.time.TimeSeries var84 = var50.createCopy(var74, var83);
    int var85 = var37.getIndex(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + ""+ "'", var65.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == (-1));

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.CrosshairState var4 = new org.jfree.chart.plot.CrosshairState();
//     org.jfree.chart.plot.PlotOrientation var11 = null;
//     var4.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var11);
//     double var13 = var4.getCrosshairY();
//     double var14 = var4.getCrosshairDistance();
//     var4.setCrosshairX(3.0d);
//     double var17 = var4.getCrosshairDistance();
//     java.awt.geom.Point2D var18 = var4.getAnchor();
//     var4.updateCrosshairX(0.0d);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var22 = var21.getDomainAxisEdge();
//     var21.clearRangeMarkers(0);
//     java.awt.Stroke var25 = var21.getDomainCrosshairStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var29 = var28.getRangeAxis();
//     java.awt.Paint var30 = var28.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var28);
//     java.awt.Image var32 = var28.getBackgroundImage();
//     java.awt.geom.Point2D var33 = var28.getQuadrantOrigin();
//     var21.panDomainAxes(0.0d, var27, var33);
//     var4.setAnchor(var33);
//     var0.zoomRangeAxes((-1.0d), var3, var33, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
//     org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxisForDataset(2147483647);
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var4.setFixedDomainAxisSpace(var5, true);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.util.List var10 = null;
//     var4.drawRangeTickBands(var8, var9, var10);
//     org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var15 = null;
//     var13.setDrawingSupplier(var15);
//     float var17 = var13.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var21 = null;
//     org.jfree.chart.urls.XYURLGenerator var22 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
//     org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var28 = null;
//     var23.setBaseURLGenerator(var28, false);
//     java.awt.Paint var34 = var23.getItemFillPaint(10, 100, false);
//     var19.setLabelPaint(var34);
//     float var36 = var19.getAlpha();
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var13.removeDomainMarker((org.jfree.chart.plot.Marker)var19, var37);
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker)var19, var39);
//     boolean var41 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var19);
//     org.jfree.chart.util.Layer var43 = null;
//     java.util.Collection var44 = var0.getDomainMarkers(68, var43);
//     var0.setAnchorValue(0.05d, false);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var51 = null;
//     org.jfree.chart.urls.XYURLGenerator var52 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var51, var52);
//     org.jfree.chart.urls.XYURLGenerator var57 = var53.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var58 = null;
//     var53.setBaseURLGenerator(var58, false);
//     java.awt.Paint var64 = var53.getItemFillPaint(10, 100, false);
//     var49.setLabelPaint(var64);
//     float var66 = var49.getAlpha();
//     java.awt.Paint var67 = var49.getOutlinePaint();
//     java.awt.Paint var68 = var49.getOutlinePaint();
//     java.awt.Paint var69 = var49.getOutlinePaint();
//     org.jfree.chart.util.Layer var70 = null;
//     boolean var71 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var49, var70);
//     
//     // Checks the contract:  equals-hashcode on var19 and var49
//     assertTrue("Contract failed: equals-hashcode on var19 and var49", var19.equals(var49) ? var19.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var19
//     assertTrue("Contract failed: equals-hashcode on var49 and var19", var49.equals(var19) ? var49.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    java.awt.Stroke var16 = var2.getItemStroke(0, 255, false);
    java.awt.Shape var18 = var2.getSeriesShape(70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var3 = var2.getFont();
    org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    boolean var6 = var4.equals((java.lang.Object)var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 100);
    int var10 = var9.getBlue();
    java.awt.Color var11 = var9.darker();
    java.awt.Color var12 = var11.brighter();
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.event.AxisChangeEvent var16 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var15);
    org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var19 = var18.getTickLabelPaint();
    var18.zoomRange(1.0d, 100.0d);
    double var23 = var18.getLowerMargin();
    org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.labels.XYToolTipGenerator var26 = null;
    org.jfree.chart.urls.XYURLGenerator var27 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var26, var27);
    org.jfree.chart.event.RendererChangeEvent var29 = null;
    var28.notifyListeners(var29);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var33 = var32.getDomainMinorGridlineStroke();
    var32.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.plot.Marker var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    var28.drawDomainMarker(var31, (org.jfree.chart.plot.XYPlot)var32, var36, var37, var38);
    java.awt.Stroke var41 = var28.getSeriesStroke((-435));
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.xy.XYItemRenderer)var28);
    boolean var43 = var11.equals((java.lang.Object)var15);
    org.jfree.chart.plot.CombinedRangeXYPlot var44 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.data.Range var46 = null;
    org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var46);
    org.jfree.chart.block.RectangleConstraint var48 = var47.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var49 = var48.toUnconstrainedWidth();
    double var50 = var48.getHeight();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var54 = var53.getFont();
    org.jfree.chart.text.TextLine var55 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var54);
    org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis();
    boolean var57 = var55.equals((java.lang.Object)var56);
    org.jfree.data.Range var60 = new org.jfree.data.Range(0.2d, 0.2d);
    var56.setRange(var60, true, false);
    org.jfree.chart.block.RectangleConstraint var64 = var48.toRangeHeight(var60);
    var15.setDefaultAutoRange(var60);
    org.jfree.data.Range var66 = var15.getRange();
    var5.setRange(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.data.time.TimeSeries var9 = var7.getSeries((java.lang.Comparable)2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var7.getXValue(3, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2, 68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 29);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.util.TableOrder var2 = var1.getDataExtractOrder();
    org.jfree.chart.JFreeChart var3 = var1.getPieChart();
    java.awt.Image var4 = var1.getBackgroundImage();
    org.jfree.chart.LegendItemCollection var5 = var1.getLegendItems();
    org.jfree.chart.util.TableOrder var6 = var1.getDataExtractOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var5 = var4.getTickLabelPaint();
    java.lang.Class var6 = var4.getMajorTickTimePeriodClass();
    var1.setAutoRangeTimePeriodClass(var6);
    java.awt.Paint var8 = var1.getTickLabelPaint();
    var1.setUpperMargin(100.0d);
    float var11 = var1.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    double var10 = var9.getIntervalPositionFactor();
    var9.removeAllSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var15 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var9, 29, 0.0d, 1.0E-100d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected(1, 0, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    java.text.DateFormat var2 = null;
    java.text.NumberFormat var3 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var4 = var3.getRoundingMode();
    boolean var5 = var3.isGroupingUsed();
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("100", var2, var3);
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(68, (org.jfree.chart.labels.XYToolTipGenerator)var6, var7);
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.XYURLGenerator var11 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
    org.jfree.chart.event.RendererChangeEvent var13 = null;
    var12.notifyListeners(var13);
    var12.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var18 = var12.getBaseShape();
    var8.setLegendArea(var18);
    var8.setUseFillPaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.data.time.TimeSeries var9 = var7.getSeries((java.lang.Comparable)2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var7.getStartXValue(70, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var11 = var10.getRangeDescription();
    org.jfree.data.time.TimeSeries var12 = var3.addAndOrUpdate(var10);
    java.lang.String var13 = var10.getDescription();
    java.lang.String var14 = var10.getRangeDescription();
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var19 = var18.getMaximumItemCount();
    java.beans.PropertyChangeListener var20 = null;
    var18.removePropertyChangeListener(var20);
    org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var26 = var25.getRangeDescription();
    org.jfree.data.time.TimeSeries var27 = var18.addAndOrUpdate(var25);
    org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var30 = var29.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var31 = var29.getLabelInsets();
    boolean var32 = var29.isAxisLineVisible();
    var29.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var35 = var29.getFirst();
    var27.delete(var35);
    org.jfree.data.time.TimeSeriesDataItem var38 = new org.jfree.data.time.TimeSeriesDataItem(var35, 2.0d);
    org.jfree.data.time.TimeSeriesDataItem var39 = var10.addOrUpdate(var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.delete(10, 29);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + ""+ "'", var14.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + ""+ "'", var26.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setAxisLineVisible(false);
    var1.setMinorTickMarkInsideLength((-1.0f));
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.util.List var9 = var8.getSubplots();
    var8.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    java.lang.String var2 = var1.getText();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var5 = var4.getFrame();
    var1.setFrame(var5);
    java.lang.String var7 = var1.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "100"+ "'", var2.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var8 = null;
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
    org.jfree.chart.urls.XYURLGenerator var14 = var10.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    var10.setBaseURLGenerator(var15, false);
    java.awt.Paint var21 = var10.getItemFillPaint(10, 100, false);
    var6.setLabelPaint(var21);
    float var23 = var6.getAlpha();
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var6, var24);
    org.jfree.chart.util.LengthAdjustmentType var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLabelOffsetType(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var5 = null;
//     org.jfree.chart.urls.XYURLGenerator var6 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var5, var6);
//     org.jfree.chart.urls.XYURLGenerator var11 = var7.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var12 = null;
//     var7.setBaseURLGenerator(var12, false);
//     java.awt.Paint var18 = var7.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var19 = var7.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var20 = var19.getRotationAnchor();
//     org.jfree.chart.labels.XYToolTipGenerator var23 = null;
//     org.jfree.chart.urls.XYURLGenerator var24 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var23, var24);
//     org.jfree.chart.urls.XYURLGenerator var29 = var25.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var30 = null;
//     var25.setBaseURLGenerator(var30, false);
//     java.awt.Paint var36 = var25.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var25.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var38 = var37.getTextAnchor();
//     java.lang.String var39 = var38.toString();
//     java.awt.Shape var40 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Combined Range XYPlot", var1, 0.0f, 0.8f, var20, 1.0E-8d, var38);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(10.0d, "hi!", "TextAnchor.TOP_CENTER", true);
    java.text.NumberFormat var6 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("100", (java.text.NumberFormat)var5, var6);
    var6.setMinimumIntegerDigits(68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var2 = var1.getMinimumDate();
    boolean var3 = var0.containsDomainValue(var2);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(10);
    java.lang.String var6 = var5.toString();
    java.lang.String var7 = var5.toString();
    java.util.Date var8 = var5.getStart();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange(var2, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "10"+ "'", var6.equals("10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "10"+ "'", var7.equals("10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var27 = var26.getTickLabelPaint();
    java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
    java.awt.Paint var29 = var26.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
    org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
    java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
    var26.setMinorTickMarkStroke(var33);
    var26.setRangeAboutValue(0.05d, 1.0E-5d);
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    java.awt.geom.Point2D var43 = null;
    var39.zoomRangeAxes(3.0d, 0.025d, var42, var43);
    java.lang.String var45 = var39.getPlotType();
    int var46 = var39.getSeriesCount();
    java.lang.Object var47 = var39.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "Polar Plot"+ "'", var45.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 1.5848931924611136d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("100", "{0}: ({1}, {2})", "ERROR : Relative To String", "{0}: ({1}, {2})");
    java.lang.String var5 = var4.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "100"+ "'", var5.equals("100"));

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.drawBackground(var1, var2);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    int var2 = var1.getMaximumCategoryLabelLines();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.axis.AxisSpace var6 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var7 = var6.clone();
    org.jfree.chart.axis.AxisSpace var8 = new org.jfree.chart.axis.AxisSpace();
    var8.setTop(10.0d);
    var6.ensureAtLeast(var8);
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var15 = null;
    var13.setDrawingSupplier(var15);
    float var17 = var13.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var21 = null;
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
    org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var28 = null;
    var23.setBaseURLGenerator(var28, false);
    java.awt.Paint var34 = var23.getItemFillPaint(10, 100, false);
    var19.setLabelPaint(var34);
    float var36 = var19.getAlpha();
    org.jfree.chart.util.Layer var37 = null;
    boolean var38 = var13.removeDomainMarker((org.jfree.chart.plot.Marker)var19, var37);
    org.jfree.chart.util.RectangleEdge var39 = var13.getRangeAxisEdge();
    var8.add(0.05d, var39);
    org.jfree.chart.axis.AxisState var41 = null;
    var1.drawTickMarks(var3, 1.0E-5d, var5, var39, var41);
    double var43 = var1.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.05d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setMinorTickMarksVisible(false);
    java.util.TimeZone var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    java.lang.String var2 = var1.getText();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var5 = var4.getFrame();
    var1.setFrame(var5);
    java.awt.Paint var7 = var1.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "100"+ "'", var2.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    org.jfree.chart.labels.CategoryItemLabelGenerator var16 = var2.getItemLabelGenerator(70, 2, true);
    var2.setBaseItemLabelsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setLowerMargin(0.08d);
    var1.setTickMarksVisible(false);
    var1.setLowerBound((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var11 = var10.getMaximumItemCount();
    java.beans.PropertyChangeListener var12 = null;
    var10.removePropertyChangeListener(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var18 = var17.getRangeDescription();
    org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
    boolean var24 = var21.isAxisLineVisible();
    var21.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
    var19.delete(var27);
    org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var31 = var30.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isAxisLineVisible();
    var30.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
    org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
    org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var42 = var41.getMaximumItemCount();
    java.beans.PropertyChangeListener var43 = null;
    var41.removePropertyChangeListener(var43);
    org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var41);
    var37.addChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
    java.util.List var47 = var45.getSeries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var3 = var2.getTickLabelPaint();
    java.lang.Class var4 = var2.getMajorTickTimePeriodClass();
    java.awt.Paint var5 = var2.getTickMarkPaint();
    float var6 = var2.getMinorTickMarkInsideLength();
    java.util.Locale var7 = var2.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var8 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("org.jfree.chart.event.ChartChangeEvent[source=AxisLocation.BOTTOM_OR_LEFT]", var7);
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem(1.0d, (-5.76E7d));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    java.awt.Stroke var9 = var3.lookupSeriesStroke(0);
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var13 = var12.getTickLabelPaint();
    java.lang.Class var14 = var12.getMajorTickTimePeriodClass();
    java.awt.Paint var15 = var12.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var17 = null;
    org.jfree.chart.urls.XYURLGenerator var18 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var17, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = null;
    var19.notifyListeners(var20);
    var19.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var25 = var19.getBaseShape();
    var12.setLeftArrow(var25);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var25);
    var3.setLegendShape(100, var25);
    var3.setBaseItemLabelsVisible(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var9);
    double var12 = var9.getDomainUpperBound(true);
    org.jfree.data.xy.IntervalXYDelegate var14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var9, false);
    var14.setAutoWidth(true);
    double var17 = var14.getFixedIntervalWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setIntervalPositionFactor(90.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var3 = var2.getSize();
    int var4 = var0.indexOf((java.lang.Comparable)var3);
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var9 = var8.clone();
    var8.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var8);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var18 = var14.isSelected(0, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(96, 3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var0.setBaseLinesVisible(true);
    boolean var8 = var0.getItemShapeFilled(0, 1);
    java.awt.Shape var10 = var0.lookupSeriesShape((-1));
    var0.setBaseShapesVisible(true);
    boolean var15 = var0.getItemShapeVisible(70, 2147483647);
    java.awt.Paint var19 = var0.getItemPaint(96, 1, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    boolean var13 = var0.canSelectByPoint();
    double var14 = var0.getRangeCrosshairValue();
    java.lang.Object var15 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     var2.setOutlineVisible(true);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.data.Range var7 = var2.getDataRange(var6);
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var9);
//     double var11 = var10.getGap();
//     org.jfree.chart.util.RectangleEdge var13 = var10.getDomainAxisEdge(0);
//     java.lang.String var14 = var10.getPlotType();
//     org.jfree.chart.axis.AxisLocation var16 = var10.getDomainAxisLocation(100);
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var18 = var17.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var19 = null;
//     var17.setDrawingSupplier(var19);
//     float var21 = var17.getForegroundAlpha();
//     boolean var22 = var17.isDomainZoomable();
//     org.jfree.chart.plot.CombinedDomainXYPlot var23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var17.add((org.jfree.chart.plot.XYPlot)var23, 100);
//     java.awt.Stroke var26 = var17.getDomainCrosshairStroke();
//     org.jfree.chart.event.PlotChangeEvent var27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var17);
//     var10.plotChanged(var27);
//     var2.plotChanged(var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setSeriesURLGenerator(3, var7, true);
    int var10 = var2.getPassCount();
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.LegendItemCollection var13 = var2.getLegendItems();
    org.jfree.chart.labels.XYToolTipGenerator var15 = null;
    org.jfree.chart.urls.XYURLGenerator var16 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
    org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
    var17.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var27 = var17.getItemLabelGenerator(1, 1, true);
    org.jfree.chart.labels.ItemLabelPosition var31 = var17.getPositiveItemLabelPosition((-1), 0, false);
    var2.setBaseNegativeItemLabelPosition(var31, false);
    var2.setBaseSeriesVisibleInLegend(true, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var40 = var2.getItemLabelGenerator((-1), 2, true);
    boolean var41 = var2.getDataBoundsIncludesVisibleSeriesOnly();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    int var2 = var1.getMaximumCategoryLabelLines();
    var1.setMaximumCategoryLabelWidthRatio(1.0f);
    var1.configure();
    var1.setLabelToolTip("");
    java.lang.Object var8 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var5.setSeriesURLGenerator(10, var7);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var5.setSeriesURLGenerator(3, var10, true);
    boolean var13 = var0.equals((java.lang.Object)var5);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.data.Range var15 = var5.findRangeBounds(var14);
    var5.setBaseSeriesVisibleInLegend(false, true);
    int var19 = var5.getDefaultEntityRadius();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var1 = var0.getDatasetRenderingOrder();
    int var2 = var0.getWeight();
    org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis(68);
    java.lang.Comparable var5 = var0.getDomainCrosshairRowKey();
    org.jfree.chart.axis.CategoryAxis var6 = var0.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.DateTickUnit var1 = null;
//     var0.setTickUnit(var1, true, true);
//     org.jfree.chart.axis.DateTickUnit var5 = null;
//     java.util.Date var6 = var0.calculateLowestVisibleTickValue(var5);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
    var2.setFixedLegendItems(var6);
    int var8 = var2.getRendererCount();
    org.jfree.chart.axis.AxisLocation var9 = var2.getRangeAxisLocation();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setAnchorValue(Double.NaN);
    java.lang.Comparable var14 = var11.getDomainCrosshairRowKey();
    var11.clearDomainMarkers();
    java.awt.Paint var16 = var11.getNoDataMessagePaint();
    org.jfree.chart.axis.CategoryAnchor var17 = var11.getDomainGridlinePosition();
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var22 = var21.getDomainAxisEdge();
    var21.clearRangeMarkers(0);
    java.awt.Stroke var25 = var21.getDomainCrosshairStroke();
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var29 = var28.getRangeAxis();
    java.awt.Paint var30 = var28.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var28);
    java.awt.Image var32 = var28.getBackgroundImage();
    java.awt.geom.Point2D var33 = var28.getQuadrantOrigin();
    var21.panDomainAxes(0.0d, var27, var33);
    var11.zoomDomainAxes(10.0d, Double.NaN, var20, var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var36 = var2.findSubplot(var10, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var11 = var10.getMaximumItemCount();
    java.beans.PropertyChangeListener var12 = null;
    var10.removePropertyChangeListener(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var18 = var17.getRangeDescription();
    org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
    boolean var24 = var21.isAxisLineVisible();
    var21.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
    var19.delete(var27);
    org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var31 = var30.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isAxisLineVisible();
    var30.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
    org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
    org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var42 = var41.getMaximumItemCount();
    java.beans.PropertyChangeListener var43 = null;
    var41.removePropertyChangeListener(var43);
    org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var41);
    var37.addChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
    org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var51 = var50.getMaximumItemCount();
    java.beans.PropertyChangeListener var52 = null;
    var50.removePropertyChangeListener(var52);
    org.jfree.data.time.TimeSeries var57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var58 = var57.getRangeDescription();
    org.jfree.data.time.TimeSeries var59 = var50.addAndOrUpdate(var57);
    java.lang.String var60 = var57.getDescription();
    java.lang.String var61 = var57.getRangeDescription();
    org.jfree.data.time.TimeSeries var65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var66 = var65.getMaximumItemCount();
    java.beans.PropertyChangeListener var67 = null;
    var65.removePropertyChangeListener(var67);
    org.jfree.data.time.TimeSeries var72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var73 = var72.getRangeDescription();
    org.jfree.data.time.TimeSeries var74 = var65.addAndOrUpdate(var72);
    org.jfree.chart.axis.PeriodAxis var76 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var77 = var76.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var78 = var76.getLabelInsets();
    boolean var79 = var76.isAxisLineVisible();
    var76.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var82 = var76.getFirst();
    var74.delete(var82);
    org.jfree.data.time.TimeSeriesDataItem var85 = new org.jfree.data.time.TimeSeriesDataItem(var82, 2.0d);
    org.jfree.data.time.TimeSeriesDataItem var86 = var57.addOrUpdate(var85);
    var45.addSeries(var57);
    org.jfree.data.time.TimeSeries var91 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var92 = var91.getMaximumItemCount();
    var45.removeSeries(var91);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var91.update(68, (java.lang.Number)15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + ""+ "'", var58.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + ""+ "'", var61.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var73 + "' != '" + ""+ "'", var73.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 2147483647);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    var2.setOutlineVisible(true);
    org.jfree.chart.LegendItemCollection var6 = var2.getFixedLegendItems();
    var2.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var9 = var2.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setRangeAxisLocation(var10, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     boolean var4 = var3.getAutoPopulateSeriesOutlineStroke();
//     var3.setBaseCreateEntities(false);
//     boolean var8 = var3.isSeriesVisible(1);
//     var3.setShapesVisible(false);
//     boolean var11 = var3.getShapesVisible();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var14);
//     double var16 = var15.getGap();
//     var15.setOutlineVisible(true);
//     org.jfree.chart.LegendItemCollection var19 = var15.getFixedLegendItems();
//     org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var22 = var21.getTickLabelPaint();
//     var21.zoomRange(1.0d, 100.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var27 = var26.getDomainMinorGridlineStroke();
//     var21.setAxisLineStroke(var27);
//     var15.setOutlineStroke(var27);
//     org.jfree.chart.axis.PeriodAxis var31 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var32 = var31.getTickLabelPaint();
//     java.lang.Class var33 = var31.getMajorTickTimePeriodClass();
//     java.awt.Paint var34 = var31.getTickMarkPaint();
//     org.jfree.chart.axis.TickUnitSource var35 = var31.getStandardTickUnits();
//     java.awt.geom.Rectangle2D var36 = null;
//     var3.fillDomainGridBand(var12, (org.jfree.chart.plot.XYPlot)var15, (org.jfree.chart.axis.ValueAxis)var31, var36, 4.0d, 0.025d);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
//     var1.setAxisLineVisible(false);
//     var1.setNegativeArrowVisible(false);
//     float var8 = var1.getMinorTickMarkInsideLength();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var12 = var11.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var13 = null;
//     var11.setDrawingSupplier(var13);
//     float var15 = var11.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var19 = null;
//     org.jfree.chart.urls.XYURLGenerator var20 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var19, var20);
//     org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var26 = null;
//     var21.setBaseURLGenerator(var26, false);
//     java.awt.Paint var32 = var21.getItemFillPaint(10, 100, false);
//     var17.setLabelPaint(var32);
//     float var34 = var17.getAlpha();
//     org.jfree.chart.util.Layer var35 = null;
//     boolean var36 = var11.removeDomainMarker((org.jfree.chart.plot.Marker)var17, var35);
//     org.jfree.chart.util.RectangleEdge var37 = var11.getRangeAxisEdge();
//     java.awt.geom.GeneralPath var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.RenderingSource var40 = null;
//     var11.select(var38, var39, var40);
//     org.jfree.chart.plot.DrawingSupplier var42 = null;
//     var11.setDrawingSupplier(var42);
//     org.jfree.chart.util.RectangleEdge var44 = var11.getDomainAxisEdge();
//     double var45 = var1.java2DToValue(5.0d, var10, var44);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.025d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    float var5 = var1.getMinorTickMarkInsideLength();
    java.awt.Stroke var6 = var1.getMinorTickMarkStroke();
    var1.resizeRange(2.0d, 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    java.text.DateFormat var1 = null;
    java.text.NumberFormat var2 = java.text.NumberFormat.getInstance();
    int var3 = var2.getMaximumFractionDigits();
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("100", var1, var2);
    java.text.NumberFormat var5 = var4.getYFormat();
    java.math.RoundingMode var6 = var5.getRoundingMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    boolean var13 = var0.isDomainZeroBaselineVisible();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var25 = null;
    var18.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var25);
    double var27 = var18.getCrosshairY();
    boolean var28 = var0.render(var14, var15, 10, var17, var18);
    double var29 = var18.getCrosshairX();
    java.awt.geom.Point2D var30 = var18.getAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var8 = null;
    var6.setDrawingSupplier(var8);
    var3.setPlot((org.jfree.chart.plot.XYPlot)var6);
    java.awt.Shape var12 = var3.lookupSeriesShape(2147483647);
    org.jfree.chart.entity.ChartEntity var15 = new org.jfree.chart.entity.ChartEntity(var12, "{0}: ({1}, {2})", "AxisLabelEntity: label = ");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     var0.setDomainCrosshairVisible(false);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var0.drawBackgroundImage(var4, var5);
//     double var7 = var0.getDomainCrosshairValue();
//     java.awt.Paint var8 = var0.getDomainZeroBaselinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var12 = var11.getRangeAxis();
//     java.awt.Paint var13 = var11.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var11);
//     java.awt.Image var15 = var11.getBackgroundImage();
//     java.awt.geom.Point2D var16 = var11.getQuadrantOrigin();
//     var0.panRangeAxes(3.0d, var10, var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var0.setBaseLinesVisible(true);
    boolean var6 = var0.getBaseSeriesVisibleInLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    boolean var12 = var7.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var13 = var7.getDataset();
    var7.setAutoPopulateSectionPaint(true);
    boolean var16 = var7.getSeparatorsVisible();
    boolean var17 = var7.getAutoPopulateSectionPaint();
    var7.setMinimumArcAngleToDraw(100.0d);
    java.awt.Shape var20 = var7.getLegendItemShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var2 = var0.getSegment((-1L));
//     org.jfree.chart.axis.SegmentedTimeline var3 = var0.getBaseTimeline();
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var5 = var4.getMinimumDate();
//     long var6 = var0.toTimelineValue(var5);
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var8 = var7.getMinimumDate();
//     boolean var10 = var7.isHiddenValue(1L);
//     org.jfree.data.Range var11 = var7.getRange();
//     org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var14 = var13.getTickLabelPaint();
//     java.lang.Class var15 = var13.getMajorTickTimePeriodClass();
//     java.awt.Paint var16 = var13.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var18 = null;
//     org.jfree.chart.urls.XYURLGenerator var19 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var18, var19);
//     org.jfree.chart.event.RendererChangeEvent var21 = null;
//     var20.notifyListeners(var21);
//     var20.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var26 = var20.getBaseShape();
//     var13.setLeftArrow(var26);
//     var13.setRangeWithMargins(0.025d, 4.0d);
//     java.util.TimeZone var31 = var13.getTimeZone();
//     org.jfree.chart.axis.PeriodAxis var33 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var34 = var33.getTickLabelPaint();
//     java.lang.Class var35 = var33.getMajorTickTimePeriodClass();
//     java.awt.Paint var36 = var33.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var38 = null;
//     org.jfree.chart.urls.XYURLGenerator var39 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var38, var39);
//     org.jfree.chart.event.RendererChangeEvent var41 = null;
//     var40.notifyListeners(var41);
//     var40.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var46 = var40.getBaseShape();
//     var33.setLeftArrow(var46);
//     var33.setRangeWithMargins(0.025d, 4.0d);
//     java.util.TimeZone var51 = var33.getTimeZone();
//     var13.setTimeZone(var51);
//     var7.setTimeZone(var51);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year(var5, var51);
//     org.jfree.chart.text.TextFragment var57 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var58 = var57.getFont();
//     org.jfree.chart.text.TextLine var59 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var58);
//     org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis();
//     boolean var61 = var59.equals((java.lang.Object)var60);
//     org.jfree.data.Range var64 = new org.jfree.data.Range(0.2d, 0.2d);
//     var60.setRange(var64, false, true);
//     java.util.TimeZone var68 = var60.getTimeZone();
//     org.jfree.chart.axis.PeriodAxis var70 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var71 = var70.getTickLabelPaint();
//     java.lang.Class var72 = var70.getMajorTickTimePeriodClass();
//     java.awt.Paint var73 = var70.getTickMarkPaint();
//     float var74 = var70.getMinorTickMarkInsideLength();
//     java.util.Locale var75 = var70.getLocale();
//     org.jfree.data.time.Month var76 = new org.jfree.data.time.Month(var5, var68, var75);
//     java.util.Calendar var77 = null;
//     long var78 = var76.getMiddleMillisecond(var77);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    boolean var9 = var0.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var11);
    double var13 = var12.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var15 = var14.getRangeAxis();
    org.jfree.chart.LegendItemCollection var16 = var14.getLegendItems();
    var12.setFixedLegendItems(var16);
    var0.setFixedLegendItems(var16);
    var0.clearDomainMarkers(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
    int var18 = var17.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var23 = var22.getSize();
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity(var16, (org.jfree.data.general.PieDataset)var17, 100, (-1), (java.lang.Comparable)var22, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    java.lang.String var27 = var26.getShapeType();
    var26.setPieIndex(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "rect"+ "'", var27.equals("rect"));

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    boolean var13 = var2.getAutoPopulateSeriesPaint();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
    int var18 = var17.getBlue();
    var2.setSeriesOutlinePaint(0, (java.awt.Paint)var17, true);
    org.jfree.chart.util.GradientPaintTransformer var21 = var2.getGradientPaintTransformer();
    int var22 = var2.getRowCount();
    java.awt.Stroke var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseStroke(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.AbstractPieLabelDistributor var38 = var7.getLabelDistributor();
    int var39 = var38.getItemCount();
    int var40 = var38.getItemCount();
    var38.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var43 = var38.getPieLabelRecord(70);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    var0.configureDomainAxes();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var6 = var5.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var7 = var5.getLabelInsets();
    java.lang.String var8 = var7.toString();
    var0.setAxisOffset(var7);
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.CategoryMarker var13 = null;
    org.jfree.chart.util.Layer var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(68, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var8 = null;
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
    org.jfree.chart.urls.XYURLGenerator var14 = var10.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    var10.setBaseURLGenerator(var15, false);
    java.awt.Paint var21 = var10.getItemFillPaint(10, 100, false);
    var6.setLabelPaint(var21);
    float var23 = var6.getAlpha();
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var6, var24);
    org.jfree.chart.axis.ValueAxis var27 = null;
    var0.setRangeAxis(0, var27);
    var0.setWeight((-435));
    boolean var31 = var0.canSelectByPoint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
//     var2.setTop(10.0d);
//     var0.ensureAtLeast(var2);
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var0.ensureAtLeast(var6);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.zoomRange(1.0d, 100.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    var1.setAxisLineStroke(var7);
    org.jfree.data.general.DefaultPieDataset var9 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var9, (java.lang.Comparable)"hi!", 10.0d);
    var9.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var9);
    java.awt.Paint var17 = null;
    var16.setLabelBackgroundPaint(var17);
    var16.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var22 = null;
    org.jfree.chart.urls.XYURLGenerator var23 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var22, var23);
    org.jfree.chart.urls.XYURLGenerator var28 = var24.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var29 = null;
    var24.setBaseURLGenerator(var29, false);
    java.awt.Paint var35 = var24.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var36 = var24.getBaseNegativeItemLabelPosition();
    java.awt.Color var39 = java.awt.Color.getColor("hi!", 100);
    int var40 = var39.getBlue();
    var24.setBaseLegendTextPaint((java.awt.Paint)var39);
    var16.setLabelOutlinePaint((java.awt.Paint)var39);
    org.jfree.chart.labels.PieSectionLabelGenerator var43 = var16.getLabelGenerator();
    java.awt.Shape var44 = var16.getLegendItemShape();
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var47, 1.0d, 3.0d);
    boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var44, var47);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.clone(var47);
    var1.setDownArrow(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.plot.DrawingSupplier var3 = var2.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 1.0E-8d, 0.08d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var3 = var2.getFont();
    org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
    org.jfree.chart.text.TextFragment var5 = var4.getFirstTextFragment();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.RenderingSource var11 = null;
    var6.select(10.0d, 100.0d, var10, var11);
    var6.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var16 = null;
    org.jfree.chart.urls.XYURLGenerator var17 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var16, var17);
    org.jfree.chart.urls.XYURLGenerator var22 = var18.getURLGenerator(0, 1, true);
    var18.setBaseSeriesVisibleInLegend(false);
    int var25 = var6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var18);
    org.jfree.chart.labels.XYToolTipGenerator var27 = null;
    org.jfree.chart.urls.XYURLGenerator var28 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var27, var28);
    org.jfree.chart.urls.XYURLGenerator var33 = var29.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var34 = null;
    var29.setBaseURLGenerator(var34, false);
    java.awt.Paint var40 = var29.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var41 = var29.getBaseNegativeItemLabelPosition();
    var18.setBasePositiveItemLabelPosition(var41, true);
    var18.setBaseSeriesVisibleInLegend(true);
    boolean var46 = var5.equals((java.lang.Object)var18);
    org.jfree.data.general.DefaultPieDataset var47 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var50 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var47, (java.lang.Comparable)"hi!", 10.0d);
    var47.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var54 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var47);
    java.awt.Paint var55 = null;
    var54.setLabelBackgroundPaint(var55);
    var54.setInnerSeparatorExtension(0.0d);
    java.awt.Stroke var59 = var54.getLabelLinkStroke();
    var18.setBaseOutlineStroke(var59, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    java.awt.Font var4 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("", var4, (org.jfree.chart.plot.Plot)var5, false);
    java.lang.Object var8 = var7.getTextAntiAlias();
    var7.setBackgroundImageAlignment(2147483647);
    java.awt.RenderingHints var11 = var7.getRenderingHints();
    var1.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var7);
    java.lang.Object var13 = var1.clone();
    var1.setText("RectangleEdge.LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.setAnchorValue(Double.NaN);
//     org.jfree.chart.LegendItemCollection var8 = var5.getLegendItems();
//     java.lang.String[] var11 = org.jfree.data.time.SerialDate.getMonths(true);
//     org.jfree.chart.axis.SymbolAxis var12 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var11);
//     java.awt.Paint var13 = var12.getGridBandPaint();
//     var5.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("100");
//     org.jfree.chart.block.BlockFrame var20 = var19.getFrame();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getPadding();
//     var17.setLabelInsets(var21);
//     var5.setDomainAxis(2, (org.jfree.chart.axis.CategoryAxis)var17, false);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var27 = var2.initialise(var3, var4, var5, 70, var26);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var2 = var1.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.RenderingSource var6 = null;
    var1.select(10.0d, 100.0d, var5, var6);
    var1.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
    var10.add((org.jfree.chart.block.Block)var11);
    org.jfree.chart.block.Arrangement var13 = var10.getArrangement();
    org.jfree.chart.block.BorderArrangement var14 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, var13, (org.jfree.chart.block.Arrangement)var14);
    java.awt.Paint var16 = var15.getItemPaint();
    org.jfree.chart.block.BlockContainer var17 = var15.getItemContainer();
    org.jfree.chart.util.RectangleAnchor var18 = var15.getLegendItemGraphicLocation();
    org.jfree.chart.block.BlockContainer var19 = var15.getItemContainer();
    java.awt.Graphics2D var20 = null;
    org.jfree.data.Range var21 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(var21, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var24 = var0.arrange(var19, var20, var23);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     var3.setBaseSeriesVisibleInLegend(false);
//     org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
//     var3.setBaseItemLabelGenerator(var10);
//     java.awt.Font var13 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
//     var16.clearSubtitles();
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var20 = var19.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
//     var16.setPadding(var21);
//     org.jfree.chart.event.ChartChangeEventType var23 = null;
//     org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var16, var23);
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var27 = null;
//     org.jfree.chart.urls.XYURLGenerator var28 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var27, var28);
//     org.jfree.chart.event.RendererChangeEvent var30 = null;
//     var29.notifyListeners(var30);
//     org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var33 = var32.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var34 = null;
//     var32.setDrawingSupplier(var34);
//     var29.setPlot((org.jfree.chart.plot.XYPlot)var32);
//     java.awt.geom.GeneralPath var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.RenderingSource var39 = null;
//     var32.select(var37, var38, var39);
//     java.awt.Stroke var41 = var32.getRangeMinorGridlineStroke();
//     java.lang.String[] var44 = org.jfree.data.time.SerialDate.getMonths(true);
//     org.jfree.chart.axis.SymbolAxis var45 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.TOP_OR_RIGHT", var44);
//     java.awt.Paint var46 = var45.getGridBandPaint();
//     boolean var47 = var45.getAutoRangeStickyZero();
//     java.awt.Color var52 = java.awt.Color.getColor("hi!", 100);
//     java.lang.String var53 = var52.toString();
//     org.jfree.chart.plot.IntervalMarker var54 = new org.jfree.chart.plot.IntervalMarker(0.08d, 1.0d, (java.awt.Paint)var52);
//     java.awt.geom.Rectangle2D var55 = null;
//     var3.drawRangeMarker(var25, (org.jfree.chart.plot.XYPlot)var32, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.chart.plot.Marker)var54, var55);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var2 = var1.getTitlePaint();
    java.awt.Paint var3 = var1.getLegendBackgroundPaint();
    java.awt.Paint var4 = var1.getTitlePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("AxisLabelEntity: label = ", var1, 0.8f, 0.8f, 0.0d, 0.0f, 10.0f);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    var3.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
    var3.setBaseItemLabelGenerator(var10);
    java.awt.Font var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
    var16.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var20 = var19.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
    var16.setPadding(var21);
    org.jfree.chart.event.ChartChangeEventType var23 = null;
    org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var16, var23);
    var3.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.zoomRange(1.0d, 100.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    var1.setAxisLineStroke(var7);
    boolean var9 = var1.isTickMarksVisible();
    float var10 = var1.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var5 = var4.getTickLabelPaint();
//     java.lang.Class var6 = var4.getMajorTickTimePeriodClass();
//     var1.setAutoRangeTimePeriodClass(var6);
//     java.awt.Paint var8 = var1.getTickLabelPaint();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var11 = var10.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.RenderingSource var15 = null;
//     var10.select(10.0d, 100.0d, var14, var15);
//     var10.setOutlineVisible(false);
//     boolean var19 = var10.isRangePannable();
//     boolean var20 = var10.isOutlineVisible();
//     org.jfree.chart.LegendItemCollection var21 = var10.getLegendItems();
//     java.awt.Paint var22 = var10.getOutlinePaint();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     int var26 = var25.getMaximumCategoryLabelLines();
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.axis.AxisSpace var30 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var31 = var30.clone();
//     org.jfree.chart.axis.AxisSpace var32 = new org.jfree.chart.axis.AxisSpace();
//     var32.setTop(10.0d);
//     var30.ensureAtLeast(var32);
//     org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var38 = var37.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var39 = null;
//     var37.setDrawingSupplier(var39);
//     float var41 = var37.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var45 = null;
//     org.jfree.chart.urls.XYURLGenerator var46 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var47 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var45, var46);
//     org.jfree.chart.urls.XYURLGenerator var51 = var47.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var52 = null;
//     var47.setBaseURLGenerator(var52, false);
//     java.awt.Paint var58 = var47.getItemFillPaint(10, 100, false);
//     var43.setLabelPaint(var58);
//     float var60 = var43.getAlpha();
//     org.jfree.chart.util.Layer var61 = null;
//     boolean var62 = var37.removeDomainMarker((org.jfree.chart.plot.Marker)var43, var61);
//     org.jfree.chart.util.RectangleEdge var63 = var37.getRangeAxisEdge();
//     var32.add(0.05d, var63);
//     org.jfree.chart.axis.AxisState var65 = null;
//     var25.drawTickMarks(var27, 1.0E-5d, var29, var63, var65);
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var70 = null;
//     java.awt.geom.Point2D var71 = null;
//     var67.zoomRangeAxes(0.0d, 10.0d, var70, var71);
//     org.jfree.chart.axis.AxisSpace var73 = new org.jfree.chart.axis.AxisSpace();
//     var67.setFixedDomainAxisSpace(var73, false);
//     org.jfree.chart.axis.AxisSpace var76 = var1.reserveSpace(var9, (org.jfree.chart.plot.Plot)var10, var23, var63, var73);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setSeriesURLGenerator(3, var7, true);
    int var10 = var2.getPassCount();
    org.jfree.chart.renderer.category.BarPainter var11 = var2.getBarPainter();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var2.getLegendItemToolTipGenerator();
    var2.setAutoPopulateSeriesOutlineStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var27 = var26.getTickLabelPaint();
    java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
    java.awt.Paint var29 = var26.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
    org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
    java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
    var26.setMinorTickMarkStroke(var33);
    var26.setRangeAboutValue(0.05d, 1.0E-5d);
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    java.awt.geom.Point2D var43 = null;
    var39.zoomRangeAxes(3.0d, 0.025d, var42, var43);
    java.lang.String var45 = var39.getPlotType();
    var39.addCornerTextItem("");
    var39.setAngleGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "Polar Plot"+ "'", var45.equals("Polar Plot"));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var2 = var1.getTitlePaint();
    java.awt.Paint var3 = var1.getItemLabelPaint();
    org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var7 = var6.getFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("Combined Range XYPlot", var7);
    java.awt.Font var9 = var8.getFont();
    var1.setLargeFont(var9);
    java.awt.Paint var11 = var1.getShadowPaint();
    java.awt.Paint var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPlotBackgroundPaint(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     var2.setOutlineVisible(true);
//     var2.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var10 = var9.getDomainMinorGridlineStroke();
//     org.jfree.chart.axis.AxisLocation var11 = var9.getRangeAxisLocation();
//     var2.setRangeAxisLocation(68, var11, false);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.CrosshairState var16 = new org.jfree.chart.plot.CrosshairState();
//     org.jfree.chart.plot.PlotOrientation var23 = null;
//     var16.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var23);
//     double var25 = var16.getCrosshairY();
//     double var26 = var16.getCrosshairDistance();
//     var16.setCrosshairX(3.0d);
//     double var29 = var16.getCrosshairDistance();
//     java.awt.geom.Point2D var30 = var16.getAnchor();
//     var16.updateCrosshairX(0.0d);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var34 = var33.getDomainAxisEdge();
//     var33.clearRangeMarkers(0);
//     java.awt.Stroke var37 = var33.getDomainCrosshairStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var41 = var40.getRangeAxis();
//     java.awt.Paint var42 = var40.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var40);
//     java.awt.Image var44 = var40.getBackgroundImage();
//     java.awt.geom.Point2D var45 = var40.getQuadrantOrigin();
//     var33.panDomainAxes(0.0d, var39, var45);
//     var16.setAnchor(var45);
//     org.jfree.chart.plot.PlotState var48 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     var2.draw(var14, var15, var45, var48, var49);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    java.awt.Stroke var9 = var3.lookupSeriesStroke(0);
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var13 = var12.getTickLabelPaint();
    java.lang.Class var14 = var12.getMajorTickTimePeriodClass();
    java.awt.Paint var15 = var12.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var17 = null;
    org.jfree.chart.urls.XYURLGenerator var18 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var17, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = null;
    var19.notifyListeners(var20);
    var19.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var25 = var19.getBaseShape();
    var12.setLeftArrow(var25);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var25);
    var3.setLegendShape(100, var25);
    org.jfree.chart.labels.ItemLabelPosition var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setBasePositiveItemLabelPosition(var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var27 = var26.getTickLabelPaint();
    java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
    java.awt.Paint var29 = var26.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
    org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
    java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
    var26.setMinorTickMarkStroke(var33);
    var26.setRangeAboutValue(0.05d, 1.0E-5d);
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
    org.jfree.chart.renderer.PolarItemRenderer var40 = var39.getRenderer();
    java.lang.String var41 = var39.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "Polar Plot"+ "'", var41.equals("Polar Plot"));

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var3.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("rect");
//     var1.setSmallestValue(10.0d);
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.Font var7 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var8, false);
//     org.jfree.chart.axis.AxisSpace var11 = null;
//     var8.setFixedRangeAxisSpace(var11);
//     org.jfree.chart.axis.AxisLocation var13 = var8.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var14 = org.jfree.chart.axis.AxisLocation.getOpposite(var13);
//     org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var16 = var15.getDomainMinorGridlineStroke();
//     var15.setDomainCrosshairVisible(false);
//     java.awt.Paint var19 = var15.getRangeCrosshairPaint();
//     float var20 = var15.getBackgroundImageAlpha();
//     var15.setGap(0.0d);
//     var15.clearDomainAxes();
//     org.jfree.chart.plot.PlotOrientation var24 = var15.getOrientation();
//     org.jfree.chart.util.RectangleEdge var25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var13, var24);
//     double var26 = var1.java2DToValue(0.0d, var5, var25);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    org.jfree.data.general.DatasetChangeEvent var3 = null;
    var0.datasetChanged(var3);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var0.setBaseLinesVisible(true);
    boolean var8 = var0.getItemShapeFilled(0, 1);
    java.awt.Shape var10 = var0.lookupSeriesShape((-1));
    var0.setBaseShapesVisible(true);
    org.jfree.chart.labels.XYToolTipGenerator var14 = null;
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var14, var15);
    org.jfree.chart.urls.XYURLGenerator var20 = var16.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var21 = null;
    var16.setBaseURLGenerator(var21, false);
    java.awt.Paint var27 = var16.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var28 = var16.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var29 = var28.getTextAnchor();
    var0.setBasePositiveItemLabelPosition(var28);
    var0.setSeriesShapesFilled(15, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    var7.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var3.drawDomainMarker(var6, (org.jfree.chart.plot.XYPlot)var7, var11, var12, var13);
    org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var18 = var17.getTickLabelPaint();
    java.lang.Class var19 = var17.getMajorTickTimePeriodClass();
    java.awt.Paint var20 = var17.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var22 = null;
    org.jfree.chart.urls.XYURLGenerator var23 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var22, var23);
    org.jfree.chart.event.RendererChangeEvent var25 = null;
    var24.notifyListeners(var25);
    var24.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var30 = var24.getBaseShape();
    var17.setLeftArrow(var30);
    org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity(var30);
    var3.setLegendShape(255, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    var0.setDomainCrosshairVisible(false);
    java.awt.Paint var4 = var0.getRangeCrosshairPaint();
    float var5 = var0.getBackgroundImageAlpha();
    var0.setGap(0.0d);
    var0.clearDomainAxes();
    org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var10 = var9.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var11 = null;
    var9.setDrawingSupplier(var11);
    float var13 = var9.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var17 = null;
    org.jfree.chart.urls.XYURLGenerator var18 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var17, var18);
    org.jfree.chart.urls.XYURLGenerator var23 = var19.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var24 = null;
    var19.setBaseURLGenerator(var24, false);
    java.awt.Paint var30 = var19.getItemFillPaint(10, 100, false);
    var15.setLabelPaint(var30);
    float var32 = var15.getAlpha();
    org.jfree.chart.util.Layer var33 = null;
    boolean var34 = var9.removeDomainMarker((org.jfree.chart.plot.Marker)var15, var33);
    org.jfree.chart.util.Layer var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var15, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    org.jfree.chart.renderer.RendererUtilities var0 = new org.jfree.chart.renderer.RendererUtilities();

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var3 = var2.getSize();
    int var4 = var0.indexOf((java.lang.Comparable)var3);
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var9 = var8.clone();
    var8.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var8);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    java.util.List var16 = var14.getSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset)var14, 3, 0.05d, 1.5848931924611136d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var3, (org.jfree.chart.urls.XYURLGenerator)var5);
    var6.setSeriesShapesVisible(3, false);
    boolean var10 = var6.getBaseShapesFilled();
    java.awt.Paint var14 = var6.getItemOutlinePaint(0, (-1), false);
    double var15 = var6.getStepPoint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.05d, (java.lang.Number)2147483647);
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer();
    var1.add((org.jfree.chart.block.Block)var2);
    boolean var4 = var1.isEmpty();
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement();
    var1.setArrangement((org.jfree.chart.block.Arrangement)var5);
    java.util.List var7 = var1.getBlocks();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addExceptions(var7);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
    var2.setFixedLegendItems(var6);
    int var8 = var2.getRendererCount();
    org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.event.MarkerChangeEvent var11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var10);
    var2.markerChanged(var11);
    org.jfree.chart.axis.AxisLocation var14 = var2.getRangeAxisLocation(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
    var2.setFixedLegendItems(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var9 = var6.get(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

}
