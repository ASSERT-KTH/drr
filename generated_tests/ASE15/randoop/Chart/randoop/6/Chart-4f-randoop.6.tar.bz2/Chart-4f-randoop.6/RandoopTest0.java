
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.title.Title var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var2 = new org.jfree.chart.entity.TitleEntity(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Paint var7 = null;
    java.awt.Paint var9 = null;
    java.awt.Stroke var10 = null;
    java.awt.Shape var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Paint var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "", "hi!", "", true, var5, true, var7, true, var9, var10, false, var12, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 10);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var1, var2, var3, var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    java.awt.Stroke var6 = null;
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("", "", "hi!", "", var4, var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1);
    org.jfree.data.general.SeriesChangeInfo var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 100.0f, (-1.0f), var4, 0.0d, var6);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.LineUtilities.clipLine(var0, var1);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
    } catch (java.lang.StringIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     java.awt.Image var0 = null;
//     java.io.ObjectOutputStream var1 = null;
//     org.jfree.chart.util.SerialUtilities.writeImage(var0, var1);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    int var2 = var1.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", var3);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
//     org.jfree.chart.block.BorderArrangement var2 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.block.BorderArrangement var3 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var2, (org.jfree.chart.block.Arrangement)var3);
//     
//     // Checks the contract:  equals-hashcode on var2 and var3
//     assertTrue("Contract failed: equals-hashcode on var2 and var3", var2.equals(var3) ? var2.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var2
//     assertTrue("Contract failed: equals-hashcode on var3 and var2", var3.equals(var2) ? var3.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.lang.Object var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange(var0);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.axis.ValueAxis var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-1), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", var1);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.plot.Marker var9 = null;
//     org.jfree.chart.util.Layer var10 = null;
//     var0.addRangeMarker(var9, var10);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.labels.XYToolTipGenerator var10 = null;
//     org.jfree.chart.urls.XYURLGenerator var11 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
//     org.jfree.chart.urls.XYURLGenerator var16 = var12.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var17 = null;
//     var12.setBaseURLGenerator(var17, false);
//     java.awt.Paint var23 = var12.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var12.getBaseNegativeItemLabelPosition();
//     var3.setSeriesPositiveItemLabelPosition(10, var24);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var3.", var12.equals(var3) == var3.equals(var12));
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, (-1.0d), 10.0f, 1.0f);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.AxisLocation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var1, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, var3, var4, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
//     org.jfree.chart.event.PlotChangeEvent var5 = null;
//     var2.notifyListeners(var5);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.axis.AxisLocation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getIntegerInstance(var0);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.chart.plot.CrosshairState var0 = new org.jfree.chart.plot.CrosshairState();
    var0.setCrosshairX(10.0d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    var1.pan(0.0d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 5.0d, 100.0f, 10.0f);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    java.lang.Object var5 = var4.getTextAntiAlias();
    java.awt.Paint var6 = var4.getBackgroundPaint();
    org.jfree.chart.event.ChartChangeListener var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addChangeListener(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.data.time.RegularTimePeriod var1 = null;
    org.jfree.data.time.RegularTimePeriod var2 = null;
    java.util.TimeZone var3 = null;
    java.util.Locale var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("hi!", var1, var2, var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, (-1.0f));
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.data.xy.XYDataset var0 = null;
    java.util.List var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, var1, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedHeight();
    double var4 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.0d));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.block.Arrangement var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    var4.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var8 = var7.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var9 = var7.getLabelInsets();
    var4.setPadding(var9);
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var9.createOutsetRectangle(var11, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    var4.clearSubtitles();
    org.jfree.chart.title.Title var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addSubtitle(100, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    var4.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var8 = var7.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var9 = var7.getLabelInsets();
    var4.setPadding(var9);
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var12 = var9.createOutsetRectangle(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.awt.Font var1 = null;
    org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var4 = var3.getTickLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("", var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 0);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    var4.clearSubtitles();
    org.jfree.chart.ChartRenderingInfo var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var10 = var4.createBufferedImage(0, 100, 1, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.handleClick(10, (-1), var11);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    java.awt.Paint var1 = null;
    org.jfree.chart.labels.XYToolTipGenerator var3 = null;
    org.jfree.chart.urls.XYURLGenerator var4 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var3, var4);
    org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    java.awt.Paint var16 = var5.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var17 = var5.getBaseNegativeItemLabelPosition();
    java.awt.Paint var19 = null;
    var5.setSeriesOutlinePaint(0, var19, false);
    boolean var22 = var5.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var25 = var24.getRangeAxis();
    org.jfree.chart.LegendItemCollection var26 = var24.getLegendItems();
    java.awt.Stroke var27 = var24.getDomainCrosshairStroke();
    var5.setSeriesOutlineStroke(1, var27);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var32 = null;
    org.jfree.chart.urls.XYURLGenerator var33 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var32, var33);
    org.jfree.chart.urls.XYURLGenerator var38 = var34.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var39 = null;
    var34.setBaseURLGenerator(var39, false);
    java.awt.Paint var45 = var34.getItemFillPaint(10, 100, false);
    var30.setLabelPaint(var45);
    org.jfree.chart.labels.XYToolTipGenerator var48 = null;
    org.jfree.chart.urls.XYURLGenerator var49 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var48, var49);
    org.jfree.chart.urls.XYURLGenerator var54 = var50.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var55 = null;
    var50.setBaseURLGenerator(var55, false);
    java.awt.Paint var61 = var50.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var62 = var50.getBaseNegativeItemLabelPosition();
    java.awt.Paint var64 = null;
    var50.setSeriesOutlinePaint(0, var64, false);
    boolean var67 = var50.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var69 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var70 = var69.getRangeAxis();
    org.jfree.chart.LegendItemCollection var71 = var69.getLegendItems();
    java.awt.Stroke var72 = var69.getDomainCrosshairStroke();
    var50.setSeriesOutlineStroke(1, var72);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var75 = new org.jfree.chart.plot.ValueMarker(100.0d, var1, var27, var45, var72, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
//     java.awt.Stroke var3 = var0.getDomainCrosshairStroke();
//     java.awt.Font var5 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
//     java.lang.Object var9 = var8.getTextAntiAlias();
//     java.awt.Paint var10 = var8.getBackgroundPaint();
//     var0.setDomainMinorGridlinePaint(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(1, var1);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.clipLine(var0, var1);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var3.createOutsetRectangle(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0d, 100.0f, (-1.0f));

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(var0, var1);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.renderer.xy.XYBarPainter var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    var3.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    var3.clearSeriesPaints(true);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var2 = var0.getValue((java.lang.Comparable)(-1));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.util.List var6 = null;
    var0.drawRangeTickBands(var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    java.awt.geom.Point2D var10 = null;
    var0.panDomainAxes(5.0d, var9, var10);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-435));

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    boolean var4 = var0.isDomainPannable();
    org.jfree.chart.plot.DatasetRenderingOrder var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var1 = var0.getRoundingMode();
    java.lang.String var3 = var0.format(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "100"+ "'", var3.equals("100"));

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.chart.labels.StandardXYToolTipGenerator var0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
//     org.jfree.data.xy.XYDataset var1 = null;
//     java.lang.String var4 = var0.generateLabelString(var1, 10, 100);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    java.util.Date var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     var0.setDomainCrosshairVisible(false);
//     java.awt.Font var5 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
//     org.jfree.chart.axis.AxisSpace var9 = null;
//     var6.setFixedRangeAxisSpace(var9);
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
//     var0.setDomainAxisLocation(var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var17 = null;
//     var3.setSeriesOutlinePaint(0, var17, false);
//     boolean var20 = var3.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var23 = var22.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var24 = var22.getLegendItems();
//     java.awt.Stroke var25 = var22.getDomainCrosshairStroke();
//     var3.setSeriesOutlineStroke(1, var25);
//     org.jfree.chart.urls.StandardXYURLGenerator var28 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
//     var3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var28);
//     org.jfree.chart.labels.XYToolTipGenerator var32 = null;
//     org.jfree.chart.urls.XYURLGenerator var33 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var32, var33);
//     org.jfree.chart.urls.XYURLGenerator var38 = var34.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var39 = null;
//     var34.setBaseURLGenerator(var39, false);
//     java.awt.Paint var45 = var34.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var46 = var34.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var48 = null;
//     var34.setSeriesOutlinePaint(0, var48, false);
//     boolean var51 = var34.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var53 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var54 = var53.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var55 = var53.getLegendItems();
//     java.awt.Stroke var56 = var53.getDomainCrosshairStroke();
//     var34.setSeriesOutlineStroke(1, var56);
//     org.jfree.chart.urls.StandardXYURLGenerator var59 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
//     var34.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var59);
//     var3.setSeriesURLGenerator(10, (org.jfree.chart.urls.XYURLGenerator)var59);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var34 and var3.", var34.equals(var3) == var3.equals(var34));
//     
//     // Checks the contract:  equals-hashcode on var15 and var46
//     assertTrue("Contract failed: equals-hashcode on var15 and var46", var15.equals(var46) ? var15.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var15
//     assertTrue("Contract failed: equals-hashcode on var46 and var15", var46.equals(var15) ? var46.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var53
//     assertTrue("Contract failed: equals-hashcode on var22 and var53", var22.equals(var53) ? var22.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var22
//     assertTrue("Contract failed: equals-hashcode on var53 and var22", var53.equals(var22) ? var53.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var55
//     assertTrue("Contract failed: equals-hashcode on var24 and var55", var24.equals(var55) ? var24.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var24
//     assertTrue("Contract failed: equals-hashcode on var55 and var24", var55.equals(var24) ? var55.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var59
//     assertTrue("Contract failed: equals-hashcode on var28 and var59", var28.equals(var59) ? var28.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var28
//     assertTrue("Contract failed: equals-hashcode on var59 and var28", var59.equals(var28) ? var59.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    var0.setDomainCrosshairVisible(false);
    java.awt.Paint var4 = var0.getRangeCrosshairPaint();
    float var5 = var0.getBackgroundImageAlpha();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxis((-1), (-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    org.jfree.data.time.RegularTimePeriod var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     var4.handleClick(0, 100, var7);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    java.util.TimeZone var1 = null;
    java.util.Locale var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("100");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.awt.Font var3 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("", var3, (org.jfree.chart.plot.Plot)var4, false);
    java.lang.Object var7 = var6.getTextAntiAlias();
    java.awt.Paint var8 = var6.getBackgroundPaint();
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.XYURLGenerator var11 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
    org.jfree.chart.urls.XYURLGenerator var16 = var12.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17, false);
    java.awt.Paint var23 = var12.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var24 = var12.getBaseNegativeItemLabelPosition();
    java.awt.Paint var26 = null;
    var12.setSeriesOutlinePaint(0, var26, false);
    boolean var29 = var12.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var32 = var31.getRangeAxis();
    org.jfree.chart.LegendItemCollection var33 = var31.getLegendItems();
    java.awt.Stroke var34 = var31.getDomainCrosshairStroke();
    var12.setSeriesOutlineStroke(1, var34);
    org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var37 = var36.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var40 = null;
    org.jfree.chart.RenderingSource var41 = null;
    var36.select(10.0d, 100.0d, var40, var41);
    var36.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var46 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var47 = var46.getTickLabelPaint();
    var36.setOutlinePaint(var47);
    boolean var49 = var36.isDomainCrosshairLockedOnData();
    org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var51 = var50.getRangeAxis();
    java.awt.Paint var52 = var50.getDomainGridlinePaint();
    var36.setRangeZeroBaselinePaint(var52);
    org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var56 = var55.getStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var58 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d, var8, var34, var52, var56, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var1, var2, var3);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    var0.add((org.jfree.chart.block.Block)var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var7 = var0.arrange(var3, var6);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    org.jfree.data.time.TimeSeriesDataItem var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var1 = var0.getRoundingMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.parse("hi!");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var1, var2);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.update((java.lang.Number)1.0f, (java.lang.Number)10.0f);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    var3.clearSeriesPaints(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSeriesItemLabelsVisible((-435), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(2147483647, (-1), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     org.jfree.chart.plot.PlotState var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var2.draw(var3, var4, var5, var6, var7);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var5 = var3.remove((java.lang.Number)10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var2.setFixedRangeAxisSpace(var5);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     org.jfree.chart.plot.PlotState var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var2.draw(var7, var8, var9, var10, var11);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    var0.setDomainCrosshairVisible(false);
    java.awt.Paint var4 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.Marker var6 = null;
    org.jfree.chart.util.Layer var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var0.removeRangeMarker(0, var6, var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.plot.CrosshairState var0 = new org.jfree.chart.plot.CrosshairState();
    double var1 = var0.getAnchorX();
    java.awt.geom.Point2D var2 = var0.getAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedHeight();
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var5 = var3.toRangeWidth(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("100", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var1);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var3 = var2.getCategoryLabelPositions();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var4 = new org.jfree.chart.entity.AxisEntity(var0, (org.jfree.chart.axis.Axis)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 2.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("100", var1, 0.8f, 0.5f, 1.0d, 10.0f, 0.0f);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(100, 3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    int var1 = var0.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue(2147483647, (java.lang.Comparable)1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    var9.setKey((java.lang.Comparable)2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.update((java.lang.Number)(-1.0f), (java.lang.Number)5.0d);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    double var6 = var3.getRangeBase();
    java.awt.Paint var7 = var3.getBaseOutlinePaint();
    org.jfree.chart.labels.XYToolTipGenerator var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSeriesToolTipGenerator((-435), var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.annotations.XYAnnotation var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addAnnotation(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("100", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.zoomRange(1.0d, 100.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    var1.setAxisLineStroke(var7);
    java.awt.Shape var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var12 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var9, "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 0.0d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     boolean var3 = org.jfree.chart.util.ShapeUtilities.isPointInRect(3.0d, 10.0d, var2);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.setMaximumItemCount(2147483647);
    org.jfree.data.xy.XYDataItem var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add(var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     var0.setDomainCrosshairVisible(false);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var0.drawBackgroundImage(var4, var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     float var9 = var8.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
//     var0.remove((org.jfree.chart.plot.XYPlot)var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.XYURLGenerator var11 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
    org.jfree.chart.urls.XYURLGenerator var16 = var12.getURLGenerator(0, 1, true);
    var12.setBaseSeriesVisibleInLegend(false);
    int var19 = var0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
    org.jfree.data.xy.XYDataset var21 = var0.getDataset(10);
    org.jfree.chart.axis.ValueAxis var23 = var0.getRangeAxis(3);
    org.jfree.chart.plot.Marker var25 = null;
    org.jfree.chart.util.Layer var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(3, var25, var26, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    org.jfree.chart.annotations.XYAnnotation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var5 = var2.removeAnnotation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     boolean var6 = var2.isDrawBarOutline();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     var2.drawBackground(var7, var8, var9);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(0, (-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("{0}: ({1}, {2})", var1, var2);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.RegularTimePeriod var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var9 = var3.addOrUpdate(var7, (java.lang.Number)(short)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    org.jfree.data.time.RegularTimePeriod var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var3.getValue(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    var4.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var8 = var7.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var9 = var7.getLabelInsets();
    var4.setPadding(var9);
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var9.createInsetRectangle(var11, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    var2.setOutlineVisible(true);
    java.awt.Stroke var6 = var2.getRangeCrosshairStroke();
    org.jfree.chart.plot.PlotOrientation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setOrientation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var4 = var3.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var5 = null;
    var3.setDrawingSupplier(var5);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    java.lang.Object var8 = null;
    boolean var9 = var3.equals(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var11 = var3.getQuadrantPaint((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("100", var1);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var8 = var7.getStroke();
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker((org.jfree.chart.plot.Marker)var7, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesFilled(2147483647, true);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(10, var1);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(0.0d, var14, var15, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 100);
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    float[] var5 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var2.getRGBComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    var3.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var13 = var3.getItemLabelGenerator(1, 1, true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var3.getPositiveItemLabelPosition((-1), 0, false);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.xy.XYDataItem var3 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
//     java.lang.Number var4 = var3.getX();
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)var3);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var7.setFixedDomainAxisSpace(var8, true);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     java.util.List var13 = null;
//     var7.drawRangeTickBands(var11, var12, var13);
//     org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var17 = var16.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var18 = null;
//     var16.setDrawingSupplier(var18);
//     float var20 = var16.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var24 = null;
//     org.jfree.chart.urls.XYURLGenerator var25 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var24, var25);
//     org.jfree.chart.urls.XYURLGenerator var30 = var26.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var31 = null;
//     var26.setBaseURLGenerator(var31, false);
//     java.awt.Paint var37 = var26.getItemFillPaint(10, 100, false);
//     var22.setLabelPaint(var37);
//     float var39 = var22.getAlpha();
//     org.jfree.chart.util.Layer var40 = null;
//     boolean var41 = var16.removeDomainMarker((org.jfree.chart.plot.Marker)var22, var40);
//     org.jfree.chart.util.Layer var42 = null;
//     boolean var43 = var7.removeRangeMarker((-1), (org.jfree.chart.plot.Marker)var22, var42);
//     org.jfree.chart.axis.PeriodAxis var45 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var46 = var45.getTickLabelPaint();
//     java.lang.Class var47 = var45.getMajorTickTimePeriodClass();
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.data.xy.DefaultXYDataset var49 = new org.jfree.data.xy.DefaultXYDataset();
//     var0.drawItem(var4, var5, var6, (org.jfree.chart.plot.XYPlot)var7, (org.jfree.chart.axis.ValueAxis)var45, var48, (org.jfree.data.xy.XYDataset)var49, 2147483647, 3, false, 255);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var3.createInsetRectangle(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     var3.setBaseSeriesVisibleInLegend(false);
//     org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
//     var3.setBaseItemLabelGenerator(var10);
//     java.awt.Font var13 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
//     var16.clearSubtitles();
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var20 = var19.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
//     var16.setPadding(var21);
//     org.jfree.chart.event.ChartChangeEventType var23 = null;
//     org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var16, var23);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     java.awt.geom.Point2D var27 = null;
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     var16.draw(var25, var26, var27, var28);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.setUpperMargin(0.0d);
    var1.setRange(10.0d, 10.0d);
    java.util.TimeZone var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var2.setFixedRangeAxisSpace(var5);
//     org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
//     java.awt.Paint var8 = var2.getDomainGridlinePaint();
//     java.awt.Font var10 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("", var10, (org.jfree.chart.plot.Plot)var11, false);
//     org.jfree.chart.axis.AxisSpace var14 = null;
//     var11.setFixedRangeAxisSpace(var14);
//     org.jfree.chart.axis.AxisLocation var16 = var11.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var17 = var16.getOpposite();
//     var2.setRangeAxisLocation(var16);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var11 = var10.getTickLabelPaint();
//     var0.setOutlinePaint(var11);
//     boolean var13 = var0.isDomainCrosshairLockedOnData();
//     java.lang.Object var14 = var0.clone();
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     org.jfree.chart.plot.PlotState var18 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     var0.draw(var15, var16, var17, var18, var19);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 0.0f, 0.0f, 100.0d, 10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 100);
    int var5 = var4.getBlue();
    java.awt.Color var6 = var4.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("", var1, (java.awt.Paint)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedHeight();
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var5 = var3.toRangeHeight(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var3, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "100", "hi!");
    java.util.List var8 = var7.getContributors();
    var7.setLicenceText("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    var1.setMinorTickMarksVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    org.jfree.chart.util.RectangleAnchor var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var14, var17, 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
//     var7.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.Marker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var3.drawDomainMarker(var6, (org.jfree.chart.plot.XYPlot)var7, var11, var12, var13);
//     var3.setAutoPopulateSeriesOutlinePaint(true);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var19 = var18.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.RenderingSource var23 = null;
//     var18.select(10.0d, 100.0d, var22, var23);
//     var18.setOutlineVisible(false);
//     org.jfree.chart.axis.PeriodAxis var28 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var29 = var28.getTickLabelPaint();
//     var18.setOutlinePaint(var29);
//     boolean var31 = var18.isDomainZeroBaselineVisible();
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     org.jfree.chart.plot.CrosshairState var36 = new org.jfree.chart.plot.CrosshairState();
//     org.jfree.chart.plot.PlotOrientation var43 = null;
//     var36.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var43);
//     double var45 = var36.getCrosshairY();
//     boolean var46 = var18.render(var32, var33, 10, var35, var36);
//     java.lang.Object var47 = null;
//     boolean var48 = var18.equals(var47);
//     org.jfree.chart.axis.PeriodAxis var50 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var51 = var50.getTickLabelPaint();
//     var50.setUpperMargin(0.0d);
//     java.awt.Paint var54 = var50.getLabelPaint();
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.axis.PeriodAxis var58 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var59 = var58.getTickLabelPaint();
//     java.lang.Class var60 = var58.getMajorTickTimePeriodClass();
//     java.awt.Paint var61 = var58.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var63 = null;
//     org.jfree.chart.urls.XYURLGenerator var64 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var65 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var63, var64);
//     org.jfree.chart.urls.XYURLGenerator var69 = var65.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var70 = null;
//     var65.setBaseURLGenerator(var70, false);
//     java.awt.Paint var76 = var65.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var77 = var65.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var79 = null;
//     var65.setSeriesOutlinePaint(0, var79, false);
//     boolean var82 = var65.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var84 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var85 = var84.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var86 = var84.getLegendItems();
//     java.awt.Stroke var87 = var84.getDomainCrosshairStroke();
//     var65.setSeriesOutlineStroke(1, var87);
//     java.awt.Stroke var90 = var65.getSeriesOutlineStroke(1);
//     var3.drawDomainLine(var17, (org.jfree.chart.plot.XYPlot)var18, (org.jfree.chart.axis.ValueAxis)var50, var55, 2.0d, var61, var90);
//     
//     // Checks the contract:  equals-hashcode on var3 and var65
//     assertTrue("Contract failed: equals-hashcode on var3 and var65", var3.equals(var65) ? var3.hashCode() == var65.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var65.", var3.equals(var65) == var65.equals(var3));
//     
//     // Checks the contract:  equals-hashcode on var7 and var84
//     assertTrue("Contract failed: equals-hashcode on var7 and var84", var7.equals(var84) ? var7.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var7
//     assertTrue("Contract failed: equals-hashcode on var84 and var7", var84.equals(var7) ? var84.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    org.jfree.chart.labels.XYToolTipGenerator var3 = null;
    org.jfree.chart.urls.XYURLGenerator var4 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var3, var4);
    org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    java.awt.Paint var16 = var5.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var17 = var5.getBaseNegativeItemLabelPosition();
    java.awt.Paint var19 = null;
    var5.setSeriesOutlinePaint(0, var19, false);
    boolean var22 = var5.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var25 = var24.getRangeAxis();
    org.jfree.chart.LegendItemCollection var26 = var24.getLegendItems();
    java.awt.Stroke var27 = var24.getDomainCrosshairStroke();
    var5.setSeriesOutlineStroke(1, var27);
    org.jfree.chart.labels.StandardXYToolTipGenerator var30 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    var5.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var30);
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var30, true);
    var0.setUseOutlinePaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    org.jfree.data.time.TimeSeriesDataItem var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add(var4, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.awt.GradientPaint var1 = null;
//     java.awt.Shape var2 = null;
//     java.awt.GradientPaint var3 = var0.transform(var1, var2);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
    org.jfree.data.xy.DefaultXYDataset var2 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var1.generateLabel((org.jfree.data.xy.XYDataset)var2, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var2.setFixedRangeAxisSpace(var5);
    org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
    org.jfree.chart.plot.DatasetRenderingOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setDatasetRenderingOrder(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = null;
//     var2.setSeriesURLGenerator(3, var7, true);
//     int var10 = var2.getPassCount();
//     double var11 = var2.getYOffset();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var2.drawDomainGridline(var12, var13, var14, Double.NaN);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.axis.TickType var0 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var4 = null;
//     org.jfree.chart.urls.XYURLGenerator var5 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var4, var5);
//     org.jfree.chart.urls.XYURLGenerator var10 = var6.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var11 = null;
//     var6.setBaseURLGenerator(var11, false);
//     java.awt.Paint var17 = var6.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var6.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var19 = var18.getTextAnchor();
//     org.jfree.chart.labels.XYToolTipGenerator var21 = null;
//     org.jfree.chart.urls.XYURLGenerator var22 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
//     org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var28 = null;
//     var23.setBaseURLGenerator(var28, false);
//     java.awt.Paint var34 = var23.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var35 = var23.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var36 = var35.getTextAnchor();
//     java.lang.String var37 = var36.toString();
//     org.jfree.chart.axis.NumberTick var39 = new org.jfree.chart.axis.NumberTick(var0, Double.NaN, "ERROR : Relative To String", var19, var36, 3.0d);
//     
//     // Checks the contract:  equals-hashcode on var18 and var35
//     assertTrue("Contract failed: equals-hashcode on var18 and var35", var18.equals(var35) ? var18.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var18
//     assertTrue("Contract failed: equals-hashcode on var35 and var18", var35.equals(var18) ? var35.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.axis.AxisSpace var4 = var0.getFixedDomainAxisSpace();
    java.awt.Font var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var7, false);
    var9.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var13 = var12.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var9.setPadding(var14);
    double var17 = var14.calculateLeftInset(100.0d);
    var0.setInsets(var14);
    var0.clearDomainMarkers(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var21 = var0.clone();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer();
//     var1.add((org.jfree.chart.block.Block)var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.Range var5 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, 10.0d);
//     double var8 = var7.getHeight();
//     org.jfree.chart.util.Size2D var9 = var0.arrange(var2, var4, var7);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.labels.XYToolTipGenerator var5 = null;
    org.jfree.chart.urls.XYURLGenerator var6 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var5, var6);
    org.jfree.chart.event.RendererChangeEvent var8 = null;
    var7.notifyListeners(var8);
    var7.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var13 = var7.getBaseShape();
    java.awt.Paint var14 = null;
    org.jfree.chart.labels.XYToolTipGenerator var16 = null;
    org.jfree.chart.urls.XYURLGenerator var17 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var16, var17);
    org.jfree.chart.urls.XYURLGenerator var22 = var18.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var23 = null;
    var18.setBaseURLGenerator(var23, false);
    java.awt.Paint var29 = var18.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var30 = var18.getBaseNegativeItemLabelPosition();
    java.awt.Paint var32 = null;
    var18.setSeriesOutlinePaint(0, var32, false);
    boolean var35 = var18.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var38 = var37.getRangeAxis();
    org.jfree.chart.LegendItemCollection var39 = var37.getLegendItems();
    java.awt.Stroke var40 = var37.getDomainCrosshairStroke();
    var18.setSeriesOutlineStroke(1, var40);
    java.awt.Stroke var45 = var18.getItemStroke(0, (-1), false);
    org.jfree.chart.plot.CombinedDomainXYPlot var46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var47 = var46.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var50 = null;
    org.jfree.chart.RenderingSource var51 = null;
    var46.select(10.0d, 100.0d, var50, var51);
    var46.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var56 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var57 = var56.getTickLabelPaint();
    var46.setOutlinePaint(var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem(var0, "ERROR : Relative To String", "{0}: ({1}, {2})", "TextAnchor.TOP_CENTER", var13, var14, var45, var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.chart.util.SortOrder var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByKeys(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    org.jfree.chart.labels.XYToolTipGenerator var3 = null;
    org.jfree.chart.urls.XYURLGenerator var4 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var3, var4);
    org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    java.awt.Paint var16 = var5.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var17 = var5.getBaseNegativeItemLabelPosition();
    java.awt.Paint var19 = null;
    var5.setSeriesOutlinePaint(0, var19, false);
    boolean var22 = var5.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var25 = var24.getRangeAxis();
    org.jfree.chart.LegendItemCollection var26 = var24.getLegendItems();
    java.awt.Stroke var27 = var24.getDomainCrosshairStroke();
    var5.setSeriesOutlineStroke(1, var27);
    org.jfree.chart.labels.StandardXYToolTipGenerator var30 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    var5.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var30);
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var30, true);
    java.awt.Shape var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-435), var35, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.setMaximumItemCount(2147483647);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.updateByIndex(3, (java.lang.Number)(byte)(-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    java.awt.Font var1 = null;
    java.awt.Font var3 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("", var3, (org.jfree.chart.plot.Plot)var4, false);
    org.jfree.chart.axis.AxisSpace var7 = null;
    var4.setFixedRangeAxisSpace(var7);
    org.jfree.chart.axis.AxisLocation var9 = var4.getDomainAxisLocation();
    java.awt.Paint var10 = var4.getDomainGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("100", var1, var10, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("100", var1, 100.0f, 0.8f, 5.0d, 0.0f, (-1.0f));
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(0.0d, Double.NaN);
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
//     var2.setFixedLegendItems(var6);
//     java.lang.Object var8 = var6.clone();
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var10);
//     double var12 = var11.getGap();
//     org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var14 = var13.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var15 = var13.getLegendItems();
//     var11.setFixedLegendItems(var15);
//     var6.addAll(var15);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     java.text.NumberFormat var1 = java.text.NumberFormat.getInstance();
//     java.math.RoundingMode var2 = var1.getRoundingMode();
//     boolean var3 = var1.isGroupingUsed();
//     org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, 0);
//     java.math.RoundingMode var6 = var1.getRoundingMode();
//     java.text.ParsePosition var8 = null;
//     java.lang.Object var9 = var1.parseObject("100", var8);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.util.PaintMap var0 = new org.jfree.chart.util.PaintMap();
    var0.clear();

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.add((org.jfree.chart.plot.XYPlot)var6, 100);
    org.jfree.chart.annotations.XYAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    org.jfree.chart.util.RectangleInsets var3 = var1.getPadding();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.LengthAdjustmentType var5 = null;
    org.jfree.chart.util.LengthAdjustmentType var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var7 = var3.createAdjustedRectangle(var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var3 = null;
    org.jfree.chart.urls.XYURLGenerator var4 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var3, var4);
    org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    java.awt.Paint var16 = var5.getItemFillPaint(10, 100, false);
    var1.setLabelPaint(var16);
    float var18 = var1.getAlpha();
    java.awt.Paint var19 = var1.getOutlinePaint();
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var21);
    double var23 = var22.getGap();
    var22.setOutlineVisible(true);
    var22.clearRangeMarkers();
    org.jfree.chart.labels.XYToolTipGenerator var28 = null;
    org.jfree.chart.urls.XYURLGenerator var29 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var28, var29);
    org.jfree.chart.event.RendererChangeEvent var31 = null;
    var30.notifyListeners(var31);
    var22.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var30);
    org.jfree.chart.labels.XYSeriesLabelGenerator var34 = var30.getLegendItemLabelGenerator();
    java.awt.Stroke var35 = var30.getBaseOutlineStroke();
    var1.setOutlineStroke(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.renderer.xy.XYStepRenderer var1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var1.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var1.setBaseLinesVisible(true);
//     boolean var9 = var1.getItemShapeFilled(0, 1);
//     java.awt.Shape var11 = var1.lookupSeriesShape((-1));
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, 3.0d, 1.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var14, 100.0d, 0.0f, 0.0f);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.labels.XYToolTipGenerator var2 = null;
    org.jfree.chart.urls.XYURLGenerator var3 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var2, var3);
    org.jfree.chart.urls.XYURLGenerator var8 = var4.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    var4.setBaseURLGenerator(var9, false);
    java.awt.Paint var15 = var4.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var16 = var4.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var17 = var16.getTextAnchor();
    java.lang.String var18 = var17.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var19 = new org.jfree.chart.labels.ItemLabelPosition(var0, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "TextAnchor.TOP_CENTER"+ "'", var18.equals("TextAnchor.TOP_CENTER"));

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     var0.setRenderer(var1);
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     var0.setDataset(var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     org.jfree.chart.plot.PlotState var8 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var0.draw(var5, var6, var7, var8, var9);
// 
//   }

//  public void test187() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("{0}: ({1}, {2})", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
//     org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
//     java.awt.Font var4 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("", var4, (org.jfree.chart.plot.Plot)var5, false);
//     java.lang.Object var8 = var7.getTextAntiAlias();
//     var7.setBackgroundImageAlignment(2147483647);
//     java.awt.RenderingHints var11 = var7.getRenderingHints();
//     var1.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var7);
//     org.jfree.chart.event.TitleChangeEvent var13 = null;
//     var7.titleChanged(var13);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     var1.zoomRange(1.0d, 100.0d);
//     double var6 = var1.getLowerMargin();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var10.setCategoryLabelPositionOffset(2147483647);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var17 = var16.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var18 = null;
//     var16.setDrawingSupplier(var18);
//     float var20 = var16.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var24 = null;
//     org.jfree.chart.urls.XYURLGenerator var25 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var24, var25);
//     org.jfree.chart.urls.XYURLGenerator var30 = var26.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var31 = null;
//     var26.setBaseURLGenerator(var31, false);
//     java.awt.Paint var37 = var26.getItemFillPaint(10, 100, false);
//     var22.setLabelPaint(var37);
//     float var39 = var22.getAlpha();
//     org.jfree.chart.util.Layer var40 = null;
//     boolean var41 = var16.removeDomainMarker((org.jfree.chart.plot.Marker)var22, var40);
//     org.jfree.chart.util.RectangleEdge var42 = var16.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisState var43 = null;
//     var10.drawTickMarks(var13, 10.0d, var15, var42, var43);
//     double var45 = var1.valueToJava2D(5.0d, var8, var42);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("100", var1, (-1.0f), 1.0f, 1.0d, 10.0f, 1.0f);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    boolean var4 = var1.isAutoTickUnitSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var5.getRangeAxis();
    org.jfree.chart.LegendItemCollection var7 = var5.getLegendItems();
    java.awt.Stroke var8 = var5.getDomainCrosshairStroke();
    var1.setMinorTickMarkStroke(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    var1.setCategoryLabelPositionOffset(2147483647);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var7.setDrawingSupplier(var9);
    float var11 = var7.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var15 = null;
    org.jfree.chart.urls.XYURLGenerator var16 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
    org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    var17.setBaseURLGenerator(var22, false);
    java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
    var13.setLabelPaint(var28);
    float var30 = var13.getAlpha();
    org.jfree.chart.util.Layer var31 = null;
    boolean var32 = var7.removeDomainMarker((org.jfree.chart.plot.Marker)var13, var31);
    org.jfree.chart.util.RectangleEdge var33 = var7.getRangeAxisEdge();
    org.jfree.chart.axis.AxisState var34 = null;
    var1.drawTickMarks(var4, 10.0d, var6, var33, var34);
    var1.setTickLabelsVisible(false);
    var1.setMaximumCategoryLabelWidthRatio(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getInstance(var0);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
//     java.lang.String var4 = var1.getCategoryLabelToolTip((java.lang.Comparable)"{0}: ({1}, {2})");
//     var1.setVisible(true);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var9 = var8.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.RenderingSource var13 = null;
//     var8.select(10.0d, 100.0d, var12, var13);
//     var8.setOutlineVisible(false);
//     org.jfree.chart.labels.XYToolTipGenerator var18 = null;
//     org.jfree.chart.urls.XYURLGenerator var19 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var18, var19);
//     org.jfree.chart.urls.XYURLGenerator var24 = var20.getURLGenerator(0, 1, true);
//     var20.setBaseSeriesVisibleInLegend(false);
//     int var27 = var8.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var20);
//     org.jfree.data.xy.XYDataset var29 = var8.getDataset(10);
//     org.jfree.chart.axis.ValueAxis var31 = var8.getRangeAxis(3);
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     org.jfree.chart.axis.AxisSpace var34 = null;
//     org.jfree.chart.axis.AxisSpace var35 = var1.reserveSpace(var7, (org.jfree.chart.plot.Plot)var8, var32, var33, var34);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesShape(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    float var6 = var5.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    java.awt.Paint var8 = var7.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendTextPaint((-435), var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("100", var1);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer();
//     var15.add((org.jfree.chart.block.Block)var16);
//     var14.setWrapper(var16);
//     
//     // Checks the contract:  equals-hashcode on var9 and var15
//     assertTrue("Contract failed: equals-hashcode on var9 and var15", var9.equals(var15) ? var9.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var16
//     assertTrue("Contract failed: equals-hashcode on var10 and var16", var10.equals(var16) ? var10.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var9
//     assertTrue("Contract failed: equals-hashcode on var15 and var9", var15.equals(var9) ? var15.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var10
//     assertTrue("Contract failed: equals-hashcode on var16 and var10", var16.equals(var10) ? var16.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var1.setUpperMargin(5.0d);
//     org.jfree.chart.axis.CategoryAnchor var4 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var9.setCategoryLabelPositionOffset(2147483647);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var16 = var15.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var17 = null;
//     var15.setDrawingSupplier(var17);
//     float var19 = var15.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var23 = null;
//     org.jfree.chart.urls.XYURLGenerator var24 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var23, var24);
//     org.jfree.chart.urls.XYURLGenerator var29 = var25.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var30 = null;
//     var25.setBaseURLGenerator(var30, false);
//     java.awt.Paint var36 = var25.getItemFillPaint(10, 100, false);
//     var21.setLabelPaint(var36);
//     float var38 = var21.getAlpha();
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var15.removeDomainMarker((org.jfree.chart.plot.Marker)var21, var39);
//     org.jfree.chart.util.RectangleEdge var41 = var15.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisState var42 = null;
//     var9.drawTickMarks(var12, 10.0d, var14, var41, var42);
//     double var44 = var1.getCategoryJava2DCoordinate(var4, 255, (-1), var7, var41);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var2.setFixedRangeAxisSpace(var5);
    float var7 = var2.getBackgroundImageAlpha();
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var2.getRangeMarkers(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
    java.awt.Paint var17 = var3.lookupSeriesOutlinePaint(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var2 = null;
//     var0.setDrawingSupplier(var2);
//     float var4 = var0.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var8 = null;
//     org.jfree.chart.urls.XYURLGenerator var9 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
//     org.jfree.chart.urls.XYURLGenerator var14 = var10.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var15 = null;
//     var10.setBaseURLGenerator(var15, false);
//     java.awt.Paint var21 = var10.getItemFillPaint(10, 100, false);
//     var6.setLabelPaint(var21);
//     float var23 = var6.getAlpha();
//     org.jfree.chart.util.Layer var24 = null;
//     boolean var25 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var6, var24);
//     org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge();
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.awt.geom.Point2D var29 = null;
//     org.jfree.chart.plot.PlotState var30 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     var0.draw(var27, var28, var29, var30, var31);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.axis.AxisSpace var4 = var0.getFixedDomainAxisSpace();
    java.awt.Font var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var7, false);
    var9.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var13 = var12.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var9.setPadding(var14);
    double var17 = var14.calculateLeftInset(100.0d);
    var0.setInsets(var14);
    org.jfree.chart.annotations.XYAnnotation var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var20 = var0.removeAnnotation(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("", var1);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Font var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelFont(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
    java.awt.Paint var17 = null;
    var3.setSeriesOutlinePaint(0, var17, false);
    boolean var20 = var3.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var23 = var22.getRangeAxis();
    org.jfree.chart.LegendItemCollection var24 = var22.getLegendItems();
    java.awt.Stroke var25 = var22.getDomainCrosshairStroke();
    var3.setSeriesOutlineStroke(1, var25);
    org.jfree.chart.urls.StandardXYURLGenerator var28 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    var3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var28);
    org.jfree.chart.annotations.XYAnnotation var30 = null;
    org.jfree.chart.util.Layer var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addAnnotation(var30, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    org.jfree.data.time.RegularTimePeriod var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add(var4, (java.lang.Number)0L, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     java.lang.String var4 = var3.getRangeDescription();
//     double var5 = var3.getMinY();
//     boolean var6 = var3.getNotify();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + ""+ "'", var4.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var3.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    var3.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
    var3.setBaseItemLabelGenerator(var10);
    java.awt.Font var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
    var16.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var20 = var19.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
    var16.setPadding(var21);
    org.jfree.chart.event.ChartChangeEventType var23 = null;
    org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var16, var23);
    org.jfree.chart.JFreeChart var25 = var24.getChart();
    java.lang.String var26 = var24.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.setUpperMargin(0.0d);
    java.awt.Paint var5 = var1.getLabelPaint();
    java.awt.Stroke var6 = var1.getAxisLineStroke();
    org.jfree.chart.util.RectangleInsets var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    var7.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var3.drawDomainMarker(var6, (org.jfree.chart.plot.XYPlot)var7, var11, var12, var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setBackgroundImageAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setMinorTickMarksVisible(false);
    double var6 = var1.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var5 = var4.getStroke();
    double var6 = var4.getValue();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var4);
    java.awt.Stroke var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setStroke(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    boolean var1 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.annotations.XYAnnotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var2, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var8 = null;
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
    org.jfree.chart.urls.XYURLGenerator var14 = var10.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    var10.setBaseURLGenerator(var15, false);
    java.awt.Paint var21 = var10.getItemFillPaint(10, 100, false);
    var6.setLabelPaint(var21);
    float var23 = var6.getAlpha();
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var6, var24);
    org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var28 = var27.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var29 = var27.getLabelInsets();
    var6.setLabelOffset(var29);
    org.jfree.chart.util.RectangleAnchor var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLabelAnchor(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.awt.Font var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedRangeAxisSpace(var9);
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var12 = var11.getOpposite();
    boolean var13 = var3.equals((java.lang.Object)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var15 = var3.remove((java.lang.Number)0.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     double var6 = var3.getItemLabelAnchorOffset();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var9 = var8.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.RenderingSource var13 = null;
//     var8.select(10.0d, 100.0d, var12, var13);
//     var8.setOutlineVisible(false);
//     org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var19 = var18.getTickLabelPaint();
//     var8.setOutlinePaint(var19);
//     boolean var21 = var8.isDomainCrosshairLockedOnData();
//     org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var23 = var22.getRangeAxis();
//     java.awt.Paint var24 = var22.getDomainGridlinePaint();
//     var8.setRangeZeroBaselinePaint(var24);
//     org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var28 = var27.getTickLabelPaint();
//     var27.setUpperMargin(0.0d);
//     java.awt.Paint var31 = var27.getLabelPaint();
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var35 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     float var36 = var35.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var35);
//     java.awt.Paint var38 = var37.getBackgroundPaint();
//     org.jfree.chart.axis.PeriodAxis var40 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var41 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var40);
//     double var42 = var41.getGap();
//     var41.setOutlineVisible(true);
//     var41.clearRangeMarkers();
//     org.jfree.chart.labels.XYToolTipGenerator var47 = null;
//     org.jfree.chart.urls.XYURLGenerator var48 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var47, var48);
//     org.jfree.chart.event.RendererChangeEvent var50 = null;
//     var49.notifyListeners(var50);
//     var41.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var49);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var53 = var49.getLegendItemLabelGenerator();
//     java.awt.Stroke var54 = var49.getBaseOutlineStroke();
//     var3.drawDomainLine(var7, (org.jfree.chart.plot.XYPlot)var8, (org.jfree.chart.axis.ValueAxis)var27, var32, 5.0d, var38, var54);
//     
//     // Checks the contract:  equals-hashcode on var22 and var35
//     assertTrue("Contract failed: equals-hashcode on var22 and var35", var22.equals(var35) ? var22.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var22
//     assertTrue("Contract failed: equals-hashcode on var35 and var22", var35.equals(var22) ? var35.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)0L);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset)var0, 2147483647, 10.0d, Double.NaN);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}: ({1}, {2})", var3);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.DomainOrder var24 = var18.getDomainOrder();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var27 = var18.getY((-1), 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var8 = null;
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
    org.jfree.chart.urls.XYURLGenerator var14 = var10.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    var10.setBaseURLGenerator(var15, false);
    java.awt.Paint var21 = var10.getItemFillPaint(10, 100, false);
    var6.setLabelPaint(var21);
    float var23 = var6.getAlpha();
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var6, var24);
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    java.awt.geom.Point2D var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(0.0d, var27, var28, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.util.List var6 = null;
    var0.drawRangeTickBands(var4, var5, var6);
    org.jfree.data.xy.XYDataset var9 = var0.getDataset(1);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(2.0d, var11, var12, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    boolean var13 = var0.isDomainCrosshairLockedOnData();
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var15 = var14.getRangeAxis();
    java.awt.Paint var16 = var14.getDomainGridlinePaint();
    var0.setRangeZeroBaselinePaint(var16);
    org.jfree.chart.axis.AxisLocation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var18, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    java.util.TimeZone var0 = null;
    java.util.Locale var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.Font var3 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("", var3, (org.jfree.chart.plot.Plot)var4, false);
    org.jfree.chart.axis.AxisSpace var7 = null;
    var4.setFixedRangeAxisSpace(var7);
    org.jfree.chart.axis.AxisLocation var9 = var4.getDomainAxisLocation();
    java.awt.Paint var10 = var4.getDomainGridlinePaint();
    var0.setRangeZeroBaselinePaint(var10);
    java.lang.Object var12 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.data.function.Function2D var0 = null;
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(var0, 3.0d, 1.0E-5d, 2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var3, (org.jfree.chart.urls.XYURLGenerator)var5);
    org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Number var8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var3.generateLabelString((org.jfree.data.xy.XYDataset)var7, 0, 70);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var3 = var2.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.RenderingSource var7 = null;
    var2.select(10.0d, 100.0d, var6, var7);
    var2.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var12 = null;
    org.jfree.chart.urls.XYURLGenerator var13 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var12, var13);
    org.jfree.chart.urls.XYURLGenerator var18 = var14.getURLGenerator(0, 1, true);
    var14.setBaseSeriesVisibleInLegend(false);
    int var21 = var2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var14);
    org.jfree.chart.plot.CombinedDomainXYPlot var23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var24 = var23.getRangeAxis();
    java.awt.Paint var25 = var23.getDomainGridlinePaint();
    var14.setSeriesFillPaint(0, var25);
    org.jfree.chart.axis.PeriodAxis var28 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var29 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var28);
    double var30 = var29.getGap();
    var29.setOutlineVisible(true);
    java.awt.Stroke var33 = var29.getRangeCrosshairStroke();
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, var25, var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(var0, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset)var0, 0, 3.0d, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     long var0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == (-2208960000000L));
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var17 = var16.getTickLabelPaint();
    var3.setBasePaint(var17);
    var3.setPlotArea(false);
    java.awt.Paint var22 = var3.getSeriesFillPaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var11 = var9.getSeries(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     org.jfree.chart.labels.XYToolTipGenerator var3 = null;
//     org.jfree.chart.urls.XYURLGenerator var4 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var3, var4);
//     org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var10 = null;
//     var5.setBaseURLGenerator(var10, false);
//     java.awt.Paint var16 = var5.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var5.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var19 = null;
//     var5.setSeriesOutlinePaint(0, var19, false);
//     boolean var22 = var5.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var25 = var24.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var26 = var24.getLegendItems();
//     java.awt.Stroke var27 = var24.getDomainCrosshairStroke();
//     var5.setSeriesOutlineStroke(1, var27);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var30 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
//     var5.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var30);
//     var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var30, true);
//     org.jfree.chart.block.BlockBorder var39 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d);
//     java.awt.Paint var40 = var39.getPaint();
//     var0.setSeriesPaint(100, var40);
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var45 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     boolean var46 = var45.isDomainCrosshairLockedOnData();
//     org.jfree.chart.axis.PeriodAxis var48 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var49 = var48.getTickLabelPaint();
//     java.lang.Class var50 = var48.getMajorTickTimePeriodClass();
//     var48.setMinorTickMarkInsideLength(0.0f);
//     org.jfree.chart.axis.PeriodAxis var54 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var55 = var54.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var56 = var54.getLabelInsets();
//     boolean var57 = var54.isAxisLineVisible();
//     var54.setPositiveArrowVisible(false);
//     java.lang.String var60 = var54.getLabelToolTip();
//     org.jfree.data.xy.XYSeries var64 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.lang.Object var65 = var64.clone();
//     var64.add(0.0d, 100.0d, true);
//     org.jfree.data.xy.XYSeriesCollection var70 = new org.jfree.data.xy.XYSeriesCollection(var64);
//     var0.drawItem(var42, var43, var44, (org.jfree.chart.plot.XYPlot)var45, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.data.xy.XYDataset)var70, (-1), 255, true, 3);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    java.text.NumberFormat var7 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var8 = var7.getRoundingMode();
    boolean var9 = var7.isGroupingUsed();
    java.text.NumberFormat var10 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var11 = var10.getRoundingMode();
    var7.setRoundingMode(var11);
    var0.setValue((java.lang.Comparable)var11, (java.lang.Number)3);
    org.jfree.chart.util.SortOrder var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByValues(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var2 = null;
//     var0.setDrawingSupplier(var2);
//     org.jfree.chart.axis.AxisSpace var4 = var0.getFixedDomainAxisSpace();
//     java.awt.Font var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var7, false);
//     var9.clearSubtitles();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var13 = var12.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
//     var9.setPadding(var14);
//     double var17 = var14.calculateLeftInset(100.0d);
//     var0.setInsets(var14);
//     org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var20 = var19.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.RenderingSource var24 = null;
//     var19.select(10.0d, 100.0d, var23, var24);
//     var19.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var28 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var29 = new org.jfree.chart.block.BlockContainer();
//     var28.add((org.jfree.chart.block.Block)var29);
//     org.jfree.chart.block.Arrangement var31 = var28.getArrangement();
//     org.jfree.chart.block.BorderArrangement var32 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19, var31, (org.jfree.chart.block.Arrangement)var32);
//     java.awt.Paint var34 = var33.getItemPaint();
//     var0.setDomainTickBandPaint(var34);
//     java.awt.Font var37 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("", var37, (org.jfree.chart.plot.Plot)var38, false);
//     var40.clearSubtitles();
//     java.awt.Paint var42 = var40.getBorderPaint();
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
//     
//     // Checks the contract:  equals-hashcode on var7 and var38
//     assertTrue("Contract failed: equals-hashcode on var7 and var38", var7.equals(var38) ? var7.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var7
//     assertTrue("Contract failed: equals-hashcode on var38 and var7", var38.equals(var7) ? var38.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue((-435), (java.lang.Comparable)(short)(-1), 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    var1.setCategoryLabelPositionOffset(2147483647);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var7.setDrawingSupplier(var9);
    float var11 = var7.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var15 = null;
    org.jfree.chart.urls.XYURLGenerator var16 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
    org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    var17.setBaseURLGenerator(var22, false);
    java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
    var13.setLabelPaint(var28);
    float var30 = var13.getAlpha();
    org.jfree.chart.util.Layer var31 = null;
    boolean var32 = var7.removeDomainMarker((org.jfree.chart.plot.Marker)var13, var31);
    org.jfree.chart.util.RectangleEdge var33 = var7.getRangeAxisEdge();
    org.jfree.chart.axis.AxisState var34 = null;
    var1.drawTickMarks(var4, 10.0d, var6, var33, var34);
    var1.setMaximumCategoryLabelWidthRatio(0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
//     var2.setFixedLegendItems(var6);
//     org.jfree.data.xy.XYSeries var11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.awt.Font var13 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var14.setFixedRangeAxisSpace(var17);
//     org.jfree.chart.axis.AxisLocation var19 = var14.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var20 = var19.getOpposite();
//     boolean var21 = var11.equals((java.lang.Object)var19);
//     var2.setRangeAxisLocation(var19);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    var4.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var8 = var7.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var9 = var7.getLabelInsets();
    var4.setPadding(var9);
    double var12 = var9.calculateBottomOutset(1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.0d);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 0);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var0.setBaseLinesVisible(true);
    int var6 = var0.getPassCount();
    var0.setBaseSeriesVisibleInLegend(true, true);
    java.awt.Font var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelFont(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.XYURLGenerator var11 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
    org.jfree.chart.urls.XYURLGenerator var16 = var12.getURLGenerator(0, 1, true);
    var12.setBaseSeriesVisibleInLegend(false);
    int var19 = var0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
    boolean var20 = var12.getBaseSeriesVisibleInLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var5.getRangeAxis();
    org.jfree.chart.LegendItemCollection var7 = var5.getLegendItems();
    java.awt.Stroke var8 = var5.getDomainCrosshairStroke();
    var1.setMinorTickMarkStroke(var8);
    boolean var10 = var1.isInverted();
    var1.setMinorTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var9.getY(10, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
//     org.jfree.data.xy.XYDataItem var21 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-435), (java.lang.Number)10.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer(var12, (org.jfree.data.general.Dataset)var15, (java.lang.Comparable)(-435));
//     org.jfree.data.general.Dataset var23 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var25 = new org.jfree.chart.title.LegendItemBlockContainer(var12, var23, (java.lang.Comparable)(short)100);
//     
//     // Checks the contract:  equals-hashcode on var22 and var25
//     assertTrue("Contract failed: equals-hashcode on var22 and var25", var22.equals(var25) ? var22.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var22
//     assertTrue("Contract failed: equals-hashcode on var25 and var22", var25.equals(var22) ? var25.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)false, 5.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var0.getKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.setValue((java.lang.Comparable)0.2d, (java.lang.Number)(byte)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    java.text.NumberFormat var5 = var4.getExponentFormat();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.RoundingMode var6 = var4.getRoundingMode();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    double var36 = var7.getSectionDepth();
    org.jfree.chart.util.RectangleInsets var37 = var7.getInsets();
    double var39 = var37.calculateBottomInset(5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 4.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    boolean var13 = var0.isDomainZeroBaselineVisible();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var25 = null;
    var18.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var25);
    double var27 = var18.getCrosshairY();
    boolean var28 = var0.render(var14, var15, 10, var17, var18);
    int var29 = var0.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    boolean var9 = var0.isRangePannable();
    boolean var10 = var0.isOutlineVisible();
    boolean var11 = var0.isRangeGridlinesVisible();
    org.jfree.chart.annotations.XYAnnotation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var14 = var0.removeAnnotation(var12, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var11 = var9.getSeriesKey((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.axis.AxisSpace var4 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(1.0d, var6, var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    float var2 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var4 = var3.getBackgroundPaint();
    org.jfree.chart.event.ChartProgressListener var5 = null;
    var3.addProgressListener(var5);
    var3.setTextAntiAlias(true);
    var3.fireChartChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.Font var3 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("", var3, (org.jfree.chart.plot.Plot)var4, false);
    org.jfree.chart.axis.AxisSpace var7 = null;
    var4.setFixedRangeAxisSpace(var7);
    org.jfree.chart.axis.AxisLocation var9 = var4.getDomainAxisLocation();
    java.awt.Paint var10 = var4.getDomainGridlinePaint();
    var0.setRangeZeroBaselinePaint(var10);
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.RenderingSource var15 = null;
    var0.select(2.0d, (-1.0d), var14, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    var3.add(5.0d, (java.lang.Number)(byte)0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)0.0d, 100.0d);
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var9 = var8.getTickLabelPaint();
    java.lang.Class var10 = var8.getMajorTickTimePeriodClass();
    java.awt.Paint var11 = var8.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.notifyListeners(var16);
    var15.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var21 = var15.getBaseShape();
    var8.setLeftArrow(var21);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    org.jfree.data.general.DefaultPieDataset var24 = new org.jfree.data.general.DefaultPieDataset();
    int var25 = var24.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var29 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var30 = var29.getSize();
    org.jfree.chart.entity.PieSectionEntity var33 = new org.jfree.chart.entity.PieSectionEntity(var23, (org.jfree.data.general.PieDataset)var24, 100, (-1), (java.lang.Comparable)var29, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.remove((java.lang.Comparable)100);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(70, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var2 = var1.getRoundingMode();
    boolean var3 = var1.isGroupingUsed();
    org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, 0);
    java.math.RoundingMode var6 = var1.getRoundingMode();
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    var7.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    var7.drawBackgroundImage(var11, var12);
    var7.setDomainCrosshairLockedOnData(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var16 = var1.format((java.lang.Object)var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
//     java.lang.Object var5 = var4.getTextAntiAlias();
//     var4.setBackgroundImageAlignment(2147483647);
//     java.awt.RenderingHints var8 = var4.getRenderingHints();
//     var4.clearSubtitles();
//     org.jfree.chart.labels.XYToolTipGenerator var11 = null;
//     org.jfree.chart.urls.XYURLGenerator var12 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var11, var12);
//     org.jfree.chart.urls.XYURLGenerator var17 = var13.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var18 = null;
//     var13.setBaseURLGenerator(var18, false);
//     java.awt.Paint var24 = var13.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var25 = var13.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var27 = null;
//     var13.setSeriesOutlinePaint(0, var27, false);
//     boolean var30 = var13.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var33 = var32.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var34 = var32.getLegendItems();
//     java.awt.Stroke var35 = var32.getDomainCrosshairStroke();
//     var13.setSeriesOutlineStroke(1, var35);
//     java.awt.Stroke var38 = var13.getSeriesOutlineStroke(1);
//     boolean var39 = var4.equals((java.lang.Object)1);
//     
//     // Checks the contract:  equals-hashcode on var2 and var32
//     assertTrue("Contract failed: equals-hashcode on var2 and var32", var2.equals(var32) ? var2.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var2
//     assertTrue("Contract failed: equals-hashcode on var32 and var2", var32.equals(var2) ? var32.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    var3.removeAnnotations();
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    var15.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var25 = var15.getItemLabelGenerator(1, 1, true);
    org.jfree.chart.labels.ItemLabelPosition var29 = var15.getPositiveItemLabelPosition((-1), 0, false);
    var3.setBasePositiveItemLabelPosition(var29, false);
    java.awt.Font var33 = var3.getLegendTextFont(255);
    boolean var37 = var3.getItemCreateEntity((-435), 2147483647, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(var0, 2147483647, var2);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var0);
    java.lang.Object var2 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getYValue(70, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    var3.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var13 = var3.getItemLabelGenerator(1, 1, true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var3.getPositiveItemLabelPosition((-1), 0, false);
    org.jfree.chart.labels.XYToolTipGenerator var20 = null;
    org.jfree.chart.urls.XYURLGenerator var21 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var20, var21);
    org.jfree.chart.urls.XYURLGenerator var26 = var22.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var27 = null;
    var22.setBaseURLGenerator(var27, false);
    java.awt.Paint var33 = var22.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var34 = var22.getBaseNegativeItemLabelPosition();
    java.awt.Paint var36 = null;
    var22.setSeriesOutlinePaint(0, var36, false);
    boolean var39 = var22.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var41 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var42 = var41.getRangeAxis();
    org.jfree.chart.LegendItemCollection var43 = var41.getLegendItems();
    java.awt.Stroke var44 = var41.getDomainCrosshairStroke();
    var22.setSeriesOutlineStroke(1, var44);
    org.jfree.chart.labels.StandardXYToolTipGenerator var47 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    var22.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var47);
    java.lang.String var49 = var47.getFormatString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSeriesToolTipGenerator(2147483647, (org.jfree.chart.labels.XYToolTipGenerator)var47, false);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "{0}: ({1}, {2})"+ "'", var49.equals("{0}: ({1}, {2})"));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    var9.add((org.jfree.chart.block.Block)var10);
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
    org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
    org.jfree.data.xy.XYDataItem var21 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-435), (java.lang.Number)10.0f);
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer(var12, (org.jfree.data.general.Dataset)var15, (java.lang.Comparable)(-435));
    java.lang.Object var23 = var15.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    var0.clear();
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var3 = var2.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.RenderingSource var7 = null;
    var2.select(10.0d, 100.0d, var6, var7);
    var2.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var12 = new org.jfree.chart.block.BlockContainer();
    var11.add((org.jfree.chart.block.Block)var12);
    org.jfree.chart.block.Arrangement var14 = var11.getArrangement();
    org.jfree.chart.block.BorderArrangement var15 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, var14, (org.jfree.chart.block.Arrangement)var15);
    java.awt.Paint var17 = var16.getItemPaint();
    org.jfree.chart.block.BlockContainer var18 = var16.getItemContainer();
    boolean var19 = var18.isEmpty();
    java.awt.Graphics2D var20 = null;
    org.jfree.data.Range var22 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var22);
    org.jfree.chart.block.RectangleConstraint var24 = var23.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var25 = var24.toUnconstrainedWidth();
    double var26 = var24.getWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var27 = var0.arrange(var18, var20, var24);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1.0d));

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var2 = var1.getFont();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var1.calculateDimensions(var3);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    java.text.DateFormat var1 = null;
    java.text.NumberFormat var2 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var3 = var2.getRoundingMode();
    boolean var4 = var2.isGroupingUsed();
    org.jfree.chart.labels.StandardXYToolTipGenerator var5 = new org.jfree.chart.labels.StandardXYToolTipGenerator("100", var1, var2);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var8 = null;
    var6.setDrawingSupplier(var8);
    float var10 = var6.getForegroundAlpha();
    boolean var11 = var6.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var6.add((org.jfree.chart.plot.XYPlot)var12, 100);
    java.awt.Stroke var15 = var6.getDomainCrosshairStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var16 = var2.format((java.lang.Object)var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var0.setBaseLinesVisible(true);
    boolean var8 = var0.getItemShapeFilled(0, 1);
    java.awt.Shape var10 = var0.lookupSeriesShape((-1));
    var0.setSeriesShapesVisible(3, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    var0.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    var0.drawBackgroundImage(var4, var5);
    java.awt.Paint var7 = var0.getRangeZeroBaselinePaint();
    java.awt.Color var10 = java.awt.Color.getColor("hi!", 100);
    int var11 = var10.getBlue();
    var0.setRangeMinorGridlinePaint((java.awt.Paint)var10);
    org.jfree.chart.annotations.XYAnnotation var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var14 = var0.removeAnnotation(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    java.lang.Object var5 = var4.getTextAntiAlias();
    java.awt.Paint var6 = var4.getBackgroundPaint();
    java.awt.Stroke var7 = var4.getBorderStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
//     java.awt.Paint var2 = var0.getDomainGridlinePaint();
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var7 = null;
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var7, var8);
//     org.jfree.chart.urls.XYURLGenerator var13 = var9.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var14 = null;
//     var9.setBaseURLGenerator(var14, false);
//     java.awt.Paint var20 = var9.getItemFillPaint(10, 100, false);
//     var5.setLabelPaint(var20);
//     java.awt.Paint[] var22 = new java.awt.Paint[] { var20};
//     org.jfree.chart.plot.CombinedDomainXYPlot var23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var24 = var23.getDomainMinorGridlineStroke();
//     var23.setDomainCrosshairVisible(false);
//     org.jfree.chart.labels.XYToolTipGenerator var28 = null;
//     org.jfree.chart.urls.XYURLGenerator var29 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var28, var29);
//     org.jfree.chart.urls.XYURLGenerator var34 = var30.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var35 = null;
//     var30.setBaseURLGenerator(var35, false);
//     java.awt.Paint var41 = var30.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var42 = var30.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var44 = null;
//     var30.setSeriesOutlinePaint(0, var44, false);
//     boolean var47 = var30.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var49 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var50 = var49.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var51 = var49.getLegendItems();
//     java.awt.Stroke var52 = var49.getDomainCrosshairStroke();
//     var30.setSeriesOutlineStroke(1, var52);
//     java.awt.Stroke var55 = var30.getSeriesOutlineStroke(1);
//     var23.setOutlineStroke(var55);
//     java.awt.Stroke[] var57 = new java.awt.Stroke[] { var55};
//     java.awt.Stroke[] var58 = null;
//     org.jfree.chart.axis.PeriodAxis var60 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var61 = var60.getTickLabelPaint();
//     java.lang.Class var62 = var60.getMajorTickTimePeriodClass();
//     java.awt.Paint var63 = var60.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var65 = null;
//     org.jfree.chart.urls.XYURLGenerator var66 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var67 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var65, var66);
//     org.jfree.chart.event.RendererChangeEvent var68 = null;
//     var67.notifyListeners(var68);
//     var67.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var73 = var67.getBaseShape();
//     var60.setLeftArrow(var73);
//     java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.clone(var73);
//     org.jfree.data.general.DefaultPieDataset var76 = new org.jfree.data.general.DefaultPieDataset();
//     int var77 = var76.getItemCount();
//     org.jfree.chart.axis.NumberTickUnit var81 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var82 = var81.getSize();
//     org.jfree.chart.entity.PieSectionEntity var85 = new org.jfree.chart.entity.PieSectionEntity(var75, (org.jfree.data.general.PieDataset)var76, 100, (-1), (java.lang.Comparable)var81, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//     var85.setSectionKey((java.lang.Comparable)(byte)(-1));
//     java.awt.Shape var88 = var85.getArea();
//     java.awt.Shape[] var89 = new java.awt.Shape[] { var88};
//     org.jfree.chart.plot.DefaultDrawingSupplier var90 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var22, var57, var58, var89);
//     
//     // Checks the contract:  equals-hashcode on var0 and var49
//     assertTrue("Contract failed: equals-hashcode on var0 and var49", var0.equals(var49) ? var0.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var0
//     assertTrue("Contract failed: equals-hashcode on var49 and var0", var49.equals(var0) ? var49.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var30
//     assertTrue("Contract failed: equals-hashcode on var9 and var30", var9.equals(var30) ? var9.hashCode() == var30.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var30.", var9.equals(var30) == var30.equals(var9));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var67.", var9.equals(var67) == var67.equals(var9));
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    var2.setOutlineVisible(true);
    org.jfree.chart.LegendItemCollection var6 = var2.getFixedLegendItems();
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var9 = var8.getTickLabelPaint();
    var8.zoomRange(1.0d, 100.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
    var8.setAxisLineStroke(var14);
    var2.setOutlineStroke(var14);
    org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var19);
    double var21 = var20.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var23 = var22.getRangeAxis();
    org.jfree.chart.LegendItemCollection var24 = var22.getLegendItems();
    var20.setFixedLegendItems(var24);
    int var26 = var20.getRendererCount();
    org.jfree.chart.axis.AxisLocation var27 = var20.getRangeAxisLocation();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.data.xy.XYSeries var33 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var34 = var33.clone();
    var33.add(0.0d, 100.0d, true);
    java.util.List var39 = var33.getItems();
    var20.drawDomainTickBands(var28, var29, var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.mapDatasetToRangeAxes(2147483647, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.AxisState var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var6 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var5);
//     double var7 = var6.getGap();
//     org.jfree.chart.util.RectangleEdge var9 = var6.getDomainAxisEdge(0);
//     java.util.List var10 = var0.refreshTicks(var1, var2, var3, var9);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    boolean var13 = var2.getAutoPopulateSeriesPaint();
    org.jfree.chart.plot.CategoryPlot var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setPlot(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var2.setFixedRangeAxisSpace(var5);
//     org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
//     java.awt.Paint var8 = var2.getDomainGridlinePaint();
//     org.jfree.chart.event.PlotChangeEvent var9 = null;
//     var2.plotChanged(var9);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem(100.0d, 10.0d);
    boolean var3 = var2.isSelected();
    var2.setSelected(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getRangeAxis();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeZeroBaselineStroke(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)false, 5.0d);
    int var6 = var0.getIndex((java.lang.Comparable)"Combined Range XYPlot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    java.lang.StringBuffer var6 = null;
    java.text.FieldPosition var7 = null;
    java.lang.StringBuffer var8 = var4.format(10L, var6, var7);
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.XYURLGenerator var11 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
    org.jfree.chart.urls.XYURLGenerator var16 = var12.getURLGenerator(0, 1, true);
    var12.setBaseSeriesVisibleInLegend(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var19 = var4.format((java.lang.Object)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var25 = var18.getSeriesKey(2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var11 = var10.getTickLabelPaint();
//     var0.setOutlinePaint(var11);
//     boolean var13 = var0.isDomainCrosshairLockedOnData();
//     java.lang.Object var14 = var0.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     var0.handleClick(70, (-435), var17);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    double var36 = var7.getSectionDepth();
    org.jfree.chart.util.RectangleInsets var37 = var7.getInsets();
    var7.clearSectionOutlinePaints(false);
    double var40 = var7.getMaximumExplodePercent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.event.PlotChangeEvent var3 = null;
    var2.plotChanged(var3);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.util.List var10 = var9.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.mapDatasetToRangeAxes(1, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.plot.XYCrosshairState var0 = new org.jfree.chart.plot.XYCrosshairState();
    var0.updateCrosshairX(0.05d, 70);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     double var1 = var0.getItemLabelAnchorOffset();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = null;
//     org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var5.setCategoryLabelPositionOffset(2147483647);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var12 = var11.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var13 = null;
//     var11.setDrawingSupplier(var13);
//     float var15 = var11.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var19 = null;
//     org.jfree.chart.urls.XYURLGenerator var20 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var19, var20);
//     org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var26 = null;
//     var21.setBaseURLGenerator(var26, false);
//     java.awt.Paint var32 = var21.getItemFillPaint(10, 100, false);
//     var17.setLabelPaint(var32);
//     float var34 = var17.getAlpha();
//     org.jfree.chart.util.Layer var35 = null;
//     boolean var36 = var11.removeDomainMarker((org.jfree.chart.plot.Marker)var17, var35);
//     org.jfree.chart.util.RectangleEdge var37 = var11.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisState var38 = null;
//     var5.drawTickMarks(var8, 10.0d, var10, var37, var38);
//     var5.setTickLabelsVisible(false);
//     org.jfree.chart.plot.CategoryMarker var42 = null;
//     java.awt.geom.Rectangle2D var43 = null;
//     var0.drawDomainMarker(var2, var3, (org.jfree.chart.axis.CategoryAxis)var5, var42, var43);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var11 = var10.getRangeDescription();
    org.jfree.data.time.TimeSeries var12 = var3.addAndOrUpdate(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.delete(0, 70);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue((-435), var2, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 100);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var11 = var10.getTickLabelPaint();
    var0.setOutlinePaint(var11);
    boolean var13 = var0.isDomainZeroBaselineVisible();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var25 = null;
    var18.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var25);
    double var27 = var18.getCrosshairY();
    boolean var28 = var0.render(var14, var15, 10, var17, var18);
    java.lang.Object var29 = null;
    boolean var30 = var0.equals(var29);
    org.jfree.chart.plot.SeriesRenderingOrder var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesRenderingOrder(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    org.jfree.chart.plot.CrosshairState var34 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var41 = null;
    var34.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var41);
    boolean var43 = var30.equals((java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     var3.setBaseSeriesVisibleInLegend(false);
//     org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
//     var3.setBaseItemLabelGenerator(var10);
//     java.awt.Font var13 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var14, false);
//     var16.clearSubtitles();
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var20 = var19.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getLabelInsets();
//     var16.setPadding(var21);
//     org.jfree.chart.event.ChartChangeEventType var23 = null;
//     org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var16, var23);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var26 = var25.getDomainMinorGridlineStroke();
//     var25.setDomainCrosshairVisible(false);
//     java.awt.Graphics2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     var25.drawBackgroundImage(var29, var30);
//     java.awt.Paint var32 = var25.getRangeZeroBaselinePaint();
//     var16.setBackgroundPaint(var32);
//     
//     // Checks the contract:  equals-hashcode on var14 and var25
//     assertTrue("Contract failed: equals-hashcode on var14 and var25", var14.equals(var25) ? var14.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var14
//     assertTrue("Contract failed: equals-hashcode on var25 and var14", var25.equals(var14) ? var25.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     var2.setOutlineVisible(true);
//     var2.clearRangeMarkers();
//     org.jfree.chart.labels.XYToolTipGenerator var8 = null;
//     org.jfree.chart.urls.XYURLGenerator var9 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
//     org.jfree.chart.event.RendererChangeEvent var11 = null;
//     var10.notifyListeners(var11);
//     var2.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var10);
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var16 = var15.getTickLabelPaint();
//     java.lang.Class var17 = var15.getMajorTickTimePeriodClass();
//     java.awt.Paint var18 = var15.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var20 = null;
//     org.jfree.chart.urls.XYURLGenerator var21 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var20, var21);
//     org.jfree.chart.event.RendererChangeEvent var23 = null;
//     var22.notifyListeners(var23);
//     var22.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var28 = var22.getBaseShape();
//     var15.setLeftArrow(var28);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var28);
//     boolean var31 = var10.equals((java.lang.Object)var28);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var22.", var10.equals(var22) == var22.equals(var10));
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getNumberInstance(var0);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 0);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    var9.add((org.jfree.chart.block.Block)var10);
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
    java.awt.Paint var15 = var14.getItemPaint();
    org.jfree.chart.block.BlockContainer var16 = var14.getItemContainer();
    org.jfree.chart.util.RectangleAnchor var17 = var14.getLegendItemGraphicLocation();
    org.jfree.chart.block.BlockContainer var18 = var14.getItemContainer();
    org.jfree.chart.block.BlockContainer var19 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var20 = new org.jfree.chart.block.BlockContainer();
    var19.add((org.jfree.chart.block.Block)var20);
    org.jfree.chart.block.Arrangement var22 = var19.getArrangement();
    org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var24);
    double var26 = var25.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var28 = var27.getRangeAxis();
    org.jfree.chart.LegendItemCollection var29 = var27.getLegendItems();
    var25.setFixedLegendItems(var29);
    java.lang.Object var31 = var29.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.add((org.jfree.chart.block.Block)var19, (java.lang.Object)var29);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("100");
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContentAlignmentPoint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var11 = var10.getRangeDescription();
    org.jfree.data.time.TimeSeries var12 = var3.addAndOrUpdate(var10);
    java.lang.String var13 = var10.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    boolean var6 = var2.isDrawBarOutline();
    double var7 = var2.getBase();
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 100);
    int var12 = var11.getBlue();
    java.awt.Color var13 = var11.darker();
    int var14 = var13.getBlue();
    var2.setSeriesOutlinePaint(1, (java.awt.Paint)var13, false);
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.data.Range var19 = var2.findRangeBounds(var17, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
//     org.jfree.data.xy.XYDataItem var21 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-435), (java.lang.Number)10.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer(var12, (org.jfree.data.general.Dataset)var15, (java.lang.Comparable)(-435));
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var29 = null;
//     var27.setSeriesURLGenerator(10, var29);
//     org.jfree.data.xy.XYSeries var34 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.lang.Object var35 = var34.clone();
//     boolean var36 = var27.equals((java.lang.Object)var34);
//     org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var38 = var37.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var39 = null;
//     var37.setDrawingSupplier(var39);
//     float var41 = var37.getForegroundAlpha();
//     boolean var42 = var27.equals((java.lang.Object)var37);
//     java.lang.Object var43 = var22.draw(var23, var24, (java.lang.Object)var27);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = null;
//     var2.setSeriesURLGenerator(3, var7, true);
//     int var10 = var2.getPassCount();
//     org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var15 = null;
//     var13.setSeriesURLGenerator(10, var15);
//     boolean var17 = var13.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var19 = null;
//     var13.setSeriesItemLabelGenerator(0, var19, false);
//     org.jfree.chart.labels.XYToolTipGenerator var24 = null;
//     org.jfree.chart.urls.XYURLGenerator var25 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var24, var25);
//     org.jfree.chart.urls.XYURLGenerator var30 = var26.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var31 = null;
//     var26.setBaseURLGenerator(var31, false);
//     java.awt.Paint var37 = var26.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var38 = var26.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var39 = var38.getTextAnchor();
//     var13.setSeriesNegativeItemLabelPosition(100, var38, false);
//     org.jfree.data.category.CategoryDataset var42 = null;
//     org.jfree.data.Range var44 = var13.findRangeBounds(var42, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var49 = null;
//     var47.setSeriesURLGenerator(10, var49);
//     org.jfree.chart.urls.CategoryURLGenerator var52 = null;
//     var47.setSeriesURLGenerator(3, var52, true);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var55 = var47.getLegendItemLabelGenerator();
//     var13.setLegendItemURLGenerator(var55);
//     var2.setLegendItemURLGenerator(var55);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var13.", var2.equals(var13) == var13.equals(var2));
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 10.0d);
    double var3 = var2.getHeight();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedWidth();
    java.lang.String var5 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]"+ "'", var5.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]"));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d);
    org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
    double var7 = var5.extendWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0d));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    java.text.NumberFormat var1 = var0.getYFormat();
    java.text.DateFormat var2 = var0.getXDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var2 = var1.getFont();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var5 = var4.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var6 = null;
//     var4.setDrawingSupplier(var6);
//     float var8 = var4.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var12 = null;
//     org.jfree.chart.urls.XYURLGenerator var13 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var12, var13);
//     org.jfree.chart.urls.XYURLGenerator var18 = var14.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var19 = null;
//     var14.setBaseURLGenerator(var19, false);
//     java.awt.Paint var25 = var14.getItemFillPaint(10, 100, false);
//     var10.setLabelPaint(var25);
//     float var27 = var10.getAlpha();
//     org.jfree.chart.util.Layer var28 = null;
//     boolean var29 = var4.removeDomainMarker((org.jfree.chart.plot.Marker)var10, var28);
//     org.jfree.chart.text.TextAnchor var30 = var10.getLabelTextAnchor();
//     float var31 = var1.calculateBaselineOffset(var3, var30);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     var1.zoomRange(1.0d, 100.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
//     var1.setAxisLineStroke(var7);
//     boolean var9 = var1.isPositiveArrowVisible();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var13 = var12.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var14 = null;
//     var12.setDrawingSupplier(var14);
//     float var16 = var12.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var20 = null;
//     org.jfree.chart.urls.XYURLGenerator var21 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var20, var21);
//     org.jfree.chart.urls.XYURLGenerator var26 = var22.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var27 = null;
//     var22.setBaseURLGenerator(var27, false);
//     java.awt.Paint var33 = var22.getItemFillPaint(10, 100, false);
//     var18.setLabelPaint(var33);
//     float var35 = var18.getAlpha();
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var12.removeDomainMarker((org.jfree.chart.plot.Marker)var18, var36);
//     org.jfree.chart.util.RectangleEdge var38 = var12.getRangeAxisEdge();
//     double var39 = var1.lengthToJava2D(1.0E-5d, var11, var38);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    double var1 = var0.getItemLabelAnchorOffset();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var4 = var3.getDomainMinorGridlineStroke();
    var3.setDomainCrosshairVisible(false);
    java.awt.Paint var7 = var3.getRangeCrosshairPaint();
    var0.setBasePaint(var7, true);
    double var10 = var0.getShadowXOffset();
    org.jfree.chart.urls.CategoryURLGenerator var12 = var0.getSeriesURLGenerator((-435));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.chart.util.SortOrder var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByValues(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    boolean var8 = var3.getShapesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.setMaximumItemCount(2147483647);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(2147483647, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)false, 5.0d);
    java.lang.Comparable var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getValue(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var3.notifyListeners(var4);
//     java.awt.Paint var7 = null;
//     var3.setSeriesPaint(100, var7, true);
//     org.jfree.chart.labels.ItemLabelPosition var10 = var3.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var11 = var10.getItemLabelAnchor();
//     org.jfree.chart.labels.XYToolTipGenerator var13 = null;
//     org.jfree.chart.urls.XYURLGenerator var14 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
//     org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var20 = null;
//     var15.setBaseURLGenerator(var20, false);
//     java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var28 = var27.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var29 = new org.jfree.chart.labels.ItemLabelPosition(var11, var28);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var27
//     assertTrue("Contract failed: equals-hashcode on var10 and var27", var10.equals(var27) ? var10.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var29
//     assertTrue("Contract failed: equals-hashcode on var10 and var29", var10.equals(var29) ? var10.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var10
//     assertTrue("Contract failed: equals-hashcode on var27 and var10", var27.equals(var10) ? var27.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var29
//     assertTrue("Contract failed: equals-hashcode on var27 and var29", var27.equals(var29) ? var27.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var10
//     assertTrue("Contract failed: equals-hashcode on var29 and var10", var29.equals(var10) ? var29.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var27
//     assertTrue("Contract failed: equals-hashcode on var29 and var27", var29.equals(var27) ? var29.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    var3.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var6 = var3.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     var2.setOutlineVisible(true);
//     java.awt.Stroke var6 = var2.getRangeCrosshairStroke();
//     org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var10 = var9.getFont();
//     org.jfree.chart.text.TextLine var11 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var10);
//     var2.setNoDataMessageFont(var10);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     org.jfree.chart.plot.PlotState var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     var2.draw(var13, var14, var15, var16, var17);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var3 = var2.getSize();
    int var4 = var0.indexOf((java.lang.Comparable)var3);
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var9 = var8.clone();
    var8.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var8);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.removeSeries(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "January"+ "'", var2.equals("January"));

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    java.text.NumberFormat var25 = java.text.NumberFormat.getInstance();
    java.math.RoundingMode var26 = var25.getRoundingMode();
    boolean var27 = var25.isGroupingUsed();
    org.jfree.chart.axis.NumberTickUnit var29 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var25, 0);
    java.math.RoundingMode var30 = var25.getRoundingMode();
    double[][] var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.addSeries((java.lang.Comparable)var30, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     java.awt.Paint var15 = var14.getItemPaint();
//     org.jfree.chart.block.BlockContainer var16 = var14.getItemContainer();
//     org.jfree.chart.util.RectangleAnchor var17 = var14.getLegendItemGraphicLocation();
//     org.jfree.chart.block.BlockContainer var18 = var14.getItemContainer();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.data.Range var21 = null;
//     org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var21);
//     org.jfree.chart.block.RectangleConstraint var23 = var22.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var24 = var14.arrange(var19, var22);
//     
//     // Checks the contract:  equals-hashcode on var10 and var16
//     assertTrue("Contract failed: equals-hashcode on var10 and var16", var10.equals(var16) ? var10.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var18
//     assertTrue("Contract failed: equals-hashcode on var10 and var18", var10.equals(var18) ? var10.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var10
//     assertTrue("Contract failed: equals-hashcode on var16 and var10", var16.equals(var10) ? var16.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var10
//     assertTrue("Contract failed: equals-hashcode on var18 and var10", var18.equals(var10) ? var18.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
//     java.awt.Paint var4 = var1.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var6 = null;
//     org.jfree.chart.urls.XYURLGenerator var7 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var8.notifyListeners(var9);
//     var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var14 = var8.getBaseShape();
//     var1.setLeftArrow(var14);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     org.jfree.chart.entity.ChartEntity var17 = new org.jfree.chart.entity.ChartEntity(var14);
//     org.jfree.chart.labels.XYToolTipGenerator var19 = null;
//     org.jfree.chart.urls.XYURLGenerator var20 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var19, var20);
//     org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var26 = null;
//     var21.setBaseURLGenerator(var26, false);
//     var21.removeAnnotations();
//     org.jfree.chart.labels.XYToolTipGenerator var31 = null;
//     org.jfree.chart.urls.XYURLGenerator var32 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var31, var32);
//     org.jfree.chart.urls.XYURLGenerator var37 = var33.getURLGenerator(0, 1, true);
//     var33.setBaseSeriesVisibleInLegend(false);
//     org.jfree.chart.labels.XYItemLabelGenerator var43 = var33.getItemLabelGenerator(1, 1, true);
//     org.jfree.chart.labels.ItemLabelPosition var47 = var33.getPositiveItemLabelPosition((-1), 0, false);
//     var21.setBasePositiveItemLabelPosition(var47, false);
//     boolean var50 = var17.equals((java.lang.Object)false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var8.", var21.equals(var8) == var8.equals(var21));
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    var9.add((org.jfree.chart.block.Block)var10);
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
    java.awt.Paint var15 = var14.getItemPaint();
    org.jfree.chart.util.RectangleAnchor var16 = var14.getLegendItemGraphicAnchor();
    java.awt.Paint var17 = var14.getItemPaint();
    java.awt.Font var19 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("", var19, (org.jfree.chart.plot.Plot)var20, false);
    var22.clearSubtitles();
    java.awt.Paint var24 = var22.getBorderPaint();
    boolean var25 = var22.getAntiAlias();
    var14.addChangeListener((org.jfree.chart.event.TitleChangeListener)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(70, 3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
    int var18 = var17.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var23 = var22.getSize();
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity(var16, (org.jfree.data.general.PieDataset)var17, 100, (-1), (java.lang.Comparable)var22, "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.insertValue((-1), (java.lang.Comparable)false, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    java.awt.Font var4 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("", var4, (org.jfree.chart.plot.Plot)var5, false);
    java.lang.Object var8 = var7.getTextAntiAlias();
    var7.setBackgroundImageAlignment(2147483647);
    java.awt.RenderingHints var11 = var7.getRenderingHints();
    var1.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var7);
    java.awt.Font var16 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var16, (org.jfree.chart.plot.Plot)var17, false);
    java.lang.Object var20 = var19.getTextAntiAlias();
    var19.setBackgroundImageAlignment(2147483647);
    org.jfree.chart.ChartRenderingInfo var25 = new org.jfree.chart.ChartRenderingInfo();
    var25.clear();
    var19.handleClick(3, 10, var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var28 = var7.createBufferedImage(2, 2147483647, var25);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    java.lang.Object var3 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.axis.AxisSpace var4 = var0.getFixedDomainAxisSpace();
    java.awt.Font var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var7, false);
    var9.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var13 = var12.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var9.setPadding(var14);
    double var17 = var14.calculateLeftInset(100.0d);
    var0.setInsets(var14);
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    java.awt.geom.Point2D var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(0.08d, 0.2d, var21, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 3);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"hi!");
    java.lang.Object var2 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getValue(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    java.lang.Number var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.update((java.lang.Number)100.0d, var11);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var10 = var3.getDataItem(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.lang.Class var3 = var1.getMajorTickTimePeriodClass();
    java.awt.Paint var4 = var1.getTickMarkPaint();
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.notifyListeners(var9);
    var8.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    java.awt.Shape var14 = var8.getBaseShape();
    var1.setLeftArrow(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    org.jfree.chart.entity.ChartEntity var17 = new org.jfree.chart.entity.ChartEntity(var14);
    org.jfree.chart.title.Title var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var20 = new org.jfree.chart.entity.TitleEntity(var14, var18, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance(var0);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", var1);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var3 = var2.getSize();
    int var4 = var0.indexOf((java.lang.Comparable)var3);
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var9 = var8.clone();
    var8.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var8);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.removeSeries(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    var1.setText("hi!");
    java.awt.Paint var4 = var1.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    org.jfree.chart.util.HorizontalAlignment var3 = var1.getHorizontalAlignment();
    java.awt.Graphics2D var4 = null;
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var1.arrange(var4, var7);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2147483647, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     var0.setBaseLinesVisible(true);
//     java.awt.Stroke var7 = var0.lookupSeriesStroke(0);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = null;
//     org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var12 = var11.getTickLabelPaint();
//     var11.zoomRange(1.0d, 100.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var17 = var16.getDomainMinorGridlineStroke();
//     var11.setAxisLineStroke(var17);
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.axis.PeriodAxis var22 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var23 = var22.getTickLabelPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var26 = var25.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.RenderingSource var30 = null;
//     var25.select(10.0d, 100.0d, var29, var30);
//     var25.setOutlineVisible(false);
//     org.jfree.chart.labels.XYToolTipGenerator var35 = null;
//     org.jfree.chart.urls.XYURLGenerator var36 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var35, var36);
//     org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(0, 1, true);
//     var37.setBaseSeriesVisibleInLegend(false);
//     int var44 = var25.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var37);
//     org.jfree.chart.plot.CombinedDomainXYPlot var46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var47 = var46.getRangeAxis();
//     java.awt.Paint var48 = var46.getDomainGridlinePaint();
//     var37.setSeriesFillPaint(0, var48);
//     org.jfree.chart.axis.PeriodAxis var51 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var52 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var51);
//     double var53 = var52.getGap();
//     var52.setOutlineVisible(true);
//     java.awt.Stroke var56 = var52.getRangeCrosshairStroke();
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(10.0d, var48, var56);
//     var0.drawRangeLine(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, var19, (-1.0d), var23, var56);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    java.lang.Object var5 = var4.getTextAntiAlias();
    java.awt.Paint var6 = var4.getBackgroundPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.RenderingSource var12 = null;
    var7.select(10.0d, 100.0d, var11, var12);
    var7.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var17 = new org.jfree.chart.block.BlockContainer();
    var16.add((org.jfree.chart.block.Block)var17);
    org.jfree.chart.block.Arrangement var19 = var16.getArrangement();
    org.jfree.chart.block.BorderArrangement var20 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, var19, (org.jfree.chart.block.Arrangement)var20);
    java.awt.Paint var22 = var21.getItemPaint();
    var4.addLegend(var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var26 = var4.createBufferedImage(3, 2147483647);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var8 = null;
    var6.setDrawingSupplier(var8);
    var3.setPlot((org.jfree.chart.plot.XYPlot)var6);
    org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var14 = var13.getTickLabelPaint();
    var13.setUpperMargin(0.0d);
    java.awt.Paint var17 = var13.getLabelPaint();
    java.awt.Stroke var18 = var13.getAxisLineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSeriesOutlineStroke(2147483647, var18, false);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    java.lang.String var4 = var3.getNullYString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "null"+ "'", var4.equals("null"));

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)0.0d, 100.0d);
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset)var0);
    org.jfree.chart.util.SortOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByKeys(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    double var36 = var7.getSectionDepth();
    org.jfree.chart.util.RectangleInsets var37 = var7.getInsets();
    float var38 = var7.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0f);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var2 = var0.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.add((org.jfree.chart.plot.XYPlot)var6, 100);
    double var9 = var6.getDomainCrosshairValue();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var11 = var6.getQuadrantPaint((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getDomainMarkers((-435), var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.setValue((java.lang.Comparable)0.2d, (java.lang.Number)(byte)0);
    org.jfree.chart.util.SortOrder var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByValues(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var5 = null;
//     org.jfree.chart.urls.XYURLGenerator var6 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var5, var6);
//     org.jfree.chart.urls.XYURLGenerator var11 = var7.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var12 = null;
//     var7.setBaseURLGenerator(var12, false);
//     java.awt.Paint var18 = var7.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var19 = var7.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var20 = var19.getTextAnchor();
//     org.jfree.chart.axis.PeriodAxis var22 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var23 = var22.getTickLabelPaint();
//     var22.setUpperMargin(0.0d);
//     boolean var26 = var20.equals((java.lang.Object)var22);
//     org.jfree.chart.labels.XYToolTipGenerator var29 = null;
//     org.jfree.chart.urls.XYURLGenerator var30 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var29, var30);
//     org.jfree.chart.urls.XYURLGenerator var35 = var31.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var36 = null;
//     var31.setBaseURLGenerator(var36, false);
//     java.awt.Paint var42 = var31.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var43 = var31.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var44 = var43.getTextAnchor();
//     java.lang.String var45 = var44.toString();
//     java.lang.String var46 = var44.toString();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.8f, 0.0f, var20, 0.025d, var44);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     var0.setDomainCrosshairVisible(false);
//     java.awt.Paint var4 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var6 = var5.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var7 = var5.getLegendItems();
//     java.awt.Stroke var8 = var5.getDomainCrosshairStroke();
//     var0.setRangeMinorGridlineStroke(var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var7.getEndY(10, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.awt.Font var5 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
//     org.jfree.chart.axis.AxisSpace var9 = null;
//     var6.setFixedRangeAxisSpace(var9);
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var12 = var11.getOpposite();
//     boolean var13 = var3.equals((java.lang.Object)var11);
//     double var14 = var3.getMinX();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer();
    var1.add((org.jfree.chart.block.Block)var2);
    boolean var4 = var1.isEmpty();
    java.awt.Graphics2D var5 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var7);
    org.jfree.chart.block.RectangleConstraint var9 = var8.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var10 = var9.toUnconstrainedWidth();
    double var11 = var9.getHeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var12 = var0.arrange(var1, var5, var9);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 100);
    int var8 = var7.getBlue();
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var11 = var10.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.RenderingSource var15 = null;
    var10.select(10.0d, 100.0d, var14, var15);
    var10.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var20 = null;
    org.jfree.chart.urls.XYURLGenerator var21 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var20, var21);
    org.jfree.chart.urls.XYURLGenerator var26 = var22.getURLGenerator(0, 1, true);
    var22.setBaseSeriesVisibleInLegend(false);
    int var29 = var10.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var22);
    org.jfree.chart.plot.CombinedDomainXYPlot var31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var32 = var31.getRangeAxis();
    java.awt.Paint var33 = var31.getDomainGridlinePaint();
    var22.setSeriesFillPaint(0, var33);
    org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var36);
    double var38 = var37.getGap();
    var37.setOutlineVisible(true);
    java.awt.Stroke var41 = var37.getRangeCrosshairStroke();
    org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker(10.0d, var33, var41);
    org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var45 = var44.getTickLabelPaint();
    var44.zoomRange(1.0d, 100.0d);
    double var49 = var44.getLowerMargin();
    org.jfree.chart.plot.CombinedRangeXYPlot var50 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var44);
    org.jfree.chart.plot.CombinedDomainXYPlot var51 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var52 = var51.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.RenderingSource var56 = null;
    var51.select(10.0d, 100.0d, var55, var56);
    var51.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var61 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var62 = var61.getTickLabelPaint();
    var51.setOutlinePaint(var62);
    var44.setMinorTickMarkPaint(var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem(var0, "Combined Range XYPlot", "hi!", "January", var4, (java.awt.Paint)var7, var41, var62);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var11.setCategoryLabelPositionOffset(2147483647);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var18 = var17.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var19 = null;
//     var17.setDrawingSupplier(var19);
//     float var21 = var17.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var25 = null;
//     org.jfree.chart.urls.XYURLGenerator var26 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var25, var26);
//     org.jfree.chart.urls.XYURLGenerator var31 = var27.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var32 = null;
//     var27.setBaseURLGenerator(var32, false);
//     java.awt.Paint var38 = var27.getItemFillPaint(10, 100, false);
//     var23.setLabelPaint(var38);
//     float var40 = var23.getAlpha();
//     org.jfree.chart.util.Layer var41 = null;
//     boolean var42 = var17.removeDomainMarker((org.jfree.chart.plot.Marker)var23, var41);
//     org.jfree.chart.util.RectangleEdge var43 = var17.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisState var44 = null;
//     var11.drawTickMarks(var14, 10.0d, var16, var43, var44);
//     org.jfree.chart.axis.AxisState var46 = null;
//     var6.drawTickMarks(var7, 1.0d, var9, var43, var46);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     org.jfree.chart.axis.AxisState var49 = var1.draw(var2, 0.05d, var4, var5, var43, var48);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("100");
//     java.lang.String var2 = var1.getToolTipText();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.Range var5 = null;
//     org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var5);
//     org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var8 = var7.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var9 = var1.arrange(var3, var7);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
    boolean var2 = var1.getNotify();
    var1.setPadding(1.0d, 2.0d, 1.0E-5d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    var7.setDomainCrosshairVisible(false);
    java.awt.Graphics2D var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    var7.drawBackgroundImage(var11, var12);
    double var14 = var7.getDomainCrosshairValue();
    org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var17 = var16.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var18 = var16.getLabelInsets();
    var16.setAxisLineVisible(false);
    var16.setMinorTickMarkInsideLength((-1.0f));
    org.jfree.chart.plot.CombinedDomainXYPlot var23 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var16);
    java.awt.Shape var24 = var16.getDownArrow();
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var27 = var26.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
    boolean var29 = var26.isAxisLineVisible();
    var26.setPositiveArrowVisible(false);
    var26.setAutoTickUnitSelection(false, false);
    org.jfree.data.xy.DefaultXYDataset var35 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.drawItem(var4, var5, var6, (org.jfree.chart.plot.XYPlot)var7, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.data.xy.XYDataset)var35, 68, 2, false, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var4 = var3.clone();
    var3.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var9.getX(10, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.XYURLGenerator var11 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
    org.jfree.chart.urls.XYURLGenerator var16 = var12.getURLGenerator(0, 1, true);
    var12.setBaseSeriesVisibleInLegend(false);
    int var19 = var0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
    org.jfree.chart.labels.XYToolTipGenerator var21 = null;
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
    org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var28 = null;
    var23.setBaseURLGenerator(var28, false);
    java.awt.Paint var34 = var23.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var35 = var23.getBaseNegativeItemLabelPosition();
    var12.setBasePositiveItemLabelPosition(var35, true);
    org.jfree.chart.labels.ItemLabelPosition var41 = var12.getPositiveItemLabelPosition(100, 100, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var3 = var2.getSize();
    int var4 = var0.indexOf((java.lang.Comparable)var3);
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var9 = var8.clone();
    var8.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var8);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var14.getStartXValue((-1), 68);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    var1.setAxisLineVisible(false);
    var1.setMinorTickMarkInsideLength((-1.0f));
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.ValueAxis var9 = null;
    var8.setDomainAxis(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    var9.add((org.jfree.chart.block.Block)var10);
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
    java.awt.Paint var15 = var14.getItemPaint();
    org.jfree.chart.util.RectangleAnchor var16 = var14.getLegendItemGraphicAnchor();
    java.awt.Paint var17 = var14.getItemPaint();
    boolean var18 = var14.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     int var4 = var3.getMaximumItemCount();
//     java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
//     boolean var6 = var3.equals((java.lang.Object)var5);
//     double var7 = var3.getMinY();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    double var36 = var7.getSectionDepth();
    org.jfree.chart.util.RectangleInsets var37 = var7.getInsets();
    double var39 = var37.calculateBottomInset(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 4.0d);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(2.0d, 1.0E-5d, 1.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = null;
//     java.awt.geom.RectangularShape var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     var3.paintBar(var4, var5, 255, 2147483647, false, var9, var10);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var2 = var1.getTitlePaint();
    java.awt.Paint var3 = var1.getLegendBackgroundPaint();
    org.jfree.chart.plot.PieLabelLinkStyle var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelLinkStyle(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var0.setBaseLinesVisible(true);
    boolean var8 = var0.getItemShapeFilled(0, 1);
    java.awt.Shape var10 = var0.lookupSeriesShape((-1));
    var0.setBaseShapesVisible(true);
    boolean var15 = var0.getItemShapeVisible(70, 2147483647);
    boolean var16 = var0.getBaseLinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.DomainOrder var24 = var18.getDomainOrder();
    java.util.List var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset)var18, var25, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    boolean var13 = var2.getAutoPopulateSeriesPaint();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 100);
    int var18 = var17.getBlue();
    var2.setSeriesOutlinePaint(0, (java.awt.Paint)var17, true);
    double var21 = var2.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 4.0d);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var3.setSeriesItemLabelGenerator(70, var16);
//     org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var21 = var20.getSize();
//     int var22 = var18.indexOf((java.lang.Comparable)var21);
//     org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var27 = var26.getTickLabelPaint();
//     java.lang.Class var28 = var26.getMajorTickTimePeriodClass();
//     java.awt.Paint var29 = var26.getTickMarkPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
//     var26.setMinorTickMarkStroke(var33);
//     var26.setRangeAboutValue(0.05d, 1.0E-5d);
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, (org.jfree.chart.axis.ValueAxis)var26, var38);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     java.awt.geom.Point2D var43 = null;
//     var39.zoomRangeAxes(3.0d, 0.025d, var42, var43);
//     java.lang.String var45 = var39.getPlotType();
//     org.jfree.chart.LegendItemCollection var46 = var39.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var32 and var46
//     assertTrue("Contract failed: equals-hashcode on var32 and var46", var32.equals(var46) ? var32.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var32
//     assertTrue("Contract failed: equals-hashcode on var46 and var32", var46.equals(var32) ? var46.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var3 = var2.getFont();
//     org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.util.Size2D var6 = var4.calculateDimensions(var5);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    java.text.NumberFormat var1 = var0.getYFormat();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var1.parseObject("AxisLocation.TOP_OR_RIGHT");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var0);
    org.jfree.data.xy.XYDatasetSelectionState var2 = var0.getSelectionState();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var0, (-435), 0.2d, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
    java.lang.String var2 = var1.getText();
    java.awt.Font var3 = var1.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var17 = null;
//     var3.setSeriesOutlinePaint(0, var17, false);
//     java.awt.Paint var21 = var3.getLegendTextPaint((-1));
//     org.jfree.chart.labels.XYItemLabelGenerator var22 = null;
//     var3.setBaseItemLabelGenerator(var22);
//     org.jfree.data.general.DefaultPieDataset var24 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var27 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var24, (java.lang.Comparable)"hi!", 10.0d);
//     var24.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var24);
//     java.awt.Paint var32 = null;
//     var31.setLabelBackgroundPaint(var32);
//     var31.setInnerSeparatorExtension(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var37 = null;
//     org.jfree.chart.urls.XYURLGenerator var38 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var37, var38);
//     org.jfree.chart.urls.XYURLGenerator var43 = var39.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var44 = null;
//     var39.setBaseURLGenerator(var44, false);
//     java.awt.Paint var50 = var39.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var51 = var39.getBaseNegativeItemLabelPosition();
//     java.awt.Color var54 = java.awt.Color.getColor("hi!", 100);
//     int var55 = var54.getBlue();
//     var39.setBaseLegendTextPaint((java.awt.Paint)var54);
//     var31.setLabelOutlinePaint((java.awt.Paint)var54);
//     var31.setAutoPopulateSectionOutlinePaint(true);
//     java.awt.Paint var60 = var31.getShadowPaint();
//     var3.setBaseFillPaint(var60, false);
//     
//     // Checks the contract:  equals-hashcode on var15 and var51
//     assertTrue("Contract failed: equals-hashcode on var15 and var51", var15.equals(var51) ? var15.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var15
//     assertTrue("Contract failed: equals-hashcode on var51 and var15", var51.equals(var15) ? var51.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    org.jfree.chart.labels.XYToolTipGenerator var8 = null;
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
    org.jfree.chart.urls.XYURLGenerator var14 = var10.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var15 = null;
    var10.setBaseURLGenerator(var15, false);
    boolean var18 = var10.getPlotArea();
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var21);
    double var23 = var22.getGap();
    var22.setOutlineVisible(true);
    java.awt.Stroke var26 = var22.getRangeCrosshairStroke();
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var30 = var29.getFont();
    org.jfree.chart.text.TextLine var31 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var30);
    var22.setNoDataMessageFont(var30);
    var10.setSeriesItemLabelFont(10, var30);
    org.jfree.chart.text.TextFragment var34 = new org.jfree.chart.text.TextFragment("ERROR : Relative To String", var30);
    org.jfree.chart.plot.CombinedDomainXYPlot var35 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var36 = var35.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var37 = null;
    var35.setDrawingSupplier(var37);
    org.jfree.chart.axis.AxisSpace var39 = var35.getFixedDomainAxisSpace();
    java.awt.Font var41 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("", var41, (org.jfree.chart.plot.Plot)var42, false);
    var44.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var47 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var48 = var47.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var49 = var47.getLabelInsets();
    var44.setPadding(var49);
    double var52 = var49.calculateLeftInset(100.0d);
    var35.setInsets(var49);
    org.jfree.chart.plot.CombinedDomainXYPlot var54 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var55 = var54.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var58 = null;
    org.jfree.chart.RenderingSource var59 = null;
    var54.select(10.0d, 100.0d, var58, var59);
    var54.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var63 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var64 = new org.jfree.chart.block.BlockContainer();
    var63.add((org.jfree.chart.block.Block)var64);
    org.jfree.chart.block.Arrangement var66 = var63.getArrangement();
    org.jfree.chart.block.BorderArrangement var67 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54, var66, (org.jfree.chart.block.Arrangement)var67);
    java.awt.Paint var69 = var68.getItemPaint();
    var35.setDomainTickBandPaint(var69);
    org.jfree.chart.block.LabelBlock var71 = new org.jfree.chart.block.LabelBlock("hi!", var30, var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var72 = var4.format((java.lang.Object)var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
    var0.clearRangeMarkers(0);
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var6 = var5.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var7 = null;
    var5.setDrawingSupplier(var7);
    float var9 = var5.getForegroundAlpha();
    boolean var10 = var5.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var5.add((org.jfree.chart.plot.XYPlot)var11, 100);
    java.awt.Stroke var14 = var5.getDomainCrosshairStroke();
    org.jfree.chart.event.PlotChangeEvent var15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var17);
    double var19 = var18.getGap();
    org.jfree.chart.util.RectangleEdge var21 = var18.getDomainAxisEdge(0);
    java.lang.String var22 = var18.getPlotType();
    org.jfree.chart.axis.AxisLocation var24 = var18.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(var24, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-435), var24, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Combined Range XYPlot"+ "'", var22.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    var1.setCategoryLabelPositionOffset(2147483647);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var7.setDrawingSupplier(var9);
    float var11 = var7.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var15 = null;
    org.jfree.chart.urls.XYURLGenerator var16 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
    org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    var17.setBaseURLGenerator(var22, false);
    java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
    var13.setLabelPaint(var28);
    float var30 = var13.getAlpha();
    org.jfree.chart.util.Layer var31 = null;
    boolean var32 = var7.removeDomainMarker((org.jfree.chart.plot.Marker)var13, var31);
    org.jfree.chart.util.RectangleEdge var33 = var7.getRangeAxisEdge();
    org.jfree.chart.axis.AxisState var34 = null;
    var1.drawTickMarks(var4, 10.0d, var6, var33, var34);
    var1.setUpperMargin(0.05d);
    int var38 = var1.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2147483647);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     double var1 = var0.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("100");
//     org.jfree.chart.block.BlockFrame var9 = var8.getFrame();
//     org.jfree.chart.util.RectangleInsets var10 = var8.getPadding();
//     var6.setLabelInsets(var10);
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var14 = var13.getCategoryLabelPositions();
//     var6.setCategoryLabelPositions(var14);
//     var6.setLabel("WMAP_Plot");
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var20 = var19.getTickLabelPaint();
//     java.lang.Class var21 = var19.getMajorTickTimePeriodClass();
//     java.awt.Paint var22 = var19.getTickMarkPaint();
//     org.jfree.chart.util.Layer var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     var0.drawAnnotations(var3, var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var19, var23, var24);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
//     java.awt.GradientPaint var2 = null;
//     java.awt.Shape var3 = null;
//     java.awt.GradientPaint var4 = var0.transform(var2, var3);
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.getTimeFromLong(1L);
//     var0.setAdjustForDaylightSaving(true);
//     long var5 = var0.getSegmentsIncludedSize();
//     long var7 = var0.toTimelineValue(0L);
//     int var8 = var0.getGroupSegmentCount();
//     java.util.Date var9 = null;
//     var0.addException(var9);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    var0.setBaseLinesVisible(true);
    boolean var8 = var0.getItemShapeFilled(0, 1);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var10 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var10);
    boolean var15 = var0.isItemLabelVisible(2, 2147483647, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("WMAP_Plot", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var2 = var1.getTickLabelPaint();
//     var1.setUpperMargin(0.0d);
//     var1.setRange(10.0d, 10.0d);
//     double var8 = var1.getLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-5.76E7d));
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("{0}: ({1}, {2})", "AxisLocation.TOP_OR_RIGHT");

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     java.awt.geom.Rectangle2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = var0.expand(var1, var2);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.getTimeFromLong(1L);
//     var0.setAdjustForDaylightSaving(true);
//     long var6 = var0.toMillisecond(0L);
//     java.util.Date var7 = null;
//     boolean var8 = var0.containsDomainValue(var7);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"PieSection: 100, -1(-1)");

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    float var2 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    java.lang.Object var4 = var3.getTextAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
//     java.awt.Font var19 = var3.getItemLabelFont((-1), (-1), false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var20 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     org.jfree.chart.labels.XYToolTipGenerator var23 = null;
//     org.jfree.chart.urls.XYURLGenerator var24 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var23, var24);
//     org.jfree.chart.urls.XYURLGenerator var29 = var25.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var30 = null;
//     var25.setBaseURLGenerator(var30, false);
//     java.awt.Paint var36 = var25.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var25.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var39 = null;
//     var25.setSeriesOutlinePaint(0, var39, false);
//     boolean var42 = var25.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var44 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var45 = var44.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var46 = var44.getLegendItems();
//     java.awt.Stroke var47 = var44.getDomainCrosshairStroke();
//     var25.setSeriesOutlineStroke(1, var47);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var50 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
//     var25.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var50);
//     var20.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var50, true);
//     org.jfree.chart.block.BlockBorder var59 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d);
//     java.awt.Paint var60 = var59.getPaint();
//     var20.setSeriesPaint(100, var60);
//     var3.setBaseOutlinePaint(var60, true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var37
//     assertTrue("Contract failed: equals-hashcode on var15 and var37", var15.equals(var37) ? var15.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var15
//     assertTrue("Contract failed: equals-hashcode on var37 and var15", var37.equals(var15) ? var37.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
//     org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxisForDataset(2147483647);
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var4.setFixedDomainAxisSpace(var5, true);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.util.List var10 = null;
//     var4.drawRangeTickBands(var8, var9, var10);
//     org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var15 = null;
//     var13.setDrawingSupplier(var15);
//     float var17 = var13.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var21 = null;
//     org.jfree.chart.urls.XYURLGenerator var22 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
//     org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var28 = null;
//     var23.setBaseURLGenerator(var28, false);
//     java.awt.Paint var34 = var23.getItemFillPaint(10, 100, false);
//     var19.setLabelPaint(var34);
//     float var36 = var19.getAlpha();
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var13.removeDomainMarker((org.jfree.chart.plot.Marker)var19, var37);
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker)var19, var39);
//     boolean var41 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var19);
//     org.jfree.chart.util.Layer var43 = null;
//     java.util.Collection var44 = var0.getDomainMarkers(68, var43);
//     java.awt.Graphics2D var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     var0.drawOutline(var45, var46);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
    org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxisForDataset(2147483647);
    org.jfree.chart.plot.CategoryMarker var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.add((org.jfree.chart.plot.XYPlot)var6, 100);
    var6.setDomainMinorGridlinesVisible(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var12 = var11.getRangeAxis();
    java.awt.Paint var13 = var11.getDomainGridlinePaint();
    var6.setParent((org.jfree.chart.plot.Plot)var11);
    org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
    var15.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var15);
    java.awt.Paint var23 = null;
    var22.setLabelBackgroundPaint(var23);
    var22.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var29 = var28.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.RenderingSource var33 = null;
    var28.select(10.0d, 100.0d, var32, var33);
    var28.setOutlineVisible(false);
    org.jfree.chart.labels.XYToolTipGenerator var38 = null;
    org.jfree.chart.urls.XYURLGenerator var39 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var38, var39);
    org.jfree.chart.urls.XYURLGenerator var44 = var40.getURLGenerator(0, 1, true);
    var40.setBaseSeriesVisibleInLegend(false);
    int var47 = var28.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var40);
    org.jfree.chart.plot.CombinedDomainXYPlot var49 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var50 = var49.getRangeAxis();
    java.awt.Paint var51 = var49.getDomainGridlinePaint();
    var40.setSeriesFillPaint(0, var51);
    org.jfree.chart.axis.PeriodAxis var54 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var55 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var54);
    double var56 = var55.getGap();
    var55.setOutlineVisible(true);
    java.awt.Stroke var59 = var55.getRangeCrosshairStroke();
    org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(10.0d, var51, var59);
    var22.setSeparatorPaint(var51);
    double var62 = var22.getMinimumArcAngleToDraw();
    double var63 = var22.getMaximumExplodePercent();
    java.awt.Stroke var64 = var22.getOutlineStroke();
    var11.setRangeGridlineStroke(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var7.isSelected(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(68, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    java.util.List var6 = null;
    var0.drawRangeTickBands(var4, var5, var6);
    org.jfree.data.xy.XYDataset var9 = var0.getDataset(3);
    java.awt.Paint var10 = var0.getDomainZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
    var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
    java.awt.Paint var10 = null;
    var9.setLabelBackgroundPaint(var10);
    var9.setInnerSeparatorExtension(0.0d);
    boolean var14 = var9.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var15 = var9.getDataset();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var9, true);
    org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var25 = null;
    var18.updateCrosshairPoint((-1.0d), 1.0d, 10, 0, 100.0d, (-1.0d), var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setTextAntiAlias((java.lang.Object)(-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesShape(true);
    var0.setDrawOutlines(false);
    org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var11 = var10.getMaximumItemCount();
    java.beans.PropertyChangeListener var12 = null;
    var10.removePropertyChangeListener(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var18 = var17.getRangeDescription();
    org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
    boolean var24 = var21.isAxisLineVisible();
    var21.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
    var19.delete(var27);
    org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var31 = var30.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isAxisLineVisible();
    var30.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
    org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
    org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var42 = var41.getMaximumItemCount();
    java.beans.PropertyChangeListener var43 = null;
    var41.removePropertyChangeListener(var43);
    org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var41);
    var37.addChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var48 = var45.getSeriesKey((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2147483647);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("100");
//     org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
//     java.awt.Font var4 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("", var4, (org.jfree.chart.plot.Plot)var5, false);
//     java.lang.Object var8 = var7.getTextAntiAlias();
//     var7.setBackgroundImageAlignment(2147483647);
//     java.awt.RenderingHints var11 = var7.getRenderingHints();
//     var1.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var7);
//     org.jfree.chart.event.PlotChangeEvent var13 = null;
//     var7.plotChanged(var13);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getLowerClip();
    java.awt.Stroke var16 = var2.getItemStroke(0, 255, false);
    java.io.ObjectOutputStream var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var16, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     var2.setOutlineVisible(true);
//     org.jfree.chart.LegendItemCollection var6 = var2.getFixedLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var2.handleClick(2147483647, 10, var9);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
    org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxisForDataset(2147483647);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.AxisSpace var5 = null;
    var4.setFixedDomainAxisSpace(var5, true);
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.util.List var10 = null;
    var4.drawRangeTickBands(var8, var9, var10);
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var14 = var13.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var15 = null;
    var13.setDrawingSupplier(var15);
    float var17 = var13.getForegroundAlpha();
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var21 = null;
    org.jfree.chart.urls.XYURLGenerator var22 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var21, var22);
    org.jfree.chart.urls.XYURLGenerator var27 = var23.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var28 = null;
    var23.setBaseURLGenerator(var28, false);
    java.awt.Paint var34 = var23.getItemFillPaint(10, 100, false);
    var19.setLabelPaint(var34);
    float var36 = var19.getAlpha();
    org.jfree.chart.util.Layer var37 = null;
    boolean var38 = var13.removeDomainMarker((org.jfree.chart.plot.Marker)var19, var37);
    org.jfree.chart.util.Layer var39 = null;
    boolean var40 = var4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker)var19, var39);
    boolean var41 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var19);
    org.jfree.chart.annotations.CategoryAnnotation var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     var2.setOutlineVisible(true);
//     var2.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var12 = null;
//     org.jfree.chart.urls.XYURLGenerator var13 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var12, var13);
//     org.jfree.chart.urls.XYURLGenerator var18 = var14.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var19 = null;
//     var14.setBaseURLGenerator(var19, false);
//     java.awt.Paint var25 = var14.getItemFillPaint(10, 100, false);
//     var10.setLabelPaint(var25);
//     float var27 = var10.getAlpha();
//     java.awt.Paint var28 = var10.getOutlinePaint();
//     org.jfree.chart.util.Layer var29 = null;
//     var2.addRangeMarker(2147483647, (org.jfree.chart.plot.Marker)var10, var29, true);
//     org.jfree.chart.axis.PeriodAxis var33 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var34 = var33.getTickLabelPaint();
//     java.lang.Class var35 = var33.getMajorTickTimePeriodClass();
//     java.awt.Paint var36 = var33.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var38 = null;
//     org.jfree.chart.urls.XYURLGenerator var39 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var38, var39);
//     org.jfree.chart.event.RendererChangeEvent var41 = null;
//     var40.notifyListeners(var41);
//     var40.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var46 = var40.getBaseShape();
//     var33.setLeftArrow(var46);
//     var33.setRangeWithMargins(0.025d, 4.0d);
//     org.jfree.data.Range var51 = var2.getDataRange((org.jfree.chart.axis.ValueAxis)var33);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var40.", var14.equals(var40) == var40.equals(var14));
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.xy.XYDataset var0 = null;
    java.awt.Image var4 = null;
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var4, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "100", "hi!");
    org.jfree.data.xy.XYSeries var12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var13 = var12.clone();
    var12.add(0.0d, 100.0d, true);
    java.util.List var18 = var12.getItems();
    var8.setContributors(var18);
    org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var23 = var22.getFont();
    org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var23);
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
    boolean var26 = var24.equals((java.lang.Object)var25);
    org.jfree.data.Range var29 = new org.jfree.data.Range(0.2d, 0.2d);
    var25.setRange(var29, true, false);
    double var33 = var29.getCentralValue();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var35 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(var0, var18, var29, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.2d);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     double var3 = var2.getGap();
//     var2.setOutlineVisible(true);
//     var2.clearRangeMarkers();
//     org.jfree.chart.labels.XYToolTipGenerator var8 = null;
//     org.jfree.chart.urls.XYURLGenerator var9 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var8, var9);
//     org.jfree.chart.event.RendererChangeEvent var11 = null;
//     var10.notifyListeners(var11);
//     var2.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var10);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var14 = var10.getLegendItemLabelGenerator();
//     java.awt.Stroke var15 = var10.getBaseOutlineStroke();
//     org.jfree.chart.labels.XYToolTipGenerator var17 = null;
//     org.jfree.chart.urls.XYURLGenerator var18 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var17, var18);
//     org.jfree.chart.urls.XYURLGenerator var23 = var19.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var24 = null;
//     var19.setBaseURLGenerator(var24, false);
//     java.awt.Paint var30 = var19.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var31 = var19.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var33 = null;
//     var19.setSeriesOutlinePaint(0, var33, false);
//     boolean var36 = var19.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var39 = var38.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var40 = var38.getLegendItems();
//     java.awt.Stroke var41 = var38.getDomainCrosshairStroke();
//     var19.setSeriesOutlineStroke(1, var41);
//     org.jfree.chart.urls.StandardXYURLGenerator var44 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
//     var19.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var44);
//     var10.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var44, false);
//     
//     // Checks the contract:  equals-hashcode on var10 and var19
//     assertTrue("Contract failed: equals-hashcode on var10 and var19", var10.equals(var19) ? var10.hashCode() == var19.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var19.", var10.equals(var19) == var19.equals(var10));
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 2);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     int var4 = var3.getMaximumItemCount();
//     java.text.NumberFormat var5 = java.text.NumberFormat.getNumberInstance();
//     boolean var6 = var3.equals((java.lang.Object)var5);
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     int var11 = var10.getMaximumItemCount();
//     java.beans.PropertyChangeListener var12 = null;
//     var10.removePropertyChangeListener(var12);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     java.lang.String var18 = var17.getRangeDescription();
//     org.jfree.data.time.TimeSeries var19 = var10.addAndOrUpdate(var17);
//     org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var22 = var21.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
//     boolean var24 = var21.isAxisLineVisible();
//     var21.setPositiveArrowVisible(false);
//     org.jfree.data.time.RegularTimePeriod var27 = var21.getFirst();
//     var19.delete(var27);
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var31 = var30.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
//     boolean var33 = var30.isAxisLineVisible();
//     var30.setPositiveArrowVisible(false);
//     org.jfree.data.time.RegularTimePeriod var36 = var30.getFirst();
//     org.jfree.data.time.TimeSeries var37 = var3.createCopy(var27, var36);
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
//     int var42 = var41.getMaximumItemCount();
//     java.beans.PropertyChangeListener var43 = null;
//     var41.removePropertyChangeListener(var43);
//     org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var41);
//     var37.addChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
//     java.util.List var47 = null;
//     org.jfree.data.Range var49 = var45.getDomainBounds(var47, false);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setSeriesURLGenerator(3, var7, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesToolTipGenerator((-435), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    java.lang.Object var5 = var4.getTextAntiAlias();
    var4.setBackgroundImageAlignment(2147483647);
    java.awt.RenderingHints var8 = var4.getRenderingHints();
    var4.clearSubtitles();
    var4.setAntiAlias(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    boolean var12 = var7.getAutoPopulateSectionOutlinePaint();
    org.jfree.data.general.PieDataset var13 = var7.getDataset();
    org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var13, (java.lang.Comparable)0.2d, 5.0d, 100);
    boolean var18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
    var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
    java.awt.Paint var10 = null;
    var9.setLabelBackgroundPaint(var10);
    org.jfree.chart.util.Rotation var12 = var9.getDirection();
    java.awt.Paint var13 = var9.getLabelLinkPaint();
    java.awt.Paint var14 = var9.getBaseSectionPaint();
    org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
    var15.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var15);
    java.awt.Paint var23 = null;
    var22.setLabelBackgroundPaint(var23);
    var22.setInnerSeparatorExtension(0.0d);
    java.awt.Stroke var27 = var22.getLabelLinkStroke();
    org.jfree.chart.StandardChartTheme var29 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var30 = var29.getTitlePaint();
    java.awt.Paint var31 = var29.getLegendBackgroundPaint();
    java.awt.Color var34 = java.awt.Color.getColor("hi!", 100);
    int var35 = var34.getBlue();
    java.awt.Color var36 = var34.darker();
    var29.setWallPaint((java.awt.Paint)var36);
    java.awt.Paint var38 = var29.getShadowPaint();
    org.jfree.chart.labels.XYToolTipGenerator var40 = null;
    org.jfree.chart.urls.XYURLGenerator var41 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var40, var41);
    org.jfree.chart.urls.XYURLGenerator var46 = var42.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var47 = null;
    var42.setBaseURLGenerator(var47, false);
    java.awt.Paint var53 = var42.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var54 = var42.getBaseNegativeItemLabelPosition();
    java.awt.Paint var56 = null;
    var42.setSeriesOutlinePaint(0, var56, false);
    boolean var59 = var42.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var61 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var62 = var61.getRangeAxis();
    org.jfree.chart.LegendItemCollection var63 = var61.getLegendItems();
    java.awt.Stroke var64 = var61.getDomainCrosshairStroke();
    var42.setSeriesOutlineStroke(1, var64);
    java.awt.Stroke var69 = var42.getItemStroke(0, (-1), false);
    org.jfree.chart.plot.IntervalMarker var71 = new org.jfree.chart.plot.IntervalMarker((-1.0d), Double.NaN, var14, var27, var38, var69, 0.8f);
    java.awt.Paint var72 = var71.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.ui.Licences var0 = org.jfree.chart.ui.Licences.getInstance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var8 = null;
//     var3.setBaseURLGenerator(var8, false);
//     java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var17 = null;
//     var3.setSeriesOutlinePaint(0, var17, false);
//     boolean var20 = var3.isShapesFilled();
//     org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var23 = var22.getRangeAxis();
//     org.jfree.chart.LegendItemCollection var24 = var22.getLegendItems();
//     java.awt.Stroke var25 = var22.getDomainCrosshairStroke();
//     var3.setSeriesOutlineStroke(1, var25);
//     org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var31 = null;
//     var29.setSeriesURLGenerator(10, var31);
//     boolean var33 = var29.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var35 = null;
//     var29.setSeriesItemLabelGenerator(0, var35, false);
//     org.jfree.chart.labels.XYToolTipGenerator var40 = null;
//     org.jfree.chart.urls.XYURLGenerator var41 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var40, var41);
//     org.jfree.chart.urls.XYURLGenerator var46 = var42.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var47 = null;
//     var42.setBaseURLGenerator(var47, false);
//     java.awt.Paint var53 = var42.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.ItemLabelPosition var54 = var42.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var55 = var54.getTextAnchor();
//     var29.setSeriesNegativeItemLabelPosition(100, var54, false);
//     var3.setBasePositiveItemLabelPosition(var54);
//     
//     // Checks the contract:  equals-hashcode on var15 and var54
//     assertTrue("Contract failed: equals-hashcode on var15 and var54", var15.equals(var54) ? var15.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var15
//     assertTrue("Contract failed: equals-hashcode on var54 and var15", var54.equals(var15) ? var54.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var3, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "100", "hi!");
    org.jfree.chart.ui.Library[] var8 = var7.getOptionalLibraries();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "100", "hi!");
    java.util.List var17 = var16.getContributors();
    var7.addLibrary((org.jfree.chart.ui.Library)var16);
    var16.setLicenceText("hi!");
    org.jfree.chart.labels.XYToolTipGenerator var22 = null;
    org.jfree.chart.urls.XYURLGenerator var23 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var22, var23);
    org.jfree.chart.urls.XYURLGenerator var28 = var24.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var29 = null;
    var24.setBaseURLGenerator(var29, false);
    java.awt.Paint var35 = var24.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var37 = null;
    var24.setSeriesItemLabelGenerator(70, var37);
    org.jfree.data.xy.DefaultXYDataset var39 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var41 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var42 = var41.getSize();
    int var43 = var39.indexOf((java.lang.Comparable)var42);
    org.jfree.data.Range var44 = var24.findRangeBounds((org.jfree.data.xy.XYDataset)var39);
    org.jfree.data.Range var45 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var39);
    org.jfree.data.Range var46 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var39);
    org.jfree.data.general.DefaultPieDataset var47 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var50 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var47, (java.lang.Comparable)"hi!", 10.0d);
    java.util.List var51 = var47.getKeys();
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var55 = var54.getFont();
    org.jfree.chart.text.TextLine var56 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var55);
    org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis();
    boolean var58 = var56.equals((java.lang.Object)var57);
    org.jfree.data.Range var61 = new org.jfree.data.Range(0.2d, 0.2d);
    var57.setRange(var61, true, false);
    org.jfree.data.Range var66 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset)var39, var51, var61, true);
    var16.setContributors(var51);
    var16.setLicenceText("WMAP_Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(Double.NaN);
    var0.configureDomainAxes();
    org.jfree.chart.plot.CategoryMarker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(96, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     int var2 = var1.getMaximumCategoryLabelLines();
//     var1.clearCategoryLabelToolTips();
//     org.jfree.chart.axis.CategoryAnchor var4 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var13.setCategoryLabelPositionOffset(2147483647);
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var20 = var19.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var21 = null;
//     var19.setDrawingSupplier(var21);
//     float var23 = var19.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var27 = null;
//     org.jfree.chart.urls.XYURLGenerator var28 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var27, var28);
//     org.jfree.chart.urls.XYURLGenerator var33 = var29.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var34 = null;
//     var29.setBaseURLGenerator(var34, false);
//     java.awt.Paint var40 = var29.getItemFillPaint(10, 100, false);
//     var25.setLabelPaint(var40);
//     float var42 = var25.getAlpha();
//     org.jfree.chart.util.Layer var43 = null;
//     boolean var44 = var19.removeDomainMarker((org.jfree.chart.plot.Marker)var25, var43);
//     org.jfree.chart.util.RectangleEdge var45 = var19.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisState var46 = null;
//     var13.drawTickMarks(var16, 10.0d, var18, var45, var46);
//     org.jfree.chart.axis.AxisState var48 = null;
//     var8.drawTickMarks(var9, 1.0d, var11, var45, var48);
//     double var50 = var1.getCategoryJava2DCoordinate(var4, 1, 0, var7, var45);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var1 = var0.getDatasetRenderingOrder();
    org.jfree.chart.util.PaintList var2 = new org.jfree.chart.util.PaintList();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.lang.String var4 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var4.equals("DatasetRenderingOrder.REVERSE"));

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-435));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(100.0d, "", "NOID", false);
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var6, var7);
    org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var13 = null;
    var8.setBaseURLGenerator(var13, false);
    java.awt.Paint var19 = var8.getItemFillPaint(10, 100, false);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var22 = var21.getTickLabelPaint();
    var8.setBasePaint(var22);
    var8.setPlotArea(false);
    org.jfree.chart.util.LogFormat var30 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    java.lang.StringBuffer var32 = null;
    java.text.FieldPosition var33 = null;
    java.lang.StringBuffer var34 = var30.format(10L, var32, var33);
    java.text.FieldPosition var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.StringBuffer var36 = var4.format((java.lang.Object)var8, var34, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.general.DefaultPieDataset var2 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var2, (java.lang.Comparable)"hi!", 10.0d);
//     var2.setValue((java.lang.Comparable)"hi!", (-1.0d));
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var2);
//     java.awt.Paint var10 = null;
//     var9.setLabelBackgroundPaint(var10);
//     var9.setInnerSeparatorExtension(0.0d);
//     boolean var14 = var9.getAutoPopulateSectionOutlinePaint();
//     org.jfree.data.general.PieDataset var15 = var9.getDataset();
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var9, true);
//     var17.setBorderVisible(false);
//     org.jfree.chart.title.LegendTitle var20 = var17.getLegend();
//     java.util.List var21 = null;
//     var17.setSubtitles(var21);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var5 = var4.getTickLabelPaint();
//     java.lang.Class var6 = var4.getMajorTickTimePeriodClass();
//     java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var2, var6);
//     java.io.InputStream var8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", var2);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var0.setAutoPopulateSeriesShape(true);
//     var0.setDrawOutlines(false);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var9 = var8.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var10 = null;
//     var8.setDrawingSupplier(var10);
//     float var12 = var8.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var16 = null;
//     org.jfree.chart.urls.XYURLGenerator var17 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var16, var17);
//     org.jfree.chart.urls.XYURLGenerator var22 = var18.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var23 = null;
//     var18.setBaseURLGenerator(var23, false);
//     java.awt.Paint var29 = var18.getItemFillPaint(10, 100, false);
//     var14.setLabelPaint(var29);
//     float var31 = var14.getAlpha();
//     org.jfree.chart.util.Layer var32 = null;
//     boolean var33 = var8.removeDomainMarker((org.jfree.chart.plot.Marker)var14, var32);
//     org.jfree.chart.util.RectangleEdge var34 = var8.getRangeAxisEdge();
//     org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var37 = var36.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getLabelInsets();
//     var36.setAxisLineVisible(false);
//     var36.setMinorTickMarkInsideLength((-1.0f));
//     java.lang.Object var43 = var36.clone();
//     boolean var44 = var36.isTickMarksVisible();
//     org.jfree.chart.axis.PeriodAxis var46 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var47 = var46.getTickLabelPaint();
//     java.lang.Class var48 = var46.getMajorTickTimePeriodClass();
//     java.awt.Paint var49 = var46.getTickMarkPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var51 = null;
//     org.jfree.chart.urls.XYURLGenerator var52 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var51, var52);
//     org.jfree.chart.event.RendererChangeEvent var54 = null;
//     var53.notifyListeners(var54);
//     var53.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Shape var59 = var53.getBaseShape();
//     var46.setLeftArrow(var59);
//     org.jfree.chart.labels.XYToolTipGenerator var62 = null;
//     org.jfree.chart.urls.XYURLGenerator var63 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var64 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var62, var63);
//     org.jfree.chart.urls.XYURLGenerator var68 = var64.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var69 = null;
//     var64.setBaseURLGenerator(var69, false);
//     java.awt.Paint var75 = var64.getItemFillPaint(10, 100, false);
//     org.jfree.chart.labels.XYItemLabelGenerator var77 = null;
//     var64.setSeriesItemLabelGenerator(70, var77);
//     org.jfree.data.xy.DefaultXYDataset var79 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.chart.axis.NumberTickUnit var81 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
//     double var82 = var81.getSize();
//     int var83 = var79.indexOf((java.lang.Comparable)var82);
//     org.jfree.data.Range var84 = var64.findRangeBounds((org.jfree.data.xy.XYDataset)var79);
//     org.jfree.data.Range var85 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var79);
//     org.jfree.data.Range var86 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var79);
//     var0.drawItem(var5, var6, var7, (org.jfree.chart.plot.XYPlot)var8, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.data.xy.XYDataset)var79, 70, 0, false, 96);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var9.add((org.jfree.chart.block.Block)var10);
//     org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
//     org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.data.general.DefaultPieDataset var15 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var15, (java.lang.Comparable)"hi!", 10.0d);
//     org.jfree.data.xy.XYDataItem var21 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-435), (java.lang.Number)10.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer(var12, (org.jfree.data.general.Dataset)var15, (java.lang.Comparable)(-435));
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     var22.draw(var23, var24);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", var1, 0.2d, (-1.0f), 0.8f);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    org.jfree.chart.labels.PieSectionLabelGenerator var34 = var7.getLabelGenerator();
    java.awt.Shape var35 = var7.getLegendItemShape();
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var7.markerChanged(var36);
    org.jfree.chart.util.Rotation var38 = var7.getDirection();
    org.jfree.data.general.DefaultPieDataset var39 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var42 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var39, (java.lang.Comparable)"hi!", 10.0d);
    var39.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var46 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var39);
    java.awt.Paint var47 = null;
    var46.setLabelBackgroundPaint(var47);
    org.jfree.chart.util.Rotation var49 = var46.getDirection();
    boolean var50 = var7.equals((java.lang.Object)var46);
    org.jfree.chart.plot.CombinedDomainXYPlot var51 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var52 = var51.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.RenderingSource var56 = null;
    var51.select(10.0d, 100.0d, var55, var56);
    var51.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var61 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var62 = var61.getTickLabelPaint();
    var51.setOutlinePaint(var62);
    boolean var64 = var51.isDomainCrosshairLockedOnData();
    org.jfree.chart.plot.CombinedDomainXYPlot var65 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var66 = var65.getRangeAxis();
    java.awt.Paint var67 = var65.getDomainGridlinePaint();
    var51.setRangeZeroBaselinePaint(var67);
    var46.setNoDataMessagePaint(var67);
    var46.setLabelLinkMargin(0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxis();
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", 100);
//     int var12 = var11.getBlue();
//     java.awt.Color var13 = var11.darker();
//     java.awt.Color var14 = var13.brighter();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.event.AxisChangeEvent var18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var17);
//     org.jfree.chart.axis.PeriodAxis var20 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var21 = var20.getTickLabelPaint();
//     var20.zoomRange(1.0d, 100.0d);
//     double var25 = var20.getLowerMargin();
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var20);
//     org.jfree.chart.labels.XYToolTipGenerator var28 = null;
//     org.jfree.chart.urls.XYURLGenerator var29 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var28, var29);
//     org.jfree.chart.event.RendererChangeEvent var31 = null;
//     var30.notifyListeners(var31);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var35 = var34.getDomainMinorGridlineStroke();
//     var34.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.plot.Marker var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     var30.drawDomainMarker(var33, (org.jfree.chart.plot.XYPlot)var34, var38, var39, var40);
//     java.awt.Stroke var43 = var30.getSeriesStroke((-435));
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.renderer.xy.XYItemRenderer)var30);
//     boolean var45 = var13.equals((java.lang.Object)var17);
//     org.jfree.chart.plot.CombinedRangeXYPlot var46 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var17);
//     org.jfree.data.Range var48 = null;
//     org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var48);
//     org.jfree.chart.block.RectangleConstraint var50 = var49.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var51 = var50.toUnconstrainedWidth();
//     double var52 = var50.getHeight();
//     org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var56 = var55.getFont();
//     org.jfree.chart.text.TextLine var57 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var56);
//     org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
//     boolean var59 = var57.equals((java.lang.Object)var58);
//     org.jfree.data.Range var62 = new org.jfree.data.Range(0.2d, 0.2d);
//     var58.setRange(var62, true, false);
//     org.jfree.chart.block.RectangleConstraint var66 = var50.toRangeHeight(var62);
//     var17.setDefaultAutoRange(var62);
//     var0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var17, false);
//     
//     // Checks the contract:  equals-hashcode on var34 and var0
//     assertTrue("Contract failed: equals-hashcode on var34 and var0", var34.equals(var0) ? var34.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var34 and var0.", var34.equals(var0) == var0.equals(var34));
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(Double.NaN);
//     var0.configureDomainAxes();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var0.drawBackground(var4, var5);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Jan"+ "'", var2.equals("Jan"));

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.axis.AxisSpace var4 = var0.getFixedDomainAxisSpace();
    java.awt.Font var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var7, false);
    var9.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var13 = var12.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    var9.setPadding(var14);
    double var17 = var14.calculateLeftInset(100.0d);
    var0.setInsets(var14);
    java.awt.geom.Rectangle2D var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var20 = var14.createOutsetRectangle(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var4 = var3.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var5 = null;
    var3.setDrawingSupplier(var5);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    var1.setAutoRangeMinimumSize(0.05d);
    var1.setUpperMargin(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var3 = var2.getSize();
    int var4 = var0.indexOf((java.lang.Comparable)var3);
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var9 = var8.clone();
    var8.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var8);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    org.jfree.data.xy.XYSeries var19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    var14.addSeries(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var23 = var14.getEndX(10, (-435));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var3 = var2.getFont();
    org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var3);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    boolean var6 = var4.equals((java.lang.Object)var5);
    var5.zoomRange(0.2d, 2.0d);
    java.util.Date var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setMinimumDate(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 96, 70);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    java.lang.String var11 = var10.getRangeDescription();
    org.jfree.data.time.TimeSeries var12 = var3.addAndOrUpdate(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.delete((-1), 70, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     boolean var3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((-5.76E7d), 0.0d, var2);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var1 = var0.getDatasetRenderingOrder();
    org.jfree.chart.annotations.CategoryAnnotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset();
//     org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var1, (java.lang.Comparable)"hi!", 10.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var1.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
//     boolean var7 = var0.equals((java.lang.Object)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var9 = var8.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.RenderingSource var13 = null;
//     var8.select(10.0d, 100.0d, var12, var13);
//     var8.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var17 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var18 = new org.jfree.chart.block.BlockContainer();
//     var17.add((org.jfree.chart.block.Block)var18);
//     org.jfree.chart.block.Arrangement var20 = var17.getArrangement();
//     org.jfree.chart.block.BorderArrangement var21 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8, var20, (org.jfree.chart.block.Arrangement)var21);
//     java.awt.Paint var23 = var22.getItemPaint();
//     org.jfree.chart.block.BlockContainer var24 = var22.getItemContainer();
//     org.jfree.chart.util.RectangleAnchor var25 = var22.getLegendItemGraphicLocation();
//     boolean var26 = var0.equals((java.lang.Object)var25);
//     org.jfree.chart.labels.XYToolTipGenerator var29 = null;
//     org.jfree.chart.urls.XYURLGenerator var30 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var29, var30);
//     org.jfree.chart.urls.XYURLGenerator var35 = var31.getURLGenerator(0, 1, true);
//     var31.setBaseSeriesVisibleInLegend(false);
//     org.jfree.chart.labels.XYItemLabelGenerator var38 = null;
//     var31.setBaseItemLabelGenerator(var38);
//     java.awt.Font var41 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("", var41, (org.jfree.chart.plot.Plot)var42, false);
//     var44.clearSubtitles();
//     org.jfree.chart.axis.PeriodAxis var47 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var48 = var47.getTickLabelPaint();
//     org.jfree.chart.util.RectangleInsets var49 = var47.getLabelInsets();
//     var44.setPadding(var49);
//     org.jfree.chart.event.ChartChangeEventType var51 = null;
//     org.jfree.chart.event.ChartChangeEvent var52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31, var44, var51);
//     java.awt.Paint var53 = var44.getBorderPaint();
//     var0.setPaint(68, var53);
//     
//     // Checks the contract:  equals-hashcode on var5 and var42
//     assertTrue("Contract failed: equals-hashcode on var5 and var42", var5.equals(var42) ? var5.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var5
//     assertTrue("Contract failed: equals-hashcode on var42 and var5", var42.equals(var5) ? var42.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    java.text.NumberFormat var5 = var4.getExponentFormat();
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("100");
    org.jfree.chart.block.BlockFrame var10 = var9.getFrame();
    org.jfree.chart.util.RectangleInsets var11 = var9.getPadding();
    var7.setLabelInsets(var11);
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.axis.CategoryLabelPositions var15 = var14.getCategoryLabelPositions();
    var7.setCategoryLabelPositions(var15);
    var7.setLabel("WMAP_Plot");
    org.jfree.chart.util.LogFormat var23 = new org.jfree.chart.util.LogFormat(100.0d, "hi!", "", false);
    java.lang.StringBuffer var25 = null;
    java.text.FieldPosition var26 = null;
    java.lang.StringBuffer var27 = var23.format(10L, var25, var26);
    java.text.FieldPosition var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.StringBuffer var29 = var4.format((java.lang.Object)"WMAP_Plot", var25, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    boolean var6 = var2.isDrawBarOutline();
    org.jfree.chart.labels.XYToolTipGenerator var9 = null;
    org.jfree.chart.urls.XYURLGenerator var10 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var9, var10);
    org.jfree.chart.urls.XYURLGenerator var15 = var11.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var16 = null;
    var11.setBaseURLGenerator(var16, false);
    java.awt.Paint var22 = var11.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var23 = var11.getBaseNegativeItemLabelPosition();
    java.awt.Paint var25 = null;
    var11.setSeriesOutlinePaint(0, var25, false);
    boolean var28 = var11.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var31 = var30.getRangeAxis();
    org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
    java.awt.Stroke var33 = var30.getDomainCrosshairStroke();
    var11.setSeriesOutlineStroke(1, var33);
    java.awt.Stroke var36 = var11.getSeriesOutlineStroke(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesStroke((-1), var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     var0.setRenderer(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var6 = var5.getRangeAxis();
//     java.awt.Paint var7 = var5.getDomainGridlinePaint();
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var5);
//     java.awt.Image var9 = var5.getBackgroundImage();
//     java.awt.geom.Point2D var10 = var5.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var11 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var0.draw(var3, var4, var10, var11, var12);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    double var2 = var0.getGap();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.0d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    java.text.NumberFormat var1 = var0.getYFormat();
    org.jfree.data.xy.XYSeries var5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var6 = var5.clone();
    var5.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var11 = new org.jfree.data.xy.XYSeriesCollection(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var14 = var0.generateToolTip((org.jfree.data.xy.XYDataset)var11, (-435), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.DatasetRenderingOrder var1 = var0.getDatasetRenderingOrder();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getDomainMarkers(68, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.data.time.TimeSeries var9 = var7.getSeries((java.lang.Comparable)2);
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var11 = var10.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var12 = null;
    var10.setDrawingSupplier(var12);
    boolean var14 = var10.isDomainPannable();
    org.jfree.chart.labels.XYToolTipGenerator var16 = null;
    org.jfree.chart.urls.XYURLGenerator var17 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var16, var17);
    org.jfree.chart.urls.XYURLGenerator var22 = var18.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var23 = null;
    var18.setBaseURLGenerator(var23, false);
    java.awt.Paint var29 = var18.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var30 = var18.getBaseNegativeItemLabelPosition();
    java.awt.Paint var32 = null;
    var18.setSeriesOutlinePaint(0, var32, false);
    boolean var35 = var18.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var38 = var37.getRangeAxis();
    org.jfree.chart.LegendItemCollection var39 = var37.getLegendItems();
    java.awt.Stroke var40 = var37.getDomainCrosshairStroke();
    var18.setSeriesOutlineStroke(1, var40);
    java.awt.Stroke var43 = var18.getSeriesOutlineStroke(1);
    var10.setRangeGridlineStroke(var43);
    org.jfree.chart.axis.AxisSpace var45 = null;
    var10.setFixedRangeAxisSpace(var45);
    var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var50 = var7.getEndX(10, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset)var0, (java.lang.Comparable)"hi!", 10.0d);
    var0.setValue((java.lang.Comparable)"hi!", (-1.0d));
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    java.awt.Paint var8 = null;
    var7.setLabelBackgroundPaint(var8);
    var7.setInnerSeparatorExtension(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var13, var14);
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.awt.Paint var26 = var15.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var15.getBaseNegativeItemLabelPosition();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 100);
    int var31 = var30.getBlue();
    var15.setBaseLegendTextPaint((java.awt.Paint)var30);
    var7.setLabelOutlinePaint((java.awt.Paint)var30);
    var7.setAutoPopulateSectionOutlinePaint(true);
    double var36 = var7.getSectionDepth();
    java.awt.Paint var37 = null;
    var7.setLabelBackgroundPaint(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    java.awt.Paint var7 = null;
    var3.setSeriesPaint(100, var7, true);
    org.jfree.chart.labels.ItemLabelPosition var10 = var3.getBaseNegativeItemLabelPosition();
    var3.setDataBoundsIncludesVisibleSeriesOnly(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
//     var2.setTop(10.0d);
//     var0.ensureAtLeast(var2);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
//     org.jfree.chart.plot.DrawingSupplier var9 = null;
//     var7.setDrawingSupplier(var9);
//     float var11 = var7.getForegroundAlpha();
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.labels.XYToolTipGenerator var15 = null;
//     org.jfree.chart.urls.XYURLGenerator var16 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var15, var16);
//     org.jfree.chart.urls.XYURLGenerator var21 = var17.getURLGenerator(0, 1, true);
//     org.jfree.chart.urls.XYURLGenerator var22 = null;
//     var17.setBaseURLGenerator(var22, false);
//     java.awt.Paint var28 = var17.getItemFillPaint(10, 100, false);
//     var13.setLabelPaint(var28);
//     float var30 = var13.getAlpha();
//     org.jfree.chart.util.Layer var31 = null;
//     boolean var32 = var7.removeDomainMarker((org.jfree.chart.plot.Marker)var13, var31);
//     org.jfree.chart.util.RectangleEdge var33 = var7.getRangeAxisEdge();
//     java.awt.geom.Rectangle2D var34 = var0.reserved(var6, var33);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.Range.scale(var0, 0.5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.awt.Font var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedRangeAxisSpace(var9);
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var12 = var11.getOpposite();
    boolean var13 = var3.equals((java.lang.Object)var11);
    var3.add(2.0d, (java.lang.Number)0.5f);
    int var18 = var3.indexOf((java.lang.Number)0.05d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var20 = var3.getX(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("null");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    boolean var6 = var2.isDrawBarOutline();
    double var7 = var2.getBase();
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 100);
    int var12 = var11.getBlue();
    java.awt.Color var13 = var11.darker();
    int var14 = var13.getBlue();
    var2.setSeriesOutlinePaint(1, (java.awt.Paint)var13, false);
    double var17 = var2.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
    java.awt.Paint var5 = var2.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var2.setSeriesURLGenerator(10, var4);
//     org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var2.equals((java.lang.Object)var9);
//     double var12 = var2.getLowerClip();
//     boolean var13 = var2.getAutoPopulateSeriesPaint();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var15.zoomRangeAxes(0.0d, 10.0d, var18, var19);
//     org.jfree.chart.axis.AxisSpace var21 = new org.jfree.chart.axis.AxisSpace();
//     var15.setFixedDomainAxisSpace(var21, false);
//     java.awt.geom.Rectangle2D var24 = null;
//     var2.drawDomainGridline(var14, var15, var24, 10.0d);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    double var6 = var3.getItemLabelAnchorOffset();
    org.jfree.chart.labels.XYItemLabelGenerator var8 = var3.getSeriesItemLabelGenerator(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    java.text.NumberFormat var2 = var1.getYFormat();
    java.text.DateFormat var4 = null;
    java.text.DateFormat var5 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var4, var5);
    org.jfree.chart.urls.StandardXYURLGenerator var8 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYStepRenderer var9 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var6, (org.jfree.chart.urls.XYURLGenerator)var8);
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var12.setSeriesURLGenerator(10, var14);
    org.jfree.data.xy.XYSeries var19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var20 = var19.clone();
    boolean var21 = var12.equals((java.lang.Object)var19);
    org.jfree.chart.plot.CombinedDomainXYPlot var22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var23 = var22.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var24 = null;
    var22.setDrawingSupplier(var24);
    float var26 = var22.getForegroundAlpha();
    boolean var27 = var12.equals((java.lang.Object)var22);
    double var28 = var12.getXOffset();
    java.awt.Font var31 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("", var31, (org.jfree.chart.plot.Plot)var32, false);
    org.jfree.chart.axis.AxisSpace var35 = null;
    var32.setFixedRangeAxisSpace(var35);
    org.jfree.chart.axis.AxisLocation var37 = var32.getDomainAxisLocation();
    java.awt.Paint var38 = var32.getDomainGridlinePaint();
    var12.setSeriesItemLabelPaint(255, var38, true);
    boolean var41 = var8.equals((java.lang.Object)var12);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(3, (org.jfree.chart.labels.XYToolTipGenerator)var1, (org.jfree.chart.urls.XYURLGenerator)var8);
    java.text.DateFormat var43 = var1.getYDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    var2.setTop(10.0d);
    var0.ensureAtLeast(var2);
    org.jfree.chart.util.RectangleEdge var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.ensureAtLeast(3.0d, var7);
      fail("Expected exception of type java.lang.IllegalStateException");
    } catch (java.lang.IllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, (-1.0d), 0.08d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer();
    var5.add((org.jfree.chart.block.Block)var6);
    boolean var8 = var5.isEmpty();
    org.jfree.chart.block.FlowArrangement var9 = new org.jfree.chart.block.FlowArrangement();
    var5.setArrangement((org.jfree.chart.block.Arrangement)var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var13 = null;
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var13);
    org.jfree.chart.block.RectangleConstraint var15 = var14.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var16 = var15.toUnconstrainedWidth();
    double var17 = var15.getWidth();
    org.jfree.chart.block.RectangleConstraint var18 = var15.toUnconstrainedHeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var19 = var4.arrange(var5, var11, var18);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var3 = var2.getSize();
    int var4 = var0.indexOf((java.lang.Comparable)var3);
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var9 = var8.clone();
    var8.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var8);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var19 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var14, 96, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    var3.setBaseURLGenerator(var8, false);
    java.awt.Paint var14 = var3.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
    var3.setSeriesItemLabelGenerator(70, var16);
    org.jfree.data.xy.DefaultXYDataset var18 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var21 = var20.getSize();
    int var22 = var18.indexOf((java.lang.Comparable)var21);
    org.jfree.data.Range var23 = var3.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var18, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var28 = var18.getXValue(10, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.RenderingSource var5 = null;
    var0.select(10.0d, 100.0d, var4, var5);
    var0.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    var9.add((org.jfree.chart.block.Block)var10);
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    org.jfree.chart.block.BorderArrangement var13 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var12, (org.jfree.chart.block.Arrangement)var13);
    java.awt.Paint var15 = var14.getItemPaint();
    org.jfree.chart.block.BlockContainer var16 = var14.getItemContainer();
    boolean var17 = var16.isEmpty();
    org.jfree.chart.block.Arrangement var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setArrangement(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.util.LineUtilities var0 = new org.jfree.chart.util.LineUtilities();

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var2 = var1.getStroke();
    double var3 = var1.getValue();
    org.jfree.chart.util.LengthAdjustmentType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100, "", "");
    int var4 = var3.getMaximumItemCount();
    java.beans.PropertyChangeListener var5 = null;
    var3.removePropertyChangeListener(var5);
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.data.time.TimeSeries var9 = var7.getSeries((java.lang.Comparable)2);
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var11 = var10.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var12 = null;
    var10.setDrawingSupplier(var12);
    boolean var14 = var10.isDomainPannable();
    org.jfree.chart.labels.XYToolTipGenerator var16 = null;
    org.jfree.chart.urls.XYURLGenerator var17 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var16, var17);
    org.jfree.chart.urls.XYURLGenerator var22 = var18.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var23 = null;
    var18.setBaseURLGenerator(var23, false);
    java.awt.Paint var29 = var18.getItemFillPaint(10, 100, false);
    org.jfree.chart.labels.ItemLabelPosition var30 = var18.getBaseNegativeItemLabelPosition();
    java.awt.Paint var32 = null;
    var18.setSeriesOutlinePaint(0, var32, false);
    boolean var35 = var18.isShapesFilled();
    org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var38 = var37.getRangeAxis();
    org.jfree.chart.LegendItemCollection var39 = var37.getLegendItems();
    java.awt.Stroke var40 = var37.getDomainCrosshairStroke();
    var18.setSeriesOutlineStroke(1, var40);
    java.awt.Stroke var43 = var18.getSeriesOutlineStroke(1);
    var10.setRangeGridlineStroke(var43);
    org.jfree.chart.axis.AxisSpace var45 = null;
    var10.setFixedRangeAxisSpace(var45);
    var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.removeSeries(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    var1.zoomRange(1.0d, 100.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    var1.setAxisLineStroke(var7);
    var1.setVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getDomainAxisEdge();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.labels.XYToolTipGenerator var5 = null;
    org.jfree.chart.urls.XYURLGenerator var6 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var5, var6);
    org.jfree.chart.urls.XYURLGenerator var11 = var7.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var12 = null;
    var7.setBaseURLGenerator(var12, false);
    java.awt.Paint var18 = var7.getItemFillPaint(10, 100, false);
    var3.setLabelPaint(var18);
    float var20 = var3.getAlpha();
    java.awt.Paint var21 = var3.getOutlinePaint();
    java.awt.Paint var22 = var3.getOutlinePaint();
    java.awt.Paint var23 = var3.getOutlinePaint();
    org.jfree.chart.util.Layer var24 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var3, var24);
    var0.setRangePannable(true);
    org.jfree.chart.axis.AxisLocation var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(2147483647, var29);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(0, 1, true);
    var3.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
    var3.setBaseItemLabelGenerator(var10);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var13 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
    java.lang.Object var14 = var13.clone();
    var3.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var13);
    org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var18 = var17.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var19 = var17.getLabelInsets();
    var17.setAxisLineVisible(false);
    var17.setMinorTickMarkInsideLength((-1.0f));
    java.lang.Object var24 = var17.clone();
    boolean var25 = var13.equals(var24);
    org.jfree.chart.labels.XYToolTipGenerator var29 = null;
    org.jfree.chart.urls.XYURLGenerator var30 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var29, var30);
    org.jfree.chart.urls.XYURLGenerator var35 = var31.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var36 = null;
    var31.setBaseURLGenerator(var36, false);
    boolean var39 = var31.getPlotArea();
    org.jfree.chart.axis.PeriodAxis var42 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var42);
    double var44 = var43.getGap();
    var43.setOutlineVisible(true);
    java.awt.Stroke var47 = var43.getRangeCrosshairStroke();
    org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var51 = var50.getFont();
    org.jfree.chart.text.TextLine var52 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var51);
    var43.setNoDataMessageFont(var51);
    var31.setSeriesItemLabelFont(10, var51);
    org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("ERROR : Relative To String", var51);
    org.jfree.chart.plot.CombinedDomainXYPlot var56 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var57 = var56.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var58 = null;
    var56.setDrawingSupplier(var58);
    org.jfree.chart.axis.AxisSpace var60 = var56.getFixedDomainAxisSpace();
    java.awt.Font var62 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var63 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart("", var62, (org.jfree.chart.plot.Plot)var63, false);
    var65.clearSubtitles();
    org.jfree.chart.axis.PeriodAxis var68 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var69 = var68.getTickLabelPaint();
    org.jfree.chart.util.RectangleInsets var70 = var68.getLabelInsets();
    var65.setPadding(var70);
    double var73 = var70.calculateLeftInset(100.0d);
    var56.setInsets(var70);
    org.jfree.chart.plot.CombinedDomainXYPlot var75 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var76 = var75.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var79 = null;
    org.jfree.chart.RenderingSource var80 = null;
    var75.select(10.0d, 100.0d, var79, var80);
    var75.setOutlineVisible(false);
    org.jfree.chart.block.BlockContainer var84 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockContainer var85 = new org.jfree.chart.block.BlockContainer();
    var84.add((org.jfree.chart.block.Block)var85);
    org.jfree.chart.block.Arrangement var87 = var84.getArrangement();
    org.jfree.chart.block.BorderArrangement var88 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.LegendTitle var89 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var75, var87, (org.jfree.chart.block.Arrangement)var88);
    java.awt.Paint var90 = var89.getItemPaint();
    var56.setDomainTickBandPaint(var90);
    org.jfree.chart.block.LabelBlock var92 = new org.jfree.chart.block.LabelBlock("hi!", var51, var90);
    boolean var93 = var13.equals((java.lang.Object)var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    float var4 = var0.getForegroundAlpha();
    boolean var5 = var0.isDomainZoomable();
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var7 = var6.getDomainMinorGridlineStroke();
    var6.setDomainCrosshairVisible(false);
    java.awt.Paint var10 = var6.getRangeCrosshairPaint();
    float var11 = var6.getBackgroundImageAlpha();
    var0.add((org.jfree.chart.plot.XYPlot)var6);
    double var13 = var6.getGap();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var17 = var16.getRangeAxis();
    java.awt.Paint var18 = var16.getDomainGridlinePaint();
    org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16);
    java.awt.Image var20 = var16.getBackgroundImage();
    java.awt.geom.Point2D var21 = var16.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.zoomRangeAxes(0.5d, var15, var21, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    int var2 = var1.getMaximumCategoryLabelLines();
    var1.clearCategoryLabelToolTips();
    java.lang.String var4 = var1.getLabel();
    org.jfree.chart.StandardChartTheme var7 = new org.jfree.chart.StandardChartTheme("AxisLocation.TOP_OR_RIGHT");
    java.awt.Paint var8 = var7.getTitlePaint();
    java.awt.Paint var9 = var7.getLegendBackgroundPaint();
    java.awt.Color var12 = java.awt.Color.getColor("hi!", 100);
    int var13 = var12.getBlue();
    java.awt.Color var14 = var12.darker();
    var7.setWallPaint((java.awt.Paint)var14);
    java.awt.Paint var16 = var7.getLabelLinkPaint();
    var1.setTickLabelPaint((java.lang.Comparable)0.2d, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var1, var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
    var7.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var3.drawDomainMarker(var6, (org.jfree.chart.plot.XYPlot)var7, var11, var12, var13);
    var3.setAutoPopulateSeriesOutlinePaint(true);
    var3.setBaseSeriesVisible(true);
    var3.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    int var22 = var3.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("100");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getNumberInstance();
    int var1 = var0.getMaximumFractionDigits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.parseObject("Combined Range XYPlot");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    double var3 = var2.getSize();
    int var4 = var0.indexOf((java.lang.Comparable)var3);
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var9 = var8.clone();
    var8.add(0.0d, 100.0d, true);
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var8);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    org.jfree.data.xy.XYSeries var19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    var14.addSeries(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var23 = var14.getStartY(0, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(5.0d, 2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var2.setSeriesURLGenerator(10, var4);
    org.jfree.data.xy.XYSeries var9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, false, true);
    java.lang.Object var10 = var9.clone();
    boolean var11 = var2.equals((java.lang.Object)var9);
    double var12 = var2.getUpperClip();
    double var13 = var2.getYOffset();
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var15 = var14.getDomainMinorGridlineStroke();
    org.jfree.chart.plot.DrawingSupplier var16 = null;
    var14.setDrawingSupplier(var16);
    org.jfree.chart.axis.AxisSpace var18 = var14.getFixedDomainAxisSpace();
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var20 = var19.getDomainMinorGridlineStroke();
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.RenderingSource var24 = null;
    var19.select(10.0d, 100.0d, var23, var24);
    var19.setOutlineVisible(false);
    org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var30 = var29.getTickLabelPaint();
    var19.setOutlinePaint(var30);
    boolean var32 = var19.isDomainCrosshairLockedOnData();
    org.jfree.chart.plot.CombinedDomainXYPlot var33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var34 = var33.getRangeAxis();
    java.awt.Paint var35 = var33.getDomainGridlinePaint();
    var19.setRangeZeroBaselinePaint(var35);
    var14.setRangeTickBandPaint(var35);
    var2.setShadowPaint(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    double var3 = var2.getGap();
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    org.jfree.chart.LegendItemCollection var6 = var4.getLegendItems();
    var2.setFixedLegendItems(var6);
    int var8 = var2.getRendererCount();
    org.jfree.chart.axis.AxisLocation var9 = var2.getRangeAxisLocation();
    java.awt.Font var11 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("", var11, (org.jfree.chart.plot.Plot)var12, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.add((org.jfree.chart.plot.XYPlot)var12, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.labels.XYToolTipGenerator var2 = null;
    org.jfree.chart.urls.XYURLGenerator var3 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var2, var3);
    org.jfree.chart.urls.XYURLGenerator var8 = var4.getURLGenerator(0, 1, true);
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    var4.setBaseURLGenerator(var9, false);
    boolean var12 = var4.getPlotArea();
    org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var15);
    double var17 = var16.getGap();
    var16.setOutlineVisible(true);
    java.awt.Stroke var20 = var16.getRangeCrosshairStroke();
    org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("");
    java.awt.Font var24 = var23.getFont();
    org.jfree.chart.text.TextLine var25 = new org.jfree.chart.text.TextLine("{0}: ({1}, {2})", var24);
    var16.setNoDataMessageFont(var24);
    var4.setSeriesItemLabelFont(10, var24);
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("RectangleAnchor.CENTER", var24);
    var28.setText("null");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, (org.jfree.chart.plot.Plot)var2, false);
//     java.lang.Object var5 = var4.getTextAntiAlias();
//     java.awt.Paint var6 = var4.getBackgroundPaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var8 = var7.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.RenderingSource var12 = null;
//     var7.select(10.0d, 100.0d, var11, var12);
//     var7.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var17 = new org.jfree.chart.block.BlockContainer();
//     var16.add((org.jfree.chart.block.Block)var17);
//     org.jfree.chart.block.Arrangement var19 = var16.getArrangement();
//     org.jfree.chart.block.BorderArrangement var20 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, var19, (org.jfree.chart.block.Arrangement)var20);
//     java.awt.Paint var22 = var21.getItemPaint();
//     var4.addLegend(var21);
//     org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var25 = var24.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.RenderingSource var29 = null;
//     var24.select(10.0d, 100.0d, var28, var29);
//     var24.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var33 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var34 = new org.jfree.chart.block.BlockContainer();
//     var33.add((org.jfree.chart.block.Block)var34);
//     org.jfree.chart.block.Arrangement var36 = var33.getArrangement();
//     org.jfree.chart.block.BorderArrangement var37 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24, var36, (org.jfree.chart.block.Arrangement)var37);
//     java.awt.Paint var39 = var38.getItemPaint();
//     org.jfree.chart.util.RectangleAnchor var40 = var38.getLegendItemGraphicAnchor();
//     var21.setLegendItemGraphicAnchor(var40);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var33
//     assertTrue("Contract failed: equals-hashcode on var16 and var33", var16.equals(var33) ? var16.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var34
//     assertTrue("Contract failed: equals-hashcode on var17 and var34", var17.equals(var34) ? var17.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var16
//     assertTrue("Contract failed: equals-hashcode on var33 and var16", var33.equals(var16) ? var33.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var17
//     assertTrue("Contract failed: equals-hashcode on var34 and var17", var34.equals(var17) ? var34.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var36
//     assertTrue("Contract failed: equals-hashcode on var19 and var36", var19.equals(var36) ? var19.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var19
//     assertTrue("Contract failed: equals-hashcode on var36 and var19", var36.equals(var19) ? var36.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var37
//     assertTrue("Contract failed: equals-hashcode on var20 and var37", var20.equals(var37) ? var20.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var20
//     assertTrue("Contract failed: equals-hashcode on var37 and var20", var37.equals(var20) ? var37.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.RenderingSource var5 = null;
//     var0.select(10.0d, 100.0d, var4, var5);
//     var0.setOutlineVisible(false);
//     org.jfree.chart.labels.XYToolTipGenerator var10 = null;
//     org.jfree.chart.urls.XYURLGenerator var11 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, var10, var11);
//     org.jfree.chart.urls.XYURLGenerator var16 = var12.getURLGenerator(0, 1, true);
//     var12.setBaseSeriesVisibleInLegend(false);
//     int var19 = var0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
//     org.jfree.data.xy.XYDataset var21 = var0.getDataset(10);
//     org.jfree.chart.axis.ValueAxis var23 = var0.getRangeAxis(3);
//     org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var25 = var24.getDomainMinorGridlineStroke();
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.RenderingSource var29 = null;
//     var24.select(10.0d, 100.0d, var28, var29);
//     var24.setOutlineVisible(false);
//     org.jfree.chart.block.BlockContainer var33 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var34 = new org.jfree.chart.block.BlockContainer();
//     var33.add((org.jfree.chart.block.Block)var34);
//     org.jfree.chart.block.Arrangement var36 = var33.getArrangement();
//     org.jfree.chart.block.BorderArrangement var37 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24, var36, (org.jfree.chart.block.Arrangement)var37);
//     org.jfree.chart.plot.DatasetRenderingOrder var39 = var24.getDatasetRenderingOrder();
//     var0.setDatasetRenderingOrder(var39);
//     
//     // Checks the contract:  equals-hashcode on var0 and var24
//     assertTrue("Contract failed: equals-hashcode on var0 and var24", var0.equals(var24) ? var0.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.AxisSpace var1 = null;
    var0.setFixedDomainAxisSpace(var1, true);
    java.awt.Font var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("", var5, (org.jfree.chart.plot.Plot)var6, false);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedRangeAxisSpace(var9);
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
    java.awt.Paint var12 = var6.getDomainGridlinePaint();
    var0.setRangeTickBandPaint(var12);
    org.jfree.chart.axis.AxisSpace var14 = null;
    var0.setFixedRangeAxisSpace(var14, false);
    org.jfree.chart.annotations.XYAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var17, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

}
