
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    var0.clearRangeAxes();
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
    org.jfree.data.xy.XYDataset var5 = null;
    var0.setDataset(var5);
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var9 = var8.getAngleGridlinePaint();
    var7.setOutlinePaint(var9);
    var0.setDomainCrosshairPaint(var9);
    var0.setWeight(100);
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var15 = var14.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var14.setSimpleLabelOffset(var20);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
    var23.setWidth(20.0d);
    var23.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var22.addSubtitle((org.jfree.chart.title.Title)var23);
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    var22.setBackgroundPaint((java.awt.Paint)var32);
    int var34 = var32.getAlpha();
    var0.setRangeZeroBaselinePaint((java.awt.Paint)var32);
    java.awt.color.ColorSpace var36 = var32.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var6, 0, 0);
    org.jfree.chart.JFreeChart var10 = null;
    var9.setChart(var10);
    int var12 = var9.getPercent();
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var14 = var13.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var13.setSimpleLabelOffset(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    var22.setWidth(20.0d);
    var22.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var21.addSubtitle((org.jfree.chart.title.Title)var22);
    var9.setChart(var21);
    java.lang.String var29 = var9.toString();
    java.lang.String var30 = var9.toString();
    int var31 = var9.getType();
    var9.setPercent(0);
    var9.setType(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"+ "'", var29.equals("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"+ "'", var30.equals("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    float var3 = var0.getBackgroundImageAlpha();
    var0.clearDomainMarkers();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    java.awt.Paint var13 = null;
    java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
    java.awt.Paint[] var15 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var16 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Shape var21 = null;
    java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var15, var16, var18, var20, var22);
    java.awt.Paint var24 = var23.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    var25.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    var25.setRangeAxis((org.jfree.chart.axis.ValueAxis)var30);
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var33.setCategoryMargin(10.0d);
    java.awt.Stroke var36 = var33.getAxisLineStroke();
    var30.setTickMarkStroke(var36);
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker((-1.0d), var24, var36);
    org.jfree.chart.util.Layer var39 = null;
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var38, var39);
    org.jfree.chart.util.Layer var41 = null;
    var0.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var38, var41);
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.axis.AxisSpace var45 = var0.getFixedRangeAxisSpace();
    var0.clearDomainMarkers((-16777216));
    org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
    var0.setRenderer(var48);
    org.jfree.chart.event.RendererChangeEvent var50 = null;
    var0.rendererChanged(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.CrosshairState var32 = null;
    boolean var33 = var24.render(var28, var29, 0, var31, var32);
    java.awt.Paint var35 = var24.getQuadrantPaint(0);
    org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
    var21.setPosition(var37);
    org.jfree.chart.block.BlockContainer var39 = var21.getItemContainer();
    java.awt.Graphics2D var40 = null;
    org.jfree.data.Range var42 = null;
    org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var46 = var45.getHeightConstraintType();
    java.lang.String var47 = var46.toString();
    org.jfree.data.Range var49 = null;
    org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var53 = var52.getHeightConstraintType();
    boolean var55 = var53.equals((java.lang.Object)(byte)100);
    org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint(6.25d, var42, var46, 0.2d, var49, var53);
    org.jfree.chart.util.Size2D var57 = var39.arrange(var40, var56);
    org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement();
    var58.clear();
    var39.setArrangement((org.jfree.chart.block.Arrangement)var58);
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var63 = null;
    var61.setRangeAxis(0, var63, true);
    java.awt.Paint var66 = var61.getRangeCrosshairPaint();
    java.awt.Paint var67 = var61.getNoDataMessagePaint();
    org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var61);
    org.jfree.chart.block.BlockContainer var69 = var68.getItemContainer();
    java.util.List var70 = var69.getBlocks();
    var69.setPadding(0.037500000000000006d, 0.025d, 62.72d, 0.0d);
    java.awt.Graphics2D var76 = null;
    org.jfree.chart.block.BlockBorder var77 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.axis.CategoryAxis var79 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var79.setCategoryMargin(10.0d);
    java.awt.Stroke var82 = var79.getAxisLineStroke();
    boolean var83 = var77.equals((java.lang.Object)var79);
    org.jfree.chart.block.RectangleConstraint var86 = new org.jfree.chart.block.RectangleConstraint(4.0d, 1.0d);
    org.jfree.chart.block.LengthConstraintType var87 = var86.getWidthConstraintType();
    boolean var88 = var77.equals((java.lang.Object)var86);
    org.jfree.chart.block.LengthConstraintType var89 = var86.getHeightConstraintType();
    org.jfree.chart.util.Size2D var90 = var58.arrange(var69, var76, var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "LengthConstraintType.FIXED"+ "'", var47.equals("LengthConstraintType.FIXED"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.geom.Point2D var6 = var4.getQuadrantOrigin();
    var4.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var4.setFixedRangeAxisSpace(var9, true);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var13);
    org.jfree.data.Range var15 = var13.getDefaultAutoRange();
    double var16 = var15.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.5d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.CrosshairState var32 = null;
    boolean var33 = var24.render(var28, var29, 0, var31, var32);
    java.awt.Paint var35 = var24.getQuadrantPaint(0);
    org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
    var21.setPosition(var37);
    org.jfree.chart.block.BlockContainer var39 = var21.getItemContainer();
    java.awt.Graphics2D var40 = null;
    org.jfree.data.Range var42 = null;
    org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var46 = var45.getHeightConstraintType();
    java.lang.String var47 = var46.toString();
    org.jfree.data.Range var49 = null;
    org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var53 = var52.getHeightConstraintType();
    boolean var55 = var53.equals((java.lang.Object)(byte)100);
    org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint(6.25d, var42, var46, 0.2d, var49, var53);
    org.jfree.chart.util.Size2D var57 = var39.arrange(var40, var56);
    org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement();
    var58.clear();
    var39.setArrangement((org.jfree.chart.block.Arrangement)var58);
    org.jfree.chart.title.TextTitle var61 = new org.jfree.chart.title.TextTitle();
    var61.setURLText("");
    org.jfree.chart.util.RectangleInsets var64 = var61.getMargin();
    org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
    var65.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("");
    var65.setRangeAxis((org.jfree.chart.axis.ValueAxis)var70);
    java.awt.Shape var72 = var70.getDownArrow();
    var39.add((org.jfree.chart.block.Block)var61, (java.lang.Object)var72);
    org.jfree.chart.util.HorizontalAlignment var74 = var61.getTextAlignment();
    java.lang.String var75 = var61.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "LengthConstraintType.FIXED"+ "'", var47.equals("LengthConstraintType.FIXED"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.CrosshairState var32 = null;
    boolean var33 = var24.render(var28, var29, 0, var31, var32);
    java.awt.Paint var35 = var24.getQuadrantPaint(0);
    org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
    var21.setPosition(var37);
    org.jfree.chart.block.BlockContainer var39 = var21.getItemContainer();
    java.awt.Graphics2D var40 = null;
    org.jfree.data.Range var42 = null;
    org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var46 = var45.getHeightConstraintType();
    java.lang.String var47 = var46.toString();
    org.jfree.data.Range var49 = null;
    org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var53 = var52.getHeightConstraintType();
    boolean var55 = var53.equals((java.lang.Object)(byte)100);
    org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint(6.25d, var42, var46, 0.2d, var49, var53);
    org.jfree.chart.util.Size2D var57 = var39.arrange(var40, var56);
    org.jfree.chart.util.Size2D var60 = new org.jfree.chart.util.Size2D(0.05d, 0.0d);
    org.jfree.chart.util.Size2D var61 = var56.calculateConstrainedSize(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "LengthConstraintType.FIXED"+ "'", var47.equals("LengthConstraintType.FIXED"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }


    org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
    var0.clear();
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var4 = var3.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var3.setSimpleLabelOffset(var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    var12.setWidth(20.0d);
    var12.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var11.addSubtitle((org.jfree.chart.title.Title)var12);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    var11.setBackgroundPaint((java.awt.Paint)var21);
    var0.put((java.lang.Comparable)"org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]", (java.awt.Paint)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var1 = var0.getTextAlignment();
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 10.0d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer();
//     java.lang.String var7 = var6.getID();
//     java.lang.Object var8 = var6.clone();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.Range var11 = null;
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(0.0d, var11);
//     org.jfree.data.Range var13 = var12.getHeightRange();
//     double var14 = var12.getHeight();
//     org.jfree.chart.util.Size2D var15 = var5.arrange(var6, var9, var12);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    java.awt.Image var8 = null;
    var0.setBackgroundImage(var8);
    java.awt.Paint var11 = null;
    java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
    java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
    java.awt.Paint var22 = var21.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var31.setCategoryMargin(10.0d);
    java.awt.Stroke var34 = var31.getAxisLineStroke();
    var28.setTickMarkStroke(var34);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker((-1.0d), var22, var34);
    var0.setDomainZeroBaselineStroke(var34);
    org.jfree.chart.axis.AxisLocation var38 = var0.getRangeAxisLocation();
    java.lang.String var39 = var0.getPlotType();
    float var40 = var0.getBackgroundAlpha();
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    var0.setRenderer(var41);
    org.jfree.chart.annotations.XYAnnotation var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "XY Plot"+ "'", var39.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0f);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var12.getAutoRangeStickyZero();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setFixedAutoRange(20.0d);
    boolean var19 = var12.getAutoRangeStickyZero();
    boolean var20 = var12.isAutoRange();
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var23 = var21.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var25 = null;
    var21.setRangeAxis(10, var25);
    int var27 = var21.getWeight();
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
    int var30 = var21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
    var29.setInverted(false);
    double var33 = var29.getFixedAutoRange();
    var29.zoomRange(0.025d, 0.05d);
    org.jfree.data.Range var37 = var29.getRange();
    var12.setRangeWithMargins(var37);
    java.lang.String var39 = var37.toString();
    double var40 = var37.getCentralValue();
    boolean var43 = var37.intersects(0.0d, (-1.0d));
    org.jfree.data.Range var45 = org.jfree.data.Range.shift(var37, (-5.88d));
    org.jfree.data.Range var47 = org.jfree.data.Range.shift(var45, 1.5125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "Range[0.025,0.05]"+ "'", var39.equals("Range[0.025,0.05]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.037500000000000006d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    int var6 = var0.getWeight();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    int var9 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    var8.setInverted(false);
    double var12 = var8.getFixedAutoRange();
    var8.setPositiveArrowVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var12.getAutoRangeStickyZero();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var21 = null;
    var17.setRangeAxis(10, var21);
    java.awt.Stroke var23 = null;
    var17.setOutlineStroke(var23);
    org.jfree.data.xy.XYDataset var25 = null;
    int var26 = var17.indexOf(var25);
    java.awt.Graphics2D var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    java.util.List var29 = null;
    var17.drawDomainTickBands(var27, var28, var29);
    java.awt.Color var35 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var37.setCategoryMargin(10.0d);
    java.awt.Stroke var40 = var37.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var35, var40);
    java.awt.Stroke var42 = var41.getStroke();
    var17.addDomainMarker((org.jfree.chart.plot.Marker)var41);
    double var44 = var41.getValue();
    org.jfree.chart.util.Layer var45 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var41, var45);
    org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var49 = var48.getAngleGridlinePaint();
    java.awt.Font var50 = var48.getAngleLabelFont();
    org.jfree.chart.util.RectangleInsets var51 = var48.getInsets();
    org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot();
    var53.setLabelLinkMargin(0.0d);
    var53.setLabelLinkMargin(20.0d);
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var60 = var58.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var62 = null;
    var58.setRangeAxis(10, var62);
    java.awt.Stroke var64 = null;
    var58.setOutlineStroke(var64);
    org.jfree.chart.renderer.xy.XYItemRenderer var67 = null;
    var58.setRenderer(1, var67);
    org.jfree.chart.util.HorizontalAlignment var69 = null;
    org.jfree.chart.util.VerticalAlignment var70 = null;
    org.jfree.chart.block.FlowArrangement var73 = new org.jfree.chart.block.FlowArrangement(var69, var70, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var74 = null;
    org.jfree.chart.util.VerticalAlignment var75 = null;
    org.jfree.chart.block.ColumnArrangement var78 = new org.jfree.chart.block.ColumnArrangement(var74, var75, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var79 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58, (org.jfree.chart.block.Arrangement)var73, (org.jfree.chart.block.Arrangement)var78);
    boolean var81 = var79.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var82 = new org.jfree.chart.plot.PiePlot();
    double var83 = var82.getShadowYOffset();
    double var84 = var82.getShadowYOffset();
    java.awt.Font var85 = var82.getLabelFont();
    var79.setItemFont(var85);
    var53.setLabelFont(var85);
    java.awt.Color var91 = java.awt.Color.getHSBColor(1.0f, 1.0f, 10.0f);
    org.jfree.chart.text.TextLine var92 = new org.jfree.chart.text.TextLine("Multiple Pie Plot", var85, (java.awt.Paint)var91);
    var48.setAngleLabelFont(var85);
    org.jfree.chart.text.TextLine var94 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.NONE: width=4.0, height=1.0]", var85);
    org.jfree.chart.text.TextFragment var95 = var94.getFirstTextFragment();
    java.awt.Font var96 = var95.getFont();
    var41.setLabelFont(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 20.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     int var2 = var1.getSeriesCount();
//     var1.addCornerTextItem("RectangleConstraint[LengthConstraintType.FIXED: width=4.0, height=1.0]");
//     var1.addCornerTextItem("ThreadContext");
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     java.awt.geom.Point2D var13 = var12.getQuadrantOrigin();
//     java.awt.geom.Point2D var14 = var12.getQuadrantOrigin();
//     var12.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var12.setFixedRangeAxisSpace(var17, true);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setDomainAxis((org.jfree.chart.axis.ValueAxis)var21);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var21, var23, var24);
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var27 = var26.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var32 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var26.setSimpleLabelOffset(var32);
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle();
//     var35.setWidth(20.0d);
//     var35.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var34.addSubtitle((org.jfree.chart.title.Title)var35);
//     java.awt.Color var44 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
//     var34.setBackgroundPaint((java.awt.Paint)var44);
//     var25.setOutlinePaint((java.awt.Paint)var44);
//     int var47 = var44.getGreen();
//     var1.setRadiusGridlinePaint((java.awt.Paint)var44);
//     int var49 = var44.getTransparency();
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var50, var51, var52, var53);
//     java.awt.geom.Point2D var55 = var54.getQuadrantOrigin();
//     java.awt.geom.Point2D var56 = var54.getQuadrantOrigin();
//     var54.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var59 = null;
//     var54.setFixedRangeAxisSpace(var59, true);
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("");
//     var54.setDomainAxis((org.jfree.chart.axis.ValueAxis)var63);
//     float var65 = var54.getBackgroundImageAlpha();
//     org.jfree.chart.util.RectangleEdge var66 = var54.getDomainAxisEdge();
//     java.awt.Stroke var67 = var54.getRangeCrosshairStroke();
//     org.jfree.chart.plot.ValueMarker var68 = new org.jfree.chart.plot.ValueMarker(7.0d, (java.awt.Paint)var44, var67);
//     
//     // Checks the contract:  equals-hashcode on var12 and var54
//     assertTrue("Contract failed: equals-hashcode on var12 and var54", var12.equals(var54) ? var12.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var12
//     assertTrue("Contract failed: equals-hashcode on var54 and var12", var54.equals(var12) ? var54.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    java.awt.Stroke var22 = var13.getBorderStroke();
    var13.setNotify(false);
    var13.setTextAntiAlias(true);
    var13.setTitle("ChartEntity: tooltip = null");
    var13.setBackgroundImageAlignment((-524308));
    var13.setBorderVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     var0.setRangeAxis(0, var2, true);
//     org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var9.setLicenceName("hi!");
//     boolean var12 = var0.equals((java.lang.Object)"hi!");
//     boolean var13 = var0.getDrawSharedDomainAxis();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var16 = var14.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     var14.setRangeAxis(10, var18);
//     java.awt.Stroke var20 = null;
//     var14.setOutlineStroke(var20);
//     org.jfree.data.xy.XYDataset var22 = null;
//     int var23 = var14.indexOf(var22);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     java.util.List var26 = null;
//     var14.drawDomainTickBands(var24, var25, var26);
//     org.jfree.chart.plot.DatasetRenderingOrder var28 = var14.getDatasetRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var29 = var14.getDomainAxisLocation();
//     var0.setRangeAxisLocation(var29, false);
//     var0.setRangeCrosshairValue(20.0d, false);
//     org.jfree.chart.plot.Marker var35 = null;
//     boolean var36 = var0.removeDomainMarker(var35);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    java.awt.geom.Point2D var12 = var10.getQuadrantOrigin();
    var0.zoomDomainAxes(4.0d, var5, var12);
    int var14 = var0.getWeight();
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var0.getDomainMarkers(2, var16);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var0.getDomainMarkers(1, var19);
    var0.setAnchorValue(4.0d);
    org.jfree.chart.util.Layer var24 = null;
    java.util.Collection var25 = var0.getDomainMarkers(2, var24);
    org.jfree.chart.util.SortOrder var26 = var0.getRowRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    var9.setLicenceName("hi!");
    boolean var12 = var0.equals((java.lang.Object)"hi!");
    org.jfree.data.category.CategoryDataset var14 = null;
    var0.setDataset(10, var14);
    java.awt.Paint var16 = var0.getRangeCrosshairPaint();
    boolean var17 = var0.getDrawSharedDomainAxis();
    java.awt.Stroke var18 = var0.getDomainGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.util.RectangleInsets var24 = var21.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleInsets var25 = var21.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var26 = var21.getLegendItemGraphicAnchor();
    org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot();
    double var29 = var27.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var27.markerChanged(var30);
    float var32 = var27.getBackgroundImageAlpha();
    double var33 = var27.getLabelLinkMargin();
    java.awt.Graphics2D var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot();
    double var38 = var36.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    var40.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
    var40.setRangeAxis((org.jfree.chart.axis.ValueAxis)var45);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var48.setCategoryMargin(10.0d);
    java.awt.Stroke var51 = var48.getAxisLineStroke();
    var45.setTickMarkStroke(var51);
    var36.setSectionOutlineStroke((java.lang.Comparable)1L, var51);
    org.jfree.chart.plot.AbstractPieLabelDistributor var54 = var36.getLabelDistributor();
    org.jfree.chart.plot.PlotRenderingInfo var56 = null;
    org.jfree.chart.plot.PiePlotState var57 = var27.initialise(var34, var35, (org.jfree.chart.plot.PiePlot)var36, (java.lang.Integer)10, var56);
    boolean var58 = var26.equals((java.lang.Object)var57);
    var57.setLatestAngle(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     var0.clearRangeAxes();
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
//     java.awt.Stroke var5 = var0.getDomainCrosshairStroke();
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     int var12 = var6.getWeight();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     int var15 = var6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var14);
//     boolean var16 = var6.isSubplot();
//     java.awt.Paint var18 = null;
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
//     java.awt.Paint[] var20 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Stroke var24 = null;
//     java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
//     java.awt.Shape var26 = null;
//     java.awt.Shape[] var27 = new java.awt.Shape[] { var26};
//     org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier(var19, var20, var21, var23, var25, var27);
//     java.awt.Paint var29 = var28.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setRangeAxis((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var38.setCategoryMargin(10.0d);
//     java.awt.Stroke var41 = var38.getAxisLineStroke();
//     var35.setTickMarkStroke(var41);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker((-1.0d), var29, var41);
//     java.awt.Paint var44 = var43.getLabelPaint();
//     org.jfree.chart.util.RectangleAnchor var45 = var43.getLabelAnchor();
//     var6.addDomainMarker((org.jfree.chart.plot.Marker)var43);
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot();
//     double var48 = var47.getShadowYOffset();
//     double var49 = var47.getShadowYOffset();
//     java.awt.Font var50 = var47.getLabelFont();
//     var43.setLabelFont(var50);
//     double var52 = var43.getValue();
//     org.jfree.chart.util.Layer var53 = null;
//     boolean var54 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var43, var53);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getShadowYOffset();
    double var2 = var0.getShadowYOffset();
    java.awt.Font var3 = var0.getLabelFont();
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var0.setLegendLabelURLGenerator(var4);
    boolean var6 = var0.getLabelLinksVisible();
    org.jfree.chart.labels.PieToolTipGenerator var7 = null;
    var0.setToolTipGenerator(var7);
    org.jfree.chart.util.Rotation var9 = var0.getDirection();
    boolean var10 = var0.getLabelLinksVisible();
    org.jfree.data.general.PieDataset var11 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     var0.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Paint var7 = var6.getLabelLinkPaint();
//     var0.setDomainTickBandPaint(var7);
//     java.awt.Paint var9 = var0.getDomainZeroBaselinePaint();
//     java.awt.Color var15 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var17.setCategoryMargin(10.0d);
//     java.awt.Stroke var20 = var17.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var15, var20);
//     float var22 = var21.getAlpha();
//     float var23 = var21.getAlpha();
//     org.jfree.chart.util.Layer var24 = null;
//     var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var21, var24);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var27.setCategoryMargin(10.0d);
//     java.awt.Stroke var30 = var27.getAxisLineStroke();
//     var27.configure();
//     var27.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var34 = var27.getLabelInsets();
//     boolean var35 = var27.isAxisLineVisible();
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var38 = var36.getDomainAxis((-1));
//     boolean var39 = var36.isRangeGridlinesVisible();
//     var36.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.RingPlot var42 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Paint var43 = var42.getLabelLinkPaint();
//     var36.setDomainTickBandPaint(var43);
//     java.awt.Paint var45 = var36.getDomainZeroBaselinePaint();
//     var27.addChangeListener((org.jfree.chart.event.AxisChangeListener)var36);
//     java.util.List var47 = var36.getAnnotations();
//     org.jfree.chart.plot.PiePlot var48 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var49 = var48.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var54 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var48.setSimpleLabelOffset(var54);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var48);
//     org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle();
//     var57.setWidth(20.0d);
//     var57.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var56.addSubtitle((org.jfree.chart.title.Title)var57);
//     var57.setToolTipText("");
//     java.lang.String var65 = var57.getToolTipText();
//     java.awt.Paint var66 = var57.getPaint();
//     var36.setRangeTickBandPaint(var66);
//     var0.setRangeTickBandPaint(var66);
//     
//     // Checks the contract:  equals-hashcode on var0 and var36
//     assertTrue("Contract failed: equals-hashcode on var0 and var36", var0.equals(var36) ? var0.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var0
//     assertTrue("Contract failed: equals-hashcode on var36 and var0", var36.equals(var0) ? var36.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.configure();
    var1.setLowerMargin(1.0d);
    int var8 = var1.getMaximumCategoryLabelLines();
    var1.removeCategoryLabelToolTip((java.lang.Comparable)0L);
    var1.setTickMarksVisible(false);
    var1.setCategoryLabelPositionOffset(10);
    org.jfree.chart.util.RectangleInsets var15 = var1.getLabelInsets();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var18.setCategoryMargin(10.0d);
    java.awt.Stroke var21 = var18.getAxisLineStroke();
    boolean var22 = var16.equals((java.lang.Object)var18);
    java.awt.Paint var23 = var18.getAxisLinePaint();
    org.jfree.chart.axis.CategoryLabelPositions var24 = var18.getCategoryLabelPositions();
    var1.setCategoryLabelPositions(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(20.0d);
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot();
    double var5 = var3.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var15.setCategoryMargin(10.0d);
    java.awt.Stroke var18 = var15.getAxisLineStroke();
    var12.setTickMarkStroke(var18);
    var3.setSectionOutlineStroke((java.lang.Comparable)1L, var18);
    org.jfree.chart.plot.AbstractPieLabelDistributor var21 = var3.getLabelDistributor();
    double var22 = var3.getShadowXOffset();
    java.awt.Paint var23 = var3.getLabelPaint();
    java.awt.Paint var24 = var3.getSeparatorPaint();
    java.awt.Paint var25 = var3.getBaseSectionOutlinePaint();
    boolean var26 = var0.equals((java.lang.Object)var3);
    double var27 = var3.getOuterSeparatorExtension();
    java.lang.Object var28 = var3.clone();
    double var29 = var3.getInnerSeparatorExtension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.2d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var1 = var0.getAngleGridlinePaint();
    java.awt.Font var2 = var0.getAngleLabelFont();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    java.lang.String var4 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Polar Plot"+ "'", var4.equals("Polar Plot"));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var24 = null;
    var22.setRangeAxis(0, var24, true);
    java.awt.Paint var27 = var22.getRangeCrosshairPaint();
    java.awt.Paint var28 = var22.getNoDataMessagePaint();
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    var21.setLegendItemGraphicLocation(var30);
    java.lang.Object var32 = var21.clone();
    org.jfree.chart.util.RectangleInsets var33 = var21.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleInsets var34 = var21.getLegendItemGraphicPadding();
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
    var36.setRenderer(0, var38);
    var36.configureDomainAxes();
    java.awt.Color var45 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var47.setCategoryMargin(10.0d);
    java.awt.Stroke var50 = var47.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var45, var50);
    float var52 = var51.getAlpha();
    float var53 = var51.getAlpha();
    org.jfree.chart.util.Layer var54 = null;
    var36.addRangeMarker((org.jfree.chart.plot.Marker)var51, var54);
    org.jfree.chart.util.LengthAdjustmentType var56 = var51.getLabelOffsetType();
    org.jfree.chart.util.LengthAdjustmentType var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var58 = var34.createAdjustedRectangle(var35, var56, var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    java.awt.Graphics2D var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.plot.CrosshairState var26 = null;
    boolean var27 = var0.render(var22, var23, 10, var25, var26);
    org.jfree.chart.axis.AxisLocation var28 = var0.getRangeAxisLocation();
    var0.mapDatasetToRangeAxis(10, 10);
    org.jfree.chart.ui.BasicProjectInfo var36 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    var37.setRenderer(0, var39);
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
    java.awt.geom.Point2D var48 = var47.getQuadrantOrigin();
    var37.zoomRangeAxes((-1.0d), var42, var48, false);
    boolean var51 = var36.equals((java.lang.Object)var37);
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    var37.setRenderer(var52, false);
    org.jfree.chart.axis.AxisLocation var56 = var37.getDomainAxisLocation(4);
    var0.setDomainAxisLocation(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    float var9 = var8.getBackgroundImageAlpha();
    int var10 = var8.getBackgroundImageAlignment();
    org.jfree.chart.event.ChartProgressListener var11 = null;
    var8.addProgressListener(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 15);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     var4.setRangeAxis(10, var8);
//     java.awt.Stroke var10 = null;
//     var4.setOutlineStroke(var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     int var13 = var4.indexOf(var12);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     java.util.List var16 = null;
//     var4.drawDomainTickBands(var14, var15, var16);
//     java.awt.Color var22 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var24.setCategoryMargin(10.0d);
//     java.awt.Stroke var27 = var24.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var22, var27);
//     java.awt.Stroke var29 = var28.getStroke();
//     var4.addDomainMarker((org.jfree.chart.plot.Marker)var28);
//     org.jfree.chart.text.TextAnchor var31 = var28.getLabelTextAnchor();
//     java.awt.geom.Rectangle2D var32 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 2.0f, 2.0f, var31);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var6, 0, 0);
    org.jfree.chart.JFreeChart var10 = null;
    var9.setChart(var10);
    int var12 = var9.getPercent();
    java.lang.Object var13 = var9.getSource();
    var9.setPercent(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var8.setCategoryMargin(10.0d);
    java.awt.Stroke var11 = var8.getAxisLineStroke();
    var5.setTickMarkStroke(var11);
    double var13 = var5.getLowerMargin();
    org.jfree.data.RangeType var14 = var5.getRangeType();
    java.lang.Object var15 = var5.clone();
    boolean var16 = var5.getAutoRangeIncludesZero();
    boolean var17 = var5.isVerticalTickLabels();
    var5.setFixedAutoRange(98.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var4.setRangeGridlinesVisible(true);
    java.awt.Paint var9 = null;
    java.awt.Paint[] var10 = new java.awt.Paint[] { var9};
    java.awt.Paint[] var11 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var12 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var11, var12, var14, var16, var18);
    java.awt.Paint var20 = var19.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    var21.setRangeAxis((org.jfree.chart.axis.ValueAxis)var26);
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var29.setCategoryMargin(10.0d);
    java.awt.Stroke var32 = var29.getAxisLineStroke();
    var26.setTickMarkStroke(var32);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker((-1.0d), var20, var32);
    var4.setDomainGridlineStroke(var32);
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
    java.awt.Color var44 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    java.awt.image.ColorModel var45 = null;
    java.awt.Rectangle var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    java.awt.geom.AffineTransform var48 = null;
    java.awt.RenderingHints var49 = null;
    java.awt.PaintContext var50 = var44.createContext(var45, var46, var47, var48, var49);
    java.awt.Color var51 = var44.brighter();
    var40.setOutlinePaint((java.awt.Paint)var44);
    var4.setRangeZeroBaselinePaint((java.awt.Paint)var44);
    int var54 = var44.getRed();
    org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.util.TimeZone var1 = var0.getTimeZone();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    java.util.TimeZone var3 = var2.getTimeZone();
    var0.setTimeZone(var3);
    org.jfree.chart.axis.Timeline var5 = null;
    var0.setTimeline(var5);
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(4.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var10 = var9.toUnconstrainedWidth();
    double var11 = var9.getHeight();
    org.jfree.chart.block.RectangleConstraint var12 = var9.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var14 = var9.toFixedHeight(0.2d);
    org.jfree.chart.block.RectangleConstraint var15 = var9.toUnconstrainedHeight();
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var18 = var16.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var20 = null;
    var16.setRangeAxis(10, var20);
    int var22 = var16.getWeight();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    int var25 = var16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var24);
    var24.setInverted(false);
    double var28 = var24.getFixedAutoRange();
    var24.zoomRange(0.025d, 0.05d);
    org.jfree.data.Range var32 = var24.getRange();
    org.jfree.data.Range var35 = org.jfree.data.Range.shift(var32, 2.0d, false);
    org.jfree.chart.block.RectangleConstraint var36 = var15.toRangeHeight(var32);
    org.jfree.data.Range var38 = org.jfree.data.Range.shift(var32, 1.0d);
    java.lang.String var39 = var32.toString();
    var0.setRange(var32);
    java.awt.Paint var41 = var0.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "Range[0.025,0.05]"+ "'", var39.equals("Range[0.025,0.05]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    var0.setMaximumLabelWidth((-11.0d));
    double var5 = var0.getInnerSeparatorExtension();
    java.awt.Stroke var6 = var0.getSeparatorStroke();
    var0.setLabelGap(4.0d);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    var10.setWidth(20.0d);
    java.lang.Object var13 = var10.clone();
    boolean var14 = var10.getExpandToFitSpace();
    double var15 = var10.getHeight();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
    var18.setLabelLinkMargin(0.0d);
    var18.setLabelLinkMargin(20.0d);
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var25 = var23.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var27 = null;
    var23.setRangeAxis(10, var27);
    java.awt.Stroke var29 = null;
    var23.setOutlineStroke(var29);
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    var23.setRenderer(1, var32);
    org.jfree.chart.util.HorizontalAlignment var34 = null;
    org.jfree.chart.util.VerticalAlignment var35 = null;
    org.jfree.chart.block.FlowArrangement var38 = new org.jfree.chart.block.FlowArrangement(var34, var35, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var39 = null;
    org.jfree.chart.util.VerticalAlignment var40 = null;
    org.jfree.chart.block.ColumnArrangement var43 = new org.jfree.chart.block.ColumnArrangement(var39, var40, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23, (org.jfree.chart.block.Arrangement)var38, (org.jfree.chart.block.Arrangement)var43);
    boolean var46 = var44.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot();
    double var48 = var47.getShadowYOffset();
    double var49 = var47.getShadowYOffset();
    java.awt.Font var50 = var47.getLabelFont();
    var44.setItemFont(var50);
    var18.setLabelFont(var50);
    java.awt.Color var56 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var58 = null;
    var57.setDataset(var58);
    boolean var60 = var56.equals((java.lang.Object)var57);
    org.jfree.chart.text.TextBlock var61 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var50, (java.awt.Paint)var56);
    org.jfree.chart.text.TextLine var62 = var61.getLastLine();
    java.util.List var63 = var61.getLines();
    org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var65 = var64.getTextAlignment();
    java.lang.Object var66 = var64.clone();
    boolean var67 = var61.equals((java.lang.Object)var64);
    double var68 = var64.getContentXOffset();
    java.awt.geom.Rectangle2D var69 = var64.getBounds();
    java.lang.Object var70 = null;
    java.lang.Object var71 = var10.draw(var16, var69, var70);
    org.jfree.chart.plot.RingPlot var72 = new org.jfree.chart.plot.RingPlot();
    double var74 = var72.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var75 = null;
    var72.markerChanged(var75);
    float var77 = var72.getBackgroundImageAlpha();
    boolean var78 = var72.getIgnoreNullValues();
    var72.setLabelLinkMargin(8.0d);
    org.jfree.chart.util.ObjectList var81 = new org.jfree.chart.util.ObjectList();
    var81.set(255, (java.lang.Object)'4');
    int var85 = var81.size();
    java.lang.Object var86 = var81.clone();
    boolean var87 = var72.equals((java.lang.Object)var81);
    org.jfree.chart.plot.PlotRenderingInfo var89 = null;
    org.jfree.chart.plot.PiePlotState var90 = var0.initialise(var9, var69, (org.jfree.chart.plot.PiePlot)var72, (java.lang.Integer)(-10223606), var89);
    java.awt.Font var91 = var0.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 256);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    int var6 = var5.getAlpha();
    var1.setAggregatedItemsPaint((java.awt.Paint)var5);
    org.jfree.chart.util.TableOrder var8 = var1.getDataExtractOrder();
    org.jfree.chart.ui.Licences var9 = org.jfree.chart.ui.Licences.getInstance();
    boolean var10 = var1.equals((java.lang.Object)var9);
    java.awt.Paint var11 = var1.getAggregatedItemsPaint();
    var1.zoom(0.037500000000000006d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var8.setCategoryMargin(10.0d);
    java.awt.Stroke var11 = var8.getAxisLineStroke();
    var5.setTickMarkStroke(var11);
    double var13 = var5.getLowerMargin();
    var5.setVisible(false);
    java.awt.Paint var16 = null;
    java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
    java.awt.Paint[] var18 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var19 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var20 = null;
    java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
    java.awt.Stroke var22 = null;
    java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
    java.awt.Shape var24 = null;
    java.awt.Shape[] var25 = new java.awt.Shape[] { var24};
    org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var18, var19, var21, var23, var25);
    java.awt.Shape var27 = var26.getNextShape();
    java.awt.Paint var28 = var26.getNextPaint();
    java.awt.Paint var29 = var26.getNextFillPaint();
    boolean var30 = var5.equals((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(0, var4, false);
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxisForDataset(10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setRangeAxis((org.jfree.chart.axis.ValueAxis)var14);
//     boolean var16 = var14.getAutoRangeStickyZero();
//     var14.setUpperMargin(0.0d);
//     int var19 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var14);
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot();
//     double var22 = var20.getExplodePercent((java.lang.Comparable)10L);
//     org.jfree.chart.event.MarkerChangeEvent var23 = null;
//     var20.markerChanged(var23);
//     float var25 = var20.getBackgroundImageAlpha();
//     boolean var26 = var20.getIgnoreNullValues();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var29 = var27.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     var27.setRangeAxis(10, var31);
//     int var33 = var27.getWeight();
//     var20.setParent((org.jfree.chart.plot.Plot)var27);
//     boolean var35 = var0.equals((java.lang.Object)var27);
//     java.awt.Stroke var36 = var27.getRangeCrosshairStroke();
//     var27.setRangeCrosshairValue(10.00000001d);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var40 = null;
//     var39.setDataset(var40);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.data.Range var43 = var39.getDataRange(var42);
//     java.lang.String var44 = var39.getPlotType();
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var45, var46, var47, var48);
//     java.awt.geom.Point2D var50 = var49.getQuadrantOrigin();
//     java.awt.geom.Point2D var51 = var49.getQuadrantOrigin();
//     var49.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var54 = null;
//     var49.setFixedRangeAxisSpace(var54, true);
//     java.awt.Paint var58 = null;
//     java.awt.Paint[] var59 = new java.awt.Paint[] { var58};
//     java.awt.Paint[] var60 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var61 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var62 = null;
//     java.awt.Stroke[] var63 = new java.awt.Stroke[] { var62};
//     java.awt.Stroke var64 = null;
//     java.awt.Stroke[] var65 = new java.awt.Stroke[] { var64};
//     java.awt.Shape var66 = null;
//     java.awt.Shape[] var67 = new java.awt.Shape[] { var66};
//     org.jfree.chart.plot.DefaultDrawingSupplier var68 = new org.jfree.chart.plot.DefaultDrawingSupplier(var59, var60, var61, var63, var65, var67);
//     java.awt.Paint var69 = var68.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
//     var70.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis("");
//     var70.setRangeAxis((org.jfree.chart.axis.ValueAxis)var75);
//     org.jfree.chart.axis.CategoryAxis var78 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var78.setCategoryMargin(10.0d);
//     java.awt.Stroke var81 = var78.getAxisLineStroke();
//     var75.setTickMarkStroke(var81);
//     org.jfree.chart.plot.ValueMarker var83 = new org.jfree.chart.plot.ValueMarker((-1.0d), var69, var81);
//     org.jfree.chart.util.Layer var84 = null;
//     var49.addRangeMarker((org.jfree.chart.plot.Marker)var83, var84);
//     org.jfree.chart.util.Layer var86 = null;
//     var39.addRangeMarker((org.jfree.chart.plot.Marker)var83, var86);
//     org.jfree.chart.event.MarkerChangeEvent var88 = null;
//     var83.notifyListeners(var88);
//     var83.setLabel("Range[-11.0,0.05]");
//     java.awt.Paint var92 = var83.getOutlinePaint();
//     var27.setDomainCrosshairPaint(var92);
//     
//     // Checks the contract:  equals-hashcode on var0 and var39
//     assertTrue("Contract failed: equals-hashcode on var0 and var39", var0.equals(var39) ? var0.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var0
//     assertTrue("Contract failed: equals-hashcode on var39 and var0", var39.equals(var0) ? var39.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var3 = var0.getRootPlot();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    org.jfree.chart.plot.CrosshairState var8 = null;
    boolean var9 = var0.render(var4, var5, 0, var7, var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.util.List var12 = null;
    var0.drawDomainTickBands(var10, var11, var12);
    org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var15);
    java.awt.Paint var17 = var15.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.CrosshairState var32 = null;
    boolean var33 = var24.render(var28, var29, 0, var31, var32);
    java.awt.Paint var35 = var24.getQuadrantPaint(0);
    org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
    var21.setPosition(var37);
    org.jfree.chart.block.BlockContainer var39 = var21.getItemContainer();
    java.awt.Graphics2D var40 = null;
    org.jfree.data.Range var42 = null;
    org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var46 = var45.getHeightConstraintType();
    java.lang.String var47 = var46.toString();
    org.jfree.data.Range var49 = null;
    org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var53 = var52.getHeightConstraintType();
    boolean var55 = var53.equals((java.lang.Object)(byte)100);
    org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint(6.25d, var42, var46, 0.2d, var49, var53);
    org.jfree.chart.util.Size2D var57 = var39.arrange(var40, var56);
    org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement();
    var58.clear();
    var39.setArrangement((org.jfree.chart.block.Arrangement)var58);
    var39.setWidth(0.0d);
    var39.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "LengthConstraintType.FIXED"+ "'", var47.equals("LengthConstraintType.FIXED"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    java.awt.Paint var5 = var0.getRangeCrosshairPaint();
    java.awt.Paint var6 = var0.getNoDataMessagePaint();
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.block.BlockContainer var8 = var7.getItemContainer();
    java.util.List var9 = var8.getBlocks();
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    var10.clearAnnotations();
    org.jfree.chart.event.PlotChangeEvent var12 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.event.ChartChangeEventType var13 = null;
    var12.setType(var13);
    org.jfree.chart.JFreeChart var15 = var12.getChart();
    org.jfree.chart.JFreeChart var16 = var12.getChart();
    java.lang.String var17 = var12.toString();
    boolean var18 = var8.equals((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
    var4.setVersion("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]");
    var4.setName("hi!");
    org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement();
    boolean var10 = var4.equals((java.lang.Object)var9);
    var9.clear();
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    var13.setLabelLinkMargin(0.0d);
    var13.setLabelLinkMargin(20.0d);
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var20 = var18.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var22 = null;
    var18.setRangeAxis(10, var22);
    java.awt.Stroke var24 = null;
    var18.setOutlineStroke(var24);
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    var18.setRenderer(1, var27);
    org.jfree.chart.util.HorizontalAlignment var29 = null;
    org.jfree.chart.util.VerticalAlignment var30 = null;
    org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement(var29, var30, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var34 = null;
    org.jfree.chart.util.VerticalAlignment var35 = null;
    org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var34, var35, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var38);
    boolean var41 = var39.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot();
    double var43 = var42.getShadowYOffset();
    double var44 = var42.getShadowYOffset();
    java.awt.Font var45 = var42.getLabelFont();
    var39.setItemFont(var45);
    var13.setLabelFont(var45);
    java.awt.Color var51 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var53 = null;
    var52.setDataset(var53);
    boolean var55 = var51.equals((java.lang.Object)var52);
    org.jfree.chart.text.TextBlock var56 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var45, (java.awt.Paint)var51);
    org.jfree.chart.text.TextLine var57 = var56.getLastLine();
    java.util.List var58 = var56.getLines();
    org.jfree.chart.text.TextLine var59 = var56.getLastLine();
    org.jfree.chart.text.TextLine var60 = var56.getLastLine();
    org.jfree.chart.text.TextLine var61 = var56.getLastLine();
    java.util.List var62 = var56.getLines();
    boolean var63 = var9.equals((java.lang.Object)var56);
    var9.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryMargin(10.0d);
//     java.awt.Stroke var5 = var2.getAxisLineStroke();
//     var2.configure();
//     var2.setLowerMargin(1.0d);
//     boolean var9 = var2.isAxisLineVisible();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     boolean var17 = var15.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var20 = var18.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     var18.setRangeAxis(10, var22);
//     var15.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var15, var25);
//     org.jfree.data.general.DatasetChangeEvent var27 = null;
//     var26.datasetChanged(var27);
//     float var29 = var26.getBackgroundImageAlpha();
//     java.awt.Paint var31 = null;
//     java.awt.Paint[] var32 = new java.awt.Paint[] { var31};
//     java.awt.Paint[] var33 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var34 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var35 = null;
//     java.awt.Stroke[] var36 = new java.awt.Stroke[] { var35};
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Shape var39 = null;
//     java.awt.Shape[] var40 = new java.awt.Shape[] { var39};
//     org.jfree.chart.plot.DefaultDrawingSupplier var41 = new org.jfree.chart.plot.DefaultDrawingSupplier(var32, var33, var34, var36, var38, var40);
//     java.awt.Paint var42 = var41.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     var43.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var43.setRangeAxis((org.jfree.chart.axis.ValueAxis)var48);
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var51.setCategoryMargin(10.0d);
//     java.awt.Stroke var54 = var51.getAxisLineStroke();
//     var48.setTickMarkStroke(var54);
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker((-1.0d), var42, var54);
//     java.awt.Paint var57 = var56.getLabelPaint();
//     boolean var58 = var26.removeDomainMarker((org.jfree.chart.plot.Marker)var56);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.geom.Point2D var6 = var4.getQuadrantOrigin();
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var4.setRenderer(10, var8);
    org.jfree.chart.util.Layer var11 = null;
    java.util.Collection var12 = var4.getDomainMarkers(1, var11);
    org.jfree.chart.plot.Plot var13 = var4.getParent();
    boolean var14 = var4.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.Paint var7 = null;
    java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
    java.awt.Paint[] var9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var11 = null;
    java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Shape var15 = null;
    java.awt.Shape[] var16 = new java.awt.Shape[] { var15};
    org.jfree.chart.plot.DefaultDrawingSupplier var17 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var9, var10, var12, var14, var16);
    java.awt.Paint var18 = var17.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    var19.setRangeAxis((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var27.setCategoryMargin(10.0d);
    java.awt.Stroke var30 = var27.getAxisLineStroke();
    var24.setTickMarkStroke(var30);
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker((-1.0d), var18, var30);
    org.jfree.chart.util.Layer var33 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var32, var33);
    var4.configureDomainAxes();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var38, true);
    var4.setDomainGridlinesVisible(true);
    org.jfree.chart.util.RectangleEdge var44 = var4.getDomainAxisEdge(255);
    org.jfree.chart.axis.AxisLocation var45 = var4.getDomainAxisLocation();
    java.lang.Object var46 = var4.clone();
    int var47 = var4.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var0.getLabelGenerator();
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot();
    double var12 = var10.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
    var14.setRangeAxis((org.jfree.chart.axis.ValueAxis)var19);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var22.setCategoryMargin(10.0d);
    java.awt.Stroke var25 = var22.getAxisLineStroke();
    var19.setTickMarkStroke(var25);
    var10.setSectionOutlineStroke((java.lang.Comparable)1L, var25);
    var0.setLabelOutlineStroke(var25);
    double var29 = var0.getMaximumLabelWidth();
    java.awt.Color var35 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var37.setCategoryMargin(10.0d);
    java.awt.Stroke var40 = var37.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var35, var40);
    int var42 = var35.getRed();
    int var43 = var35.getBlue();
    var0.setSectionOutlinePaint((java.lang.Comparable)(-65536), (java.awt.Paint)var35);
    java.awt.Stroke var45 = var0.getLabelLinkStroke();
    org.jfree.chart.event.PlotChangeEvent var46 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    java.lang.String var47 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "Pie Plot"+ "'", var47.equals("Pie Plot"));

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.data.general.DatasetGroup var3 = var0.getDatasetGroup();
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(1, var5);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getDomainMarkers(var7);
    int var9 = var0.getDomainAxisCount();
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot();
    double var12 = var10.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
    var14.setRangeAxis((org.jfree.chart.axis.ValueAxis)var19);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var22.setCategoryMargin(10.0d);
    java.awt.Stroke var25 = var22.getAxisLineStroke();
    var19.setTickMarkStroke(var25);
    var10.setSectionOutlineStroke((java.lang.Comparable)1L, var25);
    org.jfree.chart.plot.AbstractPieLabelDistributor var28 = var10.getLabelDistributor();
    int var29 = var28.getItemCount();
    boolean var30 = var0.equals((java.lang.Object)var29);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var0.getDomainMarkers((-10223606), var32);
    org.jfree.chart.axis.AxisLocation var35 = var0.getRangeAxisLocation(0);
    float var36 = var0.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5f);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.Paint var7 = null;
    java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
    java.awt.Paint[] var9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var11 = null;
    java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Shape var15 = null;
    java.awt.Shape[] var16 = new java.awt.Shape[] { var15};
    org.jfree.chart.plot.DefaultDrawingSupplier var17 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var9, var10, var12, var14, var16);
    java.awt.Paint var18 = var17.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    var19.setRangeAxis((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var27.setCategoryMargin(10.0d);
    java.awt.Stroke var30 = var27.getAxisLineStroke();
    var24.setTickMarkStroke(var30);
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker((-1.0d), var18, var30);
    org.jfree.chart.util.Layer var33 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var32, var33);
    java.awt.Stroke var35 = var4.getRangeCrosshairStroke();
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
    var38.setLabelURL("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    boolean var42 = var38.isHiddenValue(100L);
    var4.setDomainAxis(91, (org.jfree.chart.axis.ValueAxis)var38);
    org.jfree.chart.plot.Marker var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin(10.0d);
    java.awt.Stroke var5 = var2.getAxisLineStroke();
    var0.setLabelLinkStroke(var5);
    var0.setMinimumArcAngleToDraw(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(0, var4, false);
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var0.setRangeAxes(var11);
    java.awt.Paint var13 = null;
    java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
    java.awt.Paint[] var15 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var16 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Shape var21 = null;
    java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var15, var16, var18, var20, var22);
    java.awt.Paint var24 = var23.getNextOutlinePaint();
    var0.setRangeGridlinePaint(var24);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    var26.setRenderer(0, var28);
    org.jfree.chart.util.SortOrder var30 = var26.getRowRenderingOrder();
    var0.setRowRenderingOrder(var30);
    org.jfree.chart.axis.CategoryAxis var33 = var0.getDomainAxisForDataset(255);
    org.jfree.data.category.CategoryDataset var35 = null;
    var0.setDataset(10, var35);
    java.awt.Paint var37 = var0.getRangeCrosshairPaint();
    int var38 = var0.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(4.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedHeight();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var7 = var5.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var9 = null;
    var5.setRangeAxis(10, var9);
    int var11 = var5.getWeight();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    int var14 = var5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var13);
    var13.setInverted(false);
    double var17 = var13.getFixedAutoRange();
    var13.zoomRange(0.025d, 0.05d);
    org.jfree.data.Range var21 = var13.getRange();
    org.jfree.data.Range var24 = org.jfree.data.Range.shift(var21, 2.0d, false);
    org.jfree.chart.block.RectangleConstraint var25 = var4.toRangeWidth(var24);
    java.lang.String var26 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=4.0, height=0.0]"+ "'", var26.equals("RectangleConstraint[LengthConstraintType.FIXED: width=4.0, height=0.0]"));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    var0.set(255, (java.lang.Object)'4');
    int var4 = var0.size();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(4.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var9 = var8.toUnconstrainedWidth();
    boolean var10 = var0.equals((java.lang.Object)var8);
    java.lang.Object var12 = var0.get(0);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    java.awt.geom.Point2D var18 = var17.getQuadrantOrigin();
    java.awt.geom.Point2D var19 = var17.getQuadrantOrigin();
    var17.setRangeCrosshairValue(4.0d);
    boolean var22 = var17.isRangeZoomable();
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var25 = var23.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var27 = null;
    var23.setRangeAxis(10, var27);
    java.awt.Stroke var29 = null;
    var23.setOutlineStroke(var29);
    org.jfree.data.xy.XYDataset var31 = null;
    int var32 = var23.indexOf(var31);
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    java.util.List var35 = null;
    var23.drawDomainTickBands(var33, var34, var35);
    org.jfree.chart.plot.DatasetRenderingOrder var37 = var23.getDatasetRenderingOrder();
    var17.setDatasetRenderingOrder(var37);
    org.jfree.chart.util.Layer var39 = null;
    java.util.Collection var40 = var17.getDomainMarkers(var39);
    org.jfree.chart.ChartColor var44 = new org.jfree.chart.ChartColor(100, 0, 10);
    int var45 = var44.getRGB();
    var17.setDomainZeroBaselinePaint((java.awt.Paint)var44);
    boolean var47 = var0.equals((java.lang.Object)var17);
    java.lang.Object var49 = var0.get((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 256);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-10223606));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("Pie Plot version XY Plot.\nnull version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Pie Plot:None\nPie Plot LICENCE TERMS:\n");
    var1.setLabelAngle(0.037500000000000006d);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var6 = var5.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var5.setSimpleLabelOffset(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
//     var14.setWidth(20.0d);
//     var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var13.addSubtitle((org.jfree.chart.title.Title)var14);
//     org.jfree.chart.event.ChartChangeEventType var20 = null;
//     org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
//     org.jfree.chart.util.RectangleInsets var22 = var13.getPadding();
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var30 = var28.trimWidth(10.0d);
//     var23.setLabelPadding(var28);
//     double var33 = var28.calculateRightOutset(10.0d);
//     var13.setPadding(var28);
//     var13.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var36 = var13.getPadding();
//     int var37 = var13.getSubtitleCount();
//     int var38 = var13.getBackgroundImageAlignment();
//     java.awt.image.BufferedImage var41 = var13.createBufferedImage(15, 10);
//     var13.setBackgroundImageAlignment(256);
//     org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var49 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var51 = var49.trimWidth(10.0d);
//     var44.setLabelPadding(var49);
//     double var54 = var49.calculateRightOutset(10.0d);
//     double var56 = var49.trimWidth((-1.0d));
//     org.jfree.chart.util.UnitType var57 = var49.getUnitType();
//     var13.setPadding(var49);
//     
//     // Checks the contract:  equals-hashcode on var23 and var44
//     assertTrue("Contract failed: equals-hashcode on var23 and var44", var23.equals(var44) ? var23.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var23
//     assertTrue("Contract failed: equals-hashcode on var44 and var23", var44.equals(var23) ? var44.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var6 = null;
    var5.setDataset(var6);
    boolean var8 = var4.equals((java.lang.Object)var5);
    java.lang.String var9 = var4.toString();
    java.awt.Color var10 = java.awt.Color.getColor("RectangleAnchor.CENTER", var4);
    int var11 = var10.getRed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "java.awt.Color[r=255,g=255,b=91]"+ "'", var9.equals("java.awt.Color[r=255,g=255,b=91]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 255);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var5 = null;
    var4.setDataset(var5);
    boolean var7 = var3.equals((java.lang.Object)var4);
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge(100);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    var4.setRenderer(var10);
    var4.setAnchorValue(0.0d, false);
    org.jfree.chart.plot.CategoryMarker var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var10 = var8.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var12 = null;
    var8.setRangeAxis(10, var12);
    var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var8);
    boolean var15 = var8.isDomainGridlinesVisible();
    var8.mapDatasetToRangeAxis((-1), 0);
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var21 = var19.getDomainAxis((-1));
    boolean var22 = var19.isRangeGridlinesVisible();
    var19.setRangeGridlinesVisible(false);
    var19.setDomainCrosshairLockedOnData(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    java.awt.geom.Point2D var32 = var31.getQuadrantOrigin();
    java.awt.geom.Point2D var33 = var31.getQuadrantOrigin();
    var31.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var36 = null;
    var31.setFixedRangeAxisSpace(var36, true);
    java.awt.Paint var40 = null;
    java.awt.Paint[] var41 = new java.awt.Paint[] { var40};
    java.awt.Paint[] var42 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var43 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var44 = null;
    java.awt.Stroke[] var45 = new java.awt.Stroke[] { var44};
    java.awt.Stroke var46 = null;
    java.awt.Stroke[] var47 = new java.awt.Stroke[] { var46};
    java.awt.Shape var48 = null;
    java.awt.Shape[] var49 = new java.awt.Shape[] { var48};
    org.jfree.chart.plot.DefaultDrawingSupplier var50 = new org.jfree.chart.plot.DefaultDrawingSupplier(var41, var42, var43, var45, var47, var49);
    java.awt.Paint var51 = var50.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
    var52.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
    var52.setRangeAxis((org.jfree.chart.axis.ValueAxis)var57);
    org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var60.setCategoryMargin(10.0d);
    java.awt.Stroke var63 = var60.getAxisLineStroke();
    var57.setTickMarkStroke(var63);
    org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker((-1.0d), var51, var63);
    org.jfree.chart.util.Layer var66 = null;
    var31.addRangeMarker((org.jfree.chart.plot.Marker)var65, var66);
    var19.addRangeMarker((org.jfree.chart.plot.Marker)var65);
    java.awt.Paint var69 = var65.getLabelPaint();
    org.jfree.chart.plot.PiePlot var70 = new org.jfree.chart.plot.PiePlot();
    double var71 = var70.getShadowYOffset();
    double var72 = var70.getShadowYOffset();
    java.awt.Font var73 = var70.getLabelFont();
    var65.setLabelFont(var73);
    org.jfree.chart.util.Layer var75 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker((org.jfree.chart.plot.Marker)var65, var75);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }


    java.awt.Color var1 = java.awt.Color.getColor("Multiple Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.Paint var7 = null;
    java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
    java.awt.Paint[] var9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var11 = null;
    java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Shape var15 = null;
    java.awt.Shape[] var16 = new java.awt.Shape[] { var15};
    org.jfree.chart.plot.DefaultDrawingSupplier var17 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var9, var10, var12, var14, var16);
    java.awt.Paint var18 = var17.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    var19.setRangeAxis((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var27.setCategoryMargin(10.0d);
    java.awt.Stroke var30 = var27.getAxisLineStroke();
    var24.setTickMarkStroke(var30);
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker((-1.0d), var18, var30);
    org.jfree.chart.util.Layer var33 = null;
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var32, var33);
    var4.configureDomainAxes();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var38, true);
    var4.setDomainGridlinesVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var44 = null;
    java.awt.geom.Point2D var45 = null;
    var4.zoomRangeAxes(0.05d, var44, var45, true);
    var4.setDomainCrosshairValue(20.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    var5.setAutoTickUnitSelection(false, false);
    float var11 = var5.getTickMarkInsideLength();
    var5.setRangeAboutValue(1.0d, 8.0d);
    boolean var15 = var5.isInverted();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    var22.mapDatasetToDomainAxis(0, 0);
    java.awt.Stroke var26 = var22.getRangeCrosshairStroke();
    org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var28.setCategoryMargin(10.0d);
    java.awt.Stroke var31 = var28.getAxisLineStroke();
    var28.configure();
    var28.setLowerMargin(1.0d);
    int var35 = var28.getMaximumCategoryLabelLines();
    var28.removeCategoryLabelToolTip((java.lang.Comparable)0L);
    var28.setTickMarksVisible(false);
    java.util.List var40 = var22.getCategoriesForAxis(var28);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var42.setCategoryMargin(10.0d);
    java.awt.Stroke var45 = var42.getAxisLineStroke();
    var42.setMaximumCategoryLabelWidthRatio(1.0f);
    var42.setLabelAngle(0.0d);
    java.awt.geom.Rectangle2D var52 = null;
    org.jfree.chart.util.RectangleEdge var53 = null;
    double var54 = var42.getCategoryStart(0, 0, var52, var53);
    org.jfree.chart.util.RectangleInsets var55 = var42.getLabelInsets();
    var28.setTickLabelInsets(var55);
    var21.setItemLabelPadding(var55);
    double var59 = var55.calculateRightInset((-1.8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 3.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    java.awt.geom.Rectangle2D var2 = var1.getPieArea();
    double var3 = var1.getLatestAngle();
    double var4 = var1.getPieWRadius();
    var1.setLatestAngle(0.025d);
    var1.setPieCenterY(20.0d);
    java.awt.geom.Rectangle2D var9 = var1.getExplodedPieArea();
    var1.setTotal(3.5999999999999996d);
    java.awt.geom.Rectangle2D var12 = null;
    var1.setExplodedPieArea(var12);
    java.awt.geom.Rectangle2D var14 = null;
    var1.setExplodedPieArea(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.data.general.WaferMapDataset var3 = var2.getDataset();
    org.jfree.data.general.WaferMapDataset var4 = null;
    var2.setDataset(var4);
    org.jfree.data.general.WaferMapDataset var6 = null;
    var2.setDataset(var6);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var9.setCategoryMargin(10.0d);
    java.awt.Stroke var12 = var9.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var14 = var13.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var13.setSimpleLabelOffset(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    var22.setWidth(20.0d);
    var22.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var21.addSubtitle((org.jfree.chart.title.Title)var22);
    org.jfree.chart.event.ChartChangeEventType var28 = null;
    org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var21, var28);
    java.awt.Stroke var30 = var21.getBorderStroke();
    var21.setNotify(false);
    var2.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var21);
    java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, (-1.0f), 10.0f);
    var21.setBorderPaint((java.awt.Paint)var37);
    org.jfree.chart.title.TextTitle var39 = var21.getTitle();
    org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot();
    double var42 = var40.getExplodePercent((java.lang.Comparable)10L);
    double var43 = var40.getLabelGap();
    java.awt.Paint var44 = var40.getShadowPaint();
    java.awt.Stroke var45 = var40.getSeparatorStroke();
    var21.setBorderStroke(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    org.jfree.chart.util.RectangleInsets var22 = var13.getPadding();
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var30 = var28.trimWidth(10.0d);
    var23.setLabelPadding(var28);
    double var33 = var28.calculateRightOutset(10.0d);
    var13.setPadding(var28);
    var13.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var36 = var13.getPadding();
    int var37 = var13.getSubtitleCount();
    int var38 = var13.getBackgroundImageAlignment();
    java.awt.image.BufferedImage var41 = var13.createBufferedImage(15, 10);
    java.lang.Object var42 = var13.getTextAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 91);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(0, var4, false);
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
    boolean var10 = var0.isRangeZoomable();
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var14 = var12.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var16 = null;
    var12.setRangeAxis(10, var16);
    java.awt.Stroke var18 = null;
    var12.setOutlineStroke(var18);
    java.awt.Image var20 = null;
    var12.setBackgroundImage(var20);
    java.awt.Graphics2D var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.plot.CrosshairState var26 = null;
    boolean var27 = var12.render(var22, var23, 0, var25, var26);
    java.awt.Stroke var28 = var12.getRangeCrosshairStroke();
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    var12.setRenderer(15, var30, false);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var35 = null;
    var33.setRangeAxis(0, var35, true);
    java.awt.Paint var38 = var33.getRangeCrosshairPaint();
    java.awt.Paint var39 = var33.getNoDataMessagePaint();
    org.jfree.chart.axis.AxisLocation var41 = var33.getRangeAxisLocation(255);
    var12.setDomainAxisLocation(var41);
    var0.setDomainAxisLocation(0, var41, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    var5.setAutoRangeStickyZero(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    java.awt.Shape var17 = var15.getDownArrow();
    var5.setDownArrow(var17);
    org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var17, "", "Multiple Pie Plot");
    java.lang.Object var22 = var21.clone();
    java.lang.String var23 = var21.getShapeType();
    java.lang.Object var24 = var21.clone();
    var21.setToolTipText("RectangleConstraint[RectangleConstraintType.RANGE: width=2.05, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "poly"+ "'", var23.equals("poly"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var3 = var1.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var5 = null;
    var1.setRangeAxis(10, var5);
    java.awt.Stroke var7 = null;
    var1.setOutlineStroke(var7);
    org.jfree.data.xy.XYDataset var9 = null;
    int var10 = var1.indexOf(var9);
    int var11 = var1.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var1.getInsets();
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var15 = var13.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var17 = null;
    var13.setRangeAxis(10, var17);
    java.awt.Stroke var19 = null;
    var13.setOutlineStroke(var19);
    org.jfree.data.xy.XYDataset var21 = null;
    int var22 = var13.indexOf(var21);
    java.awt.Graphics2D var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.util.List var25 = null;
    var13.drawDomainTickBands(var23, var24, var25);
    java.awt.Color var31 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var33.setCategoryMargin(10.0d);
    java.awt.Stroke var36 = var33.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var31, var36);
    java.awt.Stroke var38 = var37.getStroke();
    var13.addDomainMarker((org.jfree.chart.plot.Marker)var37);
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets(0.14d, 0.05d, 90.0d, (-11.0d));
    var41.setTickLabelInsets(var46);
    double var49 = var46.calculateRightOutset(6.25d);
    var37.setLabelOffset(var46);
    var1.setInsets(var46, true);
    org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var55 = var53.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var57 = null;
    var53.setRangeAxis(10, var57);
    java.awt.Stroke var59 = null;
    var53.setOutlineStroke(var59);
    org.jfree.data.xy.XYDataset var61 = null;
    int var62 = var53.indexOf(var61);
    java.awt.Graphics2D var63 = null;
    java.awt.geom.Rectangle2D var64 = null;
    java.util.List var65 = null;
    var53.drawDomainTickBands(var63, var64, var65);
    org.jfree.chart.plot.DatasetRenderingOrder var67 = var53.getDatasetRenderingOrder();
    org.jfree.chart.axis.AxisLocation var68 = var53.getDomainAxisLocation();
    org.jfree.chart.plot.PiePlot var69 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var70 = var69.getLabelShadowPaint();
    var53.setRangeGridlinePaint(var70);
    var53.setDomainCrosshairVisible(true);
    java.awt.Paint var74 = var53.getDomainZeroBaselinePaint();
    org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var77 = var75.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var79 = null;
    var75.setRangeAxis(10, var79);
    int var81 = var75.getWeight();
    org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis("");
    int var84 = var75.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var83);
    org.jfree.chart.plot.SeriesRenderingOrder var85 = var75.getSeriesRenderingOrder();
    var53.setSeriesRenderingOrder(var85);
    var1.setSeriesRenderingOrder(var85);
    org.jfree.chart.JFreeChart var88 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=2.05, height=0.0]", (org.jfree.chart.plot.Plot)var1);
    boolean var89 = var1.isRangeZeroBaselineVisible();
    float var90 = var1.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-11.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0f);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var6 = var4.trimWidth(10.0d);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.text.TextAnchor var11 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    java.awt.geom.Point2D var21 = var20.getQuadrantOrigin();
    var13.zoomDomainAxes(1.0d, var15, var21);
    org.jfree.chart.event.PlotChangeEvent var23 = null;
    var13.notifyListeners(var23);
    var13.clearDomainMarkers(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    var13.setRenderer(256, var28, false);
    java.awt.Color var35 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var37.setCategoryMargin(10.0d);
    java.awt.Stroke var40 = var37.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var35, var40);
    java.awt.Stroke var42 = var41.getStroke();
    org.jfree.chart.util.Layer var43 = null;
    boolean var44 = var13.removeRangeMarker((org.jfree.chart.plot.Marker)var41, var43);
    java.awt.Color var49 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var51.setCategoryMargin(10.0d);
    java.awt.Stroke var54 = var51.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var49, var54);
    float var56 = var55.getAlpha();
    var55.setLabel("Category Plot");
    org.jfree.chart.text.TextAnchor var59 = var55.getLabelTextAnchor();
    var41.setLabelTextAnchor(var59);
    java.lang.String var61 = var59.toString();
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var8, 1.0f, 10.0f, var11, 1.05d, var59);
    boolean var63 = var4.equals((java.lang.Object)var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "TextAnchor.CENTER"+ "'", var61.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var30 = var28.trimWidth(10.0d);
    var23.setLabelPadding(var28);
    boolean var32 = var23.isCircular();
    org.jfree.chart.LegendItemCollection var33 = var23.getLegendItems();
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var23);
    java.awt.Paint var35 = var34.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var36 = var34.getTitle();
    org.jfree.chart.ChartColor var40 = new org.jfree.chart.ChartColor(100, 0, 10);
    var15.add((org.jfree.chart.block.Block)var36, (java.lang.Object)100);
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var43.setCategoryMargin(10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var46 = var43.getCategoryLabelPositions();
    var43.setFixedDimension(100.0d);
    org.jfree.chart.plot.RingPlot var49 = new org.jfree.chart.plot.RingPlot();
    double var51 = var49.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var52 = null;
    var49.markerChanged(var52);
    boolean var54 = var43.hasListener((java.util.EventListener)var49);
    boolean var55 = var15.equals((java.lang.Object)var54);
    var15.clear();
    java.lang.Object var57 = null;
    boolean var58 = var15.equals(var57);
    var15.clear();
    org.jfree.data.xy.XYDataset var60 = null;
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
    var61.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("");
    var61.setRangeAxis((org.jfree.chart.axis.ValueAxis)var66);
    float var68 = var66.getTickMarkOutsideLength();
    org.jfree.chart.renderer.PolarItemRenderer var69 = null;
    org.jfree.chart.plot.PolarPlot var70 = new org.jfree.chart.plot.PolarPlot(var60, (org.jfree.chart.axis.ValueAxis)var66, var69);
    boolean var71 = var15.equals((java.lang.Object)var66);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var66.setRangeWithMargins(0.037500000000000006d, 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.geom.Point2D var6 = var5.getQuadrantOrigin();
    java.awt.Paint var8 = null;
    java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
    java.awt.Paint[] var10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var11 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Stroke var14 = null;
    java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
    java.awt.Shape var16 = null;
    java.awt.Shape[] var17 = new java.awt.Shape[] { var16};
    org.jfree.chart.plot.DefaultDrawingSupplier var18 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var10, var11, var13, var15, var17);
    java.awt.Paint var19 = var18.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    var20.setRangeAxis((org.jfree.chart.axis.ValueAxis)var25);
    org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var28.setCategoryMargin(10.0d);
    java.awt.Stroke var31 = var28.getAxisLineStroke();
    var25.setTickMarkStroke(var31);
    org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker((-1.0d), var19, var31);
    org.jfree.chart.util.Layer var34 = null;
    var5.addRangeMarker((org.jfree.chart.plot.Marker)var33, var34);
    var5.configureDomainAxes();
    org.jfree.chart.util.RectangleInsets var37 = var5.getAxisOffset();
    boolean var38 = var0.equals((java.lang.Object)var37);
    boolean var39 = var0.getDarkerSides();
    org.jfree.chart.urls.PieURLGenerator var40 = var0.getURLGenerator();
    java.awt.Paint var41 = var0.getLabelOutlinePaint();
    org.jfree.data.general.PieDataset var42 = null;
    var0.setDataset(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.geom.Point2D var6 = var5.getQuadrantOrigin();
    java.awt.geom.Point2D var7 = var5.getQuadrantOrigin();
    var5.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var5.setFixedRangeAxisSpace(var10, true);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var14, var16, var17);
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var20 = var19.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var19.setSimpleLabelOffset(var25);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
    var28.setWidth(20.0d);
    var28.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var27.addSubtitle((org.jfree.chart.title.Title)var28);
    java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    var27.setBackgroundPaint((java.awt.Paint)var37);
    var18.setOutlinePaint((java.awt.Paint)var37);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var42.setCategoryMargin(10.0d);
    java.awt.Stroke var45 = var42.getAxisLineStroke();
    var42.configure();
    var42.setLowerMargin(1.0d);
    boolean var49 = var42.isAxisLineVisible();
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    var50.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
    var50.setRangeAxis((org.jfree.chart.axis.ValueAxis)var55);
    boolean var57 = var55.getAutoRangeStickyZero();
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var60 = var58.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var62 = null;
    var58.setRangeAxis(10, var62);
    var55.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var58);
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var40, var42, (org.jfree.chart.axis.ValueAxis)var55, var65);
    org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot();
    double var69 = var67.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
    var71.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("");
    var71.setRangeAxis((org.jfree.chart.axis.ValueAxis)var76);
    org.jfree.chart.axis.CategoryAxis var79 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var79.setCategoryMargin(10.0d);
    java.awt.Stroke var82 = var79.getAxisLineStroke();
    var76.setTickMarkStroke(var82);
    var67.setSectionOutlineStroke((java.lang.Comparable)1L, var82);
    org.jfree.chart.plot.AbstractPieLabelDistributor var85 = var67.getLabelDistributor();
    double var86 = var67.getShadowXOffset();
    java.awt.Paint var87 = var67.getLabelPaint();
    var55.setTickMarkPaint(var87);
    var18.setDomainGridlinePaint(var87);
    org.jfree.chart.util.RectangleEdge var91 = var18.getDomainAxisEdge(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var12.getAutoRangeStickyZero();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setFixedAutoRange(20.0d);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    var19.setRangeAxis((org.jfree.chart.axis.ValueAxis)var24);
    java.awt.Shape var26 = var24.getDownArrow();
    var12.setDownArrow(var26);
    var12.setAxisLineVisible(true);
    boolean var30 = var12.getAutoRangeStickyZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var13 = var12.getAngleGridlineStroke();
    var0.setDomainCrosshairStroke(var13);
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.plot.AbstractPieLabelDistributor var16 = var15.getLabelDistributor();
    java.awt.Color var21 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var23.setCategoryMargin(10.0d);
    java.awt.Stroke var26 = var23.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var21, var26);
    int var28 = var21.getBlue();
    var15.setShadowPaint((java.awt.Paint)var21);
    java.awt.Color var33 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    java.awt.image.ColorModel var34 = null;
    java.awt.Rectangle var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    java.awt.geom.AffineTransform var37 = null;
    java.awt.RenderingHints var38 = null;
    java.awt.PaintContext var39 = var33.createContext(var34, var35, var36, var37, var38);
    var15.setLabelLinkPaint((java.awt.Paint)var33);
    java.awt.Color var41 = var33.brighter();
    var0.setDomainGridlinePaint((java.awt.Paint)var41);
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
    java.awt.geom.Point2D var48 = var47.getQuadrantOrigin();
    java.awt.geom.Point2D var49 = var47.getQuadrantOrigin();
    var47.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var52 = null;
    var47.setFixedRangeAxisSpace(var52, true);
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    var47.setDomainAxis((org.jfree.chart.axis.ValueAxis)var56);
    org.jfree.data.Range var58 = var56.getDefaultAutoRange();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2);
//     org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     int var15 = var6.indexOf(var14);
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     java.util.List var18 = null;
//     var6.drawDomainTickBands(var16, var17, var18);
//     org.jfree.chart.plot.DatasetRenderingOrder var20 = var6.getDatasetRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var21 = var6.getDomainAxisLocation();
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var27 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var29 = var27.trimWidth(10.0d);
//     var22.setLabelPadding(var27);
//     boolean var31 = var22.isCircular();
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var33 = var32.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var38 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var32.setSimpleLabelOffset(var38);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var32);
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle();
//     var41.setWidth(20.0d);
//     var41.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var40.addSubtitle((org.jfree.chart.title.Title)var41);
//     java.awt.Color var50 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
//     var40.setBackgroundPaint((java.awt.Paint)var50);
//     var22.setLabelBackgroundPaint((java.awt.Paint)var50);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var54 = null;
//     var53.setDataset(var54);
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.data.Range var57 = var53.getDataRange(var56);
//     boolean var58 = var53.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisSpace var59 = null;
//     var53.setFixedRangeAxisSpace(var59);
//     java.awt.Stroke var61 = var53.getRangeGridlineStroke();
//     var53.setRangeCrosshairLockedOnData(true);
//     boolean var64 = var22.equals((java.lang.Object)var53);
//     org.jfree.chart.plot.PlotOrientation var65 = var53.getOrientation();
//     org.jfree.chart.util.RectangleEdge var66 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var21, var65);
//     var0.setDomainAxisLocation(255, var21);
//     
//     // Checks the contract:  equals-hashcode on var53 and var0
//     assertTrue("Contract failed: equals-hashcode on var53 and var0", var53.equals(var0) ? var53.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var53 and var0.", var53.equals(var0) == var0.equals(var53));
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.data.general.DatasetGroup var3 = var0.getDatasetGroup();
    org.jfree.chart.axis.AxisLocation var4 = var0.getDomainAxisLocation();
    var0.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)1.0f, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    var8.setBackgroundPaint((java.awt.Paint)var18);
    var8.setTitle("ChartEntity: tooltip = ");
    var8.removeLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var9);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var12.setCategoryMargin(10.0d);
    java.awt.Stroke var15 = var12.getAxisLineStroke();
    var9.setTickMarkStroke(var15);
    var0.setSectionOutlineStroke((java.lang.Comparable)1L, var15);
    org.jfree.chart.plot.AbstractPieLabelDistributor var18 = var0.getLabelDistributor();
    double var19 = var0.getShadowXOffset();
    java.awt.Paint var20 = var0.getShadowPaint();
    var0.setIgnoreNullValues(false);
    double var23 = var0.getOuterSeparatorExtension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.2d);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("Pie Plot version XY Plot.\nnull version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Pie Plot:None\nPie Plot LICENCE TERMS:\n");
//     java.lang.Object var2 = var1.clone();
//     var1.setMaximumCategoryLabelLines(255);
//     org.jfree.chart.axis.CategoryAnchor var5 = null;
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
//     var8.setWidth(20.0d);
//     java.lang.Object var11 = var8.clone();
//     boolean var12 = var8.getExpandToFitSpace();
//     double var13 = var8.getHeight();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
//     var16.setLabelLinkMargin(0.0d);
//     var16.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var23 = var21.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     var21.setRangeAxis(10, var25);
//     java.awt.Stroke var27 = null;
//     var21.setOutlineStroke(var27);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     var21.setRenderer(1, var30);
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.FlowArrangement var36 = new org.jfree.chart.block.FlowArrangement(var32, var33, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var36, (org.jfree.chart.block.Arrangement)var41);
//     boolean var44 = var42.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot();
//     double var46 = var45.getShadowYOffset();
//     double var47 = var45.getShadowYOffset();
//     java.awt.Font var48 = var45.getLabelFont();
//     var42.setItemFont(var48);
//     var16.setLabelFont(var48);
//     java.awt.Color var54 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var56 = null;
//     var55.setDataset(var56);
//     boolean var58 = var54.equals((java.lang.Object)var55);
//     org.jfree.chart.text.TextBlock var59 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var48, (java.awt.Paint)var54);
//     org.jfree.chart.text.TextLine var60 = var59.getLastLine();
//     java.util.List var61 = var59.getLines();
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var63 = var62.getTextAlignment();
//     java.lang.Object var64 = var62.clone();
//     boolean var65 = var59.equals((java.lang.Object)var62);
//     double var66 = var62.getContentXOffset();
//     java.awt.geom.Rectangle2D var67 = var62.getBounds();
//     java.lang.Object var68 = null;
//     java.lang.Object var69 = var8.draw(var14, var67, var68);
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var72 = var70.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     var70.setRangeAxis(0, var74, false);
//     org.jfree.chart.axis.CategoryAnchor var77 = var70.getDomainGridlinePosition();
//     org.jfree.chart.axis.ValueAxis var79 = var70.getRangeAxisForDataset(4);
//     var70.configureRangeAxes();
//     var70.setAnchorValue(0.0d);
//     org.jfree.chart.util.RectangleEdge var83 = var70.getDomainAxisEdge();
//     double var84 = var1.getCategoryJava2DCoordinate(var5, (-524308), 0, var67, var83);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=false]");
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var3 = var2.getTickUnit();
    var2.configure();
    org.jfree.chart.axis.DateTickMarkPosition var5 = var2.getTickMarkPosition();
    boolean var6 = var2.isAutoRange();
    java.lang.Object var7 = null;
    boolean var8 = var2.equals(var7);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var11 = var10.getRadiusGridlineStroke();
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
    java.awt.geom.Point2D var17 = var16.getQuadrantOrigin();
    var16.setRangeGridlinesVisible(true);
    java.awt.Paint var21 = null;
    java.awt.Paint[] var22 = new java.awt.Paint[] { var21};
    java.awt.Paint[] var23 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var24 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    java.awt.Shape var29 = null;
    java.awt.Shape[] var30 = new java.awt.Shape[] { var29};
    org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier(var22, var23, var24, var26, var28, var30);
    java.awt.Paint var32 = var31.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    var33.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis((org.jfree.chart.axis.ValueAxis)var38);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var41.setCategoryMargin(10.0d);
    java.awt.Stroke var44 = var41.getAxisLineStroke();
    var38.setTickMarkStroke(var44);
    org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker((-1.0d), var32, var44);
    var16.setDomainGridlineStroke(var44);
    var10.setRadiusGridlineStroke(var44);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var50 = var49.getTickUnit();
    var10.setAngleTickUnit((org.jfree.chart.axis.TickUnit)var50);
    java.util.Date var52 = var9.calculateHighestVisibleTickValue(var50);
    java.util.Date var53 = var2.calculateHighestVisibleTickValue(var50);
    java.text.DateFormat var54 = var2.getDateFormatOverride();
    org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var57.setCategoryMargin(10.0d);
    java.awt.Stroke var60 = var57.getAxisLineStroke();
    boolean var61 = var55.equals((java.lang.Object)var57);
    float var62 = var57.getTickMarkInsideLength();
    org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var65 = var64.getTickUnit();
    var64.configure();
    org.jfree.chart.axis.DateTickMarkPosition var67 = var64.getTickMarkPosition();
    java.lang.Object var68 = var64.clone();
    java.util.Date var69 = var64.getMinimumDate();
    var63.setMinimumDate(var69);
    var57.addCategoryLabelToolTip((java.lang.Comparable)var69, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var2.setMaximumDate(var69);
    org.jfree.chart.axis.DateAxis var74 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var75 = var74.getTickUnit();
    var74.configure();
    org.jfree.chart.axis.DateTickMarkPosition var77 = var74.getTickMarkPosition();
    java.text.DateFormat var78 = var74.getDateFormatOverride();
    java.awt.Shape var79 = var74.getUpArrow();
    java.util.Date var80 = var74.getMinimumDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var69, var80);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = var0.getTickUnit();
    var0.configure();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    java.awt.geom.Point2D var12 = var11.getQuadrantOrigin();
    var4.zoomDomainAxes(1.0d, var6, var12);
    org.jfree.chart.util.RectangleInsets var14 = var4.getAxisOffset();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
    var15.setWidth(20.0d);
    var15.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var15.setURLText("Category Plot");
    double var22 = var15.getWidth();
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.util.Size2D var26 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var31 = var29.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var33 = null;
    var29.setRangeAxis(10, var33);
    java.awt.Stroke var35 = null;
    var29.setOutlineStroke(var35);
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
    var29.setRenderer(1, var38);
    org.jfree.chart.util.HorizontalAlignment var40 = null;
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement(var40, var41, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var45 = null;
    org.jfree.chart.util.VerticalAlignment var46 = null;
    org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement(var45, var46, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var49);
    boolean var52 = var50.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.util.RectangleInsets var53 = var50.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleInsets var54 = var50.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var55 = var50.getLegendItemGraphicAnchor();
    java.awt.geom.Rectangle2D var56 = org.jfree.chart.util.RectangleAnchor.createRectangle(var26, 0.05d, 0.2d, var55);
    var15.draw(var23, var56);
    java.awt.geom.Rectangle2D var58 = var14.createOutsetRectangle(var56);
    org.jfree.chart.util.RectangleEdge var59 = null;
    double var60 = var0.valueToJava2D(98.0d, var58, var59);
    var0.configure();
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var63 = var62.getTimeline();
    org.jfree.chart.axis.DateTickMarkPosition var64 = var62.getTickMarkPosition();
    var0.setTickMarkPosition(var64);
    var0.setAutoRangeMinimumSize(100.0d);
    var0.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 20.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    int var6 = var5.getAlpha();
    var1.setAggregatedItemsPaint((java.awt.Paint)var5);
    org.jfree.chart.util.TableOrder var8 = var1.getDataExtractOrder();
    org.jfree.chart.LegendItemCollection var9 = var1.getLegendItems();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var11.setCategoryMargin(10.0d);
    java.awt.Stroke var14 = var11.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var16 = var15.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var15.setSimpleLabelOffset(var21);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var15);
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle();
    var24.setWidth(20.0d);
    var24.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var23.addSubtitle((org.jfree.chart.title.Title)var24);
    org.jfree.chart.event.ChartChangeEventType var30 = null;
    org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var11, var23, var30);
    var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var23);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    var33.setRenderer(0, var35);
    int var37 = var33.getDatasetCount();
    org.jfree.chart.plot.PlotOrientation var38 = var33.getOrientation();
    boolean var39 = var23.equals((java.lang.Object)var38);
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle();
    var40.setURLText("");
    var23.setTitle(var40);
    boolean var44 = var40.getExpandToFitSpace();
    var40.setHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var6, 0, 0);
    org.jfree.chart.JFreeChart var10 = null;
    var9.setChart(var10);
    int var12 = var9.getPercent();
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var14 = var13.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var13.setSimpleLabelOffset(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    var22.setWidth(20.0d);
    var22.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var21.addSubtitle((org.jfree.chart.title.Title)var22);
    var9.setChart(var21);
    java.lang.String var29 = var9.toString();
    java.lang.String var30 = var9.toString();
    org.jfree.chart.JFreeChart var31 = var9.getChart();
    org.jfree.chart.title.TextTitle var32 = var31.getTitle();
    boolean var33 = var31.isNotify();
    org.jfree.chart.ChartRenderingInfo var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var39 = var31.createBufferedImage((-8355712), 255, 3.0d, 0.20625d, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"+ "'", var29.equals("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"+ "'", var30.equals("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    java.awt.geom.Rectangle2D var2 = var1.getPieArea();
    double var3 = var1.getLatestAngle();
    int var4 = var1.getPassesRequired();
    var1.setLatestAngle(1.0d);
    org.jfree.chart.entity.EntityCollection var7 = var1.getEntityCollection();
    java.awt.geom.Rectangle2D var8 = null;
    var1.setLinkArea(var8);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    boolean var17 = var15.getAutoRangeStickyZero();
    java.text.NumberFormat var18 = var15.getNumberFormatOverride();
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
    var20.setLabelLinkMargin(0.0d);
    var20.setLabelLinkMargin(20.0d);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var29 = null;
    var25.setRangeAxis(10, var29);
    java.awt.Stroke var31 = null;
    var25.setOutlineStroke(var31);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    var25.setRenderer(1, var34);
    org.jfree.chart.util.HorizontalAlignment var36 = null;
    org.jfree.chart.util.VerticalAlignment var37 = null;
    org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var41 = null;
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var45);
    boolean var48 = var46.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot();
    double var50 = var49.getShadowYOffset();
    double var51 = var49.getShadowYOffset();
    java.awt.Font var52 = var49.getLabelFont();
    var46.setItemFont(var52);
    var20.setLabelFont(var52);
    java.awt.Color var58 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var60 = null;
    var59.setDataset(var60);
    boolean var62 = var58.equals((java.lang.Object)var59);
    org.jfree.chart.text.TextBlock var63 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var52, (java.awt.Paint)var58);
    org.jfree.chart.text.TextLine var64 = var63.getLastLine();
    java.util.List var65 = var63.getLines();
    org.jfree.chart.title.TextTitle var66 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var67 = var66.getTextAlignment();
    java.lang.Object var68 = var66.clone();
    boolean var69 = var63.equals((java.lang.Object)var66);
    double var70 = var66.getContentXOffset();
    java.awt.geom.Rectangle2D var71 = var66.getBounds();
    var15.setUpArrow((java.awt.Shape)var71);
    var1.setPieArea(var71);
    double var74 = var1.getPieHRadius();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.event.PlotChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var7 = var5.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var9 = null;
    var5.setRangeAxis(10, var9);
    java.awt.Stroke var11 = null;
    var5.setOutlineStroke(var11);
    org.jfree.data.xy.XYDataset var13 = null;
    int var14 = var5.indexOf(var13);
    java.awt.geom.Point2D var15 = var5.getQuadrantOrigin();
    var0.zoomRangeAxes(0.025d, var4, var15, true);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var0.getDomainMarkers((-65536), var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var0.setFixedRangeAxisSpace(var21);
    var0.setWeight(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var5 = null;
    var4.setDataset(var5);
    boolean var7 = var3.equals((java.lang.Object)var4);
    org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge(100);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    var4.setRenderer(var10);
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var4.datasetChanged(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var1 = var0.getRadiusGridlineStroke();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    org.jfree.chart.renderer.PolarItemRenderer var3 = var0.getRenderer();
    var0.setRadiusGridlinesVisible(false);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAngleLabelPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    var9.setLicenceName("hi!");
    boolean var12 = var0.equals((java.lang.Object)"hi!");
    boolean var13 = var0.getDrawSharedDomainAxis();
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var16 = var14.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var18 = null;
    var14.setRangeAxis(10, var18);
    java.awt.Stroke var20 = null;
    var14.setOutlineStroke(var20);
    org.jfree.data.xy.XYDataset var22 = null;
    int var23 = var14.indexOf(var22);
    java.awt.Graphics2D var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    java.util.List var26 = null;
    var14.drawDomainTickBands(var24, var25, var26);
    org.jfree.chart.plot.DatasetRenderingOrder var28 = var14.getDatasetRenderingOrder();
    org.jfree.chart.axis.AxisLocation var29 = var14.getDomainAxisLocation();
    var0.setRangeAxisLocation(var29, false);
    var0.setRangeCrosshairValue(20.0d, false);
    org.jfree.chart.util.RectangleEdge var36 = var0.getDomainAxisEdge(178);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var0.indexOf(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.util.List var12 = null;
    var0.drawDomainTickBands(var10, var11, var12);
    var0.setRangeCrosshairLockedOnData(true);
    boolean var16 = var0.isDomainCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var1 = var0.getAngleGridlineStroke();
    boolean var2 = var0.isRangeZoomable();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var11 = var9.trimWidth(10.0d);
    var4.setLabelPadding(var9);
    boolean var13 = var4.isCircular();
    org.jfree.chart.LegendItemCollection var14 = var4.getLegendItems();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var4);
    java.awt.Paint var16 = var15.getBackgroundPaint();
    var0.setRadiusGridlinePaint(var16);
    java.lang.Object var18 = var0.clone();
    boolean var19 = var0.isRangeZoomable();
    org.jfree.chart.renderer.PolarItemRenderer var20 = var0.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin(10.0d);
    java.awt.Stroke var5 = var2.getAxisLineStroke();
    boolean var6 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var9 = var7.getDomainAxis((-1));
    var7.clearRangeAxes();
    var2.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var7.setFixedRangeAxisSpace(var12);
    var7.setDomainCrosshairValue(3.5999999999999996d);
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRenderer((-524308), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot();
    double var25 = var24.getShadowYOffset();
    double var26 = var24.getShadowYOffset();
    java.awt.Font var27 = var24.getLabelFont();
    var21.setItemFont(var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.util.Size2D var30 = var21.arrange(var29);
    org.jfree.chart.util.RectangleEdge var31 = var21.getLegendItemGraphicEdge();
    org.jfree.chart.block.BlockContainer var32 = var21.getItemContainer();
    org.jfree.chart.util.RectangleAnchor var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setLegendItemGraphicAnchor(var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    int var1 = var0.getSeriesCount();
    var0.addCornerTextItem("RectangleConstraint[LengthConstraintType.FIXED: width=4.0, height=1.0]");
    var0.addCornerTextItem("ThreadContext");
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder();
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
    boolean var16 = var9.equals((java.lang.Object)var15);
    var0.zoomDomainAxes(4.0d, 0.0d, var8, var15);
    org.jfree.chart.event.RendererChangeEvent var18 = null;
    var0.rendererChanged(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.CrosshairState var32 = null;
    boolean var33 = var24.render(var28, var29, 0, var31, var32);
    java.awt.Paint var35 = var24.getQuadrantPaint(0);
    org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
    var21.setPosition(var37);
    org.jfree.chart.block.BlockContainer var39 = var21.getItemContainer();
    org.jfree.chart.util.RectangleInsets var40 = var21.getLegendItemGraphicPadding();
    java.awt.Graphics2D var41 = null;
    org.jfree.data.Range var43 = null;
    org.jfree.chart.block.RectangleConstraint var44 = new org.jfree.chart.block.RectangleConstraint(0.0d, var43);
    double var45 = var44.getWidth();
    org.jfree.data.Range var46 = var44.getWidthRange();
    org.jfree.chart.util.Size2D var47 = var21.arrange(var41, var44);
    org.jfree.chart.block.BlockFrame var48 = var21.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(104.0d, 0.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.setCategoryMargin(10.0d);
    java.awt.Stroke var9 = var6.getAxisLineStroke();
    var6.configure();
    var6.setLowerMargin(1.0d);
    var0.setDomainAxis(1, var6);
    int var14 = var0.getRangeAxisCount();
    boolean var15 = var0.isOutlineVisible();
    var0.setRangeCrosshairVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.getName();
    var0.setInfo("PlotOrientation.HORIZONTAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     boolean var23 = var21.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.plot.CrosshairState var32 = null;
//     boolean var33 = var24.render(var28, var29, 0, var31, var32);
//     java.awt.Paint var35 = var24.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
//     var21.setPosition(var37);
//     org.jfree.chart.block.BlockContainer var39 = var21.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var40 = var21.getLegendItemGraphicPadding();
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var47 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var49 = var47.trimWidth(10.0d);
//     var42.setLabelPadding(var47);
//     boolean var51 = var42.isCircular();
//     org.jfree.chart.LegendItemCollection var52 = var42.getLegendItems();
//     org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var42);
//     var21.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var53);
//     org.jfree.chart.util.RectangleEdge var55 = var21.getPosition();
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var58 = var56.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var59 = var56.getRootPlot();
//     java.awt.Graphics2D var60 = null;
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var63 = null;
//     org.jfree.chart.plot.CrosshairState var64 = null;
//     boolean var65 = var56.render(var60, var61, 0, var63, var64);
//     java.awt.Paint var67 = var56.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var69 = var56.getRangeAxisEdge(100);
//     var56.clearRangeMarkers((-16777216));
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     var72.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis("");
//     var72.setRangeAxis((org.jfree.chart.axis.ValueAxis)var77);
//     boolean var79 = var77.getAutoRangeStickyZero();
//     java.text.NumberFormat var80 = var77.getNumberFormatOverride();
//     int var81 = var56.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var77);
//     java.awt.Paint var82 = var56.getDomainCrosshairPaint();
//     var21.setBackgroundPaint(var82);
//     
//     // Checks the contract:  equals-hashcode on var24 and var56
//     assertTrue("Contract failed: equals-hashcode on var24 and var56", var24.equals(var56) ? var24.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var24
//     assertTrue("Contract failed: equals-hashcode on var56 and var24", var56.equals(var24) ? var56.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var59
//     assertTrue("Contract failed: equals-hashcode on var27 and var59", var27.equals(var59) ? var27.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var27
//     assertTrue("Contract failed: equals-hashcode on var59 and var27", var59.equals(var27) ? var59.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot();
    double var25 = var24.getShadowYOffset();
    double var26 = var24.getShadowYOffset();
    java.awt.Font var27 = var24.getLabelFont();
    var21.setItemFont(var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.util.Size2D var30 = var21.arrange(var29);
    java.lang.String var31 = var30.toString();
    double var32 = var30.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var31.equals("Size2D[width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    java.util.TimeZone var2 = var1.getTimeZone();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    java.util.TimeZone var4 = var3.getTimeZone();
    var1.setTimeZone(var4);
    var1.resizeRange(6.25d);
    org.jfree.data.Range var10 = new org.jfree.data.Range((-11.0d), 0.05d);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis((-1));
    boolean var14 = var11.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    var18.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
    boolean var25 = var23.getAutoRangeStickyZero();
    var15.setDomainAxis((org.jfree.chart.axis.ValueAxis)var23);
    var11.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
    var23.setFixedAutoRange(20.0d);
    var23.setInverted(false);
    boolean var32 = var10.equals((java.lang.Object)var23);
    double var34 = var10.constrain(3.0d);
    boolean var36 = var10.contains(28.124999999999993d);
    boolean var39 = var10.intersects(0.0d, 4.0d);
    var1.setRange(var10);
    org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(28.124999999999993d, var10);
    double var42 = var10.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-11.0d));

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.data.general.WaferMapDataset var3 = var2.getDataset();
    org.jfree.data.general.WaferMapDataset var4 = var2.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var1 = var0.getRadiusGridlineStroke();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.event.ChartProgressListener var6 = null;
    var5.removeProgressListener(var6);
    var5.fireChartChanged();
    java.lang.Object var9 = var5.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    int var6 = var5.getAlpha();
    var1.setAggregatedItemsPaint((java.awt.Paint)var5);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var10 = null;
    var8.setRangeAxis(0, var10, true);
    org.jfree.chart.ui.BasicProjectInfo var17 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    var17.setLicenceName("hi!");
    boolean var20 = var8.equals((java.lang.Object)"hi!");
    org.jfree.data.category.CategoryDataset var22 = null;
    var8.setDataset(10, var22);
    java.awt.Paint var24 = var8.getRangeCrosshairPaint();
    var1.setAggregatedItemsPaint(var24);
    java.awt.Paint var26 = var1.getAggregatedItemsPaint();
    java.awt.Paint var27 = var1.getAggregatedItemsPaint();
    org.jfree.chart.JFreeChart var28 = var1.getPieChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     var4.setDataset(var5);
//     boolean var7 = var3.equals((java.lang.Object)var4);
//     org.jfree.chart.util.RectangleEdge var9 = var4.getRangeAxisEdge(100);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     int var11 = var4.getIndexOf(var10);
//     org.jfree.chart.plot.DatasetRenderingOrder var12 = var4.getDatasetRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     java.awt.geom.Point2D var21 = var20.getQuadrantOrigin();
//     var13.zoomDomainAxes(1.0d, var15, var21);
//     org.jfree.chart.event.PlotChangeEvent var23 = null;
//     var13.notifyListeners(var23);
//     var13.clearDomainMarkers(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var13.setRenderer(256, var28, false);
//     java.awt.Color var35 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var37.setCategoryMargin(10.0d);
//     java.awt.Stroke var40 = var37.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var35, var40);
//     java.awt.Stroke var42 = var41.getStroke();
//     org.jfree.chart.util.Layer var43 = null;
//     boolean var44 = var13.removeRangeMarker((org.jfree.chart.plot.Marker)var41, var43);
//     org.jfree.chart.axis.AxisLocation var45 = var13.getRangeAxisLocation();
//     var4.setDomainAxisLocation(var45, false);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var51 = null;
//     var49.setRenderer(0, var51);
//     int var53 = var49.getDatasetCount();
//     double var54 = var49.getAnchorValue();
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var57 = var55.getRangeAxis(0);
//     float var58 = var55.getBackgroundImageAlpha();
//     boolean var59 = var55.isDomainGridlinesVisible();
//     org.jfree.data.category.CategoryDataset var61 = var55.getDataset(0);
//     org.jfree.chart.util.Layer var63 = null;
//     java.util.Collection var64 = var55.getRangeMarkers(10, var63);
//     org.jfree.chart.axis.AxisLocation var65 = var55.getDomainAxisLocation();
//     var49.setRangeAxisLocation(var65, true);
//     var4.setRangeAxisLocation(16, var65);
//     
//     // Checks the contract:  equals-hashcode on var13 and var55
//     assertTrue("Contract failed: equals-hashcode on var13 and var55", var13.equals(var55) ? var13.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var13
//     assertTrue("Contract failed: equals-hashcode on var55 and var13", var55.equals(var13) ? var55.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ");
    org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

}
