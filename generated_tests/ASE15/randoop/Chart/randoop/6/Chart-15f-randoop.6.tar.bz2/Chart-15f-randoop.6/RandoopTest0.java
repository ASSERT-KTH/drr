
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 100.0d, true);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.awt.Paint var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("", var1, var2, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 0.0d, (-1.0d), var3);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisOffset(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)(short)0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(0, var4, false);
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var0.removeRangeMarker(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var3 = var0.getRootPlot();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var0.draw(var4, var5, var11, var12, var13);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    var0.setDataset(var1);
    org.jfree.chart.plot.PlotOrientation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.Marker var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 100.0d, 0.0d, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var2 = null;
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
//     java.awt.geom.Point2D var8 = var7.getQuadrantOrigin();
//     var0.zoomDomainAxes(1.0d, var2, var8);
//     org.jfree.chart.event.RendererChangeEvent var10 = null;
//     var0.rendererChanged(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     var0.handleClick(100, 0, var14);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     var0.setDataset(var1);
//     var0.zoom(0.0d);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.chart.axis.AxisLocation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var3, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
//     var0.zoomRangeAxes((-1.0d), var5, var11, false);
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint[] var18 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var19 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Shape var24 = null;
//     java.awt.Shape[] var25 = new java.awt.Shape[] { var24};
//     org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var18, var19, var21, var23, var25);
//     java.awt.Paint var27 = var26.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setRangeAxis((org.jfree.chart.axis.ValueAxis)var33);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var36.setCategoryMargin(10.0d);
//     java.awt.Stroke var39 = var36.getAxisLineStroke();
//     var33.setTickMarkStroke(var39);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker((-1.0d), var27, var39);
//     org.jfree.chart.util.Layer var42 = null;
//     boolean var43 = var0.removeRangeMarker(1, (org.jfree.chart.plot.Marker)var41, var42);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.awt.Paint var1 = null;
    java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
    java.awt.Paint[] var3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var3, var4, var6, var8, var10);
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    var13.setRangeAxis((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var21.setCategoryMargin(10.0d);
    java.awt.Stroke var24 = var21.getAxisLineStroke();
    var18.setTickMarkStroke(var24);
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker((-1.0d), var12, var24);
    org.jfree.chart.util.RectangleAnchor var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.setLabelAnchor(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1);
//     org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var4 = null;
//     org.jfree.chart.util.Size2D var5 = var2.calculateConstrainedSize(var4);
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.geom.Point2D var10 = var9.getQuadrantOrigin();
//     java.awt.Paint var12 = null;
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var15 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var16 = null;
//     java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
//     java.awt.Stroke var18 = null;
//     java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
//     java.awt.Shape var20 = null;
//     java.awt.Shape[] var21 = new java.awt.Shape[] { var20};
//     org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var14, var15, var17, var19, var21);
//     java.awt.Paint var23 = var22.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var24.setRangeAxis((org.jfree.chart.axis.ValueAxis)var29);
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var32.setCategoryMargin(10.0d);
//     java.awt.Stroke var35 = var32.getAxisLineStroke();
//     var29.setTickMarkStroke(var35);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker((-1.0d), var23, var35);
//     org.jfree.chart.util.Layer var38 = null;
//     var9.addRangeMarker((org.jfree.chart.plot.Marker)var37, var38);
//     org.jfree.chart.util.Layer var40 = null;
//     boolean var41 = var0.removeDomainMarker(0, (org.jfree.chart.plot.Marker)var37, var40);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var1, 0.0f, 10.0f, 4.0d, 10.0f, 1.0f);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var6 = var4.trimWidth(10.0d);
    java.lang.String var7 = var4.toString();
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var4.createInsetRectangle(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]"+ "'", var7.equals("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]"));

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var1, var2, 0.5f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     java.awt.Paint var7 = null;
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
//     java.awt.Paint[] var9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var11 = null;
//     java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
//     java.awt.Stroke var13 = null;
//     java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
//     java.awt.Shape var15 = null;
//     java.awt.Shape[] var16 = new java.awt.Shape[] { var15};
//     org.jfree.chart.plot.DefaultDrawingSupplier var17 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var9, var10, var12, var14, var16);
//     java.awt.Paint var18 = var17.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     var19.setRangeAxis((org.jfree.chart.axis.ValueAxis)var24);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var27.setCategoryMargin(10.0d);
//     java.awt.Stroke var30 = var27.getAxisLineStroke();
//     var24.setTickMarkStroke(var30);
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker((-1.0d), var18, var30);
//     org.jfree.chart.util.Layer var33 = null;
//     var4.addRangeMarker((org.jfree.chart.plot.Marker)var32, var33);
//     java.awt.Paint var36 = null;
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var36};
//     java.awt.Paint[] var38 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var39 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var40 = null;
//     java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
//     java.awt.Stroke var42 = null;
//     java.awt.Stroke[] var43 = new java.awt.Stroke[] { var42};
//     java.awt.Shape var44 = null;
//     java.awt.Shape[] var45 = new java.awt.Shape[] { var44};
//     org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier(var37, var38, var39, var41, var43, var45);
//     java.awt.Paint var47 = var46.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     var48.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     var48.setRangeAxis((org.jfree.chart.axis.ValueAxis)var53);
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var56.setCategoryMargin(10.0d);
//     java.awt.Stroke var59 = var56.getAxisLineStroke();
//     var53.setTickMarkStroke(var59);
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker((-1.0d), var47, var59);
//     var32.setOutlinePaint(var47);
//     
//     // Checks the contract:  equals-hashcode on var17 and var46
//     assertTrue("Contract failed: equals-hashcode on var17 and var46", var17.equals(var46) ? var17.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var17
//     assertTrue("Contract failed: equals-hashcode on var46 and var17", var46.equals(var17) ? var46.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var48
//     assertTrue("Contract failed: equals-hashcode on var19 and var48", var19.equals(var48) ? var19.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var19
//     assertTrue("Contract failed: equals-hashcode on var48 and var19", var48.equals(var19) ? var48.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var61
//     assertTrue("Contract failed: equals-hashcode on var32 and var61", var32.equals(var61) ? var32.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var32
//     assertTrue("Contract failed: equals-hashcode on var61 and var32", var61.equals(var32) ? var61.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.axis.AxisLocation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    int var6 = var0.getWeight();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    int var9 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.data.Range var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setRange(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.event.PlotChangeListener var1 = null;
//     var0.addChangeListener(var1);
//     java.awt.Paint var4 = null;
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
//     java.awt.Paint[] var6 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var7 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var8 = null;
//     java.awt.Stroke[] var9 = new java.awt.Stroke[] { var8};
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Shape var12 = null;
//     java.awt.Shape[] var13 = new java.awt.Shape[] { var12};
//     org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var6, var7, var9, var11, var13);
//     java.awt.Paint var15 = var14.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setRangeAxis((org.jfree.chart.axis.ValueAxis)var21);
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var24.setCategoryMargin(10.0d);
//     java.awt.Stroke var27 = var24.getAxisLineStroke();
//     var21.setTickMarkStroke(var27);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker((-1.0d), var15, var27);
//     org.jfree.chart.util.Layer var30 = null;
//     boolean var31 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var29, var30);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getRangeAxis(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     java.awt.geom.Point2D var19 = var18.getQuadrantOrigin();
//     java.awt.geom.Point2D var20 = var18.getQuadrantOrigin();
//     var8.zoomDomainAxes(4.0d, var13, var20);
//     var4.zoomRangeAxes(1.0d, 0.0d, var7, var20);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "Category Plot", "RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", "hi!");

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    org.jfree.chart.util.RectangleInsets var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisOffset(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.setLabel("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     var5.setPositiveArrowVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     java.awt.Shape var17 = var15.getDownArrow();
//     var5.setLeftArrow(var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.Paint var6 = null;
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     java.awt.Paint[] var8 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Stroke var12 = null;
//     java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
//     java.awt.Shape var14 = null;
//     java.awt.Shape[] var15 = new java.awt.Shape[] { var14};
//     org.jfree.chart.plot.DefaultDrawingSupplier var16 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var8, var9, var11, var13, var15);
//     java.awt.Paint var17 = var16.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var18.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var26.setCategoryMargin(10.0d);
//     java.awt.Stroke var29 = var26.getAxisLineStroke();
//     var23.setTickMarkStroke(var29);
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker((-1.0d), var17, var29);
//     var4.setRangeGridlinePaint(var17);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     var34.setRangeAxis((org.jfree.chart.axis.ValueAxis)var39);
//     java.awt.Shape var41 = var39.getDownArrow();
//     var4.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var39);
//     
//     // Checks the contract:  equals-hashcode on var18 and var34
//     assertTrue("Contract failed: equals-hashcode on var18 and var34", var18.equals(var34) ? var18.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var18
//     assertTrue("Contract failed: equals-hashcode on var34 and var18", var34.equals(var18) ? var34.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     var0.setRangeAxis(0, var2, true);
//     org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var9.setLicenceName("hi!");
//     boolean var12 = var0.equals((java.lang.Object)"hi!");
//     org.jfree.data.category.CategoryDataset var14 = null;
//     var0.setDataset(10, var14);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     java.awt.geom.Point2D var22 = var21.getQuadrantOrigin();
//     java.awt.geom.Point2D var23 = var21.getQuadrantOrigin();
//     var21.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var26 = null;
//     var21.setFixedRangeAxisSpace(var26, true);
//     java.awt.Paint var30 = null;
//     java.awt.Paint[] var31 = new java.awt.Paint[] { var30};
//     java.awt.Paint[] var32 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var33 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Stroke var36 = null;
//     java.awt.Stroke[] var37 = new java.awt.Stroke[] { var36};
//     java.awt.Shape var38 = null;
//     java.awt.Shape[] var39 = new java.awt.Shape[] { var38};
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var31, var32, var33, var35, var37, var39);
//     java.awt.Paint var41 = var40.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     var42.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     var42.setRangeAxis((org.jfree.chart.axis.ValueAxis)var47);
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var50.setCategoryMargin(10.0d);
//     java.awt.Stroke var53 = var50.getAxisLineStroke();
//     var47.setTickMarkStroke(var53);
//     org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker((-1.0d), var41, var53);
//     org.jfree.chart.util.Layer var56 = null;
//     var21.addRangeMarker((org.jfree.chart.plot.Marker)var55, var56);
//     org.jfree.chart.util.Layer var58 = null;
//     boolean var59 = var0.removeRangeMarker(1, (org.jfree.chart.plot.Marker)var55, var58);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, (-11.0d), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.lang.Comparable var4 = null;
//     org.jfree.data.category.CategoryDataset var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var1.getCategorySeriesMiddle(var4, (java.lang.Comparable)4.0d, var6, 0.025d, var8, var9);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    var5.setUpperMargin(0.0d);
    org.jfree.data.Range var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setRange(var10, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var0.indexOf(var8);
    java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
    java.awt.Paint var12 = null;
    java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
    java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var15 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var16 = null;
    java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
    java.awt.Stroke var18 = null;
    java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
    java.awt.Shape var20 = null;
    java.awt.Shape[] var21 = new java.awt.Shape[] { var20};
    org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var14, var15, var17, var19, var21);
    java.awt.Paint var23 = var22.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
    var24.setRangeAxis((org.jfree.chart.axis.ValueAxis)var29);
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var32.setCategoryMargin(10.0d);
    java.awt.Stroke var35 = var32.getAxisLineStroke();
    var29.setTickMarkStroke(var35);
    org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker((-1.0d), var23, var35);
    org.jfree.chart.util.Layer var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var37, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var9 = var8.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     boolean var6 = var0.isDomainZoomable();
//     java.awt.Color var11 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var13.setCategoryMargin(10.0d);
//     java.awt.Stroke var16 = var13.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var11, var16);
//     org.jfree.chart.util.Layer var18 = null;
//     boolean var19 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var17, var18);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    var4.setRangeGridlinesVisible(true);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDatasetRenderingOrder(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var7 = var5.trimWidth(10.0d);
    var0.setLabelPadding(var5);
    double var10 = var5.calculateRightOutset(10.0d);
    double var12 = var5.trimWidth((-1.0d));
    java.awt.geom.Rectangle2D var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var16 = var5.createOutsetRectangle(var13, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-11.0d));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.event.ChartChangeListener var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addChangeListener(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", var3);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 1);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
    var1.setLowerMargin(0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var0.indexOf(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.util.List var12 = null;
    var0.drawDomainTickBands(var10, var11, var12);
    org.jfree.chart.annotations.XYAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)10);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var7 = var5.trimWidth(10.0d);
    var0.setLabelPadding(var5);
    double var10 = var5.calculateRightOutset(10.0d);
    double var12 = var5.trimWidth((-1.0d));
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.LengthAdjustmentType var14 = null;
    org.jfree.chart.util.LengthAdjustmentType var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var16 = var5.createAdjustedRectangle(var13, var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-11.0d));

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.data.general.WaferMapDataset var3 = var2.getDataset();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
//     java.awt.geom.Point2D var12 = var10.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     var2.draw(var4, var5, var12, var13, var14);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, 20.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin(10.0d);
    java.awt.Stroke var5 = var2.getAxisLineStroke();
    var2.configure();
    var2.setLowerMargin(1.0d);
    boolean var9 = var2.isAxisLineVisible();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    boolean var17 = var15.getAutoRangeStickyZero();
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var20 = var18.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var22 = null;
    var18.setRangeAxis(10, var22);
    var15.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var18);
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var15, var25);
    org.jfree.chart.axis.NumberTickUnit var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setTickUnit(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     var4.setRangeAxis(10, var8);
//     int var10 = var4.getWeight();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     int var13 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.plot.SeriesRenderingOrder var14 = var4.getSeriesRenderingOrder();
//     var0.setSeriesRenderingOrder(var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var9);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var12.setCategoryMargin(10.0d);
    java.awt.Stroke var15 = var12.getAxisLineStroke();
    var9.setTickMarkStroke(var15);
    var0.setSectionOutlineStroke((java.lang.Comparable)1L, var15);
    java.awt.Color var21 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    var0.setSeparatorPaint((java.awt.Paint)var21);
    java.awt.Stroke var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeparatorStroke(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    var0.clearRangeAxes();
    org.jfree.chart.axis.ValueAxis var4 = var0.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var3 = var0.getRootPlot();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var6 = var4.getRangeAxis(0);
//     float var7 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers();
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     java.awt.Paint var17 = null;
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
//     java.awt.Paint[] var19 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var20 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var21 = null;
//     java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
//     java.awt.Stroke var23 = null;
//     java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
//     java.awt.Shape var25 = null;
//     java.awt.Shape[] var26 = new java.awt.Shape[] { var25};
//     org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier(var18, var19, var20, var22, var24, var26);
//     java.awt.Paint var28 = var27.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     var29.setRangeAxis((org.jfree.chart.axis.ValueAxis)var34);
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var37.setCategoryMargin(10.0d);
//     java.awt.Stroke var40 = var37.getAxisLineStroke();
//     var34.setTickMarkStroke(var40);
//     org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker((-1.0d), var28, var40);
//     org.jfree.chart.util.Layer var43 = null;
//     var14.addRangeMarker((org.jfree.chart.plot.Marker)var42, var43);
//     org.jfree.chart.util.Layer var45 = null;
//     var4.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var42, var45);
//     org.jfree.chart.util.Layer var47 = null;
//     boolean var48 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var42, var47);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getShadowYOffset();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var4 = var2.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var2.setRangeAxis(0, var6, false);
    var2.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var2.setRangeAxes(var13);
    java.awt.Paint var15 = null;
    java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
    java.awt.Paint[] var17 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var18 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var23 = null;
    java.awt.Shape[] var24 = new java.awt.Shape[] { var23};
    org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var17, var18, var20, var22, var24);
    java.awt.Paint var26 = var25.getNextOutlinePaint();
    var2.setRangeGridlinePaint(var26);
    var0.setLabelShadowPaint(var26);
    var0.setMaximumLabelWidth(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     java.awt.geom.Point2D var12 = var11.getQuadrantOrigin();
//     var4.zoomDomainAxes(1.0d, var6, var12);
//     var0.zoomDomainAxes(1.0d, 0.0d, var3, var12);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     var18.setRenderer(0, var20);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     java.awt.geom.Point2D var29 = var28.getQuadrantOrigin();
//     var18.zoomRangeAxes((-1.0d), var23, var29, false);
//     var0.zoomDomainAxes(100.0d, 0.0d, var17, var29);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var28
//     assertTrue("Contract failed: equals-hashcode on var11 and var28", var11.equals(var28) ? var11.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var11
//     assertTrue("Contract failed: equals-hashcode on var28 and var11", var28.equals(var11) ? var28.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    java.awt.Paint var1 = null;
    java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
    java.awt.Paint[] var3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var3, var4, var6, var8, var10);
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    var13.setRangeAxis((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var21.setCategoryMargin(10.0d);
    java.awt.Stroke var24 = var21.getAxisLineStroke();
    var18.setTickMarkStroke(var24);
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker((-1.0d), var12, var24);
    org.jfree.chart.text.TextAnchor var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.setLabelTextAnchor(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.geom.Point2D var6 = var4.getQuadrantOrigin();
    var4.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var4.setFixedRangeAxisSpace(var9, true);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var13);
    float var15 = var4.getBackgroundImageAlpha();
    org.jfree.chart.util.RectangleEdge var16 = var4.getDomainAxisEdge();
    org.jfree.chart.axis.AxisSpace var17 = null;
    var4.setFixedDomainAxisSpace(var17, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Category Plot", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     boolean var4 = var0.isDomainGridlinesVisible();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     java.awt.geom.Point2D var15 = var14.getQuadrantOrigin();
//     var7.zoomDomainAxes(1.0d, var9, var15);
//     org.jfree.chart.plot.PlotState var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var0.draw(var5, var6, var15, var17, var18);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getShadowYOffset();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var4 = var2.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var2.setRangeAxis(0, var6, false);
    var2.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var2.setRangeAxes(var13);
    java.awt.Paint var15 = null;
    java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
    java.awt.Paint[] var17 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var18 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var23 = null;
    java.awt.Shape[] var24 = new java.awt.Shape[] { var23};
    org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var17, var18, var20, var22, var24);
    java.awt.Paint var26 = var25.getNextOutlinePaint();
    var2.setRangeGridlinePaint(var26);
    var0.setLabelShadowPaint(var26);
    org.jfree.chart.labels.PieToolTipGenerator var29 = null;
    var0.setToolTipGenerator(var29);
    org.jfree.chart.util.RectangleInsets var31 = var0.getSimpleLabelOffset();
    java.awt.geom.Rectangle2D var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var35 = var31.createInsetRectangle(var32, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var0.setSimpleLabelOffset(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var10 = var9.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var9.setSimpleLabelOffset(var15);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
//     var18.setWidth(20.0d);
//     var18.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var17.addSubtitle((org.jfree.chart.title.Title)var18);
//     java.lang.Object var24 = var18.clone();
//     var8.setTitle(var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var3 = var2.darker();
//     java.awt.color.ColorSpace var4 = null;
//     float[] var8 = new float[] { 1.0f, 100.0f, (-1.0f)};
//     float[] var9 = var2.getColorComponents(var4, var8);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var1);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.lang.Number[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var2);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.event.PlotChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedRangeAxisSpace(var3);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    var3.setRangeAxis((org.jfree.chart.axis.ValueAxis)var8);
    boolean var10 = var8.getAutoRangeStickyZero();
    var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var8);
    java.lang.Object var12 = var0.clone();
    var0.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, (-1.0f), 0.5f, var4, 10.0d, 1.0f, 0.5f);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    var3.setRangeAxis((org.jfree.chart.axis.ValueAxis)var8);
    boolean var10 = var8.getAutoRangeStickyZero();
    var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.data.Range var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setRangeWithMargins(var12, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     java.awt.geom.Point2D var12 = var11.getQuadrantOrigin();
//     var4.zoomDomainAxes(1.0d, var6, var12);
//     var0.zoomDomainAxes(1.0d, 0.0d, var3, var12);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
//     var15.setRangeAxis((org.jfree.chart.axis.ValueAxis)var20);
//     boolean var22 = var20.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var25 = var23.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     var23.setRangeAxis(10, var27);
//     var20.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     var0.setAxis((org.jfree.chart.axis.ValueAxis)var20);
//     
//     // Checks the contract:  equals-hashcode on var11 and var23
//     assertTrue("Contract failed: equals-hashcode on var11 and var23", var11.equals(var23) ? var11.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var11
//     assertTrue("Contract failed: equals-hashcode on var23 and var11", var23.equals(var11) ? var23.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     var0.setDataset(var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.data.Range var4 = var0.getDataRange(var3);
//     java.lang.String var5 = var0.getPlotType();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
//     java.awt.geom.Point2D var12 = var10.getQuadrantOrigin();
//     var10.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var15 = null;
//     var10.setFixedRangeAxisSpace(var15, true);
//     java.awt.Paint var19 = null;
//     java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
//     java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var22 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var23 = null;
//     java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Shape var27 = null;
//     java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
//     org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var21, var22, var24, var26, var28);
//     java.awt.Paint var30 = var29.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     var31.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     var31.setRangeAxis((org.jfree.chart.axis.ValueAxis)var36);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var39.setCategoryMargin(10.0d);
//     java.awt.Stroke var42 = var39.getAxisLineStroke();
//     var36.setTickMarkStroke(var42);
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker((-1.0d), var30, var42);
//     org.jfree.chart.util.Layer var45 = null;
//     var10.addRangeMarker((org.jfree.chart.plot.Marker)var44, var45);
//     org.jfree.chart.util.Layer var47 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var44, var47);
//     org.jfree.chart.event.MarkerChangeEvent var49 = null;
//     var44.notifyListeners(var49);
//     org.jfree.chart.event.MarkerChangeEvent var51 = null;
//     var44.notifyListeners(var51);
//     java.lang.Class var53 = null;
//     java.util.EventListener[] var54 = var44.getListeners(var53);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     var0.setDataset(var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.data.Range var4 = var0.getDataRange(var3);
//     boolean var5 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var0.setFixedRangeAxisSpace(var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     java.awt.geom.Point2D var19 = var18.getQuadrantOrigin();
//     var11.zoomDomainAxes(1.0d, var13, var19);
//     var0.zoomDomainAxes(4.0d, 0.025d, var10, var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var6, 0, 0);
    org.jfree.chart.JFreeChart var10 = null;
    var9.setChart(var10);
    int var12 = var9.getPercent();
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var14 = var13.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var13.setSimpleLabelOffset(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    var22.setWidth(20.0d);
    var22.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var21.addSubtitle((org.jfree.chart.title.Title)var22);
    var9.setChart(var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var29 = var21.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var0.getLabelGenerator();
    double var10 = var0.getLabelLinkMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.025d);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var1 = var0.getRadiusGridlineStroke();
//     java.awt.Stroke var2 = var0.getAngleGridlineStroke();
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.Point var6 = var0.translateValueThetaRadiusToJava2D(100.0d, 1.0d, var5);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    var0.setDataset(var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.data.Range var4 = var0.getDataRange(var3);
    java.lang.String var5 = var0.getPlotType();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    java.awt.geom.Point2D var12 = var10.getQuadrantOrigin();
    var10.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var10.setFixedRangeAxisSpace(var15, true);
    java.awt.Paint var19 = null;
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var22 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var23 = null;
    java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Shape var27 = null;
    java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var21, var22, var24, var26, var28);
    java.awt.Paint var30 = var29.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    var31.setRangeAxis((org.jfree.chart.axis.ValueAxis)var36);
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var39.setCategoryMargin(10.0d);
    java.awt.Stroke var42 = var39.getAxisLineStroke();
    var36.setTickMarkStroke(var42);
    org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker((-1.0d), var30, var42);
    org.jfree.chart.util.Layer var45 = null;
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var44, var45);
    org.jfree.chart.util.Layer var47 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var44, var47);
    org.jfree.chart.event.MarkerChangeEvent var49 = null;
    var44.notifyListeners(var49);
    org.jfree.chart.event.MarkerChangeEvent var51 = null;
    var44.notifyListeners(var51);
    org.jfree.chart.text.TextAnchor var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var44.setLabelTextAnchor(var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Category Plot"+ "'", var5.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2);
//     org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var5.setRangeAxis(0, var7, true);
//     org.jfree.chart.ui.BasicProjectInfo var14 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var14.setLicenceName("hi!");
//     boolean var17 = var5.equals((java.lang.Object)"hi!");
//     java.lang.String var18 = var5.getPlotType();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var22 = var20.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var23 = var20.getRootPlot();
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     var25.setRangeAxis(10, var29);
//     java.awt.Stroke var31 = null;
//     var25.setOutlineStroke(var31);
//     java.awt.Image var33 = null;
//     var25.setBackgroundImage(var33);
//     java.awt.Paint var36 = null;
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var36};
//     java.awt.Paint[] var38 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var39 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var40 = null;
//     java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
//     java.awt.Stroke var42 = null;
//     java.awt.Stroke[] var43 = new java.awt.Stroke[] { var42};
//     java.awt.Shape var44 = null;
//     java.awt.Shape[] var45 = new java.awt.Shape[] { var44};
//     org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier(var37, var38, var39, var41, var43, var45);
//     java.awt.Paint var47 = var46.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     var48.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     var48.setRangeAxis((org.jfree.chart.axis.ValueAxis)var53);
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var56.setCategoryMargin(10.0d);
//     java.awt.Stroke var59 = var56.getAxisLineStroke();
//     var53.setTickMarkStroke(var59);
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker((-1.0d), var47, var59);
//     var25.setDomainZeroBaselineStroke(var59);
//     org.jfree.chart.axis.AxisLocation var63 = var25.getRangeAxisLocation();
//     var20.setDomainAxisLocation(10, var63);
//     var5.setRangeAxisLocation(10, var63, false);
//     var0.setDomainAxisLocation(var63, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var5.", var0.equals(var5) == var5.equals(var0));
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var3 = var0.getRootPlot();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    org.jfree.chart.plot.CrosshairState var8 = null;
    boolean var9 = var0.render(var4, var5, 0, var7, var8);
    var0.setOutlineVisible(false);
    org.jfree.chart.annotations.XYAnnotation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    var5.setAutoRangeStickyZero(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    java.awt.Shape var17 = var15.getDownArrow();
    var5.setDownArrow(var17);
    org.jfree.chart.plot.Plot var19 = var5.getPlot();
    org.jfree.data.Range var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setRangeWithMargins(var20, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     int var6 = var0.getWeight();
//     org.jfree.chart.util.Layer var7 = null;
//     java.util.Collection var8 = var0.getRangeMarkers(var7);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var11 = var9.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     var9.setRangeAxis(10, var13);
//     int var15 = var9.getWeight();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     int var18 = var9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var17);
//     org.jfree.chart.plot.SeriesRenderingOrder var19 = var9.getSeriesRenderingOrder();
//     var0.setSeriesRenderingOrder(var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    java.awt.Image var8 = null;
    var0.setBackgroundImage(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.CrosshairState var14 = null;
    boolean var15 = var0.render(var10, var11, 0, var13, var14);
    java.awt.Paint var16 = var0.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     var0.setDataset(var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.data.Range var4 = var0.getDataRange(var3);
//     boolean var5 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var0.setFixedRangeAxisSpace(var6);
//     java.awt.Stroke var8 = var0.getRangeGridlineStroke();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawBackground(var9, var10);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    var0.setDataset(var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.data.Range var4 = var0.getDataRange(var3);
    java.lang.String var5 = var0.getPlotType();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    java.awt.geom.Point2D var12 = var10.getQuadrantOrigin();
    var10.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var10.setFixedRangeAxisSpace(var15, true);
    java.awt.Paint var19 = null;
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var22 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var23 = null;
    java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Shape var27 = null;
    java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var21, var22, var24, var26, var28);
    java.awt.Paint var30 = var29.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    var31.setRangeAxis((org.jfree.chart.axis.ValueAxis)var36);
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var39.setCategoryMargin(10.0d);
    java.awt.Stroke var42 = var39.getAxisLineStroke();
    var36.setTickMarkStroke(var42);
    org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker((-1.0d), var30, var42);
    org.jfree.chart.util.Layer var45 = null;
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var44, var45);
    org.jfree.chart.util.Layer var47 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var44, var47);
    org.jfree.chart.event.MarkerChangeEvent var49 = null;
    var44.notifyListeners(var49);
    java.awt.Paint var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var44.setLabelPaint(var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Category Plot"+ "'", var5.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 1.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-65536));

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var0.setSimpleLabelOffset(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     var9.setWidth(20.0d);
//     var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var8.addSubtitle((org.jfree.chart.title.Title)var9);
//     boolean var16 = var8.equals((java.lang.Object)(byte)1);
//     java.util.List var17 = null;
//     var8.setSubtitles(var17);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     int var6 = var0.getWeight();
//     org.jfree.chart.util.Layer var7 = null;
//     java.util.Collection var8 = var0.getRangeMarkers(var7);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var11 = var9.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var12 = var9.getRootPlot();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var16 = var14.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     var14.setRangeAxis(10, var18);
//     java.awt.Stroke var20 = null;
//     var14.setOutlineStroke(var20);
//     java.awt.Image var22 = null;
//     var14.setBackgroundImage(var22);
//     java.awt.Paint var25 = null;
//     java.awt.Paint[] var26 = new java.awt.Paint[] { var25};
//     java.awt.Paint[] var27 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var28 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var29 = null;
//     java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
//     java.awt.Stroke var31 = null;
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     java.awt.Shape var33 = null;
//     java.awt.Shape[] var34 = new java.awt.Shape[] { var33};
//     org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var26, var27, var28, var30, var32, var34);
//     java.awt.Paint var36 = var35.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     var37.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var37.setRangeAxis((org.jfree.chart.axis.ValueAxis)var42);
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var45.setCategoryMargin(10.0d);
//     java.awt.Stroke var48 = var45.getAxisLineStroke();
//     var42.setTickMarkStroke(var48);
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker((-1.0d), var36, var48);
//     var14.setDomainZeroBaselineStroke(var48);
//     org.jfree.chart.axis.AxisLocation var52 = var14.getRangeAxisLocation();
//     var9.setDomainAxisLocation(10, var52);
//     var0.setRangeAxisLocation(var52, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var9.", var0.equals(var9) == var9.equals(var0));
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryMargin(10.0d);
//     java.awt.Stroke var5 = var2.getAxisLineStroke();
//     boolean var6 = var0.equals((java.lang.Object)var2);
//     org.jfree.data.category.CategoryDataset var9 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var14 = var12.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var15 = var12.getRootPlot();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     org.jfree.chart.plot.CrosshairState var20 = null;
//     boolean var21 = var12.render(var16, var17, 0, var19, var20);
//     java.awt.Paint var23 = var12.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var25 = var12.getRangeAxisEdge(100);
//     double var26 = var2.getCategorySeriesMiddle((java.lang.Comparable)'a', (java.lang.Comparable)(byte)100, var9, (-1.0d), var11, var25);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.awt.Paint var1 = null;
    java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
    java.awt.Paint[] var3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var3, var4, var6, var8, var10);
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    var13.setRangeAxis((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var21.setCategoryMargin(10.0d);
    java.awt.Stroke var24 = var21.getAxisLineStroke();
    var18.setTickMarkStroke(var24);
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker((-1.0d), var12, var24);
    java.awt.Paint var27 = var26.getLabelPaint();
    org.jfree.chart.text.TextAnchor var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.setLabelTextAnchor(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    java.lang.Object var15 = var9.clone();
    java.awt.Graphics2D var16 = null;
    org.jfree.data.Range var18 = null;
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(0.0d, var18);
    org.jfree.data.Range var20 = var19.getHeightRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var21 = var9.arrange(var16, var19);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    java.awt.Image var8 = null;
    var0.setBackgroundImage(var8);
    java.awt.Paint var11 = null;
    java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
    java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
    java.awt.Paint var22 = var21.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var31.setCategoryMargin(10.0d);
    java.awt.Stroke var34 = var31.getAxisLineStroke();
    var28.setTickMarkStroke(var34);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker((-1.0d), var22, var34);
    var0.setDomainZeroBaselineStroke(var34);
    org.jfree.chart.axis.AxisLocation var38 = var0.getRangeAxisLocation();
    org.jfree.chart.plot.PlotOrientation var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var40 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var38, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("XY Plot", 100, 0);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     int var6 = var0.getWeight();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     int var9 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var12 = var10.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     var10.setRangeAxis(10, var14);
//     int var16 = var10.getWeight();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     int var19 = var10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var18);
//     var18.setInverted(false);
//     boolean var22 = var0.equals((java.lang.Object)false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var0.handleClick(1, 0, var6);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     var0.clearDomainMarkers();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
//     java.awt.Paint var13 = null;
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     java.awt.Paint[] var15 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var16 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var21 = null;
//     java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
//     org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var15, var16, var18, var20, var22);
//     java.awt.Paint var24 = var23.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setRangeAxis((org.jfree.chart.axis.ValueAxis)var30);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var33.setCategoryMargin(10.0d);
//     java.awt.Stroke var36 = var33.getAxisLineStroke();
//     var30.setTickMarkStroke(var36);
//     org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker((-1.0d), var24, var36);
//     org.jfree.chart.util.Layer var39 = null;
//     var10.addRangeMarker((org.jfree.chart.plot.Marker)var38, var39);
//     org.jfree.chart.util.Layer var41 = null;
//     var0.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var38, var41);
//     java.lang.Class var43 = null;
//     java.util.EventListener[] var44 = var38.getListeners(var43);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     org.jfree.chart.block.BlockContainer var22 = null;
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(4.0d, 1.0d);
//     org.jfree.chart.util.Size2D var27 = var15.arrange(var22, var23, var26);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     var1.configure();
//     var1.setLowerMargin(1.0d);
//     int var8 = var1.getMaximumCategoryLabelLines();
//     org.jfree.chart.axis.CategoryLabelPositions var9 = var1.getCategoryLabelPositions();
//     int var10 = var1.getCategoryLabelPositionOffset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.AxisState var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var16 = var14.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var17 = var14.getRootPlot();
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.chart.plot.CrosshairState var22 = null;
//     boolean var23 = var14.render(var18, var19, 0, var21, var22);
//     java.awt.Paint var25 = var14.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var27 = var14.getRangeAxisEdge(100);
//     java.util.List var28 = var1.refreshTicks(var11, var12, var13, var27);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
    var1.setFixedDimension(100.0d);
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot();
    double var9 = var7.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var10 = null;
    var7.markerChanged(var10);
    boolean var12 = var1.hasListener((java.util.EventListener)var7);
    var1.setLowerMargin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryMargin(10.0d);
//     java.awt.Stroke var5 = var2.getAxisLineStroke();
//     boolean var6 = var0.equals((java.lang.Object)var2);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var9 = var7.getDomainAxis((-1));
//     var7.clearRangeAxes();
//     var2.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var20 = var17.getRootPlot();
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.chart.plot.CrosshairState var25 = null;
//     boolean var26 = var17.render(var21, var22, 0, var24, var25);
//     java.awt.Paint var28 = var17.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var30 = var17.getRangeAxisEdge(100);
//     double var31 = var2.getCategorySeriesMiddle((java.lang.Comparable)0.0d, (java.lang.Comparable)6.25d, var14, 0.025d, var16, var30);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     java.awt.geom.Point2D var12 = var11.getQuadrantOrigin();
//     var0.zoomRangeAxes(100.0d, var6, var12, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    java.awt.Stroke var22 = var13.getBorderStroke();
    var13.setNotify(false);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var29 = null;
    var25.setRangeAxis(10, var29);
    boolean var31 = var25.isDomainZoomable();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setTextAntiAlias((java.lang.Object)var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    org.jfree.chart.util.RectangleInsets var22 = var13.getPadding();
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var30 = var28.trimWidth(10.0d);
    var23.setLabelPadding(var28);
    double var33 = var28.calculateRightOutset(10.0d);
    var13.setPadding(var28);
    org.jfree.chart.event.ChartChangeListener var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.addChangeListener(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     double var2 = var1.getShadowYOffset();
//     double var3 = var1.getShadowYOffset();
//     java.awt.Font var4 = var1.getLabelFont();
//     java.awt.Font var5 = var1.getLabelFont();
//     java.awt.Paint var7 = null;
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
//     java.awt.Paint[] var9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var10 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var11 = null;
//     java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
//     java.awt.Stroke var13 = null;
//     java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
//     java.awt.Shape var15 = null;
//     java.awt.Shape[] var16 = new java.awt.Shape[] { var15};
//     org.jfree.chart.plot.DefaultDrawingSupplier var17 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var9, var10, var12, var14, var16);
//     java.awt.Paint var18 = var17.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     var19.setRangeAxis((org.jfree.chart.axis.ValueAxis)var24);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var27.setCategoryMargin(10.0d);
//     java.awt.Stroke var30 = var27.getAxisLineStroke();
//     var24.setTickMarkStroke(var30);
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker((-1.0d), var18, var30);
//     org.jfree.chart.text.TextMeasurer var35 = null;
//     org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var5, var18, 0.5f, (-65536), var35);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.geom.Point2D var6 = var5.getQuadrantOrigin();
    java.awt.geom.Point2D var7 = var5.getQuadrantOrigin();
    var5.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var5.setFixedRangeAxisSpace(var10, true);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var14, var16, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     org.jfree.chart.block.BlockContainer var22 = null;
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.block.RectangleConstraint var24 = null;
//     org.jfree.chart.util.Size2D var25 = var15.arrange(var22, var23, var24);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.setCategoryMargin(10.0d);
    java.awt.Stroke var9 = var6.getAxisLineStroke();
    var6.configure();
    var6.setLowerMargin(1.0d);
    var0.setDomainAxis(1, var6);
    var6.setAxisLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var6.setCategoryMargin(10.0d);
//     java.awt.Stroke var9 = var6.getAxisLineStroke();
//     var6.configure();
//     var6.setLowerMargin(1.0d);
//     var0.setDomainAxis(1, var6);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var18 = var16.getRangeAxis(0);
//     org.jfree.data.general.DatasetGroup var19 = var16.getDatasetGroup();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
//     java.awt.geom.Point2D var28 = var27.getQuadrantOrigin();
//     java.awt.geom.Point2D var29 = var27.getQuadrantOrigin();
//     var16.zoomRangeAxes(90.0d, 4.0d, var22, var29);
//     org.jfree.chart.plot.PlotState var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     var0.draw(var14, var15, var29, var31, var32);
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]", "", var3);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=false]", var1, var2);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var5 = null;
    var4.setDataset(var5);
    boolean var7 = var3.equals((java.lang.Object)var4);
    float[] var10 = new float[] { 10.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var11 = var3.getColorComponents(var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", var1, 0.5f, 10.0f, 0.0d, 0.5f, 10.0f);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var0.setSimpleLabelOffset(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     var9.setWidth(20.0d);
//     var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var8.addSubtitle((org.jfree.chart.title.Title)var9);
//     org.jfree.chart.event.ChartProgressListener var15 = null;
//     var8.removeProgressListener(var15);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var8.draw(var17, var18);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var5 = var2.toRangeHeight(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setURLText("");
    var0.setPadding(4.0d, 0.025d, 0.0d, (-1.0d));
    org.jfree.chart.util.VerticalAlignment var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setVerticalAlignment(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
//     java.awt.geom.Point2D var8 = var7.getQuadrantOrigin();
//     org.jfree.chart.JFreeChart var9 = null;
//     org.jfree.chart.event.ChartProgressEvent var12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var8, var9, 0, 0);
//     org.jfree.chart.plot.PlotState var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     var0.draw(var1, var2, var8, var13, var14);
// 
//   }

//  public void test147() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    java.awt.Image var8 = null;
    var0.setBackgroundImage(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.CrosshairState var14 = null;
    boolean var15 = var0.render(var10, var11, 0, var13, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var17 = var0.getDomainAxisForDataset((-65536));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var6 = var5.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var5.setSimpleLabelOffset(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
//     var14.setWidth(20.0d);
//     var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var13.addSubtitle((org.jfree.chart.title.Title)var14);
//     org.jfree.chart.event.ChartChangeEventType var20 = null;
//     org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
//     org.jfree.chart.event.PlotChangeEvent var22 = null;
//     var13.plotChanged(var22);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = var4.get(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     double var2 = var1.getShadowYOffset();
//     double var3 = var1.getShadowYOffset();
//     java.awt.Font var4 = var1.getLabelFont();
//     java.awt.Font var5 = var1.getLabelFont();
//     org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("", var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.text.TextAnchor var8 = null;
//     float var9 = var6.calculateBaselineOffset(var7, var8);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxisForDataset(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    java.util.List var3 = var0.getCategories();
    org.jfree.chart.util.RectangleEdge var5 = var0.getRangeAxisEdge(10);
    org.jfree.chart.plot.CategoryMarker var6 = null;
    org.jfree.chart.util.Layer var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    java.awt.Stroke var22 = var13.getBorderStroke();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
    var23.setWidth(20.0d);
    var23.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var23.setURLText("Category Plot");
    var13.removeSubtitle((org.jfree.chart.title.Title)var23);
    org.jfree.chart.event.ChartChangeListener var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.addChangeListener(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var0.setSimpleLabelOffset(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     var9.setWidth(20.0d);
//     var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var8.addSubtitle((org.jfree.chart.title.Title)var9);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var16.setCategoryMargin(10.0d);
//     java.awt.Stroke var19 = var16.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var21 = var20.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var20.setSimpleLabelOffset(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle();
//     var29.setWidth(20.0d);
//     var29.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var28.addSubtitle((org.jfree.chart.title.Title)var29);
//     org.jfree.chart.event.ChartChangeEventType var35 = null;
//     org.jfree.chart.event.ChartChangeEvent var36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16, var28, var35);
//     java.awt.Stroke var37 = var28.getBorderStroke();
//     org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle();
//     var38.setWidth(20.0d);
//     var38.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var38.setURLText("Category Plot");
//     var28.removeSubtitle((org.jfree.chart.title.Title)var38);
//     var8.removeSubtitle((org.jfree.chart.title.Title)var38);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.geom.Point2D var6 = var5.getQuadrantOrigin();
    java.awt.geom.Point2D var7 = var5.getQuadrantOrigin();
    var5.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var5.setFixedRangeAxisSpace(var10, true);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var14, var16, var17);
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var20 = var19.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var19.setSimpleLabelOffset(var25);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
    var28.setWidth(20.0d);
    var28.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var27.addSubtitle((org.jfree.chart.title.Title)var28);
    java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    var27.setBackgroundPaint((java.awt.Paint)var37);
    var18.setOutlinePaint((java.awt.Paint)var37);
    double var40 = var18.getDomainCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1);
    double var3 = var2.getWidth();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedHeight((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint[] var2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Shape var8 = null;
//     java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var2, var3, var5, var7, var9);
//     java.awt.Paint[] var11 = null;
//     java.awt.Paint var12 = null;
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var15 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var16 = null;
//     java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
//     java.awt.Stroke var18 = null;
//     java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
//     java.awt.Shape var20 = null;
//     java.awt.Shape[] var21 = new java.awt.Shape[] { var20};
//     org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var14, var15, var17, var19, var21);
//     java.awt.Paint var23 = null;
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
//     java.awt.Paint[] var25 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var26 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Stroke var29 = null;
//     java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
//     java.awt.Shape var31 = null;
//     java.awt.Shape[] var32 = new java.awt.Shape[] { var31};
//     org.jfree.chart.plot.DefaultDrawingSupplier var33 = new org.jfree.chart.plot.DefaultDrawingSupplier(var24, var25, var26, var28, var30, var32);
//     java.awt.Paint var34 = null;
//     java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
//     java.awt.Paint[] var36 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var37 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var38 = null;
//     java.awt.Stroke[] var39 = new java.awt.Stroke[] { var38};
//     java.awt.Stroke var40 = null;
//     java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
//     java.awt.Shape var42 = null;
//     java.awt.Shape[] var43 = new java.awt.Shape[] { var42};
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier(var35, var36, var37, var39, var41, var43);
//     java.awt.Paint var45 = null;
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var45};
//     java.awt.Paint[] var47 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var48 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var49 = null;
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
//     java.awt.Stroke var51 = null;
//     java.awt.Stroke[] var52 = new java.awt.Stroke[] { var51};
//     java.awt.Shape var53 = null;
//     java.awt.Shape[] var54 = new java.awt.Shape[] { var53};
//     org.jfree.chart.plot.DefaultDrawingSupplier var55 = new org.jfree.chart.plot.DefaultDrawingSupplier(var46, var47, var48, var50, var52, var54);
//     org.jfree.chart.plot.DefaultDrawingSupplier var56 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var11, var15, var30, var41, var54);
//     
//     // Checks the contract:  equals-hashcode on var10 and var22
//     assertTrue("Contract failed: equals-hashcode on var10 and var22", var10.equals(var22) ? var10.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var33
//     assertTrue("Contract failed: equals-hashcode on var10 and var33", var10.equals(var33) ? var10.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var44
//     assertTrue("Contract failed: equals-hashcode on var10 and var44", var10.equals(var44) ? var10.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var55
//     assertTrue("Contract failed: equals-hashcode on var10 and var55", var10.equals(var55) ? var10.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var10
//     assertTrue("Contract failed: equals-hashcode on var22 and var10", var22.equals(var10) ? var22.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var33
//     assertTrue("Contract failed: equals-hashcode on var22 and var33", var22.equals(var33) ? var22.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var44
//     assertTrue("Contract failed: equals-hashcode on var22 and var44", var22.equals(var44) ? var22.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var55
//     assertTrue("Contract failed: equals-hashcode on var22 and var55", var22.equals(var55) ? var22.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var10
//     assertTrue("Contract failed: equals-hashcode on var33 and var10", var33.equals(var10) ? var33.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var22
//     assertTrue("Contract failed: equals-hashcode on var33 and var22", var33.equals(var22) ? var33.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var44
//     assertTrue("Contract failed: equals-hashcode on var33 and var44", var33.equals(var44) ? var33.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var55
//     assertTrue("Contract failed: equals-hashcode on var33 and var55", var33.equals(var55) ? var33.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var10
//     assertTrue("Contract failed: equals-hashcode on var44 and var10", var44.equals(var10) ? var44.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var22
//     assertTrue("Contract failed: equals-hashcode on var44 and var22", var44.equals(var22) ? var44.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var33
//     assertTrue("Contract failed: equals-hashcode on var44 and var33", var44.equals(var33) ? var44.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var55
//     assertTrue("Contract failed: equals-hashcode on var44 and var55", var44.equals(var55) ? var44.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var10
//     assertTrue("Contract failed: equals-hashcode on var55 and var10", var55.equals(var10) ? var55.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var22
//     assertTrue("Contract failed: equals-hashcode on var55 and var22", var55.equals(var22) ? var55.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var33
//     assertTrue("Contract failed: equals-hashcode on var55 and var33", var55.equals(var33) ? var55.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var44
//     assertTrue("Contract failed: equals-hashcode on var55 and var44", var55.equals(var44) ? var55.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.util.Rotation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDirection(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 6.25d, 10.0d, 1, (java.lang.Comparable)6.25d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", 100, 100);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    double var3 = var0.getLabelGap();
    java.awt.Paint var4 = var0.getShadowPaint();
    java.awt.Stroke var5 = var0.getSeparatorStroke();
    var0.setSeparatorsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.configure();
    var1.setLowerMargin(1.0d);
    boolean var8 = var1.isAxisLineVisible();
    var1.setMaximumCategoryLabelLines(255);
    java.lang.Comparable var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var12 = var1.getTickLabelPaint(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.geom.Point2D var6 = var4.getQuadrantOrigin();
    var4.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var6 = null;
    java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
    java.awt.Paint[] var8 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var10 = null;
    java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
    java.awt.Stroke var12 = null;
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    java.awt.Shape var14 = null;
    java.awt.Shape[] var15 = new java.awt.Shape[] { var14};
    org.jfree.chart.plot.DefaultDrawingSupplier var16 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var8, var9, var11, var13, var15);
    java.awt.Paint var17 = var16.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    var18.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var26.setCategoryMargin(10.0d);
    java.awt.Stroke var29 = var26.getAxisLineStroke();
    var23.setTickMarkStroke(var29);
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker((-1.0d), var17, var29);
    var4.setRangeGridlinePaint(var17);
    org.jfree.chart.plot.PlotOrientation var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setOrientation(var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     var1.configure();
//     var1.setLowerMargin(1.0d);
//     boolean var8 = var1.isAxisLineVisible();
//     var1.setMaximumCategoryLabelLines(255);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     var15.setRangeAxis(10, var19);
//     java.awt.Stroke var21 = null;
//     var15.setOutlineStroke(var21);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     var15.setRenderer(1, var24);
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.FlowArrangement var30 = new org.jfree.chart.block.FlowArrangement(var26, var27, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15, (org.jfree.chart.block.Arrangement)var30, (org.jfree.chart.block.Arrangement)var35);
//     boolean var38 = var36.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var41 = var39.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var42 = var39.getRootPlot();
//     java.awt.Graphics2D var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     org.jfree.chart.plot.CrosshairState var47 = null;
//     boolean var48 = var39.render(var43, var44, 0, var46, var47);
//     java.awt.Paint var50 = var39.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var52 = var39.getRangeAxisEdge(100);
//     var36.setPosition(var52);
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     org.jfree.chart.axis.AxisState var55 = var1.draw(var11, 90.0d, var13, var14, var52, var54);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var6 = var4.extendWidth(10.0d);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var4.createInsetRectangle(var7, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 20.0d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets(0.14d, 0.05d, 90.0d, (-11.0d));
    var1.setTickLabelInsets(var6);
    org.jfree.data.RangeType var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeType(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     org.jfree.data.general.DatasetGroup var3 = var0.getDatasetGroup();
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(1, var5);
//     org.jfree.chart.util.Layer var7 = null;
//     java.util.Collection var8 = var0.getDomainMarkers(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     java.awt.geom.Point2D var16 = var15.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var0.draw(var9, var10, var16, var17, var18);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin(10.0d);
    java.awt.Stroke var5 = var2.getAxisLineStroke();
    var0.setLabelLinkStroke(var5);
    org.jfree.chart.event.PlotChangeListener var7 = null;
    var0.removeChangeListener(var7);
    org.jfree.data.general.PieDataset var9 = null;
    var0.setDataset(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    float var3 = var0.getBackgroundImageAlpha();
    var0.clearDomainMarkers();
    org.jfree.data.category.CategoryDataset var6 = var0.getDataset((-65536));
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    org.jfree.chart.axis.CategoryAnchor var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePosition(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    org.jfree.chart.plot.PlotOrientation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setOrientation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     java.util.List var3 = var0.getCategories();
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.geom.Point2D var10 = var9.getQuadrantOrigin();
//     java.awt.geom.Point2D var11 = var9.getQuadrantOrigin();
//     var9.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var14 = null;
//     var9.setFixedRangeAxisSpace(var14, true);
//     java.awt.Paint var18 = null;
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
//     java.awt.Paint[] var20 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Stroke var24 = null;
//     java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
//     java.awt.Shape var26 = null;
//     java.awt.Shape[] var27 = new java.awt.Shape[] { var26};
//     org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier(var19, var20, var21, var23, var25, var27);
//     java.awt.Paint var29 = var28.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setRangeAxis((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var38.setCategoryMargin(10.0d);
//     java.awt.Stroke var41 = var38.getAxisLineStroke();
//     var35.setTickMarkStroke(var41);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker((-1.0d), var29, var41);
//     org.jfree.chart.util.Layer var44 = null;
//     var9.addRangeMarker((org.jfree.chart.plot.Marker)var43, var44);
//     java.lang.String var46 = var43.getLabel();
//     org.jfree.chart.util.Layer var47 = null;
//     boolean var48 = var0.removeRangeMarker(100, (org.jfree.chart.plot.Marker)var43, var47);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    double var3 = var0.getLabelGap();
    java.awt.Paint var4 = var0.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    java.awt.Paint var1 = null;
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var4 = var2.getDomainAxis((-1));
    boolean var5 = var2.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var9.setRangeAxis((org.jfree.chart.axis.ValueAxis)var14);
    boolean var16 = var14.getAutoRangeStickyZero();
    var6.setDomainAxis((org.jfree.chart.axis.ValueAxis)var14);
    var2.setRangeAxis((org.jfree.chart.axis.ValueAxis)var14);
    java.awt.Stroke var19 = var14.getTickMarkStroke();
    java.awt.Color var23 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var25 = var24.getAngleGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker((-1.0d), var1, var19, (java.awt.Paint)var23, var25, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var4.setCategoryMargin(10.0d);
//     java.awt.Stroke var7 = var4.getAxisLineStroke();
//     var4.configure();
//     var4.setLowerMargin(1.0d);
//     boolean var11 = var4.isAxisLineVisible();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var17);
//     boolean var19 = var17.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var22 = var20.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var20.setRangeAxis(10, var24);
//     var17.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var2, var4, (org.jfree.chart.axis.ValueAxis)var17, var27);
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot();
//     double var31 = var29.getExplodePercent((java.lang.Comparable)10L);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     var33.setRangeAxis((org.jfree.chart.axis.ValueAxis)var38);
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var41.setCategoryMargin(10.0d);
//     java.awt.Stroke var44 = var41.getAxisLineStroke();
//     var38.setTickMarkStroke(var44);
//     var29.setSectionOutlineStroke((java.lang.Comparable)1L, var44);
//     org.jfree.chart.plot.AbstractPieLabelDistributor var47 = var29.getLabelDistributor();
//     double var48 = var29.getShadowXOffset();
//     java.awt.Paint var49 = var29.getLabelPaint();
//     var17.setTickMarkPaint(var49);
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.text.G2TextMeasurer var54 = new org.jfree.chart.text.G2TextMeasurer(var53);
//     org.jfree.chart.text.TextBlock var55 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]", var1, var49, 0.0f, (-65536), (org.jfree.chart.text.TextMeasurer)var54);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    java.awt.Paint var9 = null;
    var0.setLabelOutlinePaint(var9);
    java.awt.Paint var12 = var0.getSectionPaint((java.lang.Comparable)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     var0.zoom(0.05d);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     var0.setDataset(var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.data.Range var4 = var0.getDataRange(var3);
//     java.lang.String var5 = var0.getPlotType();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
//     java.awt.geom.Point2D var12 = var10.getQuadrantOrigin();
//     var10.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var15 = null;
//     var10.setFixedRangeAxisSpace(var15, true);
//     java.awt.Paint var19 = null;
//     java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
//     java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var22 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var23 = null;
//     java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Shape var27 = null;
//     java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
//     org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var21, var22, var24, var26, var28);
//     java.awt.Paint var30 = var29.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     var31.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
//     var31.setRangeAxis((org.jfree.chart.axis.ValueAxis)var36);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var39.setCategoryMargin(10.0d);
//     java.awt.Stroke var42 = var39.getAxisLineStroke();
//     var36.setTickMarkStroke(var42);
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker((-1.0d), var30, var42);
//     org.jfree.chart.util.Layer var45 = null;
//     var10.addRangeMarker((org.jfree.chart.plot.Marker)var44, var45);
//     org.jfree.chart.util.Layer var47 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var44, var47);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var52 = var50.getRangeAxis(0);
//     java.util.List var53 = var50.getCategories();
//     org.jfree.data.xy.XYDataset var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var54, var55, var56, var57);
//     java.awt.geom.Point2D var59 = var58.getQuadrantOrigin();
//     java.awt.Paint var61 = null;
//     java.awt.Paint[] var62 = new java.awt.Paint[] { var61};
//     java.awt.Paint[] var63 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var64 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var65 = null;
//     java.awt.Stroke[] var66 = new java.awt.Stroke[] { var65};
//     java.awt.Stroke var67 = null;
//     java.awt.Stroke[] var68 = new java.awt.Stroke[] { var67};
//     java.awt.Shape var69 = null;
//     java.awt.Shape[] var70 = new java.awt.Shape[] { var69};
//     org.jfree.chart.plot.DefaultDrawingSupplier var71 = new org.jfree.chart.plot.DefaultDrawingSupplier(var62, var63, var64, var66, var68, var70);
//     java.awt.Paint var72 = var71.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
//     var73.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis("");
//     var73.setRangeAxis((org.jfree.chart.axis.ValueAxis)var78);
//     org.jfree.chart.axis.CategoryAxis var81 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var81.setCategoryMargin(10.0d);
//     java.awt.Stroke var84 = var81.getAxisLineStroke();
//     var78.setTickMarkStroke(var84);
//     org.jfree.chart.plot.ValueMarker var86 = new org.jfree.chart.plot.ValueMarker((-1.0d), var72, var84);
//     org.jfree.chart.util.Layer var87 = null;
//     var58.addRangeMarker((org.jfree.chart.plot.Marker)var86, var87);
//     org.jfree.chart.util.Layer var89 = null;
//     var50.addRangeMarker((org.jfree.chart.plot.Marker)var86, var89);
//     org.jfree.chart.util.Layer var91 = null;
//     boolean var92 = var0.removeDomainMarker((-1), (org.jfree.chart.plot.Marker)var86, var91);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    int var4 = var3.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryMargin(10.0d);
//     java.awt.Stroke var5 = var2.getAxisLineStroke();
//     boolean var6 = var0.equals((java.lang.Object)var2);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var9 = var7.getDataset((-1));
//     org.jfree.chart.util.Layer var11 = null;
//     java.util.Collection var12 = var7.getDomainMarkers(10, var11);
//     var2.setPlot((org.jfree.chart.plot.Plot)var7);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     java.awt.geom.Point2D var22 = var21.getQuadrantOrigin();
//     boolean var23 = var16.equals((java.lang.Object)var22);
//     org.jfree.chart.plot.PlotState var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     var7.draw(var14, var15, var22, var24, var25);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.025d, 100.0f, 10.0f);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, 100.0d);
    org.jfree.chart.block.Block var5 = null;
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var11, var12, 0, 0);
    org.jfree.chart.JFreeChart var16 = null;
    var15.setChart(var16);
    int var18 = var15.getPercent();
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var20 = var19.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var19.setSimpleLabelOffset(var25);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
    var28.setWidth(20.0d);
    var28.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var27.addSubtitle((org.jfree.chart.title.Title)var28);
    var15.setChart(var27);
    java.lang.String var35 = var15.toString();
    java.lang.String var36 = var15.toString();
    int var37 = var15.getType();
    var4.add(var5, (java.lang.Object)var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"+ "'", var35.equals("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"+ "'", var36.equals("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var5 = var2.toRangeWidth(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var6 = var5.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var5.setSimpleLabelOffset(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
//     var14.setWidth(20.0d);
//     var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var13.addSubtitle((org.jfree.chart.title.Title)var14);
//     org.jfree.chart.event.ChartChangeEventType var20 = null;
//     org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
//     org.jfree.chart.event.TitleChangeEvent var22 = null;
//     var13.titleChanged(var22);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.axis.AxisSpace var7 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     java.awt.geom.Point2D var16 = var15.getQuadrantOrigin();
//     var0.zoomDomainAxes(0.05d, (-1.0d), var10, var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     var8.setRangeAxis(10, var12);
//     var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var8);
//     int var15 = var8.getDomainAxisCount();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     var16.setRangeAxis((org.jfree.chart.axis.ValueAxis)var21);
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var24.setCategoryMargin(10.0d);
//     java.awt.Stroke var27 = var24.getAxisLineStroke();
//     var21.setTickMarkStroke(var27);
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var21.valueToJava2D(100.0d, var30, var31);
//     boolean var33 = var8.equals((java.lang.Object)var31);
//     
//     // Checks the contract:  equals-hashcode on var0 and var16
//     assertTrue("Contract failed: equals-hashcode on var0 and var16", var0.equals(var16) ? var0.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var0
//     assertTrue("Contract failed: equals-hashcode on var16 and var0", var16.equals(var0) ? var16.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
//     boolean var14 = var12.getAutoRangeStickyZero();
//     var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
//     var12.setFixedAutoRange(20.0d);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var21 = var19.getDomainAxis((-1));
//     boolean var22 = var19.isRangeGridlinesVisible();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var25 = var23.getDomainAxis((-1));
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     var26.setRangeAxis((org.jfree.chart.axis.ValueAxis)var31);
//     boolean var33 = var31.getAutoRangeStickyZero();
//     var23.setDomainAxis((org.jfree.chart.axis.ValueAxis)var31);
//     var19.setRangeAxis((org.jfree.chart.axis.ValueAxis)var31);
//     var31.setFixedAutoRange(20.0d);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     var38.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("");
//     var38.setRangeAxis((org.jfree.chart.axis.ValueAxis)var43);
//     java.awt.Shape var45 = var43.getDownArrow();
//     var31.setDownArrow(var45);
//     var12.setRightArrow(var45);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var23
//     assertTrue("Contract failed: equals-hashcode on var4 and var23", var4.equals(var23) ? var4.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var4
//     assertTrue("Contract failed: equals-hashcode on var23 and var4", var23.equals(var4) ? var23.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var26
//     assertTrue("Contract failed: equals-hashcode on var7 and var26", var7.equals(var26) ? var7.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var7
//     assertTrue("Contract failed: equals-hashcode on var26 and var7", var26.equals(var7) ? var26.hashCode() == var7.hashCode() : true);
// 
//   }

//  public void test197() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.chart.event.ChartChangeEvent[source=false]", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    java.lang.String var2 = var1.toString();
    org.jfree.chart.plot.PieLabelRecord var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var0.indexOf(var8);
    java.awt.Paint var10 = var0.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var12 = var0.getDomainAxisForDataset(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.toString();
    java.awt.Image var2 = var0.getLogo();
    java.awt.Image var3 = null;
    var0.setLogo(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"+ "'", var1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    org.jfree.chart.event.ChartChangeEventType var22 = var21.getType();
    java.lang.Object var23 = var21.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.toString();
    java.lang.String var2 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"+ "'", var1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"+ "'", var2.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     var40.setDataset(var41);
//     boolean var43 = var39.equals((java.lang.Object)var40);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.text.TextBlockAnchor var48 = null;
//     var44.draw(var45, 0.5f, 0.5f, var48);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var8 = var6.trimWidth(10.0d);
    var1.setLabelPadding(var6);
    boolean var10 = var1.isCircular();
    org.jfree.chart.LegendItemCollection var11 = var1.getLegendItems();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.event.ChartChangeListener var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.removeChangeListener(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var6 = var4.calculateTopInset(0.05d);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var4.createInsetRectangle(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var1 = var0.getAngleGridlineStroke();
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAngleLabelPaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     var40.setDataset(var41);
//     boolean var43 = var39.equals((java.lang.Object)var40);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.text.TextBlockAnchor var48 = null;
//     java.awt.Shape var52 = var44.calculateBounds(var45, 100.0f, 0.0f, var48, 0.5f, 100.0f, 10.0d);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, var1);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    java.awt.Paint var1 = null;
    java.awt.Color var6 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var8.setCategoryMargin(10.0d);
    java.awt.Stroke var11 = var8.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var6, var11);
    java.awt.Stroke var13 = var12.getStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker((-1.0d), var1, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     var0.setDataset(var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.data.Range var4 = var0.getDataRange(var3);
//     java.lang.String var5 = var0.getPlotType();
//     java.awt.Color var11 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var13.setCategoryMargin(10.0d);
//     java.awt.Stroke var16 = var13.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var11, var16);
//     java.awt.Stroke var18 = var17.getStroke();
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var20 = var0.removeRangeMarker(255, (org.jfree.chart.plot.Marker)var17, var19);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     var0.setRangeGridlinesVisible(false);
//     var0.setDomainCrosshairLockedOnData(false);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var11 = var9.getRangeAxis(0);
//     java.util.List var12 = var9.getCategories();
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     java.awt.geom.Point2D var18 = var17.getQuadrantOrigin();
//     java.awt.Paint var20 = null;
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
//     java.awt.Paint[] var22 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var23 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var24 = null;
//     java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
//     java.awt.Stroke var26 = null;
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     java.awt.Shape var28 = null;
//     java.awt.Shape[] var29 = new java.awt.Shape[] { var28};
//     org.jfree.chart.plot.DefaultDrawingSupplier var30 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var22, var23, var25, var27, var29);
//     java.awt.Paint var31 = var30.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setRangeAxis((org.jfree.chart.axis.ValueAxis)var37);
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var40.setCategoryMargin(10.0d);
//     java.awt.Stroke var43 = var40.getAxisLineStroke();
//     var37.setTickMarkStroke(var43);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker((-1.0d), var31, var43);
//     org.jfree.chart.util.Layer var46 = null;
//     var17.addRangeMarker((org.jfree.chart.plot.Marker)var45, var46);
//     org.jfree.chart.util.Layer var48 = null;
//     var9.addRangeMarker((org.jfree.chart.plot.Marker)var45, var48);
//     org.jfree.chart.util.Layer var50 = null;
//     boolean var51 = var0.removeDomainMarker(4, (org.jfree.chart.plot.Marker)var45, var50);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var7 = var6.getLabelLinkPaint();
    var0.setDomainTickBandPaint(var7);
    var0.setDomainCrosshairVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    java.awt.Paint var5 = var0.getRangeCrosshairPaint();
    java.awt.Paint var6 = var0.getNoDataMessagePaint();
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.block.BlockContainer var8 = var7.getItemContainer();
    org.jfree.chart.util.RectangleEdge var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setLegendItemGraphicEdge(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    java.awt.Paint var1 = null;
    java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
    java.awt.Paint[] var3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var3, var4, var6, var8, var10);
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    var13.setRangeAxis((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var21.setCategoryMargin(10.0d);
    java.awt.Stroke var24 = var21.getAxisLineStroke();
    var18.setTickMarkStroke(var24);
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker((-1.0d), var12, var24);
    org.jfree.chart.util.RectangleInsets var27 = var26.getLabelOffset();
    java.awt.geom.Rectangle2D var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var29 = var27.createOutsetRectangle(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     boolean var23 = var21.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var24 = var21.getLegendItemGraphicPadding();
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     var25.setRangeAxis(10, var29);
//     java.awt.Stroke var31 = null;
//     var25.setOutlineStroke(var31);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     var25.setRenderer(1, var34);
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var41 = null;
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var45);
//     boolean var48 = var46.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var51 = var49.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var52 = var49.getRootPlot();
//     java.awt.Graphics2D var53 = null;
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     org.jfree.chart.plot.CrosshairState var57 = null;
//     boolean var58 = var49.render(var53, var54, 0, var56, var57);
//     java.awt.Paint var60 = var49.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var62 = var49.getRangeAxisEdge(100);
//     var46.setPosition(var62);
//     org.jfree.chart.block.BlockContainer var64 = var46.getItemContainer();
//     var21.setWrapper(var64);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var40
//     assertTrue("Contract failed: equals-hashcode on var15 and var40", var15.equals(var40) ? var15.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var15
//     assertTrue("Contract failed: equals-hashcode on var40 and var15", var40.equals(var15) ? var40.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var45
//     assertTrue("Contract failed: equals-hashcode on var20 and var45", var20.equals(var45) ? var20.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var20
//     assertTrue("Contract failed: equals-hashcode on var45 and var20", var45.equals(var20) ? var45.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("XY Plot", var1, 0.0f, 100.0f, var4);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var0.indexOf(var8);
    int var10 = var0.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var11 = var0.getInsets();
    double var13 = var11.calculateLeftOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 8.0d);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     var8.setRangeAxis(10, var12);
//     var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var8);
//     boolean var15 = var8.isDomainGridlinesVisible();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     var16.setDataset(var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.data.Range var20 = var16.getDataRange(var19);
//     java.lang.String var21 = var16.getPlotType();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     java.awt.geom.Point2D var27 = var26.getQuadrantOrigin();
//     java.awt.geom.Point2D var28 = var26.getQuadrantOrigin();
//     var26.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var31 = null;
//     var26.setFixedRangeAxisSpace(var31, true);
//     java.awt.Paint var35 = null;
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     java.awt.Paint[] var37 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var38 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Stroke var41 = null;
//     java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
//     java.awt.Shape var43 = null;
//     java.awt.Shape[] var44 = new java.awt.Shape[] { var43};
//     org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier(var36, var37, var38, var40, var42, var44);
//     java.awt.Paint var46 = var45.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     var47.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     var47.setRangeAxis((org.jfree.chart.axis.ValueAxis)var52);
//     org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var55.setCategoryMargin(10.0d);
//     java.awt.Stroke var58 = var55.getAxisLineStroke();
//     var52.setTickMarkStroke(var58);
//     org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker((-1.0d), var46, var58);
//     org.jfree.chart.util.Layer var61 = null;
//     var26.addRangeMarker((org.jfree.chart.plot.Marker)var60, var61);
//     org.jfree.chart.util.Layer var63 = null;
//     var16.addRangeMarker((org.jfree.chart.plot.Marker)var60, var63);
//     java.lang.Object var65 = var60.clone();
//     var8.addDomainMarker((org.jfree.chart.plot.Marker)var60);
//     
//     // Checks the contract:  equals-hashcode on var0 and var47
//     assertTrue("Contract failed: equals-hashcode on var0 and var47", var0.equals(var47) ? var0.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var0
//     assertTrue("Contract failed: equals-hashcode on var47 and var0", var47.equals(var0) ? var47.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var12.getAutoRangeStickyZero();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setAutoRangeMinimumSize(6.25d);
    java.text.NumberFormat var19 = null;
    var12.setNumberFormatOverride(var19);
    org.jfree.chart.axis.NumberTickUnit var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setTickUnit(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, 0.5f, var4, 100.0d, var6);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    java.awt.geom.Point2D var13 = var12.getQuadrantOrigin();
    java.awt.geom.Point2D var14 = var12.getQuadrantOrigin();
    var12.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var17 = null;
    var12.setFixedRangeAxisSpace(var17, true);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
    var12.setDomainAxis((org.jfree.chart.axis.ValueAxis)var21);
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var21, var23, var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxis((-10223606), var23, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(4.0d, 1.0d);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeWidth(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    var13.setTitle("Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    java.awt.Image var8 = null;
    var0.setBackgroundImage(var8);
    java.awt.Paint var11 = null;
    java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
    java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
    java.awt.Paint var22 = var21.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var31.setCategoryMargin(10.0d);
    java.awt.Stroke var34 = var31.getAxisLineStroke();
    var28.setTickMarkStroke(var34);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker((-1.0d), var22, var34);
    var0.setDomainZeroBaselineStroke(var34);
    org.jfree.chart.axis.AxisLocation var38 = var0.getRangeAxisLocation();
    org.jfree.chart.plot.PlotOrientation var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var40 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var38, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, 100.0d);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var7 = var5.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     var5.setRangeAxis(10, var9);
//     java.awt.Stroke var11 = null;
//     var5.setOutlineStroke(var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     var5.setRenderer(1, var14);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.FlowArrangement var20 = new org.jfree.chart.block.FlowArrangement(var16, var17, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var20, (org.jfree.chart.block.Arrangement)var25);
//     boolean var28 = var26.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var29 = var26.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var30 = var26.getItemLabelPadding();
//     org.jfree.chart.block.BlockContainer var31 = var26.getItemContainer();
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.block.RectangleConstraint var33 = null;
//     org.jfree.chart.util.Size2D var34 = var4.arrange(var31, var32, var33);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=4.0, height=1.0]", var1, 0.0f, 10.0f, var4, 90.0d, var6);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setURLText("");
    var0.setPadding(4.0d, 0.025d, 0.0d, (-1.0d));
    var0.setPadding(0.025d, 20.0d, 0.0d, 10.0d);
    java.awt.Graphics2D var13 = null;
    org.jfree.data.Range var15 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var19 = var18.getHeightConstraintType();
    java.lang.String var20 = var19.toString();
    org.jfree.data.Range var22 = null;
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var26 = var25.getHeightConstraintType();
    boolean var28 = var26.equals((java.lang.Object)(byte)100);
    org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(6.25d, var15, var19, 0.2d, var22, var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var30 = var0.arrange(var13, var29);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "LengthConstraintType.FIXED"+ "'", var20.equals("LengthConstraintType.FIXED"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     boolean var23 = var21.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var24 = var21.getLegendItemGraphicPadding();
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var28 = var27.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var33 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var27.setSimpleLabelOffset(var33);
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var27);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
//     var36.setWidth(20.0d);
//     var36.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var35.addSubtitle((org.jfree.chart.title.Title)var36);
//     java.lang.Object var42 = var36.clone();
//     java.lang.Object var43 = var21.draw(var25, var26, var42);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ChartChangeEventType.GENERAL", "XY Plot", var3);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var5 = null;
    var4.setDataset(var5);
    boolean var7 = var3.equals((java.lang.Object)var4);
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
    double var10 = var8.getExplodePercent((java.lang.Comparable)10L);
    double var11 = var8.getLabelGap();
    java.awt.Paint var12 = var8.getShadowPaint();
    java.awt.Stroke var13 = var8.getSeparatorStroke();
    var4.setDomainGridlineStroke(var13);
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("ThreadContext", var1, var2, var3);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.plot.CategoryMarker var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var8.removeProgressListener(var15);
    java.awt.Paint var17 = var8.getBorderPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var20 = var8.createBufferedImage(0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    java.awt.Image var8 = null;
    var0.setBackgroundImage(var8);
    java.awt.Paint var11 = null;
    java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
    java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
    java.awt.Paint var22 = var21.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var31.setCategoryMargin(10.0d);
    java.awt.Stroke var34 = var31.getAxisLineStroke();
    var28.setTickMarkStroke(var34);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker((-1.0d), var22, var34);
    var0.setDomainZeroBaselineStroke(var34);
    org.jfree.chart.axis.AxisLocation var38 = var0.getRangeAxisLocation();
    org.jfree.data.xy.XYDataset var39 = var0.getDataset();
    org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var43 = var41.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var45 = null;
    var41.setRangeAxis(10, var45);
    java.awt.Stroke var47 = null;
    var41.setOutlineStroke(var47);
    java.awt.Image var49 = null;
    var41.setBackgroundImage(var49);
    java.awt.Paint var52 = null;
    java.awt.Paint[] var53 = new java.awt.Paint[] { var52};
    java.awt.Paint[] var54 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var55 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var56 = null;
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    java.awt.Stroke var58 = null;
    java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
    java.awt.Shape var60 = null;
    java.awt.Shape[] var61 = new java.awt.Shape[] { var60};
    org.jfree.chart.plot.DefaultDrawingSupplier var62 = new org.jfree.chart.plot.DefaultDrawingSupplier(var53, var54, var55, var57, var59, var61);
    java.awt.Paint var63 = var62.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
    var64.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("");
    var64.setRangeAxis((org.jfree.chart.axis.ValueAxis)var69);
    org.jfree.chart.axis.CategoryAxis var72 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var72.setCategoryMargin(10.0d);
    java.awt.Stroke var75 = var72.getAxisLineStroke();
    var69.setTickMarkStroke(var75);
    org.jfree.chart.plot.ValueMarker var77 = new org.jfree.chart.plot.ValueMarker((-1.0d), var63, var75);
    var41.setDomainZeroBaselineStroke(var75);
    org.jfree.chart.axis.AxisLocation var79 = var41.getRangeAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-65536), var79, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    var4.addOptionalLibrary("");
    org.jfree.chart.ui.Library[] var7 = var4.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2);
    var0.configureDomainAxes();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.axis.AxisSpace var6 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.PlotOrientation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2);
    var0.configureDomainAxes();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.axis.AxisSpace var6 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.axis.AxisSpace var7 = var0.getFixedRangeAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var1 = var0.getAngleGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
//     boolean var7 = var4.isRangeGridlinesVisible();
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
//     java.awt.geom.Point2D var24 = var23.getQuadrantOrigin();
//     var16.zoomDomainAxes(1.0d, var18, var24);
//     var12.zoomDomainAxes(1.0d, 0.0d, var15, var24);
//     var4.zoomRangeAxes((-1.0d), var11, var24);
//     var0.zoomRangeAxes(90.0d, var3, var24);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var12.getAutoRangeStickyZero();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setAutoRangeMinimumSize(6.25d);
    var12.setPositiveArrowVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
//     var1.setFixedDimension(100.0d);
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot();
//     double var9 = var7.getExplodePercent((java.lang.Comparable)10L);
//     org.jfree.chart.event.MarkerChangeEvent var10 = null;
//     var7.markerChanged(var10);
//     boolean var12 = var1.hasListener((java.util.EventListener)var7);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var18 = var16.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     var16.setRangeAxis(10, var20);
//     java.awt.Stroke var22 = null;
//     var16.setOutlineStroke(var22);
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     var16.setRenderer(1, var25);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.FlowArrangement var31 = new org.jfree.chart.block.FlowArrangement(var27, var28, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement(var32, var33, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, (org.jfree.chart.block.Arrangement)var31, (org.jfree.chart.block.Arrangement)var36);
//     boolean var39 = var37.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var40 = var37.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var41 = var37.getItemLabelPadding();
//     java.awt.Color var45 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     var46.setDataset(var47);
//     boolean var49 = var45.equals((java.lang.Object)var46);
//     org.jfree.chart.util.RectangleEdge var51 = var46.getRangeAxisEdge(100);
//     var37.setLegendItemGraphicEdge(var51);
//     double var53 = var1.getCategoryStart(0, 100, var15, var51);
// 
//   }

//  public void test244() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("LengthConstraintType.FIXED", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    java.awt.Stroke var22 = var13.getBorderStroke();
    var13.setNotify(false);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var29 = null;
    var25.setRangeAxis(10, var29);
    java.awt.Stroke var31 = null;
    var25.setOutlineStroke(var31);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    var25.setRenderer(1, var34);
    org.jfree.chart.util.HorizontalAlignment var36 = null;
    org.jfree.chart.util.VerticalAlignment var37 = null;
    org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var41 = null;
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var45);
    boolean var48 = var46.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot();
    double var50 = var49.getShadowYOffset();
    double var51 = var49.getShadowYOffset();
    java.awt.Font var52 = var49.getLabelFont();
    var46.setItemFont(var52);
    var13.removeSubtitle((org.jfree.chart.title.Title)var46);
    org.jfree.chart.util.RectangleAnchor var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var46.setLegendItemGraphicAnchor(var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     org.jfree.chart.JFreeChart var6 = null;
//     org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var6, 0, 0);
//     org.jfree.chart.JFreeChart var10 = null;
//     var9.setChart(var10);
//     int var12 = var9.getPercent();
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var14 = var13.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var13.setSimpleLabelOffset(var19);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
//     var22.setWidth(20.0d);
//     var22.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var21.addSubtitle((org.jfree.chart.title.Title)var22);
//     var9.setChart(var21);
//     java.lang.String var29 = var9.toString();
//     java.lang.String var30 = var9.toString();
//     int var31 = var9.getType();
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var33.setCategoryMargin(10.0d);
//     java.awt.Stroke var36 = var33.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var38 = var37.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var43 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var37.setSimpleLabelOffset(var43);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var37);
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
//     var46.setWidth(20.0d);
//     var46.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var45.addSubtitle((org.jfree.chart.title.Title)var46);
//     org.jfree.chart.event.ChartChangeEventType var52 = null;
//     org.jfree.chart.event.ChartChangeEvent var53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var33, var45, var52);
//     java.awt.Stroke var54 = var45.getBorderStroke();
//     var45.setNotify(false);
//     var9.setChart(var45);
//     
//     // Checks the contract:  equals-hashcode on var13 and var37
//     assertTrue("Contract failed: equals-hashcode on var13 and var37", var13.equals(var37) ? var13.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var13
//     assertTrue("Contract failed: equals-hashcode on var37 and var13", var37.equals(var13) ? var37.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.configure();
    var1.setLowerMargin(1.0d);
    java.lang.Comparable var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var9 = var1.getCategoryLabelToolTip(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    int var6 = var5.getAlpha();
    var1.setAggregatedItemsPaint((java.awt.Paint)var5);
    org.jfree.chart.util.TableOrder var8 = var1.getDataExtractOrder();
    org.jfree.data.category.CategoryDataset var9 = null;
    var1.setDataset(var9);
    org.jfree.chart.JFreeChart var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPieChart(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     double var2 = var1.getShadowYOffset();
//     double var3 = var1.getShadowYOffset();
//     java.awt.Font var4 = var1.getLabelFont();
//     java.awt.Font var5 = var1.getLabelFont();
//     org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("", var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = var6.calculateDimensions(var7);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var3 = var0.getRootPlot();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.plot.CrosshairState var8 = null;
//     boolean var9 = var0.render(var4, var5, 0, var7, var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     java.util.List var12 = null;
//     var0.drawDomainTickBands(var10, var11, var12);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     var14.setDataset(var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.data.Range var18 = var14.getDataRange(var17);
//     java.lang.String var19 = var14.getPlotType();
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     java.awt.geom.Point2D var25 = var24.getQuadrantOrigin();
//     java.awt.geom.Point2D var26 = var24.getQuadrantOrigin();
//     var24.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var29 = null;
//     var24.setFixedRangeAxisSpace(var29, true);
//     java.awt.Paint var33 = null;
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     java.awt.Paint[] var35 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var36 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Shape var41 = null;
//     java.awt.Shape[] var42 = new java.awt.Shape[] { var41};
//     org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var35, var36, var38, var40, var42);
//     java.awt.Paint var44 = var43.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("");
//     var45.setRangeAxis((org.jfree.chart.axis.ValueAxis)var50);
//     org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var53.setCategoryMargin(10.0d);
//     java.awt.Stroke var56 = var53.getAxisLineStroke();
//     var50.setTickMarkStroke(var56);
//     org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker((-1.0d), var44, var56);
//     org.jfree.chart.util.Layer var59 = null;
//     var24.addRangeMarker((org.jfree.chart.plot.Marker)var58, var59);
//     org.jfree.chart.util.Layer var61 = null;
//     var14.addRangeMarker((org.jfree.chart.plot.Marker)var58, var61);
//     org.jfree.chart.event.MarkerChangeEvent var63 = null;
//     var58.notifyListeners(var63);
//     org.jfree.chart.event.MarkerChangeEvent var65 = null;
//     var58.notifyListeners(var65);
//     org.jfree.chart.util.LengthAdjustmentType var67 = var58.getLabelOffsetType();
//     org.jfree.chart.util.Layer var68 = null;
//     boolean var69 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var58, var68);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(6.25d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     double var1 = var0.getShadowYOffset();
//     double var2 = var0.getShadowYOffset();
//     java.awt.Font var3 = var0.getLabelFont();
//     org.jfree.chart.urls.PieURLGenerator var4 = null;
//     var0.setLegendLabelURLGenerator(var4);
//     boolean var6 = var0.getLabelLinksVisible();
//     org.jfree.chart.labels.PieToolTipGenerator var7 = null;
//     var0.setToolTipGenerator(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     java.awt.geom.Point2D var19 = var18.getQuadrantOrigin();
//     var11.zoomDomainAxes(1.0d, var13, var19);
//     org.jfree.chart.plot.PlotState var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     var0.draw(var9, var10, var19, var21, var22);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     java.awt.geom.Point2D var6 = var4.getQuadrantOrigin();
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     var4.setRenderer(10, var8);
//     org.jfree.chart.util.Layer var11 = null;
//     java.util.Collection var12 = var4.getDomainMarkers(1, var11);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var14 = var13.getFixedRangeAxisSpace();
//     java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var20 = null;
//     var19.setDataset(var20);
//     boolean var22 = var18.equals((java.lang.Object)var19);
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot();
//     double var25 = var23.getExplodePercent((java.lang.Comparable)10L);
//     double var26 = var23.getLabelGap();
//     java.awt.Paint var27 = var23.getShadowPaint();
//     java.awt.Stroke var28 = var23.getSeparatorStroke();
//     var19.setDomainGridlineStroke(var28);
//     var13.setDomainCrosshairStroke(var28);
//     var4.setDomainCrosshairStroke(var28);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("XY Plot", 0, (-1));
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     var3.setRangeAxis((org.jfree.chart.axis.ValueAxis)var8);
//     boolean var10 = var8.getAutoRangeStickyZero();
//     var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var17);
//     boolean var19 = var17.getAutoRangeStickyZero();
//     var17.setAutoRangeStickyZero(false);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     var22.setRangeAxis((org.jfree.chart.axis.ValueAxis)var27);
//     java.awt.Shape var29 = var27.getDownArrow();
//     var17.setDownArrow(var29);
//     var8.setLeftArrow(var29);
//     
//     // Checks the contract:  equals-hashcode on var3 and var22
//     assertTrue("Contract failed: equals-hashcode on var3 and var22", var3.equals(var22) ? var3.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var3
//     assertTrue("Contract failed: equals-hashcode on var22 and var3", var22.equals(var3) ? var22.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.PlotOrientation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var11 = var10.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(0.2d, var1, var5, 10.0d, var7, var11);
    org.jfree.chart.block.RectangleConstraint var14 = var12.toFixedWidth(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     var40.setDataset(var41);
//     boolean var43 = var39.equals((java.lang.Object)var40);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
//     org.jfree.chart.text.TextLine var45 = var44.getLastLine();
//     java.util.List var46 = var44.getLines();
//     org.jfree.chart.text.TextLine var47 = var44.getLastLine();
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.text.TextBlockAnchor var51 = null;
//     var44.draw(var48, 10.0f, (-1.0f), var51);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.configure();
    var1.setLowerMargin(1.0d);
    var1.setLabel("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    java.awt.geom.Rectangle2D var2 = var1.getPieArea();
    double var3 = var1.getLatestAngle();
    double var4 = var1.getPieWRadius();
    int var5 = var1.getPassesRequired();
    java.awt.geom.Rectangle2D var6 = null;
    var1.setLinkArea(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     java.awt.geom.Point2D var6 = var5.getQuadrantOrigin();
//     java.awt.geom.Point2D var7 = var5.getQuadrantOrigin();
//     var5.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var5.setFixedRangeAxisSpace(var10, true);
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var14, var16, var17);
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var20 = var19.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var19.setSimpleLabelOffset(var25);
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
//     var28.setWidth(20.0d);
//     var28.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var27.addSubtitle((org.jfree.chart.title.Title)var28);
//     java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
//     var27.setBackgroundPaint((java.awt.Paint)var37);
//     var18.setOutlinePaint((java.awt.Paint)var37);
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var41 = var40.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var40.setSimpleLabelOffset(var46);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var40);
//     org.jfree.chart.ChartRenderingInfo var51 = null;
//     java.awt.image.BufferedImage var52 = var48.createBufferedImage(10, 256, var51);
//     var18.setBackgroundImage((java.awt.Image)var52);
//     
//     // Checks the contract:  equals-hashcode on var19 and var40
//     assertTrue("Contract failed: equals-hashcode on var19 and var40", var19.equals(var40) ? var19.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var19
//     assertTrue("Contract failed: equals-hashcode on var40 and var19", var40.equals(var19) ? var40.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset((-1));
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var5 = var3.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var3.setRangeAxis(0, var7, false);
//     var3.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var13};
//     var3.setRangeAxes(var14);
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint[] var18 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var19 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Shape var24 = null;
//     java.awt.Shape[] var25 = new java.awt.Shape[] { var24};
//     org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var18, var19, var21, var23, var25);
//     java.awt.Paint var27 = var26.getNextOutlinePaint();
//     var3.setRangeGridlinePaint(var27);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     var29.setRenderer(0, var31);
//     org.jfree.chart.util.SortOrder var33 = var29.getRowRenderingOrder();
//     var3.setRowRenderingOrder(var33);
//     var0.setColumnRenderingOrder(var33);
//     
//     // Checks the contract:  equals-hashcode on var0 and var29
//     assertTrue("Contract failed: equals-hashcode on var0 and var29", var0.equals(var29) ? var0.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var0
//     assertTrue("Contract failed: equals-hashcode on var29 and var0", var29.equals(var0) ? var29.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     java.awt.Image var8 = null;
//     var0.setBackgroundImage(var8);
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var19 = null;
//     java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
//     java.awt.Paint var22 = var21.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var31.setCategoryMargin(10.0d);
//     java.awt.Stroke var34 = var31.getAxisLineStroke();
//     var28.setTickMarkStroke(var34);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker((-1.0d), var22, var34);
//     var0.setDomainZeroBaselineStroke(var34);
//     org.jfree.chart.axis.AxisLocation var38 = var0.getRangeAxisLocation();
//     java.lang.String var39 = var0.getPlotType();
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var42 = var40.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     var40.setRangeAxis(10, var44);
//     java.awt.Stroke var46 = null;
//     var40.setOutlineStroke(var46);
//     java.awt.Image var48 = null;
//     var40.setBackgroundImage(var48);
//     java.awt.Paint var51 = null;
//     java.awt.Paint[] var52 = new java.awt.Paint[] { var51};
//     java.awt.Paint[] var53 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var54 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var55 = null;
//     java.awt.Stroke[] var56 = new java.awt.Stroke[] { var55};
//     java.awt.Stroke var57 = null;
//     java.awt.Stroke[] var58 = new java.awt.Stroke[] { var57};
//     java.awt.Shape var59 = null;
//     java.awt.Shape[] var60 = new java.awt.Shape[] { var59};
//     org.jfree.chart.plot.DefaultDrawingSupplier var61 = new org.jfree.chart.plot.DefaultDrawingSupplier(var52, var53, var54, var56, var58, var60);
//     java.awt.Paint var62 = var61.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     var63.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("");
//     var63.setRangeAxis((org.jfree.chart.axis.ValueAxis)var68);
//     org.jfree.chart.axis.CategoryAxis var71 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var71.setCategoryMargin(10.0d);
//     java.awt.Stroke var74 = var71.getAxisLineStroke();
//     var68.setTickMarkStroke(var74);
//     org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker((-1.0d), var62, var74);
//     var40.setDomainZeroBaselineStroke(var74);
//     org.jfree.chart.axis.AxisLocation var78 = var40.getRangeAxisLocation();
//     java.lang.String var79 = var40.getPlotType();
//     org.jfree.data.xy.XYDataset var81 = var40.getDataset(10);
//     java.awt.Paint var82 = var40.getRangeZeroBaselinePaint();
//     var0.setDomainZeroBaselinePaint(var82);
//     
//     // Checks the contract:  equals-hashcode on var0 and var40
//     assertTrue("Contract failed: equals-hashcode on var0 and var40", var0.equals(var40) ? var0.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var0
//     assertTrue("Contract failed: equals-hashcode on var40 and var0", var40.equals(var0) ? var40.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var61
//     assertTrue("Contract failed: equals-hashcode on var21 and var61", var21.equals(var61) ? var21.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var21
//     assertTrue("Contract failed: equals-hashcode on var61 and var21", var61.equals(var21) ? var61.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var63
//     assertTrue("Contract failed: equals-hashcode on var23 and var63", var23.equals(var63) ? var23.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var23
//     assertTrue("Contract failed: equals-hashcode on var63 and var23", var63.equals(var23) ? var63.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var76
//     assertTrue("Contract failed: equals-hashcode on var36 and var76", var36.equals(var76) ? var36.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var36
//     assertTrue("Contract failed: equals-hashcode on var76 and var36", var76.equals(var36) ? var76.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    float var3 = var0.getBackgroundImageAlpha();
    var0.clearDomainMarkers();
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var0.removeAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", (-1));
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
//     double var4 = var3.getShadowYOffset();
//     double var5 = var3.getShadowYOffset();
//     java.awt.Font var6 = var3.getLabelFont();
//     java.awt.Paint var7 = var3.getBaseSectionPaint();
//     boolean var8 = var2.equals((java.lang.Object)var3);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.util.Size2D var12 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     var15.setRangeAxis(10, var19);
//     java.awt.Stroke var21 = null;
//     var15.setOutlineStroke(var21);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     var15.setRenderer(1, var24);
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.FlowArrangement var30 = new org.jfree.chart.block.FlowArrangement(var26, var27, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15, (org.jfree.chart.block.Arrangement)var30, (org.jfree.chart.block.Arrangement)var35);
//     boolean var38 = var36.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var39 = var36.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var40 = var36.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var41 = var36.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var42 = org.jfree.chart.util.RectangleAnchor.createRectangle(var12, 0.05d, 0.2d, var41);
//     org.jfree.chart.plot.PiePlot var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     org.jfree.chart.plot.PiePlotState var46 = var3.initialise(var9, var42, var43, (java.lang.Integer)4, var45);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     var0.setDataset(var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.data.Range var4 = var0.getDataRange(var3);
//     boolean var5 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var0.setFixedRangeAxisSpace(var6);
//     java.awt.Stroke var8 = var0.getRangeGridlineStroke();
//     java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     var13.setDataset(var14);
//     boolean var16 = var12.equals((java.lang.Object)var13);
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot();
//     double var19 = var17.getExplodePercent((java.lang.Comparable)10L);
//     double var20 = var17.getLabelGap();
//     java.awt.Paint var21 = var17.getShadowPaint();
//     java.awt.Stroke var22 = var17.getSeparatorStroke();
//     var13.setDomainGridlineStroke(var22);
//     var0.setDomainGridlineStroke(var22);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    java.awt.Stroke var2 = var0.getStroke((java.lang.Comparable)"RectangleConstraint[LengthConstraintType.FIXED: width=4.0, height=1.0]");
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    var3.setRangeAxis((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var11.setCategoryMargin(10.0d);
    java.awt.Stroke var14 = var11.getAxisLineStroke();
    var8.setTickMarkStroke(var14);
    double var16 = var8.getLowerMargin();
    var8.setRangeAboutValue(90.0d, 25.312499999999993d);
    boolean var20 = var0.equals((java.lang.Object)90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryMargin(10.0d);
//     java.awt.Stroke var5 = var2.getAxisLineStroke();
//     boolean var6 = var0.equals((java.lang.Object)var2);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var9 = var7.getDomainAxis((-1));
//     var7.clearRangeAxes();
//     var2.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     java.awt.Paint var12 = var2.getLabelPaint();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot();
//     double var16 = var14.getExplodePercent((java.lang.Comparable)10L);
//     org.jfree.chart.event.MarkerChangeEvent var17 = null;
//     var14.markerChanged(var17);
//     double var19 = var14.getMaximumLabelWidth();
//     org.jfree.chart.util.Size2D var22 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     var25.setRangeAxis(10, var29);
//     java.awt.Stroke var31 = null;
//     var25.setOutlineStroke(var31);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     var25.setRenderer(1, var34);
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var41 = null;
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var45);
//     boolean var48 = var46.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var49 = var46.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var50 = var46.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var51 = var46.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var52 = org.jfree.chart.util.RectangleAnchor.createRectangle(var22, 0.05d, 0.2d, var51);
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     org.jfree.chart.axis.AxisSpace var54 = null;
//     org.jfree.chart.axis.AxisSpace var55 = var2.reserveSpace(var13, (org.jfree.chart.plot.Plot)var14, var52, var53, var54);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     var4.setDataset(var5);
//     boolean var7 = var3.equals((java.lang.Object)var4);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getRangeAxis(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     java.lang.Object var12 = var8.clone();
//     boolean var13 = var4.equals((java.lang.Object)var8);
//     
//     // Checks the contract:  equals-hashcode on var4 and var8
//     assertTrue("Contract failed: equals-hashcode on var4 and var8", var4.equals(var8) ? var4.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var4
//     assertTrue("Contract failed: equals-hashcode on var8 and var4", var8.equals(var4) ? var8.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    java.util.List var3 = var0.getCategories();
    org.jfree.chart.util.RectangleEdge var5 = var0.getRangeAxisEdge(10);
    org.jfree.data.general.DatasetChangeEvent var6 = null;
    var0.datasetChanged(var6);
    var0.clearAnnotations();
    var0.mapDatasetToRangeAxis(100, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryMargin(10.0d);
//     java.awt.Stroke var5 = var2.getAxisLineStroke();
//     var2.configure();
//     var2.setLowerMargin(1.0d);
//     boolean var9 = var2.isAxisLineVisible();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     boolean var17 = var15.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var20 = var18.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     var18.setRangeAxis(10, var22);
//     var15.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var15, var25);
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var28.setCategoryMargin(10.0d);
//     java.awt.Stroke var31 = var28.getAxisLineStroke();
//     var28.setMaximumCategoryLabelWidthRatio(1.0f);
//     var28.setLabelAngle(0.0d);
//     int var36 = var26.getDomainAxisIndex(var28);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     java.awt.geom.Point2D var43 = var42.getQuadrantOrigin();
//     java.awt.Paint var45 = null;
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var45};
//     java.awt.Paint[] var47 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var48 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var49 = null;
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
//     java.awt.Stroke var51 = null;
//     java.awt.Stroke[] var52 = new java.awt.Stroke[] { var51};
//     java.awt.Shape var53 = null;
//     java.awt.Shape[] var54 = new java.awt.Shape[] { var53};
//     org.jfree.chart.plot.DefaultDrawingSupplier var55 = new org.jfree.chart.plot.DefaultDrawingSupplier(var46, var47, var48, var50, var52, var54);
//     java.awt.Paint var56 = var55.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
//     var57.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("");
//     var57.setRangeAxis((org.jfree.chart.axis.ValueAxis)var62);
//     org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var65.setCategoryMargin(10.0d);
//     java.awt.Stroke var68 = var65.getAxisLineStroke();
//     var62.setTickMarkStroke(var68);
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker((-1.0d), var56, var68);
//     org.jfree.chart.util.Layer var71 = null;
//     var42.addRangeMarker((org.jfree.chart.plot.Marker)var70, var71);
//     org.jfree.chart.util.Layer var73 = null;
//     boolean var74 = var26.removeDomainMarker(100, (org.jfree.chart.plot.Marker)var70, var73);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    int var6 = var0.getWeight();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    int var9 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    boolean var10 = var8.isInverted();
    java.awt.Shape var11 = var8.getLeftArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    var8.setBackgroundPaint((java.awt.Paint)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var20 = var8.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("LengthConstraintType.FIXED", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var0.setSimpleLabelOffset(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var10.setCategoryMargin(10.0d);
//     java.awt.Stroke var13 = var10.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var15 = var14.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var14.setSimpleLabelOffset(var20);
//     org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
//     var23.setWidth(20.0d);
//     var23.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var22.addSubtitle((org.jfree.chart.title.Title)var23);
//     org.jfree.chart.event.ChartChangeEventType var29 = null;
//     org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var22, var29);
//     org.jfree.chart.util.RectangleInsets var31 = var22.getPadding();
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var37 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var39 = var37.trimWidth(10.0d);
//     var32.setLabelPadding(var37);
//     double var42 = var37.calculateRightOutset(10.0d);
//     var22.setPadding(var37);
//     var22.fireChartChanged();
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
//     var45.clearAnnotations();
//     org.jfree.chart.event.PlotChangeEvent var47 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var45);
//     var22.plotChanged(var47);
//     var8.plotChanged(var47);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    var1.setLabelLinkMargin(0.0d);
    var1.setLabelLinkMargin(20.0d);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var10 = null;
    var6.setRangeAxis(10, var10);
    java.awt.Stroke var12 = null;
    var6.setOutlineStroke(var12);
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    var6.setRenderer(1, var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var22 = null;
    org.jfree.chart.util.VerticalAlignment var23 = null;
    org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
    boolean var29 = var27.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
    double var31 = var30.getShadowYOffset();
    double var32 = var30.getShadowYOffset();
    java.awt.Font var33 = var30.getLabelFont();
    var27.setItemFont(var33);
    var1.setLabelFont(var33);
    java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var41 = null;
    var40.setDataset(var41);
    boolean var43 = var39.equals((java.lang.Object)var40);
    org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
    org.jfree.chart.text.TextLine var45 = var44.getLastLine();
    java.util.List var46 = var44.getLines();
    org.jfree.chart.text.TextLine var47 = var44.getLastLine();
    java.awt.Font var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var52 = var50.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var54 = null;
    var50.setRangeAxis(10, var54);
    java.awt.Stroke var56 = null;
    var50.setOutlineStroke(var56);
    java.awt.Image var58 = null;
    var50.setBackgroundImage(var58);
    java.awt.Paint var61 = null;
    java.awt.Paint[] var62 = new java.awt.Paint[] { var61};
    java.awt.Paint[] var63 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var64 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var65 = null;
    java.awt.Stroke[] var66 = new java.awt.Stroke[] { var65};
    java.awt.Stroke var67 = null;
    java.awt.Stroke[] var68 = new java.awt.Stroke[] { var67};
    java.awt.Shape var69 = null;
    java.awt.Shape[] var70 = new java.awt.Shape[] { var69};
    org.jfree.chart.plot.DefaultDrawingSupplier var71 = new org.jfree.chart.plot.DefaultDrawingSupplier(var62, var63, var64, var66, var68, var70);
    java.awt.Paint var72 = var71.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
    var73.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis("");
    var73.setRangeAxis((org.jfree.chart.axis.ValueAxis)var78);
    org.jfree.chart.axis.CategoryAxis var81 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var81.setCategoryMargin(10.0d);
    java.awt.Stroke var84 = var81.getAxisLineStroke();
    var78.setTickMarkStroke(var84);
    org.jfree.chart.plot.ValueMarker var86 = new org.jfree.chart.plot.ValueMarker((-1.0d), var72, var84);
    var50.setDomainZeroBaselineStroke(var84);
    org.jfree.chart.axis.AxisLocation var88 = var50.getRangeAxisLocation();
    java.lang.String var89 = var50.getPlotType();
    org.jfree.data.xy.XYDataset var91 = var50.getDataset(10);
    java.awt.Paint var92 = var50.getRangeZeroBaselinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var44.addLine("org.jfree.chart.event.ChartChangeEvent[source=false]", var49, var92);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var89 + "' != '" + "XY Plot"+ "'", var89.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("ThreadContext", var1);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var5.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var5.setSimpleLabelOffset(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    var14.setWidth(20.0d);
    var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var13.addSubtitle((org.jfree.chart.title.Title)var14);
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
    java.awt.Stroke var22 = var13.getBorderStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var23 = var13.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     boolean var23 = var21.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var24 = var21.getLegendItemGraphicPadding();
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     var25.setRangeAxis(10, var29);
//     java.awt.Stroke var31 = null;
//     var25.setOutlineStroke(var31);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     var25.setRenderer(1, var34);
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var41 = null;
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var45);
//     boolean var48 = var46.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var51 = var49.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var52 = var49.getRootPlot();
//     java.awt.Graphics2D var53 = null;
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     org.jfree.chart.plot.CrosshairState var57 = null;
//     boolean var58 = var49.render(var53, var54, 0, var56, var57);
//     java.awt.Paint var60 = var49.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var62 = var49.getRangeAxisEdge(100);
//     var46.setPosition(var62);
//     org.jfree.chart.block.BlockContainer var64 = var46.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var65 = var46.getLegendItemGraphicPadding();
//     var21.setItemLabelPadding(var65);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var40
//     assertTrue("Contract failed: equals-hashcode on var15 and var40", var15.equals(var40) ? var15.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var15
//     assertTrue("Contract failed: equals-hashcode on var40 and var15", var40.equals(var15) ? var40.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var45
//     assertTrue("Contract failed: equals-hashcode on var20 and var45", var20.equals(var45) ? var20.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var20
//     assertTrue("Contract failed: equals-hashcode on var45 and var20", var45.equals(var20) ? var45.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(0, var4, false);
//     var0.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var10};
//     var0.setRangeAxes(var11);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     var0.setRenderer(10, var14);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var0.setRenderer(var16, false);
//     org.jfree.chart.axis.CategoryAxis var19 = var0.getDomainAxis();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     java.awt.geom.Point2D var26 = var25.getQuadrantOrigin();
//     java.awt.Paint var28 = null;
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var28};
//     java.awt.Paint[] var30 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var31 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Shape var36 = null;
//     java.awt.Shape[] var37 = new java.awt.Shape[] { var36};
//     org.jfree.chart.plot.DefaultDrawingSupplier var38 = new org.jfree.chart.plot.DefaultDrawingSupplier(var29, var30, var31, var33, var35, var37);
//     java.awt.Paint var39 = var38.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     var40.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
//     var40.setRangeAxis((org.jfree.chart.axis.ValueAxis)var45);
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var48.setCategoryMargin(10.0d);
//     java.awt.Stroke var51 = var48.getAxisLineStroke();
//     var45.setTickMarkStroke(var51);
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker((-1.0d), var39, var51);
//     org.jfree.chart.util.Layer var54 = null;
//     var25.addRangeMarker((org.jfree.chart.plot.Marker)var53, var54);
//     org.jfree.chart.util.Layer var56 = null;
//     boolean var57 = var0.removeRangeMarker(256, (org.jfree.chart.plot.Marker)var53, var56);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("Other");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    java.awt.geom.Rectangle2D var2 = var1.getPieArea();
    double var3 = var1.getLatestAngle();
    java.awt.geom.Rectangle2D var4 = var1.getLinkArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     var8.setRangeAxis(10, var12);
//     var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var8);
//     int var15 = var8.getDomainAxisCount();
//     boolean var16 = var8.isRangeCrosshairVisible();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis((-1));
//     boolean var20 = var17.isRangeGridlinesVisible();
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var23 = var21.getDomainAxis((-1));
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var24.setRangeAxis((org.jfree.chart.axis.ValueAxis)var29);
//     boolean var31 = var29.getAutoRangeStickyZero();
//     var21.setDomainAxis((org.jfree.chart.axis.ValueAxis)var29);
//     var17.setRangeAxis((org.jfree.chart.axis.ValueAxis)var29);
//     var29.setFixedAutoRange(20.0d);
//     boolean var36 = var29.getAutoRangeStickyZero();
//     org.jfree.chart.axis.MarkerAxisBand var37 = null;
//     var29.setMarkerBand(var37);
//     var8.setRangeAxis((org.jfree.chart.axis.ValueAxis)var29);
//     
//     // Checks the contract:  equals-hashcode on var8 and var17
//     assertTrue("Contract failed: equals-hashcode on var8 and var17", var8.equals(var17) ? var8.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var8
//     assertTrue("Contract failed: equals-hashcode on var17 and var8", var17.equals(var8) ? var17.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    var4.addOptionalLibrary("");
    org.jfree.chart.ui.Library[] var7 = var4.getOptionalLibraries();
    java.lang.String var8 = var4.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     boolean var4 = var0.isDomainGridlinesVisible();
//     org.jfree.data.category.CategoryDataset var6 = var0.getDataset(0);
//     org.jfree.chart.util.Layer var8 = null;
//     java.util.Collection var9 = var0.getRangeMarkers(10, var8);
//     org.jfree.chart.axis.AxisLocation var10 = var0.getDomainAxisLocation();
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     java.awt.geom.Point2D var16 = var15.getQuadrantOrigin();
//     java.awt.geom.Point2D var17 = var15.getQuadrantOrigin();
//     var15.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var20 = null;
//     var15.setFixedRangeAxisSpace(var20, true);
//     java.awt.Paint var24 = null;
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Paint[] var26 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var27 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var28 = null;
//     java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Shape var32 = null;
//     java.awt.Shape[] var33 = new java.awt.Shape[] { var32};
//     org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier(var25, var26, var27, var29, var31, var33);
//     java.awt.Paint var35 = var34.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     var36.setRangeAxis((org.jfree.chart.axis.ValueAxis)var41);
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var44.setCategoryMargin(10.0d);
//     java.awt.Stroke var47 = var44.getAxisLineStroke();
//     var41.setTickMarkStroke(var47);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker((-1.0d), var35, var47);
//     org.jfree.chart.util.Layer var50 = null;
//     var15.addRangeMarker((org.jfree.chart.plot.Marker)var49, var50);
//     org.jfree.chart.util.Layer var52 = null;
//     boolean var53 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var49, var52);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     double var2 = var1.getShadowYOffset();
//     double var3 = var1.getShadowYOffset();
//     java.awt.Font var4 = var1.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var7 = var5.getRangeAxis(0);
//     float var8 = var5.getBackgroundImageAlpha();
//     var5.clearDomainMarkers();
//     var5.setNoDataMessage("Category Plot");
//     java.awt.Paint var12 = var5.getRangeCrosshairPaint();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.G2TextMeasurer var15 = new org.jfree.chart.text.G2TextMeasurer(var14);
//     org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", var4, var12, 10.0f, (org.jfree.chart.text.TextMeasurer)var15);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     var4.setDataset(var5);
//     boolean var7 = var3.equals((java.lang.Object)var4);
//     org.jfree.chart.axis.AxisSpace var8 = var4.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.event.PlotChangeListener var12 = null;
//     var11.addChangeListener(var12);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var18 = var16.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     var16.setRangeAxis(10, var20);
//     java.awt.Stroke var22 = null;
//     var16.setOutlineStroke(var22);
//     org.jfree.data.xy.XYDataset var24 = null;
//     int var25 = var16.indexOf(var24);
//     java.awt.geom.Point2D var26 = var16.getQuadrantOrigin();
//     var11.zoomRangeAxes(0.025d, var15, var26, true);
//     var4.zoomRangeAxes(0.0d, var10, var26, true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var11
//     assertTrue("Contract failed: equals-hashcode on var4 and var11", var4.equals(var11) ? var4.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var4
//     assertTrue("Contract failed: equals-hashcode on var11 and var4", var11.equals(var4) ? var11.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraint[LengthConstraintType.FIXED: width=4.0, height=1.0]", "", var3);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     org.jfree.data.general.DatasetGroup var3 = var0.getDatasetGroup();
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(1, var5);
//     org.jfree.chart.util.Layer var7 = null;
//     java.util.Collection var8 = var0.getDomainMarkers(var7);
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     double var10 = var9.getShadowYOffset();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var13 = var11.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     var11.setRangeAxis(0, var15, false);
//     var11.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.ValueAxis[] var22 = new org.jfree.chart.axis.ValueAxis[] { var21};
//     var11.setRangeAxes(var22);
//     java.awt.Paint var24 = null;
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Paint[] var26 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var27 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var28 = null;
//     java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Shape var32 = null;
//     java.awt.Shape[] var33 = new java.awt.Shape[] { var32};
//     org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier(var25, var26, var27, var29, var31, var33);
//     java.awt.Paint var35 = var34.getNextOutlinePaint();
//     var11.setRangeGridlinePaint(var35);
//     var9.setLabelShadowPaint(var35);
//     org.jfree.chart.labels.PieToolTipGenerator var38 = null;
//     var9.setToolTipGenerator(var38);
//     org.jfree.chart.util.RectangleInsets var40 = var9.getSimpleLabelOffset();
//     double var42 = var40.extendWidth(4.0d);
//     var0.setAxisOffset(var40);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     var0.handleClick(100, 255, var46);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     boolean var23 = var21.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var24 = var21.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var25 = var21.getItemLabelPadding();
//     org.jfree.chart.block.BlockContainer var26 = var21.getItemContainer();
//     java.util.List var27 = var26.getBlocks();
//     java.awt.Graphics2D var28 = null;
//     org.jfree.data.Range var30 = null;
//     org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(0.0d, var30);
//     org.jfree.chart.block.LengthConstraintType var32 = var31.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var33 = var26.arrange(var28, var31);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.geom.Point2D var6 = var4.getQuadrantOrigin();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var10.setCategoryMargin(10.0d);
    java.awt.Stroke var13 = var10.getAxisLineStroke();
    var10.configure();
    var10.setLowerMargin(1.0d);
    boolean var17 = var10.isAxisLineVisible();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    var18.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
    boolean var25 = var23.getAutoRangeStickyZero();
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var28 = var26.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var30 = null;
    var26.setRangeAxis(10, var30);
    var23.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var26);
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var8, var10, (org.jfree.chart.axis.ValueAxis)var23, var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxis((-65536), (org.jfree.chart.axis.ValueAxis)var23, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    java.awt.Color var2 = java.awt.Color.getColor("", (-1));
    java.awt.Color var3 = var2.darker();
    float[] var5 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var2.getComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(0, var4, false);
//     org.jfree.chart.axis.CategoryAnchor var7 = var0.getDomainGridlinePosition();
//     org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxisForDataset(4);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     var10.setRangeAxis(0, var12, true);
//     org.jfree.chart.ui.BasicProjectInfo var19 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var19.setLicenceName("hi!");
//     boolean var22 = var10.equals((java.lang.Object)"hi!");
//     org.jfree.data.category.CategoryDataset var24 = null;
//     var10.setDataset(10, var24);
//     java.awt.Paint var26 = var10.getRangeCrosshairPaint();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var29 = var27.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     var27.setRangeAxis(10, var31);
//     java.awt.Stroke var33 = null;
//     var27.setOutlineStroke(var33);
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     var27.setRenderer(1, var36);
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.util.VerticalAlignment var39 = null;
//     org.jfree.chart.block.FlowArrangement var42 = new org.jfree.chart.block.FlowArrangement(var38, var39, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var43 = null;
//     org.jfree.chart.util.VerticalAlignment var44 = null;
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27, (org.jfree.chart.block.Arrangement)var42, (org.jfree.chart.block.Arrangement)var47);
//     java.awt.Graphics2D var49 = null;
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     org.jfree.chart.plot.CrosshairState var53 = null;
//     boolean var54 = var27.render(var49, var50, 10, var52, var53);
//     org.jfree.chart.axis.AxisLocation var55 = var27.getRangeAxisLocation();
//     var10.setDomainAxisLocation(var55);
//     boolean var57 = var0.equals((java.lang.Object)var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
    org.jfree.chart.block.LengthConstraintType var11 = var10.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(0.2d, var1, var5, 10.0d, var7, var11);
    org.jfree.data.Range var13 = var12.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.configure();
    var1.setLowerMargin(1.0d);
    int var8 = var1.getMaximumCategoryLabelLines();
    var1.removeCategoryLabelToolTip((java.lang.Comparable)0L);
    var1.setTickMarksVisible(false);
    var1.setCategoryLabelPositionOffset(10);
    java.awt.Font var15 = var1.getTickLabelFont();
    var1.setFixedDimension((-11.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var30 = var28.trimWidth(10.0d);
    var23.setLabelPadding(var28);
    boolean var32 = var23.isCircular();
    org.jfree.chart.LegendItemCollection var33 = var23.getLegendItems();
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var23);
    java.awt.Paint var35 = var34.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var36 = var34.getTitle();
    org.jfree.chart.ChartColor var40 = new org.jfree.chart.ChartColor(100, 0, 10);
    var15.add((org.jfree.chart.block.Block)var36, (java.lang.Object)100);
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var36.setTextAlignment(var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    int var6 = var0.getWeight();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    int var9 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    var8.setInverted(false);
    java.awt.Paint var12 = var8.getTickMarkPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setRangeWithMargins(25.312499999999993d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     var5.setAutoRangeStickyZero(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     java.awt.Shape var17 = var15.getDownArrow();
//     var5.setDownArrow(var17);
//     org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var17, "ChartChangeEventType.GENERAL", "LengthConstraintType.FIXED");
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("");
//     var22.setRangeAxis((org.jfree.chart.axis.ValueAxis)var27);
//     boolean var29 = var27.getAutoRangeStickyZero();
//     var27.setAutoRangeStickyZero(false);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setRangeAxis((org.jfree.chart.axis.ValueAxis)var37);
//     java.awt.Shape var39 = var37.getDownArrow();
//     var27.setDownArrow(var39);
//     org.jfree.chart.entity.ChartEntity var43 = new org.jfree.chart.entity.ChartEntity(var39, "", "Multiple Pie Plot");
//     var21.setArea(var39);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var32
//     assertTrue("Contract failed: equals-hashcode on var10 and var32", var10.equals(var32) ? var10.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var10
//     assertTrue("Contract failed: equals-hashcode on var32 and var10", var32.equals(var10) ? var32.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var1 = var0.getRadiusGridlineStroke();
//     java.awt.Stroke var2 = var0.getAngleGridlineStroke();
//     org.jfree.chart.renderer.PolarItemRenderer var3 = var0.getRenderer();
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var5 = var4.getAngleGridlineStroke();
//     boolean var6 = var4.isDomainZoomable();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var9 = var7.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     var7.setRangeAxis(10, var11);
//     int var13 = var7.getWeight();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     int var16 = var7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var15);
//     var15.setInverted(false);
//     double var19 = var15.getFixedAutoRange();
//     var15.zoomRange(0.025d, 0.05d);
//     org.jfree.data.Range var23 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var15);
//     var0.setAxis((org.jfree.chart.axis.ValueAxis)var15);
//     org.jfree.chart.axis.TickUnit var25 = var0.getAngleTickUnit();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     java.awt.geom.Point2D var36 = var35.getQuadrantOrigin();
//     var28.zoomDomainAxes(1.0d, var30, var36);
//     var0.zoomDomainAxes(0.2d, var27, var36, true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var35
//     assertTrue("Contract failed: equals-hashcode on var7 and var35", var7.equals(var35) ? var7.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var7
//     assertTrue("Contract failed: equals-hashcode on var35 and var7", var35.equals(var7) ? var35.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var13 = var12.getAngleGridlineStroke();
    var0.setDomainCrosshairStroke(var13);
    org.jfree.chart.axis.ValueAxis var15 = var0.getRangeAxis();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var18 = null;
    var17.setDataset(var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.data.Range var21 = var17.getDataRange(var20);
    java.lang.String var22 = var17.getPlotType();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    java.awt.geom.Point2D var28 = var27.getQuadrantOrigin();
    java.awt.geom.Point2D var29 = var27.getQuadrantOrigin();
    var27.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var32 = null;
    var27.setFixedRangeAxisSpace(var32, true);
    java.awt.Paint var36 = null;
    java.awt.Paint[] var37 = new java.awt.Paint[] { var36};
    java.awt.Paint[] var38 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var39 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var40 = null;
    java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
    java.awt.Stroke var42 = null;
    java.awt.Stroke[] var43 = new java.awt.Stroke[] { var42};
    java.awt.Shape var44 = null;
    java.awt.Shape[] var45 = new java.awt.Shape[] { var44};
    org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier(var37, var38, var39, var41, var43, var45);
    java.awt.Paint var47 = var46.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    var48.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
    var48.setRangeAxis((org.jfree.chart.axis.ValueAxis)var53);
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var56.setCategoryMargin(10.0d);
    java.awt.Stroke var59 = var56.getAxisLineStroke();
    var53.setTickMarkStroke(var59);
    org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker((-1.0d), var47, var59);
    org.jfree.chart.util.Layer var62 = null;
    var27.addRangeMarker((org.jfree.chart.plot.Marker)var61, var62);
    org.jfree.chart.util.Layer var64 = null;
    var17.addRangeMarker((org.jfree.chart.plot.Marker)var61, var64);
    java.lang.Object var66 = var61.clone();
    org.jfree.chart.event.MarkerChangeEvent var67 = null;
    var61.notifyListeners(var67);
    org.jfree.chart.util.Layer var69 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, (org.jfree.chart.plot.Marker)var61, var69);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Category Plot"+ "'", var22.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    java.awt.geom.Point2D var8 = var7.getQuadrantOrigin();
    var0.zoomDomainAxes(1.0d, var2, var8);
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.util.RectangleInsets var24 = var21.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleInsets var25 = var21.getItemLabelPadding();
    org.jfree.chart.block.BlockContainer var26 = var21.getItemContainer();
    boolean var27 = var21.getNotify();
    java.awt.Paint var28 = var21.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getShadowYOffset();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var4 = var2.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var2.setRangeAxis(0, var6, false);
    var2.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var2.setRangeAxes(var13);
    java.awt.Paint var15 = null;
    java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
    java.awt.Paint[] var17 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var18 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var23 = null;
    java.awt.Shape[] var24 = new java.awt.Shape[] { var23};
    org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var17, var18, var20, var22, var24);
    java.awt.Paint var26 = var25.getNextOutlinePaint();
    var2.setRangeGridlinePaint(var26);
    var0.setLabelShadowPaint(var26);
    org.jfree.chart.labels.PieToolTipGenerator var29 = null;
    var0.setToolTipGenerator(var29);
    org.jfree.chart.util.RectangleInsets var31 = var0.getSimpleLabelOffset();
    java.awt.Paint var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelLinkPaint(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var1 = var0.getRadiusGridlineStroke();
//     org.jfree.data.xy.XYDataset var2 = var0.getDataset();
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var4 = var3.getAngleGridlineStroke();
//     java.awt.Stroke var5 = var3.getAngleGridlineStroke();
//     var0.setRadiusGridlineStroke(var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Other", var1, 20.0d, 100.0f, (-1.0f));
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     var4.setDataset(var5);
//     boolean var7 = var3.equals((java.lang.Object)var4);
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
//     double var10 = var8.getExplodePercent((java.lang.Comparable)10L);
//     double var11 = var8.getLabelGap();
//     java.awt.Paint var12 = var8.getShadowPaint();
//     java.awt.Stroke var13 = var8.getSeparatorStroke();
//     var4.setDomainGridlineStroke(var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.util.Size2D var18 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var23 = var21.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     var21.setRangeAxis(10, var25);
//     java.awt.Stroke var27 = null;
//     var21.setOutlineStroke(var27);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     var21.setRenderer(1, var30);
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.FlowArrangement var36 = new org.jfree.chart.block.FlowArrangement(var32, var33, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var36, (org.jfree.chart.block.Arrangement)var41);
//     boolean var44 = var42.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var45 = var42.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var46 = var42.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var47 = var42.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var48 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, 0.05d, 0.2d, var47);
//     var4.drawBackground(var15, var48);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var12.getAutoRangeStickyZero();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setAutoRangeMinimumSize(6.25d);
    java.text.NumberFormat var19 = null;
    var12.setNumberFormatOverride(var19);
    var12.setTickLabelsVisible(false);
    var12.resizeRange((-11.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var12.getAutoRangeStickyZero();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setFixedAutoRange(20.0d);
    var12.setInverted(false);
    org.jfree.chart.axis.MarkerAxisBand var21 = var12.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(0.025d, 0.025d, 3.0d, 90.0d, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(0, var4, false);
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var0.setRangeAxes(var11);
    org.jfree.chart.annotations.CategoryAnnotation var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var14 = var0.removeAnnotation(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin(10.0d);
    java.awt.Stroke var5 = var2.getAxisLineStroke();
    var0.setLabelLinkStroke(var5);
    org.jfree.chart.event.PlotChangeListener var7 = null;
    var0.removeChangeListener(var7);
    java.awt.Paint var9 = var0.getSeparatorPaint();
    java.awt.Stroke var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeparatorStroke(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     double var1 = var0.getShadowYOffset();
//     double var2 = var0.getShadowYOffset();
//     java.awt.Font var3 = var0.getLabelFont();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.util.Size2D var7 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var12 = var10.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     var10.setRangeAxis(10, var14);
//     java.awt.Stroke var16 = null;
//     var10.setOutlineStroke(var16);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     var10.setRenderer(1, var19);
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.FlowArrangement var25 = new org.jfree.chart.block.FlowArrangement(var21, var22, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10, (org.jfree.chart.block.Arrangement)var25, (org.jfree.chart.block.Arrangement)var30);
//     boolean var33 = var31.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var34 = var31.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var35 = var31.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var36 = var31.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var37 = org.jfree.chart.util.RectangleAnchor.createRectangle(var7, 0.05d, 0.2d, var36);
//     org.jfree.chart.plot.PiePlot var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     org.jfree.chart.plot.PiePlotState var41 = var0.initialise(var4, var37, var38, (java.lang.Integer)1, var40);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.setMaximumCategoryLabelWidthRatio(1.0f);
    var1.setLabelAngle((-1.0d));
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var11 = var9.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var13 = null;
    var9.setRangeAxis(0, var13, false);
    var1.setPlot((org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.util.SortOrder var17 = var9.getRowRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.geom.Point2D var6 = var5.getQuadrantOrigin();
    java.awt.geom.Point2D var7 = var5.getQuadrantOrigin();
    var5.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var5.setFixedRangeAxisSpace(var10, true);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var14, var16, var17);
    var18.setOutlineVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    int var22 = var18.getIndexOf(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var1 = var0.getRadiusGridlineStroke();
//     java.awt.Stroke var2 = var0.getAngleGridlineStroke();
//     var0.zoom(0.14d);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(0, var9, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var6 = var4.calculateBottomInset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.FIXED", var1, 10.0f, (-1.0f), var4, (-11.0d), var6);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getShadowYOffset();
    double var2 = var0.getLabelGap();
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var4 = var3.getLabelShadowPaint();
    var0.setLabelPaint(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     boolean var4 = var0.isDomainGridlinesVisible();
//     org.jfree.data.category.CategoryDataset var6 = var0.getDataset(0);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.event.PlotChangeListener var11 = null;
//     var10.addChangeListener(var11);
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     var15.setRangeAxis(10, var19);
//     java.awt.Stroke var21 = null;
//     var15.setOutlineStroke(var21);
//     org.jfree.data.xy.XYDataset var23 = null;
//     int var24 = var15.indexOf(var23);
//     java.awt.geom.Point2D var25 = var15.getQuadrantOrigin();
//     var10.zoomRangeAxes(0.025d, var14, var25, true);
//     var0.zoomRangeAxes(3.0d, 0.025d, var9, var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=178,g=178,b=178]", var1);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    var0.setDataset(var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.data.Range var4 = var0.getDataRange(var3);
    java.lang.String var5 = var0.getPlotType();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    java.awt.geom.Point2D var12 = var10.getQuadrantOrigin();
    var10.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var10.setFixedRangeAxisSpace(var15, true);
    java.awt.Paint var19 = null;
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var22 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var23 = null;
    java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Shape var27 = null;
    java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var21, var22, var24, var26, var28);
    java.awt.Paint var30 = var29.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    var31.setRangeAxis((org.jfree.chart.axis.ValueAxis)var36);
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var39.setCategoryMargin(10.0d);
    java.awt.Stroke var42 = var39.getAxisLineStroke();
    var36.setTickMarkStroke(var42);
    org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker((-1.0d), var30, var42);
    org.jfree.chart.util.Layer var45 = null;
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var44, var45);
    org.jfree.chart.util.Layer var47 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var44, var47);
    org.jfree.chart.event.MarkerChangeEvent var49 = null;
    var44.notifyListeners(var49);
    org.jfree.chart.event.MarkerChangeEvent var51 = null;
    var44.notifyListeners(var51);
    org.jfree.chart.util.LengthAdjustmentType var53 = var44.getLabelOffsetType();
    java.lang.String var54 = var44.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Category Plot"+ "'", var5.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var3 = var0.getRootPlot();
    java.awt.Paint var5 = null;
    java.awt.Paint[] var6 = new java.awt.Paint[] { var5};
    java.awt.Paint[] var7 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var8 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var9 = null;
    java.awt.Stroke[] var10 = new java.awt.Stroke[] { var9};
    java.awt.Stroke var11 = null;
    java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
    java.awt.Shape var13 = null;
    java.awt.Shape[] var14 = new java.awt.Shape[] { var13};
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var7, var8, var10, var12, var14);
    java.awt.Paint var16 = var15.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    var17.setRangeAxis((org.jfree.chart.axis.ValueAxis)var22);
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var25.setCategoryMargin(10.0d);
    java.awt.Stroke var28 = var25.getAxisLineStroke();
    var22.setTickMarkStroke(var28);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker((-1.0d), var16, var28);
    java.awt.Paint var31 = var30.getLabelPaint();
    org.jfree.chart.util.RectangleAnchor var32 = var30.getLabelAnchor();
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var30);
    java.awt.Graphics2D var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    var0.drawBackgroundImage(var34, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var0.markerChanged(var3);
    float var5 = var0.getBackgroundImageAlpha();
    double var6 = var0.getLabelLinkMargin();
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot();
    double var11 = var9.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    var13.setRangeAxis((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var21.setCategoryMargin(10.0d);
    java.awt.Stroke var24 = var21.getAxisLineStroke();
    var18.setTickMarkStroke(var24);
    var9.setSectionOutlineStroke((java.lang.Comparable)1L, var24);
    org.jfree.chart.plot.AbstractPieLabelDistributor var27 = var9.getLabelDistributor();
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    org.jfree.chart.plot.PiePlotState var30 = var0.initialise(var7, var8, (org.jfree.chart.plot.PiePlot)var9, (java.lang.Integer)10, var29);
    double var31 = var0.getMaximumLabelWidth();
    java.lang.String var32 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "Pie Plot"+ "'", var32.equals("Pie Plot"));

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.configure();
    var1.setLowerMargin(1.0d);
    boolean var8 = var1.isAxisLineVisible();
    var1.setMaximumCategoryLabelLines(255);
    var1.setCategoryLabelPositionOffset((-1));
    var1.setTickMarkOutsideLength(100.0f);
    java.lang.Comparable var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var16 = var1.getCategoryLabelToolTip(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var6 = var5.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var5.setSimpleLabelOffset(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
//     var14.setWidth(20.0d);
//     var14.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var13.addSubtitle((org.jfree.chart.title.Title)var14);
//     org.jfree.chart.event.ChartChangeEventType var20 = null;
//     org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var13, var20);
//     java.awt.Stroke var22 = var13.getBorderStroke();
//     var13.setNotify(false);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     var25.setRangeAxis(10, var29);
//     java.awt.Stroke var31 = null;
//     var25.setOutlineStroke(var31);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     var25.setRenderer(1, var34);
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var41 = null;
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var45);
//     boolean var48 = var46.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot();
//     double var50 = var49.getShadowYOffset();
//     double var51 = var49.getShadowYOffset();
//     java.awt.Font var52 = var49.getLabelFont();
//     var46.setItemFont(var52);
//     var13.removeSubtitle((org.jfree.chart.title.Title)var46);
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var57 = var55.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     var55.setRangeAxis(10, var59);
//     java.awt.Stroke var61 = null;
//     var55.setOutlineStroke(var61);
//     org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
//     var55.setRenderer(1, var64);
//     org.jfree.chart.util.HorizontalAlignment var66 = null;
//     org.jfree.chart.util.VerticalAlignment var67 = null;
//     org.jfree.chart.block.FlowArrangement var70 = new org.jfree.chart.block.FlowArrangement(var66, var67, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var71 = null;
//     org.jfree.chart.util.VerticalAlignment var72 = null;
//     org.jfree.chart.block.ColumnArrangement var75 = new org.jfree.chart.block.ColumnArrangement(var71, var72, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55, (org.jfree.chart.block.Arrangement)var70, (org.jfree.chart.block.Arrangement)var75);
//     boolean var78 = var76.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var79 = var76.getLegendItemGraphicPadding();
//     var46.setItemLabelPadding(var79);
//     
//     // Checks the contract:  equals-hashcode on var25 and var55
//     assertTrue("Contract failed: equals-hashcode on var25 and var55", var25.equals(var55) ? var25.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var25
//     assertTrue("Contract failed: equals-hashcode on var55 and var25", var55.equals(var25) ? var55.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var70
//     assertTrue("Contract failed: equals-hashcode on var40 and var70", var40.equals(var70) ? var40.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var40
//     assertTrue("Contract failed: equals-hashcode on var70 and var40", var70.equals(var40) ? var70.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var75
//     assertTrue("Contract failed: equals-hashcode on var45 and var75", var45.equals(var75) ? var45.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var45
//     assertTrue("Contract failed: equals-hashcode on var75 and var45", var75.equals(var45) ? var75.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     var1.setMaximumCategoryLabelWidthRatio(1.0f);
//     var1.clearCategoryLabelToolTips();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var13 = var11.getDataset((-1));
//     org.jfree.chart.util.RectangleEdge var14 = var11.getDomainAxisEdge();
//     double var15 = var1.getCategoryStart(0, 10, var10, var14);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     var8.setRangeAxis(10, var12);
//     var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var8);
//     boolean var15 = var8.isDomainGridlinesVisible();
//     var8.mapDatasetToRangeAxis((-1), 0);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var21 = var19.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     var19.setRangeAxis(0, var23, false);
//     var19.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.ValueAxis[] var30 = new org.jfree.chart.axis.ValueAxis[] { var29};
//     var19.setRangeAxes(var30);
//     var8.setDomainAxes(var30);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     boolean var23 = var21.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.plot.CrosshairState var32 = null;
//     boolean var33 = var24.render(var28, var29, 0, var31, var32);
//     java.awt.Paint var35 = var24.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
//     var21.setPosition(var37);
//     org.jfree.chart.block.BlockContainer var39 = var21.getItemContainer();
//     java.awt.Graphics2D var40 = null;
//     org.jfree.data.Range var42 = null;
//     org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
//     org.jfree.chart.block.LengthConstraintType var46 = var45.getHeightConstraintType();
//     java.lang.String var47 = var46.toString();
//     org.jfree.data.Range var49 = null;
//     org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint((-11.0d), 0.025d);
//     org.jfree.chart.block.LengthConstraintType var53 = var52.getHeightConstraintType();
//     boolean var55 = var53.equals((java.lang.Object)(byte)100);
//     org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint(6.25d, var42, var46, 0.2d, var49, var53);
//     org.jfree.chart.util.Size2D var57 = var39.arrange(var40, var56);
//     org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement();
//     var58.clear();
//     var39.setArrangement((org.jfree.chart.block.Arrangement)var58);
//     org.jfree.chart.title.TextTitle var61 = new org.jfree.chart.title.TextTitle();
//     var61.setURLText("");
//     org.jfree.chart.util.RectangleInsets var64 = var61.getMargin();
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
//     var65.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("");
//     var65.setRangeAxis((org.jfree.chart.axis.ValueAxis)var70);
//     java.awt.Shape var72 = var70.getDownArrow();
//     var39.add((org.jfree.chart.block.Block)var61, (java.lang.Object)var72);
//     org.jfree.chart.block.ColumnArrangement var74 = new org.jfree.chart.block.ColumnArrangement();
//     var39.setArrangement((org.jfree.chart.block.Arrangement)var74);
//     
//     // Checks the contract:  equals-hashcode on var58 and var74
//     assertTrue("Contract failed: equals-hashcode on var58 and var74", var58.equals(var74) ? var58.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var58
//     assertTrue("Contract failed: equals-hashcode on var74 and var58", var74.equals(var58) ? var74.hashCode() == var58.hashCode() : true);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    java.awt.Stroke var4 = var0.getRangeCrosshairStroke();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.setCategoryMargin(10.0d);
    java.awt.Stroke var9 = var6.getAxisLineStroke();
    var6.configure();
    var6.setLowerMargin(1.0d);
    int var13 = var6.getMaximumCategoryLabelLines();
    var6.removeCategoryLabelToolTip((java.lang.Comparable)0L);
    var6.setTickMarksVisible(false);
    java.util.List var18 = var0.getCategoriesForAxis(var6);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var20.setCategoryMargin(10.0d);
    java.awt.Stroke var23 = var20.getAxisLineStroke();
    var20.setMaximumCategoryLabelWidthRatio(1.0f);
    var20.setLabelAngle(0.0d);
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var20.getCategoryStart(0, 0, var30, var31);
    org.jfree.chart.util.RectangleInsets var33 = var20.getLabelInsets();
    var6.setTickLabelInsets(var33);
    var6.setTickMarksVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var6, 0, 0);
    org.jfree.chart.JFreeChart var10 = null;
    var9.setChart(var10);
    int var12 = var9.getPercent();
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var14 = var13.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var13.setSimpleLabelOffset(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    var22.setWidth(20.0d);
    var22.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var21.addSubtitle((org.jfree.chart.title.Title)var22);
    var9.setChart(var21);
    java.lang.String var29 = var9.toString();
    var9.setType(0);
    org.jfree.chart.JFreeChart var32 = var9.getChart();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var33 = var32.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"+ "'", var29.equals("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     var0.setRangeAxis(0, var2, true);
//     org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var9.setLicenceName("hi!");
//     boolean var12 = var0.equals((java.lang.Object)"hi!");
//     java.lang.String var13 = var0.getPlotType();
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var18 = var15.getRootPlot();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var22 = var20.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var20.setRangeAxis(10, var24);
//     java.awt.Stroke var26 = null;
//     var20.setOutlineStroke(var26);
//     java.awt.Image var28 = null;
//     var20.setBackgroundImage(var28);
//     java.awt.Paint var31 = null;
//     java.awt.Paint[] var32 = new java.awt.Paint[] { var31};
//     java.awt.Paint[] var33 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var34 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var35 = null;
//     java.awt.Stroke[] var36 = new java.awt.Stroke[] { var35};
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Shape var39 = null;
//     java.awt.Shape[] var40 = new java.awt.Shape[] { var39};
//     org.jfree.chart.plot.DefaultDrawingSupplier var41 = new org.jfree.chart.plot.DefaultDrawingSupplier(var32, var33, var34, var36, var38, var40);
//     java.awt.Paint var42 = var41.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     var43.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var43.setRangeAxis((org.jfree.chart.axis.ValueAxis)var48);
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var51.setCategoryMargin(10.0d);
//     java.awt.Stroke var54 = var51.getAxisLineStroke();
//     var48.setTickMarkStroke(var54);
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker((-1.0d), var42, var54);
//     var20.setDomainZeroBaselineStroke(var54);
//     org.jfree.chart.axis.AxisLocation var58 = var20.getRangeAxisLocation();
//     var15.setDomainAxisLocation(10, var58);
//     var0.setRangeAxisLocation(10, var58, false);
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var65 = var63.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var66 = var63.getRootPlot();
//     java.awt.Graphics2D var67 = null;
//     java.awt.geom.Rectangle2D var68 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var70 = null;
//     org.jfree.chart.plot.CrosshairState var71 = null;
//     boolean var72 = var63.render(var67, var68, 0, var70, var71);
//     var63.setOutlineVisible(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var75 = var63.getRenderer();
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var78 = var76.getDomainAxis((-1));
//     boolean var79 = var76.isRangeGridlinesVisible();
//     org.jfree.chart.LegendItemCollection var80 = var76.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var82 = var76.getDomainAxisLocation(0);
//     var63.setDomainAxisLocation(var82, false);
//     var0.setRangeAxisLocation(0, var82, true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var15
//     assertTrue("Contract failed: equals-hashcode on var76 and var15", var76.equals(var15) ? var76.hashCode() == var15.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var76 and var15.", var76.equals(var15) == var15.equals(var76));
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    var9.setLicenceName("hi!");
    boolean var12 = var0.equals((java.lang.Object)"hi!");
    boolean var13 = var0.getDrawSharedDomainAxis();
    int var14 = var0.getDomainAxisCount();
    org.jfree.chart.axis.CategoryAxis var15 = var0.getDomainAxis();
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis((-1));
    boolean var20 = var17.isRangeGridlinesVisible();
    org.jfree.chart.LegendItemCollection var21 = var17.getLegendItems();
    org.jfree.chart.axis.AxisLocation var23 = var17.getDomainAxisLocation(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-65536), var23, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     java.awt.Image var8 = null;
//     var0.setBackgroundImage(var8);
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var19 = null;
//     java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
//     java.awt.Paint var22 = var21.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var31.setCategoryMargin(10.0d);
//     java.awt.Stroke var34 = var31.getAxisLineStroke();
//     var28.setTickMarkStroke(var34);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker((-1.0d), var22, var34);
//     var0.setDomainZeroBaselineStroke(var34);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var39.setCategoryMargin(10.0d);
//     java.awt.Stroke var42 = var39.getAxisLineStroke();
//     var0.setDomainCrosshairStroke(var42);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
//     var44.setRangeAxis((org.jfree.chart.axis.ValueAxis)var49);
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var52.setCategoryMargin(10.0d);
//     java.awt.Stroke var55 = var52.getAxisLineStroke();
//     var49.setTickMarkStroke(var55);
//     double var57 = var49.getLowerMargin();
//     org.jfree.data.RangeType var58 = var49.getRangeType();
//     var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var49);
//     
//     // Checks the contract:  equals-hashcode on var23 and var44
//     assertTrue("Contract failed: equals-hashcode on var23 and var44", var23.equals(var44) ? var23.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var23
//     assertTrue("Contract failed: equals-hashcode on var44 and var23", var44.equals(var23) ? var44.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var5 = null;
    var4.setDataset(var5);
    boolean var7 = var3.equals((java.lang.Object)var4);
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot();
    double var10 = var8.getExplodePercent((java.lang.Comparable)10L);
    double var11 = var8.getLabelGap();
    java.awt.Paint var12 = var8.getShadowPaint();
    java.awt.Stroke var13 = var8.getSeparatorStroke();
    var4.setDomainGridlineStroke(var13);
    boolean var15 = var4.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var1 = var0.getLogo();
    java.util.List var2 = var0.getContributors();
    java.lang.String var3 = var0.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Color var8 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    java.awt.image.ColorModel var9 = null;
    java.awt.Rectangle var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.awt.geom.AffineTransform var12 = null;
    java.awt.RenderingHints var13 = null;
    java.awt.PaintContext var14 = var8.createContext(var9, var10, var11, var12, var13);
    java.awt.Color var15 = var8.brighter();
    var4.setOutlinePaint((java.awt.Paint)var8);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedDomainAxisSpace();
    org.jfree.chart.annotations.XYAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 20.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var9 = var7.trimWidth(10.0d);
    var2.setLabelPadding(var7);
    boolean var11 = var2.isCircular();
    double var12 = var2.getStartAngle();
    java.awt.Stroke var13 = var2.getBaseSectionOutlineStroke();
    var0.put((java.lang.Comparable)8.0d, var13);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, (-10223606), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     var5.setAutoRangeStickyZero(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     java.awt.Shape var17 = var15.getDownArrow();
//     var5.setDownArrow(var17);
//     org.jfree.chart.plot.Plot var19 = var5.getPlot();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     java.awt.geom.Point2D var29 = var28.getQuadrantOrigin();
//     var21.zoomDomainAxes(1.0d, var23, var29);
//     org.jfree.chart.util.RectangleInsets var31 = var21.getAxisOffset();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     var32.setWidth(20.0d);
//     var32.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var32.setURLText("Category Plot");
//     double var39 = var32.getWidth();
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.util.Size2D var43 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var48 = var46.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     var46.setRangeAxis(10, var50);
//     java.awt.Stroke var52 = null;
//     var46.setOutlineStroke(var52);
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     var46.setRenderer(1, var55);
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.FlowArrangement var61 = new org.jfree.chart.block.FlowArrangement(var57, var58, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var62 = null;
//     org.jfree.chart.util.VerticalAlignment var63 = null;
//     org.jfree.chart.block.ColumnArrangement var66 = new org.jfree.chart.block.ColumnArrangement(var62, var63, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46, (org.jfree.chart.block.Arrangement)var61, (org.jfree.chart.block.Arrangement)var66);
//     boolean var69 = var67.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var70 = var67.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var71 = var67.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var72 = var67.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var43, 0.05d, 0.2d, var72);
//     var32.draw(var40, var73);
//     java.awt.geom.Rectangle2D var75 = var31.createOutsetRectangle(var73);
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     var76.setRangeAxis(0, var78, true);
//     org.jfree.chart.ui.BasicProjectInfo var85 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var85.setLicenceName("hi!");
//     boolean var88 = var76.equals((java.lang.Object)"hi!");
//     org.jfree.data.category.CategoryDataset var90 = null;
//     var76.setDataset(10, var90);
//     java.awt.Paint var92 = var76.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var93 = var76.getDomainAxisEdge();
//     double var94 = var5.valueToJava2D(6.25d, var75, var93);
//     
//     // Checks the contract:  equals-hashcode on var21 and var76
//     assertTrue("Contract failed: equals-hashcode on var21 and var76", var21.equals(var76) ? var21.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var21
//     assertTrue("Contract failed: equals-hashcode on var76 and var21", var76.equals(var21) ? var76.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.configure();
    var1.setLowerMargin(1.0d);
    int var8 = var1.getMaximumCategoryLabelLines();
    var1.setLowerMargin(0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    double var6 = var0.getDomainCrosshairValue();
    double var7 = var0.getDomainCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.data.general.DatasetGroup var3 = var0.getDatasetGroup();
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(1, var5);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getDomainMarkers(var7);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     var40.setDataset(var41);
//     boolean var43 = var39.equals((java.lang.Object)var40);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
//     org.jfree.chart.text.TextLine var45 = var44.getLastLine();
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var47 = var46.getTextAlignment();
//     var44.setLineAlignment(var47);
//     org.jfree.chart.util.HorizontalAlignment var49 = var44.getLineAlignment();
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.text.TextBlockAnchor var53 = null;
//     var44.draw(var50, 0.0f, 100.0f, var53);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
//     int var5 = var4.getItemCount();
//     org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var12 = var10.trimWidth(10.0d);
//     java.lang.String var13 = var10.toString();
//     boolean var14 = var4.equals((java.lang.Object)var10);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis((-1));
//     boolean var18 = var15.isRangeGridlinesVisible();
//     org.jfree.chart.LegendItemCollection var19 = var15.getLegendItems();
//     int var20 = var19.getItemCount();
//     int var21 = var19.getItemCount();
//     var4.addAll(var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var9 = var7.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     var7.setRangeAxis(10, var11);
//     java.awt.Stroke var13 = null;
//     var7.setOutlineStroke(var13);
//     java.awt.Image var15 = null;
//     var7.setBackgroundImage(var15);
//     java.awt.Paint var18 = null;
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
//     java.awt.Paint[] var20 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Stroke var24 = null;
//     java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
//     java.awt.Shape var26 = null;
//     java.awt.Shape[] var27 = new java.awt.Shape[] { var26};
//     org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier(var19, var20, var21, var23, var25, var27);
//     java.awt.Paint var29 = var28.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setRangeAxis((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var38.setCategoryMargin(10.0d);
//     java.awt.Stroke var41 = var38.getAxisLineStroke();
//     var35.setTickMarkStroke(var41);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker((-1.0d), var29, var41);
//     var7.setDomainZeroBaselineStroke(var41);
//     org.jfree.chart.axis.AxisLocation var45 = var7.getRangeAxisLocation();
//     java.lang.String var46 = var7.getPlotType();
//     java.awt.Stroke var47 = var7.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var50 = var48.getDomainAxis((-1));
//     boolean var51 = var48.isRangeGridlinesVisible();
//     var48.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.RingPlot var54 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Paint var55 = var54.getLabelLinkPaint();
//     var48.setDomainTickBandPaint(var55);
//     java.awt.Paint var57 = var48.getNoDataMessagePaint();
//     var7.setRangeZeroBaselinePaint(var57);
//     var5.setLabelPaint(var57);
//     
//     // Checks the contract:  equals-hashcode on var0 and var30
//     assertTrue("Contract failed: equals-hashcode on var0 and var30", var0.equals(var30) ? var0.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var0
//     assertTrue("Contract failed: equals-hashcode on var30 and var0", var30.equals(var0) ? var30.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    java.lang.Object var15 = var9.clone();
    double var16 = var9.getHeight();
    org.jfree.chart.block.BlockFrame var17 = var9.getFrame();
    boolean var18 = var9.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot();
//     double var5 = var3.getExplodePercent((java.lang.Comparable)10L);
//     var3.setMaximumLabelWidth((-11.0d));
//     org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var15 = var13.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     var13.setRangeAxis(10, var17);
//     java.awt.Stroke var19 = null;
//     var13.setOutlineStroke(var19);
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     var13.setRenderer(1, var22);
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.util.VerticalAlignment var25 = null;
//     org.jfree.chart.block.FlowArrangement var28 = new org.jfree.chart.block.FlowArrangement(var24, var25, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13, (org.jfree.chart.block.Arrangement)var28, (org.jfree.chart.block.Arrangement)var33);
//     boolean var36 = var34.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var37 = var34.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var38 = var34.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var39 = var34.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, 0.05d, 0.2d, var39);
//     var3.setLegendItemShape((java.awt.Shape)var40);
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     org.jfree.chart.axis.AxisState var45 = var0.draw(var1, 4.0d, var40, var42, var43, var44);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    float var3 = var0.getBackgroundImageAlpha();
    var0.clearDomainMarkers();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    java.awt.geom.Point2D var11 = var10.getQuadrantOrigin();
    java.awt.Paint var13 = null;
    java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
    java.awt.Paint[] var15 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var16 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Shape var21 = null;
    java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var15, var16, var18, var20, var22);
    java.awt.Paint var24 = var23.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    var25.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    var25.setRangeAxis((org.jfree.chart.axis.ValueAxis)var30);
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var33.setCategoryMargin(10.0d);
    java.awt.Stroke var36 = var33.getAxisLineStroke();
    var30.setTickMarkStroke(var36);
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker((-1.0d), var24, var36);
    org.jfree.chart.util.Layer var39 = null;
    var10.addRangeMarker((org.jfree.chart.plot.Marker)var38, var39);
    org.jfree.chart.util.Layer var41 = null;
    var0.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var38, var41);
    org.jfree.chart.annotations.CategoryAnnotation var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var44 = var0.removeAnnotation(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

//  public void test361() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("ChartChangeEventType.GENERAL", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var5.setRenderer(0, var7);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    java.awt.geom.Point2D var16 = var15.getQuadrantOrigin();
    var5.zoomRangeAxes((-1.0d), var10, var16, false);
    boolean var19 = var4.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    var5.setRenderer(var20, false);
    org.jfree.chart.axis.AxisLocation var24 = var5.getDomainAxisLocation(4);
    org.jfree.chart.plot.PlotOrientation var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var26 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var24, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     var40.setDataset(var41);
//     boolean var43 = var39.equals((java.lang.Object)var40);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
//     org.jfree.chart.text.TextLine var45 = var44.getLastLine();
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.text.TextAnchor var49 = null;
//     var45.draw(var46, 1.0f, 1.0f, var49, 10.0f, 10.0f, 4.0d);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = var2.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var2.setSimpleLabelOffset(var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var11 = var2.getLabelGenerator();
    org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot();
    double var14 = var12.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
    var16.setRangeAxis((org.jfree.chart.axis.ValueAxis)var21);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var24.setCategoryMargin(10.0d);
    java.awt.Stroke var27 = var24.getAxisLineStroke();
    var21.setTickMarkStroke(var27);
    var12.setSectionOutlineStroke((java.lang.Comparable)1L, var27);
    var2.setLabelOutlineStroke(var27);
    java.awt.Paint var31 = var2.getBaseSectionPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var1, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets(0.14d, 0.05d, 90.0d, (-11.0d));
//     var1.setTickLabelInsets(var6);
//     boolean var8 = var1.getAutoRangeStickyZero();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var13 = var11.getRangeAxis(0);
//     java.util.List var14 = var11.getCategories();
//     org.jfree.chart.util.RectangleEdge var16 = var11.getRangeAxisEdge(10);
//     double var17 = var1.valueToJava2D(6.25d, var10, var16);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     org.jfree.chart.JFreeChart var6 = null;
//     org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var6, 0, 0);
//     org.jfree.chart.JFreeChart var10 = null;
//     var9.setChart(var10);
//     int var12 = var9.getPercent();
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var14 = var13.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var13.setSimpleLabelOffset(var19);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
//     var22.setWidth(20.0d);
//     var22.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var21.addSubtitle((org.jfree.chart.title.Title)var22);
//     var9.setChart(var21);
//     java.lang.String var29 = var9.toString();
//     var9.setType(0);
//     org.jfree.chart.JFreeChart var32 = var9.getChart();
//     org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var34.setCategoryMargin(10.0d);
//     java.awt.Stroke var37 = var34.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var39 = var38.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var44 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var38.setSimpleLabelOffset(var44);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
//     org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle();
//     var47.setWidth(20.0d);
//     var47.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var46.addSubtitle((org.jfree.chart.title.Title)var47);
//     org.jfree.chart.event.ChartChangeEventType var53 = null;
//     org.jfree.chart.event.ChartChangeEvent var54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var34, var46, var53);
//     java.awt.Stroke var55 = var46.getBorderStroke();
//     org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle();
//     var56.setWidth(20.0d);
//     var56.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var56.setURLText("Category Plot");
//     var46.removeSubtitle((org.jfree.chart.title.Title)var56);
//     java.awt.Stroke var64 = var46.getBorderStroke();
//     var9.setChart(var46);
//     
//     // Checks the contract:  equals-hashcode on var13 and var38
//     assertTrue("Contract failed: equals-hashcode on var13 and var38", var13.equals(var38) ? var13.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var13
//     assertTrue("Contract failed: equals-hashcode on var38 and var13", var38.equals(var13) ? var38.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     var0.setRenderer(1, var9);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     org.jfree.chart.plot.CrosshairState var26 = null;
//     boolean var27 = var0.render(var22, var23, 10, var25, var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     java.awt.geom.Point2D var37 = var36.getQuadrantOrigin();
//     var29.zoomDomainAxes(1.0d, var31, var37);
//     org.jfree.chart.util.RectangleInsets var39 = var29.getAxisOffset();
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle();
//     var40.setWidth(20.0d);
//     var40.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var40.setURLText("Category Plot");
//     double var47 = var40.getWidth();
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.util.Size2D var51 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var56 = var54.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     var54.setRangeAxis(10, var58);
//     java.awt.Stroke var60 = null;
//     var54.setOutlineStroke(var60);
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     var54.setRenderer(1, var63);
//     org.jfree.chart.util.HorizontalAlignment var65 = null;
//     org.jfree.chart.util.VerticalAlignment var66 = null;
//     org.jfree.chart.block.FlowArrangement var69 = new org.jfree.chart.block.FlowArrangement(var65, var66, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var70 = null;
//     org.jfree.chart.util.VerticalAlignment var71 = null;
//     org.jfree.chart.block.ColumnArrangement var74 = new org.jfree.chart.block.ColumnArrangement(var70, var71, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54, (org.jfree.chart.block.Arrangement)var69, (org.jfree.chart.block.Arrangement)var74);
//     boolean var77 = var75.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var78 = var75.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var79 = var75.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var80 = var75.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var81 = org.jfree.chart.util.RectangleAnchor.createRectangle(var51, 0.05d, 0.2d, var80);
//     var40.draw(var48, var81);
//     java.awt.geom.Rectangle2D var83 = var39.createOutsetRectangle(var81);
//     org.jfree.chart.plot.PlotRenderingInfo var85 = null;
//     org.jfree.chart.plot.CrosshairState var86 = null;
//     boolean var87 = var0.render(var28, var83, 2, var85, var86);
//     
//     // Checks the contract:  equals-hashcode on var0 and var54
//     assertTrue("Contract failed: equals-hashcode on var0 and var54", var0.equals(var54) ? var0.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var0
//     assertTrue("Contract failed: equals-hashcode on var54 and var0", var54.equals(var0) ? var54.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var69
//     assertTrue("Contract failed: equals-hashcode on var15 and var69", var15.equals(var69) ? var15.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var15
//     assertTrue("Contract failed: equals-hashcode on var69 and var15", var69.equals(var15) ? var69.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var74
//     assertTrue("Contract failed: equals-hashcode on var20 and var74", var20.equals(var74) ? var20.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var20
//     assertTrue("Contract failed: equals-hashcode on var74 and var20", var74.equals(var20) ? var74.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var0.setSimpleLabelOffset(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     var9.setWidth(20.0d);
//     var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var8.addSubtitle((org.jfree.chart.title.Title)var9);
//     boolean var16 = var8.equals((java.lang.Object)(byte)1);
//     java.lang.Object var17 = var8.getTextAntiAlias();
//     java.util.List var18 = null;
//     var8.setSubtitles(var18);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
    double var4 = var2.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var6.setRangeAxis((org.jfree.chart.axis.ValueAxis)var11);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var14.setCategoryMargin(10.0d);
    java.awt.Stroke var17 = var14.getAxisLineStroke();
    var11.setTickMarkStroke(var17);
    var2.setSectionOutlineStroke((java.lang.Comparable)1L, var17);
    org.jfree.chart.plot.AbstractPieLabelDistributor var20 = var2.getLabelDistributor();
    double var21 = var2.getShadowXOffset();
    java.awt.Paint var22 = var2.getLabelPaint();
    boolean var23 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.util.RectangleAnchor var24 = var1.getLabelAnchor();
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot();
    var26.setLabelLinkMargin(0.0d);
    var26.setLabelLinkMargin(20.0d);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var33 = var31.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var35 = null;
    var31.setRangeAxis(10, var35);
    java.awt.Stroke var37 = null;
    var31.setOutlineStroke(var37);
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    var31.setRenderer(1, var40);
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.FlowArrangement var46 = new org.jfree.chart.block.FlowArrangement(var42, var43, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var47 = null;
    org.jfree.chart.util.VerticalAlignment var48 = null;
    org.jfree.chart.block.ColumnArrangement var51 = new org.jfree.chart.block.ColumnArrangement(var47, var48, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31, (org.jfree.chart.block.Arrangement)var46, (org.jfree.chart.block.Arrangement)var51);
    boolean var54 = var52.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var55 = new org.jfree.chart.plot.PiePlot();
    double var56 = var55.getShadowYOffset();
    double var57 = var55.getShadowYOffset();
    java.awt.Font var58 = var55.getLabelFont();
    var52.setItemFont(var58);
    var26.setLabelFont(var58);
    java.awt.Color var64 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var66 = null;
    var65.setDataset(var66);
    boolean var68 = var64.equals((java.lang.Object)var65);
    org.jfree.chart.text.TextBlock var69 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var58, (java.awt.Paint)var64);
    var1.setLabelFont(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setRangeAxis((org.jfree.chart.axis.ValueAxis)var6);
//     boolean var8 = var6.getAutoRangeStickyZero();
//     java.awt.Font var9 = var6.getLabelFont();
//     java.awt.Color var13 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     java.awt.image.ColorModel var14 = null;
//     java.awt.Rectangle var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     java.awt.geom.AffineTransform var17 = null;
//     java.awt.RenderingHints var18 = null;
//     java.awt.PaintContext var19 = var13.createContext(var14, var15, var16, var17, var18);
//     java.awt.Color var20 = var13.brighter();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.text.G2TextMeasurer var24 = new org.jfree.chart.text.G2TextMeasurer(var23);
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var9, (java.awt.Paint)var20, 1.0f, 2, (org.jfree.chart.text.TextMeasurer)var24);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     java.awt.Stroke var4 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     var0.setRenderer(var5, false);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var9 = null;
//     var8.setDataset(var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.data.Range var12 = var8.getDataRange(var11);
//     java.lang.String var13 = var8.getPlotType();
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     java.awt.geom.Point2D var19 = var18.getQuadrantOrigin();
//     java.awt.geom.Point2D var20 = var18.getQuadrantOrigin();
//     var18.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var23 = null;
//     var18.setFixedRangeAxisSpace(var23, true);
//     java.awt.Paint var27 = null;
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     java.awt.Paint[] var29 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var30 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var31 = null;
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     java.awt.Stroke var33 = null;
//     java.awt.Stroke[] var34 = new java.awt.Stroke[] { var33};
//     java.awt.Shape var35 = null;
//     java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var28, var29, var30, var32, var34, var36);
//     java.awt.Paint var38 = var37.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     var39.setRangeAxis((org.jfree.chart.axis.ValueAxis)var44);
//     org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var47.setCategoryMargin(10.0d);
//     java.awt.Stroke var50 = var47.getAxisLineStroke();
//     var44.setTickMarkStroke(var50);
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker((-1.0d), var38, var50);
//     org.jfree.chart.util.Layer var53 = null;
//     var18.addRangeMarker((org.jfree.chart.plot.Marker)var52, var53);
//     org.jfree.chart.util.Layer var55 = null;
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var52, var55);
//     java.lang.Object var57 = var52.clone();
//     org.jfree.chart.event.MarkerChangeEvent var58 = null;
//     var52.notifyListeners(var58);
//     boolean var60 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var52);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var0.markerChanged(var3);
    org.jfree.chart.labels.PieToolTipGenerator var5 = null;
    var0.setToolTipGenerator(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    java.awt.Color var2 = java.awt.Color.getColor("", (-1));
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    double var4 = var3.getShadowYOffset();
    double var5 = var3.getShadowYOffset();
    java.awt.Font var6 = var3.getLabelFont();
    java.awt.Paint var7 = var3.getBaseSectionPaint();
    boolean var8 = var2.equals((java.lang.Object)var3);
    org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var15 = var13.extendWidth(10.0d);
    var3.setLabelPadding(var13);
    org.jfree.chart.urls.PieURLGenerator var17 = var3.getURLGenerator();
    var3.setIgnoreNullValues(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 20.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     java.awt.Image var8 = null;
//     var0.setBackgroundImage(var8);
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var19 = null;
//     java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
//     java.awt.Paint var22 = var21.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var31.setCategoryMargin(10.0d);
//     java.awt.Stroke var34 = var31.getAxisLineStroke();
//     var28.setTickMarkStroke(var34);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker((-1.0d), var22, var34);
//     var0.setDomainZeroBaselineStroke(var34);
//     org.jfree.chart.axis.AxisLocation var38 = var0.getRangeAxisLocation();
//     java.lang.String var39 = var0.getPlotType();
//     org.jfree.data.xy.XYDataset var41 = var0.getDataset(10);
//     java.awt.Paint var42 = var0.getRangeZeroBaselinePaint();
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     java.awt.geom.Point2D var52 = var51.getQuadrantOrigin();
//     var44.zoomDomainAxes(1.0d, var46, var52);
//     org.jfree.chart.util.RectangleInsets var54 = var44.getAxisOffset();
//     org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle();
//     var55.setWidth(20.0d);
//     var55.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var55.setURLText("Category Plot");
//     double var62 = var55.getWidth();
//     java.awt.Graphics2D var63 = null;
//     org.jfree.chart.util.Size2D var66 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var71 = var69.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     var69.setRangeAxis(10, var73);
//     java.awt.Stroke var75 = null;
//     var69.setOutlineStroke(var75);
//     org.jfree.chart.renderer.xy.XYItemRenderer var78 = null;
//     var69.setRenderer(1, var78);
//     org.jfree.chart.util.HorizontalAlignment var80 = null;
//     org.jfree.chart.util.VerticalAlignment var81 = null;
//     org.jfree.chart.block.FlowArrangement var84 = new org.jfree.chart.block.FlowArrangement(var80, var81, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var85 = null;
//     org.jfree.chart.util.VerticalAlignment var86 = null;
//     org.jfree.chart.block.ColumnArrangement var89 = new org.jfree.chart.block.ColumnArrangement(var85, var86, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var90 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var69, (org.jfree.chart.block.Arrangement)var84, (org.jfree.chart.block.Arrangement)var89);
//     boolean var92 = var90.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var93 = var90.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var94 = var90.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var95 = var90.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var96 = org.jfree.chart.util.RectangleAnchor.createRectangle(var66, 0.05d, 0.2d, var95);
//     var55.draw(var63, var96);
//     java.awt.geom.Rectangle2D var98 = var54.createOutsetRectangle(var96);
//     var0.drawBackground(var43, var96);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    java.awt.Shape var0 = null;
    org.jfree.data.general.PieDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PieSectionEntity var7 = new org.jfree.chart.entity.PieSectionEntity(var0, var1, 0, (-65536), (java.lang.Comparable)256, "", "org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("XY Plot", "RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var3);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var7 = var5.trimWidth(10.0d);
    var0.setLabelPadding(var5);
    boolean var9 = var0.isCircular();
    java.awt.Paint var10 = var0.getShadowPaint();
    org.jfree.chart.urls.PieURLGenerator var11 = null;
    var0.setLegendLabelURLGenerator(var11);
    java.lang.String var13 = var0.getPlotType();
    org.jfree.chart.labels.PieSectionLabelGenerator var14 = var0.getLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Pie Plot"+ "'", var13.equals("Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(0, var4, false);
    org.jfree.chart.axis.CategoryAnchor var7 = var0.getDomainGridlinePosition();
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxisForDataset(4);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    java.awt.geom.Point2D var16 = var15.getQuadrantOrigin();
    java.awt.Paint var18 = null;
    java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
    java.awt.Paint[] var20 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var22 = null;
    java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
    java.awt.Stroke var24 = null;
    java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
    java.awt.Shape var26 = null;
    java.awt.Shape[] var27 = new java.awt.Shape[] { var26};
    org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier(var19, var20, var21, var23, var25, var27);
    java.awt.Paint var29 = var28.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    var30.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
    var30.setRangeAxis((org.jfree.chart.axis.ValueAxis)var35);
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var38.setCategoryMargin(10.0d);
    java.awt.Stroke var41 = var38.getAxisLineStroke();
    var35.setTickMarkStroke(var41);
    org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker((-1.0d), var29, var41);
    org.jfree.chart.util.Layer var44 = null;
    var15.addRangeMarker((org.jfree.chart.plot.Marker)var43, var44);
    org.jfree.chart.util.Layer var46 = null;
    var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var43, var46);
    var43.setAlpha(0.0f);
    var43.setLabel("HorizontalAlignment.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
    double var3 = var2.getHeight();
    var2.setHeight(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     var0.clear();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var4 = var2.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var2.setRangeAxis(10, var6);
//     java.awt.Stroke var8 = null;
//     var2.setOutlineStroke(var8);
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     var2.setRenderer(1, var11);
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var18 = null;
//     org.jfree.chart.util.VerticalAlignment var19 = null;
//     org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, (org.jfree.chart.block.Arrangement)var17, (org.jfree.chart.block.Arrangement)var22);
//     boolean var25 = var23.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot();
//     double var27 = var26.getShadowYOffset();
//     double var28 = var26.getShadowYOffset();
//     java.awt.Font var29 = var26.getLabelFont();
//     var23.setItemFont(var29);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.util.Size2D var32 = var23.arrange(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     var33.setRangeAxis(0, var35, true);
//     java.awt.Paint var38 = var33.getRangeCrosshairPaint();
//     var0.add((org.jfree.chart.block.Block)var23, (java.lang.Object)var38);
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var42 = var40.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     var40.setRangeAxis(10, var44);
//     java.awt.Stroke var46 = null;
//     var40.setOutlineStroke(var46);
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     var40.setRenderer(1, var49);
//     org.jfree.chart.util.HorizontalAlignment var51 = null;
//     org.jfree.chart.util.VerticalAlignment var52 = null;
//     org.jfree.chart.block.FlowArrangement var55 = new org.jfree.chart.block.FlowArrangement(var51, var52, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var56 = null;
//     org.jfree.chart.util.VerticalAlignment var57 = null;
//     org.jfree.chart.block.ColumnArrangement var60 = new org.jfree.chart.block.ColumnArrangement(var56, var57, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40, (org.jfree.chart.block.Arrangement)var55, (org.jfree.chart.block.Arrangement)var60);
//     boolean var63 = var61.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var64 = var61.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var65 = var61.getItemLabelPadding();
//     org.jfree.chart.block.BlockContainer var66 = var61.getItemContainer();
//     java.awt.Color var70 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var72 = null;
//     var71.setDataset(var72);
//     boolean var74 = var70.equals((java.lang.Object)var71);
//     org.jfree.chart.axis.AxisSpace var75 = var71.getFixedDomainAxisSpace();
//     org.jfree.chart.axis.AxisSpace var76 = var71.getFixedRangeAxisSpace();
//     var71.configureDomainAxes();
//     var0.add((org.jfree.chart.block.Block)var61, (java.lang.Object)var71);
//     
//     // Checks the contract:  equals-hashcode on var22 and var60
//     assertTrue("Contract failed: equals-hashcode on var22 and var60", var22.equals(var60) ? var22.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var22
//     assertTrue("Contract failed: equals-hashcode on var60 and var22", var60.equals(var22) ? var60.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var40
//     assertTrue("Contract failed: equals-hashcode on var2 and var40", var2.equals(var40) ? var2.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var2
//     assertTrue("Contract failed: equals-hashcode on var40 and var2", var40.equals(var2) ? var40.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var55
//     assertTrue("Contract failed: equals-hashcode on var17 and var55", var17.equals(var55) ? var17.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var17
//     assertTrue("Contract failed: equals-hashcode on var55 and var17", var55.equals(var17) ? var55.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var71
//     assertTrue("Contract failed: equals-hashcode on var33 and var71", var33.equals(var71) ? var33.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var33
//     assertTrue("Contract failed: equals-hashcode on var71 and var33", var71.equals(var33) ? var71.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     var0.setRangeAxis(0, var2, true);
//     org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var9.setLicenceName("hi!");
//     boolean var12 = var0.equals((java.lang.Object)"hi!");
//     boolean var13 = var0.getDrawSharedDomainAxis();
//     int var14 = var0.getDomainAxisCount();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
//     var15.setRangeAxis((org.jfree.chart.axis.ValueAxis)var20);
//     boolean var22 = var20.getAutoRangeStickyZero();
//     var20.setAutoRangeStickyZero(false);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setRangeAxis((org.jfree.chart.axis.ValueAxis)var30);
//     java.awt.Shape var32 = var30.getDownArrow();
//     var20.setDownArrow(var32);
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var20);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var4 = var3.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var3.setSimpleLabelOffset(var9);
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
//     org.jfree.chart.ChartRenderingInfo var14 = null;
//     java.awt.image.BufferedImage var15 = var11.createBufferedImage(10, 256, var14);
//     org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("Pie Plot", "XY Plot", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.awt.Image)var15, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "Multiple Pie Plot", "");
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = var23.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var23.setSimpleLabelOffset(var29);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     java.awt.image.BufferedImage var35 = var31.createBufferedImage(10, 256, var34);
//     org.jfree.chart.ui.ProjectInfo var39 = new org.jfree.chart.ui.ProjectInfo("Pie Plot", "XY Plot", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.awt.Image)var35, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "Multiple Pie Plot", "");
//     var19.setLogo((java.awt.Image)var35);
//     
//     // Checks the contract:  equals-hashcode on var3 and var23
//     assertTrue("Contract failed: equals-hashcode on var3 and var23", var3.equals(var23) ? var3.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var3
//     assertTrue("Contract failed: equals-hashcode on var23 and var3", var23.equals(var3) ? var23.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var31
//     assertTrue("Contract failed: equals-hashcode on var11 and var31", var11.equals(var31) ? var11.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var11
//     assertTrue("Contract failed: equals-hashcode on var31 and var11", var31.equals(var11) ? var31.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var1 = var0.getRadiusGridlineStroke();
//     java.awt.Stroke var2 = var0.getAngleGridlineStroke();
//     java.awt.Stroke var3 = null;
//     var0.setRadiusGridlineStroke(var3);
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot();
//     double var9 = var7.getExplodePercent((java.lang.Comparable)10L);
//     var7.setMaximumLabelWidth((-11.0d));
//     org.jfree.chart.util.Size2D var14 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     var17.setRangeAxis(10, var21);
//     java.awt.Stroke var23 = null;
//     var17.setOutlineStroke(var23);
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     var17.setRenderer(1, var26);
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement(var28, var29, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var33, var34, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, (org.jfree.chart.block.Arrangement)var32, (org.jfree.chart.block.Arrangement)var37);
//     boolean var40 = var38.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var41 = var38.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var42 = var38.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var43 = var38.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var14, 0.05d, 0.2d, var43);
//     var7.setLegendItemShape((java.awt.Shape)var44);
//     java.awt.Point var46 = var0.translateValueThetaRadiusToJava2D((-2.0d), (-2.0d), var44);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var2 = null;
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     java.awt.geom.Point2D var9 = var8.getQuadrantOrigin();
//     java.awt.geom.Point2D var10 = var8.getQuadrantOrigin();
//     var8.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var13 = null;
//     var8.setFixedRangeAxisSpace(var13, true);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var8.setDomainAxis((org.jfree.chart.axis.ValueAxis)var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var17, var19, var20);
//     java.awt.Stroke var22 = var21.getRangeCrosshairStroke();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var25 = var23.getRangeAxis(0);
//     org.jfree.data.general.DatasetGroup var26 = var23.getDatasetGroup();
//     org.jfree.chart.plot.PlotRenderingInfo var29 = null;
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     java.awt.geom.Point2D var35 = var34.getQuadrantOrigin();
//     java.awt.geom.Point2D var36 = var34.getQuadrantOrigin();
//     var23.zoomRangeAxes(90.0d, 4.0d, var29, var36);
//     var21.setQuadrantOrigin(var36);
//     var0.zoomRangeAxes(0.14d, var2, var36);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    java.awt.geom.Point2D var6 = var4.getQuadrantOrigin();
    var4.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var4.setFixedRangeAxisSpace(var9, true);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var13);
    float var15 = var4.getBackgroundImageAlpha();
    org.jfree.chart.util.RectangleEdge var16 = var4.getDomainAxisEdge();
    var4.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.data.general.DatasetGroup var3 = var0.getDatasetGroup();
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(1, var5);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.CategoryAxis var9 = var0.getDomainAxis(256);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    var1.distributeLabels((-11.0d), 100.0d);
    var1.sort();

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     java.awt.geom.Point2D var12 = var11.getQuadrantOrigin();
//     var4.zoomDomainAxes(1.0d, var6, var12);
//     var0.zoomDomainAxes(1.0d, 0.0d, var3, var12);
//     boolean var15 = var0.isRangeZoomable();
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot();
//     double var20 = var18.getExplodePercent((java.lang.Comparable)10L);
//     var18.setMaximumLabelWidth((-11.0d));
//     org.jfree.chart.util.Size2D var25 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     var28.setRangeAxis(10, var32);
//     java.awt.Stroke var34 = null;
//     var28.setOutlineStroke(var34);
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     var28.setRenderer(1, var37);
//     org.jfree.chart.util.HorizontalAlignment var39 = null;
//     org.jfree.chart.util.VerticalAlignment var40 = null;
//     org.jfree.chart.block.FlowArrangement var43 = new org.jfree.chart.block.FlowArrangement(var39, var40, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var44 = null;
//     org.jfree.chart.util.VerticalAlignment var45 = null;
//     org.jfree.chart.block.ColumnArrangement var48 = new org.jfree.chart.block.ColumnArrangement(var44, var45, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28, (org.jfree.chart.block.Arrangement)var43, (org.jfree.chart.block.Arrangement)var48);
//     boolean var51 = var49.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var52 = var49.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var53 = var49.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var54 = var49.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var55 = org.jfree.chart.util.RectangleAnchor.createRectangle(var25, 0.05d, 0.2d, var54);
//     var18.setLegendItemShape((java.awt.Shape)var55);
//     java.awt.Point var57 = var0.translateValueThetaRadiusToJava2D((-2.0d), (-2.0d), var55);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     var40.setDataset(var41);
//     boolean var43 = var39.equals((java.lang.Object)var40);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
//     org.jfree.chart.text.TextLine var45 = var44.getLastLine();
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot();
//     var47.setLabelLinkMargin(0.0d);
//     var47.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var54 = var52.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     var52.setRangeAxis(10, var56);
//     java.awt.Stroke var58 = null;
//     var52.setOutlineStroke(var58);
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     var52.setRenderer(1, var61);
//     org.jfree.chart.util.HorizontalAlignment var63 = null;
//     org.jfree.chart.util.VerticalAlignment var64 = null;
//     org.jfree.chart.block.FlowArrangement var67 = new org.jfree.chart.block.FlowArrangement(var63, var64, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var68 = null;
//     org.jfree.chart.util.VerticalAlignment var69 = null;
//     org.jfree.chart.block.ColumnArrangement var72 = new org.jfree.chart.block.ColumnArrangement(var68, var69, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52, (org.jfree.chart.block.Arrangement)var67, (org.jfree.chart.block.Arrangement)var72);
//     boolean var75 = var73.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var76 = new org.jfree.chart.plot.PiePlot();
//     double var77 = var76.getShadowYOffset();
//     double var78 = var76.getShadowYOffset();
//     java.awt.Font var79 = var76.getLabelFont();
//     var73.setItemFont(var79);
//     var47.setLabelFont(var79);
//     java.awt.Color var85 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var86 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var87 = null;
//     var86.setDataset(var87);
//     boolean var89 = var85.equals((java.lang.Object)var86);
//     org.jfree.chart.text.TextBlock var90 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var79, (java.awt.Paint)var85);
//     org.jfree.chart.text.TextLine var91 = var90.getLastLine();
//     org.jfree.chart.title.TextTitle var92 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var93 = var92.getTextAlignment();
//     var90.setLineAlignment(var93);
//     org.jfree.chart.text.TextLine var95 = var90.getLastLine();
//     org.jfree.chart.text.TextFragment var96 = var95.getFirstTextFragment();
//     var45.addFragment(var96);
//     
//     // Checks the contract:  equals-hashcode on var1 and var47
//     assertTrue("Contract failed: equals-hashcode on var1 and var47", var1.equals(var47) ? var1.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var76
//     assertTrue("Contract failed: equals-hashcode on var30 and var76", var30.equals(var76) ? var30.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var1
//     assertTrue("Contract failed: equals-hashcode on var47 and var1", var47.equals(var1) ? var47.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var30
//     assertTrue("Contract failed: equals-hashcode on var76 and var30", var76.equals(var30) ? var76.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var52
//     assertTrue("Contract failed: equals-hashcode on var6 and var52", var6.equals(var52) ? var6.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var6
//     assertTrue("Contract failed: equals-hashcode on var52 and var6", var52.equals(var6) ? var52.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var67
//     assertTrue("Contract failed: equals-hashcode on var21 and var67", var21.equals(var67) ? var21.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var21
//     assertTrue("Contract failed: equals-hashcode on var67 and var21", var67.equals(var21) ? var67.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var72
//     assertTrue("Contract failed: equals-hashcode on var26 and var72", var26.equals(var72) ? var26.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var26
//     assertTrue("Contract failed: equals-hashcode on var72 and var26", var72.equals(var26) ? var72.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var86
//     assertTrue("Contract failed: equals-hashcode on var40 and var86", var40.equals(var86) ? var40.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var40
//     assertTrue("Contract failed: equals-hashcode on var86 and var40", var86.equals(var40) ? var86.hashCode() == var40.hashCode() : true);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin(10.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     var1.configure();
//     var1.setLowerMargin(1.0d);
//     int var8 = var1.getMaximumCategoryLabelLines();
//     var1.removeCategoryLabelToolTip((java.lang.Comparable)0L);
//     java.awt.Font var11 = var1.getLabelFont();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     var15.setRangeAxis(10, var19);
//     java.awt.Stroke var21 = null;
//     var15.setOutlineStroke(var21);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     var15.setRenderer(1, var24);
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.FlowArrangement var30 = new org.jfree.chart.block.FlowArrangement(var26, var27, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15, (org.jfree.chart.block.Arrangement)var30, (org.jfree.chart.block.Arrangement)var35);
//     boolean var38 = var36.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var39 = var36.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var40 = var36.getItemLabelPadding();
//     java.awt.Color var44 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var46 = null;
//     var45.setDataset(var46);
//     boolean var48 = var44.equals((java.lang.Object)var45);
//     org.jfree.chart.util.RectangleEdge var50 = var45.getRangeAxisEdge(100);
//     var36.setLegendItemGraphicEdge(var50);
//     double var52 = var1.getCategoryEnd(10, 0, var14, var50);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var0.markerChanged(var3);
    org.jfree.chart.urls.PieURLGenerator var5 = null;
    var0.setLegendLabelURLGenerator(var5);
    java.awt.Shape var7 = var0.getLegendItemShape();
    double var8 = var0.getStartAngle();
    org.jfree.chart.util.RectangleInsets var9 = var0.getSimpleLabelOffset();
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var17 = var15.trimWidth(10.0d);
    var10.setLabelPadding(var15);
    double var19 = var10.getStartAngle();
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var21 = var20.getLabelShadowPaint();
    var10.setBaseSectionPaint(var21);
    var0.setLabelPaint(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.CrosshairState var32 = null;
    boolean var33 = var24.render(var28, var29, 0, var31, var32);
    java.awt.Paint var35 = var24.getQuadrantPaint(0);
    org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
    var21.setPosition(var37);
    java.lang.String var39 = var37.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "RectangleEdge.RIGHT"+ "'", var39.equals("RectangleEdge.RIGHT"));

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickMarkPosition(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var8.removeProgressListener(var15);
    org.jfree.chart.event.ChartChangeListener var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.removeChangeListener(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var8.removeProgressListener(var15);
    java.awt.Paint var17 = var8.getBorderPaint();
    int var18 = var8.getSubtitleCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var19 = var8.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Stroke var1 = var0.getRadiusGridlineStroke();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    java.awt.geom.Point2D var7 = var6.getQuadrantOrigin();
    var6.setRangeGridlinesVisible(true);
    java.awt.Paint var11 = null;
    java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
    java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
    java.awt.Paint var22 = var21.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    var23.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var31.setCategoryMargin(10.0d);
    java.awt.Stroke var34 = var31.getAxisLineStroke();
    var28.setTickMarkStroke(var34);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker((-1.0d), var22, var34);
    var6.setDomainGridlineStroke(var34);
    var0.setRadiusGridlineStroke(var34);
    org.jfree.data.xy.XYDataset var39 = null;
    var0.setDataset(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var3 = var0.getRootPlot();
    org.jfree.data.xy.XYDataset var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataset((-10223606), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("org.jfree.chart.event.ChartChangeEvent[source=false]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     var5.setAutoRangeStickyZero(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     java.awt.Shape var17 = var15.getDownArrow();
//     var5.setDownArrow(var17);
//     org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var17, "", "Multiple Pie Plot");
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var23 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var24 = null;
//     java.lang.String var25 = var21.getImageMapAreaTag(var23, var24);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    double var8 = var6.getRight();
    java.awt.geom.Rectangle2D var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var12 = var6.createOutsetRectangle(var9, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var26 = var24.getDomainAxis((-1));
    org.jfree.chart.plot.Plot var27 = var24.getRootPlot();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.CrosshairState var32 = null;
    boolean var33 = var24.render(var28, var29, 0, var31, var32);
    java.awt.Paint var35 = var24.getQuadrantPaint(0);
    org.jfree.chart.util.RectangleEdge var37 = var24.getRangeAxisEdge(100);
    var21.setPosition(var37);
    org.jfree.chart.util.RectangleInsets var43 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var45 = var43.extendWidth(10.0d);
    double var46 = var43.getBottom();
    var21.setLegendItemGraphicPadding(var43);
    java.awt.Paint var48 = var21.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 20.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, var1);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.util.TimeZone var1 = var0.getTimeZone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(10.0d, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var7 = null;
    var6.setDataset(var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.data.Range var10 = var6.getDataRange(var9);
    boolean var11 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisSpace var12 = null;
    var6.setFixedRangeAxisSpace(var12);
    java.awt.Stroke var14 = var6.getRangeGridlineStroke();
    var0.setRangeGridlineStroke(var14);
    org.jfree.chart.LegendItemCollection var16 = var0.getFixedLegendItems();
    boolean var17 = var0.isDomainZoomable();
    int var18 = var0.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    java.awt.Paint var5 = var0.getRangeCrosshairPaint();
    java.awt.Paint var6 = var0.getNoDataMessagePaint();
    org.jfree.chart.plot.CategoryMarker var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var0.indexOf(var8);
    org.jfree.data.xy.XYDataset var10 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    var5.setAutoRangeStickyZero(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    java.awt.Shape var17 = var15.getDownArrow();
    var5.setDownArrow(var17);
    org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var17, "", "Multiple Pie Plot");
    java.awt.Shape var22 = var21.getArea();
    org.jfree.chart.entity.ChartEntity var25 = new org.jfree.chart.entity.ChartEntity(var22, "org.jfree.chart.event.ChartChangeEvent[source=false]", "org.jfree.chart.event.ChartChangeEvent[source=false]");
    java.lang.String var26 = var25.getURLText();
    var25.setToolTipText("LengthConstraintType.FIXED");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=false]"+ "'", var26.equals("org.jfree.chart.event.ChartChangeEvent[source=false]"));

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin(10.0d);
    java.awt.Stroke var5 = var2.getAxisLineStroke();
    boolean var6 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var9 = var7.getDomainAxis((-1));
    var7.clearRangeAxes();
    var2.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    java.awt.Paint var12 = var2.getLabelPaint();
    var2.removeCategoryLabelToolTip((java.lang.Comparable)10);
    java.lang.String var16 = var2.getCategoryLabelToolTip((java.lang.Comparable)"Category Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    var1.setLabelLinkMargin(0.0d);
    var1.setLabelLinkMargin(20.0d);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var10 = null;
    var6.setRangeAxis(10, var10);
    java.awt.Stroke var12 = null;
    var6.setOutlineStroke(var12);
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    var6.setRenderer(1, var15);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var22 = null;
    org.jfree.chart.util.VerticalAlignment var23 = null;
    org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
    boolean var29 = var27.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
    double var31 = var30.getShadowYOffset();
    double var32 = var30.getShadowYOffset();
    java.awt.Font var33 = var30.getLabelFont();
    var27.setItemFont(var33);
    var1.setLabelFont(var33);
    java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var41 = null;
    var40.setDataset(var41);
    boolean var43 = var39.equals((java.lang.Object)var40);
    org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
    org.jfree.chart.text.TextLine var45 = var44.getLastLine();
    java.util.List var46 = var44.getLines();
    org.jfree.chart.text.TextLine var47 = var44.getLastLine();
    org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot();
    double var50 = var49.getShadowYOffset();
    double var51 = var49.getShadowYOffset();
    java.awt.Font var52 = var49.getLabelFont();
    java.awt.Paint var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var44.addLine("Polar Plot", var52, var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    var0.clearRangeAxes();
    java.awt.Paint var4 = var0.getRangeTickBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    java.awt.image.ColorModel var4 = null;
    java.awt.Rectangle var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    java.awt.geom.AffineTransform var7 = null;
    java.awt.RenderingHints var8 = null;
    java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
    java.awt.Color var10 = var3.brighter();
    java.awt.Color var11 = var10.brighter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.util.TimeZone var1 = var0.getTimeZone();
//     java.util.Date var2 = null;
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle();
//     var3.setWidth(20.0d);
//     var3.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var3.setURLText("Category Plot");
//     double var10 = var3.getWidth();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.util.Size2D var14 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     var17.setRangeAxis(10, var21);
//     java.awt.Stroke var23 = null;
//     var17.setOutlineStroke(var23);
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     var17.setRenderer(1, var26);
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement(var28, var29, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var33, var34, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, (org.jfree.chart.block.Arrangement)var32, (org.jfree.chart.block.Arrangement)var37);
//     boolean var40 = var38.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var41 = var38.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var42 = var38.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var43 = var38.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var14, 0.05d, 0.2d, var43);
//     var3.draw(var11, var44);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var48 = var46.getDataset((-1));
//     org.jfree.chart.util.RectangleEdge var49 = var46.getDomainAxisEdge();
//     double var50 = var0.dateToJava2D(var2, var44, var49);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin(10.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.configure();
    var1.setLowerMargin(1.0d);
    int var8 = var1.getMaximumCategoryLabelLines();
    var1.removeCategoryLabelToolTip((java.lang.Comparable)0L);
    var1.setTickMarksVisible(false);
    var1.setCategoryLabelPositionOffset(10);
    java.awt.Font var15 = var1.getTickLabelFont();
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var17 = var16.getTextAlignment();
    boolean var18 = var1.equals((java.lang.Object)var17);
    var1.setCategoryMargin(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Color var8 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    java.awt.image.ColorModel var9 = null;
    java.awt.Rectangle var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.awt.geom.AffineTransform var12 = null;
    java.awt.RenderingHints var13 = null;
    java.awt.PaintContext var14 = var8.createContext(var9, var10, var11, var12, var13);
    java.awt.Color var15 = var8.brighter();
    var4.setOutlinePaint((java.awt.Paint)var8);
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    var4.setRenderer(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(10, var4);
//     java.awt.Stroke var6 = null;
//     var0.setOutlineStroke(var6);
//     org.jfree.data.xy.XYDataset var8 = null;
//     int var9 = var0.indexOf(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     java.util.List var12 = null;
//     var0.drawDomainTickBands(var10, var11, var12);
//     org.jfree.chart.plot.DatasetRenderingOrder var14 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
//     var15.setLabelLinkMargin(0.0d);
//     var15.setLabelLinkMargin(20.0d);
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var22.setCategoryMargin(10.0d);
//     java.awt.Stroke var25 = var22.getAxisLineStroke();
//     boolean var26 = var20.equals((java.lang.Object)var22);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var29 = var27.getDataset((-1));
//     org.jfree.chart.util.Layer var31 = null;
//     java.util.Collection var32 = var27.getDomainMarkers(10, var31);
//     var22.setPlot((org.jfree.chart.plot.Plot)var27);
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var22.getCategoryMiddle(100, 0, var36, var37);
//     java.awt.Color var43 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var45.setCategoryMargin(10.0d);
//     java.awt.Stroke var48 = var45.getAxisLineStroke();
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var43, var48);
//     java.awt.Stroke var50 = var49.getStroke();
//     var22.setAxisLineStroke(var50);
//     var15.setLabelOutlineStroke(var50);
//     var0.setDomainZeroBaselineStroke(var50);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     var54.setRangeAxis(0, var56, true);
//     java.awt.Paint var59 = var54.getRangeCrosshairPaint();
//     java.awt.Paint var60 = var54.getNoDataMessagePaint();
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54);
//     org.jfree.chart.util.RectangleAnchor var62 = var61.getLegendItemGraphicLocation();
//     boolean var63 = var0.equals((java.lang.Object)var61);
//     
//     // Checks the contract:  equals-hashcode on var27 and var54
//     assertTrue("Contract failed: equals-hashcode on var27 and var54", var27.equals(var54) ? var27.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var27
//     assertTrue("Contract failed: equals-hashcode on var54 and var27", var54.equals(var27) ? var54.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.data.xy.XYDataset var12 = var0.getDataset(256);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     java.awt.geom.Point2D var6 = var4.getQuadrantOrigin();
//     var4.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var9 = null;
//     var4.setFixedRangeAxisSpace(var9, true);
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
//     java.awt.geom.Point2D var23 = var22.getQuadrantOrigin();
//     org.jfree.chart.JFreeChart var24 = null;
//     org.jfree.chart.event.ChartProgressEvent var27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var23, var24, 0, 0);
//     var4.zoomDomainAxes(0.0d, 0.025d, var17, var23);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     var29.setRangeAxis((org.jfree.chart.axis.ValueAxis)var34);
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var37.setCategoryMargin(10.0d);
//     java.awt.Stroke var40 = var37.getAxisLineStroke();
//     var34.setTickMarkStroke(var40);
//     double var42 = var34.getLowerMargin();
//     int var43 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var34);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.plot.RingPlot var46 = new org.jfree.chart.plot.RingPlot();
//     double var48 = var46.getExplodePercent((java.lang.Comparable)10L);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
//     var50.setRangeAxis((org.jfree.chart.axis.ValueAxis)var55);
//     org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var58.setCategoryMargin(10.0d);
//     java.awt.Stroke var61 = var58.getAxisLineStroke();
//     var55.setTickMarkStroke(var61);
//     var46.setSectionOutlineStroke((java.lang.Comparable)1L, var61);
//     org.jfree.chart.plot.AbstractPieLabelDistributor var64 = var46.getLabelDistributor();
//     double var65 = var46.getShadowXOffset();
//     java.awt.Paint var66 = var46.getLabelPaint();
//     boolean var67 = var45.equals((java.lang.Object)var46);
//     org.jfree.chart.util.Layer var68 = null;
//     boolean var69 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var45, var68);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    java.awt.Paint var23 = null;
    java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
    java.awt.Paint[] var25 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var26 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    java.awt.Stroke var29 = null;
    java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
    java.awt.Shape var31 = null;
    java.awt.Shape[] var32 = new java.awt.Shape[] { var31};
    org.jfree.chart.plot.DefaultDrawingSupplier var33 = new org.jfree.chart.plot.DefaultDrawingSupplier(var24, var25, var26, var28, var30, var32);
    java.awt.Paint var34 = var33.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    var35.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
    var35.setRangeAxis((org.jfree.chart.axis.ValueAxis)var40);
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var43.setCategoryMargin(10.0d);
    java.awt.Stroke var46 = var43.getAxisLineStroke();
    var40.setTickMarkStroke(var46);
    org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker((-1.0d), var34, var46);
    org.jfree.chart.util.RectangleInsets var49 = var48.getLabelOffset();
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var48);
    java.awt.Color var53 = java.awt.Color.getColor("", (-1));
    java.awt.Color var54 = var53.darker();
    java.lang.String var55 = var54.toString();
    var48.setLabelPaint((java.awt.Paint)var54);
    float[] var60 = new float[] { 10.0f, 1.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var61 = var54.getRGBComponents(var60);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "java.awt.Color[r=178,g=178,b=178]"+ "'", var55.equals("java.awt.Color[r=178,g=178,b=178]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"Rotation.CLOCKWISE", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var2 = var1.getRadiusGridlineStroke();
//     java.awt.Font var3 = var1.getAngleLabelFont();
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.geom.Point2D var10 = var9.getQuadrantOrigin();
//     java.awt.geom.Point2D var11 = var9.getQuadrantOrigin();
//     var9.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var14 = null;
//     var9.setFixedRangeAxisSpace(var14, true);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setDomainAxis((org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var18, var20, var21);
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = var23.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var23.setSimpleLabelOffset(var29);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     var32.setWidth(20.0d);
//     var32.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var31.addSubtitle((org.jfree.chart.title.Title)var32);
//     java.awt.Color var41 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
//     var31.setBackgroundPaint((java.awt.Paint)var41);
//     var22.setOutlinePaint((java.awt.Paint)var41);
//     java.awt.color.ColorSpace var44 = var41.getColorSpace();
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.text.G2TextMeasurer var48 = new org.jfree.chart.text.G2TextMeasurer(var47);
//     org.jfree.chart.text.TextBlock var49 = org.jfree.chart.text.TextUtilities.createTextBlock("Polar Plot", var3, (java.awt.Paint)var41, 0.5f, 10, (org.jfree.chart.text.TextMeasurer)var48);
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2);
//     var0.configureDomainAxes();
//     java.lang.Object var5 = var0.clone();
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var9 = var7.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     var7.setRangeAxis(0, var11, false);
//     var7.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.ValueAxis[] var18 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var7.setRangeAxes(var18);
//     java.awt.Paint var20 = null;
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
//     java.awt.Paint[] var22 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var23 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var24 = null;
//     java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
//     java.awt.Stroke var26 = null;
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     java.awt.Shape var28 = null;
//     java.awt.Shape[] var29 = new java.awt.Shape[] { var28};
//     org.jfree.chart.plot.DefaultDrawingSupplier var30 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var22, var23, var25, var27, var29);
//     java.awt.Paint var31 = var30.getNextOutlinePaint();
//     var7.setRangeGridlinePaint(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     var33.setRenderer(0, var35);
//     org.jfree.chart.util.SortOrder var37 = var33.getRowRenderingOrder();
//     var7.setRowRenderingOrder(var37);
//     var0.setColumnRenderingOrder(var37);
//     
//     // Checks the contract:  equals-hashcode on var0 and var33
//     assertTrue("Contract failed: equals-hashcode on var0 and var33", var0.equals(var33) ? var0.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var0
//     assertTrue("Contract failed: equals-hashcode on var33 and var0", var33.equals(var0) ? var33.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     java.util.List var6 = var4.getAnnotations();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var9 = var7.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     var7.setRangeAxis(10, var11);
//     double var13 = var7.getDomainCrosshairValue();
//     var7.clearRangeMarkers();
//     java.awt.Stroke var15 = var7.getDomainCrosshairStroke();
//     var4.setRangeCrosshairStroke(var15);
//     
//     // Checks the contract:  equals-hashcode on var4 and var7
//     assertTrue("Contract failed: equals-hashcode on var4 and var7", var4.equals(var7) ? var4.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var4
//     assertTrue("Contract failed: equals-hashcode on var7 and var4", var7.equals(var4) ? var7.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var0.setSimpleLabelOffset(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     var9.setWidth(20.0d);
//     var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var8.addSubtitle((org.jfree.chart.title.Title)var9);
//     org.jfree.chart.event.ChartProgressListener var15 = null;
//     var8.removeProgressListener(var15);
//     java.awt.Paint var17 = var8.getBorderPaint();
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot(var18);
//     java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
//     int var24 = var23.getAlpha();
//     var19.setAggregatedItemsPaint((java.awt.Paint)var23);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var27.setCategoryMargin(10.0d);
//     java.awt.Stroke var30 = var27.getAxisLineStroke();
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var32 = var31.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var37 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var31.setSimpleLabelOffset(var37);
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle();
//     var40.setWidth(20.0d);
//     var40.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var39.addSubtitle((org.jfree.chart.title.Title)var40);
//     org.jfree.chart.event.ChartChangeEventType var46 = null;
//     org.jfree.chart.event.ChartChangeEvent var47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var27, var39, var46);
//     org.jfree.chart.util.RectangleInsets var48 = var39.getPadding();
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var54 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var56 = var54.trimWidth(10.0d);
//     var49.setLabelPadding(var54);
//     double var59 = var54.calculateRightOutset(10.0d);
//     var39.setPadding(var54);
//     var39.fireChartChanged();
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
//     var62.clearAnnotations();
//     org.jfree.chart.event.PlotChangeEvent var64 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var62);
//     var39.plotChanged(var64);
//     var19.notifyListeners(var64);
//     var8.plotChanged(var64);
//     
//     // Checks the contract:  equals-hashcode on var0 and var31
//     assertTrue("Contract failed: equals-hashcode on var0 and var31", var0.equals(var31) ? var0.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     var0.setRangeAxis(0, var2, true);
//     org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var9.setLicenceName("hi!");
//     boolean var12 = var0.equals((java.lang.Object)"hi!");
//     boolean var13 = var0.getDrawSharedDomainAxis();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var16 = var14.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     var14.setRangeAxis(0, var18, false);
//     var14.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.ValueAxis[] var25 = new org.jfree.chart.axis.ValueAxis[] { var24};
//     var14.setRangeAxes(var25);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var14.setRenderer(10, var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     var30.setRenderer(0, var32);
//     org.jfree.chart.util.SortOrder var34 = var30.getRowRenderingOrder();
//     var14.setRowRenderingOrder(var34);
//     var0.setColumnRenderingOrder(var34);
//     
//     // Checks the contract:  equals-hashcode on var0 and var30
//     assertTrue("Contract failed: equals-hashcode on var0 and var30", var0.equals(var30) ? var0.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var0
//     assertTrue("Contract failed: equals-hashcode on var30 and var0", var30.equals(var0) ? var30.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setRangeAxis(0, var4, false);
//     var0.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var10};
//     var0.setRangeAxes(var11);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     var0.setRenderer(10, var14);
//     var0.mapDatasetToRangeAxis(255, 4);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     var19.setRangeAxis(0, var21, true);
//     org.jfree.chart.ui.BasicProjectInfo var28 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
//     var28.setLicenceName("hi!");
//     boolean var31 = var19.equals((java.lang.Object)"hi!");
//     java.lang.String var32 = var19.getPlotType();
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var36 = var34.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var37 = var34.getRootPlot();
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var41 = var39.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     var39.setRangeAxis(10, var43);
//     java.awt.Stroke var45 = null;
//     var39.setOutlineStroke(var45);
//     java.awt.Image var47 = null;
//     var39.setBackgroundImage(var47);
//     java.awt.Paint var50 = null;
//     java.awt.Paint[] var51 = new java.awt.Paint[] { var50};
//     java.awt.Paint[] var52 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var53 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var54 = null;
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     java.awt.Stroke var56 = null;
//     java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
//     java.awt.Shape var58 = null;
//     java.awt.Shape[] var59 = new java.awt.Shape[] { var58};
//     org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier(var51, var52, var53, var55, var57, var59);
//     java.awt.Paint var61 = var60.getNextOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     var62.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     var62.setRangeAxis((org.jfree.chart.axis.ValueAxis)var67);
//     org.jfree.chart.axis.CategoryAxis var70 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var70.setCategoryMargin(10.0d);
//     java.awt.Stroke var73 = var70.getAxisLineStroke();
//     var67.setTickMarkStroke(var73);
//     org.jfree.chart.plot.ValueMarker var75 = new org.jfree.chart.plot.ValueMarker((-1.0d), var61, var73);
//     var39.setDomainZeroBaselineStroke(var73);
//     org.jfree.chart.axis.AxisLocation var77 = var39.getRangeAxisLocation();
//     var34.setDomainAxisLocation(10, var77);
//     var19.setRangeAxisLocation(10, var77, false);
//     var0.setDomainAxisLocation(var77, true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var0
//     assertTrue("Contract failed: equals-hashcode on var62 and var0", var62.equals(var0) ? var62.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var62 and var0.", var62.equals(var0) == var0.equals(var62));
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 0, 10);
    float[] var6 = new float[] { 1.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getRGBColorComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
//     var3.setLabelLinkMargin(0.0d);
//     var3.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     var8.setRangeAxis(10, var12);
//     java.awt.Stroke var14 = null;
//     var8.setOutlineStroke(var14);
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     var8.setRenderer(1, var17);
//     org.jfree.chart.util.HorizontalAlignment var19 = null;
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.FlowArrangement var23 = new org.jfree.chart.block.FlowArrangement(var19, var20, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.util.VerticalAlignment var25 = null;
//     org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8, (org.jfree.chart.block.Arrangement)var23, (org.jfree.chart.block.Arrangement)var28);
//     boolean var31 = var29.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot();
//     double var33 = var32.getShadowYOffset();
//     double var34 = var32.getShadowYOffset();
//     java.awt.Font var35 = var32.getLabelFont();
//     var29.setItemFont(var35);
//     var3.setLabelFont(var35);
//     java.awt.Color var41 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var43 = null;
//     var42.setDataset(var43);
//     boolean var45 = var41.equals((java.lang.Object)var42);
//     org.jfree.chart.text.TextBlock var46 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var35, (java.awt.Paint)var41);
//     var1.setLabelFont(var35);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var49 = null;
//     var48.setDataset(var49);
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.data.Range var52 = var48.getDataRange(var51);
//     boolean var53 = var48.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisSpace var54 = null;
//     var48.setFixedRangeAxisSpace(var54);
//     var48.clearRangeMarkers();
//     int var57 = var48.getBackgroundImageAlignment();
//     var1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var48);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var61 = var59.getRangeAxis(0);
//     float var62 = var59.getBackgroundImageAlpha();
//     boolean var63 = var59.isDomainGridlinesVisible();
//     org.jfree.chart.util.Layer var65 = null;
//     java.util.Collection var66 = var59.getDomainMarkers(4, var65);
//     boolean var67 = var1.equals((java.lang.Object)var65);
//     
//     // Checks the contract:  equals-hashcode on var42 and var59
//     assertTrue("Contract failed: equals-hashcode on var42 and var59", var42.equals(var59) ? var42.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var42
//     assertTrue("Contract failed: equals-hashcode on var59 and var42", var59.equals(var42) ? var59.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("Category Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var0.markerChanged(var3);
    float var5 = var0.getBackgroundImageAlpha();
    var0.setInnerSeparatorExtension(20.0d);
    org.jfree.data.general.PieDataset var8 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint[] var2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke var6 = null;
    java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
    java.awt.Shape var8 = null;
    java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var2, var3, var5, var7, var9);
    java.awt.Shape var11 = var10.getNextShape();
    java.awt.Paint var12 = var10.getNextFillPaint();
    java.awt.Stroke var13 = var10.getNextOutlineStroke();
    java.awt.Stroke var14 = var10.getNextStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]");
//     org.jfree.data.general.PieDataset var2 = null;
//     java.text.AttributedString var4 = var1.generateAttributedSectionLabel(var2, (java.lang.Comparable)"");
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 1);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var1 = null;
    var0.setRenderer(var1, true);
    org.jfree.chart.plot.CategoryMarker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((-10223606), var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    java.awt.Graphics2D var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.plot.CrosshairState var26 = null;
    boolean var27 = var0.render(var22, var23, 10, var25, var26);
    org.jfree.chart.axis.AxisLocation var28 = var0.getRangeAxisLocation();
    boolean var29 = var0.isDomainCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    var0.setLabelLinkMargin(0.0d);
    var0.setLabelLinkMargin(20.0d);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var7.setCategoryMargin(10.0d);
    java.awt.Stroke var10 = var7.getAxisLineStroke();
    boolean var11 = var5.equals((java.lang.Object)var7);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var14 = var12.getDataset((-1));
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var12.getDomainMarkers(10, var16);
    var7.setPlot((org.jfree.chart.plot.Plot)var12);
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var7.getCategoryMiddle(100, 0, var21, var22);
    java.awt.Color var28 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var30.setCategoryMargin(10.0d);
    java.awt.Stroke var33 = var30.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var28, var33);
    java.awt.Stroke var35 = var34.getStroke();
    var7.setAxisLineStroke(var35);
    var0.setLabelOutlineStroke(var35);
    var0.setBackgroundImageAlignment(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.event.ChartProgressEvent[source=Point2D.Double[0.0, 0.0]]");
//     org.jfree.data.general.PieDataset var2 = null;
//     java.text.AttributedString var4 = var1.generateAttributedSectionLabel(var2, (java.lang.Comparable)1.0d);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint[] var2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Shape var8 = null;
//     java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var2, var3, var5, var7, var9);
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var19 = null;
//     java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
//     java.awt.Paint var22 = null;
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
//     java.awt.Paint[] var24 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var25 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var26 = null;
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     java.awt.Stroke var28 = null;
//     java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
//     java.awt.Shape var30 = null;
//     java.awt.Shape[] var31 = new java.awt.Shape[] { var30};
//     org.jfree.chart.plot.DefaultDrawingSupplier var32 = new org.jfree.chart.plot.DefaultDrawingSupplier(var23, var24, var25, var27, var29, var31);
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Stroke var34 = var33.getRadiusGridlineStroke();
//     java.awt.Stroke var35 = var33.getAngleGridlineStroke();
//     java.awt.Stroke[] var36 = new java.awt.Stroke[] { var35};
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot();
//     double var39 = var37.getExplodePercent((java.lang.Comparable)10L);
//     var37.setMaximumLabelWidth((-11.0d));
//     org.jfree.chart.util.Size2D var44 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var49 = var47.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     var47.setRangeAxis(10, var51);
//     java.awt.Stroke var53 = null;
//     var47.setOutlineStroke(var53);
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     var47.setRenderer(1, var56);
//     org.jfree.chart.util.HorizontalAlignment var58 = null;
//     org.jfree.chart.util.VerticalAlignment var59 = null;
//     org.jfree.chart.block.FlowArrangement var62 = new org.jfree.chart.block.FlowArrangement(var58, var59, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var63 = null;
//     org.jfree.chart.util.VerticalAlignment var64 = null;
//     org.jfree.chart.block.ColumnArrangement var67 = new org.jfree.chart.block.ColumnArrangement(var63, var64, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47, (org.jfree.chart.block.Arrangement)var62, (org.jfree.chart.block.Arrangement)var67);
//     boolean var70 = var68.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var71 = var68.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var72 = var68.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var73 = var68.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var74 = org.jfree.chart.util.RectangleAnchor.createRectangle(var44, 0.05d, 0.2d, var73);
//     var37.setLegendItemShape((java.awt.Shape)var74);
//     java.awt.Shape[] var76 = new java.awt.Shape[] { var74};
//     org.jfree.chart.plot.DefaultDrawingSupplier var77 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var13, var29, var36, var76);
//     
//     // Checks the contract:  equals-hashcode on var10 and var21
//     assertTrue("Contract failed: equals-hashcode on var10 and var21", var10.equals(var21) ? var10.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var32
//     assertTrue("Contract failed: equals-hashcode on var10 and var32", var10.equals(var32) ? var10.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var10
//     assertTrue("Contract failed: equals-hashcode on var21 and var10", var21.equals(var10) ? var21.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var32
//     assertTrue("Contract failed: equals-hashcode on var21 and var32", var21.equals(var32) ? var21.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var10
//     assertTrue("Contract failed: equals-hashcode on var32 and var10", var32.equals(var10) ? var32.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var21
//     assertTrue("Contract failed: equals-hashcode on var32 and var21", var32.equals(var21) ? var32.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getTextAlignment();
    java.lang.Object var2 = var0.clone();
    var0.setToolTipText("XY Plot");
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var5.setRenderer(0, var7);
    var5.configureDomainAxes();
    java.lang.Object var10 = var5.clone();
    boolean var11 = var0.equals(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    int var1 = var0.getSeriesCount();
    var0.setAngleLabelsVisible(false);
    java.lang.String var4 = var0.getPlotType();
    boolean var5 = var0.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Polar Plot"+ "'", var4.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var0.indexOf(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.util.List var12 = null;
    var0.drawDomainTickBands(var10, var11, var12);
    org.jfree.chart.plot.DatasetRenderingOrder var14 = var0.getDatasetRenderingOrder();
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
    var15.setLabelLinkMargin(0.0d);
    var15.setLabelLinkMargin(20.0d);
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var22.setCategoryMargin(10.0d);
    java.awt.Stroke var25 = var22.getAxisLineStroke();
    boolean var26 = var20.equals((java.lang.Object)var22);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var29 = var27.getDataset((-1));
    org.jfree.chart.util.Layer var31 = null;
    java.util.Collection var32 = var27.getDomainMarkers(10, var31);
    var22.setPlot((org.jfree.chart.plot.Plot)var27);
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    double var38 = var22.getCategoryMiddle(100, 0, var36, var37);
    java.awt.Color var43 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var45.setCategoryMargin(10.0d);
    java.awt.Stroke var48 = var45.getAxisLineStroke();
    org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(20.0d, (java.awt.Paint)var43, var48);
    java.awt.Stroke var50 = var49.getStroke();
    var22.setAxisLineStroke(var50);
    var15.setLabelOutlineStroke(var50);
    var0.setDomainZeroBaselineStroke(var50);
    java.awt.Font var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNoDataMessageFont(var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    java.text.NumberFormat var8 = var5.getNumberFormatOverride();
    var5.setTickLabelsVisible(true);
    org.jfree.data.Range var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setRange(var11, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
//     int var5 = var4.getItemCount();
//     java.lang.Object var6 = var4.clone();
//     java.lang.Object var7 = var4.clone();
//     
//     // Checks the contract:  equals-hashcode on var6 and var7
//     assertTrue("Contract failed: equals-hashcode on var6 and var7", var6.equals(var7) ? var6.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var6
//     assertTrue("Contract failed: equals-hashcode on var7 and var6", var7.equals(var6) ? var7.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    java.awt.geom.Rectangle2D var2 = var1.getPieArea();
    double var3 = var1.getLatestAngle();
    double var4 = var1.getPieWRadius();
    int var5 = var1.getPassesRequired();
    var1.setPieWRadius(28.124999999999993d);
    double var8 = var1.getLatestAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getDomainMarkers(var6);
    boolean var8 = var4.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     var4.setDataset(var5);
//     boolean var7 = var3.equals((java.lang.Object)var4);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getRangeAxis(0);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     var8.setRangeAxis(0, var12, false);
//     var8.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.AxisLocation var17 = var8.getDomainAxisLocation();
//     var4.setDomainAxisLocation(var17, true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var8
//     assertTrue("Contract failed: equals-hashcode on var4 and var8", var4.equals(var8) ? var4.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var4
//     assertTrue("Contract failed: equals-hashcode on var8 and var4", var8.equals(var4) ? var8.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var8.setCategoryMargin(10.0d);
    java.awt.Stroke var11 = var8.getAxisLineStroke();
    var5.setTickMarkStroke(var11);
    var5.setAutoRange(false);
    java.awt.Paint var15 = var5.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.plot.AbstractPieLabelDistributor var1 = var0.getLabelDistributor();
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = var2.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var2.setSimpleLabelOffset(var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    float var11 = var10.getBackgroundImageAlpha();
    var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var10);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    java.awt.geom.Point2D var18 = var17.getQuadrantOrigin();
    java.awt.geom.Point2D var19 = var17.getQuadrantOrigin();
    var17.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var17.setFixedRangeAxisSpace(var22, true);
    java.awt.Paint var26 = null;
    java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
    java.awt.Paint[] var28 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var29 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var30 = null;
    java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
    java.awt.Stroke var32 = null;
    java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
    java.awt.Shape var34 = null;
    java.awt.Shape[] var35 = new java.awt.Shape[] { var34};
    org.jfree.chart.plot.DefaultDrawingSupplier var36 = new org.jfree.chart.plot.DefaultDrawingSupplier(var27, var28, var29, var31, var33, var35);
    java.awt.Paint var37 = var36.getNextOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
    var38.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("");
    var38.setRangeAxis((org.jfree.chart.axis.ValueAxis)var43);
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var46.setCategoryMargin(10.0d);
    java.awt.Stroke var49 = var46.getAxisLineStroke();
    var43.setTickMarkStroke(var49);
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker((-1.0d), var37, var49);
    org.jfree.chart.util.Layer var52 = null;
    var17.addRangeMarker((org.jfree.chart.plot.Marker)var51, var52);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setTextAntiAlias((java.lang.Object)var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 1.0f, 10.0f);
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("Multiple Pie Plot", var33, (java.awt.Paint)var39);
//     org.jfree.chart.text.TextFragment var41 = var40.getFirstTextFragment();
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.text.TextAnchor var43 = null;
//     float var44 = var41.calculateBaselineOffset(var42, var43);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    java.lang.Object var15 = var9.clone();
    java.awt.Paint var16 = var9.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "Range[0.025,0.05]", "RectangleConstraint[LengthConstraintType.NONE: width=4.0, height=1.0]");

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(0, var4, false);
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var0.setRangeAxes(var11);
    var0.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    var0.clearRangeAxes();
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
    int var5 = var0.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    var8.setBackgroundPaint((java.awt.Paint)var18);
    int var20 = var18.getAlpha();
    int var21 = var18.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var0.setSimpleLabelOffset(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     var9.setWidth(20.0d);
//     var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var8.addSubtitle((org.jfree.chart.title.Title)var9);
//     org.jfree.chart.event.ChartProgressListener var15 = null;
//     var8.removeProgressListener(var15);
//     java.awt.Paint var17 = var8.getBorderPaint();
//     org.jfree.chart.event.ChartProgressListener var18 = null;
//     var8.removeProgressListener(var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var28 = var26.trimWidth(10.0d);
//     var21.setLabelPadding(var26);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
//     java.awt.geom.Point2D var38 = var37.getQuadrantOrigin();
//     var30.zoomDomainAxes(1.0d, var32, var38);
//     org.jfree.chart.util.RectangleInsets var40 = var30.getAxisOffset();
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle();
//     var41.setWidth(20.0d);
//     var41.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var41.setURLText("Category Plot");
//     double var48 = var41.getWidth();
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.util.Size2D var52 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var57 = var55.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     var55.setRangeAxis(10, var59);
//     java.awt.Stroke var61 = null;
//     var55.setOutlineStroke(var61);
//     org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
//     var55.setRenderer(1, var64);
//     org.jfree.chart.util.HorizontalAlignment var66 = null;
//     org.jfree.chart.util.VerticalAlignment var67 = null;
//     org.jfree.chart.block.FlowArrangement var70 = new org.jfree.chart.block.FlowArrangement(var66, var67, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var71 = null;
//     org.jfree.chart.util.VerticalAlignment var72 = null;
//     org.jfree.chart.block.ColumnArrangement var75 = new org.jfree.chart.block.ColumnArrangement(var71, var72, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55, (org.jfree.chart.block.Arrangement)var70, (org.jfree.chart.block.Arrangement)var75);
//     boolean var78 = var76.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var79 = var76.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var80 = var76.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var81 = var76.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var82 = org.jfree.chart.util.RectangleAnchor.createRectangle(var52, 0.05d, 0.2d, var81);
//     var41.draw(var49, var82);
//     java.awt.geom.Rectangle2D var84 = var40.createOutsetRectangle(var82);
//     java.awt.geom.Rectangle2D var85 = var26.createInsetRectangle(var82);
//     var8.draw(var20, var82);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "", "hi!");
    java.lang.String var6 = var5.getVersion();
    var5.setVersion("Range[0.025,0.05]");
    org.jfree.chart.ui.Library[] var9 = var5.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("HorizontalAlignment.CENTER", var1);
// 
//   }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER", var1);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var10 = var8.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     var8.setRangeAxis(10, var12);
//     var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var8);
//     boolean var15 = var8.isDomainGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
//     java.awt.geom.Point2D var24 = var23.getQuadrantOrigin();
//     org.jfree.chart.JFreeChart var25 = null;
//     org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var24, var25, 0, 0);
//     var8.zoomRangeAxes(90.0d, 0.08d, var18, var24);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getShadowYOffset();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var4 = var2.getRangeAxis(0);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var2.setRangeAxis(0, var6, false);
    var2.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var2.setRangeAxes(var13);
    java.awt.Paint var15 = null;
    java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
    java.awt.Paint[] var17 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var18 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var19 = null;
    java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
    java.awt.Stroke var21 = null;
    java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
    java.awt.Shape var23 = null;
    java.awt.Shape[] var24 = new java.awt.Shape[] { var23};
    org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var17, var18, var20, var22, var24);
    java.awt.Paint var26 = var25.getNextOutlinePaint();
    var2.setRangeGridlinePaint(var26);
    var0.setLabelShadowPaint(var26);
    org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot();
    double var31 = var29.getExplodePercent((java.lang.Comparable)10L);
    var29.setMaximumLabelWidth((-11.0d));
    double var34 = var29.getInnerSeparatorExtension();
    org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var36 = var35.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var35.setSimpleLabelOffset(var41);
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var35);
    org.jfree.chart.labels.PieSectionLabelGenerator var44 = var35.getLabelGenerator();
    var29.setLegendLabelGenerator(var44);
    var0.setLabelGenerator(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    boolean var3 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var6 = var4.getDomainAxis((-1));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    boolean var14 = var12.getAutoRangeStickyZero();
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setFixedAutoRange(20.0d);
    var12.setInverted(false);
    var12.setAutoTickUnitSelection(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    var9.setLicenceName("hi!");
    boolean var12 = var0.equals((java.lang.Object)"hi!");
    org.jfree.chart.event.RendererChangeEvent var13 = null;
    var0.rendererChanged(var13);
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    var0.setRenderer(var15, false);
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var20 = var0.removeRangeMarker(var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     java.awt.Stroke var4 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var7 = var5.getDomainAxis((-1));
//     boolean var8 = var5.isRangeGridlinesVisible();
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var11 = var9.getDomainAxis((-1));
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var17);
//     boolean var19 = var17.getAutoRangeStickyZero();
//     var9.setDomainAxis((org.jfree.chart.axis.ValueAxis)var17);
//     var5.setRangeAxis((org.jfree.chart.axis.ValueAxis)var17);
//     java.awt.Stroke var22 = var17.getTickMarkStroke();
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis(0);
    java.util.List var3 = var0.getCategories();
    org.jfree.chart.util.RectangleEdge var5 = var0.getRangeAxisEdge(10);
    org.jfree.data.general.DatasetChangeEvent var6 = null;
    var0.datasetChanged(var6);
    var0.clearAnnotations();
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    var0.setRenderer(0, var10, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(0, var2, true);
    org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    var9.setLicenceName("hi!");
    boolean var12 = var0.equals((java.lang.Object)"hi!");
    org.jfree.data.category.CategoryDataset var14 = null;
    var0.setDataset(10, var14);
    org.jfree.chart.plot.DatasetRenderingOrder var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    double var8 = var6.trimWidth(10.0d);
    var1.setLabelPadding(var6);
    boolean var10 = var1.isCircular();
    org.jfree.chart.LegendItemCollection var11 = var1.getLegendItems();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    java.awt.Paint var13 = var12.getBackgroundPaint();
    org.jfree.chart.title.TextTitle var14 = var12.getTitle();
    java.lang.Object var15 = var14.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var1 = var0.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var3 = var0.getStringArray("java.awt.Color[r=255,g=255,b=255]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    var0.setLabelLinkMargin(0.0d);
    var0.setLabelLinkMargin(20.0d);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var7 = var5.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var9 = null;
    var5.setRangeAxis(10, var9);
    java.awt.Stroke var11 = null;
    var5.setOutlineStroke(var11);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var5.setRenderer(1, var14);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.FlowArrangement var20 = new org.jfree.chart.block.FlowArrangement(var16, var17, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var21 = null;
    org.jfree.chart.util.VerticalAlignment var22 = null;
    org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var20, (org.jfree.chart.block.Arrangement)var25);
    boolean var28 = var26.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot();
    double var30 = var29.getShadowYOffset();
    double var31 = var29.getShadowYOffset();
    java.awt.Font var32 = var29.getLabelFont();
    var26.setItemFont(var32);
    var0.setLabelFont(var32);
    double var35 = var0.getLabelLinkMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 20.0d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var10 = var8.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var12 = null;
    var8.setRangeAxis(10, var12);
    var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var8);
    var8.setRangeCrosshairVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getShadowYOffset();
    double var2 = var0.getLabelGap();
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var5.setCategoryMargin(10.0d);
    java.awt.Stroke var8 = var5.getAxisLineStroke();
    boolean var9 = var3.equals((java.lang.Object)var5);
    java.awt.Paint var10 = var5.getAxisLinePaint();
    var0.setLabelPaint(var10);
    java.awt.Paint var12 = null;
    var0.setLabelOutlinePaint(var12);
    var0.setLabelLinksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var7 = var5.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     var5.setRangeAxis(10, var9);
//     java.awt.Stroke var11 = null;
//     var5.setOutlineStroke(var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     var5.setRenderer(1, var14);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.FlowArrangement var20 = new org.jfree.chart.block.FlowArrangement(var16, var17, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var20, (org.jfree.chart.block.Arrangement)var25);
//     boolean var28 = var26.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var29 = var26.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var30 = var26.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var31 = var26.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var32 = org.jfree.chart.util.RectangleAnchor.createRectangle(var2, 0.05d, 0.2d, var31);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var35 = var33.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     var33.setRangeAxis(10, var37);
//     java.awt.Stroke var39 = null;
//     var33.setOutlineStroke(var39);
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     var33.setRenderer(1, var42);
//     org.jfree.chart.util.HorizontalAlignment var44 = null;
//     org.jfree.chart.util.VerticalAlignment var45 = null;
//     org.jfree.chart.block.FlowArrangement var48 = new org.jfree.chart.block.FlowArrangement(var44, var45, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var49 = null;
//     org.jfree.chart.util.VerticalAlignment var50 = null;
//     org.jfree.chart.block.ColumnArrangement var53 = new org.jfree.chart.block.ColumnArrangement(var49, var50, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33, (org.jfree.chart.block.Arrangement)var48, (org.jfree.chart.block.Arrangement)var53);
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     var55.setRangeAxis(0, var57, true);
//     java.awt.Paint var60 = var55.getRangeCrosshairPaint();
//     java.awt.Paint var61 = var55.getNoDataMessagePaint();
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
//     org.jfree.chart.util.RectangleAnchor var63 = var62.getLegendItemGraphicLocation();
//     var54.setLegendItemGraphicLocation(var63);
//     java.awt.geom.Point2D var65 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var63);
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var48
//     assertTrue("Contract failed: equals-hashcode on var20 and var48", var20.equals(var48) ? var20.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var20
//     assertTrue("Contract failed: equals-hashcode on var48 and var20", var48.equals(var20) ? var48.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var53
//     assertTrue("Contract failed: equals-hashcode on var25 and var53", var25.equals(var53) ? var25.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var25
//     assertTrue("Contract failed: equals-hashcode on var53 and var25", var53.equals(var25) ? var53.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)255, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
//     org.jfree.chart.event.MarkerChangeEvent var3 = null;
//     var0.markerChanged(var3);
//     boolean var5 = var0.isCircular();
//     org.jfree.chart.labels.PieToolTipGenerator var6 = null;
//     var0.setToolTipGenerator(var6);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     var0.drawBackground(var8, var9);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var0.setSimpleLabelOffset(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    var9.setWidth(20.0d);
    var9.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var8.addSubtitle((org.jfree.chart.title.Title)var9);
    java.lang.Object var15 = var9.clone();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(4.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var20 = var19.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var21 = var19.toUnconstrainedHeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var22 = var9.arrange(var16, var21);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    java.awt.geom.Point2D var6 = var5.getQuadrantOrigin();
    java.awt.geom.Point2D var7 = var5.getQuadrantOrigin();
    var5.setRangeCrosshairValue(4.0d);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var5.setFixedRangeAxisSpace(var10, true);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var14, var16, var17);
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var20 = var19.getLabelShadowPaint();
    org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
    var19.setSimpleLabelOffset(var25);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
    var28.setWidth(20.0d);
    var28.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
    var27.addSubtitle((org.jfree.chart.title.Title)var28);
    java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 0.0f, (-1.0f));
    var27.setBackgroundPaint((java.awt.Paint)var37);
    var18.setOutlinePaint((java.awt.Paint)var37);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var42.setCategoryMargin(10.0d);
    java.awt.Stroke var45 = var42.getAxisLineStroke();
    var42.configure();
    var42.setLowerMargin(1.0d);
    boolean var49 = var42.isAxisLineVisible();
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    var50.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("");
    var50.setRangeAxis((org.jfree.chart.axis.ValueAxis)var55);
    boolean var57 = var55.getAutoRangeStickyZero();
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var60 = var58.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var62 = null;
    var58.setRangeAxis(10, var62);
    var55.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var58);
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var40, var42, (org.jfree.chart.axis.ValueAxis)var55, var65);
    org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot();
    double var69 = var67.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
    var71.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("");
    var71.setRangeAxis((org.jfree.chart.axis.ValueAxis)var76);
    org.jfree.chart.axis.CategoryAxis var79 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var79.setCategoryMargin(10.0d);
    java.awt.Stroke var82 = var79.getAxisLineStroke();
    var76.setTickMarkStroke(var82);
    var67.setSectionOutlineStroke((java.lang.Comparable)1L, var82);
    org.jfree.chart.plot.AbstractPieLabelDistributor var85 = var67.getLabelDistributor();
    double var86 = var67.getShadowXOffset();
    java.awt.Paint var87 = var67.getLabelPaint();
    var55.setTickMarkPaint(var87);
    var18.setDomainGridlinePaint(var87);
    org.jfree.chart.renderer.xy.XYItemRenderer var90 = null;
    var18.setRenderer(var90);
    var18.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var8.setCategoryMargin(10.0d);
//     java.awt.Stroke var11 = var8.getAxisLineStroke();
//     var5.setTickMarkStroke(var11);
//     double var13 = var5.getLowerMargin();
//     org.jfree.data.RangeType var14 = var5.getRangeType();
//     java.lang.Object var15 = var5.clone();
//     var5.setRangeWithMargins(6.25d, 10.0d);
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var27 = var25.trimWidth(10.0d);
//     var20.setLabelPadding(var25);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     java.awt.geom.Point2D var37 = var36.getQuadrantOrigin();
//     var29.zoomDomainAxes(1.0d, var31, var37);
//     org.jfree.chart.util.RectangleInsets var39 = var29.getAxisOffset();
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle();
//     var40.setWidth(20.0d);
//     var40.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var40.setURLText("Category Plot");
//     double var47 = var40.getWidth();
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.util.Size2D var51 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var56 = var54.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     var54.setRangeAxis(10, var58);
//     java.awt.Stroke var60 = null;
//     var54.setOutlineStroke(var60);
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     var54.setRenderer(1, var63);
//     org.jfree.chart.util.HorizontalAlignment var65 = null;
//     org.jfree.chart.util.VerticalAlignment var66 = null;
//     org.jfree.chart.block.FlowArrangement var69 = new org.jfree.chart.block.FlowArrangement(var65, var66, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var70 = null;
//     org.jfree.chart.util.VerticalAlignment var71 = null;
//     org.jfree.chart.block.ColumnArrangement var74 = new org.jfree.chart.block.ColumnArrangement(var70, var71, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54, (org.jfree.chart.block.Arrangement)var69, (org.jfree.chart.block.Arrangement)var74);
//     boolean var77 = var75.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var78 = var75.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var79 = var75.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var80 = var75.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var81 = org.jfree.chart.util.RectangleAnchor.createRectangle(var51, 0.05d, 0.2d, var80);
//     var40.draw(var48, var81);
//     java.awt.geom.Rectangle2D var83 = var39.createOutsetRectangle(var81);
//     java.awt.geom.Rectangle2D var84 = var25.createInsetRectangle(var81);
//     org.jfree.chart.plot.XYPlot var85 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var87 = var85.getDomainAxis((-1));
//     org.jfree.chart.plot.Plot var88 = var85.getRootPlot();
//     java.awt.Graphics2D var89 = null;
//     java.awt.geom.Rectangle2D var90 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var92 = null;
//     org.jfree.chart.plot.CrosshairState var93 = null;
//     boolean var94 = var85.render(var89, var90, 0, var92, var93);
//     java.awt.Paint var96 = var85.getQuadrantPaint(0);
//     org.jfree.chart.util.RectangleEdge var98 = var85.getRangeAxisEdge(100);
//     double var99 = var5.valueToJava2D(25.312499999999993d, var84, var98);
//     
//     // Checks the contract:  equals-hashcode on var36 and var85
//     assertTrue("Contract failed: equals-hashcode on var36 and var85", var36.equals(var85) ? var36.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var36
//     assertTrue("Contract failed: equals-hashcode on var85 and var36", var85.equals(var36) ? var85.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     var40.setDataset(var41);
//     boolean var43 = var39.equals((java.lang.Object)var40);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
//     org.jfree.chart.text.TextLine var45 = var44.getLastLine();
//     java.util.List var46 = var44.getLines();
//     org.jfree.chart.text.TextLine var47 = var44.getLastLine();
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.text.TextBlockAnchor var51 = null;
//     java.awt.Shape var55 = var44.calculateBounds(var48, 0.0f, 1.0f, var51, 0.0f, 100.0f, (-11.0d));
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
//     boolean var3 = var0.isRangeGridlinesVisible();
//     var0.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     var6.setDataset(var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.data.Range var10 = var6.getDataRange(var9);
//     boolean var11 = var6.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var6.setFixedRangeAxisSpace(var12);
//     java.awt.Stroke var14 = var6.getRangeGridlineStroke();
//     var0.setRangeGridlineStroke(var14);
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
//     var17.setLabelLinkMargin(0.0d);
//     var17.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var24 = var22.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     var22.setRangeAxis(10, var26);
//     java.awt.Stroke var28 = null;
//     var22.setOutlineStroke(var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     var22.setRenderer(1, var31);
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.FlowArrangement var37 = new org.jfree.chart.block.FlowArrangement(var33, var34, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.util.VerticalAlignment var39 = null;
//     org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var38, var39, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var37, (org.jfree.chart.block.Arrangement)var42);
//     boolean var45 = var43.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot();
//     double var47 = var46.getShadowYOffset();
//     double var48 = var46.getShadowYOffset();
//     java.awt.Font var49 = var46.getLabelFont();
//     var43.setItemFont(var49);
//     var17.setLabelFont(var49);
//     java.awt.Color var55 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var57 = null;
//     var56.setDataset(var57);
//     boolean var59 = var55.equals((java.lang.Object)var56);
//     org.jfree.chart.text.TextBlock var60 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var49, (java.awt.Paint)var55);
//     var0.setRangeZeroBaselinePaint((java.awt.Paint)var55);
//     
//     // Checks the contract:  equals-hashcode on var6 and var56
//     assertTrue("Contract failed: equals-hashcode on var6 and var56", var6.equals(var56) ? var6.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var6
//     assertTrue("Contract failed: equals-hashcode on var56 and var6", var56.equals(var6) ? var56.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.ui.Licences var0 = org.jfree.chart.ui.Licences.getInstance();
    java.lang.String var1 = var0.getGPL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
    boolean var7 = var5.getAutoRangeStickyZero();
    var5.setAutoRangeStickyZero(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.mapDatasetToDomainAxis(0, 0);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    java.awt.Shape var17 = var15.getDownArrow();
    var5.setDownArrow(var17);
    org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var17, "", "Multiple Pie Plot");
    java.awt.Shape var22 = var21.getArea();
    org.jfree.chart.entity.ChartEntity var25 = new org.jfree.chart.entity.ChartEntity(var22, "org.jfree.chart.event.ChartChangeEvent[source=false]", "org.jfree.chart.event.ChartChangeEvent[source=false]");
    java.lang.String var26 = var25.getURLText();
    var25.setToolTipText("Rotation.CLOCKWISE");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=false]"+ "'", var26.equals("org.jfree.chart.event.ChartChangeEvent[source=false]"));

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     var1.setLabelLinkMargin(0.0d);
//     var1.setLabelLinkMargin(20.0d);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var8 = var6.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var6.setRangeAxis(10, var10);
//     java.awt.Stroke var12 = null;
//     var6.setOutlineStroke(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     var6.setRenderer(1, var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var26);
//     boolean var29 = var27.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     double var31 = var30.getShadowYOffset();
//     double var32 = var30.getShadowYOffset();
//     java.awt.Font var33 = var30.getLabelFont();
//     var27.setItemFont(var33);
//     var1.setLabelFont(var33);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     var40.setDataset(var41);
//     boolean var43 = var39.equals((java.lang.Object)var40);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]", var33, (java.awt.Paint)var39);
//     org.jfree.chart.text.TextLine var45 = var44.getLastLine();
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var47 = var46.getTextAlignment();
//     var44.setLineAlignment(var47);
//     org.jfree.chart.util.HorizontalAlignment var49 = var44.getLineAlignment();
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var52.setCategoryMargin(10.0d);
//     java.awt.Stroke var55 = var52.getAxisLineStroke();
//     var52.setMaximumCategoryLabelWidthRatio(1.0f);
//     var52.setLowerMargin(25.312499999999993d);
//     java.awt.Font var61 = var52.getTickLabelFont((java.lang.Comparable)(short)0);
//     org.jfree.chart.plot.PiePlot var62 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var67 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var69 = var67.trimWidth(10.0d);
//     var62.setLabelPadding(var67);
//     boolean var71 = var62.isCircular();
//     java.awt.Paint var72 = var62.getShadowPaint();
//     double var73 = var62.getMaximumExplodePercent();
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var76 = var74.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     var74.setRangeAxis(10, var78);
//     java.awt.Stroke var80 = null;
//     var74.setOutlineStroke(var80);
//     org.jfree.data.xy.XYDataset var82 = null;
//     int var83 = var74.indexOf(var82);
//     java.awt.Graphics2D var84 = null;
//     java.awt.geom.Rectangle2D var85 = null;
//     java.util.List var86 = null;
//     var74.drawDomainTickBands(var84, var85, var86);
//     org.jfree.chart.plot.DatasetRenderingOrder var88 = var74.getDatasetRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var89 = var74.getDomainAxisLocation();
//     org.jfree.chart.plot.PiePlot var90 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var91 = var90.getLabelShadowPaint();
//     var74.setRangeGridlinePaint(var91);
//     var62.setBaseSectionOutlinePaint(var91);
//     var44.addLine("", var61, var91);
//     
//     // Checks the contract:  equals-hashcode on var30 and var90
//     assertTrue("Contract failed: equals-hashcode on var30 and var90", var30.equals(var90) ? var30.hashCode() == var90.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var90 and var30
//     assertTrue("Contract failed: equals-hashcode on var90 and var30", var90.equals(var30) ? var90.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var7 = var5.getAutoRangeStickyZero();
//     var5.setAutoRangeStickyZero(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.mapDatasetToDomainAxis(0, 0);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     java.awt.Shape var17 = var15.getDownArrow();
//     var5.setDownArrow(var17);
//     org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var17, "", "Multiple Pie Plot");
//     java.awt.Shape var22 = var21.getArea();
//     org.jfree.chart.entity.ChartEntity var25 = new org.jfree.chart.entity.ChartEntity(var22, "org.jfree.chart.event.ChartChangeEvent[source=false]", "org.jfree.chart.event.ChartChangeEvent[source=false]");
//     java.lang.String var26 = var25.getURLText();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var27 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var28 = null;
//     java.lang.String var29 = var25.getImageMapAreaTag(var27, var28);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    int var6 = var0.getWeight();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    int var9 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    var8.setInverted(false);
    org.jfree.chart.plot.Plot var12 = var8.getPlot();
    boolean var13 = var8.isAutoTickUnitSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setRangeAxis(10, var4);
    java.awt.Stroke var6 = null;
    var0.setOutlineStroke(var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(1, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, 10.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var15, (org.jfree.chart.block.Arrangement)var20);
    boolean var23 = var21.equals((java.lang.Object)(short)(-1));
    org.jfree.chart.util.RectangleInsets var24 = var21.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleInsets var25 = var21.getItemLabelPadding();
    double var26 = var25.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0d);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.geom.Point2D var5 = var4.getQuadrantOrigin();
//     org.jfree.chart.JFreeChart var6 = null;
//     org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var6, 0, 0);
//     org.jfree.chart.JFreeChart var10 = null;
//     var9.setChart(var10);
//     int var12 = var9.getPercent();
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var14 = var13.getLabelShadowPaint();
//     org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     var13.setSimpleLabelOffset(var19);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
//     var22.setWidth(20.0d);
//     var22.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var21.addSubtitle((org.jfree.chart.title.Title)var22);
//     var9.setChart(var21);
//     java.lang.String var29 = var9.toString();
//     java.lang.String var30 = var9.toString();
//     org.jfree.chart.JFreeChart var31 = var9.getChart();
//     org.jfree.chart.title.TextTitle var32 = var31.getTitle();
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     var31.handleClick((-16777216), (-10223606), var35);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    var0.setLabelLinkMargin(0.0d);
    double var3 = var0.getInteriorGap();
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var0.getLegendLabelToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     double var2 = var1.getShadowYOffset();
//     double var3 = var1.getShadowYOffset();
//     java.awt.Font var4 = var1.getLabelFont();
//     java.awt.Font var5 = var1.getLabelFont();
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, (-1.0d), 0.0d);
//     double var13 = var11.trimWidth(10.0d);
//     var6.setLabelPadding(var11);
//     double var15 = var6.getStartAngle();
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var17 = var16.getLabelShadowPaint();
//     var6.setBaseSectionPaint(var17);
//     org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=178,g=178,b=178]", var5, var17, 10.0f);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var2 = null;
//     java.awt.geom.Point2D var3 = null;
//     var0.zoomRangeAxes(1.0E-8d, var2, var3, true);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var2 = var0.getExplodePercent((java.lang.Comparable)10L);
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var0.markerChanged(var3);
    double var5 = var0.getMaximumLabelWidth();
    org.jfree.chart.urls.PieURLGenerator var6 = var0.getLegendLabelURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset((-1));
//     java.util.List var3 = var0.getAnnotations();
//     var0.zoom(90.0d);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.event.PlotChangeListener var1 = null;
//     var0.addChangeListener(var1);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var7 = var5.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     var5.setRangeAxis(10, var9);
//     java.awt.Stroke var11 = null;
//     var5.setOutlineStroke(var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     int var14 = var5.indexOf(var13);
//     java.awt.geom.Point2D var15 = var5.getQuadrantOrigin();
//     var0.zoomRangeAxes(0.025d, var4, var15, true);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     java.awt.geom.Point2D var27 = var26.getQuadrantOrigin();
//     var19.zoomDomainAxes(1.0d, var21, var27);
//     org.jfree.chart.util.RectangleInsets var29 = var19.getAxisOffset();
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle();
//     var30.setWidth(20.0d);
//     var30.setToolTipText("RectangleInsets[t=-1.0,l=10.0,b=-1.0,r=0.0]");
//     var30.setURLText("Category Plot");
//     double var37 = var30.getWidth();
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.util.Size2D var41 = new org.jfree.chart.util.Size2D(100.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.ValueAxis var46 = var44.getDomainAxis((-1));
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     var44.setRangeAxis(10, var48);
//     java.awt.Stroke var50 = null;
//     var44.setOutlineStroke(var50);
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     var44.setRenderer(1, var53);
//     org.jfree.chart.util.HorizontalAlignment var55 = null;
//     org.jfree.chart.util.VerticalAlignment var56 = null;
//     org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 100.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var60 = null;
//     org.jfree.chart.util.VerticalAlignment var61 = null;
//     org.jfree.chart.block.ColumnArrangement var64 = new org.jfree.chart.block.ColumnArrangement(var60, var61, 10.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var44, (org.jfree.chart.block.Arrangement)var59, (org.jfree.chart.block.Arrangement)var64);
//     boolean var67 = var65.equals((java.lang.Object)(short)(-1));
//     org.jfree.chart.util.RectangleInsets var68 = var65.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleInsets var69 = var65.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var70 = var65.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var71 = org.jfree.chart.util.RectangleAnchor.createRectangle(var41, 0.05d, 0.2d, var70);
//     var30.draw(var38, var71);
//     java.awt.geom.Rectangle2D var73 = var29.createOutsetRectangle(var71);
//     var0.drawBackground(var18, var71);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    java.lang.String var2 = var1.toString();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getShadowYOffset();
    double var2 = var0.getShadowYOffset();
    java.awt.Paint var3 = var0.getOutlinePaint();
    java.lang.Object var4 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var1 = var0.getLogo();
    java.util.List var2 = var0.getContributors();
    java.util.List var3 = var0.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

}
