
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    boolean var10 = var9.isEmpty();
    org.jfree.data.general.Dataset var11 = var9.getDataset();
    org.jfree.data.general.Dataset var12 = var9.getDataset();
    org.jfree.chart.block.FlowArrangement var13 = new org.jfree.chart.block.FlowArrangement();
    var9.setArrangement((org.jfree.chart.block.Arrangement)var13);
    var9.setURLText("org.jfree.chart.ChartColor[r=0,g=4,b=0]");
    java.awt.Graphics2D var17 = null;
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var21 = var20.getLowerDate();
    org.jfree.data.Range var24 = org.jfree.data.Range.shift((org.jfree.data.Range)var20, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, 1.0d);
    org.jfree.chart.util.Size2D var29 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    org.jfree.chart.util.Size2D var30 = var26.calculateConstrainedSize(var29);
    org.jfree.data.Range var31 = var26.getWidthRange();
    double var32 = var26.getWidth();
    org.jfree.data.Range var33 = var26.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var9.arrange(var17, var26);
    org.jfree.chart.util.Size2D var37 = new org.jfree.chart.util.Size2D(1.0d, 0.0d);
    org.jfree.chart.util.Size2D var38 = var26.calculateConstrainedSize(var37);
    org.jfree.chart.axis.CategoryLabelPosition var41 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var42 = var41.getWidthRatio();
    double var43 = var41.getAngle();
    org.jfree.chart.util.RectangleAnchor var44 = var41.getCategoryAnchor();
    java.awt.geom.Rectangle2D var45 = org.jfree.chart.util.RectangleAnchor.createRectangle(var38, 1.5d, (-1.05d), var44);
    org.jfree.chart.axis.AxisCollection var46 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var47 = var46.getAxesAtBottom();
    java.util.List var48 = var46.getAxesAtTop();
    java.util.List var49 = var46.getAxesAtRight();
    boolean var50 = var44.equals((java.lang.Object)var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.util.RectangleAnchor var16 = null;
    var15.setLegendItemGraphicLocation(var16);
    double var18 = var15.getWidth();
    java.awt.Graphics2D var19 = null;
    org.jfree.data.time.DateRange var22 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var23 = var22.getLowerDate();
    org.jfree.data.Range var26 = org.jfree.data.Range.shift((org.jfree.data.Range)var22, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var26, 1.0d);
    java.lang.String var29 = var28.toString();
    org.jfree.chart.block.RectangleConstraint var31 = var28.toFixedHeight(0.35d);
    org.jfree.chart.util.Size2D var32 = var15.arrange(var19, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]"+ "'", var29.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getCategoryMargin();
    boolean var11 = var3.equals((java.lang.Object)var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var3);
    var12.clearSubtitles();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var15 = var12.getSubtitle((-10289251));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    double var6 = var2.getItemMargin();
    boolean var8 = var2.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var11 = var2.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var13.setRangeWithMargins((org.jfree.data.Range)var16, false, true);
    org.jfree.data.Range var20 = var13.getDefaultAutoRange();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.AxisState var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    java.util.List var25 = var13.refreshTicks(var21, var22, var23, var24);
    java.awt.Font var26 = var13.getLabelFont();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
    var29.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var33 = var29.getURLGenerator();
    java.awt.Shape var34 = var29.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var35 = null;
    var29.setLabelGenerator(var35);
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
    int var41 = var40.getBackgroundImageAlignment();
    var29.addChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
    org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var46 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var44.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var46);
    org.jfree.chart.renderer.category.IntervalBarRenderer var48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var50 = null;
    var48.setSeriesItemLabelFont(1, var50);
    boolean var52 = var48.getBaseSeriesVisibleInLegend();
    java.awt.Paint var55 = var48.getItemOutlinePaint(13, 100);
    var44.setBaseItemLabelPaint(var55);
    var29.setSectionPaint((java.lang.Comparable)(short)100, var55);
    org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("Default Group", var26, var55);
    java.awt.geom.Rectangle2D var59 = var58.getBounds();
    var2.setBaseShape((java.awt.Shape)var59, false);
    org.jfree.chart.plot.PlotRenderingInfo var63 = null;
    boolean var64 = var0.render(var1, var59, (-457), var63);
    var0.configureDomainAxes();
    org.jfree.chart.axis.ValueAxis var66 = var0.getRangeAxis();
    org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.PlotOrientation var68 = var0.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    java.lang.Object var11 = var3.clone();
    boolean var12 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.util.SortOrder var13 = var0.getRowRenderingOrder();
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    double var20 = var16.getItemMargin();
    boolean var22 = var16.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var24 = null;
    var23.rendererChanged(var24);
    var16.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var23);
    org.jfree.data.general.Dataset var28 = null;
    org.jfree.data.general.DatasetChangeEvent var29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var28);
    var23.datasetChanged(var29);
    var0.datasetChanged(var29);
    org.jfree.chart.util.RectangleEdge var32 = var0.getRangeAxisEdge();
    org.jfree.chart.util.Layer var34 = null;
    java.util.Collection var35 = var0.getDomainMarkers(0, var34);
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var40 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var37.setRangeWithMargins((org.jfree.data.Range)var40, false, true);
    org.jfree.data.Range var44 = var37.getDefaultAutoRange();
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.axis.AxisState var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.util.RectangleEdge var48 = null;
    java.util.List var49 = var37.refreshTicks(var45, var46, var47, var48);
    java.awt.Font var50 = var37.getLabelFont();
    org.jfree.chart.plot.MultiplePiePlot var51 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var52 = var51.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var53 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var56 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var53.setRangeWithMargins((org.jfree.data.Range)var56, false, true);
    org.jfree.data.Range var60 = var53.getDefaultAutoRange();
    java.awt.Graphics2D var61 = null;
    org.jfree.chart.axis.AxisState var62 = null;
    java.awt.geom.Rectangle2D var63 = null;
    org.jfree.chart.util.RectangleEdge var64 = null;
    java.util.List var65 = var53.refreshTicks(var61, var62, var63, var64);
    org.jfree.chart.plot.Plot var66 = var53.getPlot();
    boolean var67 = var51.equals((java.lang.Object)var53);
    java.awt.Paint var68 = var53.getAxisLinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
    org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var36, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var53, var69);
    org.jfree.chart.axis.AxisLocation var71 = var70.getRangeAxisLocation();
    var0.setDomainAxisLocation(var71);
    org.jfree.chart.axis.AxisLocation var74 = var0.getDomainAxisLocation(0);
    org.jfree.chart.axis.AxisLocation var75 = var74.getOpposite();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }


    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var6 = var5.getTransparency();
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder(10.0d, 10.0d, 100.0d, 1.0d, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var13 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var14 = null;
    var13.addChangeListener(var14);
    org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var12, (org.jfree.data.general.Dataset)var13, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    boolean var18 = var17.isEmpty();
    org.jfree.data.general.Dataset var19 = var17.getDataset();
    org.jfree.data.general.Dataset var20 = var17.getDataset();
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement();
    var17.setArrangement((org.jfree.chart.block.Arrangement)var21);
    var17.setURLText("org.jfree.chart.ChartColor[r=0,g=4,b=0]");
    java.awt.Graphics2D var25 = null;
    org.jfree.data.time.DateRange var27 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0d, (org.jfree.data.Range)var27);
    java.lang.String var29 = var28.toString();
    org.jfree.data.Range var30 = var28.getHeightRange();
    org.jfree.chart.util.Size2D var31 = var17.arrange(var25, var28);
    boolean var32 = var7.equals((java.lang.Object)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"+ "'", var29.equals("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    var2.setShadowYOffset(1.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var8.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getBaseItemLabelGenerator();
    double var11 = var8.getBase();
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    var2.setOutlineStroke(var12);
    var2.setDepthFactor(0.0d);
    org.jfree.chart.plot.Plot var16 = var2.getRootPlot();
    org.jfree.data.general.PieDataset var17 = var2.getDataset();
    org.jfree.chart.plot.DrawingSupplier var18 = var2.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.renderer.category.StackedAreaRenderer var3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    double var8 = var4.getItemMargin();
    boolean var10 = var4.isSeriesVisibleInLegend(1);
    java.lang.Boolean var12 = var4.getSeriesCreateEntities(1);
    java.awt.Paint var14 = var4.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var17 = null;
    var15.setSeriesItemLabelFont(1, var17);
    boolean var19 = var15.getBaseSeriesVisibleInLegend();
    java.awt.Paint var22 = var15.getItemOutlinePaint(13, 100);
    var4.setBaseFillPaint(var22, true);
    var4.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var28 = var4.getBaseNegativeItemLabelPosition();
    boolean var29 = var3.equals((java.lang.Object)var28);
    org.jfree.data.DefaultKeyedValues2D var30 = new org.jfree.data.DefaultKeyedValues2D();
    boolean var31 = var3.equals((java.lang.Object)var30);
    org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
    java.util.Date var33 = var32.getEnd();
    org.jfree.data.time.RegularTimePeriod var34 = var32.previous();
    int var35 = var30.getColumnIndex((java.lang.Comparable)var32);
    java.lang.Number var37 = var1.getQ3Value((java.lang.Comparable)var32, (java.lang.Comparable)"Nearest");
    java.lang.Comparable var38 = null;
    java.lang.Number var40 = var1.getQ1Value(var38, (java.lang.Comparable)2);
    java.lang.Number var43 = var1.getMinRegularValue((java.lang.Comparable)"First", (java.lang.Comparable)(-0.5d));
    org.jfree.data.Range var45 = var1.getRangeBounds(false);
    boolean var46 = var0.equals((java.lang.Object)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var49 = var1.getMaxRegularValue(3, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var3.setRangeWithMargins((org.jfree.data.Range)var6, false, true);
    org.jfree.data.Range var10 = var3.getDefaultAutoRange();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.AxisState var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    java.util.List var15 = var3.refreshTicks(var11, var12, var13, var14);
    java.awt.Font var16 = var3.getLabelFont();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    var19.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var19.axisChanged(var24);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var16, (org.jfree.chart.plot.Plot)var19, false);
    var27.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var30 = var27.getTitle();
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.entity.EntityCollection var32 = null;
    org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
    java.awt.geom.Rectangle2D var34 = var33.getChartArea();
    var30.draw(var31, var34);
    org.jfree.chart.ChartColor var39 = new org.jfree.chart.ChartColor(0, 4, 0);
    var30.setPaint((java.awt.Paint)var39);
    java.lang.String var41 = var39.toString();
    org.jfree.chart.title.LegendGraphic var42 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var39);
    boolean var43 = var42.isShapeOutlineVisible();
    boolean var44 = var42.isShapeVisible();
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D(var46);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var47);
    var47.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var51 = var47.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var52 = null;
    var47.axisChanged(var52);
    var47.setDepthFactor(100.0d);
    boolean var56 = var42.equals((java.lang.Object)var47);
    java.awt.Shape var57 = var42.getShape();
    java.awt.Paint var58 = var42.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=4,b=0]"+ "'", var41.equals("org.jfree.chart.ChartColor[r=0,g=4,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    int var2 = var0.getWeight();
    var0.clearDomainMarkers();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation((-1));
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D(var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var8);
    var8.setShadowYOffset(0.0d);
    double var12 = var8.getMaximumLabelWidth();
    org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var15 = null;
    var13.setSeriesItemLabelFont(1, var15);
    boolean var17 = var13.getBaseSeriesVisibleInLegend();
    java.awt.Paint var20 = var13.getItemOutlinePaint(13, 100);
    var8.setBackgroundPaint(var20);
    java.awt.Paint var22 = var8.getBaseSectionOutlinePaint();
    var0.setDomainTickBandPaint(var22);
    java.awt.Paint var24 = var0.getDomainGridlinePaint();
    var0.configureDomainAxes();
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    var0.setRenderer(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
//     long var4 = var3.getSegmentsExcludedSize();
//     int var5 = var3.getSegmentsIncluded();
//     long var7 = var3.getTimeFromLong(1L);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     org.jfree.chart.util.Size2D var11 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
//     java.lang.Object var12 = var11.clone();
//     int var13 = var8.compareTo((java.lang.Object)var11);
//     java.util.Date var14 = var8.getStart();
//     java.util.Date var15 = var8.getEnd();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var16 = var3.getSegment(var15);
//     var3.addBaseTimelineException(1969L);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var2 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder();
//     boolean var4 = var2.equals((java.lang.Object)var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     double var7 = var6.getCategoryMargin();
//     int var8 = var6.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.CategoryAnchor var9 = null;
//     org.jfree.chart.entity.EntityCollection var12 = null;
//     org.jfree.chart.ChartRenderingInfo var13 = new org.jfree.chart.ChartRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getChartArea();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var17 = var15.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var19 = var18.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var20 = var18.getBaseItemLabelGenerator();
//     java.awt.Paint var22 = null;
//     var18.setSeriesFillPaint(1, var22, false);
//     var18.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var28 = var18.getLegendItemLabelGenerator();
//     var15.setLegendItemToolTipGenerator(var28);
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.util.Size2D var32 = var30.arrange(var31);
//     org.jfree.chart.util.RectangleEdge var33 = var30.getPosition();
//     boolean var34 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var33);
//     double var35 = var6.getCategoryJava2DCoordinate(var9, 0, 10, var14, var33);
//     var3.draw(var5, var14);
//     boolean var37 = var1.equals((java.lang.Object)var5);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(2);
//     boolean var40 = var1.isOnOrAfter(var39);
//     int var41 = var1.toSerial();
//     java.lang.String var42 = var1.toString();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(15);
//     java.lang.String var45 = var44.getDescription();
//     java.lang.String var46 = var44.getDescription();
//     boolean var47 = var1.isAfter(var44);
//     org.jfree.data.time.SerialDate var48 = null;
//     org.jfree.data.time.SerialDate var49 = var44.getEndOfCurrentMonth(var48);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    int var1 = var0.getItemCount();
    java.lang.Class var2 = null;
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var5 = var4.getUpArrow();
    java.awt.Shape var6 = var4.getDownArrow();
    java.util.Date var7 = var4.getMinimumDate();
    java.util.TimeZone var8 = null;
    org.jfree.data.time.RegularTimePeriod var9 = org.jfree.data.time.RegularTimePeriod.createInstance(var2, var7, var8);
    org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var7);
    var0.setValue((java.lang.Comparable)var10, 4.0d);
    org.jfree.data.time.RegularTimePeriod var13 = var10.next();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("java.awt.Color[r=0,g=0,b=0]");
    org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    var2.addFragment(var4);
    org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var8 = var7.getPaint();
    var2.removeFragment(var7);
    float var10 = var7.getBaselineOffset();
    float var11 = var7.getBaselineOffset();
    float var12 = var7.getBaselineOffset();
    var1.addFragment(var7);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    double var16 = var15.getCategoryMargin();
    org.jfree.chart.axis.CategoryAxis[] var17 = new org.jfree.chart.axis.CategoryAxis[] { var15};
    var14.setDomainAxes(var17);
    org.jfree.chart.axis.CategoryAxis var20 = var14.getDomainAxisForDataset(0);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var23.setRangeWithMargins((org.jfree.data.Range)var26, false, true);
    org.jfree.data.Range var30 = var23.getDefaultAutoRange();
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.axis.AxisState var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    java.util.List var35 = var23.refreshTicks(var31, var32, var33, var34);
    java.awt.Font var36 = var23.getLabelFont();
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
    var39.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var43 = var39.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var44 = null;
    var39.axisChanged(var44);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var36, (org.jfree.chart.plot.Plot)var39, false);
    var47.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var50 = var47.getTitle();
    java.awt.Graphics2D var51 = null;
    org.jfree.chart.entity.EntityCollection var52 = null;
    org.jfree.chart.ChartRenderingInfo var53 = new org.jfree.chart.ChartRenderingInfo(var52);
    java.awt.geom.Rectangle2D var54 = var53.getChartArea();
    var50.draw(var51, var54);
    org.jfree.chart.plot.CategoryMarker var57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    org.jfree.chart.util.LengthAdjustmentType var58 = var57.getLabelOffsetType();
    java.lang.Object var59 = null;
    boolean var60 = var58.equals(var59);
    java.lang.String var61 = var58.toString();
    org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var63 = var62.getFixedLegendItems();
    java.awt.geom.Point2D var64 = var62.getQuadrantOrigin();
    boolean var65 = var58.equals((java.lang.Object)var64);
    org.jfree.chart.plot.PlotState var66 = new org.jfree.chart.plot.PlotState();
    org.jfree.chart.ChartRenderingInfo var67 = null;
    org.jfree.chart.plot.PlotRenderingInfo var68 = new org.jfree.chart.plot.PlotRenderingInfo(var67);
    var14.draw(var21, var54, var64, var66, var68);
    boolean var70 = var7.equals((java.lang.Object)var14);
    var14.mapDatasetToRangeAxis(100, 55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "EXPAND"+ "'", var61.equals("EXPAND"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    var0.setDomainCrosshairValue(0.0d);
    var0.setRangeCrosshairValue((-7.0d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var7.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var11 = var10.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var10.getBaseItemLabelGenerator();
    java.awt.Paint var14 = null;
    var10.setSeriesFillPaint(1, var14, false);
    var10.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = var10.getLegendItemLabelGenerator();
    var7.setLegendItemToolTipGenerator(var20);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    java.lang.Object var23 = null;
    boolean var24 = var22.equals(var23);
    java.awt.Paint var25 = var22.getItemPaint();
    var0.setDomainGridlinePaint(var25);
    org.jfree.chart.plot.DatasetRenderingOrder var27 = var0.getDatasetRenderingOrder();
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var32 = var31.getUpArrow();
    java.awt.Shape var33 = var31.getDownArrow();
    java.awt.Stroke var34 = var31.getTickMarkStroke();
    var29.setRangeCrosshairStroke(var34);
    org.jfree.chart.util.Layer var37 = null;
    java.util.Collection var38 = var29.getDomainMarkers(13, var37);
    org.jfree.chart.axis.AxisSpace var39 = new org.jfree.chart.axis.AxisSpace();
    double var40 = var39.getBottom();
    var39.setTop(0.0d);
    double var43 = var39.getBottom();
    org.jfree.chart.axis.AxisSpace var44 = new org.jfree.chart.axis.AxisSpace();
    double var45 = var44.getBottom();
    java.lang.Object var46 = var44.clone();
    var39.ensureAtLeast(var44);
    var29.setFixedDomainAxisSpace(var44);
    double var49 = var44.getTop();
    var0.setFixedDomainAxisSpace(var44);
    org.jfree.chart.LegendItemCollection var51 = var0.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("Default Group");
    java.lang.Comparable var2 = var1.getKey();
    org.jfree.data.KeyToGroupMap var4 = new org.jfree.data.KeyToGroupMap();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var7 = var6.getUpArrow();
    boolean var8 = var4.equals((java.lang.Object)var7);
    boolean var10 = var4.equals((java.lang.Object)0.0f);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var13 = var12.getUpArrow();
    java.awt.Shape var14 = var12.getDownArrow();
    java.util.Date var15 = var12.getMinimumDate();
    int var16 = var4.getGroupIndex((java.lang.Comparable)var15);
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var19 = var18.getUpArrow();
    java.awt.Shape var20 = var18.getDownArrow();
    java.util.Date var21 = var18.getMinimumDate();
    java.lang.String var22 = var18.getLabel();
    java.util.Date var23 = var18.getMinimumDate();
    org.jfree.data.gantt.Task var24 = new org.jfree.data.gantt.Task("Pie 3D Plot", var15, var23);
    var1.add(var24);
    org.jfree.data.gantt.TaskSeries var27 = new org.jfree.data.gantt.TaskSeries("Default Group");
    java.lang.Comparable var28 = var27.getKey();
    java.beans.PropertyChangeListener var29 = null;
    var27.removePropertyChangeListener(var29);
    org.jfree.data.gantt.Task var31 = null;
    var27.remove(var31);
    org.jfree.data.gantt.TaskSeriesCollection var33 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var34 = null;
    var33.addChangeListener(var34);
    org.jfree.data.general.PieDataset var37 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var33, (-435));
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var33, false);
    java.util.List var40 = var33.getRowKeys();
    var27.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var33);
    var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var33);
    int var43 = var33.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Default Group"+ "'", var2.equals("Default Group"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "hi!"+ "'", var22.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Default Group"+ "'", var28.equals("Default Group"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.ChartColor[r=0,g=4,b=0]");

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getCategoryMargin();
    var0.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var5 = var4.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var6.setRangeWithMargins((org.jfree.data.Range)var9, false, true);
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.AxisState var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    java.util.List var18 = var6.refreshTicks(var14, var15, var16, var17);
    org.jfree.chart.plot.Plot var19 = var6.getPlot();
    boolean var20 = var4.equals((java.lang.Object)var6);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D(var21);
    var22.setIgnoreZeroValues(true);
    var4.setParent((org.jfree.chart.plot.Plot)var22);
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var30 = var29.getLabelOffset();
    boolean var31 = var26.equals((java.lang.Object)var29);
    org.jfree.chart.event.MarkerChangeEvent var32 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var29);
    var4.markerChanged(var32);
    var4.setLimit(90.0d);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
    var39.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var43 = var39.getURLGenerator();
    java.awt.Shape var44 = var39.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var45 = null;
    var39.setLabelGenerator(var45);
    java.lang.Object var47 = var39.clone();
    boolean var48 = var36.equals((java.lang.Object)var39);
    java.awt.Color var50 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var51 = var50.getTransparency();
    var36.setRangeCrosshairPaint((java.awt.Paint)var50);
    java.awt.Color var53 = var50.brighter();
    var4.setAggregatedItemsPaint((java.awt.Paint)var53);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }


    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.IntervalMarker var4 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var5 = var4.getAlpha();
    java.awt.Paint var6 = var4.getPaint();
    var1.setAngleLabelPaint(var6);
    java.awt.Paint var8 = var1.getAngleLabelPaint();
    java.awt.Stroke var9 = var1.getRadiusGridlineStroke();
    var1.setRadiusGridlinesVisible(false);
    org.jfree.chart.renderer.category.GanttRenderer var12 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var13 = var12.getCompletePaint();
    var1.setRadiusGridlinePaint(var13);
    java.awt.Font var15 = var1.getAngleLabelFont();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var16 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    var19.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
    java.awt.Shape var24 = var19.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = null;
    var19.setLabelGenerator(var25);
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
    int var31 = var30.getBackgroundImageAlignment();
    var19.addChangeListener((org.jfree.chart.event.PlotChangeListener)var30);
    java.awt.Stroke var33 = var30.getBorderStroke();
    var16.setGroupStroke(var33);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var16.getLegendItemURLGenerator();
    java.awt.Paint var36 = var16.getGroupPaint();
    java.awt.Paint var39 = var16.getItemFillPaint(15, 100);
    org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("ChartChangeEventType.GENERAL", var15, var39);
    org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
    double var42 = var41.getBottom();
    var41.setRight(8.0d);
    java.lang.Object var45 = var41.clone();
    boolean var46 = var40.equals((java.lang.Object)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.chart.plot.MultiplePiePlot var15 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var16 = var15.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var17.setRangeWithMargins((org.jfree.data.Range)var20, false, true);
    org.jfree.data.Range var24 = var17.getDefaultAutoRange();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.AxisState var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var17.refreshTicks(var25, var26, var27, var28);
    org.jfree.chart.plot.Plot var30 = var17.getPlot();
    boolean var31 = var15.equals((java.lang.Object)var17);
    java.awt.Paint var32 = var17.getAxisLinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var17, var33);
    org.jfree.chart.axis.AxisLocation var35 = var34.getRangeAxisLocation();
    org.jfree.chart.LegendItemCollection var36 = var34.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var4 = var3.getLowerDate();
    java.util.Date var5 = var3.getUpperDate();
    boolean var6 = var0.containsDomainValue(var5);
    long var7 = var0.getSegmentsIncludedSize();
    boolean var9 = var0.containsDomainValue(1417420800000L);
    boolean var11 = var0.containsDomainValue(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 432000000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var3 = var2.getUpArrow();
    java.awt.Shape var4 = var2.getDownArrow();
    java.awt.Stroke var5 = var2.getTickMarkStroke();
    var0.setRangeCrosshairStroke(var5);
    java.awt.geom.Point2D var7 = var0.getQuadrantOrigin();
    java.awt.Paint var8 = var0.getDomainZeroBaselinePaint();
    java.awt.Stroke var9 = var0.getDomainGridlineStroke();
    boolean var10 = var0.isRangeZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(100);
    int var3 = var2.getMonth();
    int var4 = var2.getYYYY();
    java.lang.Class var5 = null;
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var8 = var7.getUpArrow();
    java.awt.Shape var9 = var7.getDownArrow();
    java.util.Date var10 = var7.getMinimumDate();
    java.util.TimeZone var11 = null;
    org.jfree.data.time.RegularTimePeriod var12 = org.jfree.data.time.RegularTimePeriod.createInstance(var5, var10, var11);
    org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(var10);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var10);
    boolean var15 = var2.isOnOrBefore(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate)var2);
    org.jfree.data.DefaultKeyedValues var17 = new org.jfree.data.DefaultKeyedValues();
    int var18 = var17.getItemCount();
    org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(100);
    int var22 = var21.getMonth();
    int var23 = var21.getYYYY();
    java.lang.Class var24 = null;
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var27 = var26.getUpArrow();
    java.awt.Shape var28 = var26.getDownArrow();
    java.util.Date var29 = var26.getMinimumDate();
    java.util.TimeZone var30 = null;
    org.jfree.data.time.RegularTimePeriod var31 = org.jfree.data.time.RegularTimePeriod.createInstance(var24, var29, var30);
    org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(var29);
    org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var29);
    boolean var34 = var21.isOnOrBefore(var33);
    org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate)var21);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(100);
    int var38 = var37.getMonth();
    org.jfree.data.time.SerialDate var39 = var21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var37);
    var17.setValue((java.lang.Comparable)var37, (java.lang.Number)9);
    org.jfree.data.time.SerialDate var42 = var16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var3 = var2.getUpArrow();
    java.awt.Shape var4 = var2.getDownArrow();
    java.awt.Stroke var5 = var2.getTickMarkStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getDomainMarkers(13, var8);
    boolean var10 = var0.isRangeZeroBaselineVisible();
    org.jfree.chart.axis.AxisLocation var11 = var0.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
    java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var13 = null;
    var11.setSeriesItemLabelFont(1, var13);
    boolean var15 = var11.getBaseSeriesVisibleInLegend();
    java.awt.Paint var18 = var11.getItemOutlinePaint(13, 100);
    var0.setBaseFillPaint(var18, true);
    org.jfree.chart.urls.StandardCategoryURLGenerator var24 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "", "");
    var0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var24, false);
    java.awt.Stroke var27 = var0.getBaseOutlineStroke();
    double var28 = var0.getMaximumBarWidth();
    org.jfree.chart.labels.CategoryToolTipGenerator var29 = var0.getBaseToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getRowCount();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var3.setRangeWithMargins((org.jfree.data.Range)var6, false, true);
    org.jfree.data.Range var10 = var3.getDefaultAutoRange();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.AxisState var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    java.util.List var15 = var3.refreshTicks(var11, var12, var13, var14);
    java.awt.Font var16 = var3.getLabelFont();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    var19.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var19.axisChanged(var24);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var16, (org.jfree.chart.plot.Plot)var19, false);
    var27.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var30 = var27.getTitle();
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.entity.EntityCollection var32 = null;
    org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
    java.awt.geom.Rectangle2D var34 = var33.getChartArea();
    var30.draw(var31, var34);
    org.jfree.chart.ChartColor var39 = new org.jfree.chart.ChartColor(0, 4, 0);
    var30.setPaint((java.awt.Paint)var39);
    org.jfree.chart.block.BlockFrame var41 = var30.getFrame();
    org.jfree.chart.axis.DateTickUnit var44 = new org.jfree.chart.axis.DateTickUnit(0, (-435));
    java.lang.Object var45 = null;
    int var46 = var44.compareTo(var45);
    org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    float var49 = var48.getBaselineOffset();
    boolean var50 = var44.equals((java.lang.Object)var49);
    var0.addObject((java.lang.Object)var30, (java.lang.Comparable)var44, (java.lang.Comparable)"RectangleAnchor.CENTER");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var55 = var0.getObject(3, 5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
    java.awt.geom.Point2D var4 = var2.getQuadrantOrigin();
    org.jfree.chart.axis.ValueAxis var5 = null;
    var2.setRangeAxis(var5);
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D(var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var9);
    java.awt.Shape var11 = var9.getLegendItemShape();
    org.jfree.data.general.PieDataset var12 = var9.getDataset();
    org.jfree.chart.labels.PieSectionLabelGenerator var13 = var9.getLabelGenerator();
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var15 = var14.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var16 = var14.getBaseItemLabelGenerator();
    java.awt.Paint var18 = null;
    var14.setSeriesFillPaint(1, var18, false);
    java.awt.Stroke var22 = null;
    var14.setSeriesStroke(0, var22);
    org.jfree.chart.renderer.category.IntervalBarRenderer var25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var27 = null;
    var25.setSeriesItemLabelFont(1, var27);
    org.jfree.chart.renderer.category.IntervalBarRenderer var29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var31 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var29.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var31);
    var25.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var31);
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var34 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var36 = null;
    org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D(var36);
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var37);
    var37.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var41 = var37.getURLGenerator();
    java.awt.Shape var42 = var37.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var43 = null;
    var37.setLabelGenerator(var43);
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D(var46);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var47);
    int var49 = var48.getBackgroundImageAlignment();
    var37.addChangeListener((org.jfree.chart.event.PlotChangeListener)var48);
    java.awt.Stroke var51 = var48.getBorderStroke();
    var34.setGroupStroke(var51);
    var25.setBaseStroke(var51);
    var14.setSeriesStroke(0, var51);
    var9.setLabelLinkStroke(var51);
    var2.setRangeZeroBaselineStroke(var51);
    var0.setSeparatorStroke(var51);
    double var58 = var0.getSectionDepth();
    boolean var59 = var0.getSeparatorsVisible();
    org.jfree.chart.LegendItemCollection var60 = var0.getLegendItems();
    var0.setInnerSeparatorExtension((-7.0d));
    java.lang.Object var63 = null;
    boolean var64 = var0.equals(var63);
    boolean var65 = var0.isCircular();
    var0.setSectionDepth(7.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var3 = var2.getUpArrow();
    java.awt.Shape var4 = var2.getDownArrow();
    java.awt.Stroke var5 = var2.getTickMarkStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = var0.getRendererForDataset(var8);
    var0.setDomainCrosshairLockedOnData(false);
    java.awt.Paint var12 = var0.getRangeZeroBaselinePaint();
    org.jfree.data.DefaultKeyedValues2D var14 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var15 = var14.getRowKeys();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var19 = var17.lookupSeriesShape((-1));
    var16.setUpArrow(var19);
    java.util.Date var21 = var16.getMaximumDate();
    int var22 = var14.getColumnIndex((java.lang.Comparable)var21);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var26 = var24.lookupSeriesShape((-1));
    var23.setUpArrow(var26);
    var23.setLabel("");
    java.util.TimeZone var30 = var23.getTimeZone();
    org.jfree.data.time.Year var31 = new org.jfree.data.time.Year(var21, var30);
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", var30);
    var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var32);
    org.jfree.data.time.DateRange var36 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var37 = var36.getLowerDate();
    org.jfree.data.Range var40 = org.jfree.data.Range.shift((org.jfree.data.Range)var36, 0.0d, false);
    boolean var43 = var36.intersects(10.0d, (-1.05d));
    org.jfree.data.time.DateRange var46 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var47 = var46.getLowerDate();
    org.jfree.data.Range var50 = org.jfree.data.Range.shift((org.jfree.data.Range)var46, 0.0d, false);
    boolean var53 = var46.intersects(10.0d, (-1.05d));
    double var54 = var46.getLowerBound();
    org.jfree.data.Range var55 = org.jfree.data.Range.combine((org.jfree.data.Range)var36, (org.jfree.data.Range)var46);
    org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var58 = var57.getUpArrow();
    java.awt.Shape var59 = var57.getDownArrow();
    java.util.Date var60 = var57.getMinimumDate();
    java.lang.String var61 = var57.getLabel();
    java.util.Date var62 = var57.getMinimumDate();
    var57.setLabelToolTip("org.jfree.chart.event.ChartChangeEvent[source=true]");
    org.jfree.data.time.DateRange var67 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var68 = var67.getLowerDate();
    org.jfree.data.Range var70 = org.jfree.data.Range.shift((org.jfree.data.Range)var67, (-1.0d));
    var57.setRangeWithMargins((org.jfree.data.Range)var67);
    org.jfree.data.Range var72 = org.jfree.data.Range.combine((org.jfree.data.Range)var36, (org.jfree.data.Range)var67);
    var32.setRangeWithMargins((org.jfree.data.Range)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "hi!"+ "'", var61.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var3, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var8 = var7.toString();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var12, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var17 = var16.toString();
    org.jfree.chart.ui.Library[] var18 = var16.getLibraries();
    var7.addLibrary((org.jfree.chart.ui.Library)var16);
    var7.setLicenceText("");
    java.awt.Image var25 = null;
    org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var25, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var30 = var29.toString();
    java.awt.Image var34 = null;
    org.jfree.chart.ui.ProjectInfo var38 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var34, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var39 = var38.toString();
    org.jfree.chart.ui.Library[] var40 = var38.getLibraries();
    var29.addLibrary((org.jfree.chart.ui.Library)var38);
    var29.setLicenceText("");
    var7.addLibrary((org.jfree.chart.ui.Library)var29);
    org.jfree.chart.ui.Library[] var45 = var29.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var8.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var17.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var30.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var39.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Font var3 = var1.getLabelFont();
    java.text.DateFormat var4 = var1.getDateFormatOverride();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
    var7.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
    java.awt.Shape var12 = var7.getLegendItemShape();
    org.jfree.chart.util.Rotation var13 = var7.getDirection();
    org.jfree.chart.util.RectangleInsets var14 = var7.getInsets();
    var1.setLabelInsets(var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var20 = null;
    var18.setSeriesItemLabelFont(1, var20);
    double var22 = var18.getItemMargin();
    boolean var24 = var18.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var27 = var18.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var29.setRangeWithMargins((org.jfree.data.Range)var32, false, true);
    org.jfree.data.Range var36 = var29.getDefaultAutoRange();
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.axis.AxisState var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.RectangleEdge var40 = null;
    java.util.List var41 = var29.refreshTicks(var37, var38, var39, var40);
    java.awt.Font var42 = var29.getLabelFont();
    org.jfree.data.general.PieDataset var44 = null;
    org.jfree.chart.plot.PiePlot3D var45 = new org.jfree.chart.plot.PiePlot3D(var44);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var45);
    var45.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var49 = var45.getURLGenerator();
    java.awt.Shape var50 = var45.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var51 = null;
    var45.setLabelGenerator(var51);
    org.jfree.data.general.PieDataset var54 = null;
    org.jfree.chart.plot.PiePlot3D var55 = new org.jfree.chart.plot.PiePlot3D(var54);
    org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var55);
    int var57 = var56.getBackgroundImageAlignment();
    var45.addChangeListener((org.jfree.chart.event.PlotChangeListener)var56);
    org.jfree.chart.renderer.category.IntervalBarRenderer var60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var62 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var60.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var62);
    org.jfree.chart.renderer.category.IntervalBarRenderer var64 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var66 = null;
    var64.setSeriesItemLabelFont(1, var66);
    boolean var68 = var64.getBaseSeriesVisibleInLegend();
    java.awt.Paint var71 = var64.getItemOutlinePaint(13, 100);
    var60.setBaseItemLabelPaint(var71);
    var45.setSectionPaint((java.lang.Comparable)(short)100, var71);
    org.jfree.chart.block.LabelBlock var74 = new org.jfree.chart.block.LabelBlock("Default Group", var42, var71);
    java.awt.geom.Rectangle2D var75 = var74.getBounds();
    var18.setBaseShape((java.awt.Shape)var75, false);
    org.jfree.chart.plot.PlotRenderingInfo var79 = null;
    boolean var80 = var16.render(var17, var75, (-457), var79);
    java.awt.geom.Rectangle2D var83 = var14.createOutsetRectangle(var75, true, false);
    double var85 = var14.trimHeight(1.0d);
    org.jfree.chart.util.UnitType var86 = var14.getUnitType();
    java.lang.String var87 = var86.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == (-7.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var87 + "' != '" + "UnitType.ABSOLUTE"+ "'", var87.equals("UnitType.ABSOLUTE"));

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    java.lang.Object var4 = var0.getObject(13);
    java.lang.Object var6 = var0.getObject(255);
    org.jfree.chart.renderer.category.StackedBarRenderer var8 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var9 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var10 = var8.findRangeBounds((org.jfree.data.category.CategoryDataset)var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var16 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var17 = null;
    var16.addChangeListener(var17);
    org.jfree.chart.title.LegendItemBlockContainer var20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var15, (org.jfree.data.general.Dataset)var16, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.Comparable var22 = var21.getAggregatedItemsKey();
    boolean var23 = var16.hasListener((java.util.EventListener)var21);
    java.util.List var24 = var16.getColumnKeys();
    org.jfree.data.Range var25 = var8.findRangeBounds((org.jfree.data.category.CategoryDataset)var16);
    boolean var26 = var0.equals((java.lang.Object)var16);
    java.lang.Object var28 = var0.getObject(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Other"+ "'", var22.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var2 = var1.getRowKeys();
    java.util.List var3 = var1.getColumnKeys();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    java.util.Date var5 = var4.getEnd();
    var1.removeColumn((java.lang.Comparable)var4);
    var0.setValue((java.lang.Comparable)var4, (java.lang.Number)0.0d);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var2 = var1.getRowKeys();
    java.util.List var3 = var1.getColumnKeys();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    java.util.Date var5 = var4.getEnd();
    var1.removeColumn((java.lang.Comparable)var4);
    var0.setValue((java.lang.Comparable)var4, (java.lang.Number)0.0d);
    java.util.List var9 = var0.getKeys();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
    var13.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var17 = var13.getURLGenerator();
    java.awt.Shape var18 = var13.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var19 = null;
    var13.setLabelGenerator(var19);
    java.lang.Object var21 = var13.clone();
    boolean var22 = var10.equals((java.lang.Object)var13);
    org.jfree.chart.util.SortOrder var23 = var10.getRowRenderingOrder();
    var10.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.GanttRenderer var26 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.plot.CategoryMarker var28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var28.setKey((java.lang.Comparable)false);
    boolean var31 = var28.getDrawAsLine();
    boolean var32 = var26.equals((java.lang.Object)var28);
    var10.addDomainMarker(var28);
    org.jfree.chart.axis.AxisSpace var34 = var10.getFixedRangeAxisSpace();
    org.jfree.chart.util.SortOrder var35 = var10.getColumnRenderingOrder();
    var0.sortByValues(var35);
    java.util.List var37 = var0.getKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.util.Rotation var8 = var2.getDirection();
    java.awt.Paint var9 = var2.getBaseSectionOutlinePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var2.setLegendLabelURLGenerator(var10);
    var2.setDepthFactor(0.0d);
    double var14 = var2.getMinimumArcAngleToDraw();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0E-5d);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("8-April-1900", var1, 1.0d, (-1.0f), 2.0f);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Paint var3 = var1.lookupSeriesOutlinePaint(255);
    java.lang.Object var4 = var1.clone();
    int var5 = var1.getPassCount();
    org.jfree.chart.renderer.AreaRendererEndType var6 = var1.getEndType();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    boolean var8 = var7.isAxisLineVisible();
    org.jfree.chart.renderer.category.IntervalBarRenderer var9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var11 = null;
    var9.setSeriesItemLabelFont(1, var11);
    boolean var13 = var9.getBaseSeriesVisibleInLegend();
    java.awt.Paint var16 = var9.getItemOutlinePaint(13, 100);
    java.awt.Shape var19 = var9.getItemShape((-1), 1);
    org.jfree.chart.entity.AxisLabelEntity var22 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var7, var19, "hi!", "Default Group");
    org.jfree.chart.entity.LegendItemEntity var23 = new org.jfree.chart.entity.LegendItemEntity(var19);
    var23.setSeriesKey((java.lang.Comparable)"black");
    java.lang.Comparable var26 = var23.getSeriesKey();
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var27 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var28 = null;
    java.lang.String var29 = var23.getImageMapAreaTag(var27, var28);
    boolean var30 = var6.equals((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "black"+ "'", var26.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + ""+ "'", var29.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    double var8 = var4.getItemMargin();
    boolean var10 = var4.isSeriesVisibleInLegend(1);
    java.lang.Boolean var12 = var4.getSeriesCreateEntities(1);
    java.awt.Paint var14 = var4.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var17 = null;
    var15.setSeriesItemLabelFont(1, var17);
    boolean var19 = var15.getBaseSeriesVisibleInLegend();
    java.awt.Paint var22 = var15.getItemOutlinePaint(13, 100);
    var4.setBaseFillPaint(var22, true);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var29 = var28.getUpArrow();
    java.awt.Shape var30 = var28.getDownArrow();
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var4.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    java.awt.Shape var36 = var4.getItemShape(255, 2);
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var38.setRangeWithMargins((org.jfree.data.Range)var41, false, true);
    org.jfree.data.Range var45 = var38.getDefaultAutoRange();
    java.awt.Graphics2D var46 = null;
    org.jfree.chart.axis.AxisState var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    org.jfree.chart.util.RectangleEdge var49 = null;
    java.util.List var50 = var38.refreshTicks(var46, var47, var48, var49);
    java.awt.Font var51 = var38.getLabelFont();
    org.jfree.data.general.PieDataset var53 = null;
    org.jfree.chart.plot.PiePlot3D var54 = new org.jfree.chart.plot.PiePlot3D(var53);
    org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var54);
    var54.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var58 = var54.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var59 = null;
    var54.axisChanged(var59);
    org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var51, (org.jfree.chart.plot.Plot)var54, false);
    var62.setBackgroundImageAlignment(10);
    org.jfree.chart.plot.Plot var65 = var62.getPlot();
    java.awt.Paint var66 = var62.getBackgroundPaint();
    org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("hi!", "DateTickMarkPosition.START", "SortOrder.ASCENDING", "ERROR : Relative To String", var36, var66);
    java.awt.Shape var68 = var67.getLine();
    java.awt.Stroke var69 = var67.getLineStroke();
    boolean var70 = var67.isLineVisible();
    var67.setDatasetIndex(4);
    java.awt.Paint var73 = var67.getOutlinePaint();
    java.lang.String var74 = var67.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var74 + "' != '" + "SortOrder.ASCENDING"+ "'", var74.equals("SortOrder.ASCENDING"));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelOffset();
    java.awt.geom.Rectangle2D var11 = null;
    var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var9, var11);
    java.lang.Object var13 = var6.clone();
    var6.setAutoTickUnitSelection(false, true);
    float var17 = var6.getTickMarkInsideLength();
    org.jfree.chart.util.RectangleInsets var18 = var6.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    var0.setAutoPopulateSeriesStroke(false);
    org.jfree.data.KeyToGroupMap var4 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)"RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    var0.setSeriesToGroupMap(var4);
    java.util.List var6 = var4.getGroups();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    var0.setDomainCrosshairValue(0.0d);
    var0.setRangeCrosshairValue((-7.0d));
    int var7 = var0.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     var0.clearRangeAxes();
//     var0.clearDomainMarkers(100);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
//     var7.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
//     java.awt.Shape var12 = var7.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var13 = null;
//     var7.setLabelGenerator(var13);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     int var19 = var18.getBackgroundImageAlignment();
//     var7.addChangeListener((org.jfree.chart.event.PlotChangeListener)var18);
//     int var21 = var7.getPieIndex();
//     java.awt.Paint var22 = var7.getBaseSectionPaint();
//     var0.setRangeTickBandPaint(var22);
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var27 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var24.setRangeWithMargins((org.jfree.data.Range)var27, false, true);
//     org.jfree.data.Range var31 = var24.getDefaultAutoRange();
//     var24.setAutoTickUnitSelection(false, false);
//     java.text.DateFormat var35 = null;
//     var24.setDateFormatOverride(var35);
//     java.util.TimeZone var37 = var24.getTimeZone();
//     org.jfree.data.Range var38 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
//     var24.setLabelURL("Other");
//     org.jfree.data.Range var41 = var24.getDefaultAutoRange();
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var46 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var43.setRangeWithMargins((org.jfree.data.Range)var46, false, true);
//     org.jfree.data.Range var50 = var43.getDefaultAutoRange();
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.axis.AxisState var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     org.jfree.chart.util.RectangleEdge var54 = null;
//     java.util.List var55 = var43.refreshTicks(var51, var52, var53, var54);
//     java.awt.Font var56 = var43.getLabelFont();
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.PiePlot3D var59 = new org.jfree.chart.plot.PiePlot3D(var58);
//     org.jfree.chart.JFreeChart var60 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var59);
//     var59.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var63 = var59.getURLGenerator();
//     java.awt.Shape var64 = var59.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var65 = null;
//     var59.setLabelGenerator(var65);
//     org.jfree.data.general.PieDataset var68 = null;
//     org.jfree.chart.plot.PiePlot3D var69 = new org.jfree.chart.plot.PiePlot3D(var68);
//     org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var69);
//     int var71 = var70.getBackgroundImageAlignment();
//     var59.addChangeListener((org.jfree.chart.event.PlotChangeListener)var70);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var74 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var76 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var74.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var76);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var78 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var80 = null;
//     var78.setSeriesItemLabelFont(1, var80);
//     boolean var82 = var78.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var85 = var78.getItemOutlinePaint(13, 100);
//     var74.setBaseItemLabelPaint(var85);
//     var59.setSectionPaint((java.lang.Comparable)(short)100, var85);
//     org.jfree.chart.block.LabelBlock var88 = new org.jfree.chart.block.LabelBlock("Default Group", var56, var85);
//     java.awt.geom.Rectangle2D var89 = var88.getBounds();
//     org.jfree.chart.util.RectangleInsets var90 = var88.getPadding();
//     var24.setLabelInsets(var90);
//     
//     // Checks the contract:  equals-hashcode on var17 and var69
//     assertTrue("Contract failed: equals-hashcode on var17 and var69", var17.equals(var69) ? var17.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var17
//     assertTrue("Contract failed: equals-hashcode on var69 and var17", var69.equals(var17) ? var69.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var70
//     assertTrue("Contract failed: equals-hashcode on var18 and var70", var18.equals(var70) ? var18.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var18
//     assertTrue("Contract failed: equals-hashcode on var70 and var18", var70.equals(var18) ? var70.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    var1.configure();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var4 = var3.clone();
    var3.setDrawOutlines(true);
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var8 = var7.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var7.getBaseItemLabelGenerator();
    java.awt.Paint var11 = null;
    var7.setSeriesFillPaint(1, var11, false);
    var7.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var18 = var7.getSeriesPositiveItemLabelPosition(100);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var23 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var20.setRangeWithMargins((org.jfree.data.Range)var23, false, true);
    org.jfree.data.Range var27 = var20.getDefaultAutoRange();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.AxisState var29 = null;
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.util.RectangleEdge var31 = null;
    java.util.List var32 = var20.refreshTicks(var28, var29, var30, var31);
    java.awt.Font var33 = var20.getLabelFont();
    org.jfree.data.general.PieDataset var35 = null;
    org.jfree.chart.plot.PiePlot3D var36 = new org.jfree.chart.plot.PiePlot3D(var35);
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var36);
    var36.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var40 = var36.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var41 = null;
    var36.axisChanged(var41);
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var33, (org.jfree.chart.plot.Plot)var36, false);
    boolean var45 = var18.equals((java.lang.Object)var33);
    var3.setBaseItemLabelFont(var33);
    var1.setLabelFont(var33);
    double var48 = var1.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.chart.util.Rotation var10 = var2.getDirection();
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var12.setRangeWithMargins((org.jfree.data.Range)var15, false, true);
    org.jfree.data.Range var19 = var12.getDefaultAutoRange();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.axis.AxisState var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    java.util.List var24 = var12.refreshTicks(var20, var21, var22, var23);
    java.awt.Font var25 = var12.getLabelFont();
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var28);
    var28.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var32 = var28.getURLGenerator();
    java.awt.Shape var33 = var28.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var34 = null;
    var28.setLabelGenerator(var34);
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.PiePlot3D var38 = new org.jfree.chart.plot.PiePlot3D(var37);
    org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var38);
    int var40 = var39.getBackgroundImageAlignment();
    var28.addChangeListener((org.jfree.chart.event.PlotChangeListener)var39);
    org.jfree.chart.renderer.category.IntervalBarRenderer var43 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var45 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var43.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var45);
    org.jfree.chart.renderer.category.IntervalBarRenderer var47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var49 = null;
    var47.setSeriesItemLabelFont(1, var49);
    boolean var51 = var47.getBaseSeriesVisibleInLegend();
    java.awt.Paint var54 = var47.getItemOutlinePaint(13, 100);
    var43.setBaseItemLabelPaint(var54);
    var28.setSectionPaint((java.lang.Comparable)(short)100, var54);
    org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("Default Group", var25, var54);
    var2.setLabelBackgroundPaint(var54);
    double var59 = var2.getDepthFactor();
    java.awt.Stroke var60 = var2.getBaseSectionOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
//     long var4 = var3.getSegmentsExcludedSize();
//     var3.addException((-1L), 0L);
//     org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var9 = var8.getDataExtractOrder();
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var10.setRangeWithMargins((org.jfree.data.Range)var13, false, true);
//     org.jfree.data.Range var17 = var10.getDefaultAutoRange();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.axis.AxisState var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     java.util.List var22 = var10.refreshTicks(var18, var19, var20, var21);
//     org.jfree.chart.plot.Plot var23 = var10.getPlot();
//     boolean var24 = var8.equals((java.lang.Object)var10);
//     java.awt.Paint var25 = var10.getAxisLinePaint();
//     double var26 = var10.getLabelAngle();
//     java.util.Date var27 = var10.getMinimumDate();
//     var3.addBaseTimelineException(var27);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("Other", var1);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.GradientPaintTransformer var3 = var2.getGradientPaintTransformer();
    java.awt.Font var4 = var2.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    var0.setItemMargin(3.0d);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D(var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var10);
    var10.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var14 = var10.getURLGenerator();
    java.awt.Shape var15 = var10.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var16 = null;
    var10.setLabelGenerator(var16);
    java.lang.Object var18 = var10.clone();
    boolean var19 = var7.equals((java.lang.Object)var10);
    org.jfree.chart.util.SortOrder var20 = var7.getRowRenderingOrder();
    java.lang.Object var21 = null;
    boolean var22 = var20.equals(var21);
    var3.setRowRenderingOrder(var20);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var25 = var24.clone();
    org.jfree.chart.urls.StandardCategoryURLGenerator var29 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "org.jfree.chart.event.ChartChangeEvent[source=true]", "");
    org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var32 = var30.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var33 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var34 = var33.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var33.getBaseItemLabelGenerator();
    java.awt.Paint var37 = null;
    var33.setSeriesFillPaint(1, var37, false);
    var33.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var43 = var33.getLegendItemLabelGenerator();
    var30.setLegendItemToolTipGenerator(var43);
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    java.lang.Object var46 = null;
    boolean var47 = var45.equals(var46);
    java.awt.Paint var48 = var45.getItemPaint();
    boolean var49 = var29.equals((java.lang.Object)var48);
    var24.setBasePaint(var48, true);
    var3.setDomainGridlinePaint(var48);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    java.awt.Color var55 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var56 = var55.getTransparency();
    int var57 = var55.getGreen();
    java.lang.String var58 = org.jfree.chart.util.PaintUtilities.colorToString(var55);
    var0.setArtifactPaint((java.awt.Paint)var55);
    boolean var60 = var0.getFillBox();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + "black"+ "'", var58.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelOffset();
    boolean var5 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.util.GradientPaintTransformType var6 = var0.getType();
    java.lang.String var7 = var6.toString();
    org.jfree.chart.util.StandardGradientPaintTransformer var8 = new org.jfree.chart.util.StandardGradientPaintTransformer(var6);
    org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var10 = var9.getPieChart();
    var10.setTitle("SerialDate.weekInMonthToString(): invalid code.");
    var10.setNotify(false);
    boolean var15 = var6.equals((java.lang.Object)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var7.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    double var8 = var4.getItemMargin();
    boolean var10 = var4.isSeriesVisibleInLegend(1);
    java.lang.Boolean var12 = var4.getSeriesCreateEntities(1);
    java.awt.Paint var14 = var4.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var17 = null;
    var15.setSeriesItemLabelFont(1, var17);
    boolean var19 = var15.getBaseSeriesVisibleInLegend();
    java.awt.Paint var22 = var15.getItemOutlinePaint(13, 100);
    var4.setBaseFillPaint(var22, true);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var29 = var28.getUpArrow();
    java.awt.Shape var30 = var28.getDownArrow();
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var4.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    java.awt.Shape var36 = var4.getItemShape(255, 2);
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var38.setRangeWithMargins((org.jfree.data.Range)var41, false, true);
    org.jfree.data.Range var45 = var38.getDefaultAutoRange();
    java.awt.Graphics2D var46 = null;
    org.jfree.chart.axis.AxisState var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    org.jfree.chart.util.RectangleEdge var49 = null;
    java.util.List var50 = var38.refreshTicks(var46, var47, var48, var49);
    java.awt.Font var51 = var38.getLabelFont();
    org.jfree.data.general.PieDataset var53 = null;
    org.jfree.chart.plot.PiePlot3D var54 = new org.jfree.chart.plot.PiePlot3D(var53);
    org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var54);
    var54.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var58 = var54.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var59 = null;
    var54.axisChanged(var59);
    org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var51, (org.jfree.chart.plot.Plot)var54, false);
    var62.setBackgroundImageAlignment(10);
    org.jfree.chart.plot.Plot var65 = var62.getPlot();
    java.awt.Paint var66 = var62.getBackgroundPaint();
    org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("hi!", "DateTickMarkPosition.START", "SortOrder.ASCENDING", "ERROR : Relative To String", var36, var66);
    java.awt.Shape var68 = var67.getLine();
    int var69 = var67.getDatasetIndex();
    org.jfree.data.general.Dataset var70 = var67.getDataset();
    int var71 = var67.getDatasetIndex();
    java.awt.Shape var72 = var67.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    org.jfree.chart.plot.DatasetRenderingOrder var3 = var0.getDatasetRenderingOrder();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation(0);
    int var6 = var0.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    var1.setLowerMargin((-0.9500000000000001d));
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    boolean var5 = var4.isAxisLineVisible();
    org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var8 = null;
    var6.setSeriesItemLabelFont(1, var8);
    boolean var10 = var6.getBaseSeriesVisibleInLegend();
    java.awt.Paint var13 = var6.getItemOutlinePaint(13, 100);
    java.awt.Shape var16 = var6.getItemShape((-1), 1);
    org.jfree.chart.entity.AxisLabelEntity var19 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var4, var16, "hi!", "Default Group");
    var1.setRightArrow(var16);
    org.jfree.chart.util.HorizontalAlignment var21 = null;
    org.jfree.chart.util.VerticalAlignment var22 = null;
    org.jfree.chart.block.FlowArrangement var25 = new org.jfree.chart.block.FlowArrangement(var21, var22, 100.0d, 0.0d);
    org.jfree.chart.util.HorizontalAlignment var26 = null;
    org.jfree.chart.util.VerticalAlignment var27 = null;
    org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var31 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var32 = null;
    var31.addChangeListener(var32);
    org.jfree.chart.title.LegendItemBlockContainer var35 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, (org.jfree.data.general.Dataset)var31, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    boolean var36 = var35.isEmpty();
    java.util.List var37 = var35.getBlocks();
    java.awt.Graphics2D var38 = null;
    org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var42 = var41.getLowerDate();
    org.jfree.data.Range var45 = org.jfree.data.Range.shift((org.jfree.data.Range)var41, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint(var45, 1.0d);
    org.jfree.chart.util.Size2D var48 = var25.arrange((org.jfree.chart.block.BlockContainer)var35, var38, var47);
    java.lang.String var49 = var48.toString();
    org.jfree.chart.axis.CategoryLabelPosition var52 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var53 = var52.getWidthRatio();
    double var54 = var52.getAngle();
    org.jfree.chart.util.RectangleAnchor var55 = var52.getCategoryAnchor();
    java.awt.geom.Rectangle2D var56 = org.jfree.chart.util.RectangleAnchor.createRectangle(var48, 4.0d, 90.0d, var55);
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, var55, 1.0d, 90.0d);
    java.lang.String var60 = var55.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var49.equals("Size2D[width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + "RectangleAnchor.CENTER"+ "'", var60.equals("RectangleAnchor.CENTER"));

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Shape var3 = var1.getDownArrow();
    java.util.Date var4 = var1.getMinimumDate();
    java.lang.String var5 = var1.getLabel();
    java.util.Date var6 = var1.getMinimumDate();
    var1.setLabelToolTip("org.jfree.chart.event.ChartChangeEvent[source=true]");
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var12 = var11.getLowerDate();
    org.jfree.data.Range var14 = org.jfree.data.Range.shift((org.jfree.data.Range)var11, (-1.0d));
    var1.setRangeWithMargins((org.jfree.data.Range)var11);
    float var16 = var1.getTickMarkInsideLength();
    java.awt.Shape var17 = var1.getLeftArrow();
    org.jfree.chart.axis.DateTickMarkPosition var18 = var1.getTickMarkPosition();
    var1.configure();
    java.text.DateFormat var20 = null;
    var1.setDateFormatOverride(var20);
    var1.setNegativeArrowVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getMaxIcon();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D(var5);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var6);
    var6.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var10 = var6.getURLGenerator();
    java.awt.Shape var11 = var6.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var12 = null;
    var6.setLabelGenerator(var12);
    java.lang.Object var14 = var6.clone();
    boolean var15 = var3.equals((java.lang.Object)var6);
    org.jfree.chart.util.SortOrder var16 = var3.getRowRenderingOrder();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", (org.jfree.chart.plot.Plot)var3);
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var20);
    var20.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var24 = var20.getURLGenerator();
    java.awt.Shape var25 = var20.getLegendItemShape();
    org.jfree.chart.util.Rotation var26 = var20.getDirection();
    java.awt.Paint var27 = var20.getBaseSectionOutlinePaint();
    var3.setRangeGridlinePaint(var27);
    var0.setGroupPaint(var27);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
    java.awt.Paint var35 = var32.getItemLabelPaint(255, 1);
    var0.setGroupPaint(var35);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var37 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.data.gantt.TaskSeriesCollection var38 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var39 = var38.getRowCount();
    org.jfree.data.Range var40 = var37.findRangeBounds((org.jfree.data.category.CategoryDataset)var38);
    org.jfree.data.Range var42 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var38, false);
    org.jfree.data.general.DatasetGroup var43 = var38.getGroup();
    org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var38);
    org.jfree.data.Range var45 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    var0.clearDomainAxes();
    var0.clearRangeAxes();
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    var0.setRenderer(var6, false);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
    java.awt.geom.Point2D var11 = var9.getQuadrantOrigin();
    var9.setDomainCrosshairValue(0.0d);
    var9.clearRangeMarkers(96);
    org.jfree.chart.axis.AxisLocation var16 = var9.getRangeAxisLocation();
    var0.setRangeAxisLocation(var16, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    double var6 = var2.getItemMargin();
    boolean var8 = var2.isSeriesVisibleInLegend(1);
    java.lang.Boolean var10 = var2.getSeriesCreateEntities(1);
    java.awt.Paint var12 = var2.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var15 = null;
    var13.setSeriesItemLabelFont(1, var15);
    boolean var17 = var13.getBaseSeriesVisibleInLegend();
    java.awt.Paint var20 = var13.getItemOutlinePaint(13, 100);
    var2.setBaseFillPaint(var20, true);
    var2.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var26 = var2.getBaseNegativeItemLabelPosition();
    boolean var27 = var1.equals((java.lang.Object)var26);
    java.awt.Font var30 = var1.getItemLabelFont(3, 13);
    org.jfree.chart.renderer.category.StackedAreaRenderer var32 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.StackedAreaRenderer var34 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Paint var36 = var34.lookupSeriesOutlinePaint(255);
    java.lang.Object var37 = var34.clone();
    int var38 = var34.getPassCount();
    org.jfree.chart.renderer.AreaRendererEndType var39 = var34.getEndType();
    var32.setEndType(var39);
    var1.setEndType(var39);
    java.lang.String var42 = var39.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "AreaRendererEndType.TAPER"+ "'", var42.equals("AreaRendererEndType.TAPER"));

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    double var6 = var2.getItemMargin();
    boolean var8 = var2.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var11 = var2.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var13.setRangeWithMargins((org.jfree.data.Range)var16, false, true);
    org.jfree.data.Range var20 = var13.getDefaultAutoRange();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.AxisState var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    java.util.List var25 = var13.refreshTicks(var21, var22, var23, var24);
    java.awt.Font var26 = var13.getLabelFont();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
    var29.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var33 = var29.getURLGenerator();
    java.awt.Shape var34 = var29.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var35 = null;
    var29.setLabelGenerator(var35);
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
    int var41 = var40.getBackgroundImageAlignment();
    var29.addChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
    org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var46 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var44.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var46);
    org.jfree.chart.renderer.category.IntervalBarRenderer var48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var50 = null;
    var48.setSeriesItemLabelFont(1, var50);
    boolean var52 = var48.getBaseSeriesVisibleInLegend();
    java.awt.Paint var55 = var48.getItemOutlinePaint(13, 100);
    var44.setBaseItemLabelPaint(var55);
    var29.setSectionPaint((java.lang.Comparable)(short)100, var55);
    org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("Default Group", var26, var55);
    java.awt.geom.Rectangle2D var59 = var58.getBounds();
    var2.setBaseShape((java.awt.Shape)var59, false);
    org.jfree.chart.plot.PlotRenderingInfo var63 = null;
    boolean var64 = var0.render(var1, var59, (-457), var63);
    org.jfree.chart.plot.CategoryMarker var66 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var66.setKey((java.lang.Comparable)1.0d);
    var66.setDrawAsLine(true);
    boolean var71 = var0.equals((java.lang.Object)true);
    boolean var72 = var0.getDrawSharedDomainAxis();
    boolean var73 = var0.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
    int var15 = var14.getBackgroundImageAlignment();
    var3.addChangeListener((org.jfree.chart.event.PlotChangeListener)var14);
    java.awt.Stroke var17 = var14.getBorderStroke();
    var0.setGroupStroke(var17);
    java.awt.Paint var19 = null;
    var0.setBasePaint(var19, true);
    javax.swing.Icon var22 = var0.getObjectIcon();
    org.jfree.chart.renderer.category.IntervalBarRenderer var28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var30 = null;
    var28.setSeriesItemLabelFont(1, var30);
    double var32 = var28.getItemMargin();
    boolean var34 = var28.isSeriesVisibleInLegend(1);
    java.lang.Boolean var36 = var28.getSeriesCreateEntities(1);
    java.awt.Paint var38 = var28.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var41 = null;
    var39.setSeriesItemLabelFont(1, var41);
    boolean var43 = var39.getBaseSeriesVisibleInLegend();
    java.awt.Paint var46 = var39.getItemOutlinePaint(13, 100);
    var28.setBaseFillPaint(var46, true);
    java.awt.Graphics2D var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = null;
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var53 = var52.getUpArrow();
    java.awt.Shape var54 = var52.getDownArrow();
    org.jfree.chart.plot.Marker var55 = null;
    java.awt.geom.Rectangle2D var56 = null;
    var28.drawRangeMarker(var49, var50, (org.jfree.chart.axis.ValueAxis)var52, var55, var56);
    java.awt.Shape var60 = var28.getItemShape(255, 2);
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var65 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var62.setRangeWithMargins((org.jfree.data.Range)var65, false, true);
    org.jfree.data.Range var69 = var62.getDefaultAutoRange();
    java.awt.Graphics2D var70 = null;
    org.jfree.chart.axis.AxisState var71 = null;
    java.awt.geom.Rectangle2D var72 = null;
    org.jfree.chart.util.RectangleEdge var73 = null;
    java.util.List var74 = var62.refreshTicks(var70, var71, var72, var73);
    java.awt.Font var75 = var62.getLabelFont();
    org.jfree.data.general.PieDataset var77 = null;
    org.jfree.chart.plot.PiePlot3D var78 = new org.jfree.chart.plot.PiePlot3D(var77);
    org.jfree.chart.JFreeChart var79 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var78);
    var78.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var82 = var78.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var83 = null;
    var78.axisChanged(var83);
    org.jfree.chart.JFreeChart var86 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var75, (org.jfree.chart.plot.Plot)var78, false);
    var86.setBackgroundImageAlignment(10);
    org.jfree.chart.plot.Plot var89 = var86.getPlot();
    java.awt.Paint var90 = var86.getBackgroundPaint();
    org.jfree.chart.LegendItem var91 = new org.jfree.chart.LegendItem("hi!", "DateTickMarkPosition.START", "SortOrder.ASCENDING", "ERROR : Relative To String", var60, var90);
    java.awt.Shape var92 = var91.getLine();
    java.awt.Stroke var93 = var91.getLineStroke();
    boolean var94 = var91.isLineVisible();
    java.awt.Paint var95 = var91.getOutlinePaint();
    var0.setSeriesOutlinePaint(85, var95, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
//     var3.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
//     java.awt.Shape var8 = var3.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
//     var3.setLabelGenerator(var9);
//     java.lang.Object var11 = var3.clone();
//     boolean var12 = var0.equals((java.lang.Object)var3);
//     var0.clearDomainMarkers(12);
//     org.jfree.chart.axis.CategoryAnchor var15 = var0.getDomainGridlinePosition();
//     org.jfree.chart.event.MarkerChangeEvent var16 = null;
//     var0.markerChanged(var16);
//     org.jfree.chart.axis.AxisSpace var18 = new org.jfree.chart.axis.AxisSpace();
//     double var19 = var18.getBottom();
//     var18.setRight(8.0d);
//     var0.setFixedDomainAxisSpace(var18);
//     java.lang.Object var23 = var18.clone();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.axis.AxisSpace var25 = new org.jfree.chart.axis.AxisSpace();
//     double var26 = var25.getBottom();
//     var25.setTop(0.0d);
//     double var29 = var25.getLeft();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var32 = null;
//     var30.setSeriesItemLabelFont(1, var32);
//     double var34 = var30.getItemMargin();
//     boolean var36 = var30.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var38 = var30.getSeriesCreateEntities(1);
//     var30.setBaseItemLabelsVisible(true, false);
//     int var42 = var30.getRowCount();
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var45 = var44.getFixedLegendItems();
//     java.awt.geom.Point2D var46 = var44.getQuadrantOrigin();
//     org.jfree.chart.util.RectangleInsets var47 = var44.getAxisOffset();
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = var44.getRendererForDataset(var48);
//     java.awt.Stroke var50 = var44.getRangeCrosshairStroke();
//     var30.setSeriesOutlineStroke(12, var50, true);
//     boolean var53 = var25.equals((java.lang.Object)var50);
//     org.jfree.chart.util.HorizontalAlignment var54 = null;
//     org.jfree.chart.util.VerticalAlignment var55 = null;
//     org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement(var54, var55, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var59 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var60 = null;
//     var59.addChangeListener(var60);
//     org.jfree.chart.title.LegendItemBlockContainer var63 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var58, (org.jfree.data.general.Dataset)var59, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.data.general.Dataset var64 = var63.getDataset();
//     org.jfree.chart.entity.EntityCollection var65 = null;
//     org.jfree.chart.ChartRenderingInfo var66 = new org.jfree.chart.ChartRenderingInfo(var65);
//     java.awt.geom.Rectangle2D var67 = var66.getChartArea();
//     var63.setBounds(var67);
//     java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var67, 0.0d, 0.8f, 0.95f);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var73 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var75 = var73.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var76 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var77 = var76.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var78 = var76.getBaseItemLabelGenerator();
//     java.awt.Paint var80 = null;
//     var76.setSeriesFillPaint(1, var80, false);
//     var76.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var86 = var76.getLegendItemLabelGenerator();
//     var73.setLegendItemToolTipGenerator(var86);
//     org.jfree.chart.title.LegendTitle var88 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var73);
//     java.awt.Graphics2D var89 = null;
//     org.jfree.chart.util.Size2D var90 = var88.arrange(var89);
//     org.jfree.chart.util.RectangleEdge var91 = var88.getPosition();
//     java.awt.geom.Rectangle2D var92 = var25.reserved(var67, var91);
//     java.awt.geom.Rectangle2D var93 = var18.shrink(var24, var92);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var3 = var2.getUpArrow();
    java.awt.Shape var4 = var2.getDownArrow();
    java.awt.Stroke var5 = var2.getTickMarkStroke();
    var0.setRangeCrosshairStroke(var5);
    var0.setRangeGridlinesVisible(false);
    boolean var9 = var0.isDomainZoomable();
    java.awt.Stroke var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainZeroBaselineStroke(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }
// 
// 
//     org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(false);
//     var1.clear();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var6 = var5.getUpArrow();
//     java.awt.Font var7 = var5.getLabelFont();
//     java.text.DateFormat var8 = var5.getDateFormatOverride();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var11);
//     var11.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var15 = var11.getURLGenerator();
//     java.awt.Shape var16 = var11.getLegendItemShape();
//     org.jfree.chart.util.Rotation var17 = var11.getDirection();
//     org.jfree.chart.util.RectangleInsets var18 = var11.getInsets();
//     var5.setLabelInsets(var18);
//     boolean var20 = var3.equals((java.lang.Object)var5);
//     long var21 = var3.getLastMillisecond();
//     var1.removeValue((java.lang.Comparable)var21, (java.lang.Comparable)90.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1420099199999L);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }


    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((-6.0d), (-9.0d), 1.5d, (-7.0d), var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    boolean var2 = var0.equals((java.lang.Object)(-1.0f));
    java.awt.Paint var4 = var0.getSeriesPaint(0);
    boolean var7 = var0.isItemLabelVisible(13, 1900);
    var0.setBaseSeriesVisible(false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var3 = var2.getUpArrow();
    java.awt.Shape var4 = var2.getDownArrow();
    java.awt.Stroke var5 = var2.getTickMarkStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getDomainMarkers(13, var8);
    boolean var10 = var0.isRangeZeroBaselineVisible();
    var0.setRangeCrosshairValue((-1.05d));
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
    java.awt.geom.Point2D var15 = var13.getQuadrantOrigin();
    org.jfree.chart.util.RectangleInsets var16 = var13.getAxisOffset();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var20);
    var20.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var24 = var20.getURLGenerator();
    java.awt.Shape var25 = var20.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var26 = null;
    var20.setLabelGenerator(var26);
    java.lang.Object var28 = var20.clone();
    boolean var29 = var17.equals((java.lang.Object)var20);
    org.jfree.chart.util.SortOrder var30 = var17.getRowRenderingOrder();
    var17.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.IntervalBarRenderer var33 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var35 = null;
    var33.setSeriesItemLabelFont(1, var35);
    double var37 = var33.getItemMargin();
    boolean var39 = var33.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var40 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var41 = null;
    var40.rendererChanged(var41);
    var33.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var40);
    org.jfree.data.general.Dataset var45 = null;
    org.jfree.data.general.DatasetChangeEvent var46 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var45);
    var40.datasetChanged(var46);
    var17.datasetChanged(var46);
    org.jfree.data.general.Dataset var49 = var46.getDataset();
    var13.datasetChanged(var46);
    java.awt.Stroke var51 = var13.getDomainCrosshairStroke();
    var0.setRangeZeroBaselineStroke(var51);
    boolean var53 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.util.RectangleInsets var54 = var0.getAxisOffset();
    org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    java.text.NumberFormat var57 = null;
    var56.setNumberFormatOverride(var57);
    var56.setAutoRangeStickyZero(true);
    int var61 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == (-1));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    double var15 = var0.getItemMargin();
    boolean var18 = var0.isItemLabelVisible((-1), 0);
    org.jfree.chart.renderer.category.IntervalBarRenderer var19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var20 = var19.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var19.getBaseItemLabelGenerator();
    java.awt.Paint var23 = null;
    var19.setSeriesFillPaint(1, var23, false);
    java.awt.Stroke var27 = null;
    var19.setSeriesStroke(0, var27);
    org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var32 = null;
    var30.setSeriesItemLabelFont(1, var32);
    org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var36 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var34.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var36);
    var30.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var36);
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var39 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var41 = null;
    org.jfree.chart.plot.PiePlot3D var42 = new org.jfree.chart.plot.PiePlot3D(var41);
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var42);
    var42.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var46 = var42.getURLGenerator();
    java.awt.Shape var47 = var42.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var48 = null;
    var42.setLabelGenerator(var48);
    org.jfree.data.general.PieDataset var51 = null;
    org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D(var51);
    org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var52);
    int var54 = var53.getBackgroundImageAlignment();
    var42.addChangeListener((org.jfree.chart.event.PlotChangeListener)var53);
    java.awt.Stroke var56 = var53.getBorderStroke();
    var39.setGroupStroke(var56);
    var30.setBaseStroke(var56);
    var19.setSeriesStroke(0, var56);
    var0.setBaseOutlineStroke(var56, true);
    java.awt.Paint var62 = var0.getBasePaint();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var4 = var3.getAlpha();
    java.awt.Paint var5 = var3.getPaint();
    var0.setAngleLabelPaint(var5);
    java.awt.Color var8 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    float[] var12 = new float[] { 1.0f, 10.0f, (-1.0f)};
    float[] var13 = var8.getRGBColorComponents(var12);
    boolean var14 = var0.equals((java.lang.Object)var8);
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
    var16.setAutoRange(true);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var22 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var19.setRangeWithMargins((org.jfree.data.Range)var22, false, true);
    org.jfree.data.Range var26 = var19.getDefaultAutoRange();
    var19.setAutoTickUnitSelection(false, false);
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var33 = var32.getLowerDate();
    org.jfree.data.Range var36 = org.jfree.data.Range.shift((org.jfree.data.Range)var32, 0.0d, false);
    boolean var39 = var32.intersects(10.0d, (-1.05d));
    double var40 = var32.getLowerBound();
    var19.setRangeWithMargins((org.jfree.data.Range)var32, false, true);
    var16.setDefaultAutoRange((org.jfree.data.Range)var32);
    org.jfree.data.Range var45 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var49 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var46.setRangeWithMargins((org.jfree.data.Range)var49, false, true);
    var46.setTickMarkOutsideLength(100.0f);
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var46);
    java.awt.Paint var56 = var0.getRadiusGridlinePaint();
    java.awt.Stroke var57 = var0.getRadiusGridlineStroke();
    java.awt.Paint var58 = var0.getRadiusGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("Default Group");
    java.lang.Comparable var2 = var1.getKey();
    java.beans.PropertyChangeListener var3 = null;
    var1.removePropertyChangeListener(var3);
    int var5 = var1.getItemCount();
    java.lang.String var6 = var1.getDescription();
    var1.fireSeriesChanged();
    java.lang.Comparable var8 = var1.getKey();
    var1.removeAll();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Default Group"+ "'", var2.equals("Default Group"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Default Group"+ "'", var8.equals("Default Group"));

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.chart.plot.CategoryMarker var3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var0);
//     org.jfree.data.time.RegularTimePeriod var4 = var0.next();
//     int var5 = var0.getYearValue();
//     java.util.Date var6 = var0.getEnd();
//     long var7 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24180L);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(4);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    org.jfree.data.Range var5 = org.jfree.data.Range.shift((org.jfree.data.Range)var2, (-1.05d), false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.data.time.TimePeriodFormatException: Default Group", var1, 0.65d, 0.8f, 1.0f);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.axis.ValueAxis var7 = var3.getRangeAxis();
//     var3.clearRangeMarkers(4);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
//     var13.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var17 = var13.getURLGenerator();
//     java.awt.Shape var18 = var13.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var19 = null;
//     var13.setLabelGenerator(var19);
//     java.lang.Object var21 = var13.clone();
//     boolean var22 = var10.equals((java.lang.Object)var13);
//     org.jfree.chart.util.SortOrder var23 = var10.getRowRenderingOrder();
//     java.lang.Object var24 = null;
//     boolean var25 = var23.equals(var24);
//     org.jfree.chart.plot.CategoryMarker var27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     var27.setKey((java.lang.Comparable)false);
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D(var31);
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var32);
//     java.awt.Shape var34 = var32.getLegendItemShape();
//     var27.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var32);
//     java.awt.Paint var36 = var32.getLabelShadowPaint();
//     boolean var37 = var23.equals((java.lang.Object)var32);
//     var3.setColumnRenderingOrder(var23);
//     org.jfree.chart.util.HorizontalAlignment var39 = null;
//     org.jfree.chart.util.VerticalAlignment var40 = null;
//     org.jfree.chart.block.FlowArrangement var43 = new org.jfree.chart.block.FlowArrangement(var39, var40, 100.0d, 0.0d);
//     org.jfree.chart.util.HorizontalAlignment var44 = null;
//     org.jfree.chart.util.VerticalAlignment var45 = null;
//     org.jfree.chart.block.ColumnArrangement var48 = new org.jfree.chart.block.ColumnArrangement(var44, var45, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var49 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var50 = null;
//     var49.addChangeListener(var50);
//     org.jfree.chart.title.LegendItemBlockContainer var53 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var48, (org.jfree.data.general.Dataset)var49, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     boolean var54 = var53.isEmpty();
//     java.util.List var55 = var53.getBlocks();
//     java.awt.Graphics2D var56 = null;
//     org.jfree.data.time.DateRange var59 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     java.util.Date var60 = var59.getLowerDate();
//     org.jfree.data.Range var63 = org.jfree.data.Range.shift((org.jfree.data.Range)var59, 0.0d, false);
//     org.jfree.chart.block.RectangleConstraint var65 = new org.jfree.chart.block.RectangleConstraint(var63, 1.0d);
//     org.jfree.chart.util.Size2D var66 = var43.arrange((org.jfree.chart.block.BlockContainer)var53, var56, var65);
//     java.lang.String var67 = var66.toString();
//     org.jfree.chart.axis.CategoryLabelPosition var70 = new org.jfree.chart.axis.CategoryLabelPosition();
//     float var71 = var70.getWidthRatio();
//     double var72 = var70.getAngle();
//     org.jfree.chart.util.RectangleAnchor var73 = var70.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var74 = org.jfree.chart.util.RectangleAnchor.createRectangle(var66, 4.0d, 90.0d, var73);
//     var1.drawDomainGridline(var2, var3, var74, 15.0d);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
    java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var13 = null;
    var11.setSeriesItemLabelFont(1, var13);
    boolean var15 = var11.getBaseSeriesVisibleInLegend();
    java.awt.Paint var18 = var11.getItemOutlinePaint(13, 100);
    var0.setBaseFillPaint(var18, true);
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var24);
    var24.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var28 = var24.getURLGenerator();
    java.awt.Shape var29 = var24.getLegendItemShape();
    java.awt.Paint var30 = var24.getLabelLinkPaint();
    var0.setSeriesFillPaint(10, var30, false);
    int var33 = var0.getColumnCount();
    org.jfree.chart.plot.CategoryMarker var35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var35.setKey((java.lang.Comparable)false);
    org.jfree.data.general.PieDataset var39 = null;
    org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D(var39);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var40);
    java.awt.Shape var42 = var40.getLegendItemShape();
    var35.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var40);
    java.awt.Paint var44 = var40.getLabelShadowPaint();
    java.awt.Color var47 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var48 = var47.getTransparency();
    int var49 = var47.getAlpha();
    int var50 = var47.getAlpha();
    var40.setSectionPaint((java.lang.Comparable)"Default Group", (java.awt.Paint)var47);
    int var52 = var47.getTransparency();
    var0.setBasePaint((java.awt.Paint)var47, true);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var55 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.renderer.category.StackedAreaRenderer var57 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var58 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var60 = null;
    var58.setSeriesItemLabelFont(1, var60);
    double var62 = var58.getItemMargin();
    boolean var64 = var58.isSeriesVisibleInLegend(1);
    java.lang.Boolean var66 = var58.getSeriesCreateEntities(1);
    java.awt.Paint var68 = var58.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var69 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var71 = null;
    var69.setSeriesItemLabelFont(1, var71);
    boolean var73 = var69.getBaseSeriesVisibleInLegend();
    java.awt.Paint var76 = var69.getItemOutlinePaint(13, 100);
    var58.setBaseFillPaint(var76, true);
    var58.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var82 = var58.getBaseNegativeItemLabelPosition();
    boolean var83 = var57.equals((java.lang.Object)var82);
    org.jfree.data.DefaultKeyedValues2D var84 = new org.jfree.data.DefaultKeyedValues2D();
    boolean var85 = var57.equals((java.lang.Object)var84);
    org.jfree.data.time.Year var86 = new org.jfree.data.time.Year();
    java.util.Date var87 = var86.getEnd();
    org.jfree.data.time.RegularTimePeriod var88 = var86.previous();
    int var89 = var84.getColumnIndex((java.lang.Comparable)var86);
    java.lang.Number var91 = var55.getQ3Value((java.lang.Comparable)var86, (java.lang.Comparable)"Nearest");
    java.lang.Comparable var92 = null;
    java.lang.Number var94 = var55.getQ1Value(var92, (java.lang.Comparable)2);
    org.jfree.data.Range var95 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var55);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var4 = var3.getAlpha();
    java.awt.Paint var5 = var3.getPaint();
    var0.setAngleLabelPaint(var5);
    java.awt.Paint var7 = var0.getAngleGridlinePaint();
    var0.setRadiusGridlinesVisible(false);
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.FlowArrangement var14 = new org.jfree.chart.block.FlowArrangement(var10, var11, 100.0d, 0.0d);
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var20 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var21 = null;
    var20.addChangeListener(var21);
    org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, (org.jfree.data.general.Dataset)var20, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    boolean var25 = var24.isEmpty();
    java.util.List var26 = var24.getBlocks();
    java.awt.Graphics2D var27 = null;
    org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var31 = var30.getLowerDate();
    org.jfree.data.Range var34 = org.jfree.data.Range.shift((org.jfree.data.Range)var30, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var36 = new org.jfree.chart.block.RectangleConstraint(var34, 1.0d);
    org.jfree.chart.util.Size2D var37 = var14.arrange((org.jfree.chart.block.BlockContainer)var24, var27, var36);
    org.jfree.chart.renderer.category.GanttRenderer var38 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.plot.CategoryMarker var40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var40.setKey((java.lang.Comparable)false);
    boolean var43 = var40.getDrawAsLine();
    boolean var44 = var38.equals((java.lang.Object)var40);
    double var45 = var38.getStartPercent();
    double var46 = var38.getEndPercent();
    org.jfree.chart.util.GradientPaintTransformer var47 = var38.getGradientPaintTransformer();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var48 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var49 = var48.getColumnCount();
    org.jfree.data.Range var50 = var38.findRangeBounds((org.jfree.data.category.CategoryDataset)var48);
    org.jfree.data.general.DatasetChangeEvent var51 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var14, (org.jfree.data.general.Dataset)var48);
    var0.datasetChanged(var51);
    java.awt.Paint var53 = var0.getAngleLabelPaint();
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var55 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var57 = var55.lookupSeriesShape((-1));
    var54.setUpArrow(var57);
    var54.setLabel("");
    java.util.TimeZone var61 = var54.getTimeZone();
    boolean var62 = var54.isInverted();
    var54.setVerticalTickLabels(false);
    org.jfree.data.general.PieDataset var66 = null;
    org.jfree.chart.plot.PiePlot3D var67 = new org.jfree.chart.plot.PiePlot3D(var66);
    org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var67);
    var67.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var71 = var67.getURLGenerator();
    java.awt.Shape var72 = var67.getLegendItemShape();
    org.jfree.chart.util.Rotation var73 = var67.getDirection();
    java.awt.Paint var74 = var67.getBaseSectionOutlinePaint();
    org.jfree.chart.urls.PieURLGenerator var75 = null;
    var67.setLegendLabelURLGenerator(var75);
    org.jfree.chart.labels.PieSectionLabelGenerator var77 = var67.getLabelGenerator();
    var54.setPlot((org.jfree.chart.plot.Plot)var67);
    org.jfree.data.Range var79 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.35d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.65d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    boolean var1 = var0.isAxisLineVisible();
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    boolean var6 = var2.getBaseSeriesVisibleInLegend();
    java.awt.Paint var9 = var2.getItemOutlinePaint(13, 100);
    java.awt.Shape var12 = var2.getItemShape((-1), 1);
    org.jfree.chart.entity.AxisLabelEntity var15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var12, "hi!", "Default Group");
    java.lang.String var16 = var15.getToolTipText();
    java.awt.Shape var17 = var15.getArea();
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var18 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    var18.setItemMargin(0.05d);
    boolean var21 = var15.equals((java.lang.Object)0.05d);
    java.lang.String var22 = var15.getToolTipText();
    java.lang.String var23 = var15.getToolTipText();
    java.lang.String var24 = var15.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "hi!"+ "'", var22.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "hi!"+ "'", var23.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "hi!"+ "'", var24.equals("hi!"));

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    org.jfree.chart.util.RectangleInsets var3 = var0.getAxisOffset();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = var0.getRendererForDataset(var4);
    java.awt.Stroke var6 = var0.getRangeCrosshairStroke();
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    double var2 = var1.getBase();
    var1.setRenderAsPercentages(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    boolean var3 = var0.containsDomainRange((-1L), 1L);
    var0.addException((-31507200000L));
    org.jfree.chart.axis.SegmentedTimeline var6 = var0.getBaseTimeline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var8 = null;
    var7.rendererChanged(var8);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var7);
    org.jfree.data.general.Dataset var12 = null;
    org.jfree.data.general.DatasetChangeEvent var13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var12);
    var7.datasetChanged(var13);
    java.lang.String var15 = var7.getPlotType();
    org.jfree.chart.renderer.WaferMapRenderer var16 = null;
    var7.setRenderer(var16);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    double var19 = var18.getCategoryMargin();
    var18.setMaximumCategoryLabelWidthRatio(1.0f);
    var18.addCategoryLabelToolTip((java.lang.Comparable)"RectangleEdge.TOP", "RectangleEdge.TOP");
    org.jfree.chart.event.RendererChangeEvent var25 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"RectangleEdge.TOP");
    var7.rendererChanged(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "WMAP_Plot"+ "'", var15.equals("WMAP_Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getRowCount();
    org.jfree.chart.renderer.category.GanttRenderer var2 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D(var4);
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var5);
    var5.setShadowYOffset(0.0d);
    org.jfree.chart.labels.PieToolTipGenerator var9 = null;
    var5.setToolTipGenerator(var9);
    java.awt.Paint var11 = var5.getBackgroundPaint();
    var2.setIncompletePaint(var11);
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(100);
    org.jfree.chart.renderer.category.LayeredBarRenderer var15 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder();
    boolean var17 = var15.equals((java.lang.Object)var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    double var20 = var19.getCategoryMargin();
    int var21 = var19.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAnchor var22 = null;
    org.jfree.chart.entity.EntityCollection var25 = null;
    org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo(var25);
    java.awt.geom.Rectangle2D var27 = var26.getChartArea();
    org.jfree.chart.renderer.category.IntervalBarRenderer var28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var30 = var28.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var32 = var31.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var33 = var31.getBaseItemLabelGenerator();
    java.awt.Paint var35 = null;
    var31.setSeriesFillPaint(1, var35, false);
    var31.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var41 = var31.getLegendItemLabelGenerator();
    var28.setLegendItemToolTipGenerator(var41);
    org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.util.Size2D var45 = var43.arrange(var44);
    org.jfree.chart.util.RectangleEdge var46 = var43.getPosition();
    boolean var47 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var46);
    double var48 = var19.getCategoryJava2DCoordinate(var22, 0, 10, var27, var46);
    var16.draw(var18, var27);
    boolean var50 = var14.equals((java.lang.Object)var18);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(2);
    boolean var53 = var14.isOnOrAfter(var52);
    int var54 = var14.toSerial();
    java.lang.String var55 = var14.toString();
    org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(15);
    java.lang.String var58 = var57.getDescription();
    java.lang.String var59 = var57.getDescription();
    boolean var60 = var14.isAfter(var57);
    java.util.Date var61 = var14.toDate();
    var0.addObject((java.lang.Object)var11, (java.lang.Comparable)var14, (java.lang.Comparable)1969);
    java.util.List var64 = var0.getRowKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "9-April-1900"+ "'", var55.equals("9-April-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    double var3 = var2.getCategoryMargin();
    var2.setMaximumCategoryLabelWidthRatio(1.0f);
    var2.configure();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D(var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var10);
    var10.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var14 = var10.getURLGenerator();
    java.awt.Shape var15 = var10.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var16 = null;
    var10.setLabelGenerator(var16);
    java.lang.Object var18 = var10.clone();
    boolean var19 = var7.equals((java.lang.Object)var10);
    org.jfree.chart.util.SortOrder var20 = var7.getRowRenderingOrder();
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D(var22);
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var23);
    var23.setShadowYOffset(0.0d);
    var23.setShadowYOffset(1.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var30 = var29.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var31 = var29.getBaseItemLabelGenerator();
    double var32 = var29.getBase();
    java.awt.Stroke var33 = var29.getBaseOutlineStroke();
    var23.setOutlineStroke(var33);
    var23.setShadowYOffset(10.0d);
    var7.setParent((org.jfree.chart.plot.Plot)var23);
    boolean var38 = var7.getDrawSharedDomainAxis();
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
    var39.setMaximumCategoryLabelLines((-435));
    var39.setMaximumCategoryLabelLines((-435));
    int var44 = var7.getDomainAxisIndex(var39);
    org.jfree.chart.plot.PlotOrientation var45 = var7.getOrientation();
    boolean var46 = var2.equals((java.lang.Object)var7);
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var49 = var48.getFixedLegendItems();
    var48.clearDomainAxes();
    double var51 = var48.getDomainCrosshairValue();
    org.jfree.chart.plot.IntervalMarker var55 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var56 = var55.getAlpha();
    org.jfree.chart.util.Layer var57 = null;
    var48.addRangeMarker(1, (org.jfree.chart.plot.Marker)var55, var57);
    org.jfree.chart.util.Layer var59 = null;
    var7.addRangeMarker(96, (org.jfree.chart.plot.Marker)var55, var59);
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var55);
    java.awt.Paint var62 = var55.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getMaxIcon();
    var0.setDrawLines(true);
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
    var7.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
    java.awt.Shape var12 = var7.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var13 = null;
    var7.setLabelGenerator(var13);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    int var19 = var18.getBackgroundImageAlignment();
    var7.addChangeListener((org.jfree.chart.event.PlotChangeListener)var18);
    java.awt.Stroke var21 = var18.getBorderStroke();
    var4.setGroupStroke(var21);
    javax.swing.Icon var23 = var4.getObjectIcon();
    java.awt.Paint var24 = var4.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var25 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var26 = var25.getMaxIcon();
    java.awt.Stroke var27 = var25.getGroupStroke();
    org.jfree.chart.renderer.category.LayeredBarRenderer var28 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.block.LineBorder var29 = new org.jfree.chart.block.LineBorder();
    boolean var30 = var28.equals((java.lang.Object)var29);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var36 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var33.setRangeWithMargins((org.jfree.data.Range)var36, false, true);
    org.jfree.data.Range var40 = var33.getDefaultAutoRange();
    java.awt.Graphics2D var41 = null;
    org.jfree.chart.axis.AxisState var42 = null;
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.chart.util.RectangleEdge var44 = null;
    java.util.List var45 = var33.refreshTicks(var41, var42, var43, var44);
    java.awt.Font var46 = var33.getLabelFont();
    org.jfree.data.general.PieDataset var48 = null;
    org.jfree.chart.plot.PiePlot3D var49 = new org.jfree.chart.plot.PiePlot3D(var48);
    org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var49);
    var49.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var53 = var49.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var54 = null;
    var49.axisChanged(var54);
    org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var46, (org.jfree.chart.plot.Plot)var49, false);
    var57.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var60 = var57.getTitle();
    java.awt.Graphics2D var61 = null;
    org.jfree.chart.entity.EntityCollection var62 = null;
    org.jfree.chart.ChartRenderingInfo var63 = new org.jfree.chart.ChartRenderingInfo(var62);
    java.awt.geom.Rectangle2D var64 = var63.getChartArea();
    var60.draw(var61, var64);
    var29.draw(var31, var64);
    java.awt.Stroke var67 = var29.getStroke();
    var25.setGroupStroke(var67);
    javax.swing.Icon var69 = var25.getObjectIcon();
    var4.setObjectIcon(var69);
    var0.setObjectIcon(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    java.awt.Paint var3 = var2.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("Monday");
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    org.jfree.chart.axis.NumberTickUnit var9 = new org.jfree.chart.axis.NumberTickUnit((-0.5d));
    var7.setTickUnit(var9);
    var5.setTickUnit(var9);
    var2.setTickUnit(var9);
    org.jfree.chart.axis.MarkerAxisBand var13 = var2.getMarkerBand();
    java.awt.Font var14 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.OUTSIDE12", var14);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var18);
    var18.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var22 = var18.getURLGenerator();
    java.awt.Shape var23 = var18.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var24 = null;
    var18.setLabelGenerator(var24);
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var28);
    int var30 = var29.getBackgroundImageAlignment();
    var18.addChangeListener((org.jfree.chart.event.PlotChangeListener)var29);
    java.awt.Stroke var32 = var29.getBorderStroke();
    var15.addChangeListener((org.jfree.chart.event.TitleChangeListener)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    java.lang.Object var11 = var3.clone();
    boolean var12 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.util.SortOrder var13 = var0.getRowRenderingOrder();
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    double var20 = var16.getItemMargin();
    boolean var22 = var16.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var24 = null;
    var23.rendererChanged(var24);
    var16.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var23);
    org.jfree.data.general.Dataset var28 = null;
    org.jfree.data.general.DatasetChangeEvent var29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var28);
    var23.datasetChanged(var29);
    var0.datasetChanged(var29);
    org.jfree.chart.axis.CategoryAxis var33 = var0.getDomainAxis(13);
    var0.setNoDataMessage("DateTickMarkPosition.START");
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.plot.CategoryMarker var39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var39.setKey((java.lang.Comparable)false);
    org.jfree.data.general.PieDataset var43 = null;
    org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D(var43);
    org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var44);
    java.awt.Shape var46 = var44.getLegendItemShape();
    var39.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var44);
    org.jfree.chart.util.RectangleInsets var48 = var39.getLabelOffset();
    java.awt.Font var49 = var39.getLabelFont();
    org.jfree.chart.util.Layer var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var39, var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.chart.plot.MultiplePiePlot var15 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var16 = var15.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var17.setRangeWithMargins((org.jfree.data.Range)var20, false, true);
    org.jfree.data.Range var24 = var17.getDefaultAutoRange();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.AxisState var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var17.refreshTicks(var25, var26, var27, var28);
    org.jfree.chart.plot.Plot var30 = var17.getPlot();
    boolean var31 = var15.equals((java.lang.Object)var17);
    java.awt.Paint var32 = var17.getAxisLinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var17, var33);
    org.jfree.chart.axis.AxisLocation var35 = var34.getRangeAxisLocation();
    int var36 = var34.getDatasetCount();
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var38 = var37.getFixedLegendItems();
    java.awt.geom.Point2D var39 = var37.getQuadrantOrigin();
    var37.setDomainCrosshairValue(0.0d);
    var37.setRangeCrosshairValue((-7.0d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var46 = var44.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var48 = var47.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var49 = var47.getBaseItemLabelGenerator();
    java.awt.Paint var51 = null;
    var47.setSeriesFillPaint(1, var51, false);
    var47.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var57 = var47.getLegendItemLabelGenerator();
    var44.setLegendItemToolTipGenerator(var57);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var44);
    java.lang.Object var60 = null;
    boolean var61 = var59.equals(var60);
    java.awt.Paint var62 = var59.getItemPaint();
    var37.setDomainGridlinePaint(var62);
    org.jfree.data.xy.XYDataset var65 = var37.getDataset(12);
    org.jfree.chart.plot.SeriesRenderingOrder var66 = var37.getSeriesRenderingOrder();
    var34.setSeriesRenderingOrder(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getCategoryMargin();
    var0.setMaximumCategoryLabelWidthRatio(1.0f);
    var0.configure();
    var0.setMaximumCategoryLabelLines(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var3, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var8 = var7.toString();
    org.jfree.chart.ui.Library[] var9 = var7.getLibraries();
    java.lang.String var10 = var7.toString();
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var14, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.util.List var19 = var18.getContributors();
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var18);
    java.lang.String var21 = var18.getCopyright();
    java.lang.String var22 = var18.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var8.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var10.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var21.equals("SerialDate.weekInMonthToString(): invalid code."));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "hi!"+ "'", var22.equals("hi!"));

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var3 = var2.getAlpha();
    java.awt.Paint var4 = var2.getPaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var5.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var7);
    org.jfree.chart.util.GradientPaintTransformer var9 = var5.getGradientPaintTransformer();
    var2.setGradientPaintTransformer(var9);
    org.jfree.chart.text.TextAnchor var11 = var2.getLabelTextAnchor();
    java.awt.Paint var12 = var2.getLabelPaint();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    double var14 = var13.getCategoryMargin();
    var13.setMaximumCategoryLabelWidthRatio(1.0f);
    var13.addCategoryLabelToolTip((java.lang.Comparable)"RectangleEdge.TOP", "RectangleEdge.TOP");
    org.jfree.chart.util.RectangleInsets var20 = var13.getTickLabelInsets();
    var2.setLabelOffset(var20);
    org.jfree.chart.util.GradientPaintTransformer var22 = var2.getGradientPaintTransformer();
    var2.setEndValue(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    var0.draw(var3, 0.0f, 10.0f, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.plot.CategoryMarker var2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var2.setKey((java.lang.Comparable)false);
    boolean var5 = var2.getDrawAsLine();
    boolean var6 = var0.equals((java.lang.Object)var2);
    java.awt.Paint var7 = var2.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    java.lang.Object var2 = null;
    int var3 = var1.indexOf(var2);
    org.jfree.chart.renderer.category.GanttRenderer var4 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var5 = var4.getCompletePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var8 = null;
    var6.setSeriesItemLabelFont(1, var8);
    boolean var10 = var6.getBaseSeriesVisibleInLegend();
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var12 = var11.getBaseShape();
    org.jfree.chart.labels.ItemLabelPosition var13 = null;
    var11.setNegativeItemLabelPositionFallback(var13);
    java.awt.Paint var15 = var11.getBaseItemLabelPaint();
    var6.setBaseItemLabelPaint(var15, false);
    var4.setCompletePaint(var15);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    double var20 = var19.getCategoryMargin();
    java.awt.Paint var21 = var19.getTickMarkPaint();
    var4.setIncompletePaint(var21);
    int var23 = var1.indexOf((java.lang.Object)var4);
    var4.setEndPercent((-0.9500000000000001d));
    var4.setAutoPopulateSeriesOutlinePaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1));

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    int var1 = var0.getPassCount();
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var2.setSeriesToolTipGenerator(1, var7);
    var2.setItemLabelAnchorOffset(0.0d);
    boolean var11 = var2.getBaseItemLabelsVisible();
    java.awt.Stroke var13 = var2.lookupSeriesOutlineStroke(255);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var15 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var2.setSeriesToolTipGenerator(13, (org.jfree.chart.labels.CategoryToolTipGenerator)var15);
    org.jfree.chart.axis.SegmentedTimeline var17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var18 = var15.equals((java.lang.Object)var17);
    java.text.NumberFormat var19 = var15.getNumberFormat();
    var0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator)var15, false);
    boolean var24 = var0.isItemLabelVisible(2014, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.renderer.category.StackedAreaRenderer var3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    double var8 = var4.getItemMargin();
    boolean var10 = var4.isSeriesVisibleInLegend(1);
    java.lang.Boolean var12 = var4.getSeriesCreateEntities(1);
    java.awt.Paint var14 = var4.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var17 = null;
    var15.setSeriesItemLabelFont(1, var17);
    boolean var19 = var15.getBaseSeriesVisibleInLegend();
    java.awt.Paint var22 = var15.getItemOutlinePaint(13, 100);
    var4.setBaseFillPaint(var22, true);
    var4.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var28 = var4.getBaseNegativeItemLabelPosition();
    boolean var29 = var3.equals((java.lang.Object)var28);
    org.jfree.data.DefaultKeyedValues2D var30 = new org.jfree.data.DefaultKeyedValues2D();
    boolean var31 = var3.equals((java.lang.Object)var30);
    org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
    java.util.Date var33 = var32.getEnd();
    org.jfree.data.time.RegularTimePeriod var34 = var32.previous();
    int var35 = var30.getColumnIndex((java.lang.Comparable)var32);
    java.lang.Number var36 = var0.getMinOutlier((java.lang.Comparable)(byte)10, (java.lang.Comparable)var32);
    org.jfree.data.Range var38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, (-7.0d));
    int var39 = var0.getColumnCount();
    java.lang.Number var42 = var0.getMedianValue((java.lang.Comparable)"rect", (java.lang.Comparable)255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    double var6 = var2.getItemMargin();
    boolean var8 = var2.isSeriesVisibleInLegend(1);
    java.lang.Boolean var10 = var2.getSeriesCreateEntities(1);
    java.awt.Paint var12 = var2.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var15 = null;
    var13.setSeriesItemLabelFont(1, var15);
    boolean var17 = var13.getBaseSeriesVisibleInLegend();
    java.awt.Paint var20 = var13.getItemOutlinePaint(13, 100);
    var2.setBaseFillPaint(var20, true);
    var2.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var26 = var2.getBaseNegativeItemLabelPosition();
    boolean var27 = var1.equals((java.lang.Object)var26);
    org.jfree.chart.urls.CategoryURLGenerator var29 = null;
    var1.setSeriesURLGenerator(0, var29, false);
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.PiePlot3D var35 = new org.jfree.chart.plot.PiePlot3D(var34);
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var35);
    var35.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var39 = var35.getURLGenerator();
    java.awt.Shape var40 = var35.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var41 = null;
    var35.setLabelGenerator(var41);
    java.lang.Object var43 = var35.clone();
    boolean var44 = var32.equals((java.lang.Object)var35);
    org.jfree.chart.util.SortOrder var45 = var32.getRowRenderingOrder();
    var32.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.GanttRenderer var48 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.plot.CategoryMarker var50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var50.setKey((java.lang.Comparable)false);
    boolean var53 = var50.getDrawAsLine();
    boolean var54 = var48.equals((java.lang.Object)var50);
    var32.addDomainMarker(var50);
    var1.setPlot(var32);
    org.jfree.chart.renderer.AreaRendererEndType var57 = var1.getEndType();
    var1.setRenderAsPercentages(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     double var6 = var2.getMaximumLabelWidth();
//     org.jfree.chart.util.Rotation var7 = var2.getDirection();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.data.time.TimePeriodFormatException: Default Group");
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     double var14 = var13.getCategoryMargin();
//     int var15 = var13.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.CategoryAnchor var16 = null;
//     org.jfree.chart.entity.EntityCollection var19 = null;
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo(var19);
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var22 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var24 = var22.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var26 = var25.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var27 = var25.getBaseItemLabelGenerator();
//     java.awt.Paint var29 = null;
//     var25.setSeriesFillPaint(1, var29, false);
//     var25.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var25.getLegendItemLabelGenerator();
//     var22.setLegendItemToolTipGenerator(var35);
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.util.Size2D var39 = var37.arrange(var38);
//     org.jfree.chart.util.RectangleEdge var40 = var37.getPosition();
//     boolean var41 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var40);
//     double var42 = var13.getCategoryJava2DCoordinate(var16, 0, 10, var21, var40);
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var11.valueToJava2D(10.0d, var21, var43);
//     org.jfree.chart.plot.IntervalMarker var47 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var48 = var47.getAlpha();
//     org.jfree.chart.util.RectangleAnchor var49 = var47.getLabelAnchor();
//     java.awt.geom.Point2D var50 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var49);
//     org.jfree.chart.plot.PlotState var51 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.entity.EntityCollection var52 = null;
//     org.jfree.chart.ChartRenderingInfo var53 = new org.jfree.chart.ChartRenderingInfo(var52);
//     java.awt.geom.Rectangle2D var54 = var53.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var55 = var53.getPlotInfo();
//     org.jfree.chart.renderer.category.CategoryItemRendererState var56 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var55);
//     java.awt.geom.Rectangle2D var57 = var55.getPlotArea();
//     var2.draw(var8, var9, var50, var51, var55);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.DrawingSupplier var4 = null;
    var0.setDrawingSupplier(var4);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation();
    var0.clearDomainAxes();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var12 = var11.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var11.getBaseItemLabelGenerator();
    java.awt.Paint var15 = null;
    var11.setSeriesFillPaint(1, var15, false);
    var11.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var21 = var11.getLegendItemLabelGenerator();
    double var22 = var11.getBase();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxis();
    boolean var28 = var23.getDrawSharedDomainAxis();
    boolean var29 = var11.equals((java.lang.Object)var23);
    org.jfree.chart.entity.EntityCollection var32 = null;
    org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
    java.awt.geom.Rectangle2D var34 = var33.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var35 = var33.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var36 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var35);
    org.jfree.chart.entity.EntityCollection var37 = var36.getEntityCollection();
    org.jfree.chart.plot.PlotRenderingInfo var38 = var36.getInfo();
    org.jfree.chart.plot.CategoryMarker var40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    org.jfree.chart.util.LengthAdjustmentType var41 = var40.getLabelOffsetType();
    java.lang.Object var42 = null;
    boolean var43 = var41.equals(var42);
    java.lang.String var44 = var41.toString();
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var46 = var45.getFixedLegendItems();
    java.awt.geom.Point2D var47 = var45.getQuadrantOrigin();
    boolean var48 = var41.equals((java.lang.Object)var47);
    var23.zoomRangeAxes(0.05d, 0.0d, var38, var47);
    var0.zoomRangeAxes((-6.0d), 0.0d, var10, var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "EXPAND"+ "'", var44.equals("EXPAND"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
    int var15 = var14.getBackgroundImageAlignment();
    var3.addChangeListener((org.jfree.chart.event.PlotChangeListener)var14);
    java.awt.Stroke var17 = var14.getBorderStroke();
    var0.setGroupStroke(var17);
    javax.swing.Icon var19 = var0.getObjectIcon();
    java.awt.Paint var20 = var0.getBaseOutlinePaint();
    java.awt.Paint var21 = var0.getGroupPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("Monday");
    org.jfree.chart.axis.NumberTickUnit var2 = var1.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    java.awt.Shape var22 = var17.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var23 = null;
    var17.setLabelGenerator(var23);
    org.jfree.data.general.PieDataset var26 = null;
    org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
    int var29 = var28.getBackgroundImageAlignment();
    var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
    org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var34);
    org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var38 = null;
    var36.setSeriesItemLabelFont(1, var38);
    boolean var40 = var36.getBaseSeriesVisibleInLegend();
    java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
    var32.setBaseItemLabelPaint(var43);
    var17.setSectionPaint((java.lang.Comparable)(short)100, var43);
    org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("Default Group", var14, var43);
    java.awt.geom.Rectangle2D var47 = var46.getBounds();
    org.jfree.chart.util.RectangleInsets var48 = var46.getPadding();
    var46.setWidth((-7.0d));
    var46.setToolTipText("Default Group");
    org.jfree.chart.renderer.category.GanttRenderer var53 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var54 = var53.getCompletePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var55 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var57 = null;
    var55.setSeriesItemLabelFont(1, var57);
    boolean var59 = var55.getBaseSeriesVisibleInLegend();
    org.jfree.chart.renderer.category.IntervalBarRenderer var60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var61 = var60.getBaseShape();
    org.jfree.chart.labels.ItemLabelPosition var62 = null;
    var60.setNegativeItemLabelPositionFallback(var62);
    java.awt.Paint var64 = var60.getBaseItemLabelPaint();
    var55.setBaseItemLabelPaint(var64, false);
    var53.setCompletePaint(var64);
    org.jfree.chart.axis.CategoryAxis var68 = new org.jfree.chart.axis.CategoryAxis();
    double var69 = var68.getCategoryMargin();
    java.awt.Paint var70 = var68.getTickMarkPaint();
    var53.setIncompletePaint(var70);
    java.awt.Font var74 = var53.getItemLabelFont(0, 1900);
    var46.setFont(var74);
    var46.setToolTipText("Range[-1.0,0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("Monday");
    double var2 = var1.getFixedAutoRange();
    org.jfree.data.Range var3 = var1.getRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 0.8f, 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-905168));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }


    org.jfree.chart.plot.IntervalMarker var4 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var5 = var4.getAlpha();
    java.awt.Paint var6 = var4.getPaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var7.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var9);
    org.jfree.chart.util.GradientPaintTransformer var11 = var7.getGradientPaintTransformer();
    var4.setGradientPaintTransformer(var11);
    org.jfree.chart.text.TextAnchor var13 = var4.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var16 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var17 = var16.getWidthRatio();
    org.jfree.chart.text.TextAnchor var18 = var16.getRotationAnchor();
    org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
    org.jfree.chart.axis.NumberTick var24 = new org.jfree.chart.axis.NumberTick((java.lang.Number)10.0d, "java.awt.Color[r=0,g=0,b=0]", var18, var22, 0.0d);
    org.jfree.chart.axis.NumberTick var26 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0f, "RectangleEdge.TOP", var13, var22, 0.0d);
    java.lang.String var27 = var26.getText();
    java.lang.String var28 = var26.getText();
    java.lang.Number var29 = var26.getNumber();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "RectangleEdge.TOP"+ "'", var27.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "RectangleEdge.TOP"+ "'", var28.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + 100.0f+ "'", var29.equals(100.0f));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("DateTickMarkPosition.START");

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }


    java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    var1.setMaximumCategoryLabelLines((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    boolean var8 = var4.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var4.getItemOutlinePaint(13, 100);
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 4, 0);
    boolean var16 = org.jfree.chart.util.PaintUtilities.equal(var11, (java.awt.Paint)var15);
    var1.setAxisLinePaint((java.awt.Paint)var15);
    java.awt.Paint[] var18 = new java.awt.Paint[] { var15};
    java.awt.Stroke[] var19 = null;
    org.jfree.chart.plot.CategoryMarker var21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var21.setKey((java.lang.Comparable)false);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D(var25);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var26);
    java.awt.Shape var28 = var26.getLegendItemShape();
    var21.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var26);
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var33 = var32.getUpArrow();
    java.awt.Shape var34 = var32.getDownArrow();
    java.awt.Stroke var35 = var32.getTickMarkStroke();
    var30.setRangeCrosshairStroke(var35);
    java.awt.geom.Point2D var37 = var30.getQuadrantOrigin();
    java.lang.String var38 = var30.getPlotType();
    java.awt.Stroke var39 = var30.getRangeZeroBaselineStroke();
    var21.setOutlineStroke(var39);
    java.awt.Stroke[] var41 = new java.awt.Stroke[] { var39};
    java.awt.Shape[] var42 = null;
    org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var18, var19, var41, var42);
    java.awt.Stroke var44 = var43.getNextOutlineStroke();
    java.awt.Paint var45 = var43.getNextPaint();
    java.awt.Stroke var46 = var43.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "XY Plot"+ "'", var38.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }
// 
// 
//     java.lang.String[] var3 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var5 = new java.lang.Comparable[] { "DateTickMarkPosition.START"};
//     java.lang.Number[][] var6 = null;
//     java.lang.Number[] var7 = null;
//     java.lang.Number[][] var8 = new java.lang.Number[][] { var7};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var6, var8);
//     java.lang.Number[][] var10 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var11 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var3, var5, var8, var10);
//     org.jfree.data.category.CategoryDataset var12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[-1.0,0.0]", "ERROR : Relative To String", var10);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    boolean var1 = var0.isAxisLineVisible();
    double var2 = var0.getLowerMargin();
    org.jfree.chart.axis.DateTickMarkPosition var3 = var0.getTickMarkPosition();
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "DateTickMarkPosition.START"+ "'", var4.equals("DateTickMarkPosition.START"));

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("Monday");
    var1.setTickLabelsVisible(false);
    org.jfree.chart.axis.NumberTickUnit var4 = var1.getTickUnit();
    java.lang.String var6 = var4.valueToString(12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "12"+ "'", var6.equals("12"));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    org.jfree.chart.renderer.category.GanttRenderer var1 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var2 = var1.getCompletePaint();
    var0.setPositiveBarPaint(var2);
    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var6 = var5.getTransparency();
    int var7 = var5.getGreen();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var5);
    java.awt.color.ColorSpace var9 = var5.getColorSpace();
    var0.setLastBarPaint((java.awt.Paint)var5);
    org.jfree.chart.plot.CategoryMarker var12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var12.setKey((java.lang.Comparable)false);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    java.awt.Shape var19 = var17.getLegendItemShape();
    var12.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var17);
    java.awt.Paint var21 = var17.getLabelShadowPaint();
    java.awt.Color var24 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var25 = var24.getTransparency();
    int var26 = var24.getAlpha();
    int var27 = var24.getAlpha();
    var17.setSectionPaint((java.lang.Comparable)"Default Group", (java.awt.Paint)var24);
    int var29 = var24.getTransparency();
    var0.setLastBarPaint((java.awt.Paint)var24);
    java.awt.Color var32 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var33 = var32.getTransparency();
    int var34 = var32.getGreen();
    java.awt.Color var35 = var32.brighter();
    var0.setLastBarPaint((java.awt.Paint)var32);
    java.awt.Paint var37 = var0.getFirstBarPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "black"+ "'", var8.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var3.setRangeWithMargins((org.jfree.data.Range)var6, false, true);
    org.jfree.data.Range var10 = var3.getDefaultAutoRange();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.AxisState var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    java.util.List var15 = var3.refreshTicks(var11, var12, var13, var14);
    java.awt.Font var16 = var3.getLabelFont();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    var19.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var19.axisChanged(var24);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var16, (org.jfree.chart.plot.Plot)var19, false);
    var27.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var30 = var27.getTitle();
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.entity.EntityCollection var32 = null;
    org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
    java.awt.geom.Rectangle2D var34 = var33.getChartArea();
    var30.draw(var31, var34);
    org.jfree.chart.ChartColor var39 = new org.jfree.chart.ChartColor(0, 4, 0);
    var30.setPaint((java.awt.Paint)var39);
    java.lang.String var41 = var39.toString();
    org.jfree.chart.title.LegendGraphic var42 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var39);
    java.awt.Shape var43 = var42.getLine();
    var42.setShapeVisible(false);
    boolean var46 = var42.isShapeOutlineVisible();
    org.jfree.chart.renderer.category.IntervalBarRenderer var47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var49 = var47.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var50 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var51 = var50.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var52 = var50.getBaseItemLabelGenerator();
    java.awt.Paint var54 = null;
    var50.setSeriesFillPaint(1, var54, false);
    var50.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var60 = var50.getLegendItemLabelGenerator();
    var47.setLegendItemToolTipGenerator(var60);
    org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47);
    java.awt.Graphics2D var63 = null;
    org.jfree.chart.util.Size2D var64 = var62.arrange(var63);
    org.jfree.chart.util.RectangleAnchor var65 = var62.getLegendItemGraphicAnchor();
    var42.setShapeLocation(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=4,b=0]"+ "'", var41.equals("org.jfree.chart.ChartColor[r=0,g=4,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.awt.Stroke var2 = var0.getStroke(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    boolean var10 = var9.isEmpty();
    org.jfree.data.general.Dataset var11 = var9.getDataset();
    org.jfree.data.general.Dataset var12 = var9.getDataset();
    org.jfree.chart.block.FlowArrangement var13 = new org.jfree.chart.block.FlowArrangement();
    var9.setArrangement((org.jfree.chart.block.Arrangement)var13);
    var9.setURLText("org.jfree.chart.ChartColor[r=0,g=4,b=0]");
    java.awt.Graphics2D var17 = null;
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var21 = var20.getLowerDate();
    org.jfree.data.Range var24 = org.jfree.data.Range.shift((org.jfree.data.Range)var20, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, 1.0d);
    org.jfree.chart.util.Size2D var29 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    org.jfree.chart.util.Size2D var30 = var26.calculateConstrainedSize(var29);
    org.jfree.data.Range var31 = var26.getWidthRange();
    double var32 = var26.getWidth();
    org.jfree.data.Range var33 = var26.getWidthRange();
    org.jfree.chart.util.Size2D var34 = var9.arrange(var17, var26);
    org.jfree.chart.util.Size2D var37 = new org.jfree.chart.util.Size2D(1.0d, 0.0d);
    org.jfree.chart.util.Size2D var38 = var26.calculateConstrainedSize(var37);
    org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var42 = var41.getLowerDate();
    org.jfree.data.Range var45 = org.jfree.data.Range.shift((org.jfree.data.Range)var41, 0.0d, false);
    boolean var48 = var41.intersects(10.0d, (-1.05d));
    double var49 = var41.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var50 = var26.toRangeWidth((org.jfree.data.Range)var41);
    double var51 = var41.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-0.5d));

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var2 = var1.getTransparency();
    java.awt.Color var3 = var1.brighter();
    java.awt.Color var4 = var3.darker();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    double var6 = var2.getItemMargin();
    boolean var8 = var2.isSeriesVisibleInLegend(1);
    java.lang.Boolean var10 = var2.getSeriesCreateEntities(1);
    java.awt.Paint var12 = var2.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var15 = null;
    var13.setSeriesItemLabelFont(1, var15);
    boolean var17 = var13.getBaseSeriesVisibleInLegend();
    java.awt.Paint var20 = var13.getItemOutlinePaint(13, 100);
    var2.setBaseFillPaint(var20, true);
    var2.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var26 = var2.getBaseNegativeItemLabelPosition();
    boolean var27 = var1.equals((java.lang.Object)var26);
    org.jfree.chart.urls.CategoryURLGenerator var29 = null;
    var1.setSeriesURLGenerator(0, var29, false);
    var1.setSeriesVisible(12, (java.lang.Boolean)false, false);
    org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var40 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var37.setRangeWithMargins((org.jfree.data.Range)var40, false, true);
    org.jfree.data.Range var44 = var37.getDefaultAutoRange();
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.axis.AxisState var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.util.RectangleEdge var48 = null;
    java.util.List var49 = var37.refreshTicks(var45, var46, var47, var48);
    java.awt.Font var50 = var37.getLabelFont();
    org.jfree.data.general.PieDataset var52 = null;
    org.jfree.chart.plot.PiePlot3D var53 = new org.jfree.chart.plot.PiePlot3D(var52);
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var53);
    var53.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var57 = var53.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var58 = null;
    var53.axisChanged(var58);
    org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var50, (org.jfree.chart.plot.Plot)var53, false);
    var61.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var64 = var61.getTitle();
    boolean var65 = var64.getExpandToFitSpace();
    java.lang.String var66 = var64.getToolTipText();
    boolean var67 = var1.equals((java.lang.Object)var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var3 = var2.getAlpha();
    java.awt.Paint var4 = var2.getPaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var5.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var7);
    org.jfree.chart.util.GradientPaintTransformer var9 = var5.getGradientPaintTransformer();
    var2.setGradientPaintTransformer(var9);
    org.jfree.chart.text.TextAnchor var11 = var2.getLabelTextAnchor();
    var2.setLabel("Default Group");
    var2.setEndValue((-1.05d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var18 = var17.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var17.getBaseItemLabelGenerator();
    java.awt.Paint var21 = null;
    var17.setSeriesFillPaint(1, var21, false);
    var17.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var28 = var17.getSeriesPositiveItemLabelPosition(100);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var33 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var30.setRangeWithMargins((org.jfree.data.Range)var33, false, true);
    org.jfree.data.Range var37 = var30.getDefaultAutoRange();
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.axis.AxisState var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    org.jfree.chart.util.RectangleEdge var41 = null;
    java.util.List var42 = var30.refreshTicks(var38, var39, var40, var41);
    java.awt.Font var43 = var30.getLabelFont();
    org.jfree.data.general.PieDataset var45 = null;
    org.jfree.chart.plot.PiePlot3D var46 = new org.jfree.chart.plot.PiePlot3D(var45);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var46);
    var46.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var50 = var46.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var51 = null;
    var46.axisChanged(var51);
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var43, (org.jfree.chart.plot.Plot)var46, false);
    boolean var55 = var28.equals((java.lang.Object)var43);
    java.awt.Color var57 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    float[] var61 = new float[] { 1.0f, 10.0f, (-1.0f)};
    float[] var62 = var57.getRGBColorComponents(var61);
    org.jfree.chart.text.TextMeasurer var65 = null;
    org.jfree.chart.text.TextBlock var66 = org.jfree.chart.text.TextUtilities.createTextBlock("", var43, (java.awt.Paint)var57, 0.0f, 10, var65);
    java.util.List var67 = var66.getLines();
    org.jfree.chart.text.TextLine var69 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
    var66.addLine(var69);
    boolean var71 = var2.equals((java.lang.Object)var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var1 = var0.clone();
    var0.setDrawOutlines(true);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var5 = var4.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getBaseItemLabelGenerator();
    java.awt.Paint var8 = null;
    var4.setSeriesFillPaint(1, var8, false);
    var4.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var4.getSeriesPositiveItemLabelPosition(100);
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var17.setRangeWithMargins((org.jfree.data.Range)var20, false, true);
    org.jfree.data.Range var24 = var17.getDefaultAutoRange();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.AxisState var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var17.refreshTicks(var25, var26, var27, var28);
    java.awt.Font var30 = var17.getLabelFont();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D(var32);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var33);
    var33.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var37 = var33.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var38 = null;
    var33.axisChanged(var38);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var30, (org.jfree.chart.plot.Plot)var33, false);
    boolean var42 = var15.equals((java.lang.Object)var30);
    var0.setBaseItemLabelFont(var30);
    org.jfree.chart.plot.CategoryPlot var44 = var0.getPlot();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var45 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var50 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var47.setRangeWithMargins((org.jfree.data.Range)var50, false, true);
    var47.setTickMarkOutsideLength(100.0f);
    double var56 = var47.getLowerBound();
    java.awt.Color var58 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var59 = var58.getTransparency();
    int var60 = var58.getGreen();
    java.lang.String var61 = org.jfree.chart.util.PaintUtilities.colorToString(var58);
    java.awt.color.ColorSpace var62 = var58.getColorSpace();
    var47.setAxisLinePaint((java.awt.Paint)var58);
    var0.setSeriesItemLabelPaint(85, (java.awt.Paint)var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == (-1.05d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "black"+ "'", var61.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var3 = null;
    var1.setSeriesItemLabelFont(1, var3);
    double var5 = var1.getItemMargin();
    boolean var7 = var1.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var8 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.rendererChanged(var9);
    var1.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var8);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var13.setRangeWithMargins((org.jfree.data.Range)var16, false, true);
    org.jfree.data.Range var20 = var13.getDefaultAutoRange();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.AxisState var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    java.util.List var25 = var13.refreshTicks(var21, var22, var23, var24);
    java.awt.Font var26 = var13.getLabelFont();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
    var29.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var33 = var29.getURLGenerator();
    java.awt.Shape var34 = var29.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var35 = null;
    var29.setLabelGenerator(var35);
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
    int var41 = var40.getBackgroundImageAlignment();
    var29.addChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
    org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var46 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var44.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var46);
    org.jfree.chart.renderer.category.IntervalBarRenderer var48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var50 = null;
    var48.setSeriesItemLabelFont(1, var50);
    boolean var52 = var48.getBaseSeriesVisibleInLegend();
    java.awt.Paint var55 = var48.getItemOutlinePaint(13, 100);
    var44.setBaseItemLabelPaint(var55);
    var29.setSectionPaint((java.lang.Comparable)(short)100, var55);
    org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("Default Group", var26, var55);
    java.awt.geom.Rectangle2D var59 = var58.getBounds();
    org.jfree.chart.util.RectangleInsets var60 = var58.getPadding();
    var8.setInsets(var60);
    double var62 = var60.getBottom();
    var0.setInsets(var60);
    java.awt.Paint var64 = var0.getRangeGridlinePaint();
    org.jfree.chart.axis.AxisSpace var65 = var0.getFixedRangeAxisSpace();
    float var66 = var0.getBackgroundAlpha();
    var0.setDomainGridlinesVisible(false);
    boolean var69 = var0.isRangeGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var3, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var8 = var7.toString();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var12, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var17 = var16.toString();
    org.jfree.chart.ui.Library[] var18 = var16.getLibraries();
    var7.addLibrary((org.jfree.chart.ui.Library)var16);
    var7.setLicenceText("");
    java.awt.Image var25 = null;
    org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var25, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var30 = var29.toString();
    java.awt.Image var34 = null;
    org.jfree.chart.ui.ProjectInfo var38 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var34, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var39 = var38.toString();
    org.jfree.chart.ui.Library[] var40 = var38.getLibraries();
    var29.addLibrary((org.jfree.chart.ui.Library)var38);
    var29.setLicenceText("");
    var7.addLibrary((org.jfree.chart.ui.Library)var29);
    org.jfree.chart.ui.Library[] var45 = var7.getLibraries();
    org.jfree.data.general.PieDataset var47 = null;
    org.jfree.chart.plot.PiePlot3D var48 = new org.jfree.chart.plot.PiePlot3D(var47);
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var48);
    int var50 = var49.getBackgroundImageAlignment();
    java.awt.Image var51 = var49.getBackgroundImage();
    boolean var52 = var49.isBorderVisible();
    org.jfree.chart.event.ChartProgressEvent var55 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var7, var49, 0, 15);
    java.lang.Object var56 = var55.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var8.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var17.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var30.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var39.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.data.general.Dataset var10 = var9.getDataset();
    org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var12 = var11.getDataExtractOrder();
    boolean var13 = var9.equals((java.lang.Object)var12);
    java.lang.String var14 = var9.getURLText();
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var17 = var15.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var19 = var18.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var20 = var18.getBaseItemLabelGenerator();
    java.awt.Paint var22 = null;
    var18.setSeriesFillPaint(1, var22, false);
    var18.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var28 = var18.getLegendItemLabelGenerator();
    var15.setLegendItemToolTipGenerator(var28);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    java.lang.Object var31 = null;
    boolean var32 = var30.equals(var31);
    java.awt.Paint var33 = var30.getItemPaint();
    org.jfree.chart.util.RectangleInsets var34 = var30.getPadding();
    double var36 = var34.calculateTopOutset(0.2d);
    var9.setPadding(var34);
    java.lang.String var38 = var9.getURLText();
    org.jfree.data.general.Dataset var39 = var9.getDataset();
    org.jfree.chart.block.Arrangement var40 = var9.getArrangement();
    org.jfree.data.general.Dataset var41 = var9.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var2 = var1.getUpArrow();
//     java.awt.Font var3 = var1.getLabelFont();
//     java.text.DateFormat var4 = var1.getDateFormatOverride();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
//     var7.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
//     java.awt.Shape var12 = var7.getLegendItemShape();
//     org.jfree.chart.util.Rotation var13 = var7.getDirection();
//     org.jfree.chart.util.RectangleInsets var14 = var7.getInsets();
//     var1.setLabelInsets(var14);
//     org.jfree.data.time.DateRange var18 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     java.util.Date var19 = var18.getLowerDate();
//     java.util.Date var20 = var18.getUpperDate();
//     double var21 = var18.getLowerBound();
//     var1.setDefaultAutoRange((org.jfree.data.Range)var18);
//     java.text.DateFormat var23 = null;
//     var1.setDateFormatOverride(var23);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var26 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var27 = var26.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var28 = var26.getBaseItemLabelGenerator();
//     java.awt.Paint var30 = null;
//     var26.setSeriesFillPaint(1, var30, false);
//     var26.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var26.getSeriesPositiveItemLabelPosition(100);
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var42 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var39.setRangeWithMargins((org.jfree.data.Range)var42, false, true);
//     org.jfree.data.Range var46 = var39.getDefaultAutoRange();
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.AxisState var48 = null;
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     java.util.List var51 = var39.refreshTicks(var47, var48, var49, var50);
//     java.awt.Font var52 = var39.getLabelFont();
//     org.jfree.data.general.PieDataset var54 = null;
//     org.jfree.chart.plot.PiePlot3D var55 = new org.jfree.chart.plot.PiePlot3D(var54);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var55);
//     var55.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var59 = var55.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var60 = null;
//     var55.axisChanged(var60);
//     org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var52, (org.jfree.chart.plot.Plot)var55, false);
//     boolean var64 = var37.equals((java.lang.Object)var52);
//     java.awt.Color var66 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var70 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var71 = var66.getRGBColorComponents(var70);
//     org.jfree.chart.text.TextMeasurer var74 = null;
//     org.jfree.chart.text.TextBlock var75 = org.jfree.chart.text.TextUtilities.createTextBlock("", var52, (java.awt.Paint)var66, 0.0f, 10, var74);
//     java.awt.Color var80 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var84 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var85 = var80.getRGBColorComponents(var84);
//     float[] var86 = java.awt.Color.RGBtoHSB(0, 2, (-457), var84);
//     boolean var87 = var75.equals((java.lang.Object)var86);
//     org.jfree.chart.util.HorizontalAlignment var88 = var75.getLineAlignment();
//     java.awt.Graphics2D var89 = null;
//     org.jfree.chart.text.TextBlockAnchor var92 = null;
//     java.awt.Shape var96 = var75.calculateBounds(var89, 0.0f, 0.0f, var92, 10.0f, 0.95f, 3.0d);
//     org.jfree.chart.entity.AxisLabelEntity var99 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var96, "VerticalAlignment.CENTER", "RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
//     
//     // Checks the contract:  equals-hashcode on var7 and var55
//     assertTrue("Contract failed: equals-hashcode on var7 and var55", var7.equals(var55) ? var7.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var7
//     assertTrue("Contract failed: equals-hashcode on var55 and var7", var55.equals(var7) ? var55.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var56
//     assertTrue("Contract failed: equals-hashcode on var8 and var56", var8.equals(var56) ? var8.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var8
//     assertTrue("Contract failed: equals-hashcode on var56 and var8", var56.equals(var8) ? var56.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.data.general.Dataset var10 = var9.getDataset();
    java.lang.Comparable var11 = var9.getSeriesKey();
    java.lang.Comparable var12 = var9.getSeriesKey();
    java.lang.Object var13 = null;
    boolean var14 = var9.equals(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var11.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var12.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    double var8 = var4.getItemMargin();
    boolean var10 = var4.isSeriesVisibleInLegend(1);
    java.lang.Boolean var12 = var4.getSeriesCreateEntities(1);
    java.awt.Paint var14 = var4.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var17 = null;
    var15.setSeriesItemLabelFont(1, var17);
    boolean var19 = var15.getBaseSeriesVisibleInLegend();
    java.awt.Paint var22 = var15.getItemOutlinePaint(13, 100);
    var4.setBaseFillPaint(var22, true);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var29 = var28.getUpArrow();
    java.awt.Shape var30 = var28.getDownArrow();
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var4.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    java.awt.Shape var36 = var4.getItemShape(255, 2);
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var38.setRangeWithMargins((org.jfree.data.Range)var41, false, true);
    org.jfree.data.Range var45 = var38.getDefaultAutoRange();
    java.awt.Graphics2D var46 = null;
    org.jfree.chart.axis.AxisState var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    org.jfree.chart.util.RectangleEdge var49 = null;
    java.util.List var50 = var38.refreshTicks(var46, var47, var48, var49);
    java.awt.Font var51 = var38.getLabelFont();
    org.jfree.data.general.PieDataset var53 = null;
    org.jfree.chart.plot.PiePlot3D var54 = new org.jfree.chart.plot.PiePlot3D(var53);
    org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var54);
    var54.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var58 = var54.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var59 = null;
    var54.axisChanged(var59);
    org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var51, (org.jfree.chart.plot.Plot)var54, false);
    var62.setBackgroundImageAlignment(10);
    org.jfree.chart.plot.Plot var65 = var62.getPlot();
    java.awt.Paint var66 = var62.getBackgroundPaint();
    org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("hi!", "DateTickMarkPosition.START", "SortOrder.ASCENDING", "ERROR : Relative To String", var36, var66);
    boolean var69 = var67.equals((java.lang.Object)"Multiple Pie Plot");
    java.text.AttributedString var70 = var67.getAttributedLabel();
    java.lang.String var71 = var67.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var71 + "' != '" + "DateTickMarkPosition.START"+ "'", var71.equals("DateTickMarkPosition.START"));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(96, 1, (-10289251));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    var0.clearRangeAxes();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var0.getDomainMarkers(1969, var6);
    var0.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Shape var3 = var1.getDownArrow();
    java.util.Date var4 = var1.getMinimumDate();
    java.awt.Paint var5 = var1.getLabelPaint();
    var1.setAutoRangeMinimumSize(10.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    java.awt.Paint var18 = var15.getItemPaint();
    org.jfree.chart.util.HorizontalAlignment var19 = var15.getHorizontalAlignment();
    org.jfree.chart.util.RectangleEdge var20 = var15.getLegendItemGraphicEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.setMax(100.0d);
    var0.cursorDown(0.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var8 = var6.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var10 = var9.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var9.getBaseItemLabelGenerator();
    java.awt.Paint var13 = null;
    var9.setSeriesFillPaint(1, var13, false);
    var9.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var9.getLegendItemLabelGenerator();
    var6.setLegendItemToolTipGenerator(var19);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.util.Size2D var23 = var21.arrange(var22);
    org.jfree.chart.util.RectangleEdge var24 = var21.getPosition();
    var0.moveCursor(100.0d, var24);
    org.jfree.data.DefaultKeyedValues2D var26 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var27 = var26.getColumnKeys();
    var0.setTicks(var27);
    var0.cursorDown(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.data.time.TimePeriodFormatException: Default Group");
    org.jfree.chart.axis.MarkerAxisBand var3 = var2.getMarkerBand();
    boolean var4 = var0.equals((java.lang.Object)var2);
    java.awt.Paint var5 = var0.getWallPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test132"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("Monday");
//     org.jfree.chart.axis.CategoryAnchor var2 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.axis.AxisSpace var6 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     double var9 = var8.getCategoryMargin();
//     int var10 = var8.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.CategoryAnchor var11 = null;
//     org.jfree.chart.entity.EntityCollection var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo(var14);
//     java.awt.geom.Rectangle2D var16 = var15.getChartArea();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var19 = var17.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var21 = var20.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var20.getBaseItemLabelGenerator();
//     java.awt.Paint var24 = null;
//     var20.setSeriesFillPaint(1, var24, false);
//     var20.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var20.getLegendItemLabelGenerator();
//     var17.setLegendItemToolTipGenerator(var30);
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.util.Size2D var34 = var32.arrange(var33);
//     org.jfree.chart.util.RectangleEdge var35 = var32.getPosition();
//     boolean var36 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var35);
//     double var37 = var8.getCategoryJava2DCoordinate(var11, 0, 10, var16, var35);
//     org.jfree.data.time.DateRange var40 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     java.util.Date var41 = var40.getLowerDate();
//     java.util.Date var42 = var40.getUpperDate();
//     double var43 = var40.getLowerBound();
//     boolean var44 = var35.equals((java.lang.Object)var40);
//     var6.add(0.0d, var35);
//     double var46 = var1.getCategoryJava2DCoordinate(var2, 96, 30, var5, var35);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test133"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.95f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 7.0d, 0.5f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test134"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesLinesVisible(15, (java.lang.Boolean)true);
    org.jfree.chart.LegendItem var6 = var0.getLegendItem(13, 15);
    boolean var7 = var0.getBaseLinesVisible();
    int var8 = var0.getPassCount();
    var0.setDrawOutlines(false);
    var0.setSeriesShapesVisible(2, (java.lang.Boolean)false);
    org.jfree.chart.renderer.category.GanttRenderer var14 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var15 = var14.getCompletePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    double var20 = var16.getItemMargin();
    boolean var22 = var16.isSeriesVisibleInLegend(1);
    java.lang.Boolean var24 = var16.getSeriesCreateEntities(1);
    java.awt.Paint var26 = var16.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var27 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var29 = null;
    var27.setSeriesItemLabelFont(1, var29);
    boolean var31 = var27.getBaseSeriesVisibleInLegend();
    java.awt.Paint var34 = var27.getItemOutlinePaint(13, 100);
    var16.setBaseFillPaint(var34, true);
    var16.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var40 = var16.getBaseNegativeItemLabelPosition();
    int var41 = var16.getColumnCount();
    org.jfree.chart.labels.ItemLabelPosition var44 = var16.getPositiveItemLabelPosition(96, 15);
    var14.setBasePositiveItemLabelPosition(var44);
    var0.setBaseNegativeItemLabelPosition(var44, true);
    java.awt.Paint var50 = var0.getItemFillPaint((-1), 15);
    var0.setSeriesShapesVisible(85, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test135"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var17.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var19);
    org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var23 = null;
    var21.setSeriesItemLabelFont(1, var23);
    boolean var25 = var21.getBaseSeriesVisibleInLegend();
    java.awt.Paint var28 = var21.getItemOutlinePaint(13, 100);
    var17.setBaseItemLabelPaint(var28);
    var2.setSectionPaint((java.lang.Comparable)(short)100, var28);
    var2.setLabelLinksVisible(true);
    java.awt.Color var34 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var35 = var34.getTransparency();
    int var36 = var34.getAlpha();
    int var37 = var34.getAlpha();
    var2.setBaseSectionOutlinePaint((java.awt.Paint)var34);
    java.awt.Color var39 = var34.brighter();
    java.awt.color.ColorSpace var40 = var34.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test136"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("14-January-1900", var1, var2);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test137"); }


    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var4 = var3.getLowerDate();
    org.jfree.data.Range var7 = org.jfree.data.Range.shift((org.jfree.data.Range)var3, 0.0d, false);
    java.util.Date var8 = var3.getUpperDate();
    double var9 = var3.getCentralValue();
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(26.0d, (org.jfree.data.Range)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.5d));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test138"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var2);
    var3.setURLText("12/31/69");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test139"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
    org.jfree.chart.axis.CategoryLabelPosition var3 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var4 = var3.getWidthRatio();
    org.jfree.chart.text.TextAnchor var5 = var3.getRotationAnchor();
    var2.setLabelTextAnchor(var5);
    org.jfree.chart.util.RectangleAnchor var7 = var2.getLabelAnchor();
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var9 = var8.getFixedLegendItems();
    java.awt.geom.Point2D var10 = var8.getQuadrantOrigin();
    org.jfree.chart.axis.ValueAxis var11 = null;
    var8.setRangeAxis(var11);
    org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker((-1.05d));
    java.awt.Paint var15 = var14.getLabelPaint();
    var8.setRangeTickBandPaint(var15);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.DrawingSupplier var22 = null;
    var18.setDrawingSupplier(var22);
    org.jfree.chart.axis.AxisLocation var24 = var18.getRangeAxisLocation();
    var8.setDomainAxisLocation(255, var24);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
    double var32 = var31.getCategoryMargin();
    var31.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var36 = var31.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var37 = var27.getCategoriesForAxis(var31);
    org.jfree.chart.util.RectangleEdge var38 = var27.getRangeAxisEdge();
    boolean var39 = var27.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var41 = var27.getRangeAxisLocation(4);
    var8.setRangeAxisLocation(2, var41, false);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var8);
    org.jfree.chart.plot.MultiplePiePlot var45 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var46 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var47 = null;
    var46.addChangeListener(var47);
    var45.setDataset((org.jfree.data.category.CategoryDataset)var46);
    org.jfree.data.general.PieDataset var51 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var46, (java.lang.Comparable)'4');
    org.jfree.chart.plot.PiePlot var52 = new org.jfree.chart.plot.PiePlot(var51);
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test140"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var3 = var2.getUpArrow();
    java.awt.Shape var4 = var2.getDownArrow();
    java.awt.Stroke var5 = var2.getTickMarkStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = var0.getRendererForDataset(var8);
    var0.mapDatasetToRangeAxis(2, 96);
    var0.setWeight(255);
    var0.setDomainCrosshairValue(100.0d);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var20);
    var20.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var24 = var20.getURLGenerator();
    java.awt.Shape var25 = var20.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var26 = null;
    var20.setLabelGenerator(var26);
    java.lang.Object var28 = var20.clone();
    boolean var29 = var17.equals((java.lang.Object)var20);
    org.jfree.chart.util.SortOrder var30 = var17.getRowRenderingOrder();
    var17.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.GanttRenderer var33 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.plot.CategoryMarker var35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var35.setKey((java.lang.Comparable)false);
    boolean var38 = var35.getDrawAsLine();
    boolean var39 = var33.equals((java.lang.Object)var35);
    var17.addDomainMarker(var35);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
    double var42 = var41.getCategoryMargin();
    var41.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var46 = var41.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    org.jfree.data.general.SeriesChangeEvent var47 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var41);
    int var48 = var17.getDomainAxisIndex(var41);
    org.jfree.chart.axis.AxisSpace var49 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
    double var52 = var51.getCategoryMargin();
    int var53 = var51.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAnchor var54 = null;
    org.jfree.chart.entity.EntityCollection var57 = null;
    org.jfree.chart.ChartRenderingInfo var58 = new org.jfree.chart.ChartRenderingInfo(var57);
    java.awt.geom.Rectangle2D var59 = var58.getChartArea();
    org.jfree.chart.renderer.category.IntervalBarRenderer var60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var62 = var60.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var63 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var64 = var63.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var65 = var63.getBaseItemLabelGenerator();
    java.awt.Paint var67 = null;
    var63.setSeriesFillPaint(1, var67, false);
    var63.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var73 = var63.getLegendItemLabelGenerator();
    var60.setLegendItemToolTipGenerator(var73);
    org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60);
    java.awt.Graphics2D var76 = null;
    org.jfree.chart.util.Size2D var77 = var75.arrange(var76);
    org.jfree.chart.util.RectangleEdge var78 = var75.getPosition();
    boolean var79 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var78);
    double var80 = var51.getCategoryJava2DCoordinate(var54, 0, 10, var59, var78);
    org.jfree.data.time.DateRange var83 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var84 = var83.getLowerDate();
    java.util.Date var85 = var83.getUpperDate();
    double var86 = var83.getLowerBound();
    boolean var87 = var78.equals((java.lang.Object)var83);
    var49.add(0.0d, var78);
    java.lang.String var89 = var49.toString();
    var17.setFixedDomainAxisSpace(var49);
    var0.setFixedDomainAxisSpace(var49);
    int var92 = var0.getWeight();
    boolean var93 = var0.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test141"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((-9.0d), (-9.0d), (-1.05d), (-26.0d));
    org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test142"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    int var4 = var3.getSubtitleCount();
    org.jfree.chart.entity.EntityCollection var7 = null;
    org.jfree.chart.ChartRenderingInfo var8 = new org.jfree.chart.ChartRenderingInfo(var7);
    java.awt.geom.Rectangle2D var9 = var8.getChartArea();
    org.jfree.chart.entity.EntityCollection var10 = var8.getEntityCollection();
    org.jfree.chart.plot.PlotRenderingInfo var11 = var8.getPlotInfo();
    var3.handleClick(4, 10, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var13 = var3.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test143"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
//     org.jfree.chart.plot.DatasetRenderingOrder var3 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation(0);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D(var9);
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var10);
//     var10.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var14 = var10.getURLGenerator();
//     java.awt.Shape var15 = var10.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var16 = null;
//     var10.setLabelGenerator(var16);
//     java.lang.Object var18 = var10.clone();
//     boolean var19 = var7.equals((java.lang.Object)var10);
//     org.jfree.chart.util.SortOrder var20 = var7.getRowRenderingOrder();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", (org.jfree.chart.plot.Plot)var7);
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var24);
//     var24.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var28 = var24.getURLGenerator();
//     java.awt.Shape var29 = var24.getLegendItemShape();
//     org.jfree.chart.util.Rotation var30 = var24.getDirection();
//     java.awt.Paint var31 = var24.getBaseSectionOutlinePaint();
//     var7.setRangeGridlinePaint(var31);
//     var0.setRangeZeroBaselinePaint(var31);
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var34 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D(var36);
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var37);
//     var37.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var41 = var37.getURLGenerator();
//     java.awt.Shape var42 = var37.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var43 = null;
//     var37.setLabelGenerator(var43);
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D(var46);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var47);
//     int var49 = var48.getBackgroundImageAlignment();
//     var37.addChangeListener((org.jfree.chart.event.PlotChangeListener)var48);
//     java.awt.Stroke var51 = var48.getBorderStroke();
//     var34.setGroupStroke(var51);
//     java.awt.Stroke var53 = var34.getGroupStroke();
//     var0.setRangeCrosshairStroke(var53);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var38
//     assertTrue("Contract failed: equals-hashcode on var11 and var38", var11.equals(var38) ? var11.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var11
//     assertTrue("Contract failed: equals-hashcode on var38 and var11", var38.equals(var11) ? var38.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test144"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var3 = var2.getUpArrow();
    java.awt.Shape var4 = var2.getDownArrow();
    java.awt.Stroke var5 = var2.getTickMarkStroke();
    var0.setRangeCrosshairStroke(var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getDomainMarkers(13, var8);
    org.jfree.chart.event.RendererChangeEvent var10 = null;
    var0.rendererChanged(var10);
    var0.setDomainGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test145"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("");
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement(var2, var3, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var7 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var8 = null;
    var7.addChangeListener(var8);
    org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, (org.jfree.data.general.Dataset)var7, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var7);
    var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var7);
    java.util.List var14 = var7.getColumnKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test146"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    double var5 = var4.getCategoryMargin();
    var4.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var9 = var4.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var10 = var0.getCategoriesForAxis(var4);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot3D var14 = new org.jfree.chart.plot.PiePlot3D(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var14);
    var14.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var18 = var14.getURLGenerator();
    java.awt.Shape var19 = var14.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var20 = null;
    var14.setLabelGenerator(var20);
    java.lang.Object var22 = var14.clone();
    boolean var23 = var11.equals((java.lang.Object)var14);
    org.jfree.chart.util.SortOrder var24 = var11.getRowRenderingOrder();
    var0.setColumnRenderingOrder(var24);
    org.jfree.chart.util.SortOrder var26 = var0.getRowRenderingOrder();
    java.awt.Stroke var27 = var0.getDomainGridlineStroke();
    org.jfree.chart.util.Layer var28 = null;
    java.util.Collection var29 = var0.getDomainMarkers(var28);
    int var30 = var0.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test147"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var17.axisChanged(var22);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
    var25.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var28 = var25.getTitle();
    boolean var29 = var28.getExpandToFitSpace();
    java.lang.Object var30 = var28.clone();
    java.lang.String var31 = var28.getURLText();
    org.jfree.chart.block.BlockFrame var32 = var28.getFrame();
    boolean var33 = var28.getNotify();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var35 = var34.clone();
    var34.setDrawOutlines(true);
    var34.setBaseLinesVisible(false);
    org.jfree.chart.urls.CategoryURLGenerator var41 = null;
    var34.setSeriesURLGenerator(1, var41);
    org.jfree.chart.renderer.category.IntervalBarRenderer var43 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var45 = null;
    var43.setSeriesItemLabelFont(1, var45);
    double var47 = var43.getItemMargin();
    boolean var49 = var43.isSeriesVisibleInLegend(1);
    java.lang.Boolean var51 = var43.getSeriesCreateEntities(1);
    var43.setBaseItemLabelsVisible(true, false);
    int var55 = var43.getRowCount();
    org.jfree.chart.renderer.category.IntervalBarRenderer var56 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var58 = null;
    var56.setSeriesItemLabelFont(1, var58);
    double var60 = var56.getItemMargin();
    boolean var62 = var56.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var65 = var56.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.text.TextAnchor var66 = var65.getRotationAnchor();
    var43.setPositiveItemLabelPositionFallback(var65);
    var34.setBaseNegativeItemLabelPosition(var65, false);
    var34.setSeriesLinesVisible(4, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var73 = var34.getLegendItemURLGenerator();
    boolean var74 = var28.equals((java.lang.Object)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test148"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    boolean var10 = var9.isEmpty();
    org.jfree.data.general.Dataset var11 = var9.getDataset();
    var9.setToolTipText("Multiple Pie Plot");
    var9.setToolTipText("Nearest");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test149"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.chart.ChartColor[r=0,g=4,b=0]", var1);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test150"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    var2.setShadowYOffset(1.0d);
    int var8 = var2.getPieIndex();
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot();
    var11.setSectionDepth(8.0d);
    java.awt.Paint var14 = var11.getSeparatorPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var15 = var11.getLegendLabelToolTipGenerator();
    java.awt.Paint var16 = var11.getOutlinePaint();
    java.lang.Integer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var19 = var18.getFixedLegendItems();
    var18.clearDomainAxes();
    var18.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.entity.EntityCollection var24 = null;
    org.jfree.chart.ChartRenderingInfo var25 = new org.jfree.chart.ChartRenderingInfo(var24);
    java.awt.geom.Rectangle2D var26 = var25.getChartArea();
    org.jfree.data.time.TimePeriodFormatException var28 = new org.jfree.data.time.TimePeriodFormatException("Default Group");
    boolean var29 = var25.equals((java.lang.Object)"Default Group");
    org.jfree.chart.plot.PlotRenderingInfo var30 = var25.getPlotInfo();
    java.awt.geom.Point2D var31 = null;
    var18.zoomDomainAxes(8.0d, var30, var31);
    int var33 = var30.getSubplotCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var34 = var2.initialise(var9, var10, (org.jfree.chart.plot.PiePlot)var11, var17, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test151"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    java.awt.Stroke var16 = var13.getBorderStroke();
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var19 = var17.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var21 = var20.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var20.getBaseItemLabelGenerator();
    java.awt.Paint var24 = null;
    var20.setSeriesFillPaint(1, var24, false);
    var20.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var20.getLegendItemLabelGenerator();
    var17.setLegendItemToolTipGenerator(var30);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.util.Size2D var34 = var32.arrange(var33);
    var13.addLegend(var32);
    org.jfree.chart.util.RectangleInsets var36 = var32.getLegendItemGraphicPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test152"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    double var5 = var4.getCategoryMargin();
    var4.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var9 = var4.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var10 = var0.getCategoriesForAxis(var4);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.renderer.category.IntervalBarRenderer var12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var14 = null;
    var12.setSeriesItemLabelFont(1, var14);
    boolean var16 = var12.getBaseSeriesVisibleInLegend();
    java.awt.Paint var19 = var12.getItemOutlinePaint(13, 100);
    var0.setRangeCrosshairPaint(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test153"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
    java.lang.Boolean var4 = var2.getSeriesLinesVisible(3);
    java.awt.Paint var6 = var2.lookupSeriesFillPaint(55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test154"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesLinesVisible(15, (java.lang.Boolean)true);
    org.jfree.chart.LegendItem var6 = var0.getLegendItem(13, 15);
    boolean var7 = var0.getBaseLinesVisible();
    int var8 = var0.getPassCount();
    var0.setDrawOutlines(false);
    var0.setSeriesShapesVisible(2, (java.lang.Boolean)false);
    org.jfree.chart.renderer.category.GanttRenderer var14 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var15 = var14.getCompletePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    double var20 = var16.getItemMargin();
    boolean var22 = var16.isSeriesVisibleInLegend(1);
    java.lang.Boolean var24 = var16.getSeriesCreateEntities(1);
    java.awt.Paint var26 = var16.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var27 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var29 = null;
    var27.setSeriesItemLabelFont(1, var29);
    boolean var31 = var27.getBaseSeriesVisibleInLegend();
    java.awt.Paint var34 = var27.getItemOutlinePaint(13, 100);
    var16.setBaseFillPaint(var34, true);
    var16.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var40 = var16.getBaseNegativeItemLabelPosition();
    int var41 = var16.getColumnCount();
    org.jfree.chart.labels.ItemLabelPosition var44 = var16.getPositiveItemLabelPosition(96, 15);
    var14.setBasePositiveItemLabelPosition(var44);
    var0.setBaseNegativeItemLabelPosition(var44, true);
    java.awt.Paint var50 = var0.getItemFillPaint((-1), 15);
    java.lang.Boolean var52 = var0.getSeriesShapesVisible((-905168));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test155"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Shape var3 = var1.getDownArrow();
    java.util.Date var4 = var1.getMinimumDate();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var8 = var7.getUpArrow();
    java.awt.Shape var9 = var7.getDownArrow();
    java.awt.Stroke var10 = var7.getTickMarkStroke();
    var5.setRangeCrosshairStroke(var10);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var5.getDomainMarkers(13, var13);
    org.jfree.chart.axis.AxisSpace var15 = new org.jfree.chart.axis.AxisSpace();
    double var16 = var15.getBottom();
    var15.setTop(0.0d);
    double var19 = var15.getBottom();
    org.jfree.chart.axis.AxisSpace var20 = new org.jfree.chart.axis.AxisSpace();
    double var21 = var20.getBottom();
    java.lang.Object var22 = var20.clone();
    var15.ensureAtLeast(var20);
    var5.setFixedDomainAxisSpace(var20);
    boolean var25 = var1.hasListener((java.util.EventListener)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test156"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var2 = var1.getMaxIcon();
    var0.setMinIcon(var2);
    java.awt.Paint var6 = var0.getItemOutlinePaint(10, 4);
    java.awt.Stroke var7 = var0.getGroupStroke();
    var0.setItemLabelAnchorOffset(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test157"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var1 = var0.clone();
    java.lang.Boolean var3 = var0.getSeriesLinesVisible(0);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var8 = null;
    var6.setSeriesItemLabelFont(1, var8);
    double var10 = var6.getItemMargin();
    boolean var12 = var6.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var15 = var6.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var17.setRangeWithMargins((org.jfree.data.Range)var20, false, true);
    org.jfree.data.Range var24 = var17.getDefaultAutoRange();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.AxisState var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var17.refreshTicks(var25, var26, var27, var28);
    java.awt.Font var30 = var17.getLabelFont();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D(var32);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var33);
    var33.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var37 = var33.getURLGenerator();
    java.awt.Shape var38 = var33.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var39 = null;
    var33.setLabelGenerator(var39);
    org.jfree.data.general.PieDataset var42 = null;
    org.jfree.chart.plot.PiePlot3D var43 = new org.jfree.chart.plot.PiePlot3D(var42);
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var43);
    int var45 = var44.getBackgroundImageAlignment();
    var33.addChangeListener((org.jfree.chart.event.PlotChangeListener)var44);
    org.jfree.chart.renderer.category.IntervalBarRenderer var48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var50 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var48.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var50);
    org.jfree.chart.renderer.category.IntervalBarRenderer var52 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var54 = null;
    var52.setSeriesItemLabelFont(1, var54);
    boolean var56 = var52.getBaseSeriesVisibleInLegend();
    java.awt.Paint var59 = var52.getItemOutlinePaint(13, 100);
    var48.setBaseItemLabelPaint(var59);
    var33.setSectionPaint((java.lang.Comparable)(short)100, var59);
    org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("Default Group", var30, var59);
    java.awt.geom.Rectangle2D var63 = var62.getBounds();
    var6.setBaseShape((java.awt.Shape)var63, false);
    org.jfree.chart.plot.PlotRenderingInfo var67 = null;
    boolean var68 = var4.render(var5, var63, (-457), var67);
    java.awt.Stroke var69 = var4.getDomainGridlineStroke();
    var0.setBaseStroke(var69);
    java.io.ObjectOutputStream var71 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var69, var71);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test158"); }


    org.jfree.chart.block.BlockResult var0 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var1 = var0.getEntityCollection();
    org.jfree.chart.entity.EntityCollection var2 = var0.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test159"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    java.awt.Stroke var16 = var13.getBorderStroke();
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var19 = var17.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var21 = var20.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var20.getBaseItemLabelGenerator();
    java.awt.Paint var24 = null;
    var20.setSeriesFillPaint(1, var24, false);
    var20.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var20.getLegendItemLabelGenerator();
    var17.setLegendItemToolTipGenerator(var30);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.util.Size2D var34 = var32.arrange(var33);
    var13.addLegend(var32);
    org.jfree.chart.block.BlockContainer var36 = var32.getItemContainer();
    org.jfree.chart.block.BlockContainer var37 = null;
    var32.setWrapper(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test160"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.data.general.Dataset var10 = var9.getDataset();
    java.lang.Comparable var11 = var9.getSeriesKey();
    org.jfree.chart.block.Arrangement var12 = var9.getArrangement();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var11.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test161"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    int var11 = var5.getRowIndex((java.lang.Comparable)(-1.0f));
    org.jfree.data.gantt.TaskSeries var13 = new org.jfree.data.gantt.TaskSeries("Default Group");
    java.lang.Comparable var14 = var13.getKey();
    org.jfree.data.KeyToGroupMap var16 = new org.jfree.data.KeyToGroupMap();
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var19 = var18.getUpArrow();
    boolean var20 = var16.equals((java.lang.Object)var19);
    boolean var22 = var16.equals((java.lang.Object)0.0f);
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var25 = var24.getUpArrow();
    java.awt.Shape var26 = var24.getDownArrow();
    java.util.Date var27 = var24.getMinimumDate();
    int var28 = var16.getGroupIndex((java.lang.Comparable)var27);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var31 = var30.getUpArrow();
    java.awt.Shape var32 = var30.getDownArrow();
    java.util.Date var33 = var30.getMinimumDate();
    java.lang.String var34 = var30.getLabel();
    java.util.Date var35 = var30.getMinimumDate();
    org.jfree.data.gantt.Task var36 = new org.jfree.data.gantt.Task("Pie 3D Plot", var27, var35);
    var13.add(var36);
    org.jfree.data.gantt.Task var39 = var13.get(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst");
    var5.add(var13);
    java.lang.Class var41 = null;
    org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var44 = var43.getUpArrow();
    java.awt.Shape var45 = var43.getDownArrow();
    java.util.Date var46 = var43.getMinimumDate();
    java.util.TimeZone var47 = null;
    org.jfree.data.time.RegularTimePeriod var48 = org.jfree.data.time.RegularTimePeriod.createInstance(var41, var46, var47);
    org.jfree.data.time.Month var49 = new org.jfree.data.time.Month(var46);
    int var50 = var5.getColumnIndex((java.lang.Comparable)var49);
    java.lang.Number var51 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    org.jfree.data.general.PieDataset var53 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var5, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "Default Group"+ "'", var14.equals("Default Group"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "hi!"+ "'", var34.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + 0.0d+ "'", var51.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test162"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.Year var2 = var0.getYear();
    org.jfree.chart.plot.CategoryMarker var3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var0);
    org.jfree.data.time.RegularTimePeriod var4 = var0.next();
    java.util.Date var5 = var4.getEnd();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test163"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var1 = var0.getRowKeys();
    java.lang.Object var2 = null;
    boolean var3 = var0.equals(var2);
    java.lang.Object var4 = var0.clone();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var9.setRangeWithMargins((org.jfree.data.Range)var12, false, true);
    org.jfree.data.Range var16 = var9.getDefaultAutoRange();
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.axis.AxisState var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    java.util.List var21 = var9.refreshTicks(var17, var18, var19, var20);
    java.awt.Font var22 = var9.getLabelFont();
    org.jfree.chart.plot.MultiplePiePlot var23 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var24 = var23.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var28 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var25.setRangeWithMargins((org.jfree.data.Range)var28, false, true);
    org.jfree.data.Range var32 = var25.getDefaultAutoRange();
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.axis.AxisState var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    java.util.List var37 = var25.refreshTicks(var33, var34, var35, var36);
    org.jfree.chart.plot.Plot var38 = var25.getPlot();
    boolean var39 = var23.equals((java.lang.Object)var25);
    java.awt.Paint var40 = var25.getAxisLinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var25, var41);
    org.jfree.chart.axis.AxisLocation var43 = var42.getRangeAxisLocation();
    var5.setRangeAxisLocation(15, var43);
    var5.setRangeCrosshairLockedOnData(false);
    int var47 = var5.getSeriesCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
    int var49 = var5.getIndexOf(var48);
    boolean var50 = var0.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test164"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 0.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-10));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test165"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("Pie 3D Plot", var1, var2, var3);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test166"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAutoRange(true);
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    boolean var5 = var4.isAxisLineVisible();
    org.jfree.chart.axis.DateTickUnit var8 = new org.jfree.chart.axis.DateTickUnit(0, (-435));
    java.lang.String var9 = var8.toString();
    var4.setTickUnit(var8, false, false);
    java.util.Date var13 = var1.calculateHighestVisibleTickValue(var8);
    java.text.DateFormat var14 = null;
    var1.setDateFormatOverride(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "DateTickUnit[YEAR, -435]"+ "'", var9.equals("DateTickUnit[YEAR, -435]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test167"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.data.time.TimePeriodFormatException: Default Group");
    org.jfree.chart.axis.MarkerAxisBand var3 = var2.getMarkerBand();
    boolean var4 = var0.equals((java.lang.Object)var2);
    var2.setFixedDimension(7.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test168"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var1 = var0.getFont();
    var0.setToolTipText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var6 = var4.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var8 = var7.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var7.getBaseItemLabelGenerator();
    java.awt.Paint var11 = null;
    var7.setSeriesFillPaint(1, var11, false);
    var7.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var7.getLegendItemLabelGenerator();
    var4.setLegendItemToolTipGenerator(var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.lang.Object var20 = null;
    boolean var21 = var19.equals(var20);
    java.awt.Paint var22 = var19.getItemPaint();
    org.jfree.chart.util.HorizontalAlignment var23 = var19.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, Double.NaN, 0.0d);
    var0.setTextAlignment(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test169"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     double var5 = var4.getCategoryMargin();
//     var4.setMaximumCategoryLabelWidthRatio(1.0f);
//     java.lang.String var9 = var4.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
//     java.util.List var10 = var0.getCategoriesForAxis(var4);
//     var0.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.axis.AxisSpace var13 = null;
//     var0.setFixedRangeAxisSpace(var13);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(Double.NaN, 0.0d, false);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var21 = var19.getRowIndex((java.lang.Comparable)(-7.0d));
//     double var23 = var19.getRangeUpperBound(true);
//     org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var19, true);
//     double var27 = var19.getRangeLowerBound(false);
//     java.lang.Number var28 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var19);
//     org.jfree.data.Range var29 = var18.findRangeBounds((org.jfree.data.category.CategoryDataset)var19);
//     double var31 = var19.getRangeUpperBound(false);
//     var0.setDataset((org.jfree.data.category.CategoryDataset)var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + 0.0d+ "'", var28.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == Double.NaN);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test170"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
//     int var2 = var1.getMonth();
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var4 = var3.getNoDataMessagePaint();
//     org.jfree.chart.event.RendererChangeEvent var5 = null;
//     var3.rendererChanged(var5);
//     java.awt.Stroke var7 = var3.getAngleGridlineStroke();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)var1, (java.lang.Object)var7);
//     org.jfree.data.category.DefaultCategoryDataset var9 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var11 = var9.getRowIndex((java.lang.Comparable)(-1.05d));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var14 = null;
//     var12.setSeriesItemLabelFont(1, var14);
//     boolean var16 = var12.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16);
//     boolean var18 = var9.equals((java.lang.Object)var16);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     org.jfree.chart.util.Size2D var24 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
//     java.lang.Object var25 = var24.clone();
//     int var26 = var21.compareTo((java.lang.Object)var24);
//     var9.addValue(3.0d, (java.lang.Comparable)(short)0, (java.lang.Comparable)var21);
//     var9.validateObject();
//     int var29 = var9.getColumnCount();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(15);
//     java.lang.String var34 = var33.getDescription();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addYears(12, var33);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var39 = null;
//     var37.setSeriesItemLabelFont(1, var39);
//     double var41 = var37.getItemMargin();
//     boolean var43 = var37.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var45 = var37.getSeriesCreateEntities(1);
//     var37.setBaseItemLabelsVisible(true, false);
//     int var49 = var37.getRowCount();
//     org.jfree.data.gantt.TaskSeriesCollection var50 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var51 = null;
//     var50.addChangeListener(var51);
//     org.jfree.data.Range var53 = var37.findRangeBounds((org.jfree.data.category.CategoryDataset)var50);
//     org.jfree.data.Range var54 = var36.findRangeBounds((org.jfree.data.category.CategoryDataset)var50);
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var59 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var56.setRangeWithMargins((org.jfree.data.Range)var59, false, true);
//     org.jfree.data.Range var63 = var56.getDefaultAutoRange();
//     var56.setAutoTickUnitSelection(false, false);
//     java.text.DateFormat var67 = null;
//     var56.setDateFormatOverride(var67);
//     boolean var70 = var56.isHiddenValue(0L);
//     boolean var71 = var55.equals((java.lang.Object)var70);
//     org.jfree.chart.util.Size2D var74 = new org.jfree.chart.util.Size2D(1.0d, (-1.05d));
//     java.lang.String var75 = var74.toString();
//     java.lang.Object var76 = var74.clone();
//     boolean var77 = var55.equals((java.lang.Object)var74);
//     org.jfree.data.general.PieDataset var78 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var50, (java.lang.Comparable)var55);
//     var9.addValue(0.0d, (java.lang.Comparable)var35, (java.lang.Comparable)var55);
//     org.jfree.data.time.SerialDate var80 = null;
//     boolean var82 = var1.isInRange(var35, var80, (-16777216));
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test171"); }


    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)255);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var5 = var4.getUpArrow();
    java.awt.Shape var6 = var4.getDownArrow();
    java.util.Date var7 = var4.getMinimumDate();
    java.lang.String var8 = var4.getLabel();
    java.util.Date var9 = var4.getMinimumDate();
    int var10 = var2.getRowIndex((java.lang.Comparable)var9);
    org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var14 = var13.getLowerDate();
    org.jfree.data.Range var16 = org.jfree.data.Range.shift((org.jfree.data.Range)var13, (-1.0d));
    double var18 = var13.constrain(0.05d);
    java.util.Date var19 = var13.getUpperDate();
    org.jfree.data.time.SimpleTimePeriod var20 = new org.jfree.data.time.SimpleTimePeriod(var9, var19);
    int var21 = var1.getKeyCount((java.lang.Comparable)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test172"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    var0.setDomainCrosshairValue(0.0d);
    var0.setRangeCrosshairValue((-7.0d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var7.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var11 = var10.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var10.getBaseItemLabelGenerator();
    java.awt.Paint var14 = null;
    var10.setSeriesFillPaint(1, var14, false);
    var10.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = var10.getLegendItemLabelGenerator();
    var7.setLegendItemToolTipGenerator(var20);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    java.lang.Object var23 = null;
    boolean var24 = var22.equals(var23);
    java.awt.Paint var25 = var22.getItemPaint();
    var0.setDomainGridlinePaint(var25);
    org.jfree.chart.plot.DatasetRenderingOrder var27 = var0.getDatasetRenderingOrder();
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var32 = var31.getUpArrow();
    java.awt.Shape var33 = var31.getDownArrow();
    java.awt.Stroke var34 = var31.getTickMarkStroke();
    var29.setRangeCrosshairStroke(var34);
    org.jfree.chart.util.Layer var37 = null;
    java.util.Collection var38 = var29.getDomainMarkers(13, var37);
    org.jfree.chart.axis.AxisSpace var39 = new org.jfree.chart.axis.AxisSpace();
    double var40 = var39.getBottom();
    var39.setTop(0.0d);
    double var43 = var39.getBottom();
    org.jfree.chart.axis.AxisSpace var44 = new org.jfree.chart.axis.AxisSpace();
    double var45 = var44.getBottom();
    java.lang.Object var46 = var44.clone();
    var39.ensureAtLeast(var44);
    var29.setFixedDomainAxisSpace(var44);
    double var49 = var44.getTop();
    var0.setFixedDomainAxisSpace(var44);
    org.jfree.chart.entity.EntityCollection var53 = null;
    org.jfree.chart.ChartRenderingInfo var54 = new org.jfree.chart.ChartRenderingInfo(var53);
    java.awt.geom.Rectangle2D var55 = var54.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var56 = var54.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var57 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var56);
    java.lang.Object var58 = var56.clone();
    org.jfree.chart.ChartRenderingInfo var59 = var56.getOwner();
    org.jfree.chart.plot.PlotRenderingInfo var60 = var59.getPlotInfo();
    var0.handleClick(85, 255, var60);
    java.awt.Paint var62 = var0.getRangeZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test173"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var6 = var5.getLowerDate();
    org.jfree.data.Range var9 = org.jfree.data.Range.shift((org.jfree.data.Range)var5, 0.0d, false);
    java.util.Date var10 = var5.getUpperDate();
    java.lang.Object var11 = var0.getObject((java.lang.Comparable)var10);
    org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var15 = var14.getLowerDate();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var18);
    int var20 = var19.getBackgroundImageAlignment();
    java.awt.Image var21 = var19.getBackgroundImage();
    boolean var22 = var19.isBorderVisible();
    var0.addObject((java.lang.Comparable)var15, (java.lang.Object)var22);
    java.lang.Object var25 = var0.getObject((-1));
    java.lang.Object var27 = var0.getObject(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + false+ "'", var27.equals(false));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test174"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var8 = null;
    var6.setSeriesItemLabelFont(1, var8);
    double var10 = var6.getItemMargin();
    boolean var12 = var6.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var15 = var6.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var17.setRangeWithMargins((org.jfree.data.Range)var20, false, true);
    org.jfree.data.Range var24 = var17.getDefaultAutoRange();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.AxisState var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var17.refreshTicks(var25, var26, var27, var28);
    java.awt.Font var30 = var17.getLabelFont();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D(var32);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var33);
    var33.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var37 = var33.getURLGenerator();
    java.awt.Shape var38 = var33.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var39 = null;
    var33.setLabelGenerator(var39);
    org.jfree.data.general.PieDataset var42 = null;
    org.jfree.chart.plot.PiePlot3D var43 = new org.jfree.chart.plot.PiePlot3D(var42);
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var43);
    int var45 = var44.getBackgroundImageAlignment();
    var33.addChangeListener((org.jfree.chart.event.PlotChangeListener)var44);
    org.jfree.chart.renderer.category.IntervalBarRenderer var48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var50 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var48.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var50);
    org.jfree.chart.renderer.category.IntervalBarRenderer var52 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var54 = null;
    var52.setSeriesItemLabelFont(1, var54);
    boolean var56 = var52.getBaseSeriesVisibleInLegend();
    java.awt.Paint var59 = var52.getItemOutlinePaint(13, 100);
    var48.setBaseItemLabelPaint(var59);
    var33.setSectionPaint((java.lang.Comparable)(short)100, var59);
    org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("Default Group", var30, var59);
    java.awt.geom.Rectangle2D var63 = var62.getBounds();
    var6.setBaseShape((java.awt.Shape)var63, false);
    java.awt.Font var68 = var6.getItemLabelFont((-457), 15);
    org.jfree.chart.axis.MarkerAxisBand var69 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var1, 0.0d, 0.0d, (-0.9500000000000001d), (-0.9500000000000001d), var68);
    org.jfree.data.RangeType var70 = var1.getRangeType();
    java.awt.Stroke var71 = var1.getTickMarkStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test175"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var1.addChangeListener(var2);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test176"); }


    org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var1.setKey((java.lang.Comparable)false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D(var5);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var6);
    java.awt.Shape var8 = var6.getLegendItemShape();
    var1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var6);
    java.awt.Paint var10 = var6.getLabelShadowPaint();
    java.awt.Color var13 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var14 = var13.getTransparency();
    int var15 = var13.getAlpha();
    int var16 = var13.getAlpha();
    var6.setSectionPaint((java.lang.Comparable)"Default Group", (java.awt.Paint)var13);
    int var18 = var13.getGreen();
    float[] var19 = null;
    float[] var20 = var13.getComponents(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test177"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(1388563200000L, 1388563200000L);
    java.util.Date var3 = var2.getStart();
    java.util.Date var4 = var2.getStart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test178"); }


    org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var1.setKey((java.lang.Comparable)false);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D(var5);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var6);
    java.awt.Shape var8 = var6.getLegendItemShape();
    var1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var6);
    org.jfree.chart.util.LengthAdjustmentType var10 = var1.getLabelOffsetType();
    java.lang.String var11 = var10.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "EXPAND"+ "'", var11.equals("EXPAND"));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test179"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesCreateEntities(255);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var5 = var4.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getBaseItemLabelGenerator();
    java.awt.Paint var8 = null;
    var4.setSeriesFillPaint(1, var8, false);
    var4.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var4.getSeriesPositiveItemLabelPosition(100);
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var17.setRangeWithMargins((org.jfree.data.Range)var20, false, true);
    org.jfree.data.Range var24 = var17.getDefaultAutoRange();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.AxisState var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var17.refreshTicks(var25, var26, var27, var28);
    java.awt.Font var30 = var17.getLabelFont();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D(var32);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var33);
    var33.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var37 = var33.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var38 = null;
    var33.axisChanged(var38);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var30, (org.jfree.chart.plot.Plot)var33, false);
    boolean var42 = var15.equals((java.lang.Object)var30);
    var0.setSeriesNegativeItemLabelPosition(255, var15);
    org.jfree.chart.text.TextAnchor var44 = var15.getTextAnchor();
    double var45 = var15.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test180"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setTickMarksVisible(true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test181"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var4 = null;
    var0.setSeriesFillPaint(1, var4, false);
    java.awt.Stroke var8 = null;
    var0.setSeriesStroke(0, var8);
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var13 = null;
    var11.setSeriesItemLabelFont(1, var13);
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var15.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var17);
    var11.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var17);
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var20 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D(var22);
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var23);
    var23.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var27 = var23.getURLGenerator();
    java.awt.Shape var28 = var23.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var29 = null;
    var23.setLabelGenerator(var29);
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D(var32);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var33);
    int var35 = var34.getBackgroundImageAlignment();
    var23.addChangeListener((org.jfree.chart.event.PlotChangeListener)var34);
    java.awt.Stroke var37 = var34.getBorderStroke();
    var20.setGroupStroke(var37);
    var11.setBaseStroke(var37);
    var0.setSeriesStroke(0, var37);
    var0.setSeriesItemLabelsVisible(4, false);
    org.jfree.chart.LegendItemCollection var44 = var0.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test182"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    double var5 = var4.getCategoryMargin();
    var4.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var9 = var4.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var10 = var0.getCategoriesForAxis(var4);
    org.jfree.chart.util.RectangleEdge var11 = var0.getRangeAxisEdge();
    boolean var12 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    java.text.NumberFormat var15 = null;
    var14.setNumberFormatOverride(var15);
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.data.RangeType var18 = var14.getRangeType();
    boolean var19 = var14.getAutoRangeIncludesZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test183"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    int var3 = var0.getItemCount();
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var4, var6);
    java.lang.Number[][] var8 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var4, var8);
    boolean var10 = var0.equals((java.lang.Object)var4);
    java.util.List var11 = var0.getKeys();
    org.jfree.chart.renderer.category.StackedAreaRenderer var13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var16 = null;
    var14.setSeriesItemLabelFont(1, var16);
    double var18 = var14.getItemMargin();
    boolean var20 = var14.isSeriesVisibleInLegend(1);
    java.lang.Boolean var22 = var14.getSeriesCreateEntities(1);
    java.awt.Paint var24 = var14.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var27 = null;
    var25.setSeriesItemLabelFont(1, var27);
    boolean var29 = var25.getBaseSeriesVisibleInLegend();
    java.awt.Paint var32 = var25.getItemOutlinePaint(13, 100);
    var14.setBaseFillPaint(var32, true);
    var14.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var38 = var14.getBaseNegativeItemLabelPosition();
    boolean var39 = var13.equals((java.lang.Object)var38);
    org.jfree.data.DefaultKeyedValues2D var40 = new org.jfree.data.DefaultKeyedValues2D();
    boolean var41 = var13.equals((java.lang.Object)var40);
    org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
    java.util.Date var43 = var42.getEnd();
    org.jfree.data.time.RegularTimePeriod var44 = var42.previous();
    int var45 = var40.getColumnIndex((java.lang.Comparable)var42);
    java.lang.Object var46 = null;
    var0.addObject((java.lang.Comparable)var45, var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test184"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem((-435), 10);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D(var5);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var6);
    var6.setShadowYOffset(0.0d);
    var6.setShadowYOffset(1.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var13 = var12.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    double var15 = var12.getBase();
    java.awt.Stroke var16 = var12.getBaseOutlineStroke();
    var6.setOutlineStroke(var16);
    var6.setShadowYOffset(10.0d);
    boolean var20 = var6.getLabelLinksVisible();
    boolean var21 = var0.equals((java.lang.Object)var6);
    java.awt.Paint var22 = var0.getArtifactPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test185"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    boolean var1 = var0.isAxisLineVisible();
    double var2 = var0.getLowerMargin();
    org.jfree.data.DefaultKeyedValues2D var4 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var5 = var4.getRowKeys();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var7.lookupSeriesShape((-1));
    var6.setUpArrow(var9);
    java.util.Date var11 = var6.getMaximumDate();
    int var12 = var4.getColumnIndex((java.lang.Comparable)var11);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var16 = var14.lookupSeriesShape((-1));
    var13.setUpArrow(var16);
    var13.setLabel("");
    java.util.TimeZone var20 = var13.getTimeZone();
    org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(var11, var20);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", var20);
    var0.setTimeZone(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test186"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var2 = var1.getRowKeys();
    java.util.List var3 = var1.getColumnKeys();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    java.util.Date var5 = var4.getEnd();
    var1.removeColumn((java.lang.Comparable)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(13, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test187"); }
// 
// 
//     java.lang.Number[][] var0 = null;
//     java.lang.Number[] var1 = null;
//     java.lang.Number[][] var2 = new java.lang.Number[][] { var1};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
//     org.jfree.data.DefaultKeyedValues2D var4 = new org.jfree.data.DefaultKeyedValues2D();
//     java.util.List var5 = var4.getRowKeys();
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var9 = var7.lookupSeriesShape((-1));
//     var6.setUpArrow(var9);
//     java.util.Date var11 = var6.getMaximumDate();
//     int var12 = var4.getColumnIndex((java.lang.Comparable)var11);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var16 = var14.lookupSeriesShape((-1));
//     var13.setUpArrow(var16);
//     var13.setLabel("");
//     java.util.TimeZone var20 = var13.getTimeZone();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(var11, var20);
//     boolean var22 = var3.equals((java.lang.Object)var20);
//     java.util.List var23 = var3.getColumnKeys();
//     java.util.List var24 = var3.getRowKeys();
//     java.lang.Comparable var26 = var3.getColumnKey(4);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test188"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4);
//     java.lang.String var6 = var5.toString();
//     java.lang.Object var7 = var5.getSource();
//     org.jfree.chart.event.ChartChangeEventType var8 = var5.getType();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     double var10 = var9.getCategoryMargin();
//     int var11 = var9.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.CategoryAnchor var12 = null;
//     org.jfree.chart.entity.EntityCollection var15 = null;
//     org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getChartArea();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var20 = var18.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var22 = var21.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var21.getBaseItemLabelGenerator();
//     java.awt.Paint var25 = null;
//     var21.setSeriesFillPaint(1, var25, false);
//     var21.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var31 = var21.getLegendItemLabelGenerator();
//     var18.setLegendItemToolTipGenerator(var31);
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.util.Size2D var35 = var33.arrange(var34);
//     org.jfree.chart.util.RectangleEdge var36 = var33.getPosition();
//     boolean var37 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var36);
//     double var38 = var9.getCategoryJava2DCoordinate(var12, 0, 10, var17, var36);
//     org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     java.util.Date var42 = var41.getLowerDate();
//     java.util.Date var43 = var41.getUpperDate();
//     double var44 = var41.getLowerBound();
//     boolean var45 = var36.equals((java.lang.Object)var41);
//     java.util.Date var46 = var41.getLowerDate();
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var50 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var47.setRangeWithMargins((org.jfree.data.Range)var50, false, true);
//     org.jfree.data.Range var54 = var47.getDefaultAutoRange();
//     var47.setAutoTickUnitSelection(false, false);
//     java.text.DateFormat var58 = null;
//     var47.setDateFormatOverride(var58);
//     java.util.TimeZone var60 = var47.getTimeZone();
//     org.jfree.data.time.Year var61 = new org.jfree.data.time.Year(var46, var60);
//     boolean var62 = var8.equals((java.lang.Object)var60);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var21.", var0.equals(var21) == var21.equals(var0));
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test189"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("-3,-3,3,3");

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test190"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var3 = var2.getAlpha();
    java.awt.Paint var4 = var2.getPaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var5.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var7);
    org.jfree.chart.util.GradientPaintTransformer var9 = var5.getGradientPaintTransformer();
    var2.setGradientPaintTransformer(var9);
    java.lang.Object var11 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test191"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    org.jfree.chart.util.RectangleInsets var3 = var0.getAxisOffset();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = var0.getRendererForDataset(var4);
    java.awt.Stroke var6 = var0.getRangeCrosshairStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var10 = var7.getItemPaint((-435), 255);
    var0.setDomainTickBandPaint(var10);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
    java.awt.geom.Point2D var15 = var13.getQuadrantOrigin();
    org.jfree.chart.axis.ValueAxis var16 = null;
    var13.setRangeAxis(var16);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker((-1.05d));
    java.awt.Paint var20 = var19.getLabelPaint();
    var13.setRangeTickBandPaint(var20);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.DrawingSupplier var27 = null;
    var23.setDrawingSupplier(var27);
    org.jfree.chart.axis.AxisLocation var29 = var23.getRangeAxisLocation();
    var13.setDomainAxisLocation(255, var29);
    var0.setDomainAxisLocation(3, var29);
    org.jfree.chart.axis.AxisLocation var32 = var29.getOpposite();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test192"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    var3.setShadowYOffset(1.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var10 = var9.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var9.getBaseItemLabelGenerator();
    double var12 = var9.getBase();
    java.awt.Stroke var13 = var9.getBaseOutlineStroke();
    var3.setOutlineStroke(var13);
    var3.setShadowYOffset(10.0d);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    var19.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
    java.awt.Shape var24 = var19.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = null;
    var19.setLabelGenerator(var25);
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
    int var31 = var30.getBackgroundImageAlignment();
    var19.addChangeListener((org.jfree.chart.event.PlotChangeListener)var30);
    org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var36 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var34.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var36);
    org.jfree.chart.renderer.category.IntervalBarRenderer var38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var40 = null;
    var38.setSeriesItemLabelFont(1, var40);
    boolean var42 = var38.getBaseSeriesVisibleInLegend();
    java.awt.Paint var45 = var38.getItemOutlinePaint(13, 100);
    var34.setBaseItemLabelPaint(var45);
    var19.setSectionPaint((java.lang.Comparable)(short)100, var45);
    var3.setLabelLinkPaint(var45);
    java.awt.Stroke var49 = var3.getOutlineStroke();
    var0.setSeparatorStroke(var49);
    java.lang.Object var51 = null;
    boolean var52 = var0.equals(var51);
    java.awt.Paint var53 = var0.getOutlinePaint();
    var0.setSectionDepth((-9.0d));
    java.awt.Font var56 = var0.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test193"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    var2.setShadowYOffset(1.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var8.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getBaseItemLabelGenerator();
    double var11 = var8.getBase();
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    var2.setOutlineStroke(var12);
    var2.setDepthFactor(0.0d);
    org.jfree.chart.util.RectangleInsets var16 = var2.getInsets();
    java.awt.Paint var17 = var2.getShadowPaint();
    boolean var18 = var2.getLabelLinksVisible();
    org.jfree.chart.urls.PieURLGenerator var19 = null;
    var2.setURLGenerator(var19);
    var2.setLabelLinksVisible(false);
    org.jfree.chart.labels.PieToolTipGenerator var23 = var2.getToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test194"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     var0.setSectionDepth(8.0d);
//     java.awt.Paint var3 = var0.getSeparatorPaint();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     org.jfree.chart.util.Size2D var7 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
//     java.lang.Object var8 = var7.clone();
//     int var9 = var4.compareTo((java.lang.Object)var7);
//     int var10 = var4.getYearValue();
//     boolean var12 = var4.equals((java.lang.Object)"org.jfree.chart.event.ChartChangeEvent[source=true]");
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var16 = var15.getUpArrow();
//     java.awt.Shape var17 = var15.getDownArrow();
//     java.awt.Stroke var18 = var15.getTickMarkStroke();
//     var13.setRangeCrosshairStroke(var18);
//     java.awt.geom.Point2D var20 = var13.getQuadrantOrigin();
//     org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     var22.setKey((java.lang.Comparable)false);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
//     java.awt.Shape var29 = var27.getLegendItemShape();
//     var22.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var27);
//     java.awt.Paint var31 = var27.getLabelShadowPaint();
//     java.awt.Color var34 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var35 = var34.getTransparency();
//     int var36 = var34.getAlpha();
//     int var37 = var34.getAlpha();
//     var27.setSectionPaint((java.lang.Comparable)"Default Group", (java.awt.Paint)var34);
//     var13.setRangeCrosshairPaint((java.awt.Paint)var34);
//     var0.setSectionOutlinePaint((java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=true]", (java.awt.Paint)var34);
//     int var41 = var34.getRed();
//     int var42 = var34.getRGB();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == (-16777216));
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test195"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test196"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    boolean var2 = var1.getRenderAsPercentages();
    org.jfree.chart.LegendItem var5 = var1.getLegendItem(3, 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test197"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var1 = var0.getWidthRatio();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var5 = var4.getLowerDate();
    org.jfree.data.Range var8 = org.jfree.data.Range.shift((org.jfree.data.Range)var4, 0.0d, false);
    java.util.Date var9 = var4.getUpperDate();
    boolean var10 = var0.equals((java.lang.Object)var9);
    double var11 = var0.getAngle();
    org.jfree.chart.text.TextAnchor var12 = var0.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var13 = var0.getWidthType();
    java.lang.String var14 = var13.toString();
    java.lang.String var15 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "CategoryLabelWidthType.CATEGORY"+ "'", var14.equals("CategoryLabelWidthType.CATEGORY"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "CategoryLabelWidthType.CATEGORY"+ "'", var15.equals("CategoryLabelWidthType.CATEGORY"));

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test198"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    var1.addFragment(var3);
    org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var7 = var6.getPaint();
    var1.removeFragment(var6);
    float var9 = var6.getBaselineOffset();
    java.awt.Font var10 = var6.getFont();
    org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test199"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var11.setRangeWithMargins((org.jfree.data.Range)var14, false, true);
    org.jfree.data.Range var18 = var11.getDefaultAutoRange();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.axis.AxisState var20 = null;
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    java.util.List var23 = var11.refreshTicks(var19, var20, var21, var22);
    java.awt.Font var24 = var11.getLabelFont();
    org.jfree.data.general.PieDataset var26 = null;
    org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
    var27.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var31 = var27.getURLGenerator();
    java.awt.Shape var32 = var27.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var33 = null;
    var27.setLabelGenerator(var33);
    org.jfree.data.general.PieDataset var36 = null;
    org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D(var36);
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var37);
    int var39 = var38.getBackgroundImageAlignment();
    var27.addChangeListener((org.jfree.chart.event.PlotChangeListener)var38);
    org.jfree.chart.renderer.category.IntervalBarRenderer var42 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var44 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var42.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var44);
    org.jfree.chart.renderer.category.IntervalBarRenderer var46 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var48 = null;
    var46.setSeriesItemLabelFont(1, var48);
    boolean var50 = var46.getBaseSeriesVisibleInLegend();
    java.awt.Paint var53 = var46.getItemOutlinePaint(13, 100);
    var42.setBaseItemLabelPaint(var53);
    var27.setSectionPaint((java.lang.Comparable)(short)100, var53);
    org.jfree.chart.block.LabelBlock var56 = new org.jfree.chart.block.LabelBlock("Default Group", var24, var53);
    var56.setURLText("");
    var56.setID("First");
    java.lang.Object var61 = var56.clone();
    java.lang.Object var62 = null;
    boolean var63 = var56.equals(var62);
    var9.add((org.jfree.chart.block.Block)var56);
    org.jfree.chart.util.RectangleInsets var65 = var9.getPadding();
    boolean var66 = var9.isEmpty();
    boolean var67 = var9.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test200"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    org.jfree.chart.renderer.category.GanttRenderer var1 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var2 = var1.getCompletePaint();
    var0.setPositiveBarPaint(var2);
    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var6 = var5.getTransparency();
    int var7 = var5.getGreen();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var5);
    java.awt.color.ColorSpace var9 = var5.getColorSpace();
    var0.setLastBarPaint((java.awt.Paint)var5);
    java.awt.Paint var11 = var0.getFirstBarPaint();
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var16 = var15.getAlpha();
    java.awt.Paint var17 = var15.getPaint();
    var12.setAngleLabelPaint(var17);
    java.awt.Color var20 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    float[] var24 = new float[] { 1.0f, 10.0f, (-1.0f)};
    float[] var25 = var20.getRGBColorComponents(var24);
    boolean var26 = var12.equals((java.lang.Object)var20);
    java.awt.Color var27 = var20.brighter();
    var0.setFirstBarPaint((java.awt.Paint)var20);
    boolean var29 = var0.getBaseCreateEntities();
    org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var32 = var30.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var33 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var34 = var33.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var33.getBaseItemLabelGenerator();
    java.awt.Paint var37 = null;
    var33.setSeriesFillPaint(1, var37, false);
    var33.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var43 = var33.getLegendItemLabelGenerator();
    var30.setLegendItemToolTipGenerator(var43);
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
    org.jfree.chart.util.RectangleAnchor var46 = null;
    var45.setLegendItemGraphicLocation(var46);
    org.jfree.chart.block.BlockContainer var48 = var45.getItemContainer();
    org.jfree.chart.util.RectangleInsets var49 = var45.getItemLabelPadding();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var50 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var53 = var50.getItemPaint((-435), 255);
    var45.setBackgroundPaint(var53);
    var0.setFirstBarPaint(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "black"+ "'", var8.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test201"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var3 = null;
    var1.setSeriesItemLabelFont(1, var3);
    double var5 = var1.getItemMargin();
    boolean var7 = var1.isSeriesVisibleInLegend(1);
    java.lang.Boolean var9 = var1.getSeriesCreateEntities(1);
    var1.setBaseItemLabelsVisible(true, false);
    int var13 = var1.getRowCount();
    org.jfree.data.gantt.TaskSeriesCollection var14 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var15 = null;
    var14.addChangeListener(var15);
    org.jfree.data.Range var17 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var14);
    org.jfree.data.Range var18 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var14);
    org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var23 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var20.setRangeWithMargins((org.jfree.data.Range)var23, false, true);
    org.jfree.data.Range var27 = var20.getDefaultAutoRange();
    var20.setAutoTickUnitSelection(false, false);
    java.text.DateFormat var31 = null;
    var20.setDateFormatOverride(var31);
    boolean var34 = var20.isHiddenValue(0L);
    boolean var35 = var19.equals((java.lang.Object)var34);
    org.jfree.chart.util.Size2D var38 = new org.jfree.chart.util.Size2D(1.0d, (-1.05d));
    java.lang.String var39 = var38.toString();
    java.lang.Object var40 = var38.clone();
    boolean var41 = var19.equals((java.lang.Object)var38);
    org.jfree.data.general.PieDataset var42 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var14, (java.lang.Comparable)var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var45 = var14.getEndValue(9, 85);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "Size2D[width=1.0, height=-1.05]"+ "'", var39.equals("Size2D[width=1.0, height=-1.05]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test202"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    var1.setVisible(false);
    var1.setAutoRange(false);
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var8 = var7.getUpArrow();
    java.awt.Shape var9 = var7.getDownArrow();
    java.util.Date var10 = var7.getMinimumDate();
    java.lang.String var11 = var7.getLabel();
    java.util.Date var12 = var7.getMinimumDate();
    var7.setLabelToolTip("org.jfree.chart.event.ChartChangeEvent[source=true]");
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var18 = var17.getLowerDate();
    org.jfree.data.Range var20 = org.jfree.data.Range.shift((org.jfree.data.Range)var17, (-1.0d));
    var7.setRangeWithMargins((org.jfree.data.Range)var17);
    float var22 = var7.getTickMarkInsideLength();
    java.awt.Shape var23 = var7.getLeftArrow();
    org.jfree.chart.axis.DateTickMarkPosition var24 = var7.getTickMarkPosition();
    var7.configure();
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var7, var26);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var29.setRangeWithMargins((org.jfree.data.Range)var32, false, true);
    var29.setTickMarkOutsideLength(100.0f);
    double var38 = var29.getLowerBound();
    java.lang.String var39 = var29.getLabel();
    var29.centerRange(1.0d);
    org.jfree.data.Range var42 = var29.getRange();
    var27.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var29);
    org.jfree.chart.util.RectangleInsets var44 = var27.getAxisOffset();
    org.jfree.chart.util.UnitType var45 = var44.getUnitType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "hi!"+ "'", var11.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-1.05d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test203"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.Layer var1 = null;
    java.util.Collection var2 = var0.getDomainMarkers(var1);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var6 = var5.getUpArrow();
    java.awt.Shape var7 = var5.getDownArrow();
    java.awt.Stroke var8 = var5.getTickMarkStroke();
    var3.setRangeCrosshairStroke(var8);
    var0.setDomainGridlineStroke(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var0.getRenderer((-1));
    org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge((-435));
    org.jfree.chart.LegendItemCollection var15 = var0.getLegendItems();
    java.awt.Paint var16 = var0.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test204"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    double var8 = var4.getItemMargin();
    boolean var10 = var4.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var11 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var12 = null;
    var11.rendererChanged(var12);
    var4.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var16.setRangeWithMargins((org.jfree.data.Range)var19, false, true);
    org.jfree.data.Range var23 = var16.getDefaultAutoRange();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.axis.AxisState var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    java.util.List var28 = var16.refreshTicks(var24, var25, var26, var27);
    java.awt.Font var29 = var16.getLabelFont();
    org.jfree.data.general.PieDataset var31 = null;
    org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D(var31);
    org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var32);
    var32.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var36 = var32.getURLGenerator();
    java.awt.Shape var37 = var32.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var38 = null;
    var32.setLabelGenerator(var38);
    org.jfree.data.general.PieDataset var41 = null;
    org.jfree.chart.plot.PiePlot3D var42 = new org.jfree.chart.plot.PiePlot3D(var41);
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var42);
    int var44 = var43.getBackgroundImageAlignment();
    var32.addChangeListener((org.jfree.chart.event.PlotChangeListener)var43);
    org.jfree.chart.renderer.category.IntervalBarRenderer var47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var49 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var47.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var49);
    org.jfree.chart.renderer.category.IntervalBarRenderer var51 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var53 = null;
    var51.setSeriesItemLabelFont(1, var53);
    boolean var55 = var51.getBaseSeriesVisibleInLegend();
    java.awt.Paint var58 = var51.getItemOutlinePaint(13, 100);
    var47.setBaseItemLabelPaint(var58);
    var32.setSectionPaint((java.lang.Comparable)(short)100, var58);
    org.jfree.chart.block.LabelBlock var61 = new org.jfree.chart.block.LabelBlock("Default Group", var29, var58);
    java.awt.geom.Rectangle2D var62 = var61.getBounds();
    org.jfree.chart.util.RectangleInsets var63 = var61.getPadding();
    var11.setInsets(var63);
    double var65 = var63.getBottom();
    var3.setInsets(var63);
    java.awt.Paint var67 = var3.getRangeGridlinePaint();
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var3);
    org.jfree.chart.renderer.category.IntervalBarRenderer var69 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var71 = null;
    var69.setSeriesItemLabelFont(1, var71);
    double var73 = var69.getItemMargin();
    boolean var75 = var69.isSeriesVisibleInLegend(1);
    java.lang.Boolean var77 = var69.getSeriesCreateEntities(1);
    org.jfree.chart.plot.CategoryPlot var78 = var69.getPlot();
    org.jfree.chart.plot.DrawingSupplier var79 = var69.getDrawingSupplier();
    boolean var80 = var69.getBaseItemLabelsVisible();
    var3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test205"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var3 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var2);
    org.jfree.data.DefaultKeyedValues2D var5 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var6 = var5.getRowKeys();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var10 = var8.lookupSeriesShape((-1));
    var7.setUpArrow(var10);
    java.util.Date var12 = var7.getMaximumDate();
    int var13 = var5.getColumnIndex((java.lang.Comparable)var12);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var17 = var15.lookupSeriesShape((-1));
    var14.setUpArrow(var17);
    var14.setLabel("");
    java.util.TimeZone var21 = var14.getTimeZone();
    org.jfree.data.time.Year var22 = new org.jfree.data.time.Year(var12, var21);
    java.lang.Number var23 = var2.getQ1Value((java.lang.Comparable)10L, (java.lang.Comparable)var22);
    int var24 = var2.getRowCount();
    java.lang.Comparable var26 = null;
    java.util.List var27 = var2.getOutliers((java.lang.Comparable)0.35d, var26);
    org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(100);
    int var30 = var29.getMonth();
    int var31 = var29.getYYYY();
    java.lang.Number var33 = var2.getMinRegularValue((java.lang.Comparable)var31, (java.lang.Comparable)"14-January-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test206"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var17.axisChanged(var22);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
    var25.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var28 = var25.getTitle();
    boolean var29 = var28.getExpandToFitSpace();
    java.lang.Object var30 = var28.clone();
    java.lang.String var31 = var28.getURLText();
    org.jfree.chart.event.TitleChangeEvent var32 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var28);
    org.jfree.chart.title.Title var33 = var32.getTitle();
    org.jfree.chart.event.TitleChangeEvent var34 = new org.jfree.chart.event.TitleChangeEvent(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test207"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(30, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test208"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var1 = var0.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test209"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Font var3 = var1.getLabelFont();
    java.text.DateFormat var4 = var1.getDateFormatOverride();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
    var7.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
    java.awt.Shape var12 = var7.getLegendItemShape();
    org.jfree.chart.util.Rotation var13 = var7.getDirection();
    org.jfree.chart.util.RectangleInsets var14 = var7.getInsets();
    var1.setLabelInsets(var14);
    org.jfree.chart.axis.DateTickMarkPosition var16 = var1.getTickMarkPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test210"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getDomainMarkers(10, var3);
    boolean var5 = var0.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test211"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    var1.setAutoTickUnitSelection(false, false);
    java.text.DateFormat var12 = null;
    var1.setDateFormatOverride(var12);
    org.jfree.data.KeyToGroupMap var16 = new org.jfree.data.KeyToGroupMap();
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var19 = var18.getUpArrow();
    boolean var20 = var16.equals((java.lang.Object)var19);
    boolean var22 = var16.equals((java.lang.Object)0.0f);
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var25 = var24.getUpArrow();
    java.awt.Shape var26 = var24.getDownArrow();
    java.util.Date var27 = var24.getMinimumDate();
    int var28 = var16.getGroupIndex((java.lang.Comparable)var27);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var31 = var30.getUpArrow();
    java.awt.Shape var32 = var30.getDownArrow();
    java.util.Date var33 = var30.getMinimumDate();
    java.lang.String var34 = var30.getLabel();
    java.util.Date var35 = var30.getMinimumDate();
    org.jfree.data.gantt.Task var36 = new org.jfree.data.gantt.Task("Pie 3D Plot", var27, var35);
    org.jfree.data.DefaultKeyedValues2D var37 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var38 = var37.getRowKeys();
    org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var40 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var42 = var40.lookupSeriesShape((-1));
    var39.setUpArrow(var42);
    java.util.Date var44 = var39.getMaximumDate();
    int var45 = var37.getColumnIndex((java.lang.Comparable)var44);
    org.jfree.data.gantt.Task var46 = new org.jfree.data.gantt.Task("org.jfree.chart.ChartColor[r=0,g=4,b=0]", var27, var44);
    var1.setMaximumDate(var44);
    org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var44);
    int var49 = var0.getIndex((java.lang.Comparable)var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "hi!"+ "'", var34.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test212"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var3.setRangeWithMargins((org.jfree.data.Range)var6, false, true);
    org.jfree.data.Range var10 = var3.getDefaultAutoRange();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.AxisState var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    java.util.List var15 = var3.refreshTicks(var11, var12, var13, var14);
    java.awt.Font var16 = var3.getLabelFont();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    var19.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var19.axisChanged(var24);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var16, (org.jfree.chart.plot.Plot)var19, false);
    var27.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var30 = var27.getTitle();
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.entity.EntityCollection var32 = null;
    org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
    java.awt.geom.Rectangle2D var34 = var33.getChartArea();
    var30.draw(var31, var34);
    org.jfree.chart.ChartColor var39 = new org.jfree.chart.ChartColor(0, 4, 0);
    var30.setPaint((java.awt.Paint)var39);
    java.lang.String var41 = var39.toString();
    org.jfree.chart.title.LegendGraphic var42 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var39);
    boolean var43 = var42.isShapeOutlineVisible();
    boolean var44 = var42.isShapeVisible();
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D(var46);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var47);
    var47.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var51 = var47.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var52 = null;
    var47.axisChanged(var52);
    var47.setDepthFactor(100.0d);
    boolean var56 = var42.equals((java.lang.Object)var47);
    java.awt.Shape var57 = var42.getShape();
    boolean var58 = var42.isLineVisible();
    var42.setShapeFilled(false);
    org.jfree.chart.util.RectangleAnchor var61 = var42.getShapeAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=4,b=0]"+ "'", var41.equals("org.jfree.chart.ChartColor[r=0,g=4,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test213"); }


    java.lang.Number[][] var0 = null;
    java.lang.Number[] var1 = null;
    java.lang.Number[][] var2 = new java.lang.Number[][] { var1};
    org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
    org.jfree.data.DefaultKeyedValues2D var4 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var5 = var4.getRowKeys();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var7.lookupSeriesShape((-1));
    var6.setUpArrow(var9);
    java.util.Date var11 = var6.getMaximumDate();
    int var12 = var4.getColumnIndex((java.lang.Comparable)var11);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var16 = var14.lookupSeriesShape((-1));
    var13.setUpArrow(var16);
    var13.setLabel("");
    java.util.TimeZone var20 = var13.getTimeZone();
    org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(var11, var20);
    boolean var22 = var3.equals((java.lang.Object)var20);
    java.util.List var23 = var3.getRowKeys();
    org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot();
    var24.setSectionDepth(8.0d);
    java.awt.Paint var27 = var24.getSeparatorPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var28 = var24.getLegendLabelToolTipGenerator();
    java.awt.Paint var29 = var24.getOutlinePaint();
    var24.setLabelLinkMargin((-7.0d));
    boolean var32 = var3.equals((java.lang.Object)var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var34 = var3.getSeriesKey(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test214"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var3 = var2.getLowerDate();
    org.jfree.data.Range var6 = org.jfree.data.Range.shift((org.jfree.data.Range)var2, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, 1.0d);
    org.jfree.chart.util.Size2D var11 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    org.jfree.chart.util.Size2D var12 = var8.calculateConstrainedSize(var11);
    org.jfree.data.Range var13 = var8.getWidthRange();
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var13, var14);
    boolean var18 = var15.intersects(4.0d, 1.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test215"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getLeftArrow();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var5 = var4.getLowerDate();
    org.jfree.data.Range var8 = org.jfree.data.Range.shift((org.jfree.data.Range)var4, 0.0d, false);
    boolean var11 = var4.intersects(10.0d, (-1.05d));
    org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var15 = var14.getLowerDate();
    org.jfree.data.Range var18 = org.jfree.data.Range.shift((org.jfree.data.Range)var14, 0.0d, false);
    boolean var21 = var14.intersects(10.0d, (-1.05d));
    double var22 = var14.getLowerBound();
    org.jfree.data.Range var23 = org.jfree.data.Range.combine((org.jfree.data.Range)var4, (org.jfree.data.Range)var14);
    var0.setDefaultAutoRange(var23);
    double var25 = var0.getLowerBound();
    var0.setFixedDimension(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test216"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    var2.setPieIndex((-10289251));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test217"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesLinesVisible(15, (java.lang.Boolean)true);
    org.jfree.chart.LegendItem var6 = var0.getLegendItem(13, 15);
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var0.getItemLabelGenerator(1, 0);
    java.awt.Paint var12 = var0.getItemOutlinePaint((-1), (-1));
    boolean var14 = var0.isSeriesVisible(1900);
    int var15 = var0.getPassCount();
    java.lang.Boolean var17 = var0.getSeriesShapesFilled(100);
    int var18 = var0.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test218"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    var0.clear();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var3.setRangeWithMargins((org.jfree.data.Range)var6, false, true);
    org.jfree.data.Range var10 = var3.getDefaultAutoRange();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.AxisState var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    java.util.List var15 = var3.refreshTicks(var11, var12, var13, var14);
    java.awt.Font var16 = var3.getLabelFont();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    var19.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var19.axisChanged(var24);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var16, (org.jfree.chart.plot.Plot)var19, false);
    var27.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var30 = var27.getTitle();
    boolean var31 = var30.getExpandToFitSpace();
    java.lang.Object var32 = var30.clone();
    java.lang.String var33 = var30.getURLText();
    var30.setURLText("ERROR : Relative To String");
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
    var39.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var43 = var39.getURLGenerator();
    java.awt.Shape var44 = var39.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var45 = null;
    var39.setLabelGenerator(var45);
    java.lang.Object var47 = var39.clone();
    boolean var48 = var36.equals((java.lang.Object)var39);
    org.jfree.chart.util.SortOrder var49 = var36.getRowRenderingOrder();
    var36.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.GanttRenderer var52 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.plot.CategoryMarker var54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var54.setKey((java.lang.Comparable)false);
    boolean var57 = var54.getDrawAsLine();
    boolean var58 = var52.equals((java.lang.Object)var54);
    var36.addDomainMarker(var54);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var62 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
    org.jfree.chart.plot.IntervalMarker var65 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var66 = var65.getAlpha();
    java.awt.Paint var67 = var65.getPaint();
    boolean var68 = var62.equals((java.lang.Object)var67);
    java.awt.Paint var69 = var62.getWallPaint();
    var36.setDomainGridlinePaint(var69);
    org.jfree.chart.axis.DateAxis var71 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var74 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var71.setRangeWithMargins((org.jfree.data.Range)var74, false, true);
    org.jfree.data.Range var78 = var71.getDefaultAutoRange();
    var71.setAutoTickUnitSelection(false, false);
    java.text.DateFormat var82 = null;
    var71.setDateFormatOverride(var82);
    org.jfree.data.Range var84 = var71.getDefaultAutoRange();
    org.jfree.chart.axis.ValueAxis[] var85 = new org.jfree.chart.axis.ValueAxis[] { var71};
    var36.setRangeAxes(var85);
    var0.add((org.jfree.chart.block.Block)var30, (java.lang.Object)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test219"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var17.axisChanged(var22);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
    var25.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var28 = var25.getTitle();
    boolean var29 = var28.getExpandToFitSpace();
    java.lang.Object var30 = var28.clone();
    java.lang.String var31 = var28.getText();
    org.jfree.chart.util.RectangleInsets var32 = var28.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=true]"+ "'", var31.equals("org.jfree.chart.event.ChartChangeEvent[source=true]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test220"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Font var3 = var1.getLabelFont();
    java.text.DateFormat var4 = var1.getDateFormatOverride();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
    var7.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
    java.awt.Shape var12 = var7.getLegendItemShape();
    org.jfree.chart.util.Rotation var13 = var7.getDirection();
    org.jfree.chart.util.RectangleInsets var14 = var7.getInsets();
    var1.setLabelInsets(var14);
    org.jfree.data.time.DateRange var18 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var19 = var18.getLowerDate();
    java.util.Date var20 = var18.getUpperDate();
    double var21 = var18.getLowerBound();
    var1.setDefaultAutoRange((org.jfree.data.Range)var18);
    java.text.DateFormat var23 = null;
    var1.setDateFormatOverride(var23);
    var1.setLabel("ChartChangeEventType.GENERAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1.0d));

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test221"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    var1.setVisible(false);
    var1.setAutoRange(false);
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var8 = var7.getUpArrow();
    java.awt.Shape var9 = var7.getDownArrow();
    java.util.Date var10 = var7.getMinimumDate();
    java.lang.String var11 = var7.getLabel();
    java.util.Date var12 = var7.getMinimumDate();
    var7.setLabelToolTip("org.jfree.chart.event.ChartChangeEvent[source=true]");
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var18 = var17.getLowerDate();
    org.jfree.data.Range var20 = org.jfree.data.Range.shift((org.jfree.data.Range)var17, (-1.0d));
    var7.setRangeWithMargins((org.jfree.data.Range)var17);
    float var22 = var7.getTickMarkInsideLength();
    java.awt.Shape var23 = var7.getLeftArrow();
    org.jfree.chart.axis.DateTickMarkPosition var24 = var7.getTickMarkPosition();
    var7.configure();
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var7, var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRange(26.0d, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "hi!"+ "'", var11.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test222"); }


    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var6 = var5.getTransparency();
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder(10.0d, 10.0d, 100.0d, 1.0d, (java.awt.Paint)var5);
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var10 = null;
    var8.setSeriesItemLabelFont(1, var10);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
    var8.setSeriesToolTipGenerator(1, var13);
    boolean var15 = var7.equals((java.lang.Object)var8);
    java.awt.Paint var18 = var8.getItemOutlinePaint(2014, 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test223"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    var2.setShadowYOffset(1.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var8.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getBaseItemLabelGenerator();
    double var11 = var8.getBase();
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    var2.setOutlineStroke(var12);
    var2.setDepthFactor(0.0d);
    org.jfree.chart.plot.Plot var16 = var2.getRootPlot();
    org.jfree.data.general.PieDataset var17 = var2.getDataset();
    java.awt.Paint var18 = var2.getLabelShadowPaint();
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot();
    var19.setAngleLabelsVisible(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var22 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var23 = var22.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var24 = var22.getBaseItemLabelGenerator();
    double var25 = var22.getBase();
    java.awt.Stroke var26 = var22.getBaseOutlineStroke();
    var19.setAngleGridlineStroke(var26);
    var2.setLabelLinkStroke(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test224"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.plot.CategoryMarker var2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var2.setKey((java.lang.Comparable)false);
    boolean var5 = var2.getDrawAsLine();
    boolean var6 = var0.equals((java.lang.Object)var2);
    double var7 = var0.getStartPercent();
    java.awt.Paint var8 = var0.getIncompletePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.35d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test225"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    org.jfree.chart.LegendItem var9 = var0.getLegendItem((-435), (-1));
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    double var15 = var14.getCategoryMargin();
    var14.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var19 = var14.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var20 = var10.getCategoriesForAxis(var14);
    var10.setRangeCrosshairValue(10.0d);
    org.jfree.chart.axis.AxisSpace var23 = null;
    var10.setFixedRangeAxisSpace(var23);
    java.awt.Stroke var25 = var10.getDomainGridlineStroke();
    var0.setBaseStroke(var25);
    org.jfree.chart.renderer.category.IntervalBarRenderer var28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var30 = null;
    var28.setSeriesItemLabelFont(1, var30);
    double var32 = var28.getItemMargin();
    boolean var34 = var28.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var37 = var28.getNegativeItemLabelPosition(13, 4);
    var0.setSeriesPositiveItemLabelPosition(30, var37, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test226"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.DrawingSupplier var4 = null;
    var0.setDrawingSupplier(var4);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    double var8 = var7.getCategoryMargin();
    org.jfree.chart.axis.CategoryAxis[] var9 = new org.jfree.chart.axis.CategoryAxis[] { var7};
    var6.setDomainAxes(var9);
    var0.setDomainAxes(var9);
    org.jfree.chart.plot.PlotOrientation var12 = var0.getOrientation();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.title.LegendTitle var15 = var13.getLegend(1969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test227"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("UnitType.ABSOLUTE");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test228"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
    int var3 = var2.getPassCount();
    java.awt.Paint[] var4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setMaximumCategoryLabelLines((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var10 = null;
    var8.setSeriesItemLabelFont(1, var10);
    boolean var12 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var15 = var8.getItemOutlinePaint(13, 100);
    org.jfree.chart.ChartColor var19 = new org.jfree.chart.ChartColor(0, 4, 0);
    boolean var20 = org.jfree.chart.util.PaintUtilities.equal(var15, (java.awt.Paint)var19);
    var5.setAxisLinePaint((java.awt.Paint)var19);
    java.awt.Paint[] var22 = new java.awt.Paint[] { var19};
    java.awt.Stroke[] var23 = null;
    org.jfree.chart.plot.CategoryMarker var25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var25.setKey((java.lang.Comparable)false);
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D(var29);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var30);
    java.awt.Shape var32 = var30.getLegendItemShape();
    var25.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var30);
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var37 = var36.getUpArrow();
    java.awt.Shape var38 = var36.getDownArrow();
    java.awt.Stroke var39 = var36.getTickMarkStroke();
    var34.setRangeCrosshairStroke(var39);
    java.awt.geom.Point2D var41 = var34.getQuadrantOrigin();
    java.lang.String var42 = var34.getPlotType();
    java.awt.Stroke var43 = var34.getRangeZeroBaselineStroke();
    var25.setOutlineStroke(var43);
    java.awt.Stroke[] var45 = new java.awt.Stroke[] { var43};
    java.awt.Shape[] var46 = null;
    org.jfree.chart.plot.DefaultDrawingSupplier var47 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var22, var23, var45, var46);
    java.awt.Stroke var48 = var47.getNextOutlineStroke();
    java.awt.Paint var49 = var47.getNextPaint();
    boolean var50 = var2.equals((java.lang.Object)var47);
    java.awt.Stroke var51 = var47.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "XY Plot"+ "'", var42.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test229"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
//     org.jfree.chart.util.RectangleInsets var3 = var0.getAxisOffset();
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = var0.getRendererForDataset(var4);
//     java.awt.Stroke var6 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.plot.DatasetRenderingOrder var7 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var11);
//     var11.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var15 = var11.getURLGenerator();
//     java.awt.Shape var16 = var11.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var17 = null;
//     var11.setLabelGenerator(var17);
//     java.lang.Object var19 = var11.clone();
//     boolean var20 = var8.equals((java.lang.Object)var11);
//     org.jfree.chart.util.SortOrder var21 = var8.getRowRenderingOrder();
//     var8.setDrawSharedDomainAxis(true);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var26 = null;
//     var24.setSeriesItemLabelFont(1, var26);
//     double var28 = var24.getItemMargin();
//     boolean var30 = var24.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var31 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var32 = null;
//     var31.rendererChanged(var32);
//     var24.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var31);
//     org.jfree.data.general.Dataset var36 = null;
//     org.jfree.data.general.DatasetChangeEvent var37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var36);
//     var31.datasetChanged(var37);
//     var8.datasetChanged(var37);
//     org.jfree.data.general.Dataset var40 = var37.getDataset();
//     var0.datasetChanged(var37);
//     boolean var42 = var0.isRangeZeroBaselineVisible();
//     java.awt.Stroke var43 = var0.getDomainCrosshairStroke();
//     org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.IntervalMarker var47 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var48 = var47.getAlpha();
//     java.awt.Paint var49 = var47.getPaint();
//     var44.setAngleLabelPaint(var49);
//     java.awt.Paint var51 = var44.getAngleLabelPaint();
//     java.awt.Stroke var52 = var44.getRadiusGridlineStroke();
//     var44.setRadiusGridlinesVisible(false);
//     boolean var55 = var44.isAngleLabelsVisible();
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var58 = var57.getFixedLegendItems();
//     java.awt.geom.Point2D var59 = var57.getQuadrantOrigin();
//     org.jfree.chart.plot.DatasetRenderingOrder var60 = var57.getDatasetRenderingOrder();
//     java.awt.geom.Point2D var61 = var57.getQuadrantOrigin();
//     java.awt.Paint var62 = var57.getDomainTickBandPaint();
//     org.jfree.chart.ChartRenderingInfo var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = new org.jfree.chart.plot.PlotRenderingInfo(var65);
//     var57.handleClick(0, 15, var66);
//     org.jfree.chart.renderer.RendererState var68 = new org.jfree.chart.renderer.RendererState(var66);
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.DateAxis var71 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var72 = var71.getUpArrow();
//     java.awt.Shape var73 = var71.getDownArrow();
//     java.awt.Stroke var74 = var71.getTickMarkStroke();
//     var69.setRangeCrosshairStroke(var74);
//     java.awt.geom.Point2D var76 = var69.getQuadrantOrigin();
//     var44.zoomDomainAxes(0.35d, var66, var76);
//     var0.setQuadrantOrigin(var76);
//     
//     // Checks the contract:  equals-hashcode on var0 and var57
//     assertTrue("Contract failed: equals-hashcode on var0 and var57", var0.equals(var57) ? var0.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var0
//     assertTrue("Contract failed: equals-hashcode on var57 and var0", var57.equals(var0) ? var57.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test230"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    boolean var1 = var0.getGenerateEntities();
    var0.setGenerateEntities(true);
    var0.setGenerateEntities(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test231"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    double var8 = var4.getItemMargin();
    boolean var10 = var4.isSeriesVisibleInLegend(1);
    java.lang.Boolean var12 = var4.getSeriesCreateEntities(1);
    java.awt.Paint var14 = var4.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var17 = null;
    var15.setSeriesItemLabelFont(1, var17);
    boolean var19 = var15.getBaseSeriesVisibleInLegend();
    java.awt.Paint var22 = var15.getItemOutlinePaint(13, 100);
    var4.setBaseFillPaint(var22, true);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var29 = var28.getUpArrow();
    java.awt.Shape var30 = var28.getDownArrow();
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var4.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var31, var32);
    java.awt.Shape var36 = var4.getItemShape(255, 2);
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var38.setRangeWithMargins((org.jfree.data.Range)var41, false, true);
    org.jfree.data.Range var45 = var38.getDefaultAutoRange();
    java.awt.Graphics2D var46 = null;
    org.jfree.chart.axis.AxisState var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    org.jfree.chart.util.RectangleEdge var49 = null;
    java.util.List var50 = var38.refreshTicks(var46, var47, var48, var49);
    java.awt.Font var51 = var38.getLabelFont();
    org.jfree.data.general.PieDataset var53 = null;
    org.jfree.chart.plot.PiePlot3D var54 = new org.jfree.chart.plot.PiePlot3D(var53);
    org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var54);
    var54.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var58 = var54.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var59 = null;
    var54.axisChanged(var59);
    org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var51, (org.jfree.chart.plot.Plot)var54, false);
    var62.setBackgroundImageAlignment(10);
    org.jfree.chart.plot.Plot var65 = var62.getPlot();
    java.awt.Paint var66 = var62.getBackgroundPaint();
    org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("hi!", "DateTickMarkPosition.START", "SortOrder.ASCENDING", "ERROR : Relative To String", var36, var66);
    java.awt.Stroke var68 = var67.getOutlineStroke();
    org.jfree.data.general.Dataset var69 = var67.getDataset();
    java.awt.Paint var70 = var67.getLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test232"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(1388563200000L, 15, (-1));

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test233"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.Comparable var11 = var10.getAggregatedItemsKey();
    boolean var12 = var5.hasListener((java.util.EventListener)var10);
    var10.setAggregatedItemsKey((java.lang.Comparable)0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Other"+ "'", var11.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test234"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var3 = var2.getLowerDate();
    org.jfree.data.Range var6 = org.jfree.data.Range.shift((org.jfree.data.Range)var2, 0.0d, false);
    boolean var9 = var2.intersects(10.0d, (-1.05d));
    double var11 = var2.constrain(12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test235"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    double var5 = var4.getCategoryMargin();
    var4.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var9 = var4.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var10 = var0.getCategoriesForAxis(var4);
    java.awt.Paint var11 = var0.getDomainGridlinePaint();
    int var12 = var0.getBackgroundImageAlignment();
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
    java.awt.geom.Point2D var15 = var13.getQuadrantOrigin();
    org.jfree.chart.util.RectangleInsets var16 = var13.getAxisOffset();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = var13.getRendererForDataset(var17);
    java.awt.Stroke var19 = var13.getRangeCrosshairStroke();
    org.jfree.chart.plot.DatasetRenderingOrder var20 = var13.getDatasetRenderingOrder();
    var0.setDatasetRenderingOrder(var20);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var22.setAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test236"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     java.awt.geom.Point2D var3 = var1.getQuadrantOrigin();
//     var1.setDomainCrosshairValue(0.0d);
//     var1.clearRangeMarkers(96);
//     var1.clearRangeMarkers(2);
//     var1.setRangeGridlinesVisible(false);
//     var1.setDomainCrosshairValue(90.0d, true);
//     int var15 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var16 = null;
//     var0.peg(var16);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test237"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    var0.setAngleLabelsVisible(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    double var6 = var3.getBase();
    java.awt.Stroke var7 = var3.getBaseOutlineStroke();
    var0.setAngleGridlineStroke(var7);
    boolean var9 = var0.isRadiusGridlinesVisible();
    java.awt.Paint var10 = var0.getAngleLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test238"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    var0.clear();
    var0.clear();
    var0.clear();

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test239"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelOffset();
    java.awt.geom.Rectangle2D var11 = null;
    var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var9, var11);
    org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var15 = var13.lookupSeriesShape((-1));
    org.jfree.chart.labels.ItemLabelPosition var17 = var13.getSeriesPositiveItemLabelPosition((-1));
    var2.setBasePositiveItemLabelPosition(var17, false);
    java.awt.Paint var20 = var2.getBaseOutlinePaint();
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var22 = var21.getFixedLegendItems();
    java.awt.geom.Point2D var23 = var21.getQuadrantOrigin();
    org.jfree.chart.util.RectangleInsets var24 = var21.getAxisOffset();
    org.jfree.chart.LegendItemCollection var25 = var21.getLegendItems();
    boolean var26 = var2.equals((java.lang.Object)var21);
    boolean var27 = var21.isOutlineVisible();
    java.awt.Paint var28 = var21.getDomainCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test240"); }


    java.lang.Number[][] var0 = null;
    java.lang.Number[] var1 = null;
    java.lang.Number[][] var2 = new java.lang.Number[][] { var1};
    org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
    org.jfree.data.DefaultKeyedValues2D var4 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var5 = var4.getRowKeys();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var7.lookupSeriesShape((-1));
    var6.setUpArrow(var9);
    java.util.Date var11 = var6.getMaximumDate();
    int var12 = var4.getColumnIndex((java.lang.Comparable)var11);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var16 = var14.lookupSeriesShape((-1));
    var13.setUpArrow(var16);
    var13.setLabel("");
    java.util.TimeZone var20 = var13.getTimeZone();
    org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(var11, var20);
    boolean var22 = var3.equals((java.lang.Object)var20);
    org.jfree.chart.renderer.category.StackedBarRenderer var24 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    double var25 = var24.getBase();
    org.jfree.data.time.DateRange var28 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var29 = var28.getLowerDate();
    org.jfree.data.Range var32 = org.jfree.data.Range.shift((org.jfree.data.Range)var28, 0.0d, false);
    boolean var33 = var24.equals((java.lang.Object)0.0d);
    int var34 = var24.getPassCount();
    boolean var35 = var3.equals((java.lang.Object)var24);
    org.jfree.chart.util.HorizontalAlignment var37 = null;
    org.jfree.chart.util.VerticalAlignment var38 = null;
    org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var42 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var43 = null;
    var42.addChangeListener(var43);
    org.jfree.chart.title.LegendItemBlockContainer var46 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var41, (org.jfree.data.general.Dataset)var42, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var47 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.renderer.category.StackedAreaRenderer var49 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var50 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var52 = null;
    var50.setSeriesItemLabelFont(1, var52);
    double var54 = var50.getItemMargin();
    boolean var56 = var50.isSeriesVisibleInLegend(1);
    java.lang.Boolean var58 = var50.getSeriesCreateEntities(1);
    java.awt.Paint var60 = var50.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var61 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var63 = null;
    var61.setSeriesItemLabelFont(1, var63);
    boolean var65 = var61.getBaseSeriesVisibleInLegend();
    java.awt.Paint var68 = var61.getItemOutlinePaint(13, 100);
    var50.setBaseFillPaint(var68, true);
    var50.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var74 = var50.getBaseNegativeItemLabelPosition();
    boolean var75 = var49.equals((java.lang.Object)var74);
    org.jfree.data.DefaultKeyedValues2D var76 = new org.jfree.data.DefaultKeyedValues2D();
    boolean var77 = var49.equals((java.lang.Object)var76);
    org.jfree.data.time.Year var78 = new org.jfree.data.time.Year();
    java.util.Date var79 = var78.getEnd();
    org.jfree.data.time.RegularTimePeriod var80 = var78.previous();
    int var81 = var76.getColumnIndex((java.lang.Comparable)var78);
    java.lang.Number var83 = var47.getQ3Value((java.lang.Comparable)var78, (java.lang.Comparable)"Nearest");
    org.jfree.data.general.PieDataset var84 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var42, (java.lang.Comparable)var78);
    java.lang.Number var85 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setStartValue(0, (java.lang.Comparable)var78, var85);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test241"); }


    java.lang.Number[][] var0 = null;
    java.lang.Number[] var1 = null;
    java.lang.Number[][] var2 = new java.lang.Number[][] { var1};
    org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
    org.jfree.data.DefaultKeyedValues2D var4 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var5 = var4.getRowKeys();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var7.lookupSeriesShape((-1));
    var6.setUpArrow(var9);
    java.util.Date var11 = var6.getMaximumDate();
    int var12 = var4.getColumnIndex((java.lang.Comparable)var11);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var16 = var14.lookupSeriesShape((-1));
    var13.setUpArrow(var16);
    var13.setLabel("");
    java.util.TimeZone var20 = var13.getTimeZone();
    org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(var11, var20);
    boolean var22 = var3.equals((java.lang.Object)var20);
    java.util.List var23 = var3.getColumnKeys();
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var27.setRangeWithMargins((org.jfree.data.Range)var30, false, true);
    org.jfree.data.Range var34 = var27.getDefaultAutoRange();
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.axis.AxisState var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleEdge var38 = null;
    java.util.List var39 = var27.refreshTicks(var35, var36, var37, var38);
    java.awt.Font var40 = var27.getLabelFont();
    org.jfree.data.general.PieDataset var42 = null;
    org.jfree.chart.plot.PiePlot3D var43 = new org.jfree.chart.plot.PiePlot3D(var42);
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var43);
    var43.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var47 = var43.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var48 = null;
    var43.axisChanged(var48);
    org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var40, (org.jfree.chart.plot.Plot)var43, false);
    var51.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var54 = var51.getTitle();
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.entity.EntityCollection var56 = null;
    org.jfree.chart.ChartRenderingInfo var57 = new org.jfree.chart.ChartRenderingInfo(var56);
    java.awt.geom.Rectangle2D var58 = var57.getChartArea();
    var54.draw(var55, var58);
    org.jfree.chart.ChartColor var63 = new org.jfree.chart.ChartColor(0, 4, 0);
    var54.setPaint((java.awt.Paint)var63);
    java.lang.String var65 = var63.toString();
    org.jfree.chart.title.LegendGraphic var66 = new org.jfree.chart.title.LegendGraphic(var25, (java.awt.Paint)var63);
    boolean var67 = var66.isShapeOutlineVisible();
    boolean var68 = var66.isShapeVisible();
    org.jfree.chart.axis.AxisSpace var69 = new org.jfree.chart.axis.AxisSpace();
    double var70 = var69.getBottom();
    var69.setTop(0.0d);
    var69.setRight((-0.9500000000000001d));
    var69.setBottom(2.0d);
    double var77 = var69.getTop();
    boolean var78 = var66.equals((java.lang.Object)var77);
    org.jfree.chart.plot.RingPlot var79 = new org.jfree.chart.plot.RingPlot();
    var79.setSectionDepth(8.0d);
    java.awt.Paint var82 = var79.getSeparatorPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var83 = var79.getLegendLabelToolTipGenerator();
    java.awt.Paint var84 = var79.getOutlinePaint();
    var66.setOutlinePaint(var84);
    boolean var86 = var3.equals((java.lang.Object)var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=4,b=0]"+ "'", var65.equals("org.jfree.chart.ChartColor[r=0,g=4,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test242"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    var0.setDomainCrosshairValue(0.0d);
    var0.clearRangeMarkers(96);
    boolean var7 = var0.isDomainCrosshairVisible();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var9.setRangeWithMargins((org.jfree.data.Range)var12, false, true);
    var9.setTickMarkOutsideLength(100.0f);
    org.jfree.data.time.DateRange var18 = new org.jfree.data.time.DateRange();
    var9.setRange((org.jfree.data.Range)var18);
    var0.setRangeAxis(96, (org.jfree.chart.axis.ValueAxis)var9, true);
    org.jfree.chart.util.RectangleEdge var23 = var0.getDomainAxisEdge(55);
    org.jfree.chart.plot.CategoryMarker var25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var25.setKey((java.lang.Comparable)1.0d);
    var25.setDrawAsLine(true);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var25.notifyListeners(var30);
    org.jfree.chart.util.Layer var32 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var25, var32);
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var38 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var35.setRangeWithMargins((org.jfree.data.Range)var38, false, true);
    org.jfree.data.Range var42 = var35.getDefaultAutoRange();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.axis.AxisState var44 = null;
    java.awt.geom.Rectangle2D var45 = null;
    org.jfree.chart.util.RectangleEdge var46 = null;
    java.util.List var47 = var35.refreshTicks(var43, var44, var45, var46);
    java.awt.Font var48 = var35.getLabelFont();
    org.jfree.data.general.PieDataset var50 = null;
    org.jfree.chart.plot.PiePlot3D var51 = new org.jfree.chart.plot.PiePlot3D(var50);
    org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var51);
    var51.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var55 = var51.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var56 = null;
    var51.axisChanged(var56);
    org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var48, (org.jfree.chart.plot.Plot)var51, false);
    var59.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var62 = var59.getTitle();
    java.awt.Graphics2D var63 = null;
    org.jfree.chart.entity.EntityCollection var64 = null;
    org.jfree.chart.ChartRenderingInfo var65 = new org.jfree.chart.ChartRenderingInfo(var64);
    java.awt.geom.Rectangle2D var66 = var65.getChartArea();
    var62.draw(var63, var66);
    org.jfree.chart.ChartColor var71 = new org.jfree.chart.ChartColor(0, 4, 0);
    var62.setPaint((java.awt.Paint)var71);
    org.jfree.data.general.PieDataset var74 = null;
    org.jfree.chart.plot.PiePlot3D var75 = new org.jfree.chart.plot.PiePlot3D(var74);
    org.jfree.chart.JFreeChart var76 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var75);
    int var77 = var76.getBackgroundImageAlignment();
    var62.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var76);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var76);
    org.jfree.chart.util.Layer var81 = null;
    java.util.Collection var82 = var0.getDomainMarkers(2, var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test243"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelOffset();
    java.awt.geom.Rectangle2D var11 = null;
    var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var9, var11);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D(var14);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var15);
    var15.setShadowYOffset(0.0d);
    double var19 = var15.getMaximumLabelWidth();
    org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var22 = null;
    var20.setSeriesItemLabelFont(1, var22);
    boolean var24 = var20.getBaseSeriesVisibleInLegend();
    java.awt.Paint var27 = var20.getItemOutlinePaint(13, 100);
    var15.setBackgroundPaint(var27);
    var2.setWallPaint(var27);
    double var30 = var2.getXOffset();
    java.awt.Paint var31 = var2.getBaseFillPaint();
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    var33.setLowerMargin((-0.9500000000000001d));
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
    boolean var37 = var36.isAxisLineVisible();
    org.jfree.chart.renderer.category.IntervalBarRenderer var38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var40 = null;
    var38.setSeriesItemLabelFont(1, var40);
    boolean var42 = var38.getBaseSeriesVisibleInLegend();
    java.awt.Paint var45 = var38.getItemOutlinePaint(13, 100);
    java.awt.Shape var48 = var38.getItemShape((-1), 1);
    org.jfree.chart.entity.AxisLabelEntity var51 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var36, var48, "hi!", "Default Group");
    var33.setRightArrow(var48);
    org.jfree.chart.util.HorizontalAlignment var53 = null;
    org.jfree.chart.util.VerticalAlignment var54 = null;
    org.jfree.chart.block.FlowArrangement var57 = new org.jfree.chart.block.FlowArrangement(var53, var54, 100.0d, 0.0d);
    org.jfree.chart.util.HorizontalAlignment var58 = null;
    org.jfree.chart.util.VerticalAlignment var59 = null;
    org.jfree.chart.block.ColumnArrangement var62 = new org.jfree.chart.block.ColumnArrangement(var58, var59, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var63 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var64 = null;
    var63.addChangeListener(var64);
    org.jfree.chart.title.LegendItemBlockContainer var67 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var62, (org.jfree.data.general.Dataset)var63, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    boolean var68 = var67.isEmpty();
    java.util.List var69 = var67.getBlocks();
    java.awt.Graphics2D var70 = null;
    org.jfree.data.time.DateRange var73 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var74 = var73.getLowerDate();
    org.jfree.data.Range var77 = org.jfree.data.Range.shift((org.jfree.data.Range)var73, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var79 = new org.jfree.chart.block.RectangleConstraint(var77, 1.0d);
    org.jfree.chart.util.Size2D var80 = var57.arrange((org.jfree.chart.block.BlockContainer)var67, var70, var79);
    java.lang.String var81 = var80.toString();
    org.jfree.chart.axis.CategoryLabelPosition var84 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var85 = var84.getWidthRatio();
    double var86 = var84.getAngle();
    org.jfree.chart.util.RectangleAnchor var87 = var84.getCategoryAnchor();
    java.awt.geom.Rectangle2D var88 = org.jfree.chart.util.RectangleAnchor.createRectangle(var80, 4.0d, 90.0d, var87);
    java.awt.Shape var91 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var48, var87, 1.0d, 90.0d);
    boolean var92 = var2.equals((java.lang.Object)90.0d);
    double var93 = var2.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var81 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var81.equals("Size2D[width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.2d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test244"); }


    java.lang.Number[][] var1 = null;
    java.lang.Number[] var2 = null;
    java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
    org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
    org.jfree.data.DefaultKeyedValues2D var5 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var6 = var5.getRowKeys();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var10 = var8.lookupSeriesShape((-1));
    var7.setUpArrow(var10);
    java.util.Date var12 = var7.getMaximumDate();
    int var13 = var5.getColumnIndex((java.lang.Comparable)var12);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var17 = var15.lookupSeriesShape((-1));
    var14.setUpArrow(var17);
    var14.setLabel("");
    java.util.TimeZone var21 = var14.getTimeZone();
    org.jfree.data.time.Year var22 = new org.jfree.data.time.Year(var12, var21);
    boolean var23 = var4.equals((java.lang.Object)var21);
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("", var21);
    java.awt.Paint var25 = var24.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test245"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var1 = var0.getWidthRatio();
    boolean var3 = var0.equals((java.lang.Object)"GradientPaintTransformType.VERTICAL");
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var5 = var4.getWidthRatio();
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var9 = var8.getLowerDate();
    org.jfree.data.Range var12 = org.jfree.data.Range.shift((org.jfree.data.Range)var8, 0.0d, false);
    java.util.Date var13 = var8.getUpperDate();
    boolean var14 = var4.equals((java.lang.Object)var13);
    double var15 = var4.getAngle();
    org.jfree.chart.text.TextAnchor var16 = var4.getRotationAnchor();
    float var17 = var4.getWidthRatio();
    org.jfree.chart.axis.CategoryLabelPosition var18 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var19 = var18.getWidthRatio();
    double var20 = var18.getAngle();
    org.jfree.chart.util.RectangleAnchor var21 = var18.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var22 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22);
    org.jfree.chart.axis.CategoryLabelPositions var24 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var4, var18, var22);
    java.lang.Object var25 = null;
    boolean var26 = var0.equals(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test246"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
    int var4 = var3.getSegmentsIncluded();
    java.util.Date var6 = var3.getDate((-2208927600000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test247"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var5.setRangeWithMargins((org.jfree.data.Range)var8, false, true);
    org.jfree.data.Range var12 = var5.getDefaultAutoRange();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.axis.AxisState var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.util.RectangleEdge var16 = null;
    java.util.List var17 = var5.refreshTicks(var13, var14, var15, var16);
    java.awt.Font var18 = var5.getLabelFont();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D(var20);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var21);
    var21.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var25 = var21.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var26 = null;
    var21.axisChanged(var26);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var18, (org.jfree.chart.plot.Plot)var21, false);
    org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("GradientPaintTransformType.VERTICAL", var18);
    var0.removeFragment(var30);
    float var32 = var30.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0f);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test248"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    var0.setSectionDepth(8.0d);
    java.awt.Paint var3 = var0.getSeparatorPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var0.getLegendLabelToolTipGenerator();
    java.awt.Paint var5 = var0.getOutlinePaint();
    var0.setLabelLinkMargin((-7.0d));
    org.jfree.chart.urls.PieURLGenerator var8 = var0.getURLGenerator();
    java.awt.Paint var9 = var0.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test249"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelOffset();
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
    org.jfree.chart.util.GradientPaintTransformer var8 = var4.getGradientPaintTransformer();
    var2.setGradientPaintTransformer(var8);
    java.awt.Paint var10 = var2.getPaint();
    org.jfree.chart.util.RectangleAnchor var11 = var2.getLabelAnchor();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D(var14);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var15);
    var15.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var19 = var15.getURLGenerator();
    java.awt.Shape var20 = var15.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var21 = null;
    var15.setLabelGenerator(var21);
    java.lang.Object var23 = var15.clone();
    boolean var24 = var12.equals((java.lang.Object)var15);
    org.jfree.chart.util.SortOrder var25 = var12.getRowRenderingOrder();
    var12.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.IntervalBarRenderer var28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var30 = null;
    var28.setSeriesItemLabelFont(1, var30);
    double var32 = var28.getItemMargin();
    boolean var34 = var28.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var35 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var36 = null;
    var35.rendererChanged(var36);
    var28.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var35);
    org.jfree.data.general.Dataset var40 = null;
    org.jfree.data.general.DatasetChangeEvent var41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var40);
    var35.datasetChanged(var41);
    var12.datasetChanged(var41);
    org.jfree.chart.util.RectangleEdge var44 = var12.getRangeAxisEdge();
    org.jfree.chart.util.Layer var46 = null;
    java.util.Collection var47 = var12.getDomainMarkers(0, var46);
    org.jfree.data.xy.XYDataset var48 = null;
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var52 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var49.setRangeWithMargins((org.jfree.data.Range)var52, false, true);
    org.jfree.data.Range var56 = var49.getDefaultAutoRange();
    java.awt.Graphics2D var57 = null;
    org.jfree.chart.axis.AxisState var58 = null;
    java.awt.geom.Rectangle2D var59 = null;
    org.jfree.chart.util.RectangleEdge var60 = null;
    java.util.List var61 = var49.refreshTicks(var57, var58, var59, var60);
    java.awt.Font var62 = var49.getLabelFont();
    org.jfree.chart.plot.MultiplePiePlot var63 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var64 = var63.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var68 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var65.setRangeWithMargins((org.jfree.data.Range)var68, false, true);
    org.jfree.data.Range var72 = var65.getDefaultAutoRange();
    java.awt.Graphics2D var73 = null;
    org.jfree.chart.axis.AxisState var74 = null;
    java.awt.geom.Rectangle2D var75 = null;
    org.jfree.chart.util.RectangleEdge var76 = null;
    java.util.List var77 = var65.refreshTicks(var73, var74, var75, var76);
    org.jfree.chart.plot.Plot var78 = var65.getPlot();
    boolean var79 = var63.equals((java.lang.Object)var65);
    java.awt.Paint var80 = var65.getAxisLinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var81 = null;
    org.jfree.chart.plot.XYPlot var82 = new org.jfree.chart.plot.XYPlot(var48, (org.jfree.chart.axis.ValueAxis)var49, (org.jfree.chart.axis.ValueAxis)var65, var81);
    org.jfree.chart.axis.AxisLocation var83 = var82.getRangeAxisLocation();
    var12.setDomainAxisLocation(var83);
    org.jfree.chart.axis.AxisLocation var86 = var12.getDomainAxisLocation(0);
    org.jfree.chart.LegendItemCollection var87 = var12.getLegendItems();
    org.jfree.chart.axis.ValueAxis var89 = var12.getRangeAxisForDataset((-10289251));
    var2.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test250"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    double var7 = var6.getCategoryMargin();
    org.jfree.chart.axis.CategoryAxis[] var8 = new org.jfree.chart.axis.CategoryAxis[] { var6};
    var5.setDomainAxes(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var5.getRenderer(255);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D(var14);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var15);
    var15.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var19 = var15.getURLGenerator();
    java.awt.Shape var20 = var15.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var21 = null;
    var15.setLabelGenerator(var21);
    java.lang.Object var23 = var15.clone();
    boolean var24 = var12.equals((java.lang.Object)var15);
    org.jfree.chart.util.SortOrder var25 = var12.getRowRenderingOrder();
    var12.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.GanttRenderer var28 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.plot.CategoryMarker var30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var30.setKey((java.lang.Comparable)false);
    boolean var33 = var30.getDrawAsLine();
    boolean var34 = var28.equals((java.lang.Object)var30);
    var12.addDomainMarker(var30);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
    org.jfree.chart.plot.IntervalMarker var41 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var42 = var41.getAlpha();
    java.awt.Paint var43 = var41.getPaint();
    boolean var44 = var38.equals((java.lang.Object)var43);
    java.awt.Paint var45 = var38.getWallPaint();
    var12.setDomainGridlinePaint(var45);
    org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var50 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var47.setRangeWithMargins((org.jfree.data.Range)var50, false, true);
    org.jfree.data.Range var54 = var47.getDefaultAutoRange();
    var47.setAutoTickUnitSelection(false, false);
    java.text.DateFormat var58 = null;
    var47.setDateFormatOverride(var58);
    org.jfree.data.Range var60 = var47.getDefaultAutoRange();
    org.jfree.chart.axis.ValueAxis[] var61 = new org.jfree.chart.axis.ValueAxis[] { var47};
    var12.setRangeAxes(var61);
    var5.setRangeAxes(var61);
    var0.setDomainAxes(var61);
    org.jfree.chart.util.RectangleEdge var65 = var0.getDomainAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test251"); }


    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var4 = var3.getUpArrow();
    boolean var5 = var1.equals((java.lang.Object)var4);
    boolean var7 = var1.equals((java.lang.Object)0.0f);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var10 = var9.getUpArrow();
    java.awt.Shape var11 = var9.getDownArrow();
    java.util.Date var12 = var9.getMinimumDate();
    int var13 = var1.getGroupIndex((java.lang.Comparable)var12);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var16 = var15.getUpArrow();
    java.awt.Shape var17 = var15.getDownArrow();
    java.util.Date var18 = var15.getMinimumDate();
    java.lang.String var19 = var15.getLabel();
    java.util.Date var20 = var15.getMinimumDate();
    org.jfree.data.gantt.Task var21 = new org.jfree.data.gantt.Task("Pie 3D Plot", var12, var20);
    var21.setPercentComplete(1.0d);
    var21.setPercentComplete((java.lang.Double)(-1.0d));
    java.lang.Double var26 = var21.getPercentComplete();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "hi!"+ "'", var19.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1.0d)+ "'", var26.equals((-1.0d)));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test252"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker((-1.05d));
    java.awt.Paint var7 = var6.getLabelPaint();
    var0.setRangeTickBandPaint(var7);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var0.setRenderer(var9);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var13 = var12.getUpArrow();
    java.awt.Font var14 = var12.getLabelFont();
    java.text.DateFormat var15 = var12.getDateFormatOverride();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var18);
    var18.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var22 = var18.getURLGenerator();
    java.awt.Shape var23 = var18.getLegendItemShape();
    org.jfree.chart.util.Rotation var24 = var18.getDirection();
    org.jfree.chart.util.RectangleInsets var25 = var18.getInsets();
    var12.setLabelInsets(var25);
    org.jfree.data.time.DateRange var29 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var30 = var29.getLowerDate();
    java.util.Date var31 = var29.getUpperDate();
    double var32 = var29.getLowerBound();
    var12.setDefaultAutoRange((org.jfree.data.Range)var29);
    var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var0.setRangeCrosshairValue(0.0d);
    java.awt.Paint var37 = var0.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test253"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
    org.jfree.chart.renderer.category.IntervalBarRenderer var9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var9.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var11);
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var11);
    java.lang.Boolean var15 = var0.getSeriesVisibleInLegend(3);
    boolean var16 = var0.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test254"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var8 = null;
    var6.setSeriesItemLabelFont(1, var8);
    double var10 = var6.getItemMargin();
    boolean var12 = var6.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var15 = var6.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var17.setRangeWithMargins((org.jfree.data.Range)var20, false, true);
    org.jfree.data.Range var24 = var17.getDefaultAutoRange();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.AxisState var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var17.refreshTicks(var25, var26, var27, var28);
    java.awt.Font var30 = var17.getLabelFont();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D(var32);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var33);
    var33.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var37 = var33.getURLGenerator();
    java.awt.Shape var38 = var33.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var39 = null;
    var33.setLabelGenerator(var39);
    org.jfree.data.general.PieDataset var42 = null;
    org.jfree.chart.plot.PiePlot3D var43 = new org.jfree.chart.plot.PiePlot3D(var42);
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var43);
    int var45 = var44.getBackgroundImageAlignment();
    var33.addChangeListener((org.jfree.chart.event.PlotChangeListener)var44);
    org.jfree.chart.renderer.category.IntervalBarRenderer var48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var50 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var48.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var50);
    org.jfree.chart.renderer.category.IntervalBarRenderer var52 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var54 = null;
    var52.setSeriesItemLabelFont(1, var54);
    boolean var56 = var52.getBaseSeriesVisibleInLegend();
    java.awt.Paint var59 = var52.getItemOutlinePaint(13, 100);
    var48.setBaseItemLabelPaint(var59);
    var33.setSectionPaint((java.lang.Comparable)(short)100, var59);
    org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("Default Group", var30, var59);
    java.awt.geom.Rectangle2D var63 = var62.getBounds();
    var6.setBaseShape((java.awt.Shape)var63, false);
    java.awt.Font var68 = var6.getItemLabelFont((-457), 15);
    org.jfree.chart.axis.MarkerAxisBand var69 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var1, 0.0d, 0.0d, (-0.9500000000000001d), (-0.9500000000000001d), var68);
    var1.setRangeWithMargins(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test255"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getPlotInfo();
    java.awt.geom.Rectangle2D var4 = var3.getPlotArea();
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    org.jfree.chart.util.VerticalAlignment var6 = null;
    org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement(var5, var6, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var10 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var11 = null;
    var10.addChangeListener(var11);
    org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var9, (org.jfree.data.general.Dataset)var10, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.data.general.Dataset var15 = var14.getDataset();
    org.jfree.chart.entity.EntityCollection var16 = null;
    org.jfree.chart.ChartRenderingInfo var17 = new org.jfree.chart.ChartRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getChartArea();
    var14.setBounds(var18);
    var3.setPlotArea(var18);
    java.awt.geom.Rectangle2D var21 = var3.getDataArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test256"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.lang.Object var16 = null;
//     boolean var17 = var15.equals(var16);
//     java.awt.Paint var18 = var15.getItemPaint();
//     org.jfree.chart.util.HorizontalAlignment var19 = var15.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, Double.NaN, 0.0d);
//     org.jfree.chart.block.BlockContainer var24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var23);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var27 = var25.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var29 = var28.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var30 = var28.getBaseItemLabelGenerator();
//     java.awt.Paint var32 = null;
//     var28.setSeriesFillPaint(1, var32, false);
//     var28.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var38 = var28.getLegendItemLabelGenerator();
//     var25.setLegendItemToolTipGenerator(var38);
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
//     java.lang.Object var41 = null;
//     boolean var42 = var40.equals(var41);
//     java.lang.Object var43 = null;
//     var23.add((org.jfree.chart.block.Block)var40, var43);
//     
//     // Checks the contract:  equals-hashcode on var13 and var38
//     assertTrue("Contract failed: equals-hashcode on var13 and var38", var13.equals(var38) ? var13.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var13
//     assertTrue("Contract failed: equals-hashcode on var38 and var13", var38.equals(var13) ? var38.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test257"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    var0.clearDomainAxes();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.entity.EntityCollection var6 = null;
    org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo(var6);
    java.awt.geom.Rectangle2D var8 = var7.getChartArea();
    org.jfree.data.time.TimePeriodFormatException var10 = new org.jfree.data.time.TimePeriodFormatException("Default Group");
    boolean var11 = var7.equals((java.lang.Object)"Default Group");
    org.jfree.chart.plot.PlotRenderingInfo var12 = var7.getPlotInfo();
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(8.0d, var12, var13);
    var0.clearAnnotations();
    var0.mapDatasetToRangeAxis((-435), 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test258"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D(var4);
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var5);
    var5.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var9 = var5.getURLGenerator();
    java.awt.Shape var10 = var5.getLegendItemShape();
    var0.setShape(10, var10);
    java.awt.Shape var13 = var0.getShape((-435));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test259"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    org.jfree.chart.renderer.category.GanttRenderer var1 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var2 = var1.getCompletePaint();
    var0.setPositiveBarPaint(var2);
    java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var6 = var5.getTransparency();
    int var7 = var5.getGreen();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var5);
    java.awt.color.ColorSpace var9 = var5.getColorSpace();
    var0.setLastBarPaint((java.awt.Paint)var5);
    java.awt.Color var16 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var17 = var16.getTransparency();
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(10.0d, 10.0d, 100.0d, 1.0d, (java.awt.Paint)var16);
    int var19 = var16.getTransparency();
    java.awt.Color var24 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    float[] var28 = new float[] { 1.0f, 10.0f, (-1.0f)};
    float[] var29 = var24.getRGBColorComponents(var28);
    float[] var30 = java.awt.Color.RGBtoHSB(0, 2, (-457), var28);
    float[] var31 = var16.getRGBColorComponents(var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var32 = var5.getComponents(var31);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "black"+ "'", var8.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test260"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
    long var4 = var3.getSegmentsExcludedSize();
    int var5 = var3.getSegmentsIncluded();
    long var7 = var3.getTimeFromLong(1L);
    org.jfree.chart.axis.SegmentedTimeline var8 = var3.getBaseTimeline();
    int var9 = var3.getSegmentsExcluded();
    org.jfree.chart.axis.SegmentedTimeline var10 = var3.getBaseTimeline();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test261"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesLinesVisible(15, (java.lang.Boolean)true);
    org.jfree.chart.LegendItem var6 = var0.getLegendItem(13, 15);
    boolean var7 = var0.getBaseLinesVisible();
    int var8 = var0.getPassCount();
    var0.setDrawOutlines(false);
    var0.setSeriesShapesVisible(2, (java.lang.Boolean)false);
    org.jfree.chart.renderer.category.GanttRenderer var14 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var15 = var14.getCompletePaint();
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    double var20 = var16.getItemMargin();
    boolean var22 = var16.isSeriesVisibleInLegend(1);
    java.lang.Boolean var24 = var16.getSeriesCreateEntities(1);
    java.awt.Paint var26 = var16.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var27 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var29 = null;
    var27.setSeriesItemLabelFont(1, var29);
    boolean var31 = var27.getBaseSeriesVisibleInLegend();
    java.awt.Paint var34 = var27.getItemOutlinePaint(13, 100);
    var16.setBaseFillPaint(var34, true);
    var16.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var40 = var16.getBaseNegativeItemLabelPosition();
    int var41 = var16.getColumnCount();
    org.jfree.chart.labels.ItemLabelPosition var44 = var16.getPositiveItemLabelPosition(96, 15);
    var14.setBasePositiveItemLabelPosition(var44);
    var0.setBaseNegativeItemLabelPosition(var44, true);
    boolean var48 = var0.getBaseShapesFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test262"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)true);
    org.jfree.data.general.DatasetGroup var4 = new org.jfree.data.general.DatasetGroup("RectangleAnchor.CENTER");
    var0.setGroup(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test263"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var1.addChangeListener(var2);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var8 = var6.lookupSeriesShape((-1));
    var5.setUpArrow(var8);
    java.util.Date var10 = var5.getMaximumDate();
    org.jfree.chart.axis.DateTickMarkPosition var11 = var5.getTickMarkPosition();
    boolean var12 = var1.equals((java.lang.Object)var5);
    int var13 = var1.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.remove((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test264"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    org.jfree.chart.util.RectangleInsets var3 = var0.getAxisOffset();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
    var7.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
    java.awt.Shape var12 = var7.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var13 = null;
    var7.setLabelGenerator(var13);
    java.lang.Object var15 = var7.clone();
    boolean var16 = var4.equals((java.lang.Object)var7);
    org.jfree.chart.util.SortOrder var17 = var4.getRowRenderingOrder();
    var4.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var22 = null;
    var20.setSeriesItemLabelFont(1, var22);
    double var24 = var20.getItemMargin();
    boolean var26 = var20.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var27 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var28 = null;
    var27.rendererChanged(var28);
    var20.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var27);
    org.jfree.data.general.Dataset var32 = null;
    org.jfree.data.general.DatasetChangeEvent var33 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var32);
    var27.datasetChanged(var33);
    var4.datasetChanged(var33);
    org.jfree.data.general.Dataset var36 = var33.getDataset();
    var0.datasetChanged(var33);
    org.jfree.chart.util.RectangleEdge var38 = var0.getRangeAxisEdge();
    org.jfree.chart.event.RendererChangeEvent var39 = null;
    var0.rendererChanged(var39);
    var0.clearRangeMarkers();
    org.jfree.chart.plot.PlotOrientation var42 = var0.getOrientation();
    java.awt.Stroke var43 = var0.getDomainZeroBaselineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test265"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    boolean var2 = var0.containsKey("ChartEntity: tooltip = hi!");
    boolean var4 = var0.containsKey("org.jfree.data.time.TimePeriodFormatException: Default Group");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var0.getString("java.awt.Color[r=0,g=0,b=0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test266"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getLeftArrow();
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var4);
    org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var8 = null;
    var6.setSeriesItemLabelFont(1, var8);
    boolean var10 = var6.getBaseSeriesVisibleInLegend();
    java.awt.Paint var13 = var6.getItemOutlinePaint(13, 100);
    var2.setBaseItemLabelPaint(var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    int var17 = var15.getRowIndex((java.lang.Comparable)(-1.05d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var20 = null;
    var18.setSeriesItemLabelFont(1, var20);
    boolean var22 = var18.getBaseSeriesVisibleInLegend();
    org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22);
    boolean var24 = var15.equals((java.lang.Object)var22);
    org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
    org.jfree.chart.util.Size2D var30 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    java.lang.Object var31 = var30.clone();
    int var32 = var27.compareTo((java.lang.Object)var30);
    var15.addValue(3.0d, (java.lang.Comparable)(short)0, (java.lang.Comparable)var27);
    org.jfree.data.DefaultKeyedValues2D var34 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var35 = var34.getRowKeys();
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var39 = var37.lookupSeriesShape((-1));
    var36.setUpArrow(var39);
    java.util.Date var41 = var36.getMaximumDate();
    int var42 = var34.getColumnIndex((java.lang.Comparable)var41);
    org.jfree.data.DefaultKeyedValues2D var43 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var44 = var43.getRowKeys();
    org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var46 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var48 = var46.lookupSeriesShape((-1));
    var45.setUpArrow(var48);
    java.util.Date var50 = var45.getMaximumDate();
    int var51 = var43.getColumnIndex((java.lang.Comparable)var50);
    var15.removeValue((java.lang.Comparable)var42, (java.lang.Comparable)var51);
    org.jfree.data.Range var53 = var2.findRangeBounds((org.jfree.data.category.CategoryDataset)var15);
    java.util.List var54 = var15.getColumnKeys();
    java.util.List var55 = var15.getRowKeys();
    org.jfree.chart.axis.DateTickUnit var58 = new org.jfree.chart.axis.DateTickUnit(0, (-435));
    org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var62 = var60.lookupSeriesShape((-1));
    var59.setUpArrow(var62);
    java.util.Date var64 = var59.getMaximumDate();
    java.util.Date var65 = var58.rollDate(var64);
    var15.removeValue((java.lang.Comparable)var58, (java.lang.Comparable)30);
    java.util.Date var68 = var0.calculateHighestVisibleTickValue(var58);
    int var69 = var58.getUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test267"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelOffset();
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
    org.jfree.chart.util.GradientPaintTransformer var8 = var4.getGradientPaintTransformer();
    var2.setGradientPaintTransformer(var8);
    java.awt.Paint var10 = var2.getPaint();
    org.jfree.chart.util.RectangleAnchor var11 = var2.getLabelAnchor();
    org.jfree.chart.util.GradientPaintTransformer var12 = var2.getGradientPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test268"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(100);
    int var2 = var1.getMonth();
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(100);
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    boolean var7 = var5.equals((java.lang.Object)var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getCategoryMargin();
    int var11 = var9.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAnchor var12 = null;
    org.jfree.chart.entity.EntityCollection var15 = null;
    org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo(var15);
    java.awt.geom.Rectangle2D var17 = var16.getChartArea();
    org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var20 = var18.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var22 = var21.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var21.getBaseItemLabelGenerator();
    java.awt.Paint var25 = null;
    var21.setSeriesFillPaint(1, var25, false);
    var21.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var31 = var21.getLegendItemLabelGenerator();
    var18.setLegendItemToolTipGenerator(var31);
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.util.Size2D var35 = var33.arrange(var34);
    org.jfree.chart.util.RectangleEdge var36 = var33.getPosition();
    boolean var37 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var36);
    double var38 = var9.getCategoryJava2DCoordinate(var12, 0, 10, var17, var36);
    var6.draw(var8, var17);
    boolean var40 = var4.equals((java.lang.Object)var8);
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(2);
    boolean var43 = var4.isOnOrAfter(var42);
    int var44 = var4.toSerial();
    org.jfree.data.time.SerialDate var46 = var4.getFollowingDayOfWeek(3);
    org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(15);
    java.lang.String var50 = var49.getDescription();
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addYears(12, var49);
    boolean var52 = var1.isInRange((org.jfree.data.time.SerialDate)var4, var49);
    org.jfree.data.DefaultKeyedValue var54 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)var52, (java.lang.Number)(-457));
    java.lang.Number var55 = var54.getValue();
    var54.setValue((java.lang.Number)1969L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-457)+ "'", var55.equals((-457)));

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test269"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var5 = null;
    var3.setSeriesItemLabelFont(1, var5);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, true);
    int var17 = var0.getRowCount();
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(100);
    org.jfree.chart.renderer.category.LayeredBarRenderer var21 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder();
    boolean var23 = var21.equals((java.lang.Object)var22);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
    double var26 = var25.getCategoryMargin();
    int var27 = var25.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAnchor var28 = null;
    org.jfree.chart.entity.EntityCollection var31 = null;
    org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo(var31);
    java.awt.geom.Rectangle2D var33 = var32.getChartArea();
    org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var36 = var34.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var38 = var37.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var39 = var37.getBaseItemLabelGenerator();
    java.awt.Paint var41 = null;
    var37.setSeriesFillPaint(1, var41, false);
    var37.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var47 = var37.getLegendItemLabelGenerator();
    var34.setLegendItemToolTipGenerator(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    java.awt.Graphics2D var50 = null;
    org.jfree.chart.util.Size2D var51 = var49.arrange(var50);
    org.jfree.chart.util.RectangleEdge var52 = var49.getPosition();
    boolean var53 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var52);
    double var54 = var25.getCategoryJava2DCoordinate(var28, 0, 10, var33, var52);
    var22.draw(var24, var33);
    boolean var56 = var20.equals((java.lang.Object)var24);
    org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(2);
    boolean var59 = var20.isOnOrAfter(var58);
    org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(15);
    java.lang.String var63 = var62.getDescription();
    org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addYears(0, var62);
    boolean var65 = var20.isOnOrAfter(var64);
    org.jfree.data.time.SerialDate var67 = var20.getNearestDayOfWeek(1);
    int var68 = var20.getDayOfWeek();
    java.lang.Comparable var69 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setValue((java.lang.Number)7.0d, (java.lang.Comparable)var20, var69);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 2);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test270"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
//     double var3 = var2.getBottom();
//     var2.setTop(0.0d);
//     double var6 = var2.getLeft();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var9 = null;
//     var7.setSeriesItemLabelFont(1, var9);
//     double var11 = var7.getItemMargin();
//     boolean var13 = var7.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var15 = var7.getSeriesCreateEntities(1);
//     var7.setBaseItemLabelsVisible(true, false);
//     int var19 = var7.getRowCount();
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var22 = var21.getFixedLegendItems();
//     java.awt.geom.Point2D var23 = var21.getQuadrantOrigin();
//     org.jfree.chart.util.RectangleInsets var24 = var21.getAxisOffset();
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = var21.getRendererForDataset(var25);
//     java.awt.Stroke var27 = var21.getRangeCrosshairStroke();
//     var7.setSeriesOutlineStroke(12, var27, true);
//     boolean var30 = var2.equals((java.lang.Object)var27);
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var36 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var37 = null;
//     var36.addChangeListener(var37);
//     org.jfree.chart.title.LegendItemBlockContainer var40 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var35, (org.jfree.data.general.Dataset)var36, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.data.general.Dataset var41 = var40.getDataset();
//     org.jfree.chart.entity.EntityCollection var42 = null;
//     org.jfree.chart.ChartRenderingInfo var43 = new org.jfree.chart.ChartRenderingInfo(var42);
//     java.awt.geom.Rectangle2D var44 = var43.getChartArea();
//     var40.setBounds(var44);
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var44, 0.0d, 0.8f, 0.95f);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var50 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var52 = var50.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var53 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var54 = var53.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var55 = var53.getBaseItemLabelGenerator();
//     java.awt.Paint var57 = null;
//     var53.setSeriesFillPaint(1, var57, false);
//     var53.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var63 = var53.getLegendItemLabelGenerator();
//     var50.setLegendItemToolTipGenerator(var63);
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50);
//     java.awt.Graphics2D var66 = null;
//     org.jfree.chart.util.Size2D var67 = var65.arrange(var66);
//     org.jfree.chart.util.RectangleEdge var68 = var65.getPosition();
//     java.awt.geom.Rectangle2D var69 = var2.reserved(var44, var68);
//     java.awt.geom.Point2D var70 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(Double.NaN, 9.4607999994E10d, var69);
//     
//     // Checks the contract:  var70.equals(var70)
//     assertTrue("Contract failed: var70.equals(var70)", var70.equals(var70));
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test271"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.95f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test272"); }


    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getCategoryMargin();
    boolean var11 = var3.equals((java.lang.Object)var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var3);
    var12.clearSubtitles();
    java.util.List var14 = var12.getSubtitles();
    var12.clearSubtitles();
    boolean var16 = var12.getAntiAlias();
    int var17 = var12.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleInsets var18 = var12.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test273"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    boolean var4 = var0.isSeriesVisibleInLegend(13);
    java.lang.Boolean var6 = var0.getSeriesItemLabelsVisible(10);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var11);
    var11.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var15 = var11.getURLGenerator();
    java.awt.Shape var16 = var11.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var17 = null;
    var11.setLabelGenerator(var17);
    java.lang.Object var19 = var11.clone();
    boolean var20 = var8.equals((java.lang.Object)var11);
    org.jfree.chart.util.SortOrder var21 = var8.getRowRenderingOrder();
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", (org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.renderer.category.IntervalBarRenderer var24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var25 = var24.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var26 = var24.getBaseItemLabelGenerator();
    java.awt.Paint var28 = null;
    var24.setSeriesFillPaint(1, var28, false);
    var24.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var35 = var24.getSeriesPositiveItemLabelPosition(100);
    org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var40 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var37.setRangeWithMargins((org.jfree.data.Range)var40, false, true);
    org.jfree.data.Range var44 = var37.getDefaultAutoRange();
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.axis.AxisState var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.util.RectangleEdge var48 = null;
    java.util.List var49 = var37.refreshTicks(var45, var46, var47, var48);
    java.awt.Font var50 = var37.getLabelFont();
    org.jfree.data.general.PieDataset var52 = null;
    org.jfree.chart.plot.PiePlot3D var53 = new org.jfree.chart.plot.PiePlot3D(var52);
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var53);
    var53.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var57 = var53.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var58 = null;
    var53.axisChanged(var58);
    org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var50, (org.jfree.chart.plot.Plot)var53, false);
    boolean var62 = var35.equals((java.lang.Object)var50);
    java.awt.Color var64 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    float[] var68 = new float[] { 1.0f, 10.0f, (-1.0f)};
    float[] var69 = var64.getRGBColorComponents(var68);
    org.jfree.chart.text.TextMeasurer var72 = null;
    org.jfree.chart.text.TextBlock var73 = org.jfree.chart.text.TextUtilities.createTextBlock("", var50, (java.awt.Paint)var64, 0.0f, 10, var72);
    var8.setNoDataMessageFont(var50);
    var0.setBaseItemLabelFont(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test274"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-435), (java.lang.Number)(short)10);
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    double var4 = var3.getCategoryMargin();
    int var5 = var3.getCategoryLabelPositionOffset();
    boolean var6 = var2.equals((java.lang.Object)var5);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var8.setRangeWithMargins((org.jfree.data.Range)var11, false, true);
    org.jfree.data.Range var15 = var8.getDefaultAutoRange();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.axis.AxisState var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    java.util.List var20 = var8.refreshTicks(var16, var17, var18, var19);
    java.awt.Font var21 = var8.getLabelFont();
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var24);
    var24.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var28 = var24.getURLGenerator();
    java.awt.Shape var29 = var24.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var30 = null;
    var24.setLabelGenerator(var30);
    org.jfree.data.general.PieDataset var33 = null;
    org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D(var33);
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var34);
    int var36 = var35.getBackgroundImageAlignment();
    var24.addChangeListener((org.jfree.chart.event.PlotChangeListener)var35);
    org.jfree.chart.renderer.category.IntervalBarRenderer var39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var41 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var39.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var41);
    org.jfree.chart.renderer.category.IntervalBarRenderer var43 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var45 = null;
    var43.setSeriesItemLabelFont(1, var45);
    boolean var47 = var43.getBaseSeriesVisibleInLegend();
    java.awt.Paint var50 = var43.getItemOutlinePaint(13, 100);
    var39.setBaseItemLabelPaint(var50);
    var24.setSectionPaint((java.lang.Comparable)(short)100, var50);
    org.jfree.chart.block.LabelBlock var53 = new org.jfree.chart.block.LabelBlock("Default Group", var21, var50);
    boolean var54 = var2.equals((java.lang.Object)var53);
    org.jfree.chart.util.RectangleInsets var55 = var53.getPadding();
    double var57 = var55.calculateRightInset(9.4608E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test275"); }


    org.jfree.data.general.Dataset var1 = null;
    org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)"hi!", var1);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test276"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Paint var7 = null;
    java.awt.Paint var9 = null;
    java.awt.Stroke var10 = null;
    java.awt.Shape var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Paint var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "hi!", "", "hi!", false, var5, false, var7, true, var9, var10, false, var12, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test277"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)true, (java.lang.Number)0);
    java.lang.Number var3 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test278"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", var3);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test279"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test280"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1, var2, 1.0d, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test281"); }


    org.jfree.data.general.Dataset var1 = null;
    org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(-1.0f), var1);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test282"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test283"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test284"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint)var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test285"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, (-1.0f), 0.0f, var4);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test286"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    float[] var7 = new float[] { 100.0f, (-1.0f), 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var8 = var3.getRGBComponents(var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test287"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var2.drawDomainGridline(var9, var10, var11, 0.0d);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test288"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test289"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test290"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    java.awt.Stroke var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlineStroke(var10, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test291"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, (-1.0f), 1.0f, var4, 100.0d, var6);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test292"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test293"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test294"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test295"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 100.0d, 1.0f, 100.0f);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test296"); }


    java.util.List var8 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)100.0f, (java.lang.Number)(short)10, (java.lang.Number)100, (java.lang.Number)1.0d, (java.lang.Number)10.0d, (java.lang.Number)(-1), (java.lang.Number)(short)0, (java.lang.Number)0.0d, var8);
    java.lang.Number var10 = var9.getMedian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)10+ "'", var10.equals((short)10));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test297"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test298"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.color.ColorSpace var3 = null;
//     float[] var5 = new float[] { 100.0f};
//     float[] var6 = var2.getColorComponents(var3, var5);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test299"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test300"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("", var1);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test301"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(10, var10);
//     java.awt.Shape var12 = var2.getBaseShape();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.data.category.CategoryDataset var19 = null;
//     var2.drawItem(var13, var14, var15, var16, var17, var18, var19, 1, (-1), 1);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test302"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test303"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test304"); }


    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(10, 1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test305"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test306"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var4.setBaseCreateEntities(true);
    java.awt.Paint var8 = null;
    var4.setSeriesItemLabelPaint(0, var8, true);
    java.awt.Stroke var12 = null;
    var4.setSeriesStroke(10, var12);
    java.awt.Shape var14 = var4.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var18 = var17.getLabelOffsetType();
    java.awt.Paint var19 = var17.getPaint();
    var4.setWallPaint(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var21 = new org.jfree.chart.text.TextFragment("hi!", var1, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test307"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "hi!");
    java.lang.String var5 = var4.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test308"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test309"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test310"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    org.jfree.data.time.TimePeriodFormatException var3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    var1.addSuppressed((java.lang.Throwable)var3);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test311"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)' ', (java.lang.Comparable)1.0f);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test312"); }


    org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(-1.0d));

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test313"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    boolean var12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0, (java.lang.Object)0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test314"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    double var4 = var3.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test315"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var8.setBaseCreateEntities(true);
    java.awt.Paint var12 = null;
    var8.setSeriesItemLabelPaint(0, var12, true);
    java.awt.Shape var15 = var8.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var18.setBaseCreateEntities(true);
    java.awt.Paint var22 = null;
    var18.setSeriesItemLabelPaint(0, var22, true);
    java.awt.Stroke var26 = null;
    var18.setSeriesStroke(10, var26);
    java.awt.Shape var28 = var18.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var31 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var32 = var31.getLabelOffsetType();
    java.awt.Paint var33 = var31.getPaint();
    var18.setWallPaint(var33);
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var15, var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var36 = new org.jfree.chart.text.TextLine("hi!", var1, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test316"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 1.0d, 100.0d);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test317"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, (-1.0d), true);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test318"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var9 = var8.getLabelOffsetType();
    java.awt.Paint var10 = var8.getPaint();
    java.awt.Stroke var11 = null;
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem(var0, "", "hi!", "", var5, var10, var11, (java.awt.Paint)var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test319"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test320"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.Plot var2 = null;
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, var2, false);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test321"); }


    java.awt.Stroke var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test322"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(var0, var1);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test323"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test324"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.lang.String var6 = var5.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("", var1, (java.awt.Paint)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var6.equals("java.awt.Color[r=0,g=0,b=0]"));

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test325"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var2.getBaseURLGenerator();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.data.category.CategoryDataset var12 = null;
//     var2.drawItem(var6, var7, var8, var9, var10, var11, var12, 1, 0, 1);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test326"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("hi!", "hi!");

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test327"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)(byte)0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test328"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeValue((java.lang.Comparable)10.0f, (java.lang.Comparable)(-1L));
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test329"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    java.lang.Object var5 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test330"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test331"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test332"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, 100.0f, 0.0d, 0.0f, 0.0f);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test333"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test334"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var2.getBaseURLGenerator();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.data.category.CategoryDataset var12 = null;
//     var2.drawItem(var6, var7, var8, var9, var10, var11, var12, 0, (-1), 1);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test335"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("", 0);
    java.awt.Stroke var8 = null;
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem(var0, "", "", "hi!", var4, (java.awt.Paint)var7, var8, (java.awt.Paint)var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test336"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(10, var10);
//     java.awt.Shape var12 = var2.getBaseShape();
//     org.jfree.chart.urls.CategoryURLGenerator var14 = null;
//     var2.setSeriesURLGenerator(1, var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var2.drawOutline(var16, var17, var18);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test337"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test338"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears((-1), var1);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test339"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 0.0d, var2);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test340"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1), var1, 100, (-1));
    org.jfree.chart.JFreeChart var5 = var4.getChart();
    org.jfree.chart.JFreeChart var6 = var4.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test341"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("hi!", var1, (java.awt.Paint)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test342"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    var2.setAutoPopulateSeriesPaint(false);
    var2.setBaseSeriesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test343"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test344"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    java.lang.String var35 = var33.getLabel();
    org.jfree.data.general.Dataset var36 = null;
    var33.setDataset(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "hi!"+ "'", var35.equals("hi!"));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test345"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    java.awt.Font var5 = null;
    var2.setSeriesItemLabelFont(10, var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    var2.setBaseOutlinePaint((java.awt.Paint)var9);
    org.jfree.chart.LegendItem var13 = var2.getLegendItem(10, 1);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var2.setBaseURLGenerator(var14, false);
    java.awt.Font var18 = var2.getSeriesItemLabelFont(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test346"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
//     var2.setAutoPopulateSeriesPaint(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     java.awt.Font var11 = null;
//     var8.setSeriesItemLabelFont(10, var11);
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     var8.setBaseOutlinePaint((java.awt.Paint)var15);
//     var2.setBaseOutlinePaint((java.awt.Paint)var15);
//     
//     // Checks the contract:  equals-hashcode on var3 and var9
//     assertTrue("Contract failed: equals-hashcode on var3 and var9", var3.equals(var9) ? var3.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var3
//     assertTrue("Contract failed: equals-hashcode on var9 and var3", var9.equals(var3) ? var9.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test347"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 1.0d, var2);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test348"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    java.awt.Paint var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem(var0, "", "", "hi!", var5, var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test349"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test350"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, 1.0f, var4, 0.0d, 1.0f, 100.0f);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test351"); }


    java.awt.Paint var2 = null;
    org.jfree.chart.plot.IntervalMarker var5 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var6 = var5.getLabel();
    var5.setEndValue(10.0d);
    java.awt.Stroke var9 = var5.getStroke();
    org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var13 = var12.getLabelOffsetType();
    java.awt.Paint var14 = var12.getPaint();
    java.awt.Stroke var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var2, var9, var14, var15, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test352"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    boolean var17 = var2.getItemVisible(10, 10);
    var2.setBase(100.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var24 = var23.getBaseNegativeItemLabelPosition();
    var2.setSeriesNegativeItemLabelPosition(10, var24);
    java.awt.Color var30 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var31 = var30.getTransparency();
    var2.setSeriesOutlinePaint(0, (java.awt.Paint)var30);
    java.lang.String var33 = var30.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var33.equals("java.awt.Color[r=0,g=0,b=0]"));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test353"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test354"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 10.0d, (-1.0d), 1.0d);
    double var6 = var4.calculateLeftOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10.0d);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test355"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(0, var1);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test356"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test357"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test358"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 100.0d, var2);
// 
//   }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test359"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("ChartEntity: tooltip = ", var1, 1.0f, 100.0f, var4);
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test360"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
//     var4.setURLText("hi!");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var7 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var8 = null;
//     java.lang.String var9 = var4.getImageMapAreaTag(var7, var8);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test361"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    var2.setBaseSeriesVisible(false, false);
    java.lang.Boolean var19 = var2.getSeriesVisible(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test362"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(10.0d);
    double var2 = var1.getCursor();
    org.jfree.chart.util.RectangleEdge var4 = null;
    var1.moveCursor(1.0d, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test363"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("", "");
    java.lang.String var3 = var2.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test364"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test365"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test366"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
//     java.awt.Font var5 = null;
//     var2.setSeriesItemLabelFont(10, var5);
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
//     var2.setBaseOutlinePaint((java.awt.Paint)var9);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var14.setBaseCreateEntities(true);
//     java.awt.Paint var18 = null;
//     var14.setSeriesItemLabelPaint(0, var18, true);
//     java.awt.Stroke var22 = null;
//     var14.setSeriesStroke(10, var22);
//     java.awt.Shape var24 = var14.getBaseShape();
//     var2.setSeriesShape(10, var24, true);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var2.getSeriesPositiveItemLabelPosition(10);
//     
//     // Checks the contract:  equals-hashcode on var3 and var28
//     assertTrue("Contract failed: equals-hashcode on var3 and var28", var3.equals(var28) ? var3.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var3
//     assertTrue("Contract failed: equals-hashcode on var28 and var3", var28.equals(var3) ? var28.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test367"); }


    org.jfree.data.general.Dataset var1 = null;
    org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)1, var1);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test368"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var1.getColumnKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test369"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
//     double var4 = var2.getItemLabelAnchorOffset();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var8.setBaseCreateEntities(true);
//     java.awt.Paint var12 = null;
//     var8.setSeriesItemLabelPaint(0, var12, true);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.Marker var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var8.drawRangeMarker(var15, var16, var17, var18, var19);
//     boolean var23 = var8.getItemVisible(10, 10);
//     var8.setBase(100.0d);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var30 = var29.getBaseNegativeItemLabelPosition();
//     var8.setSeriesNegativeItemLabelPosition(10, var30);
//     var2.setSeriesPositiveItemLabelPosition(100, var30, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var2.", var29.equals(var2) == var2.equals(var29));
//     
//     // Checks the contract:  equals-hashcode on var3 and var30
//     assertTrue("Contract failed: equals-hashcode on var3 and var30", var3.equals(var30) ? var3.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var3
//     assertTrue("Contract failed: equals-hashcode on var30 and var3", var30.equals(var3) ? var30.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test370"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(10.0d);
    double var2 = var1.getCursor();
    java.util.List var3 = null;
    var1.setTicks(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test371"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(10, var10);
//     java.awt.Shape var12 = var2.getBaseShape();
//     org.jfree.chart.urls.CategoryURLGenerator var14 = null;
//     var2.setSeriesURLGenerator(1, var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.data.category.CategoryDataset var22 = null;
//     var2.drawItem(var16, var17, var18, var19, var20, var21, var22, 100, 0, 100);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test372"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 10.0d, (-1.0d), 1.0d);
    double var6 = var4.trimWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-11.0d));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test373"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    int var2 = var1.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test374"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getValue((java.lang.Comparable)0.0f, (java.lang.Comparable)(byte)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test375"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)(short)(-1), (java.lang.Number)(-1.0d));

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test376"); }


    java.util.List var8 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)100.0f, (java.lang.Number)(short)10, (java.lang.Number)100, (java.lang.Number)1.0d, (java.lang.Number)10.0d, (java.lang.Number)(-1), (java.lang.Number)(short)0, (java.lang.Number)0.0d, var8);
    java.lang.Number var10 = var9.getQ1();
    java.util.List var11 = var9.getOutliers();
    java.lang.Number var12 = var9.getMedian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100+ "'", var10.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)10+ "'", var12.equals((short)10));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test377"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    java.awt.Font var5 = null;
    var2.setSeriesItemLabelFont(10, var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    var2.setBaseOutlinePaint((java.awt.Paint)var9);
    int var11 = var9.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test378"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 10};
    java.lang.Comparable[] var2 = null;
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test379"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
//     java.awt.Font var5 = null;
//     var2.setSeriesItemLabelFont(10, var5);
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
//     var2.setBaseOutlinePaint((java.awt.Paint)var9);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var14 = var13.getBaseNegativeItemLabelPosition();
//     java.awt.Font var16 = null;
//     var13.setSeriesItemLabelFont(10, var16);
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     var13.setBaseOutlinePaint((java.awt.Paint)var20);
//     var2.setWallPaint((java.awt.Paint)var20);
//     
//     // Checks the contract:  equals-hashcode on var3 and var14
//     assertTrue("Contract failed: equals-hashcode on var3 and var14", var3.equals(var14) ? var3.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var3
//     assertTrue("Contract failed: equals-hashcode on var14 and var3", var14.equals(var3) ? var14.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test380"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var2, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test381"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!", "hi!");
    var5.setVersion("");
    var5.setVersion("hi!");
    org.jfree.chart.ui.BasicProjectInfo var15 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!", "hi!");
    var15.setVersion("");
    var15.setVersion("hi!");
    java.lang.String var20 = var15.getVersion();
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "hi!"+ "'", var20.equals("hi!"));

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test382"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var3 = var2.brighter();
    float[] var7 = new float[] { 100.0f, 0.0f, 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var8 = var2.getRGBComponents(var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test383"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addValue((java.lang.Number)1L, (java.lang.Comparable)1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test384"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test385"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1), var1, 100, (-1));
    var4.setPercent(10);
    java.lang.Object var7 = var4.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test386"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
//     java.util.Date var4 = null;
//     var3.addException(var4);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test387"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.awt.Paint var4 = var3.getOutlinePaint();
//     org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var8 = var7.getLabelOffsetType();
//     java.awt.Paint var9 = var7.getPaint();
//     java.awt.Stroke var10 = var7.getOutlineStroke();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var17.setBaseCreateEntities(true);
//     java.awt.Paint var21 = null;
//     var17.setSeriesItemLabelPaint(0, var21, true);
//     java.awt.Shape var24 = var17.getBaseShape();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var27.setBaseCreateEntities(true);
//     java.awt.Paint var31 = null;
//     var27.setSeriesItemLabelPaint(0, var31, true);
//     java.awt.Stroke var35 = null;
//     var27.setSeriesStroke(10, var35);
//     java.awt.Shape var37 = var27.getBaseShape();
//     org.jfree.chart.plot.IntervalMarker var40 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var41 = var40.getLabelOffsetType();
//     java.awt.Paint var42 = var40.getPaint();
//     var27.setWallPaint(var42);
//     org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var24, var42);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var47.setBaseCreateEntities(true);
//     java.awt.Paint var51 = null;
//     var47.setSeriesItemLabelPaint(0, var51, true);
//     java.awt.Graphics2D var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.plot.Marker var57 = null;
//     java.awt.geom.Rectangle2D var58 = null;
//     var47.drawRangeMarker(var54, var55, var56, var57, var58);
//     boolean var62 = var47.getItemVisible(10, 10);
//     var47.setBase(100.0d);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var68 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var69 = var68.getBaseNegativeItemLabelPosition();
//     var47.setSeriesNegativeItemLabelPosition(10, var69);
//     java.lang.Object var71 = var47.clone();
//     org.jfree.chart.plot.IntervalMarker var74 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var75 = var74.getLabelOffsetType();
//     java.awt.Paint var76 = var74.getPaint();
//     java.awt.Stroke var77 = var74.getOutlineStroke();
//     var47.setBaseOutlineStroke(var77, false);
//     org.jfree.chart.plot.ValueMarker var81 = new org.jfree.chart.plot.ValueMarker(0.0d, var4, var10, var42, var77, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var3 and var7
//     assertTrue("Contract failed: equals-hashcode on var3 and var7", var3.equals(var7) ? var3.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var40
//     assertTrue("Contract failed: equals-hashcode on var3 and var40", var3.equals(var40) ? var3.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var74
//     assertTrue("Contract failed: equals-hashcode on var3 and var74", var3.equals(var74) ? var3.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var3
//     assertTrue("Contract failed: equals-hashcode on var7 and var3", var7.equals(var3) ? var7.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var40
//     assertTrue("Contract failed: equals-hashcode on var7 and var40", var7.equals(var40) ? var7.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var74
//     assertTrue("Contract failed: equals-hashcode on var7 and var74", var7.equals(var74) ? var7.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var3
//     assertTrue("Contract failed: equals-hashcode on var40 and var3", var40.equals(var3) ? var40.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var7
//     assertTrue("Contract failed: equals-hashcode on var40 and var7", var40.equals(var7) ? var40.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var74
//     assertTrue("Contract failed: equals-hashcode on var40 and var74", var40.equals(var74) ? var40.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var3
//     assertTrue("Contract failed: equals-hashcode on var74 and var3", var74.equals(var3) ? var74.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var7
//     assertTrue("Contract failed: equals-hashcode on var74 and var7", var74.equals(var7) ? var74.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var40
//     assertTrue("Contract failed: equals-hashcode on var74 and var40", var74.equals(var40) ? var74.hashCode() == var40.hashCode() : true);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test388"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
//     java.awt.Font var5 = null;
//     var2.setSeriesItemLabelFont(10, var5);
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
//     var2.setBaseOutlinePaint((java.awt.Paint)var9);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var13.setBaseCreateEntities(true);
//     java.awt.Paint var17 = null;
//     var13.setSeriesItemLabelPaint(0, var17, true);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.plot.Marker var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     var13.drawRangeMarker(var20, var21, var22, var23, var24);
//     boolean var28 = var13.getItemVisible(10, 10);
//     var13.setBase(100.0d);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var35 = var34.getBaseNegativeItemLabelPosition();
//     var13.setSeriesNegativeItemLabelPosition(10, var35);
//     var2.setPositiveItemLabelPositionFallback(var35);
//     
//     // Checks the contract:  equals-hashcode on var3 and var35
//     assertTrue("Contract failed: equals-hashcode on var3 and var35", var3.equals(var35) ? var3.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var3
//     assertTrue("Contract failed: equals-hashcode on var35 and var3", var35.equals(var3) ? var35.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test389"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
//     var2.setBaseCreateEntities(true, false);
//     var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     java.lang.Comparable[] var23 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var25 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var26 = null;
//     java.lang.Number[][] var27 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var23, var25, var26, var27);
//     var2.drawItem(var16, var17, var18, var19, var20, var21, (org.jfree.data.category.CategoryDataset)var28, (-1), 10, 0);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test390"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     int var7 = var6.getRowCount();
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test391"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    var2.setSeriesVisibleInLegend(1, (java.lang.Boolean)false, false);
    java.lang.Boolean var17 = var2.getSeriesVisibleInLegend(1);
    java.awt.Paint var18 = var2.getWallPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + false+ "'", var17.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test392"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelTextAnchor(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test393"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.block.Arrangement var4 = null;
    org.jfree.chart.block.Arrangement var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test394"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(10, var10);
//     java.awt.Shape var12 = var2.getBaseShape();
//     org.jfree.chart.urls.CategoryURLGenerator var14 = null;
//     var2.setSeriesURLGenerator(1, var14);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var2.getPositiveItemLabelPosition(10, 0);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     java.awt.Color var25 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.plot.IntervalMarker var28 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var29 = var28.getLabel();
//     var28.setEndValue(10.0d);
//     java.awt.Stroke var32 = var28.getStroke();
//     org.jfree.chart.plot.CategoryMarker var33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var25, var32);
//     java.awt.geom.Rectangle2D var34 = null;
//     var2.drawDomainMarker(var19, var20, var21, var33, var34);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test395"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    java.awt.Font var5 = null;
    var2.setSeriesItemLabelFont(10, var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    var2.setBaseOutlinePaint((java.awt.Paint)var9);
    org.jfree.chart.LegendItem var13 = var2.getLegendItem(10, 1);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var2.setBaseURLGenerator(var14, false);
    java.awt.Stroke var18 = var2.getSeriesStroke(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLegendItemLabelGenerator(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test396"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    java.lang.Object var6 = var1.clone();
    var1.removeColumn((java.lang.Comparable)(byte)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test397"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)10L, "CONTRACT", var2, var3, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test398"); }
// 
// 
//     java.awt.Shape var5 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     java.lang.String var11 = var10.toString();
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.IntervalMarker var19 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var20 = var19.getLabelOffsetType();
//     java.awt.Paint var21 = var19.getPaint();
//     java.awt.Stroke var22 = var19.getOutlineStroke();
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var28.setBaseCreateEntities(true);
//     java.awt.Paint var32 = null;
//     var28.setSeriesItemLabelPaint(0, var32, true);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.plot.Marker var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     var28.drawRangeMarker(var35, var36, var37, var38, var39);
//     boolean var43 = var28.getItemVisible(10, 10);
//     var28.setBase(100.0d);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var50 = var49.getBaseNegativeItemLabelPosition();
//     var28.setSeriesNegativeItemLabelPosition(10, var50);
//     java.lang.Object var52 = var28.clone();
//     org.jfree.chart.plot.IntervalMarker var55 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var56 = var55.getLabelOffsetType();
//     java.awt.Paint var57 = var55.getPaint();
//     java.awt.Stroke var58 = var55.getOutlineStroke();
//     var28.setBaseOutlineStroke(var58, false);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var67 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var67.setBaseCreateEntities(true);
//     java.awt.Paint var71 = null;
//     var67.setSeriesItemLabelPaint(0, var71, true);
//     java.awt.Shape var74 = var67.getBaseShape();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var77 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var77.setBaseCreateEntities(true);
//     java.awt.Paint var81 = null;
//     var77.setSeriesItemLabelPaint(0, var81, true);
//     java.awt.Stroke var85 = null;
//     var77.setSeriesStroke(10, var85);
//     java.awt.Shape var87 = var77.getBaseShape();
//     org.jfree.chart.plot.IntervalMarker var90 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var91 = var90.getLabelOffsetType();
//     java.awt.Paint var92 = var90.getPaint();
//     var77.setWallPaint(var92);
//     org.jfree.chart.LegendItem var94 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var74, var92);
//     java.awt.Paint var95 = var94.getOutlinePaint();
//     org.jfree.chart.LegendItem var96 = new org.jfree.chart.LegendItem("CONTRACT", "", "hi!", "CONTRACT", false, var5, false, (java.awt.Paint)var10, true, (java.awt.Paint)var16, var22, true, var25, var58, var95);
//     
//     // Checks the contract:  equals-hashcode on var19 and var55
//     assertTrue("Contract failed: equals-hashcode on var19 and var55", var19.equals(var55) ? var19.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var90
//     assertTrue("Contract failed: equals-hashcode on var19 and var90", var19.equals(var90) ? var19.hashCode() == var90.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var19
//     assertTrue("Contract failed: equals-hashcode on var55 and var19", var55.equals(var19) ? var55.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var90
//     assertTrue("Contract failed: equals-hashcode on var55 and var90", var55.equals(var90) ? var55.hashCode() == var90.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var90 and var19
//     assertTrue("Contract failed: equals-hashcode on var90 and var19", var90.equals(var19) ? var90.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var90 and var55
//     assertTrue("Contract failed: equals-hashcode on var90 and var55", var90.equals(var55) ? var90.hashCode() == var55.hashCode() : true);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test399"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    java.awt.Shape var12 = var2.getBaseShape();
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var2.setSeriesURLGenerator(1, var14);
    org.jfree.chart.labels.ItemLabelPosition var18 = var2.getPositiveItemLabelPosition(10, 0);
    boolean var19 = var2.getBaseSeriesVisibleInLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test400"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var6 = var3.containsDomainRange(0L, 1L);
    java.lang.Object var7 = var3.clone();
    org.jfree.chart.axis.SegmentedTimeline var8 = var3.getBaseTimeline();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test401"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseCreateEntities(true, false);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
    var2.setSeriesItemLabelsVisible(0, false);
    boolean var21 = var2.isItemLabelVisible(0, 0);
    org.jfree.chart.block.Arrangement var22 = null;
    org.jfree.chart.block.Arrangement var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, var22, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test402"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    var1.setDataset(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    org.jfree.chart.util.TableOrder var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDataExtractOrder(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test403"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("CONTRACT", var1, var2);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test404"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    var6.setSeriesVisibleInLegend(1, (java.lang.Boolean)true, true);
    boolean var18 = var2.equals((java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test405"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var6, 1.0d);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test406"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(10, var10);
//     var2.setSeriesVisibleInLegend(1, (java.lang.Boolean)false, false);
//     java.lang.Boolean var17 = var2.getSeriesVisibleInLegend(1);
//     boolean var18 = var2.getAutoPopulateSeriesShape();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var23 = var22.getBaseNegativeItemLabelPosition();
//     var2.setSeriesNegativeItemLabelPosition(0, var23, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var2.", var22.equals(var2) == var2.equals(var22));
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test407"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    boolean var17 = var2.getItemVisible(10, 10);
    var2.setBase(100.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var24 = var23.getBaseNegativeItemLabelPosition();
    var2.setSeriesNegativeItemLabelPosition(10, var24);
    java.awt.Color var30 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var31 = var30.getTransparency();
    var2.setSeriesOutlinePaint(0, (java.awt.Paint)var30);
    float[] var36 = new float[] { 0.0f, (-1.0f), 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var37 = var30.getRGBComponents(var36);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test408"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    int var35 = var33.getDatasetIndex();
    java.lang.String var36 = var33.getURLText();
    java.lang.Comparable var37 = var33.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "hi!"+ "'", var36.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test409"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    java.awt.Font var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelFont(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test410"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.Marker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var2.drawRangeMarker(var9, var10, var11, var12, var13);
//     boolean var17 = var2.getItemVisible(10, 10);
//     var2.setBase(100.0d);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var25 = var2.initialise(var20, var21, var22, (-1), var24);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test411"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    org.jfree.chart.event.ChartProgressListener var10 = null;
    var9.removeProgressListener(var10);
    org.jfree.chart.event.ChartChangeListener var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.addChangeListener(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test412"); }


    java.util.List var8 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)100.0f, (java.lang.Number)(short)10, (java.lang.Number)100, (java.lang.Number)1.0d, (java.lang.Number)10.0d, (java.lang.Number)(-1), (java.lang.Number)(short)0, (java.lang.Number)0.0d, var8);
    java.lang.Number var10 = var9.getQ1();
    java.util.List var11 = var9.getOutliers();
    java.lang.Number var12 = var9.getMaxOutlier();
    java.util.List var13 = var9.getOutliers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100+ "'", var10.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.0d+ "'", var12.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test413"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    java.awt.Shape var12 = var2.getBaseShape();
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesToolTipGenerator((-1), var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test414"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     int var7 = var6.getCategoryCount();
//     java.lang.Number var8 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var6);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test415"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    org.jfree.chart.LegendItem var17 = var2.getLegendItem(1, 1);
    boolean var18 = var2.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test416"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    java.lang.Comparable var6 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var9.setBaseCreateEntities(true);
    java.awt.Paint var13 = null;
    var9.setSeriesItemLabelPaint(0, var13, true);
    java.awt.Shape var16 = var9.getBaseShape();
    java.awt.Paint var19 = var9.getItemLabelPaint(10, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSectionPaint(var6, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test417"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
//     var2.setBaseCreateEntities(true, false);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var2.drawOutline(var12, var13, var14);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test418"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseCreateEntities(true, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
    var2.setBaseToolTipGenerator(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var2.getDrawingSupplier();
    org.jfree.chart.plot.CategoryPlot var15 = var2.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test419"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Paint[] var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var10);
    java.awt.Shape var12 = var11.getNextShape();
    java.awt.Paint var13 = var11.getNextFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test420"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    var33.setSeriesKey((java.lang.Comparable)100L);
    boolean var37 = var33.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test421"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var6 = var2.getLabelOffsetType();
    double var7 = var2.getStartValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0d));

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test422"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test423"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    boolean var9 = var2.getBaseSeriesVisible();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = null;
    var2.setLegendItemToolTipGenerator(var10);
    java.awt.Stroke var13 = var2.getSeriesStroke(10);
    java.awt.Font var15 = var2.getSeriesItemLabelFont((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test424"); }


    java.lang.Object var0 = null;
    java.awt.Font var2 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot(var3);
    org.jfree.data.category.CategoryDataset var5 = null;
    var4.setDataset(var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var4.axisChanged(var7);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("CONTRACT", var2, (org.jfree.chart.plot.Plot)var4, false);
    org.jfree.chart.event.ChartProgressListener var11 = null;
    var10.removeProgressListener(var11);
    org.jfree.chart.event.ChartChangeEventType var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var14 = new org.jfree.chart.event.ChartChangeEvent(var0, var10, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test425"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var2.getSeriesURLGenerator(100);
    java.awt.Paint var8 = var2.lookupSeriesOutlinePaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test426"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     int var7 = var6.getCategoryCount();
//     java.lang.Object var8 = var6.clone();
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test427"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!", "hi!");
    var5.setVersion("");
    var5.setInfo("");
    java.lang.String var10 = var5.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "hi!"+ "'", var10.equals("hi!"));

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test428"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    boolean var9 = var2.getBaseSeriesVisible();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = null;
    var2.setLegendItemToolTipGenerator(var10);
    java.awt.Stroke var13 = var2.getSeriesStroke(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelsVisible((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test429"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    var1.handleClick((-1), 0, var4);
    java.lang.String var6 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Multiple Pie Plot"+ "'", var6.equals("Multiple Pie Plot"));

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test430"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test431"); }


    java.lang.Number var1 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(byte)1, var1);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test432"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    java.lang.String var5 = var4.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test433"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getHeightConstraintType();
    org.jfree.data.Range var4 = var2.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test434"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     int var7 = var6.getCategoryCount();
//     int var9 = var6.getSeriesIndex((java.lang.Comparable)100.0f);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test435"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedHeight(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test436"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     java.lang.Number var10 = var6.getValue((java.lang.Comparable)(-460), (java.lang.Comparable)10L);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test437"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-460), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test438"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)(-11.0d), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test439"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    var2.setEndValue(10.0d);
    java.awt.Stroke var6 = var2.getStroke();
    var2.setStartValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test440"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.lang.String var4 = var3.toString();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    java.awt.Color var10 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var13 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var14 = var13.getLabel();
    var13.setEndValue(10.0d);
    java.awt.Stroke var17 = var13.getStroke();
    org.jfree.chart.plot.CategoryMarker var18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var10, var17);
    var6.setNoDataMessagePaint((java.awt.Paint)var10);
    java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var24 = var23.getTransparency();
    java.awt.Color var25 = var23.brighter();
    var6.setLabelPaint((java.awt.Paint)var25);
    var6.setForegroundAlpha(10.0f);
    boolean var29 = var3.equals((java.lang.Object)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "CONTRACT"+ "'", var4.equals("CONTRACT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test441"); }


    java.text.DateFormat var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit((-460), 0, 100, (-1), var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test442"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)(-1), (java.lang.Number)(short)10);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test443"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 100.0d, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test444"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test445"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(10, var10);
//     java.awt.Shape var12 = var2.getBaseShape();
//     org.jfree.chart.urls.CategoryURLGenerator var14 = null;
//     var2.setSeriesURLGenerator(1, var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var2.drawBackground(var16, var17, var18);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test446"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    java.lang.String var35 = var33.getLabel();
    int var36 = var33.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "hi!"+ "'", var35.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test447"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    java.awt.Shape var12 = var2.getBaseShape();
    java.awt.Paint var13 = var2.getBasePaint();
    java.awt.Paint var15 = var2.getSeriesOutlinePaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test448"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test449"); }
// 
// 
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var5, "", "");
//     java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var13 = var12.getTransparency();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var18 = var17.getTransparency();
//     boolean var19 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var12, (java.awt.Paint)var17);
//     org.jfree.chart.title.LegendGraphic var20 = new org.jfree.chart.title.LegendGraphic(var5, (java.awt.Paint)var12);
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.plot.IntervalMarker var27 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var28 = var27.getLabel();
//     var27.setEndValue(10.0d);
//     java.awt.Stroke var31 = var27.getStroke();
//     org.jfree.chart.plot.CategoryMarker var32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var24, var31);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot(var33);
//     java.awt.Color var38 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.plot.IntervalMarker var41 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var42 = var41.getLabel();
//     var41.setEndValue(10.0d);
//     java.awt.Stroke var45 = var41.getStroke();
//     org.jfree.chart.plot.CategoryMarker var46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var38, var45);
//     var34.setNoDataMessagePaint((java.awt.Paint)var38);
//     java.awt.Color var51 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var52 = var51.getTransparency();
//     java.awt.Color var53 = var51.brighter();
//     var34.setLabelPaint((java.awt.Paint)var53);
//     java.awt.Paint var55 = var34.getLabelPaint();
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = ", "hi!", "hi!", "hi!", var5, var31, var55);
//     
//     // Checks the contract:  equals-hashcode on var27 and var41
//     assertTrue("Contract failed: equals-hashcode on var27 and var41", var27.equals(var41) ? var27.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var27
//     assertTrue("Contract failed: equals-hashcode on var41 and var27", var41.equals(var27) ? var41.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var46
//     assertTrue("Contract failed: equals-hashcode on var32 and var46", var32.equals(var46) ? var32.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var32
//     assertTrue("Contract failed: equals-hashcode on var46 and var32", var46.equals(var32) ? var46.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test450"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(1, 1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test451"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = ");
//     var1.setToolTipText("");
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var1.draw(var4, var5);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test452"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(10.0d);
    double var2 = var1.getMax();
    double var3 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test453"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test454"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(1.0d, (-11.0d));
    org.jfree.chart.util.RectangleAnchor var5 = null;
    java.awt.geom.Rectangle2D var6 = org.jfree.chart.util.RectangleAnchor.createRectangle(var2, 1.0d, (-1.0d), var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test455"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var6);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test456"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 0.0d);
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test457"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    org.jfree.chart.event.MarkerChangeEvent var15 = null;
    var1.markerChanged(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test458"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.labels.PieToolTipGenerator var6 = var1.getToolTipGenerator();
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot(var7);
    org.jfree.data.category.CategoryDataset var9 = null;
    var8.setDataset(var9);
    org.jfree.chart.plot.DrawingSupplier var11 = var8.getDrawingSupplier();
    var1.setDrawingSupplier(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test459"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    int var35 = var33.getDatasetIndex();
    java.awt.Shape var36 = var33.getShape();
    org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity(var36, "hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test460"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    org.jfree.chart.util.GradientPaintTransformer var6 = null;
    var2.setGradientPaintTransformer(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test461"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var3.setBaseCreateEntities(true);
    var3.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var3.setBaseCreateEntities(true, false);
    var3.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
    var3.setSeriesItemLabelsVisible(0, false);
    boolean var22 = var3.isItemLabelVisible(0, 0);
    java.awt.Shape var25 = var3.getItemShape(100, 0);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var0, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test462"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Paint var9 = var1.getSectionPaint((java.lang.Comparable)false);
    boolean var10 = var1.getIgnoreZeroValues();
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var15 = var14.getTransparency();
    java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var20 = var19.getTransparency();
    boolean var21 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var14, (java.awt.Paint)var19);
    java.awt.Color var22 = var14.brighter();
    var1.setLabelShadowPaint((java.awt.Paint)var22);
    double var24 = var1.getLabelLinkMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.05d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test463"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var4 = var3.getBaseNegativeItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var5 = var4.getItemLabelAnchor();
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.text.TextAnchor var13 = var8.getLabelTextAnchor();
    org.jfree.chart.labels.ItemLabelPosition var14 = new org.jfree.chart.labels.ItemLabelPosition(var5, var13);
    org.jfree.chart.text.TextAnchor var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var17 = new org.jfree.chart.labels.ItemLabelPosition(var0, var13, var15, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test464"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    var1.setBackgroundImageAlpha(1.0f);
    java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var29 = var28.getTransparency();
    java.awt.Color var30 = var28.brighter();
    var1.setLabelBackgroundPaint((java.awt.Paint)var30);
    float var32 = var1.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0f);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test465"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
//     boolean var6 = var3.containsDomainRange(0L, 1L);
//     java.lang.Object var7 = var3.clone();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var17 = var16.getLabel();
//     var16.setEndValue(10.0d);
//     java.awt.Stroke var20 = var16.getStroke();
//     org.jfree.chart.plot.CategoryMarker var21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var13, var20);
//     var9.setNoDataMessagePaint((java.awt.Paint)var13);
//     java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var27 = var26.getTransparency();
//     java.awt.Color var28 = var26.brighter();
//     var9.setLabelPaint((java.awt.Paint)var28);
//     boolean var30 = var3.equals((java.lang.Object)var28);
//     var3.addException(1L, 0L);
//     java.util.Date var34 = null;
//     long var35 = var3.toTimelineValue(var34);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test466"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "ChartEntity: tooltip = ");
    java.awt.Color var12 = java.awt.Color.getHSBColor(10.0f, 0.0f, (-1.0f));
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var16 = var15.getLabel();
    var15.setEndValue(10.0d);
    java.awt.Stroke var19 = var15.getStroke();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var26.setBaseCreateEntities(true);
    java.awt.Paint var30 = null;
    var26.setSeriesItemLabelPaint(0, var30, true);
    java.awt.Shape var33 = var26.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var36.setBaseCreateEntities(true);
    java.awt.Paint var40 = null;
    var36.setSeriesItemLabelPaint(0, var40, true);
    java.awt.Stroke var44 = null;
    var36.setSeriesStroke(10, var44);
    java.awt.Shape var46 = var36.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var49 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var50 = var49.getLabelOffsetType();
    java.awt.Paint var51 = var49.getPaint();
    var36.setWallPaint(var51);
    org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var33, var51);
    java.awt.Paint var54 = var53.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem(var0, "CONTRACT", "hi!", "hi!", var6, (java.awt.Paint)var12, var19, var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test467"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    var2.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var7 = var2.getSeriesFillPaint(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test468"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var4 = null;
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
    java.util.List var7 = var6.getRowKeys();
    org.jfree.data.general.SeriesChangeEvent var8 = null;
    var6.seriesChanged(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var11 = var6.getSeriesKey(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test469"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape var9 = null;
//     java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var10);
//     java.awt.Shape var12 = var11.getNextShape();
//     java.lang.Object var13 = var11.clone();
//     java.lang.Object var14 = var11.clone();
//     
//     // Checks the contract:  equals-hashcode on var13 and var14
//     assertTrue("Contract failed: equals-hashcode on var13 and var14", var13.equals(var14) ? var13.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var13
//     assertTrue("Contract failed: equals-hashcode on var14 and var13", var14.equals(var13) ? var14.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test470"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, (-1.0d), 0.0d);
    org.jfree.data.KeyedObject var6 = new org.jfree.data.KeyedObject((java.lang.Comparable)'#', (java.lang.Object)var5);
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, var8);
    org.jfree.chart.block.LengthConstraintType var10 = var9.getHeightConstraintType();
    java.lang.String var11 = var10.toString();
    boolean var12 = var6.equals((java.lang.Object)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var11.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test471"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    var1.setLabelGap(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test472"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(100.0d);
    org.jfree.chart.util.RectangleEdge var3 = null;
    var1.moveCursor(10.0d, var3);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test473"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var2.getBaseURLGenerator();
    java.awt.Stroke var6 = var2.getBaseStroke();
    boolean var9 = var2.getItemCreateEntity((-460), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test474"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test475"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    var2.setEndValue(10.0d);
    java.awt.Paint var6 = var2.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test476"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("ChartEntity: tooltip = ", "CONTRACT", "", var3, "hi!", "hi!", "");
    java.awt.Image var8 = null;
    var7.setLogo(var8);
    java.lang.String var10 = var7.getLicenceText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test477"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     org.jfree.data.general.SeriesChangeEvent var8 = null;
//     var6.seriesChanged(var8);
//     int var11 = var6.getCategoryIndex((java.lang.Comparable)(-460));
// 
//   }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test478"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var3.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = var3.getSeriesURLGenerator(100);
//     var3.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     java.awt.Font var13 = var3.getItemLabelFont(0, 1);
//     org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var17 = var16.getLabelOffsetType();
//     java.awt.Paint var18 = var16.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var21 = null;
//     org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("ChartEntity: tooltip = ", var13, var18, 1.0f, 1, var21);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test479"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = null;
    var2.setLegendItemToolTipGenerator(var4);
    var2.setIncludeBaseInRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test480"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     java.lang.Number var10 = var6.getEndValue((java.lang.Comparable)(short)1, (java.lang.Comparable)(byte)0);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test481"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Paint[] var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var10);
    java.awt.Shape var12 = var11.getNextShape();
    java.lang.Object var13 = var11.clone();
    java.awt.Stroke var14 = var11.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test482"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var4.setBaseCreateEntities(true);
    java.awt.Paint var8 = null;
    var4.setSeriesItemLabelPaint(0, var8, true);
    java.awt.Shape var11 = var4.getBaseShape();
    var4.setSeriesVisibleInLegend(1, (java.lang.Boolean)true, true);
    java.awt.Shape var17 = var4.getSeriesShape(1);
    int var18 = var1.compareTo((java.lang.Object)1);
    double var19 = var1.getSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test483"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     java.lang.Object var8 = var6.clone();
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test484"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape var9 = null;
//     java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var10);
//     java.awt.Paint var12 = null;
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     java.awt.Paint var14 = null;
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Paint[] var16 = null;
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var21 = null;
//     java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
//     org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var15, var16, var18, var20, var22);
//     java.awt.Paint var24 = null;
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Paint var26 = null;
//     java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
//     java.awt.Paint[] var28 = null;
//     java.awt.Stroke var29 = null;
//     java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
//     java.awt.Stroke var31 = null;
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     java.awt.Shape var33 = null;
//     java.awt.Shape[] var34 = new java.awt.Shape[] { var33};
//     org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var25, var27, var28, var30, var32, var34);
//     java.awt.Paint var36 = null;
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var36};
//     java.awt.Paint var38 = null;
//     java.awt.Paint[] var39 = new java.awt.Paint[] { var38};
//     java.awt.Paint[] var40 = null;
//     java.awt.Stroke var41 = null;
//     java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Shape var45 = null;
//     java.awt.Shape[] var46 = new java.awt.Shape[] { var45};
//     org.jfree.chart.plot.DefaultDrawingSupplier var47 = new org.jfree.chart.plot.DefaultDrawingSupplier(var37, var39, var40, var42, var44, var46);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var50.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var53 = var50.getBaseURLGenerator();
//     java.awt.Stroke var54 = var50.getBaseStroke();
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     java.awt.Paint var56 = null;
//     java.awt.Paint[] var57 = new java.awt.Paint[] { var56};
//     java.awt.Paint var58 = null;
//     java.awt.Paint[] var59 = new java.awt.Paint[] { var58};
//     java.awt.Paint[] var60 = null;
//     java.awt.Stroke var61 = null;
//     java.awt.Stroke[] var62 = new java.awt.Stroke[] { var61};
//     java.awt.Stroke var63 = null;
//     java.awt.Stroke[] var64 = new java.awt.Stroke[] { var63};
//     java.awt.Shape var65 = null;
//     java.awt.Shape[] var66 = new java.awt.Shape[] { var65};
//     org.jfree.chart.plot.DefaultDrawingSupplier var67 = new org.jfree.chart.plot.DefaultDrawingSupplier(var57, var59, var60, var62, var64, var66);
//     org.jfree.chart.event.RendererChangeEvent var68 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var66);
//     org.jfree.chart.plot.DefaultDrawingSupplier var69 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var16, var28, var44, var55, var66);
//     
//     // Checks the contract:  equals-hashcode on var11 and var23
//     assertTrue("Contract failed: equals-hashcode on var11 and var23", var11.equals(var23) ? var11.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var35
//     assertTrue("Contract failed: equals-hashcode on var11 and var35", var11.equals(var35) ? var11.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var47
//     assertTrue("Contract failed: equals-hashcode on var11 and var47", var11.equals(var47) ? var11.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var67
//     assertTrue("Contract failed: equals-hashcode on var11 and var67", var11.equals(var67) ? var11.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var11
//     assertTrue("Contract failed: equals-hashcode on var23 and var11", var23.equals(var11) ? var23.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var35
//     assertTrue("Contract failed: equals-hashcode on var23 and var35", var23.equals(var35) ? var23.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var47
//     assertTrue("Contract failed: equals-hashcode on var23 and var47", var23.equals(var47) ? var23.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var67
//     assertTrue("Contract failed: equals-hashcode on var23 and var67", var23.equals(var67) ? var23.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var11
//     assertTrue("Contract failed: equals-hashcode on var35 and var11", var35.equals(var11) ? var35.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var23
//     assertTrue("Contract failed: equals-hashcode on var35 and var23", var35.equals(var23) ? var35.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var47
//     assertTrue("Contract failed: equals-hashcode on var35 and var47", var35.equals(var47) ? var35.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var67
//     assertTrue("Contract failed: equals-hashcode on var35 and var67", var35.equals(var67) ? var35.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var11
//     assertTrue("Contract failed: equals-hashcode on var47 and var11", var47.equals(var11) ? var47.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var23
//     assertTrue("Contract failed: equals-hashcode on var47 and var23", var47.equals(var23) ? var47.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var35
//     assertTrue("Contract failed: equals-hashcode on var47 and var35", var47.equals(var35) ? var47.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var67
//     assertTrue("Contract failed: equals-hashcode on var47 and var67", var47.equals(var67) ? var47.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var11
//     assertTrue("Contract failed: equals-hashcode on var67 and var11", var67.equals(var11) ? var67.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var23
//     assertTrue("Contract failed: equals-hashcode on var67 and var23", var67.equals(var23) ? var67.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var35
//     assertTrue("Contract failed: equals-hashcode on var67 and var35", var67.equals(var35) ? var67.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var47
//     assertTrue("Contract failed: equals-hashcode on var67 and var47", var67.equals(var47) ? var67.hashCode() == var47.hashCode() : true);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test485"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var6 = var2.getSeriesURLGenerator(100);
//     var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     java.awt.Font var12 = var2.getItemLabelFont(0, 1);
//     java.lang.Comparable[] var14 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var16 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var17 = null;
//     java.lang.Number[][] var18 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var19 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var14, var16, var17, var18);
//     java.util.List var20 = var19.getRowKeys();
//     org.jfree.data.general.SeriesChangeEvent var21 = null;
//     var19.seriesChanged(var21);
//     org.jfree.data.Range var23 = var2.findRangeBounds((org.jfree.data.category.CategoryDataset)var19);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test486"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     org.jfree.data.general.PieDataset var2 = null;
//     var1.setDataset(var2);
//     var1.setMaximumLabelWidth(100.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = null;
//     var1.setURLGenerator(var6);
//     boolean var8 = var1.getIgnoreZeroValues();
//     double var9 = var1.getMaximumExplodePercent();
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test487"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test488"); }


    java.util.List var8 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)100.0f, (java.lang.Number)(short)10, (java.lang.Number)100, (java.lang.Number)1.0d, (java.lang.Number)10.0d, (java.lang.Number)(-1), (java.lang.Number)(short)0, (java.lang.Number)0.0d, var8);
    java.util.List var10 = var9.getOutliers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test489"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    var9.setAntiAlias(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var17 = var9.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test490"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(100.0d);
    var1.cursorDown(17.0d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test491"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(1.0d, (-11.0d));
    var2.setHeight(17.0d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test492"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    java.awt.Font var5 = null;
    var2.setSeriesItemLabelFont(10, var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    var2.setBaseOutlinePaint((java.awt.Paint)var9);
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var11);
    var2.setAutoPopulateSeriesShape(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test493"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test494"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, 0.0d, 1.0d, 10.0d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test495"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
    var2.setBaseToolTipGenerator(var12);
    java.awt.Paint var14 = var2.getBaseOutlinePaint();
    boolean var15 = var2.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test496"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 10.0f, (-1.0f));
    var1.setLabelBackgroundPaint((java.awt.Paint)var26);
    var1.setLabelLinksVisible(false);
    var1.setOutlineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test497"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    boolean var17 = var2.getItemVisible(10, 10);
    var2.setBase(100.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var24 = var23.getBaseNegativeItemLabelPosition();
    var2.setSeriesNegativeItemLabelPosition(10, var24);
    java.lang.Object var26 = var2.clone();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    java.awt.Stroke var32 = var29.getOutlineStroke();
    var2.setBaseOutlineStroke(var32, false);
    boolean var36 = var2.isSeriesVisibleInLegend((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test498"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.data.Range var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDefaultAutoRange(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test499"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    java.awt.Stroke var6 = var1.getSeparatorStroke();
    var1.setShadowYOffset(100.0d);
    java.lang.Comparable var9 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var13 = var12.getBaseNegativeItemLabelPosition();
    java.awt.Font var15 = null;
    var12.setSeriesItemLabelFont(10, var15);
    java.awt.Color var19 = java.awt.Color.getColor("hi!", (-1));
    var12.setBaseOutlinePaint((java.awt.Paint)var19);
    java.awt.Stroke var23 = var12.getItemOutlineStroke(10, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSectionOutlineStroke(var9, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test500"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    var2.setEndValue(10.0d);
    java.awt.Stroke var6 = var2.getStroke();
    java.awt.Stroke var7 = var2.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

}
