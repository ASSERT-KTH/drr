
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(0.0d);
    var1.cursorUp(100.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    var1.setIgnoreZeroValues(true);
    boolean var8 = var1.getSeparatorsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var9 = var8.getTransparency();
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var14 = var13.getTransparency();
    boolean var15 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var8, (java.awt.Paint)var13);
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var8);
    org.jfree.chart.util.RectangleAnchor var17 = var16.getShapeAnchor();
    org.jfree.chart.text.TextBlockAnchor var18 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var21 = new org.jfree.chart.axis.CategoryLabelPosition(var17, var18, var19, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Shape var9 = var2.getBaseShape();
//     var2.setBaseItemLabelsVisible(true, true);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     java.lang.Comparable[] var21 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var23 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var24 = null;
//     java.lang.Number[][] var25 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var26 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var21, var23, var24, var25);
//     java.util.List var27 = var26.getRowKeys();
//     var2.drawItem(var13, var14, var15, var16, var17, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.data.category.CategoryDataset)var26, 0, 0, 0);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var2.getSeriesURLGenerator(100);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var12 = var2.getItemLabelFont(0, 1);
    var2.setItemLabelAnchorOffset((-11.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    int var22 = var20.getRed();
    int var23 = var20.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-16579837));

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var4 = var3.getItemLabelAnchor();
//     org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var8 = var7.getLabel();
//     var7.setEndValue(10.0d);
//     java.awt.Stroke var11 = var7.getStroke();
//     org.jfree.chart.text.TextAnchor var12 = var7.getLabelTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var13 = new org.jfree.chart.labels.ItemLabelPosition(var4, var12);
//     org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var17 = var16.getLabel();
//     var16.setEndValue(10.0d);
//     java.awt.Stroke var20 = var16.getStroke();
//     org.jfree.chart.text.TextAnchor var21 = var16.getLabelTextAnchor();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var25 = var24.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var26 = var25.getItemLabelAnchor();
//     org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var30 = var29.getLabel();
//     var29.setEndValue(10.0d);
//     java.awt.Stroke var33 = var29.getStroke();
//     org.jfree.chart.text.TextAnchor var34 = var29.getLabelTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var35 = new org.jfree.chart.labels.ItemLabelPosition(var26, var34);
//     org.jfree.chart.labels.ItemLabelPosition var37 = new org.jfree.chart.labels.ItemLabelPosition(var4, var21, var34, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var3 and var25
//     assertTrue("Contract failed: equals-hashcode on var3 and var25", var3.equals(var25) ? var3.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var35
//     assertTrue("Contract failed: equals-hashcode on var13 and var35", var13.equals(var35) ? var13.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var37
//     assertTrue("Contract failed: equals-hashcode on var13 and var37", var13.equals(var37) ? var13.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var3
//     assertTrue("Contract failed: equals-hashcode on var25 and var3", var25.equals(var3) ? var25.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var13
//     assertTrue("Contract failed: equals-hashcode on var35 and var13", var35.equals(var13) ? var35.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var37
//     assertTrue("Contract failed: equals-hashcode on var35 and var37", var35.equals(var37) ? var35.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var13
//     assertTrue("Contract failed: equals-hashcode on var37 and var13", var37.equals(var13) ? var37.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var35
//     assertTrue("Contract failed: equals-hashcode on var37 and var35", var37.equals(var35) ? var37.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var16
//     assertTrue("Contract failed: equals-hashcode on var7 and var16", var7.equals(var16) ? var7.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var29
//     assertTrue("Contract failed: equals-hashcode on var7 and var29", var7.equals(var29) ? var7.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var7
//     assertTrue("Contract failed: equals-hashcode on var16 and var7", var16.equals(var7) ? var16.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var29
//     assertTrue("Contract failed: equals-hashcode on var16 and var29", var16.equals(var29) ? var16.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var7
//     assertTrue("Contract failed: equals-hashcode on var29 and var7", var29.equals(var7) ? var29.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var16
//     assertTrue("Contract failed: equals-hashcode on var29 and var16", var29.equals(var16) ? var29.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    int var14 = var9.getSubtitleCount();
    boolean var15 = var9.isBorderVisible();
    org.jfree.chart.title.Title var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.addSubtitle(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    var1.setBackgroundImageAlpha(1.0f);
    double var25 = var1.getLabelLinkMargin();
    boolean var26 = var1.isCircular();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("CONTRACT");

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, (-1.0d), 0.0f, (-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, (-1.0f), 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    java.lang.Object var6 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeValue((java.lang.Comparable)100, (java.lang.Comparable)100);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Stroke var4 = var2.getSeriesStroke(1);
    var2.setMaximumBarWidth((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Paint var9 = var1.getSectionPaint((java.lang.Comparable)false);
    boolean var10 = var1.getIgnoreZeroValues();
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseSectionPaint(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    java.lang.Object var6 = var1.clone();
    var1.removeColumn(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var1.getRowIndex((java.lang.Comparable)100);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "hi!");
    java.lang.String var5 = var4.getLicenceName();
    java.lang.String var6 = var4.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Font var5 = var2.getItemLabelFont(0, 1);
    boolean var6 = var2.getAutoPopulateSeriesStroke();
    boolean var8 = var2.isSeriesItemLabelsVisible(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    org.jfree.chart.LegendItem var17 = var2.getLegendItem(1, 1);
    org.jfree.chart.labels.ItemLabelPosition var19 = var2.getSeriesNegativeItemLabelPosition(10);
    double var20 = var2.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    double var10 = var2.getYOffset();
    int var11 = var2.getPassCount();
    org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var15 = var14.getLabelOffsetType();
    java.awt.Paint var16 = var14.getOutlinePaint();
    var2.setBaseOutlinePaint(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.labels.PieToolTipGenerator var6 = var1.getToolTipGenerator();
    var1.setBackgroundAlpha(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     var6.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var6);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("");

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    var33.setSeriesKey((java.lang.Comparable)100L);
    java.awt.Shape var37 = var33.getShape();
    java.awt.Stroke var38 = var33.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-460), 100, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    java.text.AttributedString var0 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, var5);
    org.jfree.chart.block.LengthConstraintType var7 = var6.getHeightConstraintType();
    java.lang.String var8 = var7.toString();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity(var12, "");
    boolean var15 = var7.equals((java.lang.Object)var12);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    org.jfree.data.general.PieDataset var18 = null;
    var17.setDataset(var18);
    var17.setMaximumLabelWidth(100.0d);
    org.jfree.chart.labels.PieToolTipGenerator var22 = var17.getToolTipGenerator();
    java.awt.Paint var23 = var17.getNoDataMessagePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem(var0, "ChartEntity: tooltip = ", "hi!", "hi!", var12, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var8.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var3 = var2.getLowerMargin();
//     java.lang.Object var4 = var2.clone();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var6.setVisible(true);
//     java.lang.Object var9 = var6.clone();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var15 = var14.getLowerMargin();
//     java.lang.Object var16 = var14.clone();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var18.setVisible(true);
//     java.lang.Object var21 = var18.clone();
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var18, var22);
//     int var24 = var11.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var14);
//     
//     // Checks the contract:  equals-hashcode on var11 and var23
//     assertTrue("Contract failed: equals-hashcode on var11 and var23", var11.equals(var23) ? var11.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var11
//     assertTrue("Contract failed: equals-hashcode on var23 and var11", var23.equals(var11) ? var23.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var2.getBaseURLGenerator();
    java.awt.Stroke var6 = var2.getBaseStroke();
    java.awt.Paint var7 = var2.getBasePaint();
    java.awt.Stroke var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlineStroke(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var3.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var3.getSeriesURLGenerator(100);
    var3.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var13 = var3.getItemLabelFont(0, 1);
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("", var13);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var22 = var21.getLabel();
    var21.setEndValue(10.0d);
    java.awt.Stroke var25 = var21.getStroke();
    org.jfree.chart.plot.CategoryMarker var26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var18, var25);
    var14.setPaint((java.awt.Paint)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(0L, 1, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var3.toMillisecond((-1L));
      fail("Expected exception of type java.lang.ArithmeticException");
    } catch (java.lang.ArithmeticException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    double var4 = var2.getEndValue();
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var2.notifyListeners(var5);
    org.jfree.chart.util.RectangleAnchor var7 = var2.getLabelAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var2.getSeriesURLGenerator(100);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = var2.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var8 = var2.getNegativeItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(1.0d, (-11.0d));
    double var3 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    var2.setEndValue(10.0d);
    java.awt.Stroke var6 = var2.getStroke();
    org.jfree.chart.text.TextAnchor var7 = var2.getLabelTextAnchor();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var11 = var10.getBaseNegativeItemLabelPosition();
    java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    var10.setSeriesFillPaint(0, (java.awt.Paint)var16);
    var2.setOutlinePaint((java.awt.Paint)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Paint var9 = var1.getSectionPaint((java.lang.Comparable)false);
    java.awt.Image var10 = var1.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    int var35 = var33.getSeriesIndex();
    java.awt.Paint var36 = var33.getFillPaint();
    java.lang.String var37 = var33.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + ""+ "'", var37.equals(""));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.Marker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var2.drawRangeMarker(var9, var10, var11, var12, var13);
//     boolean var17 = var2.getItemVisible(10, 10);
//     var2.setBase(100.0d);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var24 = var23.getBaseNegativeItemLabelPosition();
//     var2.setSeriesNegativeItemLabelPosition(10, var24);
//     java.awt.Color var30 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var31 = var30.getTransparency();
//     var2.setSeriesOutlinePaint(0, (java.awt.Paint)var30);
//     org.jfree.chart.urls.CategoryURLGenerator var34 = var2.getSeriesURLGenerator(100);
//     java.lang.Comparable[] var36 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var38 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var39 = null;
//     java.lang.Number[][] var40 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var41 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var36, var38, var39, var40);
//     java.util.List var42 = var41.getRowKeys();
//     org.jfree.data.general.SeriesChangeEvent var43 = null;
//     var41.seriesChanged(var43);
//     org.jfree.data.general.DatasetGroup var45 = var41.getGroup();
//     org.jfree.data.Range var46 = var2.findRangeBounds((org.jfree.data.category.CategoryDataset)var41);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    var4.setURLText("hi!");
    java.lang.String var7 = var4.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "poly"+ "'", var7.equals("poly"));

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Shape var6 = var2.getSeriesShape(0);
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var2.notifyListeners(var7);
//     var2.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var15 = var14.getLabelOffsetType();
//     java.awt.Paint var16 = var14.getPaint();
//     var2.setSeriesPaint(1, var16, false);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     var2.drawOutline(var19, var20, var21);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    var2.setSeriesVisibleInLegend(1, (java.lang.Boolean)false, false);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var20, "");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShape((-1), var20, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    float var6 = var2.getAlpha();
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot(var7);
    org.jfree.chart.util.RectangleInsets var9 = var8.getInsets();
    var2.setLabelOffset(var9);
    double var12 = var9.calculateBottomOutset((-11.0d));
    double var14 = var9.extendWidth(1.0d);
    java.awt.geom.Rectangle2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var18 = var9.createInsetRectangle(var15, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 17.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    java.awt.Shape var12 = var2.getBaseShape();
    org.jfree.chart.util.RectangleAnchor var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, var13, 10.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getHeightConstraintType();
    java.lang.String var4 = var3.toString();
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var8 = var7.getLabel();
    var7.setEndValue(10.0d);
    java.awt.Stroke var11 = var7.getStroke();
    org.jfree.chart.text.TextAnchor var12 = var7.getLabelTextAnchor();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var15.setBaseCreateEntities(true);
    java.awt.Paint var19 = null;
    var15.setSeriesItemLabelPaint(0, var19, true);
    java.awt.Shape var22 = var15.getBaseShape();
    java.awt.Paint var25 = var15.getItemLabelPaint(10, 0);
    java.awt.Stroke var26 = var15.getBaseOutlineStroke();
    var7.setOutlineStroke(var26);
    boolean var28 = var3.equals((java.lang.Object)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var4.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    java.lang.Object var6 = var1.clone();
    var1.removeColumn((java.lang.Comparable)(byte)(-1));
    int var9 = var1.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    double var3 = var2.getRight();
    double var5 = var2.calculateRightOutset(17.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 8.0d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1), var1, 100, (-1));
    org.jfree.chart.JFreeChart var5 = var4.getChart();
    var4.setPercent((-16579837));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var4 = var3.getLabelOffsetType();
//     java.awt.Paint var5 = var3.getPaint();
//     java.awt.Stroke var6 = var3.getOutlineStroke();
//     float var7 = var3.getAlpha();
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getInsets();
//     var3.setLabelOffset(var10);
//     org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 10.0d, (-1.0d));
//     var3.setLabelOffset(var16);
//     org.jfree.chart.util.RectangleAnchor var18 = var3.getLabelAnchor();
//     java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var18);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    double var12 = var11.getDomainCrosshairValue();
    org.jfree.chart.axis.AxisLocation var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeAxisLocation(var13, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    java.util.List var8 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)100.0f, (java.lang.Number)(short)10, (java.lang.Number)100, (java.lang.Number)1.0d, (java.lang.Number)10.0d, (java.lang.Number)(-1), (java.lang.Number)(short)0, (java.lang.Number)0.0d, var8);
    java.lang.Number var10 = var9.getQ1();
    java.util.List var11 = var9.getOutliers();
    java.lang.Number var12 = var9.getQ3();
    java.lang.Number var13 = var9.getMaxOutlier();
    org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var17 = var16.getLabelOffsetType();
    java.awt.Paint var18 = var16.getPaint();
    java.awt.Stroke var19 = var16.getOutlineStroke();
    float var20 = var16.getAlpha();
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getInsets();
    var16.setLabelOffset(var23);
    org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 10.0d, (-1.0d));
    var16.setLabelOffset(var29);
    boolean var31 = var9.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100+ "'", var10.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1.0d+ "'", var12.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0.0d+ "'", var13.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var4 = var3.getRotationAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = ");
    double var2 = var1.getWidth();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var12 = var11.getLabel();
    var11.setEndValue(10.0d);
    java.awt.Stroke var15 = var11.getStroke();
    org.jfree.chart.plot.CategoryMarker var16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var8, var15);
    var4.setNoDataMessagePaint((java.awt.Paint)var8);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var22 = var21.getTransparency();
    java.awt.Color var23 = var21.brighter();
    var4.setLabelPaint((java.awt.Paint)var23);
    var1.setPaint((java.awt.Paint)var23);
    var1.setPadding(100.0d, (-11.0d), 0.0d, 100.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var37.setBaseCreateEntities(true);
    java.awt.Paint var41 = null;
    var37.setSeriesItemLabelPaint(0, var41, true);
    java.awt.Shape var44 = var37.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var47.setBaseCreateEntities(true);
    java.awt.Paint var51 = null;
    var47.setSeriesItemLabelPaint(0, var51, true);
    java.awt.Stroke var55 = null;
    var47.setSeriesStroke(10, var55);
    java.awt.Shape var57 = var47.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var60 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var61 = var60.getLabelOffsetType();
    java.awt.Paint var62 = var60.getPaint();
    var47.setWallPaint(var62);
    org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var44, var62);
    var1.setPaint(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-11.0d), 100.0d);
    var4.clear();

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, (-11.0d));
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]"+ "'", var3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]"));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
    var2.setBaseToolTipGenerator(var12);
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesToolTipGenerator((-16579837), var15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    double var10 = var2.getYOffset();
    boolean var11 = var2.getRenderAsPercentages();
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelGenerator((-16579837), var13, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var5 = org.jfree.data.Range.expand(var0, 100.0d, (-11.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("", "hi!");

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var6 = var3.containsDomainRange(0L, 1L);
    java.lang.Object var7 = var3.clone();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var17 = var16.getLabel();
    var16.setEndValue(10.0d);
    java.awt.Stroke var20 = var16.getStroke();
    org.jfree.chart.plot.CategoryMarker var21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var13, var20);
    var9.setNoDataMessagePaint((java.awt.Paint)var13);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var27 = var26.getTransparency();
    java.awt.Color var28 = var26.brighter();
    var9.setLabelPaint((java.awt.Paint)var28);
    boolean var30 = var3.equals((java.lang.Object)var28);
    int var31 = var28.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 3);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    double var10 = var2.getYOffset();
    int var11 = var2.getPassCount();
    int var12 = var2.getPassCount();
    var2.setRenderAsPercentages(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    java.awt.Font var5 = null;
    var2.setSeriesItemLabelFont(10, var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    var2.setBaseOutlinePaint((java.awt.Paint)var9);
    java.awt.Paint var12 = var2.lookupSeriesFillPaint(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var2.setVisible(true);
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var6.setVisible(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.axis.ValueAxis var12 = var10.getDomainAxis(10);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var16 = var15.getLowerMargin();
//     java.lang.Object var17 = var15.clone();
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var19.setVisible(true);
//     java.lang.Object var22 = var19.clone();
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var19, var23);
//     org.jfree.data.Range var25 = var10.getDataRange((org.jfree.chart.axis.ValueAxis)var19);
//     
//     // Checks the contract:  equals-hashcode on var10 and var24
//     assertTrue("Contract failed: equals-hashcode on var10 and var24", var10.equals(var24) ? var10.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var10
//     assertTrue("Contract failed: equals-hashcode on var24 and var10", var24.equals(var10) ? var24.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-16579837));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var4 = var3.getTransparency();
    java.awt.Color var5 = var3.brighter();
    java.awt.Color var6 = var3.brighter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseCreateEntities(true, false);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
    var2.setSeriesItemLabelsVisible(0, false);
    boolean var21 = var2.isItemLabelVisible(0, 0);
    java.awt.Shape var24 = var2.getItemShape(100, 0);
    boolean var25 = var2.getRenderAsPercentages();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(1.0d, (-11.0d));
    java.lang.Object var3 = var2.clone();
    double var4 = var2.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-11.0d));

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
//     long var5 = var3.toTimelineValue(0L);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "ChartEntity: tooltip = ", "CONTRACT", "(true, 0)");

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 10.0f, (-1.0f));
    var1.setLabelBackgroundPaint((java.awt.Paint)var26);
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
    org.jfree.data.general.PieDataset var30 = null;
    var29.setDataset(var30);
    var29.setMaximumLabelWidth(100.0d);
    java.awt.Stroke var34 = var29.getSeparatorStroke();
    org.jfree.chart.labels.PieSectionLabelGenerator var35 = var29.getLegendLabelGenerator();
    var1.setLabelGenerator(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    org.jfree.chart.axis.SegmentedTimeline var17 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var20 = var17.containsDomainRange(0L, 1L);
    java.lang.Object var21 = var17.clone();
    java.lang.Comparable[] var23 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var26 = null;
    java.lang.Number[][] var27 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var23, var25, var26, var27);
    java.util.List var29 = var28.getRowKeys();
    var17.setExceptionSegments(var29);
    var9.setSubtitles(var29);
    org.jfree.chart.ChartRenderingInfo var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var37 = var9.createBufferedImage(100, (-16579837), 10.0d, 0.0d, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Paint[] var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape var9 = null;
    java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var10);
    java.awt.Stroke var12 = var11.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("ChartEntity: tooltip = ", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    double var4 = var2.getEndValue();
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var2.notifyListeners(var5);
    var2.setStartValue(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getValue((java.lang.Comparable)(byte)100, (java.lang.Comparable)' ');
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var2.setVisible(true);
//     var2.setLabelURL("hi!");
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var15.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var19 = var15.getSeriesURLGenerator(100);
//     var15.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     java.awt.Font var25 = var15.getItemLabelFont(0, 1);
//     var12.setLabelFont(var25);
//     org.jfree.chart.axis.MarkerAxisBand var27 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var2, 10.0d, 1.0d, 0.0d, 1.0d, var25);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var30.setBaseCreateEntities(true);
//     java.awt.Paint var34 = null;
//     var30.setSeriesItemLabelPaint(0, var34, true);
//     java.awt.Stroke var38 = null;
//     var30.setSeriesStroke(10, var38);
//     java.awt.Shape var40 = var30.getBaseShape();
//     java.awt.Paint var41 = var30.getBasePaint();
//     org.jfree.chart.text.TextMeasurer var43 = null;
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]", var25, var41, 100.0f, var43);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    double var12 = var11.getDomainCrosshairValue();
    boolean var13 = var11.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    var4.setURLText("hi!");
    var4.setToolTipText("hi!");
    java.awt.Shape var9 = var4.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("CONTRACT", "hi!", "ChartEntity: tooltip = ", var3, "", "", "hi!");
    var7.setCopyright("ChartEntity: tooltip = ");
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("CONTRACT", "hi!", "ChartEntity: tooltip = ", var13, "", "", "hi!");
    var17.setCopyright("ChartEntity: tooltip = ");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var17);
    java.awt.Image var21 = var7.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    float var6 = var2.getAlpha();
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot(var7);
    org.jfree.chart.util.RectangleInsets var9 = var8.getInsets();
    var2.setLabelOffset(var9);
    org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 10.0d, (-1.0d));
    var2.setLabelOffset(var15);
    org.jfree.chart.util.RectangleAnchor var17 = var2.getLabelAnchor();
    boolean var19 = var17.equals((java.lang.Object)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var4 = null;
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var16 = var15.getLabel();
    var15.setEndValue(10.0d);
    java.awt.Stroke var19 = var15.getStroke();
    org.jfree.chart.plot.CategoryMarker var20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var12, var19);
    var8.setNoDataMessagePaint((java.awt.Paint)var12);
    java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var26 = var25.getTransparency();
    java.awt.Color var27 = var25.brighter();
    var8.setLabelPaint((java.awt.Paint)var27);
    java.awt.Paint var29 = var8.getLabelPaint();
    var8.setBackgroundImageAlpha(1.0f);
    var6.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
    var8.setExplodePercent((java.lang.Comparable)1, 17.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    java.awt.Font var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLabelFont(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("ChartEntity: tooltip = ", "CONTRACT", "", var3, "hi!", "hi!", "");
    var7.setLicenceText("");
    java.lang.String var10 = var7.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "ChartEntity: tooltip = "+ "'", var10.equals("ChartEntity: tooltip = "));

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    java.awt.Stroke var15 = var2.getBaseOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    java.awt.Paint var12 = var2.getItemLabelPaint(10, 0);
    java.awt.Stroke var13 = var2.getBaseOutlineStroke();
    var2.setBaseSeriesVisibleInLegend(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisible(0, (java.lang.Boolean)true);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    org.jfree.chart.labels.ItemLabelPosition var10 = var2.getBaseNegativeItemLabelPosition();
    boolean var11 = var2.getAutoPopulateSeriesOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     org.jfree.data.general.SeriesChangeEvent var8 = null;
//     var6.seriesChanged(var8);
//     org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 0);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Paint var8 = var1.getLabelShadowPaint();
    org.jfree.data.general.DatasetGroup var9 = var1.getDatasetGroup();
    boolean var10 = var1.getIgnoreNullValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var1.setVisible(true);
    var1.setLabelURL("hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var1.setRange(var8, true, true);
    double var12 = var1.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    org.jfree.chart.plot.Plot var12 = var2.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Paint var8 = null;
    java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
    java.awt.Paint var10 = null;
    java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
    java.awt.Paint[] var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var11, var12, var14, var16, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var18);
    org.jfree.chart.event.ChartChangeEventType var21 = null;
    var20.setType(var21);
    var7.notifyListeners(var20);
    var4.rendererChanged(var20);
    java.lang.String var25 = var4.getPlotType();
    boolean var26 = var4.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "Polar Plot"+ "'", var25.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var1.setVisible(true);
    var1.setLabelURL("hi!");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var1.setRange(var8, true, true);
    var1.setRangeAboutValue((-1.0d), 17.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
//     java.util.Date var5 = var3.getDate(100L);
//     org.jfree.chart.axis.SegmentedTimeline var9 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
//     java.util.Date var11 = var9.getDate(100L);
//     org.jfree.chart.axis.SegmentedTimeline var15 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
//     java.util.Date var17 = var15.getDate(100L);
//     long var18 = var9.getTime(var17);
//     var3.addBaseTimelineException(var17);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    org.jfree.data.general.PieDataset var23 = null;
    var1.setDataset(var23);
    double var25 = var1.getStartAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 90.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    java.lang.Number var5 = null;
    java.lang.Comparable[] var9 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var11 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var12 = null;
    java.lang.Number[][] var13 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var14 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var9, var11, var12, var13);
    java.util.List var15 = var14.getRowKeys();
    org.jfree.data.statistics.BoxAndWhiskerItem var16 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)100.0d, (java.lang.Number)0.0d, (java.lang.Number)0.0d, (java.lang.Number)(-1L), (java.lang.Number)100.0d, var5, (java.lang.Number)(byte)100, (java.lang.Number)1.0d, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(10.0d);
    double var2 = var1.getMax();
    var1.cursorRight(10.0d);
    var1.cursorRight((-11.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    java.awt.Shape var12 = var2.getLeftArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    int var14 = var9.getSubtitleCount();
    boolean var15 = var9.isBorderVisible();
    org.jfree.chart.title.LegendTitle var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.addLegend(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    boolean var12 = var6.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("CONTRACT", "hi!", "ChartEntity: tooltip = ", var3, "", "", "hi!");
    java.util.List var8 = var7.getContributors();
    java.awt.Image var9 = null;
    var7.setLogo(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    boolean var17 = var2.getItemVisible(10, 10);
    org.jfree.chart.labels.ItemLabelPosition var19 = var2.getSeriesNegativeItemLabelPosition(10);
    java.awt.Stroke var20 = var2.getBaseOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var6, false);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     int var9 = var6.getSeriesIndex((java.lang.Comparable)"hi!");
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape var9 = null;
//     java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var10);
//     java.awt.Paint var12 = null;
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     java.awt.Paint var14 = null;
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Paint[] var16 = null;
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var21 = null;
//     java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
//     org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var15, var16, var18, var20, var22);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     org.jfree.chart.renderer.PolarItemRenderer var27 = null;
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, var27);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     java.awt.Paint var32 = null;
//     java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
//     java.awt.Paint var34 = null;
//     java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
//     java.awt.Paint[] var36 = null;
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Shape var41 = null;
//     java.awt.Shape[] var42 = new java.awt.Shape[] { var41};
//     org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var33, var35, var36, var38, var40, var42);
//     org.jfree.chart.event.RendererChangeEvent var44 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var42);
//     org.jfree.chart.event.ChartChangeEventType var45 = null;
//     var44.setType(var45);
//     var31.notifyListeners(var44);
//     var28.rendererChanged(var44);
//     var28.zoom(100.0d);
//     java.awt.Stroke var51 = var28.getAngleGridlineStroke();
//     java.awt.Stroke[] var52 = new java.awt.Stroke[] { var51};
//     org.jfree.chart.plot.IntervalMarker var55 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var56 = var55.getLabelOffsetType();
//     java.awt.Paint var57 = var55.getPaint();
//     java.awt.Stroke var58 = var55.getOutlineStroke();
//     java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
//     java.awt.Paint var60 = null;
//     java.awt.Paint[] var61 = new java.awt.Paint[] { var60};
//     java.awt.Paint var62 = null;
//     java.awt.Paint[] var63 = new java.awt.Paint[] { var62};
//     java.awt.Paint[] var64 = null;
//     java.awt.Stroke var65 = null;
//     java.awt.Stroke[] var66 = new java.awt.Stroke[] { var65};
//     java.awt.Stroke var67 = null;
//     java.awt.Stroke[] var68 = new java.awt.Stroke[] { var67};
//     java.awt.Shape var69 = null;
//     java.awt.Shape[] var70 = new java.awt.Shape[] { var69};
//     org.jfree.chart.plot.DefaultDrawingSupplier var71 = new org.jfree.chart.plot.DefaultDrawingSupplier(var61, var63, var64, var66, var68, var70);
//     org.jfree.chart.plot.DefaultDrawingSupplier var72 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var15, var52, var59, var70);
//     
//     // Checks the contract:  equals-hashcode on var11 and var23
//     assertTrue("Contract failed: equals-hashcode on var11 and var23", var11.equals(var23) ? var11.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var43
//     assertTrue("Contract failed: equals-hashcode on var11 and var43", var11.equals(var43) ? var11.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var71
//     assertTrue("Contract failed: equals-hashcode on var11 and var71", var11.equals(var71) ? var11.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var11
//     assertTrue("Contract failed: equals-hashcode on var23 and var11", var23.equals(var11) ? var23.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var43
//     assertTrue("Contract failed: equals-hashcode on var23 and var43", var23.equals(var43) ? var23.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var71
//     assertTrue("Contract failed: equals-hashcode on var23 and var71", var23.equals(var71) ? var23.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var11
//     assertTrue("Contract failed: equals-hashcode on var43 and var11", var43.equals(var11) ? var43.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var23
//     assertTrue("Contract failed: equals-hashcode on var43 and var23", var43.equals(var23) ? var43.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var71
//     assertTrue("Contract failed: equals-hashcode on var43 and var71", var43.equals(var71) ? var43.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var11
//     assertTrue("Contract failed: equals-hashcode on var71 and var11", var71.equals(var11) ? var71.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var23
//     assertTrue("Contract failed: equals-hashcode on var71 and var23", var71.equals(var23) ? var71.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var43
//     assertTrue("Contract failed: equals-hashcode on var71 and var43", var71.equals(var43) ? var71.hashCode() == var43.hashCode() : true);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape var9 = null;
//     java.awt.Shape[] var10 = new java.awt.Shape[] { var9};
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var10);
//     java.awt.Paint[] var12 = null;
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var22 = var21.getLabel();
//     var21.setEndValue(10.0d);
//     java.awt.Stroke var25 = var21.getStroke();
//     org.jfree.chart.plot.CategoryMarker var26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var18, var25);
//     var14.setNoDataMessagePaint((java.awt.Paint)var18);
//     java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var32 = var31.getTransparency();
//     java.awt.Color var33 = var31.brighter();
//     var14.setLabelPaint((java.awt.Paint)var33);
//     java.awt.Paint var35 = var14.getLabelPaint();
//     var14.setBackgroundImageAlpha(1.0f);
//     java.awt.Color var41 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var42 = var41.getTransparency();
//     java.awt.Color var43 = var41.brighter();
//     var14.setLabelBackgroundPaint((java.awt.Paint)var43);
//     java.awt.Paint[] var45 = new java.awt.Paint[] { var43};
//     java.awt.Paint var46 = null;
//     java.awt.Paint[] var47 = new java.awt.Paint[] { var46};
//     java.awt.Paint var48 = null;
//     java.awt.Paint[] var49 = new java.awt.Paint[] { var48};
//     java.awt.Paint[] var50 = null;
//     java.awt.Stroke var51 = null;
//     java.awt.Stroke[] var52 = new java.awt.Stroke[] { var51};
//     java.awt.Stroke var53 = null;
//     java.awt.Stroke[] var54 = new java.awt.Stroke[] { var53};
//     java.awt.Shape var55 = null;
//     java.awt.Shape[] var56 = new java.awt.Shape[] { var55};
//     org.jfree.chart.plot.DefaultDrawingSupplier var57 = new org.jfree.chart.plot.DefaultDrawingSupplier(var47, var49, var50, var52, var54, var56);
//     java.awt.Paint var58 = null;
//     java.awt.Paint[] var59 = new java.awt.Paint[] { var58};
//     java.awt.Paint var60 = null;
//     java.awt.Paint[] var61 = new java.awt.Paint[] { var60};
//     java.awt.Paint[] var62 = null;
//     java.awt.Stroke var63 = null;
//     java.awt.Stroke[] var64 = new java.awt.Stroke[] { var63};
//     java.awt.Stroke var65 = null;
//     java.awt.Stroke[] var66 = new java.awt.Stroke[] { var65};
//     java.awt.Shape var67 = null;
//     java.awt.Shape[] var68 = new java.awt.Shape[] { var67};
//     org.jfree.chart.plot.DefaultDrawingSupplier var69 = new org.jfree.chart.plot.DefaultDrawingSupplier(var59, var61, var62, var64, var66, var68);
//     java.awt.Shape var71 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     java.awt.Shape[] var72 = new java.awt.Shape[] { var71};
//     org.jfree.chart.plot.DefaultDrawingSupplier var73 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var12, var45, var52, var66, var72);
//     
//     // Checks the contract:  equals-hashcode on var11 and var57
//     assertTrue("Contract failed: equals-hashcode on var11 and var57", var11.equals(var57) ? var11.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var69
//     assertTrue("Contract failed: equals-hashcode on var11 and var69", var11.equals(var69) ? var11.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var11
//     assertTrue("Contract failed: equals-hashcode on var57 and var11", var57.equals(var11) ? var57.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var69
//     assertTrue("Contract failed: equals-hashcode on var57 and var69", var57.equals(var69) ? var57.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var11
//     assertTrue("Contract failed: equals-hashcode on var69 and var11", var69.equals(var11) ? var69.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var57
//     assertTrue("Contract failed: equals-hashcode on var69 and var57", var69.equals(var57) ? var69.hashCode() == var57.hashCode() : true);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var18 = var17.getLabel();
//     var17.setEndValue(10.0d);
//     java.awt.Stroke var21 = var17.getStroke();
//     org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var14, var21);
//     var10.setNoDataMessagePaint((java.awt.Paint)var14);
//     boolean var24 = var2.equals((java.lang.Object)var10);
//     var10.setMaximumLabelWidth(0.0d);
//     double var27 = var10.getMaximumLabelWidth();
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var31.setBaseCreateEntities(true);
//     java.awt.Paint var35 = null;
//     var31.setSeriesItemLabelPaint(0, var35, true);
//     java.awt.Shape var38 = var31.getBaseShape();
//     java.awt.Paint var41 = var31.getItemLabelPaint(10, 0);
//     java.awt.Stroke var42 = var31.getBaseOutlineStroke();
//     var28.setBorderStroke(var42);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var2.", var31.equals(var2) == var2.equals(var31));
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseCreateEntities(true, false);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
    var2.setSeriesItemLabelsVisible(0, false);
    boolean var21 = var2.isItemLabelVisible(0, 0);
    java.awt.Shape var24 = var2.getItemShape(100, 0);
    java.lang.Boolean var26 = var2.getSeriesVisibleInLegend(0);
    boolean var27 = var2.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + true+ "'", var26.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     java.awt.Paint var6 = null;
//     var2.setSeriesItemLabelPaint(0, var6, true);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(10, var10);
//     java.awt.Shape var12 = var2.getBaseShape();
//     org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var16 = var15.getLabelOffsetType();
//     java.awt.Paint var17 = var15.getPaint();
//     var2.setWallPaint(var17);
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, (-1.0f));
//     org.jfree.chart.util.RectangleInsets var27 = new org.jfree.chart.util.RectangleInsets(10.0d, 10.0d, (-1.0d), 1.0d);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var34.setBaseCreateEntities(true);
//     java.awt.Paint var38 = null;
//     var34.setSeriesItemLabelPaint(0, var38, true);
//     java.awt.Shape var41 = var34.getBaseShape();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var44.setBaseCreateEntities(true);
//     java.awt.Paint var48 = null;
//     var44.setSeriesItemLabelPaint(0, var48, true);
//     java.awt.Stroke var52 = null;
//     var44.setSeriesStroke(10, var52);
//     java.awt.Shape var54 = var44.getBaseShape();
//     org.jfree.chart.plot.IntervalMarker var57 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var58 = var57.getLabelOffsetType();
//     java.awt.Paint var59 = var57.getPaint();
//     var44.setWallPaint(var59);
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var41, var59);
//     java.awt.Paint var62 = var61.getOutlinePaint();
//     org.jfree.chart.block.BlockBorder var63 = new org.jfree.chart.block.BlockBorder(var27, var62);
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.RingPlot var65 = new org.jfree.chart.plot.RingPlot(var64);
//     org.jfree.data.general.PieDataset var66 = null;
//     var65.setDataset(var66);
//     var65.setMaximumLabelWidth(100.0d);
//     org.jfree.chart.urls.PieURLGenerator var70 = null;
//     var65.setURLGenerator(var70);
//     java.awt.Paint var72 = var65.getLabelShadowPaint();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var73 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var17, (java.awt.Paint)var22, var62, var72);
//     
//     // Checks the contract:  equals-hashcode on var15 and var57
//     assertTrue("Contract failed: equals-hashcode on var15 and var57", var15.equals(var57) ? var15.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var15
//     assertTrue("Contract failed: equals-hashcode on var57 and var15", var57.equals(var15) ? var57.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.setDomainGridlinesVisible(true);
    var11.setDomainZeroBaselineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }


    org.jfree.chart.axis.SegmentedTimeline var4 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
    java.util.Date var6 = var4.getDate(100L);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-16579837), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-460), (-16579837), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    java.awt.Font var5 = null;
    var2.setSeriesItemLabelFont(10, var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    var2.setBaseOutlinePaint((java.awt.Paint)var9);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var14.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var18 = var14.getSeriesURLGenerator(100);
    var14.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var24 = var14.getItemLabelFont(0, 1);
    var2.setSeriesItemLabelFont(0, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    org.jfree.chart.axis.SegmentedTimeline var17 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var20 = var17.containsDomainRange(0L, 1L);
    java.lang.Object var21 = var17.clone();
    java.lang.Comparable[] var23 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var26 = null;
    java.lang.Number[][] var27 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var23, var25, var26, var27);
    java.util.List var29 = var28.getRowKeys();
    var17.setExceptionSegments(var29);
    var9.setSubtitles(var29);
    java.awt.Image var32 = var9.getBackgroundImage();
    org.jfree.chart.ChartRenderingInfo var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var37 = var9.createBufferedImage((-1), (-16579837), 0, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
//     var2.setBaseCreateEntities(true, false);
//     var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
//     var2.setSeriesItemLabelsVisible(0, false);
//     var2.setBaseCreateEntities(false);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var2.drawBackground(var21, var22, var23);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    float var6 = var2.getAlpha();
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot(var7);
    org.jfree.chart.util.RectangleInsets var9 = var8.getInsets();
    var2.setLabelOffset(var9);
    double var12 = var9.calculateBottomOutset((-11.0d));
    double var14 = var9.extendWidth(1.0d);
    org.jfree.chart.util.UnitType var15 = var9.getUnitType();
    org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(var15, 10.0d, 1.0d, (-11.0d), 10.0d);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var23.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var27.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var27, var30);
    java.awt.Color var35 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var36 = var35.getTransparency();
    java.awt.Color var40 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var41 = var40.getTransparency();
    boolean var42 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var35, (java.awt.Paint)var40);
    java.awt.Color var43 = var35.brighter();
    var31.setDomainGridlinePaint((java.awt.Paint)var43);
    var31.setRangeCrosshairLockedOnData(false);
    boolean var47 = var15.equals((java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 17.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    org.jfree.chart.axis.SegmentedTimeline var17 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var20 = var17.containsDomainRange(0L, 1L);
    java.lang.Object var21 = var17.clone();
    java.lang.Comparable[] var23 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var26 = null;
    java.lang.Number[][] var27 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var23, var25, var26, var27);
    java.util.List var29 = var28.getRowKeys();
    var17.setExceptionSegments(var29);
    var9.setSubtitles(var29);
    java.awt.Image var32 = var9.getBackgroundImage();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var33 = var9.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Paint var9 = var1.getSectionPaint((java.lang.Comparable)false);
    boolean var10 = var1.getIgnoreZeroValues();
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var15 = var14.getTransparency();
    java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var20 = var19.getTransparency();
    boolean var21 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var14, (java.awt.Paint)var19);
    java.awt.Color var22 = var14.brighter();
    var1.setLabelShadowPaint((java.awt.Paint)var22);
    var1.setSectionOutlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var2.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var2.getBaseURLGenerator();
//     int var6 = var2.getPassCount();
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = var2.getSeriesToolTipGenerator(1);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var13 = var12.getLowerMargin();
//     java.lang.Object var14 = var12.clone();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var16.setVisible(true);
//     var16.setLabelURL("hi!");
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var29.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var33 = var29.getSeriesURLGenerator(100);
//     var29.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     java.awt.Font var39 = var29.getItemLabelFont(0, 1);
//     var26.setLabelFont(var39);
//     org.jfree.chart.axis.MarkerAxisBand var41 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var16, 10.0d, 1.0d, 0.0d, 1.0d, var39);
//     org.jfree.chart.plot.IntervalMarker var44 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var45 = var44.getLabelOffsetType();
//     java.awt.Paint var46 = var44.getPaint();
//     java.awt.Stroke var47 = var44.getOutlineStroke();
//     float var48 = var44.getAlpha();
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.plot.MultiplePiePlot var50 = new org.jfree.chart.plot.MultiplePiePlot(var49);
//     org.jfree.chart.util.RectangleInsets var51 = var50.getInsets();
//     var44.setLabelOffset(var51);
//     org.jfree.chart.util.RectangleInsets var57 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 10.0d, (-1.0d));
//     var44.setLabelOffset(var57);
//     var41.addMarker(var44);
//     var44.setLabel("");
//     java.awt.geom.Rectangle2D var62 = null;
//     var2.drawRangeMarker(var9, var10, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.plot.Marker)var44, var62);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var29.", var2.equals(var29) == var29.equals(var2));
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(0L, 1, 0);
    org.jfree.chart.axis.SegmentedTimeline var4 = var3.getBaseTimeline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var9 = var8.getTransparency();
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var14 = var13.getTransparency();
    boolean var15 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var8, (java.awt.Paint)var13);
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var8);
    org.jfree.chart.util.RectangleAnchor var17 = var16.getShapeAnchor();
    var16.setLineVisible(false);
    var16.setShapeFilled(true);
    boolean var22 = var16.isShapeFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    var1.setForegroundAlpha(10.0f);
    boolean var24 = var1.getLabelLinksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
    java.util.Date var5 = var3.getDate(100L);
    var3.addException(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    boolean var17 = var2.getItemVisible(10, 10);
    org.jfree.chart.labels.ItemLabelPosition var19 = var2.getSeriesNegativeItemLabelPosition(10);
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
    org.jfree.data.general.PieDataset var24 = null;
    var23.setDataset(var24);
    java.awt.Paint var26 = var23.getBaseSectionPaint();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var29.setBaseCreateEntities(true);
    java.awt.Paint var33 = null;
    var29.setSeriesItemLabelPaint(0, var33, true);
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.plot.Marker var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var29.drawRangeMarker(var36, var37, var38, var39, var40);
    boolean var44 = var29.getItemVisible(10, 10);
    var29.setBase(100.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var51 = var50.getBaseNegativeItemLabelPosition();
    var29.setSeriesNegativeItemLabelPosition(10, var51);
    java.lang.Object var53 = var29.clone();
    org.jfree.chart.plot.IntervalMarker var56 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var57 = var56.getLabelOffsetType();
    java.awt.Paint var58 = var56.getPaint();
    java.awt.Stroke var59 = var56.getOutlineStroke();
    var29.setBaseOutlineStroke(var59, false);
    org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(0.0d, var26, var59);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesOutlineStroke((-460), var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    java.lang.Object var6 = var1.clone();
    var1.removeColumn((java.lang.Comparable)1.0d);
    java.util.List var9 = var1.getRowKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    var1.setIgnoreZeroValues(true);
    java.awt.Paint var8 = var1.getShadowPaint();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var18 = var17.getLabel();
    var17.setEndValue(10.0d);
    java.awt.Stroke var21 = var17.getStroke();
    org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var14, var21);
    var10.setNoDataMessagePaint((java.awt.Paint)var14);
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var28 = var27.getTransparency();
    java.awt.Color var29 = var27.brighter();
    var10.setLabelPaint((java.awt.Paint)var29);
    java.awt.Paint var31 = var10.getLabelPaint();
    var10.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.util.Rotation var34 = var10.getDirection();
    var1.setDirection(var34);
    double var36 = var1.getOuterSeparatorExtension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    org.jfree.chart.text.TextAnchor var4 = var2.getLabelTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var16 = var15.getLabelOffsetType();
    java.awt.Paint var17 = var15.getPaint();
    java.awt.Stroke var18 = var15.getOutlineStroke();
    float var19 = var15.getAlpha();
    org.jfree.chart.util.Layer var20 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var15, var20);
    int var22 = var11.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 15);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var4 = null;
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    var6.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
    java.lang.Comparable[] var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setCategoryKeys(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    double var12 = var11.getDomainCrosshairValue();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var15.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var18 = var15.getBaseURLGenerator();
    java.awt.Stroke var19 = var15.getBaseStroke();
    var11.setDomainCrosshairStroke(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var18 = var17.getLabel();
    var17.setEndValue(10.0d);
    java.awt.Stroke var21 = var17.getStroke();
    org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var14, var21);
    var10.setNoDataMessagePaint((java.awt.Paint)var14);
    boolean var24 = var2.equals((java.lang.Object)var10);
    var10.setMaximumLabelWidth(0.0d);
    double var27 = var10.getMaximumLabelWidth();
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.util.RectangleInsets var29 = var28.getPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var30 = var28.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    boolean var17 = var2.getItemVisible(10, 10);
    var2.setBase(100.0d);
    boolean var20 = var2.getBaseSeriesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    double var3 = var2.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4.0d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var14 = var13.getTransparency();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    boolean var20 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var13, (java.awt.Paint)var18);
    java.awt.Color var21 = var13.brighter();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var25.setBaseCreateEntities(true);
    java.awt.Paint var29 = null;
    var25.setSeriesItemLabelPaint(0, var29, true);
    java.awt.Shape var32 = var25.getBaseShape();
    java.awt.Paint var35 = var25.getItemLabelPaint(10, 0);
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.RingPlot var38 = new org.jfree.chart.plot.RingPlot(var37);
    org.jfree.data.general.PieDataset var39 = null;
    var38.setDataset(var39);
    java.awt.Paint var41 = var38.getBaseSectionPaint();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var44.setBaseCreateEntities(true);
    java.awt.Paint var48 = null;
    var44.setSeriesItemLabelPaint(0, var48, true);
    java.awt.Graphics2D var51 = null;
    org.jfree.chart.plot.CategoryPlot var52 = null;
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.plot.Marker var54 = null;
    java.awt.geom.Rectangle2D var55 = null;
    var44.drawRangeMarker(var51, var52, var53, var54, var55);
    boolean var59 = var44.getItemVisible(10, 10);
    var44.setBase(100.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var65 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var66 = var65.getBaseNegativeItemLabelPosition();
    var44.setSeriesNegativeItemLabelPosition(10, var66);
    java.lang.Object var68 = var44.clone();
    org.jfree.chart.plot.IntervalMarker var71 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var72 = var71.getLabelOffsetType();
    java.awt.Paint var73 = var71.getPaint();
    java.awt.Stroke var74 = var71.getOutlineStroke();
    var44.setBaseOutlineStroke(var74, false);
    org.jfree.chart.plot.ValueMarker var77 = new org.jfree.chart.plot.ValueMarker(0.0d, var41, var74);
    java.awt.Shape var81 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    java.awt.Shape var82 = org.jfree.chart.util.ShapeUtilities.clone(var81);
    org.jfree.chart.entity.ChartEntity var84 = new org.jfree.chart.entity.ChartEntity(var82, "");
    org.jfree.data.general.PieDataset var85 = null;
    org.jfree.chart.plot.RingPlot var86 = new org.jfree.chart.plot.RingPlot(var85);
    org.jfree.data.general.PieDataset var87 = null;
    var86.setDataset(var87);
    var86.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var91 = null;
    var86.setURLGenerator(var91);
    boolean var93 = var86.getIgnoreZeroValues();
    java.awt.Stroke var94 = var86.getOutlineStroke();
    java.awt.Paint var95 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var96 = new org.jfree.chart.LegendItem(var0, "(true, 0)", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]", "", true, var7, false, (java.awt.Paint)var13, true, var35, var74, false, var82, var94, var95);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    java.awt.Font var5 = null;
    var2.setSeriesItemLabelFont(10, var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    var2.setBaseOutlinePaint((java.awt.Paint)var9);
    org.jfree.chart.LegendItem var13 = var2.getLegendItem(10, 1);
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var2.setBaseURLGenerator(var14, false);
    java.awt.Stroke var18 = var2.getSeriesStroke(1);
    boolean var19 = var2.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var16 = var15.getLabelOffsetType();
    java.awt.Paint var17 = var15.getPaint();
    java.awt.Stroke var18 = var15.getOutlineStroke();
    float var19 = var15.getAlpha();
    org.jfree.chart.util.Layer var20 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var15, var20);
    org.jfree.chart.axis.AxisLocation var23 = null;
    var11.setRangeAxisLocation(10, var23, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.8f);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    double var10 = var2.getYOffset();
    int var11 = var2.getPassCount();
    org.jfree.chart.labels.ItemLabelPosition var12 = var2.getNegativeItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var1.setVisible(true);
    var1.setLabelURL("hi!");
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var14.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var18 = var14.getSeriesURLGenerator(100);
    var14.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var24 = var14.getItemLabelFont(0, 1);
    var11.setLabelFont(var24);
    org.jfree.chart.axis.MarkerAxisBand var26 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var1, 10.0d, 1.0d, 0.0d, 1.0d, var24);
    var1.setLabelToolTip("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var4 = null;
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
    java.util.List var7 = var6.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var6.getEndValue(0, (-16579837));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    int var14 = var9.getSubtitleCount();
    boolean var15 = var9.isBorderVisible();
    var9.setBackgroundImageAlignment(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    var33.setSeriesKey((java.lang.Comparable)100L);
    java.awt.Paint var37 = var33.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
    java.util.Date var5 = var3.getDate(100L);
    long var6 = var3.getSegmentsGroupSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 990L);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseCreateEntities(true, false);
    org.jfree.chart.labels.ItemLabelPosition var14 = var2.getPositiveItemLabelPosition(0, 0);
    java.awt.Paint var16 = var2.getSeriesOutlinePaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var2 = var1.getLowerMargin();
    java.lang.Object var3 = var1.clone();
    java.awt.Font var4 = var1.getLabelFont();
    var1.setLabelToolTip("ChartEntity: tooltip = ");
    double var7 = var1.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.lang.Comparable[] var8 = new java.lang.Comparable[] { (byte)100};
//     java.lang.Number[] var9 = null;
//     java.lang.Number[][] var10 = new java.lang.Number[][] { var9};
//     java.lang.Number[] var11 = null;
//     java.lang.Number[][] var12 = new java.lang.Number[][] { var11};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var8, var10, var12);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ChartEntity: tooltip = ");

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    var11.setRenderer(var12);
    java.awt.Paint var14 = var11.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    var1.setBackgroundImageAlpha(1.0f);
    double var25 = var1.getLabelLinkMargin();
    var1.setSeparatorsVisible(false);
    double var28 = var1.getMaximumLabelWidth();
    java.awt.Stroke var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelLinkStroke(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)true, (java.lang.Number)0);
    java.lang.Object var3 = var2.clone();
    java.lang.Number var4 = var2.getValue();
    java.lang.String var5 = var2.toString();
    java.lang.Number var6 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "(true, 0)"+ "'", var5.equals("(true, 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0+ "'", var6.equals(0));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseCreateEntities(true, false);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
    var2.setSeriesItemLabelsVisible(0, false);
    boolean var21 = var2.isItemLabelVisible(0, 0);
    java.awt.Shape var24 = var2.getItemShape(100, 0);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(0L, 1, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var3.containsDomainRange(990L, 0L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    org.jfree.chart.axis.SegmentedTimeline var17 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var20 = var17.containsDomainRange(0L, 1L);
    java.lang.Object var21 = var17.clone();
    java.lang.Comparable[] var23 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var26 = null;
    java.lang.Number[][] var27 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var23, var25, var26, var27);
    java.util.List var29 = var28.getRowKeys();
    var17.setExceptionSegments(var29);
    var9.setSubtitles(var29);
    java.awt.Paint var32 = var9.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Paint var8 = null;
    java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
    java.awt.Paint var10 = null;
    java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
    java.awt.Paint[] var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var11, var12, var14, var16, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var18);
    org.jfree.chart.event.ChartChangeEventType var21 = null;
    var20.setType(var21);
    var7.notifyListeners(var20);
    var4.rendererChanged(var20);
    java.lang.String var25 = var4.getPlotType();
    boolean var27 = var4.equals((java.lang.Object)100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "Polar Plot"+ "'", var25.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "hi!");
    java.lang.String var5 = var4.getLicenceName();
    java.lang.String var6 = var4.getLicenceName();
    java.lang.String var7 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 10.0d, (-1.0d), 1.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var11.setBaseCreateEntities(true);
    java.awt.Paint var15 = null;
    var11.setSeriesItemLabelPaint(0, var15, true);
    java.awt.Shape var18 = var11.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var21.setBaseCreateEntities(true);
    java.awt.Paint var25 = null;
    var21.setSeriesItemLabelPaint(0, var25, true);
    java.awt.Stroke var29 = null;
    var21.setSeriesStroke(10, var29);
    java.awt.Shape var31 = var21.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var35 = var34.getLabelOffsetType();
    java.awt.Paint var36 = var34.getPaint();
    var21.setWallPaint(var36);
    org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var18, var36);
    java.awt.Paint var39 = var38.getOutlinePaint();
    org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder(var4, var39);
    double var41 = var4.getTop();
    double var43 = var4.calculateBottomOutset((-1.0d));
    double var45 = var4.calculateTopInset((-1.0d));
    java.awt.geom.Rectangle2D var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var47 = var4.createInsetRectangle(var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10.0d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    org.jfree.chart.plot.CategoryPlot var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setPlot(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    var1.setIgnoreZeroValues(true);
    java.awt.Paint var8 = var1.getShadowPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var1.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    org.jfree.data.general.PieDataset var12 = null;
    var11.setDataset(var12);
    var11.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var16 = null;
    var11.setURLGenerator(var16);
    java.awt.Paint var18 = var11.getLabelShadowPaint();
    org.jfree.data.general.DatasetGroup var19 = var11.getDatasetGroup();
    var1.setParent((org.jfree.chart.plot.Plot)var11);
    var1.setPieIndex(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.configureRangeAxes();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = var11.getRendererForDataset(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("(true, 0)", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    double var10 = var2.getYOffset();
    int var11 = var2.getPassCount();
    java.awt.Paint var13 = var2.getSeriesFillPaint((-1));
    org.jfree.chart.plot.CategoryPlot var14 = var2.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.setDomainGridlinesVisible(true);
    boolean var17 = var11.isDomainZoomable();
    org.jfree.data.xy.XYDataset var18 = null;
    int var19 = var11.indexOf(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    java.awt.Shape var12 = var2.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var16 = var15.getLabelOffsetType();
    java.awt.Paint var17 = var15.getPaint();
    var2.setWallPaint(var17);
    org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var2.getItemLabelGenerator(0, (-16579837));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    java.awt.Shape var12 = var2.getBaseShape();
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    var2.setSeriesURLGenerator(1, var14);
    org.jfree.chart.labels.ItemLabelPosition var18 = var2.getPositiveItemLabelPosition(10, 0);
    boolean var21 = var2.isItemLabelVisible(100, 1);
    int var22 = var2.getRowCount();
    java.lang.Boolean var24 = var2.getSeriesItemLabelsVisible((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(10L, 100L);
    org.jfree.data.DefaultKeyedValues2D var4 = new org.jfree.data.DefaultKeyedValues2D(true);
    java.util.List var5 = var4.getColumnKeys();
    boolean var6 = var2.equals((java.lang.Object)var4);
    java.util.Date var7 = var2.getStart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.axis.NumberTickUnit var3 = var2.getTickUnit();
    var2.setPositiveArrowVisible(true);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    java.awt.Font var11 = null;
    var8.setSeriesItemLabelFont(10, var11);
    java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
    var8.setBaseOutlinePaint((java.awt.Paint)var15);
    org.jfree.chart.JFreeChart var17 = null;
    org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var17);
    java.awt.Paint var20 = var8.lookupSeriesOutlinePaint(1);
    var2.setLabelPaint(var20);
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var22);
    java.lang.String var24 = var23.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "Polar Plot"+ "'", var24.equals("Polar Plot"));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Paint var8 = null;
    java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
    java.awt.Paint var10 = null;
    java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
    java.awt.Paint[] var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var11, var12, var14, var16, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var18);
    org.jfree.chart.event.ChartChangeEventType var21 = null;
    var20.setType(var21);
    var7.notifyListeners(var20);
    var4.rendererChanged(var20);
    boolean var25 = var4.isAngleGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var7 = var6.getLabel();
    var6.setEndValue(10.0d);
    java.awt.Stroke var10 = var6.getStroke();
    org.jfree.chart.plot.CategoryMarker var11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var3, var10);
    java.lang.Comparable var12 = var11.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (byte)10+ "'", var12.equals((byte)10));

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var6 = var3.containsDomainRange(0L, 1L);
    java.lang.Object var7 = var3.clone();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var17 = var16.getLabel();
    var16.setEndValue(10.0d);
    java.awt.Stroke var20 = var16.getStroke();
    org.jfree.chart.plot.CategoryMarker var21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var13, var20);
    var9.setNoDataMessagePaint((java.awt.Paint)var13);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var27 = var26.getTransparency();
    java.awt.Color var28 = var26.brighter();
    var9.setLabelPaint((java.awt.Paint)var28);
    boolean var30 = var3.equals((java.lang.Object)var28);
    long var32 = var3.toTimelineValue(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0L);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)true, (java.lang.Number)0);
    java.lang.Object var3 = var2.clone();
    java.lang.Number var4 = var2.getValue();
    var2.setValue((java.lang.Number)(short)1);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var9.setBaseCreateEntities(true);
    var9.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var9.setBaseCreateEntities(true, false);
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
    var9.setSeriesItemLabelsVisible(0, false);
    boolean var28 = var9.isItemLabelVisible(0, 0);
    boolean var29 = var2.equals((java.lang.Object)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
//     boolean var6 = var3.containsDomainRange(0L, 1L);
//     java.lang.Object var7 = var3.clone();
//     java.lang.Comparable[] var9 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var11 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var12 = null;
//     java.lang.Number[][] var13 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var14 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var9, var11, var12, var13);
//     java.util.List var15 = var14.getRowKeys();
//     var3.setExceptionSegments(var15);
//     long var17 = var3.getSegmentSize();
//     java.util.List var18 = null;
//     var3.addExceptions(var18);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.axis.ValueAxis var12 = null;
    var10.setRangeAxis(10, var12);
    java.awt.Paint var14 = var10.getRangeTickBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var6 = var3.containsDomainRange(0L, 1L);
    java.lang.Object var7 = var3.clone();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var17 = var16.getLabel();
    var16.setEndValue(10.0d);
    java.awt.Stroke var20 = var16.getStroke();
    org.jfree.chart.plot.CategoryMarker var21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var13, var20);
    var9.setNoDataMessagePaint((java.awt.Paint)var13);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var27 = var26.getTransparency();
    java.awt.Color var28 = var26.brighter();
    var9.setLabelPaint((java.awt.Paint)var28);
    boolean var30 = var3.equals((java.lang.Object)var28);
    var3.addException(1L, 0L);
    java.awt.Font var35 = null;
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.plot.MultiplePiePlot var37 = new org.jfree.chart.plot.MultiplePiePlot(var36);
    org.jfree.data.category.CategoryDataset var38 = null;
    var37.setDataset(var38);
    org.jfree.chart.event.AxisChangeEvent var40 = null;
    var37.axisChanged(var40);
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("CONTRACT", var35, (org.jfree.chart.plot.Plot)var37, false);
    org.jfree.chart.event.ChartChangeEvent var44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1L, var43);
    var43.clearSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = ");
    double var2 = var1.getWidth();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var12 = var11.getLabel();
    var11.setEndValue(10.0d);
    java.awt.Stroke var15 = var11.getStroke();
    org.jfree.chart.plot.CategoryMarker var16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var8, var15);
    var4.setNoDataMessagePaint((java.awt.Paint)var8);
    java.awt.Color var21 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var22 = var21.getTransparency();
    java.awt.Color var23 = var21.brighter();
    var4.setLabelPaint((java.awt.Paint)var23);
    var1.setPaint((java.awt.Paint)var23);
    var1.setID("ChartEntity: tooltip = ");
    org.jfree.chart.util.RectangleInsets var28 = var1.getPadding();
    java.awt.geom.Rectangle2D var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var32 = var28.createOutsetRectangle(var29, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.axis.ValueAxis var12 = var10.getDomainAxis(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    var1.setBackgroundImageAlpha(1.0f);
    java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var29 = var28.getTransparency();
    java.awt.Color var30 = var28.brighter();
    var1.setLabelBackgroundPaint((java.awt.Paint)var30);
    var1.setStartAngle(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    var2.setSeriesVisibleInLegend(1, (java.lang.Boolean)false, false);
    java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.lang.String var20 = var19.toString();
    java.awt.Color var21 = var19.brighter();
    var2.setWallPaint((java.awt.Paint)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var20.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)100.0d, (java.lang.Number)1.0d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    var2.setEndValue(10.0d);
    java.awt.Stroke var6 = var2.getStroke();
    org.jfree.chart.util.GradientPaintTransformer var7 = var2.getGradientPaintTransformer();
    org.jfree.chart.util.RectangleInsets var8 = var2.getLabelOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    java.awt.Paint var12 = var2.getItemLabelPaint(10, 0);
    java.lang.Boolean var14 = var2.getSeriesVisible(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var4 = var3.getBaseNegativeItemLabelPosition();
    java.awt.Font var6 = null;
    var3.setSeriesItemLabelFont(10, var6);
    java.awt.Color var10 = java.awt.Color.getColor("hi!", (-1));
    var3.setBaseOutlinePaint((java.awt.Paint)var10);
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartChangeEvent var13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var12);
    java.awt.Paint var15 = var3.lookupSeriesOutlinePaint(1);
    org.jfree.chart.labels.ItemLabelPosition var16 = var3.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var17 = var16.getRotationAnchor();
    java.lang.String var18 = var17.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var19 = new org.jfree.chart.labels.ItemLabelPosition(var0, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "TextAnchor.CENTER"+ "'", var18.equals("TextAnchor.CENTER"));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    var1.setIgnoreZeroValues(true);
    java.awt.Paint var8 = var1.getShadowPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var1.getLegendLabelToolTipGenerator();
    var1.setCircular(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var8 = var7.getLabelOffsetType();
    java.awt.Paint var9 = var7.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem(var0, "CONTRACT", "CONTRACT", "", var4, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-11.0d), 100.0d);
    java.lang.Object var5 = null;
    boolean var6 = var4.equals(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
//     java.awt.Font var5 = null;
//     var2.setSeriesItemLabelFont(10, var5);
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
//     var2.setBaseOutlinePaint((java.awt.Paint)var9);
//     org.jfree.chart.LegendItem var13 = var2.getLegendItem(10, 1);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var22 = var21.getLowerMargin();
//     java.lang.Object var23 = var21.clone();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var25.setVisible(true);
//     java.lang.Object var28 = var25.clone();
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var25, var29);
//     var30.setRangeCrosshairVisible(true);
//     boolean var33 = var30.isRangeZoomable();
//     var30.configureRangeAxes();
//     org.jfree.data.xy.XYDataset var35 = null;
//     int var36 = var30.indexOf(var35);
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var30.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var39);
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var39.valueToJava2D(17.0d, var42, var43);
//     java.lang.Comparable[] var46 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var48 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var49 = null;
//     java.lang.Number[][] var50 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var51 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var46, var48, var49, var50);
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.RingPlot var53 = new org.jfree.chart.plot.RingPlot(var52);
//     java.awt.Color var57 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.plot.IntervalMarker var60 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var61 = var60.getLabel();
//     var60.setEndValue(10.0d);
//     java.awt.Stroke var64 = var60.getStroke();
//     org.jfree.chart.plot.CategoryMarker var65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var57, var64);
//     var53.setNoDataMessagePaint((java.awt.Paint)var57);
//     java.awt.Color var70 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var71 = var70.getTransparency();
//     java.awt.Color var72 = var70.brighter();
//     var53.setLabelPaint((java.awt.Paint)var72);
//     java.awt.Paint var74 = var53.getLabelPaint();
//     var53.setBackgroundImageAlpha(1.0f);
//     var51.addChangeListener((org.jfree.data.general.DatasetChangeListener)var53);
//     var2.drawItem(var14, var15, var16, var17, var18, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.data.category.CategoryDataset)var51, (-1), 100, (-1));
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.setDomainGridlinesVisible(true);
    var11.setRangeCrosshairVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    boolean var17 = var2.getItemVisible(10, 10);
    org.jfree.chart.labels.ItemLabelPosition var19 = var2.getSeriesNegativeItemLabelPosition(10);
    var2.setBaseItemLabelsVisible(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     var3.setDataset(var4);
//     org.jfree.chart.event.AxisChangeEvent var6 = null;
//     var3.axisChanged(var6);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
//     var9.setAntiAlias(false);
//     var9.setBackgroundImageAlignment(0);
//     org.jfree.chart.axis.SegmentedTimeline var17 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
//     boolean var20 = var17.containsDomainRange(0L, 1L);
//     java.lang.Object var21 = var17.clone();
//     java.lang.Comparable[] var23 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var25 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var26 = null;
//     java.lang.Number[][] var27 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var23, var25, var26, var27);
//     java.util.List var29 = var28.getRowKeys();
//     var17.setExceptionSegments(var29);
//     var9.setSubtitles(var29);
//     java.awt.Image var32 = var9.getBackgroundImage();
//     java.awt.RenderingHints var33 = null;
//     var9.setRenderingHints(var33);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     org.jfree.data.general.SeriesChangeEvent var8 = null;
//     var6.seriesChanged(var8);
//     org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 1);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, 17.0d, 0.0d, 0.0d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var18 = var17.getLabel();
    var17.setEndValue(10.0d);
    java.awt.Stroke var21 = var17.getStroke();
    org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var14, var21);
    var10.setNoDataMessagePaint((java.awt.Paint)var14);
    boolean var24 = var2.equals((java.lang.Object)var10);
    var10.setMaximumLabelWidth(0.0d);
    double var27 = var10.getMaximumLabelWidth();
    org.jfree.chart.plot.AbstractPieLabelDistributor var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setLabelDistributor(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Paint var8 = null;
    java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
    java.awt.Paint var10 = null;
    java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
    java.awt.Paint[] var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var11, var12, var14, var16, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var18);
    org.jfree.chart.event.ChartChangeEventType var21 = null;
    var20.setType(var21);
    var7.notifyListeners(var20);
    var4.rendererChanged(var20);
    var4.zoom(100.0d);
    java.awt.Stroke var27 = var4.getAngleGridlineStroke();
    org.jfree.chart.plot.IntervalMarker var30 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var31 = var30.getLabelOffsetType();
    java.awt.Paint var32 = var30.getPaint();
    java.awt.Stroke var33 = var30.getOutlineStroke();
    var4.setOutlineStroke(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-16579837));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.configureRangeAxes();
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var11.indexOf(var16);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var11.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var20);
    boolean var22 = var20.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("(true, 0)");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("CONTRACT", "hi!", "ChartEntity: tooltip = ", var3, "", "", "hi!");
    var7.setCopyright("ChartEntity: tooltip = ");
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("CONTRACT", "hi!", "ChartEntity: tooltip = ", var13, "", "", "hi!");
    var17.setCopyright("ChartEntity: tooltip = ");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var17);
    var17.addOptionalLibrary("ChartEntity: tooltip = ");

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    var1.setBackgroundImageAlpha(1.0f);
    double var25 = var1.getLabelLinkMargin();
    var1.setSeparatorsVisible(false);
    java.lang.String var28 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Pie Plot"+ "'", var28.equals("Pie Plot"));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    var2.setSeriesVisibleInLegend(1, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var2.setBaseItemLabelGenerator(var14, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)true, (java.lang.Number)0);
    var2.setValue((java.lang.Number)100.0f);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = ");
    double var2 = var1.getWidth();
    var1.setToolTipText("");
    org.jfree.chart.block.BlockFrame var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setFrame(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     int var7 = var6.getCategoryCount();
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 1);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.clearRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var2 = var1.getLowerMargin();
    var1.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    java.util.List var2 = var1.getColumnKeys();
    var1.removeColumn((java.lang.Comparable)17.0d);
    java.lang.Comparable var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addValue((java.lang.Number)(short)0, var6, (java.lang.Comparable)(-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     java.lang.String var4 = var3.toString();
//     java.awt.color.ColorSpace var5 = null;
//     float[] var6 = null;
//     float[] var7 = var3.getComponents(var5, var6);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var12.setLabel("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var10.setWeight((-460));
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    int var19 = var10.getIndexOf(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    double var12 = var2.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    org.jfree.chart.axis.SegmentedTimeline var17 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var20 = var17.containsDomainRange(0L, 1L);
    java.lang.Object var21 = var17.clone();
    java.lang.Comparable[] var23 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var26 = null;
    java.lang.Number[][] var27 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var23, var25, var26, var27);
    java.util.List var29 = var28.getRowKeys();
    var17.setExceptionSegments(var29);
    var9.setSubtitles(var29);
    java.awt.Image var32 = var9.getBackgroundImage();
    org.jfree.chart.event.ChartProgressListener var33 = null;
    var9.removeProgressListener(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var18 = var17.getLabel();
    var17.setEndValue(10.0d);
    java.awt.Stroke var21 = var17.getStroke();
    org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var14, var21);
    var10.setNoDataMessagePaint((java.awt.Paint)var14);
    boolean var24 = var2.equals((java.lang.Object)var10);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
    org.jfree.data.general.PieDataset var27 = null;
    var26.setDataset(var27);
    var26.setMaximumLabelWidth(100.0d);
    org.jfree.chart.labels.PieToolTipGenerator var31 = var26.getToolTipGenerator();
    java.awt.Paint var32 = var26.getNoDataMessagePaint();
    var10.setLabelBackgroundPaint(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 10.0d, (-1.0d));
    double var6 = var4.calculateBottomInset(1.0d);
    double var8 = var4.calculateBottomOutset((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10.0d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    var2.setSeriesVisibleInLegend(1, (java.lang.Boolean)true, true);
    java.awt.Shape var15 = var2.getSeriesShape(1);
    var2.setMinimumBarLength((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 10.0f, (-1.0f));
    var1.setLabelBackgroundPaint((java.awt.Paint)var26);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var30.setBaseCreateEntities(true);
    java.awt.Paint var34 = null;
    var30.setSeriesItemLabelPaint(0, var34, true);
    java.awt.Shape var37 = var30.getBaseShape();
    java.awt.Paint var40 = var30.getItemLabelPaint(10, 0);
    java.awt.Stroke var41 = var30.getBaseOutlineStroke();
    var1.setBaseSectionOutlineStroke(var41);
    var1.setOuterSeparatorExtension(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var4.setBaseCreateEntities(true);
    var4.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
    java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var19 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var20 = var19.getLabel();
    var19.setEndValue(10.0d);
    java.awt.Stroke var23 = var19.getStroke();
    org.jfree.chart.plot.CategoryMarker var24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var16, var23);
    var12.setNoDataMessagePaint((java.awt.Paint)var16);
    boolean var26 = var4.equals((java.lang.Object)var12);
    int var27 = var1.compareTo((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-1));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    boolean var11 = var6.isTickLabelsVisible();
    org.jfree.data.Range var12 = var6.getDefaultAutoRange();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var14 = null;
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(var13, var14);
    org.jfree.chart.block.LengthConstraintType var16 = var15.getHeightConstraintType();
    java.lang.String var17 = var16.toString();
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    org.jfree.chart.entity.ChartEntity var23 = new org.jfree.chart.entity.ChartEntity(var21, "");
    boolean var24 = var16.equals((java.lang.Object)var21);
    boolean var25 = var12.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var17.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!", "hi!");
    var5.setVersion("");
    var5.setVersion("hi!");
    java.lang.String var10 = var5.getVersion();
    java.lang.String var11 = var5.getName();
    var5.setVersion("(true, 0)");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "hi!"+ "'", var10.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.plot.IntervalMarker var20 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var21 = var20.getLabel();
    var20.setEndValue(10.0d);
    java.awt.Stroke var24 = var20.getStroke();
    org.jfree.chart.text.TextAnchor var25 = var20.getLabelTextAnchor();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var28.setBaseCreateEntities(true);
    java.awt.Paint var32 = null;
    var28.setSeriesItemLabelPaint(0, var32, true);
    java.awt.Shape var35 = var28.getBaseShape();
    java.awt.Paint var38 = var28.getItemLabelPaint(10, 0);
    java.awt.Stroke var39 = var28.getBaseOutlineStroke();
    var20.setOutlineStroke(var39);
    var2.setBaseOutlineStroke(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.chart.plot.PlotOrientation var5 = var4.getOrientation();
    var4.zoom(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    java.lang.String var5 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "ChartEntity: tooltip = "+ "'", var5.equals("ChartEntity: tooltip = "));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var18 = var17.getLabel();
    var17.setEndValue(10.0d);
    java.awt.Stroke var21 = var17.getStroke();
    org.jfree.chart.plot.CategoryMarker var22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var14, var21);
    var10.setNoDataMessagePaint((java.awt.Paint)var14);
    boolean var24 = var2.equals((java.lang.Object)var10);
    var10.setMaximumLabelWidth(0.0d);
    double var27 = var10.getMaximumLabelWidth();
    var10.setOutlineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    var1.setIgnoreZeroValues(true);
    java.awt.Paint var8 = var1.getShadowPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var1.getLegendLabelToolTipGenerator();
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    var1.handleClick(1, (-1), var12);
    java.awt.Stroke var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseSectionOutlineStroke(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(10.0d);
    double var2 = var1.getMax();
    var1.cursorDown(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLegendItemLabelGenerator(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]", var1);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    var2.setEndValue(10.0d);
    java.awt.Stroke var6 = var2.getStroke();
    org.jfree.chart.text.TextAnchor var7 = var2.getLabelTextAnchor();
    org.jfree.chart.plot.IntervalMarker var10 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var11 = var10.getLabelOffsetType();
    java.awt.Paint var12 = var10.getPaint();
    java.awt.Stroke var13 = var10.getOutlineStroke();
    float var14 = var10.getAlpha();
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.plot.MultiplePiePlot var16 = new org.jfree.chart.plot.MultiplePiePlot(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getInsets();
    var10.setLabelOffset(var17);
    double var20 = var17.calculateBottomOutset((-11.0d));
    var2.setLabelOffset(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 4.0d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    org.jfree.data.general.PieDataset var3 = null;
    var2.setDataset(var3);
    var2.setMaximumLabelWidth(100.0d);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("Pie Plot", (org.jfree.chart.plot.Plot)var2);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 1.0d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = ");
    java.awt.Paint var2 = var1.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Shape var6 = var2.getSeriesShape(0);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var2.notifyListeners(var7);
    boolean var11 = var2.getItemVisible(0, 1);
    var2.setBaseSeriesVisible(true, false);
    org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.awt.Paint var19 = var18.getOutlinePaint();
    var2.setSeriesFillPaint(1, var19, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var9 = var8.getTransparency();
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var14 = var13.getTransparency();
    boolean var15 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var8, (java.awt.Paint)var13);
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var8);
    org.jfree.chart.util.RectangleAnchor var17 = var16.getShapeAnchor();
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var19, "", "");
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var27 = var26.getTransparency();
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var32 = var31.getTransparency();
    boolean var33 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var26, (java.awt.Paint)var31);
    org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var19, (java.awt.Paint)var26);
    org.jfree.chart.util.RectangleAnchor var35 = var34.getShapeAnchor();
    var16.setShapeAnchor(var35);
    java.awt.Shape var37 = var16.getShape();
    boolean var38 = var16.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Stroke var4 = var2.getSeriesStroke(1);
    boolean var5 = var2.getAutoPopulateSeriesOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var1.setVisible(true);
    var1.setLabelURL("hi!");
    var1.setAutoRangeMinimumSize(17.0d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var5.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var5.getSeriesURLGenerator(100);
//     var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     java.awt.Font var15 = var5.getItemLabelFont(0, 1);
//     var2.setLabelFont(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var19.setLabel("");
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var24 = var23.getLowerMargin();
//     java.lang.Object var25 = var23.clone();
//     java.awt.Font var26 = var23.getLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var27);
//     double var29 = var28.getDomainCrosshairValue();
//     java.awt.Paint var30 = var28.getDomainCrosshairPaint();
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]", var15, var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.text.TextBlockAnchor var35 = null;
//     var31.draw(var32, 0.0f, 0.0f, var35, (-1.0f), 10.0f, 17.0d);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("CONTRACT");

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    var9.setBackgroundImageAlignment(0);
    int var14 = var9.getSubtitleCount();
    boolean var15 = var9.isBorderVisible();
    java.awt.Image var16 = null;
    var9.setBackgroundImage(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    boolean var5 = var2.isInverted();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    var2.setEndValue(10.0d);
    java.awt.Stroke var6 = var2.getStroke();
    org.jfree.chart.text.TextAnchor var7 = var2.getLabelTextAnchor();
    java.lang.Object var8 = var2.clone();
    org.jfree.chart.event.MarkerChangeEvent var9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var2);
    org.jfree.chart.plot.Marker var10 = var9.getMarker();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Pie Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(10, var10);
    java.awt.Shape var12 = var2.getBaseShape();
    double var13 = var2.getXOffset();
    var2.setBaseItemLabelsVisible(true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.labels.PieToolTipGenerator var6 = var1.getToolTipGenerator();
    java.awt.Paint var7 = var1.getNoDataMessagePaint();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    org.jfree.data.general.PieDataset var10 = null;
    var9.setDataset(var10);
    var9.setMaximumLabelWidth(100.0d);
    var9.setIgnoreZeroValues(true);
    java.awt.Paint var16 = var9.getShadowPaint();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    java.awt.Color var22 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var26 = var25.getLabel();
    var25.setEndValue(10.0d);
    java.awt.Stroke var29 = var25.getStroke();
    org.jfree.chart.plot.CategoryMarker var30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var22, var29);
    var18.setNoDataMessagePaint((java.awt.Paint)var22);
    java.awt.Color var35 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var36 = var35.getTransparency();
    java.awt.Color var37 = var35.brighter();
    var18.setLabelPaint((java.awt.Paint)var37);
    java.awt.Paint var39 = var18.getLabelPaint();
    var18.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.util.Rotation var42 = var18.getDirection();
    var9.setDirection(var42);
    var1.setDirection(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    java.awt.Paint var11 = var2.getItemPaint(100, (-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)0L);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = ");
    var1.setToolTipText("");
    var1.setHeight(17.0d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    var11.setRenderer(var12);
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var11.axisChanged(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.renderer.category.StackedBarRenderer3D var8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var8.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var8.getSeriesURLGenerator(100);
    var8.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var18 = var8.getItemLabelFont(0, 1);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("", var18);
    org.jfree.chart.plot.IntervalMarker var22 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var23 = var22.getLabelOffsetType();
    java.awt.Paint var24 = var22.getPaint();
    org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("", var18, var24, 100.0f);
    var2.setSeriesItemLabelFont(0, var18, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseCreateEntities(true, false);
    java.awt.Font var13 = null;
    var2.setSeriesItemLabelFont(100, var13);
    var2.setSeriesCreateEntities(10, (java.lang.Boolean)true);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var16 = var15.getLabel();
//     var15.setEndValue(10.0d);
//     java.awt.Stroke var19 = var15.getStroke();
//     org.jfree.chart.plot.CategoryMarker var20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var12, var19);
//     var8.setNoDataMessagePaint((java.awt.Paint)var12);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var26 = var25.getTransparency();
//     java.awt.Color var27 = var25.brighter();
//     var8.setLabelPaint((java.awt.Paint)var27);
//     java.awt.Paint var29 = var8.getLabelPaint();
//     var8.setBackgroundImageAlpha(1.0f);
//     var6.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     org.jfree.chart.axis.SegmentedTimeline var36 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
//     java.util.Date var38 = var36.getDate(100L);
//     org.jfree.data.KeyToGroupMap var39 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)var38);
//     org.jfree.data.Range var40 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var6, var39);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var2.setVisible(true);
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var6.setVisible(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var15 = var14.getTransparency();
//     java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var20 = var19.getTransparency();
//     boolean var21 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var14, (java.awt.Paint)var19);
//     java.awt.Color var22 = var14.brighter();
//     var10.setDomainGridlinePaint((java.awt.Paint)var22);
//     var10.setRangeCrosshairLockedOnData(false);
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     org.jfree.chart.plot.PlotState var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var10.draw(var26, var27, var28, var29, var30);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(1.0d, (-1.0d));
    java.lang.Number var3 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1.0d+ "'", var3.equals(1.0d));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    org.jfree.data.general.PieDataset var23 = null;
    var1.setDataset(var23);
    java.lang.Object var25 = var1.clone();
    var1.setShadowYOffset((-11.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    float var6 = var1.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    double var12 = var11.getDomainCrosshairValue();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    org.jfree.data.general.PieDataset var15 = null;
    var14.setDataset(var15);
    var14.setMaximumLabelWidth(100.0d);
    var14.setIgnoreZeroValues(true);
    java.awt.Paint var21 = var14.getShadowPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var22 = var14.getLegendLabelToolTipGenerator();
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var27 = var26.getTransparency();
    java.awt.Color var28 = var26.brighter();
    org.jfree.chart.plot.IntervalMarker var31 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var32 = var31.getLabel();
    var31.setEndValue(10.0d);
    java.awt.Stroke var35 = var31.getStroke();
    java.awt.Stroke var36 = var31.getOutlineStroke();
    org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var40 = var39.getLabelOffsetType();
    java.awt.Paint var41 = var39.getPaint();
    java.awt.Stroke var42 = var39.getOutlineStroke();
    float var43 = var39.getAlpha();
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.plot.MultiplePiePlot var45 = new org.jfree.chart.plot.MultiplePiePlot(var44);
    org.jfree.chart.util.RectangleInsets var46 = var45.getInsets();
    var39.setLabelOffset(var46);
    org.jfree.chart.util.RectangleInsets var52 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 10.0d, (-1.0d));
    var39.setLabelOffset(var52);
    org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var28, var36, var52);
    var14.setBaseSectionOutlineStroke(var36);
    var11.setDomainGridlineStroke(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }


    java.util.List var8 = null;
    org.jfree.data.statistics.BoxAndWhiskerItem var9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)100.0f, (java.lang.Number)(short)10, (java.lang.Number)100, (java.lang.Number)1.0d, (java.lang.Number)10.0d, (java.lang.Number)(-1), (java.lang.Number)(short)0, (java.lang.Number)0.0d, var8);
    java.lang.Number var10 = var9.getQ1();
    java.util.List var11 = var9.getOutliers();
    java.lang.Number var12 = var9.getQ3();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var15.setBaseCreateEntities(true);
    var15.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var15.setBaseCreateEntities(true, false);
    java.awt.Font var26 = null;
    var15.setSeriesItemLabelFont(100, var26);
    boolean var28 = var9.equals((java.lang.Object)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100+ "'", var10.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1.0d+ "'", var12.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 10.0f, (-1.0f));
    var1.setLabelBackgroundPaint((java.awt.Paint)var26);
    float var28 = var1.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.5f);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
    java.util.Date var5 = var3.getDate(100L);
    org.jfree.data.KeyToGroupMap var6 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)var5);
    java.lang.Object var7 = var6.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(10.0d);
    double var2 = var1.getMax();
    var1.cursorUp((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = ");
    var1.setToolTipText("");
    var1.setWidth((-11.0d));
    var1.setMargin(1.0d, (-11.0d), 17.0d, 0.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var14.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var18 = var14.getSeriesURLGenerator(100);
    var14.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var24 = var14.getItemLabelFont(0, 1);
    org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("", var24);
    var1.setFont(var24);
    var1.setID("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    int var14 = var11.getWeight();
    boolean var15 = var11.isRangeZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    org.jfree.chart.labels.ItemLabelPosition var11 = var2.getPositiveItemLabelPosition((-460), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var4.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = var4.getSeriesURLGenerator(100);
//     var4.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     java.awt.Font var14 = var4.getItemLabelFont(0, 1);
//     java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     java.lang.String var19 = var18.toString();
//     java.awt.Color var20 = var18.brighter();
//     org.jfree.chart.text.TextLine var21 = new org.jfree.chart.text.TextLine("", var14, (java.awt.Paint)var18);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var28.setBaseCreateEntities(true);
//     java.awt.Paint var32 = null;
//     var28.setSeriesItemLabelPaint(0, var32, true);
//     java.awt.Shape var35 = var28.getBaseShape();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var38.setBaseCreateEntities(true);
//     java.awt.Paint var42 = null;
//     var38.setSeriesItemLabelPaint(0, var42, true);
//     java.awt.Stroke var46 = null;
//     var38.setSeriesStroke(10, var46);
//     java.awt.Shape var48 = var38.getBaseShape();
//     org.jfree.chart.plot.IntervalMarker var51 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var52 = var51.getLabelOffsetType();
//     java.awt.Paint var53 = var51.getPaint();
//     var38.setWallPaint(var53);
//     org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var35, var53);
//     java.text.AttributedString var56 = var55.getAttributedLabel();
//     java.awt.Paint var57 = var55.getOutlinePaint();
//     org.jfree.chart.text.TextBlock var58 = org.jfree.chart.text.TextUtilities.createTextBlock("CONTRACT", var14, var57);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var4.", var28.equals(var4) == var4.equals(var28));
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    var1.setValue((java.lang.Number)(short)100, (java.lang.Comparable)(short)10, (java.lang.Comparable)0);
    java.lang.Comparable var7 = var1.getRowKey(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow((java.lang.Comparable)(-16579837));
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)10+ "'", var7.equals((short)10));

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    org.jfree.chart.JFreeChart var36 = null;
    org.jfree.chart.event.ChartProgressEvent var39 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1), var36, 100, (-1));
    var39.setPercent(100);
    boolean var42 = var33.equals((java.lang.Object)var39);
    boolean var43 = var33.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    double var12 = var11.getDomainCrosshairValue();
    double var13 = var11.getDomainCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var4 = null;
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
    int var8 = var6.indexOf((java.lang.Comparable)(short)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("CONTRACT");

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    java.awt.Font var5 = null;
    var2.setSeriesItemLabelFont(10, var5);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    var2.setBaseOutlinePaint((java.awt.Paint)var9);
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var11);
    java.awt.Paint var14 = var2.lookupSeriesOutlinePaint(1);
    org.jfree.chart.labels.ItemLabelPosition var15 = var2.getBaseNegativeItemLabelPosition();
    boolean var16 = var2.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }


    java.text.DateFormat var2 = null;
    org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(1, 1, var2);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var10.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var13);
    boolean var15 = var10.isTickLabelsVisible();
    org.jfree.data.Range var16 = var10.getDefaultAutoRange();
    boolean var17 = var3.equals((java.lang.Object)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setLabel("");
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var7 = var6.getLowerMargin();
    java.lang.Object var8 = var6.clone();
    java.awt.Font var9 = var6.getLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var13.setVisible(true);
    var13.setLabelURL("hi!");
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 0.0d);
    var13.setRange(var20, true, true);
    var2.setRange(var20);
    double var25 = var20.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    var33.setSeriesKey((java.lang.Comparable)100L);
    java.awt.Stroke var37 = var33.getOutlineStroke();
    java.awt.Shape var38 = var33.getLine();
    var33.setSeriesKey((java.lang.Comparable)(-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var5.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var5.getSeriesURLGenerator(100);
//     var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     java.awt.Font var15 = var5.getItemLabelFont(0, 1);
//     var2.setLabelFont(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var19.setLabel("");
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var24 = var23.getLowerMargin();
//     java.lang.Object var25 = var23.clone();
//     java.awt.Font var26 = var23.getLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var27);
//     double var29 = var28.getDomainCrosshairValue();
//     java.awt.Paint var30 = var28.getDomainCrosshairPaint();
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]", var15, var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.text.TextBlockAnchor var35 = null;
//     java.awt.Shape var39 = var31.calculateBounds(var32, 0.0f, 0.0f, var35, 0.0f, 0.0f, 17.0d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.axis.NumberTickUnit var3 = var2.getTickUnit();
    var2.setPositiveArrowVisible(true);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    java.awt.Font var11 = null;
    var8.setSeriesItemLabelFont(10, var11);
    java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
    var8.setBaseOutlinePaint((java.awt.Paint)var15);
    org.jfree.chart.JFreeChart var17 = null;
    org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var17);
    java.awt.Paint var20 = var8.lookupSeriesOutlinePaint(1);
    var2.setLabelPaint(var20);
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var22);
    java.awt.Stroke var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setAxisLineStroke(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, (-1.0d), 0.0d);
    org.jfree.data.KeyedObject var6 = new org.jfree.data.KeyedObject((java.lang.Comparable)'#', (java.lang.Object)var5);
    java.lang.Object var7 = var6.getObject();
    java.lang.Object var8 = var6.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var9 = var8.getTransparency();
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var14 = var13.getTransparency();
    boolean var15 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var8, (java.awt.Paint)var13);
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var8);
    org.jfree.chart.util.RectangleAnchor var17 = var16.getShapeAnchor();
    var16.setLineVisible(false);
    org.jfree.chart.util.GradientPaintTransformer var20 = var16.getFillPaintTransformer();
    java.awt.Paint var21 = var16.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    java.text.NumberFormat var11 = var2.getNumberFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 10.0d, (-1.0d), 1.0d);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var11.setBaseCreateEntities(true);
    java.awt.Paint var15 = null;
    var11.setSeriesItemLabelPaint(0, var15, true);
    java.awt.Shape var18 = var11.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var21.setBaseCreateEntities(true);
    java.awt.Paint var25 = null;
    var21.setSeriesItemLabelPaint(0, var25, true);
    java.awt.Stroke var29 = null;
    var21.setSeriesStroke(10, var29);
    java.awt.Shape var31 = var21.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var35 = var34.getLabelOffsetType();
    java.awt.Paint var36 = var34.getPaint();
    var21.setWallPaint(var36);
    org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var18, var36);
    java.awt.Paint var39 = var38.getOutlinePaint();
    org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder(var4, var39);
    double var41 = var4.getTop();
    double var43 = var4.calculateBottomOutset((-1.0d));
    double var45 = var4.calculateTopInset((-1.0d));
    java.awt.geom.Rectangle2D var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var49 = var4.createInsetRectangle(var46, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10.0d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Paint var8 = null;
    java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
    java.awt.Paint var10 = null;
    java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
    java.awt.Paint[] var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var11, var12, var14, var16, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var18);
    org.jfree.chart.event.ChartChangeEventType var21 = null;
    var20.setType(var21);
    var7.notifyListeners(var20);
    var4.rendererChanged(var20);
    var4.zoom(100.0d);
    java.lang.String var27 = var4.getPlotType();
    java.awt.Paint var28 = var4.getAngleLabelPaint();
    boolean var29 = var4.isAngleLabelsVisible();
    org.jfree.chart.plot.IntervalMarker var32 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var33 = var32.getLabel();
    var32.setEndValue(10.0d);
    java.awt.Stroke var36 = var32.getStroke();
    java.awt.Stroke var37 = var32.getOutlineStroke();
    var4.setRadiusGridlineStroke(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Polar Plot"+ "'", var27.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, (-1.0d), 0.0f, (-1.0f));
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.lang.String var10 = var9.toString();
    org.jfree.chart.title.LegendGraphic var11 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var10.equals("java.awt.Color[r=0,g=0,b=0]"));

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var12.setLabel("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.annotations.XYAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test287"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 1.0d);
    org.jfree.chart.labels.ItemLabelPosition var5 = var2.getPositiveItemLabelPosition(100, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test288"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    java.awt.Paint var4 = var1.getBaseSectionPaint();
    java.awt.Stroke var5 = var1.getSeparatorStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test289"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     var5.setBaseCreateEntities(true);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var5.getSeriesURLGenerator(100);
//     var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     java.awt.Font var15 = var5.getItemLabelFont(0, 1);
//     var2.setLabelFont(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var19.setLabel("");
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var24 = var23.getLowerMargin();
//     java.lang.Object var25 = var23.clone();
//     java.awt.Font var26 = var23.getLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var27);
//     double var29 = var28.getDomainCrosshairValue();
//     java.awt.Paint var30 = var28.getDomainCrosshairPaint();
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]", var15, var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.text.TextBlockAnchor var35 = null;
//     java.awt.Shape var39 = var31.calculateBounds(var32, (-1.0f), 0.0f, var35, 100.0f, 10.0f, 0.0d);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test290"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.configureRangeAxes();
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var11.indexOf(var16);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var11.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var20);
    org.jfree.chart.plot.Plot var22 = var11.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test291"); }


    java.awt.Font var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    var3.setDataset(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setAntiAlias(false);
    org.jfree.chart.text.TextLine var13 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setTextAntiAlias((java.lang.Object)var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test292"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    double var7 = var1.getExplodePercent((java.lang.Comparable)(short)0);
    java.awt.Paint var8 = var1.getBaseSectionPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test293"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var16 = var15.getLabelOffsetType();
    java.awt.Paint var17 = var15.getPaint();
    java.awt.Stroke var18 = var15.getOutlineStroke();
    float var19 = var15.getAlpha();
    org.jfree.chart.util.Layer var20 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var15, var20);
    java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var26 = var25.getTransparency();
    java.awt.Color var27 = var25.brighter();
    var11.setDomainTickBandPaint((java.awt.Paint)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test294"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test295"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
    java.lang.Number[][] var4 = null;
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
    java.util.List var7 = var6.getRowKeys();
    org.jfree.data.general.SeriesChangeEvent var8 = null;
    var6.seriesChanged(var8);
    java.lang.Object var10 = null;
    boolean var11 = var6.equals(var10);
    var6.validateObject();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test296"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var15 = var14.getTransparency();
    java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var20 = var19.getTransparency();
    boolean var21 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var14, (java.awt.Paint)var19);
    java.awt.Color var22 = var14.brighter();
    var10.setDomainGridlinePaint((java.awt.Paint)var22);
    boolean var24 = var10.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test297"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.configureRangeAxes();
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var11.indexOf(var16);
    java.awt.Stroke var18 = var11.getRangeCrosshairStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test298"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("CONTRACT", "hi!", "ChartEntity: tooltip = ", var3, "", "", "hi!");
    java.util.List var8 = var7.getContributors();
    java.awt.Image var9 = var7.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test299"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-16579837), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test300"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.axis.ValueAxis var12 = var10.getDomainAxis(10);
    java.awt.Paint var13 = var10.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test301"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    var33.setSeriesKey((java.lang.Comparable)100L);
    java.awt.Stroke var37 = var33.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test302"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    float var6 = var2.getAlpha();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    org.jfree.data.general.PieDataset var9 = null;
    var8.setDataset(var9);
    var8.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var8.setURLGenerator(var13);
    java.awt.Paint var16 = var8.getSectionPaint((java.lang.Comparable)false);
    boolean var17 = var8.getIgnoreZeroValues();
    double var18 = var8.getStartAngle();
    boolean var19 = var2.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test303"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var12.setLabel("");
    var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var12);
    var10.setDomainZeroBaselineVisible(true);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test304"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     java.util.List var7 = var6.getRowKeys();
//     org.jfree.data.general.SeriesChangeEvent var8 = null;
//     var6.seriesChanged(var8);
//     boolean var10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var6);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test305"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var9, var10, var11, var12, var13);
    var2.setBaseSeriesVisible(false, false);
    boolean var18 = var2.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
    var2.setSeriesToolTipGenerator(0, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test306"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-16579837));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test307"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-16579837));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4021070));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test308"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    var1.setDataset(var2);
    var1.setMaximumLabelWidth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    boolean var8 = var1.getIgnoreZeroValues();
    java.awt.Stroke var9 = var1.getOutlineStroke();
    org.jfree.chart.plot.Plot var10 = var1.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test309"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var6 = var2.getLabelOffsetType();
    java.awt.Stroke var7 = var2.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test310"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]");

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test311"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var9 = var8.getLabel();
    var8.setEndValue(10.0d);
    java.awt.Stroke var12 = var8.getStroke();
    org.jfree.chart.plot.CategoryMarker var13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var12);
    var1.setNoDataMessagePaint((java.awt.Paint)var5);
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var19 = var18.getTransparency();
    java.awt.Color var20 = var18.brighter();
    var1.setLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var1.getLabelPaint();
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 10.0f, (-1.0f));
    var1.setLabelBackgroundPaint((java.awt.Paint)var26);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var30.setBaseCreateEntities(true);
    java.awt.Paint var34 = null;
    var30.setSeriesItemLabelPaint(0, var34, true);
    java.awt.Shape var37 = var30.getBaseShape();
    java.awt.Paint var40 = var30.getItemLabelPaint(10, 0);
    java.awt.Stroke var41 = var30.getBaseOutlineStroke();
    var1.setBaseSectionOutlineStroke(var41);
    var1.setShadowXOffset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test312"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    var4.setURLText("hi!");
    java.lang.String var7 = var4.toString();
    java.lang.Object var8 = var4.clone();
    java.lang.String var9 = var4.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "ChartEntity: tooltip = "+ "'", var7.equals("ChartEntity: tooltip = "));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "0,100,100,-100,-100,-100,-100,-100"+ "'", var9.equals("0,100,100,-100,-100,-100,-100,-100"));

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test313"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var7 = var6.getLabel();
    var6.setEndValue(10.0d);
    java.awt.Stroke var10 = var6.getStroke();
    org.jfree.chart.plot.CategoryMarker var11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var3, var10);
    boolean var12 = var11.getDrawAsLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test314"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var3.setBaseCreateEntities(true);
    java.awt.Paint var7 = null;
    var3.setSeriesItemLabelPaint(0, var7, true);
    java.awt.Shape var10 = var3.getBaseShape();
    var3.setSeriesVisibleInLegend(1, (java.lang.Boolean)true, true);
    java.awt.Paint var17 = var3.getItemFillPaint((-460), 100);
    org.jfree.data.KeyedObject var18 = new org.jfree.data.KeyedObject((java.lang.Comparable)10, (java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test315"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.configureRangeAxes();
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var11.indexOf(var16);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var11.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var20);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var20.valueToJava2D(17.0d, var23, var24);
    org.jfree.chart.plot.IntervalMarker var28 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var29 = var28.getLabelOffsetType();
    java.awt.Paint var30 = var28.getPaint();
    java.awt.Stroke var31 = var28.getOutlineStroke();
    float var32 = var28.getAlpha();
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.plot.MultiplePiePlot var34 = new org.jfree.chart.plot.MultiplePiePlot(var33);
    org.jfree.chart.util.RectangleInsets var35 = var34.getInsets();
    var28.setLabelOffset(var35);
    double var38 = var35.calculateBottomOutset((-11.0d));
    double var40 = var35.extendWidth(1.0d);
    org.jfree.chart.util.UnitType var41 = var35.getUnitType();
    org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets(var41, 10.0d, 1.0d, (-11.0d), 10.0d);
    var20.setLabelInsets(var46);
    var20.setTickMarkInsideLength(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 17.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test316"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("(true, 0)", var1, 100.0f, 100.0f, 10.0d, 10.0f, 0.0f);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test317"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    float var2 = var1.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test318"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var2.setLabel("");
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var7 = var6.getLowerMargin();
//     java.lang.Object var8 = var6.clone();
//     java.awt.Font var9 = var6.getLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var13.setVisible(true);
//     var13.setLabelURL("hi!");
//     org.jfree.data.Range var18 = null;
//     org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 0.0d);
//     var13.setRange(var20, true, true);
//     var2.setRange(var20);
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var20, (-1.0d));
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var29.setLabel("");
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     double var34 = var33.getLowerMargin();
//     java.lang.Object var35 = var33.clone();
//     java.awt.Font var36 = var33.getLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.axis.ValueAxis)var33, var37);
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var40.setVisible(true);
//     var40.setLabelURL("hi!");
//     org.jfree.data.Range var45 = null;
//     org.jfree.data.Range var47 = org.jfree.data.Range.expandToInclude(var45, 0.0d);
//     var40.setRange(var47, true, true);
//     var29.setRange(var47);
//     org.jfree.data.Range var52 = org.jfree.data.Range.combine(var20, var47);
//     
//     // Checks the contract:  equals-hashcode on var11 and var38
//     assertTrue("Contract failed: equals-hashcode on var11 and var38", var11.equals(var38) ? var11.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var11
//     assertTrue("Contract failed: equals-hashcode on var38 and var11", var38.equals(var11) ? var38.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test319"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    java.awt.Paint var12 = var11.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test320"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var4 = var3.getItemLabelAnchor();
    java.awt.Font var6 = null;
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot(var7);
    org.jfree.data.category.CategoryDataset var9 = null;
    var8.setDataset(var9);
    org.jfree.chart.event.AxisChangeEvent var11 = null;
    var8.axisChanged(var11);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("CONTRACT", var6, (org.jfree.chart.plot.Plot)var8, false);
    var14.setAntiAlias(false);
    var14.setBackgroundImageAlignment(0);
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    var14.setBackgroundPaint((java.awt.Paint)var22);
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var3, var14, (-4021070), (-4021070));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test321"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var4, var5);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     var6.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
//     int var11 = var6.getColumnIndex((java.lang.Comparable)(short)10);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test322"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1), var1, 100, (-1));
    org.jfree.chart.JFreeChart var5 = var4.getChart();
    java.lang.Object var6 = var4.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test323"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var2.getSeriesURLGenerator(100);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var12 = var2.getItemLabelFont(0, 1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLegendItemLabelGenerator(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test324"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var3.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var3.getSeriesURLGenerator(100);
    var3.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var13 = var3.getItemLabelFont(0, 1);
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.lang.String var18 = var17.toString();
    java.awt.Color var19 = var17.brighter();
    org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("", var13, (java.awt.Paint)var17);
    org.jfree.chart.text.TextFragment var21 = var20.getFirstTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var18.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test325"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var3.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var3.getSeriesURLGenerator(100);
    var3.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Font var13 = var3.getItemLabelFont(0, 1);
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.lang.String var18 = var17.toString();
    java.awt.Color var19 = var17.brighter();
    org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("", var13, (java.awt.Paint)var17);
    org.jfree.chart.text.TextFragment var21 = var20.getLastTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var18.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test326"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.configureRangeAxes();
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var11.indexOf(var16);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var11.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var20);
    org.jfree.chart.event.ChartChangeEvent var22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var20);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var29.setBaseCreateEntities(true);
    java.awt.Paint var33 = null;
    var29.setSeriesItemLabelPaint(0, var33, true);
    java.awt.Shape var36 = var29.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var39.setBaseCreateEntities(true);
    java.awt.Paint var43 = null;
    var39.setSeriesItemLabelPaint(0, var43, true);
    java.awt.Stroke var47 = null;
    var39.setSeriesStroke(10, var47);
    java.awt.Shape var49 = var39.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var52 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var53 = var52.getLabelOffsetType();
    java.awt.Paint var54 = var52.getPaint();
    var39.setWallPaint(var54);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var36, var54);
    var20.setUpArrow(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test327"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-16579837));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test328"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    org.jfree.data.general.SeriesChangeEvent var3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    org.jfree.data.general.PieDataset var6 = null;
    var5.setDataset(var6);
    var5.setMaximumLabelWidth(100.0d);
    var5.setIgnoreZeroValues(true);
    java.awt.Paint var12 = var5.getShadowPaint();
    var1.setAggregatedItemsPaint(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test329"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var2.getBaseURLGenerator();
    int var6 = var2.getPassCount();
    var2.setBaseSeriesVisible(false);
    var2.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var2.getLegendItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test330"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var6 = var3.containsDomainRange(0L, 1L);
    java.lang.Object var7 = var3.clone();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var17 = var16.getLabel();
    var16.setEndValue(10.0d);
    java.awt.Stroke var20 = var16.getStroke();
    org.jfree.chart.plot.CategoryMarker var21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var13, var20);
    var9.setNoDataMessagePaint((java.awt.Paint)var13);
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var27 = var26.getTransparency();
    java.awt.Color var28 = var26.brighter();
    var9.setLabelPaint((java.awt.Paint)var28);
    boolean var30 = var3.equals((java.lang.Object)var28);
    var3.addException(1L, 0L);
    java.awt.Font var35 = null;
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.plot.MultiplePiePlot var37 = new org.jfree.chart.plot.MultiplePiePlot(var36);
    org.jfree.data.category.CategoryDataset var38 = null;
    var37.setDataset(var38);
    org.jfree.chart.event.AxisChangeEvent var40 = null;
    var37.axisChanged(var40);
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("CONTRACT", var35, (org.jfree.chart.plot.Plot)var37, false);
    org.jfree.chart.event.ChartChangeEvent var44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1L, var43);
    org.jfree.chart.event.ChartChangeEventType var45 = null;
    var44.setType(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test331"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Stroke var5 = var2.getOutlineStroke();
    float var6 = var2.getAlpha();
    java.awt.Paint var7 = var2.getLabelPaint();
    double var8 = var2.getEndValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test332"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=-11.0]");
//     org.jfree.chart.axis.CategoryAnchor var2 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var1.getCategoryJava2DCoordinate(var2, (-460), (-1), var5, var6);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test333"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("0,100,100,-100,-100,-100,-100,-100");

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test334"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    var2.setAutoPopulateSeriesPaint(false);
    boolean var8 = var2.getItemCreateEntity((-460), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test335"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    java.awt.Paint var6 = null;
    var2.setSeriesItemLabelPaint(0, var6, true);
    java.awt.Shape var9 = var2.getBaseShape();
    double var10 = var2.getYOffset();
    boolean var11 = var2.getRenderAsPercentages();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Color var17 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.plot.IntervalMarker var20 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var21 = var20.getLabel();
    var20.setEndValue(10.0d);
    java.awt.Stroke var24 = var20.getStroke();
    org.jfree.chart.plot.CategoryMarker var25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var17, var24);
    var13.setNoDataMessagePaint((java.awt.Paint)var17);
    java.awt.Color var30 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var31 = var30.getTransparency();
    java.awt.Color var32 = var30.brighter();
    var13.setLabelPaint((java.awt.Paint)var32);
    java.awt.Paint var34 = var13.getLabelPaint();
    var2.setBaseFillPaint(var34);
    org.jfree.chart.labels.CategoryItemLabelGenerator var38 = var2.getItemLabelGenerator(0, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test336"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     var3.setDataset(var4);
//     org.jfree.chart.event.AxisChangeEvent var6 = null;
//     var3.axisChanged(var6);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
//     var9.setAntiAlias(false);
//     var9.setBackgroundImageAlignment(0);
//     org.jfree.chart.axis.SegmentedTimeline var17 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
//     boolean var20 = var17.containsDomainRange(0L, 1L);
//     java.lang.Object var21 = var17.clone();
//     java.lang.Comparable[] var23 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var25 = new java.lang.Comparable[] { (byte)0};
//     java.lang.Number[][] var26 = null;
//     java.lang.Number[][] var27 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var23, var25, var26, var27);
//     java.util.List var29 = var28.getRowKeys();
//     var17.setExceptionSegments(var29);
//     var9.setSubtitles(var29);
//     java.awt.Image var32 = var9.getBackgroundImage();
//     java.awt.Graphics2D var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     java.awt.geom.Point2D var35 = null;
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     var9.draw(var33, var34, var35, var36);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test337"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.axis.ValueAxis var12 = var10.getDomainAxis(10);
    java.awt.Stroke var13 = var10.getRangeCrosshairStroke();
    var10.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test338"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
    java.util.Date var5 = var3.getDate(100L);
    org.jfree.chart.axis.SegmentedTimeline var9 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
    java.util.Date var11 = var9.getDate(100L);
    long var12 = var3.getTime(var11);
    int var13 = var3.getGroupSegmentCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 99);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test339"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     int var4 = var3.getTransparency();
//     java.awt.Color var5 = var3.brighter();
//     org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     java.lang.String var9 = var8.getLabel();
//     var8.setEndValue(10.0d);
//     java.awt.Stroke var12 = var8.getStroke();
//     java.awt.Stroke var13 = var8.getOutlineStroke();
//     org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var17 = var16.getLabelOffsetType();
//     java.awt.Paint var18 = var16.getPaint();
//     java.awt.Stroke var19 = var16.getOutlineStroke();
//     float var20 = var16.getAlpha();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getInsets();
//     var16.setLabelOffset(var23);
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 10.0d, (-1.0d));
//     var16.setLabelOffset(var29);
//     org.jfree.chart.block.LineBorder var31 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var5, var13, var29);
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var31.draw(var32, var33);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test340"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, (-11.0d));
    double var3 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test341"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
//     java.awt.Font var5 = null;
//     var2.setSeriesItemLabelFont(10, var5);
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
//     var2.setBaseOutlinePaint((java.awt.Paint)var9);
//     org.jfree.chart.JFreeChart var11 = null;
//     org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var11);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = null;
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
//     var16.setVisible(true);
//     java.lang.Object var19 = var16.clone();
//     java.awt.Shape var20 = var16.getLeftArrow();
//     java.awt.geom.Rectangle2D var21 = null;
//     var2.drawRangeGridline(var13, var14, (org.jfree.chart.axis.ValueAxis)var16, var21, 0.0d);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test342"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = ");
    var1.setToolTipText("");
    var1.setWidth((-11.0d));
    var1.setMargin(1.0d, (-11.0d), 17.0d, 0.0d);
    double var11 = var1.getWidth();
    var1.setID("0,100,100,-100,-100,-100,-100,-100");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-11.0d));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test343"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    var11.setRangeCrosshairVisible(true);
    boolean var14 = var11.isRangeZoomable();
    var11.configureRangeAxes();
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var11.indexOf(var16);
    java.awt.Stroke var18 = var11.getRangeCrosshairStroke();
    org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var22 = var21.getLabel();
    var21.setEndValue(10.0d);
    java.awt.Stroke var25 = var21.getStroke();
    var11.addDomainMarker((org.jfree.chart.plot.Marker)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test344"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    double var3 = var2.getLowerMargin();
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    java.lang.Object var9 = var6.clone();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var10);
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    var11.setRenderer(var12);
    org.jfree.chart.util.RectangleEdge var15 = var11.getDomainAxisEdge(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test345"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getBaseNegativeItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var4 = var3.getItemLabelAnchor();
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var7.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var11.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var20 = var19.getTransparency();
    java.awt.Color var24 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var25 = var24.getTransparency();
    boolean var26 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var19, (java.awt.Paint)var24);
    java.awt.Color var27 = var19.brighter();
    var15.setDomainGridlinePaint((java.awt.Paint)var27);
    var15.setRangeCrosshairLockedOnData(false);
    java.awt.Graphics2D var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.axis.SegmentedTimeline var36 = new org.jfree.chart.axis.SegmentedTimeline((-1L), (-1), (-1));
    boolean var38 = var36.containsDomainValue(100L);
    org.jfree.chart.axis.SegmentedTimeline var42 = new org.jfree.chart.axis.SegmentedTimeline(10L, (-1), 100);
    java.util.Date var44 = var42.getDate(100L);
    org.jfree.chart.axis.SegmentedTimeline.Segment var45 = var36.getSegment(var44);
    java.util.List var46 = var36.getExceptionSegments();
    var15.drawDomainTickBands(var31, var32, var46);
    boolean var48 = var4.equals((java.lang.Object)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test346"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test347"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    java.awt.Paint var8 = null;
    java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
    java.awt.Paint var10 = null;
    java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
    java.awt.Paint[] var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Stroke[] var14 = new java.awt.Stroke[] { var13};
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Shape var17 = null;
    java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var11, var12, var14, var16, var18);
    org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var18);
    org.jfree.chart.event.ChartChangeEventType var21 = null;
    var20.setType(var21);
    var7.notifyListeners(var20);
    var4.rendererChanged(var20);
    var4.zoom(100.0d);
    java.lang.String var27 = var4.getPlotType();
    java.awt.Paint var28 = var4.getAngleLabelPaint();
    var4.addCornerTextItem("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Polar Plot"+ "'", var27.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test348"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.String var2 = var1.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test349"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    java.lang.String var3 = var2.getLabel();
    var2.setEndValue(10.0d);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var8, "ChartEntity: tooltip = ");
    org.jfree.chart.plot.IntervalMarker var13 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var14 = var13.getLabelOffsetType();
    java.awt.Paint var15 = var13.getPaint();
    java.awt.Stroke var16 = var13.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var17 = var13.getLabelOffsetType();
    boolean var18 = var10.equals((java.lang.Object)var17);
    var2.setLabelOffsetType(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test350"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     var3.setDataset(var4);
//     org.jfree.chart.event.AxisChangeEvent var6 = null;
//     var3.axisChanged(var6);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("CONTRACT", var1, (org.jfree.chart.plot.Plot)var3, false);
//     org.jfree.chart.event.ChartProgressListener var10 = null;
//     var9.removeProgressListener(var10);
//     java.awt.Stroke var12 = var9.getBorderStroke();
//     org.jfree.chart.event.PlotChangeEvent var13 = null;
//     var9.plotChanged(var13);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test351"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    var33.setSeriesKey((java.lang.Comparable)100L);
    java.awt.Shape var37 = var33.getShape();
    java.awt.Paint var38 = var33.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test352"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "", "");
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var9 = var8.getTransparency();
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    int var14 = var13.getTransparency();
    boolean var15 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var8, (java.awt.Paint)var13);
    org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var8);
    org.jfree.chart.util.RectangleAnchor var17 = var16.getShapeAnchor();
    var16.setLineVisible(false);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var26.setBaseCreateEntities(true);
    java.awt.Paint var30 = null;
    var26.setSeriesItemLabelPaint(0, var30, true);
    java.awt.Shape var33 = var26.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var36.setBaseCreateEntities(true);
    java.awt.Paint var40 = null;
    var36.setSeriesItemLabelPaint(0, var40, true);
    java.awt.Stroke var44 = null;
    var36.setSeriesStroke(10, var44);
    java.awt.Shape var46 = var36.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var49 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var50 = var49.getLabelOffsetType();
    java.awt.Paint var51 = var49.getPaint();
    var36.setWallPaint(var51);
    org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var33, var51);
    java.awt.Paint var54 = var53.getOutlinePaint();
    int var55 = var53.getDatasetIndex();
    java.awt.Shape var56 = var53.getShape();
    var16.setLine(var56);
    boolean var58 = var16.isShapeFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test353"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    boolean var9 = var2.getBaseSeriesVisible();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = null;
    var2.setLegendItemToolTipGenerator(var10);
    double var12 = var2.getMinimumBarLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test354"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var2.setBaseCreateEntities(true);
    var2.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, false);
    var2.setBaseCreateEntities(true, false);
    var2.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);
    var2.setSeriesItemLabelsVisible(0, false);
    var2.setBaseCreateEntities(false);
    org.jfree.chart.plot.CategoryPlot var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setPlot(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test355"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     var1.handleClick((-1), 0, var4);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot(var6);
//     org.jfree.data.category.CategoryDataset var8 = null;
//     var7.setDataset(var8);
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var7.axisChanged(var10);
//     org.jfree.chart.util.TableOrder var12 = var7.getDataExtractOrder();
//     var1.setDataExtractOrder(var12);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test356"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var2.setVisible(true);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = ");
    var6.setVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var9);
    boolean var11 = var6.isTickLabelsVisible();
    var6.setLowerBound(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test357"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(10);
    int var2 = var1.getYYYY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1900);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test358"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("CONTRACT");

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test359"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
//     java.awt.Paint var4 = var2.getPaint();
//     java.awt.Stroke var5 = var2.getOutlineStroke();
//     float var6 = var2.getAlpha();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot(var7);
//     org.jfree.chart.util.RectangleInsets var9 = var8.getInsets();
//     var2.setLabelOffset(var9);
//     org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), 10.0d, (-1.0d));
//     var2.setLabelOffset(var15);
//     org.jfree.chart.util.RectangleAnchor var17 = var2.getLabelAnchor();
//     org.jfree.chart.plot.IntervalMarker var20 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var21 = var20.getLabelOffsetType();
//     java.awt.Paint var22 = var20.getPaint();
//     java.awt.Stroke var23 = var20.getOutlineStroke();
//     float var24 = var20.getAlpha();
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getInsets();
//     var20.setLabelOffset(var27);
//     double var30 = var27.calculateBottomOutset((-11.0d));
//     double var32 = var27.extendWidth(1.0d);
//     org.jfree.chart.util.UnitType var33 = var27.getUnitType();
//     var2.setLabelOffset(var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test360"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var6.setBaseCreateEntities(true);
    java.awt.Paint var10 = null;
    var6.setSeriesItemLabelPaint(0, var10, true);
    java.awt.Shape var13 = var6.getBaseShape();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, (-1.0d));
    var16.setBaseCreateEntities(true);
    java.awt.Paint var20 = null;
    var16.setSeriesItemLabelPaint(0, var20, true);
    java.awt.Stroke var24 = null;
    var16.setSeriesStroke(10, var24);
    java.awt.Shape var26 = var16.getBaseShape();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    java.awt.Paint var31 = var29.getPaint();
    var16.setWallPaint(var31);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", var13, var31);
    java.awt.Paint var34 = var33.getOutlinePaint();
    var33.setSeriesKey((java.lang.Comparable)100L);
    java.awt.Stroke var37 = var33.getOutlineStroke();
    java.awt.Shape var38 = var33.getLine();
    boolean var39 = var33.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);

  }

}
