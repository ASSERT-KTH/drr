
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var4 = null;
//     org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2, (-1.0f), var4);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 10.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { '#'};
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     java.lang.Number[] var6 = null;
//     java.lang.Number[][] var7 = new java.lang.Number[][] { var6};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5, var7);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var4 = new org.jfree.chart.title.LegendGraphic(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.text.DateFormat var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(100, 10, 100, 100, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("SerialDate.weekInMonthToString(): invalid code.", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-435));

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var0.setRangeWithMargins((org.jfree.data.Range)var3, false, true);
    java.awt.Shape var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setUpArrow(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 10.0d, var2);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Paint var2 = null;
    java.awt.Stroke var3 = null;
    java.awt.Paint var4 = null;
    java.awt.Stroke var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(100.0d, 1.0d, var2, var3, var4, var5, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.drawOutline(var1, var2, var3);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var0.setRangeWithMargins((org.jfree.data.Range)var3, false, true);
    org.jfree.data.Range var7 = var0.getDefaultAutoRange();
    org.jfree.data.Range var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setInteriorGap(100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 1, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("SerialDate.weekInMonthToString(): invalid code.", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getCategoryMargin();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D(var4);
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var5);
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     org.jfree.chart.axis.AxisSpace var9 = null;
//     org.jfree.chart.axis.AxisSpace var10 = var0.reserveSpace(var2, (org.jfree.chart.plot.Plot)var5, var7, var8, var9);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.lang.Object var3 = null;
    boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)(-1), var1, var2, var3, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     java.util.Date var3 = var1.calculateHighestVisibleTickValue(var2);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var2 = var1.getUpArrow();
//     java.awt.Shape var3 = var1.getDownArrow();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.axis.AxisState var10 = var1.draw(var4, 0.2d, var6, var7, var8, var9);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.awt.Color var0 = null;
//     java.lang.String var1 = org.jfree.chart.util.PaintUtilities.colorToString(var0);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    boolean var2 = var0.equals((java.lang.Object)(-1.0f));
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-1), var4, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     java.awt.Paint var8 = var2.getLabelLinkPaint();
//     org.jfree.chart.event.PlotChangeEvent var9 = null;
//     var2.notifyListeners(var9);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.event.TitleChangeEvent var4 = null;
//     var3.titleChanged(var4);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.chart.axis.AxisState var7 = var0.draw(var1, 0.0d, var3, var4, var5, var6);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "", "");
//     org.jfree.data.category.CategoryDataset var4 = null;
//     java.lang.String var7 = var3.generateURL(var4, 1, (-1));
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("SerialDate.weekInMonthToString(): invalid code.", var1, 1.0f, 100.0f, var4, 1.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.category.CategoryDataset var16 = null;
//     var0.drawItem(var9, var10, var11, var12, var13, (org.jfree.chart.axis.ValueAxis)var15, var16, 0, 0, 10);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.category.CategoryDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.generateLabel(var1, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var4);
    var4.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var8 = var4.getURLGenerator();
    java.awt.Shape var9 = var4.getLegendItemShape();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    double var11 = var10.getCategoryMargin();
    boolean var12 = var4.equals((java.lang.Object)var11);
    java.awt.Paint var13 = var4.getShadowPaint();
    java.awt.Stroke var14 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var17 = null;
    var15.setSeriesItemLabelFont(1, var17);
    boolean var19 = var15.getBaseSeriesVisibleInLegend();
    java.awt.Paint var22 = var15.getItemOutlinePaint(13, 100);
    org.jfree.chart.renderer.category.IntervalBarRenderer var23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var24 = var23.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getBaseItemLabelGenerator();
    double var26 = var23.getBase();
    java.awt.Stroke var27 = var23.getBaseOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(0.0d, 10.0d, var13, var14, var22, var27, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.util.Rotation var8 = var2.getDirection();
    org.jfree.chart.util.RectangleInsets var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setInsets(var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(13, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     int var4 = var3.getBackgroundImageAlignment();
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     var3.handleClick((-435), 0, var7);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 0.0d, var4, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.util.Rotation var8 = var2.getDirection();
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
    var13.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var17 = var13.getURLGenerator();
    java.awt.Shape var18 = var13.getLegendItemShape();
    org.jfree.chart.util.Rotation var19 = var13.getDirection();
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var22 = var2.initialise(var9, var10, (org.jfree.chart.plot.PiePlot)var13, (java.lang.Integer)1, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "First"+ "'", var1.equals("First"));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = var0.getLegendItemToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.plot.CategoryPlot var3 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var6 = var0.initialise(var1, var2, var3, 13, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, var1);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.2d);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.LegendItemEntity var1 = new org.jfree.chart.entity.LegendItemEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
    java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var13 = null;
    var11.setSeriesItemLabelFont(1, var13);
    boolean var15 = var11.getBaseSeriesVisibleInLegend();
    java.awt.Paint var18 = var11.getItemOutlinePaint(13, 100);
    var0.setBaseFillPaint(var18, true);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var25 = var24.getUpArrow();
    java.awt.Shape var26 = var24.getDownArrow();
    org.jfree.chart.plot.Marker var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    var0.drawRangeMarker(var21, var22, (org.jfree.chart.axis.ValueAxis)var24, var27, var28);
    var24.setTickLabelsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     java.awt.Shape var22 = var17.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var23 = null;
//     var17.setLabelGenerator(var23);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
//     int var29 = var28.getBackgroundImageAlignment();
//     var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var34);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var38 = null;
//     var36.setSeriesItemLabelFont(1, var38);
//     boolean var40 = var36.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
//     var32.setBaseItemLabelPaint(var43);
//     var17.setSectionPaint((java.lang.Comparable)(short)100, var43);
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("Default Group", var14, var43);
//     java.awt.geom.Rectangle2D var47 = var46.getBounds();
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var52 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var49.setRangeWithMargins((org.jfree.data.Range)var52, false, true);
//     org.jfree.data.Range var56 = var49.getDefaultAutoRange();
//     java.awt.Graphics2D var57 = null;
//     org.jfree.chart.axis.AxisState var58 = null;
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     java.util.List var61 = var49.refreshTicks(var57, var58, var59, var60);
//     java.awt.Font var62 = var49.getLabelFont();
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.PiePlot3D var65 = new org.jfree.chart.plot.PiePlot3D(var64);
//     org.jfree.chart.JFreeChart var66 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var65);
//     var65.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var69 = var65.getURLGenerator();
//     java.awt.Shape var70 = var65.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var71 = null;
//     var65.setLabelGenerator(var71);
//     org.jfree.data.general.PieDataset var74 = null;
//     org.jfree.chart.plot.PiePlot3D var75 = new org.jfree.chart.plot.PiePlot3D(var74);
//     org.jfree.chart.JFreeChart var76 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var75);
//     int var77 = var76.getBackgroundImageAlignment();
//     var65.addChangeListener((org.jfree.chart.event.PlotChangeListener)var76);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var80 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var82 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var80.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var82);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var84 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var86 = null;
//     var84.setSeriesItemLabelFont(1, var86);
//     boolean var88 = var84.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var91 = var84.getItemOutlinePaint(13, 100);
//     var80.setBaseItemLabelPaint(var91);
//     var65.setSectionPaint((java.lang.Comparable)(short)100, var91);
//     org.jfree.chart.block.LabelBlock var94 = new org.jfree.chart.block.LabelBlock("Default Group", var62, var91);
//     java.awt.geom.Rectangle2D var95 = var94.getBounds();
//     boolean var96 = org.jfree.chart.util.ShapeUtilities.intersects(var47, var95);
//     
//     // Checks the contract:  equals-hashcode on var17 and var65
//     assertTrue("Contract failed: equals-hashcode on var17 and var65", var17.equals(var65) ? var17.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var75
//     assertTrue("Contract failed: equals-hashcode on var27 and var75", var27.equals(var75) ? var27.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var17
//     assertTrue("Contract failed: equals-hashcode on var65 and var17", var65.equals(var17) ? var65.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var27
//     assertTrue("Contract failed: equals-hashcode on var75 and var27", var75.equals(var27) ? var75.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var66
//     assertTrue("Contract failed: equals-hashcode on var18 and var66", var18.equals(var66) ? var18.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var76
//     assertTrue("Contract failed: equals-hashcode on var28 and var76", var28.equals(var76) ? var28.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var18
//     assertTrue("Contract failed: equals-hashcode on var66 and var18", var66.equals(var18) ? var66.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var28
//     assertTrue("Contract failed: equals-hashcode on var76 and var28", var76.equals(var28) ? var76.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var82
//     assertTrue("Contract failed: equals-hashcode on var34 and var82", var34.equals(var82) ? var34.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var34
//     assertTrue("Contract failed: equals-hashcode on var82 and var34", var82.equals(var34) ? var82.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var94
//     assertTrue("Contract failed: equals-hashcode on var46 and var94", var46.equals(var94) ? var46.hashCode() == var94.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var94 and var46
//     assertTrue("Contract failed: equals-hashcode on var94 and var46", var94.equals(var46) ? var94.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "", "");
//     org.jfree.data.category.CategoryDataset var4 = null;
//     java.lang.String var7 = var3.generateURL(var4, 0, (-435));
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Nearest"+ "'", var1.equals("Nearest"));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.category.CategoryDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.generateLabel(var1, 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-457));

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     java.awt.Shape var22 = var17.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var23 = null;
//     var17.setLabelGenerator(var23);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
//     int var29 = var28.getBackgroundImageAlignment();
//     var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var34);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var38 = null;
//     var36.setSeriesItemLabelFont(1, var38);
//     boolean var40 = var36.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
//     var32.setBaseItemLabelPaint(var43);
//     var17.setSectionPaint((java.lang.Comparable)(short)100, var43);
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("Default Group", var14, var43);
//     java.awt.geom.Rectangle2D var47 = var46.getBounds();
//     org.jfree.chart.util.RectangleInsets var48 = var46.getPadding();
//     org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var53 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var50.setRangeWithMargins((org.jfree.data.Range)var53, false, true);
//     org.jfree.data.Range var57 = var50.getDefaultAutoRange();
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.axis.AxisState var59 = null;
//     java.awt.geom.Rectangle2D var60 = null;
//     org.jfree.chart.util.RectangleEdge var61 = null;
//     java.util.List var62 = var50.refreshTicks(var58, var59, var60, var61);
//     java.awt.Font var63 = var50.getLabelFont();
//     org.jfree.data.general.PieDataset var65 = null;
//     org.jfree.chart.plot.PiePlot3D var66 = new org.jfree.chart.plot.PiePlot3D(var65);
//     org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var66);
//     var66.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var70 = var66.getURLGenerator();
//     java.awt.Shape var71 = var66.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var72 = null;
//     var66.setLabelGenerator(var72);
//     org.jfree.data.general.PieDataset var75 = null;
//     org.jfree.chart.plot.PiePlot3D var76 = new org.jfree.chart.plot.PiePlot3D(var75);
//     org.jfree.chart.JFreeChart var77 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var76);
//     int var78 = var77.getBackgroundImageAlignment();
//     var66.addChangeListener((org.jfree.chart.event.PlotChangeListener)var77);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var81 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var83 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var81.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var83);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var85 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var87 = null;
//     var85.setSeriesItemLabelFont(1, var87);
//     boolean var89 = var85.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var92 = var85.getItemOutlinePaint(13, 100);
//     var81.setBaseItemLabelPaint(var92);
//     var66.setSectionPaint((java.lang.Comparable)(short)100, var92);
//     org.jfree.chart.block.LabelBlock var95 = new org.jfree.chart.block.LabelBlock("Default Group", var63, var92);
//     java.awt.geom.Rectangle2D var96 = var95.getBounds();
//     java.awt.geom.Rectangle2D var99 = var48.createInsetRectangle(var96, true, true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var66
//     assertTrue("Contract failed: equals-hashcode on var17 and var66", var17.equals(var66) ? var17.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var76
//     assertTrue("Contract failed: equals-hashcode on var27 and var76", var27.equals(var76) ? var27.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var17
//     assertTrue("Contract failed: equals-hashcode on var66 and var17", var66.equals(var17) ? var66.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var27
//     assertTrue("Contract failed: equals-hashcode on var76 and var27", var76.equals(var27) ? var76.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var67
//     assertTrue("Contract failed: equals-hashcode on var18 and var67", var18.equals(var67) ? var18.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var77
//     assertTrue("Contract failed: equals-hashcode on var28 and var77", var28.equals(var77) ? var28.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var18
//     assertTrue("Contract failed: equals-hashcode on var67 and var18", var67.equals(var18) ? var67.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var28
//     assertTrue("Contract failed: equals-hashcode on var77 and var28", var77.equals(var28) ? var77.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var83
//     assertTrue("Contract failed: equals-hashcode on var34 and var83", var34.equals(var83) ? var34.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var34
//     assertTrue("Contract failed: equals-hashcode on var83 and var34", var83.equals(var34) ? var83.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var95
//     assertTrue("Contract failed: equals-hashcode on var46 and var95", var46.equals(var95) ? var46.hashCode() == var95.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var95 and var46
//     assertTrue("Contract failed: equals-hashcode on var95 and var46", var95.equals(var46) ? var95.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Default Group");

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
//     var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     double var14 = var13.getCategoryMargin();
//     int var15 = var13.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var17.lengthToJava2D(100.0d, var19, var20);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     var0.drawItem(var9, var10, var11, var12, var13, (org.jfree.chart.axis.ValueAxis)var17, var22, 10, (-457), 100);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    java.awt.Shape var22 = var17.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var23 = null;
    var17.setLabelGenerator(var23);
    org.jfree.data.general.PieDataset var26 = null;
    org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
    int var29 = var28.getBackgroundImageAlignment();
    var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
    org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var34);
    org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var38 = null;
    var36.setSeriesItemLabelFont(1, var38);
    boolean var40 = var36.getBaseSeriesVisibleInLegend();
    java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
    var32.setBaseItemLabelPaint(var43);
    var17.setSectionPaint((java.lang.Comparable)(short)100, var43);
    org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("Default Group", var14, var43);
    java.awt.geom.Rectangle2D var47 = var46.getBounds();
    org.jfree.chart.util.RectangleInsets var48 = var46.getPadding();
    org.jfree.chart.block.BlockFrame var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var46.setFrame(var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
    java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var13 = null;
    var11.setSeriesItemLabelFont(1, var13);
    boolean var15 = var11.getBaseSeriesVisibleInLegend();
    java.awt.Paint var18 = var11.getItemOutlinePaint(13, 100);
    var0.setBaseFillPaint(var18, true);
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var24);
    var24.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var28 = var24.getURLGenerator();
    java.awt.Shape var29 = var24.getLegendItemShape();
    java.awt.Paint var30 = var24.getLabelLinkPaint();
    var0.setSeriesFillPaint(10, var30, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
//     var2.setLabelGenerator(var8);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
//     int var14 = var13.getBackgroundImageAlignment();
//     var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
//     java.awt.Stroke var16 = var13.getBorderStroke();
//     org.jfree.chart.event.TitleChangeEvent var17 = null;
//     var13.titleChanged(var17);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-1));
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var3 = var1.lookupSeriesShape((-1));
    var0.setUpArrow(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize((-1.0d), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (-457));
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelDistributor(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
//     java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var13 = null;
//     var11.setSeriesItemLabelFont(1, var13);
//     boolean var15 = var11.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var18 = var11.getItemOutlinePaint(13, 100);
//     var0.setBaseFillPaint(var18, true);
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var24);
//     var24.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var28 = var24.getURLGenerator();
//     java.awt.Shape var29 = var24.getLegendItemShape();
//     java.awt.Paint var30 = var24.getLabelLinkPaint();
//     var0.setSeriesFillPaint(10, var30, false);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var35 = var34.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var34.getBaseItemLabelGenerator();
//     java.awt.Paint var38 = null;
//     var34.setSeriesFillPaint(1, var38, false);
//     var34.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.ItemLabelPosition var45 = var34.getSeriesPositiveItemLabelPosition(100);
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var50 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var47.setRangeWithMargins((org.jfree.data.Range)var50, false, true);
//     org.jfree.data.Range var54 = var47.getDefaultAutoRange();
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.axis.AxisState var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     org.jfree.chart.util.RectangleEdge var58 = null;
//     java.util.List var59 = var47.refreshTicks(var55, var56, var57, var58);
//     java.awt.Font var60 = var47.getLabelFont();
//     org.jfree.data.general.PieDataset var62 = null;
//     org.jfree.chart.plot.PiePlot3D var63 = new org.jfree.chart.plot.PiePlot3D(var62);
//     org.jfree.chart.JFreeChart var64 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var63);
//     var63.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var67 = var63.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var68 = null;
//     var63.axisChanged(var68);
//     org.jfree.chart.JFreeChart var71 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var60, (org.jfree.chart.plot.Plot)var63, false);
//     boolean var72 = var45.equals((java.lang.Object)var60);
//     var0.setSeriesPositiveItemLabelPosition(1, var45);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var34.", var11.equals(var34) == var34.equals(var11));
//     
//     // Checks the contract:  equals-hashcode on var24 and var63
//     assertTrue("Contract failed: equals-hashcode on var24 and var63", var24.equals(var63) ? var24.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var24
//     assertTrue("Contract failed: equals-hashcode on var63 and var24", var63.equals(var24) ? var63.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var64
//     assertTrue("Contract failed: equals-hashcode on var25 and var64", var25.equals(var64) ? var25.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var25
//     assertTrue("Contract failed: equals-hashcode on var64 and var25", var64.equals(var25) ? var64.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 1.0d, var4, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
    java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var13 = null;
    var11.setSeriesItemLabelFont(1, var13);
    boolean var15 = var11.getBaseSeriesVisibleInLegend();
    java.awt.Paint var18 = var11.getItemOutlinePaint(13, 100);
    var0.setBaseFillPaint(var18, true);
    java.awt.Color var23 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var24 = var23.getTransparency();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-1), (java.awt.Paint)var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Nearest", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0.0f};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)100};
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     java.lang.Number[] var6 = null;
//     java.lang.Number[][] var7 = new java.lang.Number[][] { var6};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5, var7);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     double var8 = var2.getMaximumExplodePercent();
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var1 = var0.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
//     java.awt.Paint var4 = null;
//     var0.setSeriesFillPaint(1, var4, false);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var10 = null;
//     var8.setSeriesItemLabelFont(1, var10);
//     boolean var12 = var8.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var15 = var8.getItemOutlinePaint(13, 100);
//     var0.setSeriesOutlinePaint(13, var15, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     java.awt.Shape var22 = var17.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var23 = null;
//     var17.setLabelGenerator(var23);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
//     int var29 = var28.getBackgroundImageAlignment();
//     var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var34);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var38 = null;
//     var36.setSeriesItemLabelFont(1, var38);
//     boolean var40 = var36.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
//     var32.setBaseItemLabelPaint(var43);
//     var17.setSectionPaint((java.lang.Comparable)(short)100, var43);
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("Default Group", var14, var43);
//     var46.setURLText("");
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.util.Size2D var50 = var46.arrange(var49);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     java.awt.Shape var22 = var17.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var23 = null;
//     var17.setLabelGenerator(var23);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
//     int var29 = var28.getBackgroundImageAlignment();
//     var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var34);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var38 = null;
//     var36.setSeriesItemLabelFont(1, var38);
//     boolean var40 = var36.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
//     var32.setBaseItemLabelPaint(var43);
//     var17.setSectionPaint((java.lang.Comparable)(short)100, var43);
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("Default Group", var14, var43);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.block.RectangleConstraint var48 = null;
//     org.jfree.chart.util.Size2D var49 = var46.arrange(var47, var48);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer(var0, var1, (java.lang.Comparable)(short)1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var4 = null;
    var0.setSeriesFillPaint(1, var4, false);
    var0.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.plot.CategoryPlot var10 = var0.getPlot();
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-457), var12, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    boolean var1 = var0.getRenderAsPercentages();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Monday"+ "'", var1.equals("Monday"));

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var8 = null;
//     var7.rendererChanged(var8);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var7);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var14 = null;
//     var12.setSeriesItemLabelFont(1, var14);
//     double var16 = var12.getItemMargin();
//     boolean var18 = var12.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var21 = var12.getNegativeItemLabelPosition(13, 4);
//     var0.setSeriesNegativeItemLabelPosition(0, var21);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.util.RectangleEdge var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.ensureAtLeast(10.0d, var2);
      fail("Expected exception of type java.lang.IllegalStateException");
    } catch (java.lang.IllegalStateException e) {
      // Expected exception.
    }

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var4.setRangeWithMargins((org.jfree.data.Range)var7, false, true);
//     org.jfree.data.Range var11 = var4.getDefaultAutoRange();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.AxisState var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     java.util.List var16 = var4.refreshTicks(var12, var13, var14, var15);
//     java.awt.Font var17 = var4.getLabelFont();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D(var19);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var20);
//     var20.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var24 = var20.getURLGenerator();
//     java.awt.Shape var25 = var20.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var26 = null;
//     var20.setLabelGenerator(var26);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D(var29);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var30);
//     int var32 = var31.getBackgroundImageAlignment();
//     var20.addChangeListener((org.jfree.chart.event.PlotChangeListener)var31);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var37 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var35.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var37);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var41 = null;
//     var39.setSeriesItemLabelFont(1, var41);
//     boolean var43 = var39.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var46 = var39.getItemOutlinePaint(13, 100);
//     var35.setBaseItemLabelPaint(var46);
//     var20.setSectionPaint((java.lang.Comparable)(short)100, var46);
//     org.jfree.chart.block.LabelBlock var49 = new org.jfree.chart.block.LabelBlock("Default Group", var17, var46);
//     java.awt.geom.Rectangle2D var50 = var49.getBounds();
//     org.jfree.chart.plot.CategoryPlot var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
//     double var53 = var52.getCategoryMargin();
//     java.awt.Paint var54 = var52.getTickMarkPaint();
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var57 = var56.getUpArrow();
//     org.jfree.data.gantt.TaskSeriesCollection var58 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var59 = null;
//     var58.addChangeListener(var59);
//     var0.drawItem(var1, var2, var50, var51, var52, (org.jfree.chart.axis.ValueAxis)var56, (org.jfree.data.category.CategoryDataset)var58, (-1), (-457), (-457));
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    double var16 = var15.getHeight();
    org.jfree.chart.util.VerticalAlignment var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setVerticalAlignment(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    java.awt.Shape var2 = null;
    boolean var3 = org.jfree.chart.util.ShapeUtilities.equal(var1, var2);
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    double var6 = var2.getMaximumLabelWidth();
    var2.setLabelGap(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.TaskSeries var2 = var0.getSeries(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    org.jfree.chart.event.MarkerChangeEvent var7 = null;
    var2.markerChanged(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    java.awt.Shape var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var3.setRangeWithMargins((org.jfree.data.Range)var6, false, true);
    org.jfree.data.Range var10 = var3.getDefaultAutoRange();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.AxisState var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    java.util.List var15 = var3.refreshTicks(var11, var12, var13, var14);
    java.awt.Font var16 = var3.getLabelFont();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    var19.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
    java.awt.Shape var24 = var19.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = null;
    var19.setLabelGenerator(var25);
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
    int var31 = var30.getBackgroundImageAlignment();
    var19.addChangeListener((org.jfree.chart.event.PlotChangeListener)var30);
    org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var36 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var34.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var36);
    org.jfree.chart.renderer.category.IntervalBarRenderer var38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var40 = null;
    var38.setSeriesItemLabelFont(1, var40);
    boolean var42 = var38.getBaseSeriesVisibleInLegend();
    java.awt.Paint var45 = var38.getItemOutlinePaint(13, 100);
    var34.setBaseItemLabelPaint(var45);
    var19.setSectionPaint((java.lang.Comparable)(short)100, var45);
    org.jfree.chart.block.LabelBlock var48 = new org.jfree.chart.block.LabelBlock("Default Group", var16, var45);
    java.awt.geom.Rectangle2D var49 = var48.getBounds();
    java.awt.geom.Point2D var50 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 0.2d, var49);
    java.io.ObjectOutputStream var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var50, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 100.0d, 0.0d, var3);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var2.axisChanged(var7);
    double var10 = var2.getExplodePercent((java.lang.Comparable)"First");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
//     long var4 = var3.getSegmentsExcludedSize();
//     var3.addException((-1L), 0L);
//     long var9 = var3.toTimelineValue(10L);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Shape var3 = var1.getDownArrow();
    java.util.Date var4 = var1.getMinimumDate();
    var1.setLabelURL("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    double var16 = var15.getHeight();
    org.jfree.chart.util.RectangleEdge var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setPosition(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var4 = null;
    var0.setSeriesFillPaint(1, var4, false);
    var0.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var11 = var0.getSeriesPositiveItemLabelPosition(100);
    var0.setBaseItemLabelsVisible(true, false);
    org.jfree.chart.urls.StandardCategoryURLGenerator var15 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    org.jfree.chart.axis.AxisCollection var16 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var17 = var16.getAxesAtBottom();
    java.util.List var18 = var16.getAxesAtBottom();
    boolean var19 = var15.equals((java.lang.Object)var16);
    var0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var15, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

//  public void test132() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//
//  }
//
  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Shape var3 = var1.getDownArrow();
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
//     var2.setLabelGenerator(var8);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
//     int var14 = var13.getBackgroundImageAlignment();
//     var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     var2.drawBackground(var16, var17);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    var0.setDrawBarOutline(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
//     var2.setLabelGenerator(var8);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
//     int var14 = var13.getBackgroundImageAlignment();
//     var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
//     org.jfree.chart.event.PlotChangeEvent var16 = null;
//     var13.plotChanged(var16);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getEndValue((java.lang.Comparable)'#', (java.lang.Comparable)10L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var2 = var1.getWidthRatio();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.95f);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    java.awt.Paint var18 = var15.getItemPaint();
    org.jfree.chart.util.VerticalAlignment var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setVerticalAlignment(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var1 = null;
    var0.addChangeListener(var1);
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getStartValue((java.lang.Comparable)(-1.0f), var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
//     var2.setLabelGenerator(var8);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
//     int var14 = var13.getBackgroundImageAlignment();
//     var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var18);
//     var18.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var22 = var18.getURLGenerator();
//     org.jfree.chart.labels.PieSectionLabelGenerator var23 = var18.getLabelGenerator();
//     var2.setLabelGenerator(var23);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var19
//     assertTrue("Contract failed: equals-hashcode on var3 and var19", var3.equals(var19) ? var3.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var3
//     assertTrue("Contract failed: equals-hashcode on var19 and var3", var19.equals(var3) ? var19.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
//     var2.setLabelGenerator(var8);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
//     int var14 = var13.getBackgroundImageAlignment();
//     var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
//     java.awt.Stroke var16 = var13.getBorderStroke();
//     org.jfree.chart.event.PlotChangeEvent var17 = null;
//     var13.plotChanged(var17);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(1.0d, (-1.05d));
    java.lang.Object var3 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.labels.PieToolTipGenerator var6 = null;
    var2.setToolTipGenerator(var6);
    java.awt.Paint var8 = var2.getBackgroundPaint();
    org.jfree.chart.plot.AbstractPieLabelDistributor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelDistributor(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.labels.PieToolTipGenerator var6 = null;
    var2.setToolTipGenerator(var6);
    java.lang.Comparable var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var9 = var2.getSectionPaint(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var3 = var1.lookupSeriesShape((-1));
    var0.setUpArrow(var3);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var6.setRangeWithMargins((org.jfree.data.Range)var9, false, true);
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.AxisState var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    java.util.List var18 = var6.refreshTicks(var14, var15, var16, var17);
    java.awt.Font var19 = var6.getLabelFont();
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D(var21);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var22);
    var22.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var26 = var22.getURLGenerator();
    java.awt.Shape var27 = var22.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var28 = null;
    var22.setLabelGenerator(var28);
    org.jfree.data.general.PieDataset var31 = null;
    org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D(var31);
    org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var32);
    int var34 = var33.getBackgroundImageAlignment();
    var22.addChangeListener((org.jfree.chart.event.PlotChangeListener)var33);
    org.jfree.chart.renderer.category.IntervalBarRenderer var37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var39 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var37.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var39);
    org.jfree.chart.renderer.category.IntervalBarRenderer var41 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var43 = null;
    var41.setSeriesItemLabelFont(1, var43);
    boolean var45 = var41.getBaseSeriesVisibleInLegend();
    java.awt.Paint var48 = var41.getItemOutlinePaint(13, 100);
    var37.setBaseItemLabelPaint(var48);
    var22.setSectionPaint((java.lang.Comparable)(short)100, var48);
    org.jfree.chart.block.LabelBlock var51 = new org.jfree.chart.block.LabelBlock("Default Group", var19, var48);
    java.awt.geom.Rectangle2D var52 = var51.getBounds();
    boolean var53 = org.jfree.chart.util.ShapeUtilities.equal(var3, (java.awt.Shape)var52);
    org.jfree.data.KeyToGroupMap var54 = new org.jfree.data.KeyToGroupMap();
    org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var57 = var56.getUpArrow();
    boolean var58 = var54.equals((java.lang.Object)var57);
    boolean var59 = org.jfree.chart.util.ShapeUtilities.equal(var3, var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 10.0d, 100.0d, 1.0d, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
//     java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var13 = null;
//     var11.setSeriesItemLabelFont(1, var13);
//     boolean var15 = var11.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var18 = var11.getItemOutlinePaint(13, 100);
//     var0.setBaseFillPaint(var18, true);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = null;
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var25 = var24.getUpArrow();
//     java.awt.Shape var26 = var24.getDownArrow();
//     org.jfree.chart.plot.Marker var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var0.drawRangeMarker(var21, var22, (org.jfree.chart.axis.ValueAxis)var24, var27, var28);
//     var0.setAutoPopulateSeriesShape(false);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var33 = var32.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var34 = var32.getBaseItemLabelGenerator();
//     java.awt.Paint var36 = null;
//     var32.setSeriesFillPaint(1, var36, false);
//     var32.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.ItemLabelPosition var43 = var32.getSeriesPositiveItemLabelPosition(100);
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var48 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var45.setRangeWithMargins((org.jfree.data.Range)var48, false, true);
//     org.jfree.data.Range var52 = var45.getDefaultAutoRange();
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.axis.AxisState var54 = null;
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     java.util.List var57 = var45.refreshTicks(var53, var54, var55, var56);
//     java.awt.Font var58 = var45.getLabelFont();
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot3D var61 = new org.jfree.chart.plot.PiePlot3D(var60);
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var61);
//     var61.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var65 = var61.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var66 = null;
//     var61.axisChanged(var66);
//     org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var58, (org.jfree.chart.plot.Plot)var61, false);
//     boolean var70 = var43.equals((java.lang.Object)var58);
//     var0.setBaseNegativeItemLabelPosition(var43);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var32.", var11.equals(var32) == var32.equals(var11));
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var3, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var8 = var7.toString();
    java.lang.String var9 = var7.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var8.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.lang.Object var16 = null;
//     boolean var17 = var15.equals(var16);
//     java.awt.Paint var18 = var15.getItemPaint();
//     org.jfree.chart.util.HorizontalAlignment var19 = var15.getHorizontalAlignment();
//     java.awt.Paint var20 = null;
//     var15.setBackgroundPaint(var20);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var25 = var23.lookupSeriesShape((-1));
//     var22.setUpArrow(var25);
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var31 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var28.setRangeWithMargins((org.jfree.data.Range)var31, false, true);
//     org.jfree.data.Range var35 = var28.getDefaultAutoRange();
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.axis.AxisState var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     java.util.List var40 = var28.refreshTicks(var36, var37, var38, var39);
//     java.awt.Font var41 = var28.getLabelFont();
//     org.jfree.data.general.PieDataset var43 = null;
//     org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D(var43);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var44);
//     var44.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var48 = var44.getURLGenerator();
//     java.awt.Shape var49 = var44.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var50 = null;
//     var44.setLabelGenerator(var50);
//     org.jfree.data.general.PieDataset var53 = null;
//     org.jfree.chart.plot.PiePlot3D var54 = new org.jfree.chart.plot.PiePlot3D(var53);
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var54);
//     int var56 = var55.getBackgroundImageAlignment();
//     var44.addChangeListener((org.jfree.chart.event.PlotChangeListener)var55);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var59 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var61 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var59.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var61);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var63 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var65 = null;
//     var63.setSeriesItemLabelFont(1, var65);
//     boolean var67 = var63.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var70 = var63.getItemOutlinePaint(13, 100);
//     var59.setBaseItemLabelPaint(var70);
//     var44.setSectionPaint((java.lang.Comparable)(short)100, var70);
//     org.jfree.chart.block.LabelBlock var73 = new org.jfree.chart.block.LabelBlock("Default Group", var41, var70);
//     java.awt.geom.Rectangle2D var74 = var73.getBounds();
//     boolean var75 = org.jfree.chart.util.ShapeUtilities.equal(var25, (java.awt.Shape)var74);
//     var15.setBounds(var74);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var3.", var23.equals(var3) == var3.equals(var23));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var63 and var3.", var63.equals(var3) == var3.equals(var63));
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var9.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var11);
//     var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var11);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var16 = null;
//     var14.setSeriesItemLabelFont(1, var16);
//     double var18 = var14.getItemMargin();
//     boolean var20 = var14.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var21 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var22 = null;
//     var21.rendererChanged(var22);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var29 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var26.setRangeWithMargins((org.jfree.data.Range)var29, false, true);
//     org.jfree.data.Range var33 = var26.getDefaultAutoRange();
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.axis.AxisState var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     java.util.List var38 = var26.refreshTicks(var34, var35, var36, var37);
//     java.awt.Font var39 = var26.getLabelFont();
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot3D var42 = new org.jfree.chart.plot.PiePlot3D(var41);
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var42);
//     var42.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var46 = var42.getURLGenerator();
//     java.awt.Shape var47 = var42.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var48 = null;
//     var42.setLabelGenerator(var48);
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D(var51);
//     org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var52);
//     int var54 = var53.getBackgroundImageAlignment();
//     var42.addChangeListener((org.jfree.chart.event.PlotChangeListener)var53);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var57 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var59 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var57.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var59);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var61 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var63 = null;
//     var61.setSeriesItemLabelFont(1, var63);
//     boolean var65 = var61.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var68 = var61.getItemOutlinePaint(13, 100);
//     var57.setBaseItemLabelPaint(var68);
//     var42.setSectionPaint((java.lang.Comparable)(short)100, var68);
//     org.jfree.chart.block.LabelBlock var71 = new org.jfree.chart.block.LabelBlock("Default Group", var39, var68);
//     java.awt.geom.Rectangle2D var72 = var71.getBounds();
//     org.jfree.chart.util.RectangleInsets var73 = var71.getPadding();
//     var21.setInsets(var73);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
//     
//     // Checks the contract:  equals-hashcode on var11 and var59
//     assertTrue("Contract failed: equals-hashcode on var11 and var59", var11.equals(var59) ? var11.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var11
//     assertTrue("Contract failed: equals-hashcode on var59 and var11", var59.equals(var11) ? var59.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     java.awt.Paint var3 = var1.lookupSeriesOutlinePaint(255);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var9.setRangeWithMargins((org.jfree.data.Range)var12, false, true);
//     org.jfree.data.Range var16 = var9.getDefaultAutoRange();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.AxisState var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     java.util.List var21 = var9.refreshTicks(var17, var18, var19, var20);
//     java.awt.Font var22 = var9.getLabelFont();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var25);
//     var25.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var29 = var25.getURLGenerator();
//     java.awt.Shape var30 = var25.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var31 = null;
//     var25.setLabelGenerator(var31);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot3D var35 = new org.jfree.chart.plot.PiePlot3D(var34);
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var35);
//     int var37 = var36.getBackgroundImageAlignment();
//     var25.addChangeListener((org.jfree.chart.event.PlotChangeListener)var36);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var40 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var42 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var40.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var42);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var46 = null;
//     var44.setSeriesItemLabelFont(1, var46);
//     boolean var48 = var44.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var51 = var44.getItemOutlinePaint(13, 100);
//     var40.setBaseItemLabelPaint(var51);
//     var25.setSectionPaint((java.lang.Comparable)(short)100, var51);
//     org.jfree.chart.block.LabelBlock var54 = new org.jfree.chart.block.LabelBlock("Default Group", var22, var51);
//     java.awt.geom.Rectangle2D var55 = var54.getBounds();
//     java.awt.geom.Point2D var56 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 0.2d, var55);
//     org.jfree.chart.plot.CategoryPlot var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis();
//     var58.setMaximumCategoryLabelLines((-435));
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.plot.MultiplePiePlot var62 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.data.gantt.TaskSeriesCollection var63 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var64 = null;
//     var63.addChangeListener(var64);
//     var62.setDataset((org.jfree.data.category.CategoryDataset)var63);
//     var1.drawItem(var4, var5, var55, var57, var58, var61, (org.jfree.data.category.CategoryDataset)var63, 2, 15, 100);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     java.awt.Shape var22 = var17.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var23 = null;
//     var17.setLabelGenerator(var23);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
//     int var29 = var28.getBackgroundImageAlignment();
//     var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var34);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var38 = null;
//     var36.setSeriesItemLabelFont(1, var38);
//     boolean var40 = var36.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
//     var32.setBaseItemLabelPaint(var43);
//     var17.setSectionPaint((java.lang.Comparable)(short)100, var43);
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("Default Group", var14, var43);
//     java.awt.geom.Rectangle2D var47 = var46.getBounds();
//     org.jfree.chart.util.RectangleInsets var48 = var46.getPadding();
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.block.RectangleConstraint var50 = null;
//     org.jfree.chart.util.Size2D var51 = var46.arrange(var49, var50);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
//     java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var13 = null;
//     var11.setSeriesItemLabelFont(1, var13);
//     boolean var15 = var11.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var18 = var11.getItemOutlinePaint(13, 100);
//     var0.setBaseFillPaint(var18, true);
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var18};
//     org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var23 = var22.getPaint();
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
//     var27.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var31 = var27.getURLGenerator();
//     java.awt.Shape var32 = var27.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var33 = null;
//     var27.setLabelGenerator(var33);
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D(var36);
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var37);
//     int var39 = var38.getBackgroundImageAlignment();
//     var27.addChangeListener((org.jfree.chart.event.PlotChangeListener)var38);
//     java.awt.Stroke var41 = var38.getBorderStroke();
//     java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot3D var45 = new org.jfree.chart.plot.PiePlot3D(var44);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var45);
//     var45.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var49 = var45.getURLGenerator();
//     java.awt.Shape var50 = var45.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var51 = null;
//     var45.setLabelGenerator(var51);
//     org.jfree.data.general.PieDataset var54 = null;
//     org.jfree.chart.plot.PiePlot3D var55 = new org.jfree.chart.plot.PiePlot3D(var54);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var55);
//     int var57 = var56.getBackgroundImageAlignment();
//     var45.addChangeListener((org.jfree.chart.event.PlotChangeListener)var56);
//     java.awt.Stroke var59 = var56.getBorderStroke();
//     java.awt.Stroke[] var60 = new java.awt.Stroke[] { var59};
//     java.awt.Shape[] var61 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var62 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var24, var42, var60, var61);
//     
//     // Checks the contract:  equals-hashcode on var27 and var45
//     assertTrue("Contract failed: equals-hashcode on var27 and var45", var27.equals(var45) ? var27.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var55
//     assertTrue("Contract failed: equals-hashcode on var37 and var55", var37.equals(var55) ? var37.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var27
//     assertTrue("Contract failed: equals-hashcode on var45 and var27", var45.equals(var27) ? var45.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var37
//     assertTrue("Contract failed: equals-hashcode on var55 and var37", var55.equals(var37) ? var55.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var46
//     assertTrue("Contract failed: equals-hashcode on var28 and var46", var28.equals(var46) ? var28.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var56
//     assertTrue("Contract failed: equals-hashcode on var38 and var56", var38.equals(var56) ? var38.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var28
//     assertTrue("Contract failed: equals-hashcode on var46 and var28", var46.equals(var28) ? var46.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var38
//     assertTrue("Contract failed: equals-hashcode on var56 and var38", var56.equals(var38) ? var56.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var3 = var2.getAlpha();
    java.awt.Paint var4 = var2.getPaint();
    var2.setEndValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    java.awt.Paint var18 = var15.getItemPaint();
    org.jfree.chart.util.HorizontalAlignment var19 = var15.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setVerticalAlignment(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var4 = null;
    var0.setSeriesFillPaint(1, var4, false);
    org.jfree.chart.plot.CategoryPlot var7 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var2);
    org.jfree.chart.util.GradientPaintTransformer var4 = var0.getGradientPaintTransformer();
    java.awt.Paint var6 = var0.getSeriesItemLabelPaint(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
    float[] var2 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var3 = var1.getColorComponents(var2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    java.awt.Paint var8 = var2.getLabelLinkPaint();
    org.jfree.chart.LegendItemCollection var9 = var2.getLegendItems();
    java.lang.Object var10 = var9.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getRowKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var2);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var6 = null;
//     var4.setSeriesItemLabelFont(1, var6);
//     boolean var8 = var4.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var11 = var4.getItemOutlinePaint(13, 100);
//     var0.setBaseItemLabelPaint(var11);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var15 = null;
//     var13.setSeriesItemLabelFont(1, var15);
//     double var17 = var13.getItemMargin();
//     boolean var19 = var13.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var21 = null;
//     var20.rendererChanged(var21);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var28 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var25.setRangeWithMargins((org.jfree.data.Range)var28, false, true);
//     org.jfree.data.Range var32 = var25.getDefaultAutoRange();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.axis.AxisState var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     java.util.List var37 = var25.refreshTicks(var33, var34, var35, var36);
//     java.awt.Font var38 = var25.getLabelFont();
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot3D var41 = new org.jfree.chart.plot.PiePlot3D(var40);
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var41);
//     var41.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var45 = var41.getURLGenerator();
//     java.awt.Shape var46 = var41.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var47 = null;
//     var41.setLabelGenerator(var47);
//     org.jfree.data.general.PieDataset var50 = null;
//     org.jfree.chart.plot.PiePlot3D var51 = new org.jfree.chart.plot.PiePlot3D(var50);
//     org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var51);
//     int var53 = var52.getBackgroundImageAlignment();
//     var41.addChangeListener((org.jfree.chart.event.PlotChangeListener)var52);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var56 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var58 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var56.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var58);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var62 = null;
//     var60.setSeriesItemLabelFont(1, var62);
//     boolean var64 = var60.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var67 = var60.getItemOutlinePaint(13, 100);
//     var56.setBaseItemLabelPaint(var67);
//     var41.setSectionPaint((java.lang.Comparable)(short)100, var67);
//     org.jfree.chart.block.LabelBlock var70 = new org.jfree.chart.block.LabelBlock("Default Group", var38, var67);
//     java.awt.geom.Rectangle2D var71 = var70.getBounds();
//     org.jfree.chart.util.RectangleInsets var72 = var70.getPadding();
//     var20.setInsets(var72);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     
//     // Checks the contract:  equals-hashcode on var2 and var58
//     assertTrue("Contract failed: equals-hashcode on var2 and var58", var2.equals(var58) ? var2.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var2
//     assertTrue("Contract failed: equals-hashcode on var58 and var2", var58.equals(var2) ? var58.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
//     long var4 = var3.getSegmentsExcludedSize();
//     int var5 = var3.getSegmentsIncluded();
//     long var7 = var3.getTimeFromLong(1L);
//     org.jfree.chart.axis.SegmentedTimeline var8 = var3.getBaseTimeline();
//     java.lang.Class var9 = null;
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var12 = var11.getUpArrow();
//     java.awt.Shape var13 = var11.getDownArrow();
//     java.util.Date var14 = var11.getMinimumDate();
//     java.util.TimeZone var15 = null;
//     org.jfree.data.time.RegularTimePeriod var16 = org.jfree.data.time.RegularTimePeriod.createInstance(var9, var14, var15);
//     long var17 = var3.toTimelineValue(var14);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
//     java.lang.Object var1 = var0.clone();
//     boolean var3 = var0.equals((java.lang.Object)"First");
//     java.lang.Object var4 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = var0.getRowIndex(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var1 = var0.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
//     java.awt.Paint var4 = null;
//     var0.setSeriesFillPaint(1, var4, false);
//     var0.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.plot.CategoryPlot var10 = var0.getPlot();
//     boolean var11 = var0.getBaseSeriesVisible();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     double var15 = var14.getCategoryMargin();
//     int var16 = var14.getCategoryLabelPositionOffset();
//     org.jfree.chart.plot.CategoryMarker var18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     var18.setKey((java.lang.Comparable)1.0d);
//     var18.setDrawAsLine(true);
//     org.jfree.chart.event.MarkerChangeEvent var23 = null;
//     var18.notifyListeners(var23);
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     var25.setMaximumCategoryLabelLines((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var32 = null;
//     var30.setSeriesItemLabelFont(1, var32);
//     double var34 = var30.getItemMargin();
//     boolean var36 = var30.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var39 = var30.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var44 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var41.setRangeWithMargins((org.jfree.data.Range)var44, false, true);
//     org.jfree.data.Range var48 = var41.getDefaultAutoRange();
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.axis.AxisState var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     org.jfree.chart.util.RectangleEdge var52 = null;
//     java.util.List var53 = var41.refreshTicks(var49, var50, var51, var52);
//     java.awt.Font var54 = var41.getLabelFont();
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.PiePlot3D var57 = new org.jfree.chart.plot.PiePlot3D(var56);
//     org.jfree.chart.JFreeChart var58 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var57);
//     var57.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var61 = var57.getURLGenerator();
//     java.awt.Shape var62 = var57.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var63 = null;
//     var57.setLabelGenerator(var63);
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.PiePlot3D var67 = new org.jfree.chart.plot.PiePlot3D(var66);
//     org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var67);
//     int var69 = var68.getBackgroundImageAlignment();
//     var57.addChangeListener((org.jfree.chart.event.PlotChangeListener)var68);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var72 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var74 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var72.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var74);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var76 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var78 = null;
//     var76.setSeriesItemLabelFont(1, var78);
//     boolean var80 = var76.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var83 = var76.getItemOutlinePaint(13, 100);
//     var72.setBaseItemLabelPaint(var83);
//     var57.setSectionPaint((java.lang.Comparable)(short)100, var83);
//     org.jfree.chart.block.LabelBlock var86 = new org.jfree.chart.block.LabelBlock("Default Group", var54, var83);
//     java.awt.geom.Rectangle2D var87 = var86.getBounds();
//     var30.setBaseShape((java.awt.Shape)var87, false);
//     org.jfree.chart.util.RectangleEdge var90 = null;
//     double var91 = var25.getCategoryMiddle(13, 13, var87, var90);
//     var0.drawDomainMarker(var12, var13, var14, var18, var87);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
    var1.setAutoTickUnitSelection(true);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
//     java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var14.setRangeWithMargins((org.jfree.data.Range)var17, false, true);
//     org.jfree.data.Range var21 = var14.getDefaultAutoRange();
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.AxisState var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     java.util.List var26 = var14.refreshTicks(var22, var23, var24, var25);
//     java.awt.Font var27 = var14.getLabelFont();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D(var29);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var30);
//     var30.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var34 = var30.getURLGenerator();
//     java.awt.Shape var35 = var30.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var36 = null;
//     var30.setLabelGenerator(var36);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D(var39);
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var40);
//     int var42 = var41.getBackgroundImageAlignment();
//     var30.addChangeListener((org.jfree.chart.event.PlotChangeListener)var41);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var45 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var47 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var45.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var47);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var51 = null;
//     var49.setSeriesItemLabelFont(1, var51);
//     boolean var53 = var49.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var56 = var49.getItemOutlinePaint(13, 100);
//     var45.setBaseItemLabelPaint(var56);
//     var30.setSectionPaint((java.lang.Comparable)(short)100, var56);
//     org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("Default Group", var27, var56);
//     org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var27);
//     var0.setSeriesItemLabelFont(10, var27);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var49 and var0.", var49.equals(var0) == var0.equals(var49));
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var17.axisChanged(var22);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var27.setRangeWithMargins((org.jfree.data.Range)var30, false, true);
//     org.jfree.data.Range var34 = var27.getDefaultAutoRange();
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.axis.AxisState var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     java.util.List var39 = var27.refreshTicks(var35, var36, var37, var38);
//     java.awt.Font var40 = var27.getLabelFont();
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot3D var43 = new org.jfree.chart.plot.PiePlot3D(var42);
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var43);
//     var43.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var47 = var43.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var48 = null;
//     var43.axisChanged(var48);
//     org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var40, (org.jfree.chart.plot.Plot)var43, false);
//     var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var51);
//     
//     // Checks the contract:  equals-hashcode on var17 and var43
//     assertTrue("Contract failed: equals-hashcode on var17 and var43", var17.equals(var43) ? var17.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var17
//     assertTrue("Contract failed: equals-hashcode on var43 and var17", var43.equals(var17) ? var43.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var44
//     assertTrue("Contract failed: equals-hashcode on var18 and var44", var18.equals(var44) ? var18.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var51
//     assertTrue("Contract failed: equals-hashcode on var25 and var51", var25.equals(var51) ? var25.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var18
//     assertTrue("Contract failed: equals-hashcode on var44 and var18", var44.equals(var18) ? var44.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var25
//     assertTrue("Contract failed: equals-hashcode on var51 and var25", var51.equals(var25) ? var51.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.awt.Color var1 = java.awt.Color.getColor("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var3 = var2.getAlpha();
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelTextAnchor(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.8f);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var4 = null;
    var0.setSeriesFillPaint(1, var4, false);
    var0.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.plot.CategoryPlot var10 = var0.getPlot();
    boolean var11 = var0.getBaseSeriesVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-435), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-435), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D(100.0d, var3, var4);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var17.axisChanged(var22);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
    var25.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var28 = var25.getTitle();
    org.jfree.chart.renderer.category.IntervalBarRenderer var29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var30 = var29.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var31 = var29.getBaseItemLabelGenerator();
    java.awt.Paint var33 = null;
    var29.setSeriesFillPaint(1, var33, false);
    var29.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var40 = var29.getSeriesPositiveItemLabelPosition(100);
    var29.setBaseItemLabelsVisible(true, false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var46 = null;
    var44.setSeriesItemLabelFont(1, var46);
    double var48 = var44.getItemMargin();
    boolean var50 = var44.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var51 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var52 = null;
    var51.rendererChanged(var52);
    var44.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var51);
    var29.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.setTextAntiAlias((java.lang.Object)var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    int var1 = var0.getPassCount();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var3 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var7.lookupSeriesShape((-1));
    var6.setUpArrow(var9);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var12.setRangeWithMargins((org.jfree.data.Range)var15, false, true);
    org.jfree.data.Range var19 = var12.getDefaultAutoRange();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.axis.AxisState var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    java.util.List var24 = var12.refreshTicks(var20, var21, var22, var23);
    java.awt.Font var25 = var12.getLabelFont();
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var28);
    var28.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var32 = var28.getURLGenerator();
    java.awt.Shape var33 = var28.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var34 = null;
    var28.setLabelGenerator(var34);
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.PiePlot3D var38 = new org.jfree.chart.plot.PiePlot3D(var37);
    org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var38);
    int var40 = var39.getBackgroundImageAlignment();
    var28.addChangeListener((org.jfree.chart.event.PlotChangeListener)var39);
    org.jfree.chart.renderer.category.IntervalBarRenderer var43 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var45 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var43.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var45);
    org.jfree.chart.renderer.category.IntervalBarRenderer var47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var49 = null;
    var47.setSeriesItemLabelFont(1, var49);
    boolean var51 = var47.getBaseSeriesVisibleInLegend();
    java.awt.Paint var54 = var47.getItemOutlinePaint(13, 100);
    var43.setBaseItemLabelPaint(var54);
    var28.setSectionPaint((java.lang.Comparable)(short)100, var54);
    org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("Default Group", var25, var54);
    java.awt.geom.Rectangle2D var58 = var57.getBounds();
    boolean var59 = org.jfree.chart.util.ShapeUtilities.equal(var9, (java.awt.Shape)var58);
    java.awt.geom.Point2D var60 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-7.0d), 0.0d, var58);
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis();
    double var63 = var62.getCategoryMargin();
    java.awt.Paint var64 = var62.getTickMarkPaint();
    org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis();
    boolean var66 = var65.isAxisLineVisible();
    java.awt.Font var67 = var65.getLabelFont();
    org.jfree.data.gantt.TaskSeriesCollection var68 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var2, var3, var58, var61, var62, (org.jfree.chart.axis.ValueAxis)var65, (org.jfree.data.category.CategoryDataset)var68, 0, 0, (-435));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    org.jfree.chart.entity.EntityCollection var20 = null;
    org.jfree.chart.ChartRenderingInfo var21 = new org.jfree.chart.ChartRenderingInfo(var20);
    java.awt.geom.Rectangle2D var22 = var21.getChartArea();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var23 = var13.createBufferedImage(100, (-435), 0.0d, 0.0d, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     var0.handleClick(0, (-1), var3);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var1, var2);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Paint var3 = var1.lookupSeriesOutlinePaint(255);
    java.awt.Paint var6 = var1.getItemLabelPaint(10, 255);
    org.jfree.chart.renderer.AreaRendererEndType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setEndType(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    var2.setShadowYOffset(1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setInteriorGap(100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)8.0d, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]", var2, var3, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelOffset();
//     double var5 = var3.trimWidth((-1.0d));
//     org.jfree.chart.entity.EntityCollection var6 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo(var6);
//     java.awt.geom.Rectangle2D var8 = var7.getChartArea();
//     org.jfree.chart.plot.CategoryMarker var10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     org.jfree.chart.util.LengthAdjustmentType var11 = var10.getLabelOffsetType();
//     java.lang.Object var12 = null;
//     boolean var13 = var11.equals(var12);
//     org.jfree.chart.plot.CategoryMarker var15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     org.jfree.chart.util.LengthAdjustmentType var16 = var15.getLabelOffsetType();
//     java.awt.geom.Rectangle2D var17 = var3.createAdjustedRectangle(var8, var11, var16);
//     
//     // Checks the contract:  equals-hashcode on var10 and var15
//     assertTrue("Contract failed: equals-hashcode on var10 and var15", var10.equals(var15) ? var10.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var10
//     assertTrue("Contract failed: equals-hashcode on var15 and var10", var15.equals(var10) ? var15.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var2 = var1.getWidthRatio();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.95f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
    org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var10 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var11 = null;
    var10.addChangeListener(var11);
    var9.setDataset((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.data.general.PieDataset var15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var10, (java.lang.Comparable)'4');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var17 = var6.generateLabel((org.jfree.data.category.CategoryDataset)var10, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var2.setRangeWithMargins((org.jfree.data.Range)var5, false, true);
    org.jfree.data.Range var9 = var2.getDefaultAutoRange();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.AxisState var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleEdge var13 = null;
    java.util.List var14 = var2.refreshTicks(var10, var11, var12, var13);
    org.jfree.chart.plot.Plot var15 = var2.getPlot();
    boolean var16 = var0.equals((java.lang.Object)var2);
    float var17 = var2.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0f);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]", var1, 0.8f, 0.8f, var4, 100.0d, var6);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var1 = var0.clone();
    java.lang.Boolean var3 = var0.getSeriesLinesVisible(0);
    boolean var6 = var0.getItemShapeFilled(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.util.List var1 = var0.getColumnKeys();
    var0.add(Double.NaN, (-1.05d), (java.lang.Comparable)1, (java.lang.Comparable)1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Stroke var3 = var1.getSeriesOutlineStroke(0);
    org.jfree.chart.LegendItem var6 = var1.getLegendItem((-457), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("org.jfree.data.time.TimePeriodFormatException: Default Group");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var17.axisChanged(var22);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
//     var25.setBackgroundImageAlignment(10);
//     boolean var28 = var25.isNotify();
//     org.jfree.chart.event.TitleChangeEvent var29 = null;
//     var25.titleChanged(var29);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     var0.peg(var1);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var1 = null;
//     var0.rendererChanged(var1);
//     org.jfree.chart.LegendItemCollection var3 = var0.getLegendItems();
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    double var20 = var16.getItemMargin();
    boolean var22 = var16.isSeriesVisibleInLegend(1);
    java.lang.Boolean var24 = var16.getSeriesCreateEntities(1);
    var16.setBaseItemLabelsVisible(true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setTextAntiAlias((java.lang.Object)var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.lang.Object var2 = var1.clone();
//     var1.setDrawOutlines(true);
//     org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var9 = var8.getAlpha();
//     java.awt.Paint var10 = var8.getPaint();
//     java.awt.Font var11 = var8.getLabelFont();
//     var1.setSeriesItemLabelFont(100, var11, false);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D(var15);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var16);
//     var16.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var20 = var16.getURLGenerator();
//     java.awt.Shape var21 = var16.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var22 = null;
//     var16.setLabelGenerator(var22);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D(var25);
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var26);
//     int var28 = var27.getBackgroundImageAlignment();
//     var16.addChangeListener((org.jfree.chart.event.PlotChangeListener)var27);
//     int var30 = var16.getPieIndex();
//     java.awt.Paint var31 = var16.getBaseSectionPaint();
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("black", var11, var31, 10.0f, 100, var34);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var3 = var2.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getBaseItemLabelGenerator();
    java.awt.Paint var6 = null;
    var2.setSeriesFillPaint(1, var6, false);
    var2.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var2.getLegendItemLabelGenerator();
    double var13 = var2.getBase();
    boolean var14 = var1.equals((java.lang.Object)var2);
    java.lang.Object var15 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.util.Size2D var17 = var15.arrange(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var15.getLegendItemGraphicPadding();
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var22 = var20.lookupSeriesShape((-1));
//     var19.setUpArrow(var22);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var28 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var25.setRangeWithMargins((org.jfree.data.Range)var28, false, true);
//     org.jfree.data.Range var32 = var25.getDefaultAutoRange();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.axis.AxisState var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     java.util.List var37 = var25.refreshTicks(var33, var34, var35, var36);
//     java.awt.Font var38 = var25.getLabelFont();
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot3D var41 = new org.jfree.chart.plot.PiePlot3D(var40);
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var41);
//     var41.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var45 = var41.getURLGenerator();
//     java.awt.Shape var46 = var41.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var47 = null;
//     var41.setLabelGenerator(var47);
//     org.jfree.data.general.PieDataset var50 = null;
//     org.jfree.chart.plot.PiePlot3D var51 = new org.jfree.chart.plot.PiePlot3D(var50);
//     org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var51);
//     int var53 = var52.getBackgroundImageAlignment();
//     var41.addChangeListener((org.jfree.chart.event.PlotChangeListener)var52);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var56 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var58 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var56.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var58);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var62 = null;
//     var60.setSeriesItemLabelFont(1, var62);
//     boolean var64 = var60.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var67 = var60.getItemOutlinePaint(13, 100);
//     var56.setBaseItemLabelPaint(var67);
//     var41.setSectionPaint((java.lang.Comparable)(short)100, var67);
//     org.jfree.chart.block.LabelBlock var70 = new org.jfree.chart.block.LabelBlock("Default Group", var38, var67);
//     java.awt.geom.Rectangle2D var71 = var70.getBounds();
//     boolean var72 = org.jfree.chart.util.ShapeUtilities.equal(var22, (java.awt.Shape)var71);
//     java.awt.geom.Rectangle2D var75 = var18.createInsetRectangle(var71, true, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var20 and var3.", var20.equals(var3) == var3.equals(var20));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var60 and var3.", var60.equals(var3) == var3.equals(var60));
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var1 = var0.clone();
    var0.setDrawOutlines(true);
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var8 = var7.getAlpha();
    java.awt.Paint var9 = var7.getPaint();
    java.awt.Font var10 = var7.getLabelFont();
    var0.setSeriesItemLabelFont(100, var10, false);
    int var13 = var0.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var3 = null;
//     var1.setSeriesItemLabelFont(1, var3);
//     double var5 = var1.getItemMargin();
//     boolean var7 = var1.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var9 = var1.getSeriesCreateEntities(1);
//     java.awt.Paint var11 = var1.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var14 = null;
//     var12.setSeriesItemLabelFont(1, var14);
//     boolean var16 = var12.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var19 = var12.getItemOutlinePaint(13, 100);
//     var1.setBaseFillPaint(var19, true);
//     var0.setBaseOutlinePaint(var19, false);
//     var0.setSeriesVisibleInLegend(1, (java.lang.Boolean)true, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("black", "", "org.jfree.chart.event.ChartChangeEvent[source=true]", "Nearest");

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    java.text.DateFormat var1 = var0.getDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    double var3 = var0.getUpperClip();
    var0.setSeriesItemLabelsVisible(13, (java.lang.Boolean)true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    boolean var16 = var0.isSeriesItemLabelsVisible(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var0.setSeriesItemLabelGenerator(4, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    var0.clear();

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.data.time.TimePeriodFormatException: Default Group", "org.jfree.data.time.TimePeriodFormatException: Default Group", var3);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var5 = null;
//     var3.setSeriesItemLabelFont(1, var5);
//     boolean var7 = var3.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7);
//     boolean var9 = var0.equals((java.lang.Object)var7);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     int var17 = var12.compareTo((java.lang.Object)var15);
//     var0.addValue(3.0d, (java.lang.Comparable)(short)0, (java.lang.Comparable)var12);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     org.jfree.chart.util.Size2D var24 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
//     java.lang.Object var25 = var24.clone();
//     int var26 = var21.compareTo((java.lang.Object)var24);
//     var0.setValue((-1.0d), (java.lang.Comparable)100.0f, (java.lang.Comparable)var26);
//     
//     // Checks the contract:  equals-hashcode on var15 and var24
//     assertTrue("Contract failed: equals-hashcode on var15 and var24", var15.equals(var24) ? var15.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var15
//     assertTrue("Contract failed: equals-hashcode on var24 and var15", var24.equals(var15) ? var24.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var25
//     assertTrue("Contract failed: equals-hashcode on var16 and var25", var16.equals(var25) ? var16.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var16
//     assertTrue("Contract failed: equals-hashcode on var25 and var16", var25.equals(var16) ? var25.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.statistics.BoxAndWhiskerItem var1 = null;
//     var0.add(var1, (java.lang.Comparable)'#', (java.lang.Comparable)(-1.05d));
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var2 = var0.getRowIndex((java.lang.Comparable)(-7.0d));
//     double var4 = var0.getRangeUpperBound(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var7 = var0.getMeanValue((-435), 0);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)100.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var5 = null;
    var3.setSeriesItemLabelFont(1, var5);
    double var7 = var3.getItemMargin();
    boolean var9 = var3.isSeriesVisibleInLegend(1);
    java.lang.Boolean var11 = var3.getSeriesCreateEntities(1);
    java.awt.Paint var13 = var3.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var16 = null;
    var14.setSeriesItemLabelFont(1, var16);
    boolean var18 = var14.getBaseSeriesVisibleInLegend();
    java.awt.Paint var21 = var14.getItemOutlinePaint(13, 100);
    var3.setBaseFillPaint(var21, true);
    var3.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var3.getBaseNegativeItemLabelPosition();
    boolean var28 = var2.equals((java.lang.Object)var27);
    org.jfree.data.DefaultKeyedValues2D var29 = new org.jfree.data.DefaultKeyedValues2D();
    boolean var30 = var2.equals((java.lang.Object)var29);
    org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
    java.util.Date var32 = var31.getEnd();
    org.jfree.data.time.RegularTimePeriod var33 = var31.previous();
    int var34 = var29.getColumnIndex((java.lang.Comparable)var31);
    java.lang.Number var36 = var0.getQ3Value((java.lang.Comparable)var31, (java.lang.Comparable)"Nearest");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var39 = var0.getValue(255, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    java.awt.Paint var18 = var15.getItemPaint();
    org.jfree.chart.util.HorizontalAlignment var19 = var15.getHorizontalAlignment();
    java.lang.Object var20 = null;
    boolean var21 = var19.equals(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.event.ChartProgressListener var4 = null;
//     var3.addProgressListener(var4);
//     org.jfree.chart.event.PlotChangeEvent var6 = null;
//     var3.plotChanged(var6);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var4 = null;
    var0.setSeriesFillPaint(1, var4, false);
    var0.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = var0.getLegendItemLabelGenerator();
    boolean var13 = var0.getItemCreateEntity(15, (-435));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var3 = var2.getLowerDate();
    org.jfree.data.Range var6 = org.jfree.data.Range.shift((org.jfree.data.Range)var2, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, 1.0d);
    org.jfree.chart.util.Size2D var11 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    org.jfree.chart.util.Size2D var12 = var8.calculateConstrainedSize(var11);
    org.jfree.data.Range var13 = var8.getWidthRange();
    double var14 = var8.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var7 = null;
//     var5.setSeriesItemLabelFont(1, var7);
//     double var9 = var5.getItemMargin();
//     boolean var11 = var5.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var14 = var5.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.text.TextAnchor var15 = var14.getRotationAnchor();
//     var1.draw(var2, 0.0f, 2.0f, var15, 0.95f, (-1.0f), 8.0d);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var17.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var19);
    org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var23 = null;
    var21.setSeriesItemLabelFont(1, var23);
    boolean var25 = var21.getBaseSeriesVisibleInLegend();
    java.awt.Paint var28 = var21.getItemOutlinePaint(13, 100);
    var17.setBaseItemLabelPaint(var28);
    var2.setSectionPaint((java.lang.Comparable)(short)100, var28);
    var2.setLabelLinksVisible(true);
    java.awt.Color var34 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var35 = var34.getTransparency();
    int var36 = var34.getAlpha();
    int var37 = var34.getAlpha();
    var2.setBaseSectionOutlinePaint((java.awt.Paint)var34);
    var2.setDepthFactor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 255);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    double var8 = var7.getCategoryMargin();
    var7.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var12 = var7.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    org.jfree.data.general.SeriesChangeEvent var13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var7);
    var0.seriesChanged(var13);
    java.lang.Object var15 = var13.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    boolean var1 = var0.isAxisLineVisible();
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    boolean var6 = var2.getBaseSeriesVisibleInLegend();
    java.awt.Paint var9 = var2.getItemOutlinePaint(13, 100);
    java.awt.Shape var12 = var2.getItemShape((-1), 1);
    org.jfree.chart.entity.AxisLabelEntity var15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var12, "hi!", "Default Group");
    java.lang.String var16 = var15.getToolTipText();
    java.awt.Shape var17 = var15.getArea();
    java.awt.Shape var18 = var15.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var1.addChangeListener(var2);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.remove(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.data.general.Dataset var10 = var9.getDataset();
//     org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var12 = var11.getDataExtractOrder();
//     boolean var13 = var9.equals((java.lang.Object)var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.block.RectangleConstraint var15 = null;
//     org.jfree.chart.util.Size2D var16 = var9.arrange(var14, var15);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var17.axisChanged(var22);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
    var25.setBackgroundImageAlignment(10);
    boolean var28 = var25.isNotify();
    org.jfree.chart.entity.EntityCollection var31 = null;
    org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo(var31);
    java.awt.geom.Rectangle2D var33 = var32.getChartArea();
    org.jfree.data.time.TimePeriodFormatException var35 = new org.jfree.data.time.TimePeriodFormatException("Default Group");
    boolean var36 = var32.equals((java.lang.Object)"Default Group");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var37 = var25.createBufferedImage(0, 2, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 10.0d, 1.0f, 10.0f);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getMaxOutlier((-1), 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    java.awt.Color var1 = java.awt.Color.getColor("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    java.util.List var7 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var0.getSubIntervalCount(15, (-457));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.lengthToJava2D(100.0d, var3, var4);
    double var6 = var1.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("Default Group");
    org.jfree.data.gantt.TaskSeriesCollection var2 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var3 = null;
    var2.addChangeListener(var3);
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var2, (-435));
    var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var2);
    var1.setDescription("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var17.axisChanged(var22);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
//     var25.setBackgroundImageAlignment(10);
//     org.jfree.chart.plot.Plot var28 = var25.getPlot();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var31 = var29.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var33 = var32.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var34 = var32.getBaseItemLabelGenerator();
//     java.awt.Paint var36 = null;
//     var32.setSeriesFillPaint(1, var36, false);
//     var32.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var42 = var32.getLegendItemLabelGenerator();
//     var29.setLegendItemToolTipGenerator(var42);
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
//     double var45 = var44.getHeight();
//     var25.addSubtitle((org.jfree.chart.title.Title)var44);
//     org.jfree.chart.axis.AxisState var47 = new org.jfree.chart.axis.AxisState();
//     var47.cursorLeft(10.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var51 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var53 = var51.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var54 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var55 = var54.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var56 = var54.getBaseItemLabelGenerator();
//     java.awt.Paint var58 = null;
//     var54.setSeriesFillPaint(1, var58, false);
//     var54.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var64 = var54.getLegendItemLabelGenerator();
//     var51.setLegendItemToolTipGenerator(var64);
//     org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
//     java.awt.Graphics2D var67 = null;
//     org.jfree.chart.util.Size2D var68 = var66.arrange(var67);
//     org.jfree.chart.util.RectangleEdge var69 = var66.getPosition();
//     var47.moveCursor((-7.0d), var69);
//     var44.setLegendItemGraphicEdge(var69);
//     
//     // Checks the contract:  equals-hashcode on var42 and var64
//     assertTrue("Contract failed: equals-hashcode on var42 and var64", var42.equals(var64) ? var42.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var42
//     assertTrue("Contract failed: equals-hashcode on var64 and var42", var64.equals(var42) ? var64.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(13, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    java.awt.Color var3 = java.awt.Color.getColor("SerialDate.weekInMonthToString(): invalid code.", 13);
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var7 = null;
    var5.setSeriesItemLabelFont(1, var7);
    double var9 = var5.getItemMargin();
    boolean var11 = var5.isSeriesVisibleInLegend(1);
    java.lang.Boolean var13 = var5.getSeriesCreateEntities(1);
    java.awt.Paint var15 = var5.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    boolean var20 = var16.getBaseSeriesVisibleInLegend();
    java.awt.Paint var23 = var16.getItemOutlinePaint(13, 100);
    var5.setBaseFillPaint(var23, true);
    org.jfree.chart.urls.StandardCategoryURLGenerator var29 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "", "");
    var5.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var29, false);
    java.awt.Stroke var32 = var5.getBaseOutlineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var34 = var33.clone();
    org.jfree.chart.urls.StandardCategoryURLGenerator var38 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "org.jfree.chart.event.ChartChangeEvent[source=true]", "");
    org.jfree.chart.renderer.category.IntervalBarRenderer var39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var41 = var39.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var42 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var43 = var42.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var44 = var42.getBaseItemLabelGenerator();
    java.awt.Paint var46 = null;
    var42.setSeriesFillPaint(1, var46, false);
    var42.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var52 = var42.getLegendItemLabelGenerator();
    var39.setLegendItemToolTipGenerator(var52);
    org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
    java.lang.Object var55 = null;
    boolean var56 = var54.equals(var55);
    java.awt.Paint var57 = var54.getItemPaint();
    boolean var58 = var38.equals((java.lang.Object)var57);
    var33.setBasePaint(var57, true);
    org.jfree.data.general.PieDataset var62 = null;
    org.jfree.chart.plot.PiePlot3D var63 = new org.jfree.chart.plot.PiePlot3D(var62);
    org.jfree.chart.JFreeChart var64 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var63);
    var63.setShadowYOffset(0.0d);
    var63.setShadowYOffset(1.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var69 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var70 = var69.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var71 = var69.getBaseItemLabelGenerator();
    double var72 = var69.getBase();
    java.awt.Stroke var73 = var69.getBaseOutlineStroke();
    var63.setOutlineStroke(var73);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var3, var32, var57, var73, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var6 = null;
//     var5.addChangeListener(var6);
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var15 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var16 = null;
//     var15.addChangeListener(var16);
//     org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var14, (org.jfree.data.general.Dataset)var15, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     boolean var20 = var19.isEmpty();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.FlowArrangement var26 = new org.jfree.chart.block.FlowArrangement(var22, var23, 100.0d, 0.0d);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var32 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var33 = null;
//     var32.addChangeListener(var33);
//     org.jfree.chart.title.LegendItemBlockContainer var36 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var31, (org.jfree.data.general.Dataset)var32, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     boolean var37 = var36.isEmpty();
//     java.util.List var38 = var36.getBlocks();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.data.time.DateRange var42 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     java.util.Date var43 = var42.getLowerDate();
//     org.jfree.data.Range var46 = org.jfree.data.Range.shift((org.jfree.data.Range)var42, 0.0d, false);
//     org.jfree.chart.block.RectangleConstraint var48 = new org.jfree.chart.block.RectangleConstraint(var46, 1.0d);
//     org.jfree.chart.util.Size2D var49 = var26.arrange((org.jfree.chart.block.BlockContainer)var36, var39, var48);
//     org.jfree.chart.util.Size2D var50 = var4.arrange((org.jfree.chart.block.BlockContainer)var19, var21, var48);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var31
//     assertTrue("Contract failed: equals-hashcode on var4 and var31", var4.equals(var31) ? var4.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var31
//     assertTrue("Contract failed: equals-hashcode on var14 and var31", var14.equals(var31) ? var14.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var4
//     assertTrue("Contract failed: equals-hashcode on var31 and var4", var31.equals(var4) ? var31.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var14
//     assertTrue("Contract failed: equals-hashcode on var31 and var14", var31.equals(var14) ? var31.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var32
//     assertTrue("Contract failed: equals-hashcode on var5 and var32", var5.equals(var32) ? var5.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var32
//     assertTrue("Contract failed: equals-hashcode on var15 and var32", var15.equals(var32) ? var15.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var5
//     assertTrue("Contract failed: equals-hashcode on var32 and var5", var32.equals(var5) ? var32.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var15
//     assertTrue("Contract failed: equals-hashcode on var32 and var15", var32.equals(var15) ? var32.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var19
//     assertTrue("Contract failed: equals-hashcode on var9 and var19", var9.equals(var19) ? var9.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var36
//     assertTrue("Contract failed: equals-hashcode on var9 and var36", var9.equals(var36) ? var9.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var9
//     assertTrue("Contract failed: equals-hashcode on var19 and var9", var19.equals(var9) ? var19.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var36
//     assertTrue("Contract failed: equals-hashcode on var19 and var36", var19.equals(var36) ? var19.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var9
//     assertTrue("Contract failed: equals-hashcode on var36 and var9", var36.equals(var9) ? var36.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var19
//     assertTrue("Contract failed: equals-hashcode on var36 and var19", var36.equals(var19) ? var36.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var4 = null;
//     var2.setSeriesItemLabelFont(1, var4);
//     double var6 = var2.getItemMargin();
//     boolean var8 = var2.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var2.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var13.setRangeWithMargins((org.jfree.data.Range)var16, false, true);
//     org.jfree.data.Range var20 = var13.getDefaultAutoRange();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.AxisState var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     java.util.List var25 = var13.refreshTicks(var21, var22, var23, var24);
//     java.awt.Font var26 = var13.getLabelFont();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
//     var29.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var33 = var29.getURLGenerator();
//     java.awt.Shape var34 = var29.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var35 = null;
//     var29.setLabelGenerator(var35);
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
//     int var41 = var40.getBackgroundImageAlignment();
//     var29.addChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var46 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var44.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var46);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var50 = null;
//     var48.setSeriesItemLabelFont(1, var50);
//     boolean var52 = var48.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var55 = var48.getItemOutlinePaint(13, 100);
//     var44.setBaseItemLabelPaint(var55);
//     var29.setSectionPaint((java.lang.Comparable)(short)100, var55);
//     org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("Default Group", var26, var55);
//     java.awt.geom.Rectangle2D var59 = var58.getBounds();
//     var2.setBaseShape((java.awt.Shape)var59, false);
//     org.jfree.chart.plot.PlotRenderingInfo var63 = null;
//     boolean var64 = var0.render(var1, var59, (-457), var63);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var65 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var67 = var65.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var68 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var69 = var68.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var70 = var68.getBaseItemLabelGenerator();
//     java.awt.Paint var72 = null;
//     var68.setSeriesFillPaint(1, var72, false);
//     var68.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var78 = var68.getLegendItemLabelGenerator();
//     var65.setLegendItemToolTipGenerator(var78);
//     org.jfree.chart.title.LegendTitle var80 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var65);
//     java.awt.Graphics2D var81 = null;
//     org.jfree.chart.util.Size2D var82 = var80.arrange(var81);
//     org.jfree.chart.util.RectangleInsets var83 = var80.getLegendItemGraphicPadding();
//     boolean var84 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var80);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var48 and var68.", var48.equals(var68) == var68.equals(var48));
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getCategoryMargin();
    var0.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var5 = var0.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    int var6 = var0.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
//     long var4 = var3.getSegmentsExcludedSize();
//     int var5 = var3.getSegmentsIncluded();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var8 = var7.getUpArrow();
//     java.awt.Shape var9 = var7.getDownArrow();
//     java.util.Date var10 = var7.getMinimumDate();
//     var3.addBaseTimelineException(var10);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var1 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var1);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setSeriesToolTipGenerator(1, var5);
    var0.setItemLabelAnchorOffset(0.0d);
    boolean var9 = var0.getBaseItemLabelsVisible();
    java.awt.Stroke var11 = var0.lookupSeriesOutlineStroke(255);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var13 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var0.setSeriesToolTipGenerator(13, (org.jfree.chart.labels.CategoryToolTipGenerator)var13);
    java.lang.String var15 = var13.getLabelFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "({0}, {1}) = {3} - {4}"+ "'", var15.equals("({0}, {1}) = {3} - {4}"));

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var1.setKey((java.lang.Comparable)false);
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setKey(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var3.setRangeWithMargins((org.jfree.data.Range)var6, false, true);
//     org.jfree.data.Range var10 = var3.getDefaultAutoRange();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.AxisState var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     java.util.List var15 = var3.refreshTicks(var11, var12, var13, var14);
//     java.awt.Font var16 = var3.getLabelFont();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
//     var19.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
//     java.awt.Shape var24 = var19.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var25 = null;
//     var19.setLabelGenerator(var25);
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
//     int var31 = var30.getBackgroundImageAlignment();
//     var19.addChangeListener((org.jfree.chart.event.PlotChangeListener)var30);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var36 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var34.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var36);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var40 = null;
//     var38.setSeriesItemLabelFont(1, var40);
//     boolean var42 = var38.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var45 = var38.getItemOutlinePaint(13, 100);
//     var34.setBaseItemLabelPaint(var45);
//     var19.setSectionPaint((java.lang.Comparable)(short)100, var45);
//     org.jfree.chart.block.LabelBlock var48 = new org.jfree.chart.block.LabelBlock("Default Group", var16, var45);
//     java.awt.geom.Rectangle2D var49 = var48.getBounds();
//     org.jfree.chart.util.RectangleInsets var50 = var48.getPadding();
//     var1.setInsets(var50);
//     org.jfree.data.general.PieDataset var53 = null;
//     org.jfree.chart.plot.PiePlot3D var54 = new org.jfree.chart.plot.PiePlot3D(var53);
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var54);
//     var54.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var58 = var54.getURLGenerator();
//     java.awt.Shape var59 = var54.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var60 = null;
//     var54.setLabelGenerator(var60);
//     org.jfree.data.general.PieDataset var63 = null;
//     org.jfree.chart.plot.PiePlot3D var64 = new org.jfree.chart.plot.PiePlot3D(var63);
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var64);
//     int var66 = var65.getBackgroundImageAlignment();
//     var54.addChangeListener((org.jfree.chart.event.PlotChangeListener)var65);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var69 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var71 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var69.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var71);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var73 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var75 = null;
//     var73.setSeriesItemLabelFont(1, var75);
//     boolean var77 = var73.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var80 = var73.getItemOutlinePaint(13, 100);
//     var69.setBaseItemLabelPaint(var80);
//     var54.setSectionPaint((java.lang.Comparable)(short)100, var80);
//     var54.setLabelLinksVisible(true);
//     java.awt.Color var86 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var87 = var86.getTransparency();
//     int var88 = var86.getAlpha();
//     int var89 = var86.getAlpha();
//     var54.setBaseSectionOutlinePaint((java.awt.Paint)var86);
//     var1.setNoDataMessagePaint((java.awt.Paint)var86);
//     
//     // Checks the contract:  equals-hashcode on var29 and var64
//     assertTrue("Contract failed: equals-hashcode on var29 and var64", var29.equals(var64) ? var29.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var29
//     assertTrue("Contract failed: equals-hashcode on var64 and var29", var64.equals(var29) ? var64.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var65
//     assertTrue("Contract failed: equals-hashcode on var30 and var65", var30.equals(var65) ? var30.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var30
//     assertTrue("Contract failed: equals-hashcode on var65 and var30", var65.equals(var30) ? var65.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var71
//     assertTrue("Contract failed: equals-hashcode on var36 and var71", var36.equals(var71) ? var36.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var36
//     assertTrue("Contract failed: equals-hashcode on var71 and var36", var71.equals(var36) ? var71.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D(var3);
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var4);
//     var4.setShadowYOffset(0.0d);
//     org.jfree.chart.plot.Plot var8 = var4.getRootPlot();
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var13 = var12.getUpArrow();
//     java.awt.Font var14 = var12.getLabelFont();
//     java.text.DateFormat var15 = var12.getDateFormatOverride();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var18);
//     var18.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var22 = var18.getURLGenerator();
//     java.awt.Shape var23 = var18.getLegendItemShape();
//     org.jfree.chart.util.Rotation var24 = var18.getDirection();
//     org.jfree.chart.util.RectangleInsets var25 = var18.getInsets();
//     var12.setLabelInsets(var25);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var31 = null;
//     var29.setSeriesItemLabelFont(1, var31);
//     double var33 = var29.getItemMargin();
//     boolean var35 = var29.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var38 = var29.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var43 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var40.setRangeWithMargins((org.jfree.data.Range)var43, false, true);
//     org.jfree.data.Range var47 = var40.getDefaultAutoRange();
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.axis.AxisState var49 = null;
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleEdge var51 = null;
//     java.util.List var52 = var40.refreshTicks(var48, var49, var50, var51);
//     java.awt.Font var53 = var40.getLabelFont();
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.PiePlot3D var56 = new org.jfree.chart.plot.PiePlot3D(var55);
//     org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var56);
//     var56.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var60 = var56.getURLGenerator();
//     java.awt.Shape var61 = var56.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var62 = null;
//     var56.setLabelGenerator(var62);
//     org.jfree.data.general.PieDataset var65 = null;
//     org.jfree.chart.plot.PiePlot3D var66 = new org.jfree.chart.plot.PiePlot3D(var65);
//     org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var66);
//     int var68 = var67.getBackgroundImageAlignment();
//     var56.addChangeListener((org.jfree.chart.event.PlotChangeListener)var67);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var71 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var73 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var71.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var73);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var75 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var77 = null;
//     var75.setSeriesItemLabelFont(1, var77);
//     boolean var79 = var75.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var82 = var75.getItemOutlinePaint(13, 100);
//     var71.setBaseItemLabelPaint(var82);
//     var56.setSectionPaint((java.lang.Comparable)(short)100, var82);
//     org.jfree.chart.block.LabelBlock var85 = new org.jfree.chart.block.LabelBlock("Default Group", var53, var82);
//     java.awt.geom.Rectangle2D var86 = var85.getBounds();
//     var29.setBaseShape((java.awt.Shape)var86, false);
//     org.jfree.chart.plot.PlotRenderingInfo var90 = null;
//     boolean var91 = var27.render(var28, var86, (-457), var90);
//     java.awt.geom.Rectangle2D var94 = var25.createOutsetRectangle(var86, true, false);
//     var0.draw(var10, var86);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
//     int var1 = var0.getRowCount();
//     org.jfree.data.category.DefaultCategoryDataset var3 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var5 = var3.getRowIndex((java.lang.Comparable)(-1.05d));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var8 = null;
//     var6.setSeriesItemLabelFont(1, var8);
//     boolean var10 = var6.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.event.ChartChangeEvent var11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10);
//     boolean var12 = var3.equals((java.lang.Object)var10);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     org.jfree.chart.util.Size2D var18 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
//     java.lang.Object var19 = var18.clone();
//     int var20 = var15.compareTo((java.lang.Object)var18);
//     var3.addValue(3.0d, (java.lang.Comparable)(short)0, (java.lang.Comparable)var15);
//     int var22 = var15.getMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var24 = var0.getStartValue((java.lang.Comparable)10L, (java.lang.Comparable)var22, 4);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 12);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-435));
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    java.lang.String var6 = var5.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Multiple Pie Plot"+ "'", var6.equals("Multiple Pie Plot"));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var0.setRangeWithMargins((org.jfree.data.Range)var3, false, true);
    org.jfree.data.Range var7 = var0.getDefaultAutoRange();
    var0.setAutoTickUnitSelection(false, false);
    java.text.DateFormat var11 = null;
    var0.setDateFormatOverride(var11);
    boolean var14 = var0.isHiddenValue(0L);
    java.awt.Paint var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisLinePaint(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = var0.getPieChart();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var4.setRangeWithMargins((org.jfree.data.Range)var7, false, true);
//     org.jfree.data.Range var11 = var4.getDefaultAutoRange();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.AxisState var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     java.util.List var16 = var4.refreshTicks(var12, var13, var14, var15);
//     java.awt.Font var17 = var4.getLabelFont();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D(var19);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var20);
//     var20.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var24 = var20.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var25 = null;
//     var20.axisChanged(var25);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var17, (org.jfree.chart.plot.Plot)var20, false);
//     var28.setBackgroundImageAlignment(10);
//     org.jfree.chart.title.TextTitle var31 = var28.getTitle();
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.entity.EntityCollection var33 = null;
//     org.jfree.chart.ChartRenderingInfo var34 = new org.jfree.chart.ChartRenderingInfo(var33);
//     java.awt.geom.Rectangle2D var35 = var34.getChartArea();
//     var31.draw(var32, var35);
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var40 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var42 = var40.lookupSeriesShape((-1));
//     var39.setUpArrow(var42);
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var48 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var45.setRangeWithMargins((org.jfree.data.Range)var48, false, true);
//     org.jfree.data.Range var52 = var45.getDefaultAutoRange();
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.axis.AxisState var54 = null;
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     java.util.List var57 = var45.refreshTicks(var53, var54, var55, var56);
//     java.awt.Font var58 = var45.getLabelFont();
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot3D var61 = new org.jfree.chart.plot.PiePlot3D(var60);
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var61);
//     var61.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var65 = var61.getURLGenerator();
//     java.awt.Shape var66 = var61.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var67 = null;
//     var61.setLabelGenerator(var67);
//     org.jfree.data.general.PieDataset var70 = null;
//     org.jfree.chart.plot.PiePlot3D var71 = new org.jfree.chart.plot.PiePlot3D(var70);
//     org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var71);
//     int var73 = var72.getBackgroundImageAlignment();
//     var61.addChangeListener((org.jfree.chart.event.PlotChangeListener)var72);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var76 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var78 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var76.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var78);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var80 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var82 = null;
//     var80.setSeriesItemLabelFont(1, var82);
//     boolean var84 = var80.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var87 = var80.getItemOutlinePaint(13, 100);
//     var76.setBaseItemLabelPaint(var87);
//     var61.setSectionPaint((java.lang.Comparable)(short)100, var87);
//     org.jfree.chart.block.LabelBlock var90 = new org.jfree.chart.block.LabelBlock("Default Group", var58, var87);
//     java.awt.geom.Rectangle2D var91 = var90.getBounds();
//     boolean var92 = org.jfree.chart.util.ShapeUtilities.equal(var42, (java.awt.Shape)var91);
//     java.awt.geom.Point2D var93 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-7.0d), 0.0d, var91);
//     org.jfree.chart.plot.PlotState var94 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var95 = null;
//     var0.draw(var2, var35, var93, var94, var95);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.DatasetRenderingOrder var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var1 = var0.getMaxIcon();
//     var0.setBaseSeriesVisibleInLegend(false);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var6 = var5.getFixedDomainAxisSpace();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var8.setRangeWithMargins((org.jfree.data.Range)var11, false, true);
//     org.jfree.data.Range var15 = var8.getDefaultAutoRange();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.AxisState var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     java.util.List var20 = var8.refreshTicks(var16, var17, var18, var19);
//     java.awt.Font var21 = var8.getLabelFont();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var24);
//     var24.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var28 = var24.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var29 = null;
//     var24.axisChanged(var29);
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var21, (org.jfree.chart.plot.Plot)var24, false);
//     var32.setBackgroundImageAlignment(10);
//     org.jfree.chart.title.TextTitle var35 = var32.getTitle();
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.entity.EntityCollection var37 = null;
//     org.jfree.chart.ChartRenderingInfo var38 = new org.jfree.chart.ChartRenderingInfo(var37);
//     java.awt.geom.Rectangle2D var39 = var38.getChartArea();
//     var35.draw(var36, var39);
//     var0.drawDomainGridline(var4, var5, var39, 1.0d);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelOffset();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.lang.Object var6 = var3.clone();
    java.lang.Object var7 = null;
    boolean var8 = var3.equals(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var3 = null;
    var0.setShape(15, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getMinRegularValue((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var4 = null;
    var2.setSeriesItemLabelFont(1, var4);
    double var6 = var2.getItemMargin();
    boolean var8 = var2.isSeriesVisibleInLegend(1);
    java.lang.Boolean var10 = var2.getSeriesCreateEntities(1);
    java.awt.Paint var12 = var2.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var15 = null;
    var13.setSeriesItemLabelFont(1, var15);
    boolean var17 = var13.getBaseSeriesVisibleInLegend();
    java.awt.Paint var20 = var13.getItemOutlinePaint(13, 100);
    var2.setBaseFillPaint(var20, true);
    org.jfree.chart.urls.StandardCategoryURLGenerator var26 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "", "");
    var2.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var26, false);
    java.awt.Stroke var29 = var2.getBaseOutlineStroke();
    java.awt.Font var31 = var2.getSeriesItemLabelFont(15);
    int var32 = var2.getPassCount();
    boolean var33 = var1.equals((java.lang.Object)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.lang.String var1 = var0.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.util.Size2D var17 = var15.arrange(var16);
    org.jfree.chart.util.RectangleInsets var18 = var15.getLegendItemGraphicPadding();
    org.jfree.chart.block.BlockFrame var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setFrame(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject((java.lang.Comparable)"");
    org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var6 = var5.getLowerDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var4 = null;
    var0.setSeriesFillPaint(1, var4, false);
    var0.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = var0.getLegendItemLabelGenerator();
    java.lang.Boolean var12 = var0.getSeriesItemLabelsVisible(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.ItemLabelPosition var2 = null;
    var0.setNegativeItemLabelPositionFallback(var2);
    java.awt.Paint var4 = var0.getBaseItemLabelPaint();
    org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var7 = var5.get((-435));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var1.addChangeListener(var2);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var8 = var7.getUpArrow();
    java.awt.Font var9 = var7.getLabelFont();
    java.text.DateFormat var10 = var7.getDateFormatOverride();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
    var13.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var17 = var13.getURLGenerator();
    java.awt.Shape var18 = var13.getLegendItemShape();
    org.jfree.chart.util.Rotation var19 = var13.getDirection();
    org.jfree.chart.util.RectangleInsets var20 = var13.getInsets();
    var7.setLabelInsets(var20);
    boolean var22 = var5.equals((java.lang.Object)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var24 = var1.getStartValue((java.lang.Comparable)var5, (java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    var2.setBackgroundImageAlignment(2);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    var2.handleClick(0, 2, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var6 = null;
//     var4.setSeriesItemLabelFont(1, var6);
//     double var8 = var4.getItemMargin();
//     boolean var10 = var4.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var4.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
//     org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     org.jfree.chart.text.TextAnchor var19 = var18.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst", var1, 0.95f, 0.95f, var14, (-1.05d), var19);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.plot.Plot var6 = var2.getRootPlot();
    var2.setMinimumArcAngleToDraw(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var1.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var1.getBaseItemLabelGenerator();
    java.awt.Paint var5 = null;
    var1.setSeriesFillPaint(1, var5, false);
    var1.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var12 = var1.getSeriesPositiveItemLabelPosition(100);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var14.setRangeWithMargins((org.jfree.data.Range)var17, false, true);
    org.jfree.data.Range var21 = var14.getDefaultAutoRange();
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.AxisState var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    java.util.List var26 = var14.refreshTicks(var22, var23, var24, var25);
    java.awt.Font var27 = var14.getLabelFont();
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D(var29);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var30);
    var30.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var34 = var30.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var35 = null;
    var30.axisChanged(var35);
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var27, (org.jfree.chart.plot.Plot)var30, false);
    boolean var39 = var12.equals((java.lang.Object)var27);
    java.awt.Color var41 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    float[] var45 = new float[] { 1.0f, 10.0f, (-1.0f)};
    float[] var46 = var41.getRGBColorComponents(var45);
    org.jfree.chart.text.TextMeasurer var49 = null;
    org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var27, (java.awt.Paint)var41, 0.0f, 10, var49);
    java.lang.String var51 = var41.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var51.equals("java.awt.Color[r=0,g=0,b=0]"));

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
//     org.jfree.data.Range var8 = var1.getDefaultAutoRange();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
//     java.awt.Font var14 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
//     var17.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var17.axisChanged(var22);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
//     var25.setBackgroundImageAlignment(10);
//     var25.setBorderVisible(true);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var36 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var37 = null;
//     var36.addChangeListener(var37);
//     org.jfree.chart.title.LegendItemBlockContainer var40 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var35, (org.jfree.data.general.Dataset)var36, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.data.general.Dataset var41 = var40.getDataset();
//     org.jfree.chart.entity.EntityCollection var42 = null;
//     org.jfree.chart.ChartRenderingInfo var43 = new org.jfree.chart.ChartRenderingInfo(var42);
//     java.awt.geom.Rectangle2D var44 = var43.getChartArea();
//     var40.setBounds(var44);
//     var25.draw(var30, var44);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);
    org.jfree.chart.entity.EntityCollection var2 = var1.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var5 = null;
    var3.setSeriesItemLabelFont(1, var5);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    double var5 = var4.getCategoryMargin();
    var4.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var9 = var4.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var10 = var0.getCategoriesForAxis(var4);
    java.awt.Paint var11 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotOrientation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var5 = null;
    var3.setSeriesItemLabelFont(1, var5);
    double var7 = var3.getItemMargin();
    boolean var9 = var3.isSeriesVisibleInLegend(1);
    java.lang.Boolean var11 = var3.getSeriesCreateEntities(1);
    java.awt.Paint var13 = var3.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var16 = null;
    var14.setSeriesItemLabelFont(1, var16);
    boolean var18 = var14.getBaseSeriesVisibleInLegend();
    java.awt.Paint var21 = var14.getItemOutlinePaint(13, 100);
    var3.setBaseFillPaint(var21, true);
    var3.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var3.getBaseNegativeItemLabelPosition();
    boolean var28 = var2.equals((java.lang.Object)var27);
    org.jfree.data.DefaultKeyedValues2D var29 = new org.jfree.data.DefaultKeyedValues2D();
    boolean var30 = var2.equals((java.lang.Object)var29);
    org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
    java.util.Date var32 = var31.getEnd();
    org.jfree.data.time.RegularTimePeriod var33 = var31.previous();
    int var34 = var29.getColumnIndex((java.lang.Comparable)var31);
    java.lang.Number var36 = var0.getQ3Value((java.lang.Comparable)var31, (java.lang.Comparable)"Nearest");
    java.lang.Comparable var37 = null;
    java.lang.Number var39 = var0.getQ1Value(var37, (java.lang.Comparable)2);
    java.lang.Number var42 = var0.getMinRegularValue((java.lang.Comparable)"First", (java.lang.Comparable)(-0.5d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var45 = var0.getMinOutlier(13, (-457));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
    int var15 = var14.getBackgroundImageAlignment();
    var3.addChangeListener((org.jfree.chart.event.PlotChangeListener)var14);
    java.awt.Stroke var17 = var14.getBorderStroke();
    var0.setGroupStroke(var17);
    var0.setDrawLines(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    java.lang.Comparable[] var0 = null;
    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths();
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, (java.lang.Comparable[])var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var3 = var2.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getBaseItemLabelGenerator();
//     java.awt.Paint var6 = null;
//     var2.setSeriesFillPaint(1, var6, false);
//     var2.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var2.getSeriesPositiveItemLabelPosition(100);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var18 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var15.setRangeWithMargins((org.jfree.data.Range)var18, false, true);
//     org.jfree.data.Range var22 = var15.getDefaultAutoRange();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.AxisState var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     java.util.List var27 = var15.refreshTicks(var23, var24, var25, var26);
//     java.awt.Font var28 = var15.getLabelFont();
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot3D var31 = new org.jfree.chart.plot.PiePlot3D(var30);
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var31);
//     var31.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var35 = var31.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var36 = null;
//     var31.axisChanged(var36);
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var28, (org.jfree.chart.plot.Plot)var31, false);
//     boolean var40 = var13.equals((java.lang.Object)var28);
//     java.awt.Color var42 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var46 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var47 = var42.getRGBColorComponents(var46);
//     org.jfree.chart.text.TextMeasurer var50 = null;
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var42, 0.0f, 10, var50);
//     java.util.List var52 = var51.getLines();
//     org.jfree.chart.text.TextLine var54 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
//     var51.addLine(var54);
//     org.jfree.chart.text.TextBlockAnchor var56 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var57 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var59 = null;
//     var57.setSeriesItemLabelFont(1, var59);
//     double var61 = var57.getItemMargin();
//     boolean var63 = var57.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var66 = var57.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.text.TextAnchor var67 = var66.getRotationAnchor();
//     org.jfree.chart.axis.CategoryTick var69 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"({0}, {1}) = {3} - {4}", var51, var56, var67, 8.0d);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var57 and var2.", var57.equals(var2) == var2.equals(var57));
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.chart.axis.NumberTickUnit var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var3, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getMaxIcon();
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var14 = var3.getSeriesPositiveItemLabelPosition(100);
    var0.setSeriesPositiveItemLabelPosition(12, var14);
    java.awt.Stroke var16 = null;
    var0.setGroupStroke(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     java.awt.Color var5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var6 = var5.getTransparency();
//     org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder(10.0d, 10.0d, 100.0d, 1.0d, (java.awt.Paint)var5);
//     int var8 = var5.getTransparency();
//     java.awt.color.ColorSpace var9 = null;
//     java.awt.Color var11 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var15 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var16 = var11.getRGBColorComponents(var15);
//     float[] var17 = var5.getComponents(var9, var16);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.util.Size2D var17 = var15.arrange(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var15.getLegendItemGraphicPadding();
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var20 = var19.getDataExtractOrder();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var22 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var24 = null;
//     var22.setSeriesItemLabelFont(1, var24);
//     double var26 = var22.getItemMargin();
//     boolean var28 = var22.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var31 = var22.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var36 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var33.setRangeWithMargins((org.jfree.data.Range)var36, false, true);
//     org.jfree.data.Range var40 = var33.getDefaultAutoRange();
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.axis.AxisState var42 = null;
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     java.util.List var45 = var33.refreshTicks(var41, var42, var43, var44);
//     java.awt.Font var46 = var33.getLabelFont();
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.PiePlot3D var49 = new org.jfree.chart.plot.PiePlot3D(var48);
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var49);
//     var49.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var53 = var49.getURLGenerator();
//     java.awt.Shape var54 = var49.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var55 = null;
//     var49.setLabelGenerator(var55);
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.PiePlot3D var59 = new org.jfree.chart.plot.PiePlot3D(var58);
//     org.jfree.chart.JFreeChart var60 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var59);
//     int var61 = var60.getBackgroundImageAlignment();
//     var49.addChangeListener((org.jfree.chart.event.PlotChangeListener)var60);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var64 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var66 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var64.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var66);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var68 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var70 = null;
//     var68.setSeriesItemLabelFont(1, var70);
//     boolean var72 = var68.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var75 = var68.getItemOutlinePaint(13, 100);
//     var64.setBaseItemLabelPaint(var75);
//     var49.setSectionPaint((java.lang.Comparable)(short)100, var75);
//     org.jfree.chart.block.LabelBlock var78 = new org.jfree.chart.block.LabelBlock("Default Group", var46, var75);
//     java.awt.geom.Rectangle2D var79 = var78.getBounds();
//     var22.setBaseShape((java.awt.Shape)var79, false);
//     var19.drawBackgroundImage(var21, var79);
//     java.awt.geom.Rectangle2D var85 = var18.createInsetRectangle(var79, true, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var68 and var3.", var68.equals(var3) == var3.equals(var68));
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     org.jfree.chart.block.LineBorder var1 = new org.jfree.chart.block.LineBorder();
//     boolean var2 = var0.equals((java.lang.Object)var1);
//     double var4 = var0.getSeriesBarWidth(0);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var6);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
//     var12.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var16 = var12.getURLGenerator();
//     java.awt.Shape var17 = var12.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var18 = null;
//     var12.setLabelGenerator(var18);
//     java.lang.Object var20 = var12.clone();
//     boolean var21 = var9.equals((java.lang.Object)var12);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     double var23 = var22.getCategoryMargin();
//     var22.setMaximumCategoryLabelWidthRatio(1.0f);
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var28 = var27.getUpArrow();
//     java.awt.Font var29 = var27.getLabelFont();
//     var22.setLabelFont(var29);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var34 = var32.lookupSeriesShape((-1));
//     var31.setUpArrow(var34);
//     var31.setLabel("");
//     java.util.TimeZone var38 = var31.getTimeZone();
//     boolean var39 = var31.isInverted();
//     org.jfree.data.category.CategoryDataset var40 = null;
//     var0.drawItem(var5, var7, var8, var9, var22, (org.jfree.chart.axis.ValueAxis)var31, var40, 100, 12, 0);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var4 = null;
    var0.setSeriesFillPaint(1, var4, false);
    var0.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.plot.CategoryPlot var10 = var0.getPlot();
    boolean var11 = var0.getBaseSeriesVisible();
    var0.setMinimumBarLength((-10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    java.lang.Number var0 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(var0, (java.lang.Number)0.05d);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.lang.Object var16 = null;
//     boolean var17 = var15.equals(var16);
//     java.awt.Paint var18 = var15.getItemPaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var21 = null;
//     var19.setSeriesItemLabelFont(1, var21);
//     double var23 = var19.getItemMargin();
//     boolean var25 = var19.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var26 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var27 = null;
//     var26.rendererChanged(var27);
//     var19.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var34 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var31.setRangeWithMargins((org.jfree.data.Range)var34, false, true);
//     org.jfree.data.Range var38 = var31.getDefaultAutoRange();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.axis.AxisState var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     java.util.List var43 = var31.refreshTicks(var39, var40, var41, var42);
//     java.awt.Font var44 = var31.getLabelFont();
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D(var46);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var47);
//     var47.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var51 = var47.getURLGenerator();
//     java.awt.Shape var52 = var47.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var53 = null;
//     var47.setLabelGenerator(var53);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.PiePlot3D var57 = new org.jfree.chart.plot.PiePlot3D(var56);
//     org.jfree.chart.JFreeChart var58 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var57);
//     int var59 = var58.getBackgroundImageAlignment();
//     var47.addChangeListener((org.jfree.chart.event.PlotChangeListener)var58);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var62 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var64 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var62.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var64);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var66 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var68 = null;
//     var66.setSeriesItemLabelFont(1, var68);
//     boolean var70 = var66.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var73 = var66.getItemOutlinePaint(13, 100);
//     var62.setBaseItemLabelPaint(var73);
//     var47.setSectionPaint((java.lang.Comparable)(short)100, var73);
//     org.jfree.chart.block.LabelBlock var76 = new org.jfree.chart.block.LabelBlock("Default Group", var44, var73);
//     java.awt.geom.Rectangle2D var77 = var76.getBounds();
//     org.jfree.chart.util.RectangleInsets var78 = var76.getPadding();
//     var26.setInsets(var78);
//     java.lang.String var80 = var78.toString();
//     var15.setLegendItemGraphicPadding(var78);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var3.", var19.equals(var3) == var3.equals(var19));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var66 and var3.", var66.equals(var3) == var3.equals(var66));
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var0.setRangeWithMargins((org.jfree.data.Range)var3, false, true);
//     var0.setTickMarkOutsideLength(100.0f);
//     double var9 = var0.getLowerBound();
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var14 = var12.lookupSeriesShape((-1));
//     var11.setUpArrow(var14);
//     java.util.Date var16 = var11.getMaximumDate();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)"SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var23.setRangeWithMargins((org.jfree.data.Range)var26, false, true);
//     org.jfree.data.Range var30 = var23.getDefaultAutoRange();
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.axis.AxisState var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     java.util.List var35 = var23.refreshTicks(var31, var32, var33, var34);
//     java.awt.Font var36 = var23.getLabelFont();
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
//     var39.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var43 = var39.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var44 = null;
//     var39.axisChanged(var44);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var36, (org.jfree.chart.plot.Plot)var39, false);
//     var47.setBackgroundImageAlignment(10);
//     org.jfree.chart.title.TextTitle var50 = var47.getTitle();
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.entity.EntityCollection var52 = null;
//     org.jfree.chart.ChartRenderingInfo var53 = new org.jfree.chart.ChartRenderingInfo(var52);
//     java.awt.geom.Rectangle2D var54 = var53.getChartArea();
//     var50.draw(var51, var54);
//     var11.setDownArrow((java.awt.Shape)var54);
//     org.jfree.chart.axis.AxisState var57 = new org.jfree.chart.axis.AxisState();
//     var57.setMax(100.0d);
//     var57.cursorDown(0.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var63 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var65 = var63.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var66 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var67 = var66.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var68 = var66.getBaseItemLabelGenerator();
//     java.awt.Paint var70 = null;
//     var66.setSeriesFillPaint(1, var70, false);
//     var66.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var76 = var66.getLegendItemLabelGenerator();
//     var63.setLegendItemToolTipGenerator(var76);
//     org.jfree.chart.title.LegendTitle var78 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63);
//     java.awt.Graphics2D var79 = null;
//     org.jfree.chart.util.Size2D var80 = var78.arrange(var79);
//     org.jfree.chart.util.RectangleEdge var81 = var78.getPosition();
//     var57.moveCursor(100.0d, var81);
//     double var83 = var0.valueToJava2D(0.0d, var54, var81);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var66.", var12.equals(var66) == var66.equals(var12));
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-435));
    double var5 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.CategoryMarker var2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
    var2.setKey((java.lang.Comparable)1.0d);
    var2.setDrawAsLine(true);
    float var7 = var2.getAlpha();
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var2, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var1.addChangeListener(var2);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)'4');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var1.getEndValue((-1), 2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(15);
    java.lang.String var4 = var3.getDescription();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addYears(0, var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-457), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(15);
    java.lang.String var4 = var3.getDescription();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addYears(0, var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(13, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var5 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var5.addChangeListener(var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    int var11 = var5.getRowIndex((java.lang.Comparable)(-1.0f));
    org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
    org.jfree.chart.util.Size2D var16 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    java.lang.Object var17 = var16.clone();
    int var18 = var13.compareTo((java.lang.Object)var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var20 = var5.getPercentComplete((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", (java.lang.Comparable)var13, 4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    var0.clearRangeAxes();
    org.jfree.chart.axis.ValueAxis var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-1), var4, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var2 = var1.getUpArrow();
//     java.awt.Font var3 = var1.getLabelFont();
//     java.text.DateFormat var4 = var1.getDateFormatOverride();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
//     var7.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
//     java.awt.Shape var12 = var7.getLegendItemShape();
//     org.jfree.chart.util.Rotation var13 = var7.getDirection();
//     org.jfree.chart.util.RectangleInsets var14 = var7.getInsets();
//     var1.setLabelInsets(var14);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     double var17 = var16.getCategoryMargin();
//     var16.setMaximumCategoryLabelWidthRatio(1.0f);
//     var16.clearCategoryLabelToolTips();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var24);
//     var24.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var28 = var24.getURLGenerator();
//     java.awt.Shape var29 = var24.getLegendItemShape();
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
//     double var31 = var30.getCategoryMargin();
//     boolean var32 = var24.equals((java.lang.Object)var31);
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var24);
//     var33.clearSubtitles();
//     java.util.List var35 = var33.getSubtitles();
//     java.awt.Paint var36 = var33.getBackgroundPaint();
//     var16.setLabelPaint(var36);
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var14, var36);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.LegendItemCollection var1 = new org.jfree.chart.LegendItemCollection();
//     var0.addAll(var1);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setMaximumCategoryLabelLines((-435));
    var0.setMaximumCategoryLabelLines((-435));
    java.awt.Paint var5 = var0.getTickMarkPaint();
    float var6 = var0.getTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(2014, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = var0.getPieChart();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.entity.EntityCollection var3 = null;
//     org.jfree.chart.ChartRenderingInfo var4 = new org.jfree.chart.ChartRenderingInfo(var3);
//     java.awt.geom.Rectangle2D var5 = var4.getChartArea();
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var9.setRangeWithMargins((org.jfree.data.Range)var12, false, true);
//     org.jfree.data.Range var16 = var9.getDefaultAutoRange();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.AxisState var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     java.util.List var21 = var9.refreshTicks(var17, var18, var19, var20);
//     java.awt.Font var22 = var9.getLabelFont();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var25);
//     var25.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var29 = var25.getURLGenerator();
//     java.awt.Shape var30 = var25.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var31 = null;
//     var25.setLabelGenerator(var31);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot3D var35 = new org.jfree.chart.plot.PiePlot3D(var34);
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var35);
//     int var37 = var36.getBackgroundImageAlignment();
//     var25.addChangeListener((org.jfree.chart.event.PlotChangeListener)var36);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var40 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var42 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var40.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var42);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var46 = null;
//     var44.setSeriesItemLabelFont(1, var46);
//     boolean var48 = var44.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var51 = var44.getItemOutlinePaint(13, 100);
//     var40.setBaseItemLabelPaint(var51);
//     var25.setSectionPaint((java.lang.Comparable)(short)100, var51);
//     org.jfree.chart.block.LabelBlock var54 = new org.jfree.chart.block.LabelBlock("Default Group", var22, var51);
//     java.awt.geom.Rectangle2D var55 = var54.getBounds();
//     java.awt.geom.Point2D var56 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 0.2d, var55);
//     org.jfree.chart.plot.PlotState var57 = new org.jfree.chart.plot.PlotState();
//     java.util.Map var58 = var57.getSharedAxisStates();
//     org.jfree.chart.entity.EntityCollection var59 = null;
//     org.jfree.chart.ChartRenderingInfo var60 = new org.jfree.chart.ChartRenderingInfo(var59);
//     java.awt.geom.Rectangle2D var61 = var60.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var62 = var60.getPlotInfo();
//     var0.draw(var2, var5, var56, var57, var62);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelOffset();
    java.awt.geom.Rectangle2D var11 = null;
    var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.plot.Marker)var9, var11);
    org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var15 = var13.lookupSeriesShape((-1));
    org.jfree.chart.labels.ItemLabelPosition var17 = var13.getSeriesPositiveItemLabelPosition((-1));
    var2.setBasePositiveItemLabelPosition(var17, false);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D(var21);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var22);
    var22.setShadowYOffset(0.0d);
    double var26 = var22.getMaximumLabelWidth();
    java.awt.Paint var28 = var22.getSectionOutlinePaint((java.lang.Comparable)13);
    org.jfree.data.general.PieDataset var29 = var22.getDataset();
    java.awt.Paint var30 = var22.getLabelPaint();
    var2.setWallPaint(var30);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var32 = var2.getLegendItemToolTipGenerator();
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var37 = var35.lookupSeriesShape((-1));
    var34.setUpArrow(var37);
    java.util.Date var39 = var34.getMaximumDate();
    org.jfree.data.general.PieDataset var41 = null;
    org.jfree.chart.plot.PiePlot3D var42 = new org.jfree.chart.plot.PiePlot3D(var41);
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var42);
    boolean var44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)"SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var49 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var46.setRangeWithMargins((org.jfree.data.Range)var49, false, true);
    org.jfree.data.Range var53 = var46.getDefaultAutoRange();
    java.awt.Graphics2D var54 = null;
    org.jfree.chart.axis.AxisState var55 = null;
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    java.util.List var58 = var46.refreshTicks(var54, var55, var56, var57);
    java.awt.Font var59 = var46.getLabelFont();
    org.jfree.data.general.PieDataset var61 = null;
    org.jfree.chart.plot.PiePlot3D var62 = new org.jfree.chart.plot.PiePlot3D(var61);
    org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var62);
    var62.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var66 = var62.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var67 = null;
    var62.axisChanged(var67);
    org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var59, (org.jfree.chart.plot.Plot)var62, false);
    var70.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var73 = var70.getTitle();
    java.awt.Graphics2D var74 = null;
    org.jfree.chart.entity.EntityCollection var75 = null;
    org.jfree.chart.ChartRenderingInfo var76 = new org.jfree.chart.ChartRenderingInfo(var75);
    java.awt.geom.Rectangle2D var77 = var76.getChartArea();
    var73.draw(var74, var77);
    var34.setDownArrow((java.awt.Shape)var77);
    org.jfree.chart.plot.CategoryPlot var80 = null;
    org.jfree.chart.entity.EntityCollection var82 = null;
    org.jfree.chart.ChartRenderingInfo var83 = new org.jfree.chart.ChartRenderingInfo(var82);
    java.awt.geom.Rectangle2D var84 = var83.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var85 = var83.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var86 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var85);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var87 = var2.initialise(var33, var77, var80, 2014, var85);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var3 = null;
//     var1.setSeriesItemLabelFont(1, var3);
//     double var5 = var1.getItemMargin();
//     boolean var7 = var1.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var9 = var1.getSeriesCreateEntities(1);
//     java.awt.Paint var11 = var1.lookupSeriesFillPaint(15);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var14 = var13.getUpArrow();
//     java.awt.Shape var15 = var13.getDownArrow();
//     java.awt.Stroke var16 = var13.getTickMarkStroke();
//     org.jfree.chart.plot.CategoryMarker var17 = new org.jfree.chart.plot.CategoryMarker(var0, var11, var16);
//     
//     // Checks the contract:  var17.equals(var17)
//     assertTrue("Contract failed: var17.equals(var17)", var17.equals(var17));
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.data.KeyToGroupMap var0 = new org.jfree.data.KeyToGroupMap();
    java.lang.Comparable var2 = var0.getGroup((java.lang.Comparable)(short)1);
    java.lang.Comparable var4 = var0.getGroup((java.lang.Comparable)" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Default Group"+ "'", var2.equals("Default Group"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Default Group"+ "'", var4.equals("Default Group"));

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject((java.lang.Comparable)"");
    java.util.List var3 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-435));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 1.0f);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    var0.clearRangeAxes();
    var0.clearRangeMarkers(100);
    org.jfree.chart.axis.AxisLocation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-1), var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Paint var3 = var1.lookupSeriesOutlinePaint(255);
    org.jfree.chart.LegendItem var6 = var1.getLegendItem(1, 1);
    org.jfree.chart.labels.ItemLabelPosition var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBasePositiveItemLabelPosition(var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var0.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var11.setRangeWithMargins((org.jfree.data.Range)var14, false, true);
//     org.jfree.data.Range var18 = var11.getDefaultAutoRange();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.AxisState var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     java.util.List var23 = var11.refreshTicks(var19, var20, var21, var22);
//     java.awt.Font var24 = var11.getLabelFont();
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
//     var27.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var31 = var27.getURLGenerator();
//     java.awt.Shape var32 = var27.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var33 = null;
//     var27.setLabelGenerator(var33);
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D(var36);
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var37);
//     int var39 = var38.getBackgroundImageAlignment();
//     var27.addChangeListener((org.jfree.chart.event.PlotChangeListener)var38);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var42 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var44 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var42.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var44);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var46 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var48 = null;
//     var46.setSeriesItemLabelFont(1, var48);
//     boolean var50 = var46.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var53 = var46.getItemOutlinePaint(13, 100);
//     var42.setBaseItemLabelPaint(var53);
//     var27.setSectionPaint((java.lang.Comparable)(short)100, var53);
//     org.jfree.chart.block.LabelBlock var56 = new org.jfree.chart.block.LabelBlock("Default Group", var24, var53);
//     java.awt.geom.Rectangle2D var57 = var56.getBounds();
//     var0.setBaseShape((java.awt.Shape)var57, false);
//     java.awt.Font var62 = var0.getItemLabelFont((-457), 15);
//     java.awt.Graphics2D var63 = null;
//     org.jfree.chart.util.HorizontalAlignment var64 = null;
//     org.jfree.chart.util.VerticalAlignment var65 = null;
//     org.jfree.chart.block.ColumnArrangement var68 = new org.jfree.chart.block.ColumnArrangement(var64, var65, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var69 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var70 = null;
//     var69.addChangeListener(var70);
//     org.jfree.chart.title.LegendItemBlockContainer var73 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var68, (org.jfree.data.general.Dataset)var69, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.data.general.Dataset var74 = var73.getDataset();
//     org.jfree.chart.entity.EntityCollection var75 = null;
//     org.jfree.chart.ChartRenderingInfo var76 = new org.jfree.chart.ChartRenderingInfo(var75);
//     java.awt.geom.Rectangle2D var77 = var76.getChartArea();
//     var73.setBounds(var77);
//     org.jfree.chart.entity.ChartEntity var81 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var77, "Monday", "RectangleEdge.TOP");
//     org.jfree.chart.plot.CategoryPlot var82 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.entity.EntityCollection var84 = null;
//     org.jfree.chart.ChartRenderingInfo var85 = new org.jfree.chart.ChartRenderingInfo(var84);
//     java.awt.geom.Rectangle2D var86 = var85.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var87 = var85.getPlotInfo();
//     org.jfree.chart.renderer.category.CategoryItemRendererState var88 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var87);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var89 = var0.initialise(var63, var77, var82, 15, var87);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var4 = null;
//     var2.setSeriesItemLabelFont(1, var4);
//     double var6 = var2.getItemMargin();
//     boolean var8 = var2.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var10 = var2.getSeriesCreateEntities(1);
//     java.awt.Paint var12 = var2.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var15 = null;
//     var13.setSeriesItemLabelFont(1, var15);
//     boolean var17 = var13.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var20 = var13.getItemOutlinePaint(13, 100);
//     var2.setBaseFillPaint(var20, true);
//     var2.setSeriesCreateEntities(2, (java.lang.Boolean)false);
//     org.jfree.chart.labels.ItemLabelPosition var26 = var2.getBaseNegativeItemLabelPosition();
//     boolean var27 = var1.equals((java.lang.Object)var26);
//     org.jfree.data.DefaultKeyedValues2D var28 = new org.jfree.data.DefaultKeyedValues2D();
//     boolean var29 = var1.equals((java.lang.Object)var28);
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     java.util.Date var31 = var30.getEnd();
//     org.jfree.data.time.RegularTimePeriod var32 = var30.previous();
//     int var33 = var28.getColumnIndex((java.lang.Comparable)var30);
//     java.util.Calendar var34 = null;
//     var30.peg(var34);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var17.axisChanged(var22);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
    var25.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var28 = var25.getTitle();
    java.awt.Graphics2D var29 = null;
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var33 = var32.getLowerDate();
    org.jfree.data.Range var36 = org.jfree.data.Range.shift((org.jfree.data.Range)var32, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(var36, 1.0d);
    org.jfree.chart.util.Size2D var41 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    org.jfree.chart.util.Size2D var42 = var38.calculateConstrainedSize(var41);
    org.jfree.data.Range var43 = var38.getWidthRange();
    double var44 = var38.getWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var45 = var28.arrange(var29, var38);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.util.Size2D var17 = var15.arrange(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var15.getLegendItemGraphicPadding();
//     org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     org.jfree.chart.util.RectangleInsets var22 = var21.getLabelOffset();
//     double var24 = var22.trimWidth((-1.0d));
//     double var26 = var22.calculateRightOutset(1.0d);
//     var15.setLegendItemGraphicPadding(var22);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.data.time.DateRange var31 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     java.util.Date var32 = var31.getLowerDate();
//     org.jfree.data.Range var35 = org.jfree.data.Range.shift((org.jfree.data.Range)var31, 0.0d, false);
//     org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(var35, 1.0d);
//     java.lang.String var38 = var37.toString();
//     org.jfree.chart.util.Size2D var39 = var15.arrange(var28, var37);
//     
//     // Checks the contract:  equals-hashcode on var17 and var39
//     assertTrue("Contract failed: equals-hashcode on var17 and var39", var17.equals(var39) ? var17.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var17
//     assertTrue("Contract failed: equals-hashcode on var39 and var17", var39.equals(var17) ? var39.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.function.Function2D var0 = null;
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-1.0d), (-0.9500000000000001d), 2014, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
    org.jfree.chart.plot.CategoryPlot var9 = var0.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-457), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    var2.setShadowYOffset(1.0d);
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var9 = var8.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getBaseItemLabelGenerator();
    double var11 = var8.getBase();
    java.awt.Stroke var12 = var8.getBaseOutlineStroke();
    var2.setOutlineStroke(var12);
    var2.setShadowYOffset(10.0d);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var18);
    var18.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var22 = var18.getURLGenerator();
    java.awt.Shape var23 = var18.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var24 = null;
    var18.setLabelGenerator(var24);
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var28);
    int var30 = var29.getBackgroundImageAlignment();
    var18.addChangeListener((org.jfree.chart.event.PlotChangeListener)var29);
    org.jfree.chart.renderer.category.IntervalBarRenderer var33 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var33.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var35);
    org.jfree.chart.renderer.category.IntervalBarRenderer var37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var39 = null;
    var37.setSeriesItemLabelFont(1, var39);
    boolean var41 = var37.getBaseSeriesVisibleInLegend();
    java.awt.Paint var44 = var37.getItemOutlinePaint(13, 100);
    var33.setBaseItemLabelPaint(var44);
    var18.setSectionPaint((java.lang.Comparable)(short)100, var44);
    var2.setLabelLinkPaint(var44);
    java.lang.Comparable var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExplodePercent(var48, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Object var1 = var0.clone();
    int var2 = var0.size();
    java.lang.Boolean var4 = var0.getBoolean((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
//     java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-435));
//     java.awt.Paint var12 = var0.lookupSeriesPaint(10);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D(var14);
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var15);
//     var15.setShadowYOffset(0.0d);
//     var15.setShadowYOffset(1.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var22 = var21.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var21.getBaseItemLabelGenerator();
//     double var24 = var21.getBase();
//     java.awt.Stroke var25 = var21.getBaseOutlineStroke();
//     var15.setOutlineStroke(var25);
//     var0.setBaseStroke(var25, true);
//     java.awt.Color var32 = java.awt.Color.getColor("SerialDate.weekInMonthToString(): invalid code.", 13);
//     java.awt.Color var33 = var32.brighter();
//     var0.setSeriesPaint(100, (java.awt.Paint)var33, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
// 
//   }

//  public void test331() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
//
//
//    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var0 == false);
//
//  }
//
  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     double var4 = var0.getItemMargin();
//     boolean var6 = var0.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var8 = null;
//     var7.rendererChanged(var8);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var7);
//     java.awt.Shape var12 = null;
//     var0.setSeriesShape(2, var12, true);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = null;
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getLabelOffset();
//     java.awt.geom.Rectangle2D var27 = null;
//     var18.drawRangeMarker(var19, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.plot.Marker)var25, var27);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var31 = var29.lookupSeriesShape((-1));
//     org.jfree.chart.labels.ItemLabelPosition var33 = var29.getSeriesPositiveItemLabelPosition((-1));
//     var18.setBasePositiveItemLabelPosition(var33, false);
//     var0.setSeriesNegativeItemLabelPosition(3, var33);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var0.", var29.equals(var0) == var0.equals(var29));
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     org.jfree.chart.text.TextAnchor var8 = var7.getLabelTextAnchor();
//     var1.draw(var2, 0.8f, 0.95f, var8, 0.8f, 100.0f, (-0.5d));
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("({0}, {1}) = {3} - {4}", var1);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    org.jfree.data.DefaultKeyedValues2D var7 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var8 = var7.getRowKeys();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var12 = var10.lookupSeriesShape((-1));
    var9.setUpArrow(var12);
    java.util.Date var14 = var9.getMaximumDate();
    int var15 = var7.getColumnIndex((java.lang.Comparable)var14);
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var19 = var17.lookupSeriesShape((-1));
    var16.setUpArrow(var19);
    var16.setLabel("");
    java.util.TimeZone var23 = var16.getTimeZone();
    org.jfree.data.time.Year var24 = new org.jfree.data.time.Year(var14, var23);
    org.jfree.chart.renderer.category.IntervalBarRenderer var25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var27 = null;
    var25.setSeriesItemLabelFont(1, var27);
    double var29 = var25.getItemMargin();
    boolean var31 = var25.isSeriesVisibleInLegend(1);
    java.lang.Boolean var33 = var25.getSeriesCreateEntities(1);
    java.awt.Paint var35 = var25.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var38 = null;
    var36.setSeriesItemLabelFont(1, var38);
    boolean var40 = var36.getBaseSeriesVisibleInLegend();
    java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
    var25.setBaseFillPaint(var43, true);
    org.jfree.chart.urls.StandardCategoryURLGenerator var49 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "", "");
    var25.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var49, false);
    java.awt.Stroke var52 = var25.getBaseOutlineStroke();
    var2.setSectionOutlineStroke((java.lang.Comparable)var14, var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var5 = null;
    var3.setSeriesItemLabelFont(1, var5);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var1 = null;
    var0.rendererChanged(var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
//     var3.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
//     java.awt.Shape var8 = var3.getLegendItemShape();
//     org.jfree.chart.util.Rotation var9 = var3.getDirection();
//     java.awt.Paint var10 = var3.getBaseSectionOutlinePaint();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
//     var13.setShadowYOffset(0.0d);
//     var13.setShadowYOffset(1.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var20 = var19.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var19.getBaseItemLabelGenerator();
//     double var22 = var19.getBase();
//     java.awt.Stroke var23 = var19.getBaseOutlineStroke();
//     var13.setOutlineStroke(var23);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker((-1.0d), var10, var23);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var28);
//     var28.setShadowYOffset(0.0d);
//     double var32 = var28.getMaximumLabelWidth();
//     java.awt.Paint var34 = var28.getSectionOutlinePaint((java.lang.Comparable)13);
//     org.jfree.data.general.PieDataset var35 = var28.getDataset();
//     boolean var36 = var25.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var3 and var28
//     assertTrue("Contract failed: equals-hashcode on var3 and var28", var3.equals(var28) ? var3.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var3
//     assertTrue("Contract failed: equals-hashcode on var28 and var3", var28.equals(var3) ? var28.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var29
//     assertTrue("Contract failed: equals-hashcode on var4 and var29", var4.equals(var29) ? var4.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var4
//     assertTrue("Contract failed: equals-hashcode on var29 and var4", var29.equals(var4) ? var29.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.SeriesRenderingOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesRenderingOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "Pie 3D Plot", "({0}, {1}) = {3} - {4}");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelOffset();
    boolean var5 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.event.MarkerChangeEvent var6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var3);
    var3.setEndValue((-7.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var2);
    var0.setBaseSeriesVisible(false);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.entity.EntityCollection var0 = null;
//     org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = var1.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getPlotInfo();
//     org.jfree.chart.renderer.category.CategoryItemRendererState var4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var3);
//     org.jfree.chart.entity.EntityCollection var5 = null;
//     org.jfree.chart.ChartRenderingInfo var6 = new org.jfree.chart.ChartRenderingInfo(var5);
//     java.awt.geom.Rectangle2D var7 = var6.getChartArea();
//     boolean var8 = var3.equals((java.lang.Object)var6);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     java.awt.Image var3 = null;
//     org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var3, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
//     java.lang.String var8 = var7.toString();
//     java.awt.Image var12 = null;
//     org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var12, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
//     java.lang.String var17 = var16.toString();
//     org.jfree.chart.ui.Library[] var18 = var16.getLibraries();
//     var7.addLibrary((org.jfree.chart.ui.Library)var16);
//     org.jfree.chart.ui.Library var20 = null;
//     var7.addOptionalLibrary(var20);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    double var6 = var2.getMaximumLabelWidth();
    java.awt.Paint var8 = var2.getSectionOutlinePaint((java.lang.Comparable)13);
    org.jfree.chart.plot.AbstractPieLabelDistributor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelDistributor(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.util.RectangleInsets var12 = var11.getLabelOffset();
    java.awt.geom.Rectangle2D var13 = null;
    var4.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.plot.Marker)var11, var13);
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, (org.jfree.chart.plot.Marker)var11, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
    var0.clear();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4);
    java.lang.String var6 = var5.toString();
    java.lang.Object var7 = var5.getSource();
    org.jfree.chart.event.ChartChangeEventType var8 = var5.getType();
    java.lang.String var9 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=true]"+ "'", var6.equals("org.jfree.chart.event.ChartChangeEvent[source=true]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + true+ "'", var7.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=true]"+ "'", var9.equals("org.jfree.chart.event.ChartChangeEvent[source=true]"));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var3 = var2.getLowerDate();
    org.jfree.data.Range var6 = org.jfree.data.Range.shift((org.jfree.data.Range)var2, 0.0d, false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var7.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var9);
    java.awt.Stroke var11 = var7.getBaseOutlineStroke();
    boolean var12 = var2.equals((java.lang.Object)var7);
    boolean var15 = var7.isItemLabelVisible(1, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
    org.jfree.chart.util.RectangleInsets var3 = var0.getAxisOffset();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = var0.getRendererForDataset(var4);
    org.jfree.chart.plot.PlotOrientation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    int var2 = var0.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.awt.Font var3 = var1.getLabelFont();
    java.text.DateFormat var4 = var1.getDateFormatOverride();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var7);
    var7.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var11 = var7.getURLGenerator();
    java.awt.Shape var12 = var7.getLegendItemShape();
    org.jfree.chart.util.Rotation var13 = var7.getDirection();
    org.jfree.chart.util.RectangleInsets var14 = var7.getInsets();
    var1.setLabelInsets(var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var20 = null;
    var18.setSeriesItemLabelFont(1, var20);
    double var22 = var18.getItemMargin();
    boolean var24 = var18.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var27 = var18.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var29.setRangeWithMargins((org.jfree.data.Range)var32, false, true);
    org.jfree.data.Range var36 = var29.getDefaultAutoRange();
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.axis.AxisState var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.RectangleEdge var40 = null;
    java.util.List var41 = var29.refreshTicks(var37, var38, var39, var40);
    java.awt.Font var42 = var29.getLabelFont();
    org.jfree.data.general.PieDataset var44 = null;
    org.jfree.chart.plot.PiePlot3D var45 = new org.jfree.chart.plot.PiePlot3D(var44);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var45);
    var45.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var49 = var45.getURLGenerator();
    java.awt.Shape var50 = var45.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var51 = null;
    var45.setLabelGenerator(var51);
    org.jfree.data.general.PieDataset var54 = null;
    org.jfree.chart.plot.PiePlot3D var55 = new org.jfree.chart.plot.PiePlot3D(var54);
    org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var55);
    int var57 = var56.getBackgroundImageAlignment();
    var45.addChangeListener((org.jfree.chart.event.PlotChangeListener)var56);
    org.jfree.chart.renderer.category.IntervalBarRenderer var60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var62 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var60.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var62);
    org.jfree.chart.renderer.category.IntervalBarRenderer var64 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var66 = null;
    var64.setSeriesItemLabelFont(1, var66);
    boolean var68 = var64.getBaseSeriesVisibleInLegend();
    java.awt.Paint var71 = var64.getItemOutlinePaint(13, 100);
    var60.setBaseItemLabelPaint(var71);
    var45.setSectionPaint((java.lang.Comparable)(short)100, var71);
    org.jfree.chart.block.LabelBlock var74 = new org.jfree.chart.block.LabelBlock("Default Group", var42, var71);
    java.awt.geom.Rectangle2D var75 = var74.getBounds();
    var18.setBaseShape((java.awt.Shape)var75, false);
    org.jfree.chart.plot.PlotRenderingInfo var79 = null;
    boolean var80 = var16.render(var17, var75, (-457), var79);
    java.awt.geom.Rectangle2D var83 = var14.createOutsetRectangle(var75, true, false);
    double var85 = var14.calculateBottomInset(1.0d);
    double var86 = var14.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 8.0d);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
//     var2.setLabelGenerator(var8);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
//     int var14 = var13.getBackgroundImageAlignment();
//     var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var17.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var19);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var23 = null;
//     var21.setSeriesItemLabelFont(1, var23);
//     boolean var25 = var21.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var28 = var21.getItemOutlinePaint(13, 100);
//     var17.setBaseItemLabelPaint(var28);
//     var2.setSectionPaint((java.lang.Comparable)(short)100, var28);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var33 = var32.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var34 = var32.getBaseItemLabelGenerator();
//     java.awt.Paint var36 = null;
//     var32.setSeriesFillPaint(1, var36, false);
//     var32.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.ItemLabelPosition var43 = var32.getSeriesPositiveItemLabelPosition(100);
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var48 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var45.setRangeWithMargins((org.jfree.data.Range)var48, false, true);
//     org.jfree.data.Range var52 = var45.getDefaultAutoRange();
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.axis.AxisState var54 = null;
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     java.util.List var57 = var45.refreshTicks(var53, var54, var55, var56);
//     java.awt.Font var58 = var45.getLabelFont();
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot3D var61 = new org.jfree.chart.plot.PiePlot3D(var60);
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var61);
//     var61.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var65 = var61.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var66 = null;
//     var61.axisChanged(var66);
//     org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var58, (org.jfree.chart.plot.Plot)var61, false);
//     boolean var70 = var43.equals((java.lang.Object)var58);
//     java.awt.Color var72 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var76 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var77 = var72.getRGBColorComponents(var76);
//     org.jfree.chart.text.TextMeasurer var80 = null;
//     org.jfree.chart.text.TextBlock var81 = org.jfree.chart.text.TextUtilities.createTextBlock("", var58, (java.awt.Paint)var72, 0.0f, 10, var80);
//     org.jfree.chart.axis.DateAxis var84 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var85 = var84.getUpArrow();
//     java.awt.Font var86 = var84.getLabelFont();
//     org.jfree.chart.plot.CategoryMarker var88 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     var88.setKey((java.lang.Comparable)false);
//     org.jfree.data.general.PieDataset var92 = null;
//     org.jfree.chart.plot.PiePlot3D var93 = new org.jfree.chart.plot.PiePlot3D(var92);
//     org.jfree.chart.JFreeChart var94 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var93);
//     java.awt.Shape var95 = var93.getLegendItemShape();
//     var88.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var93);
//     java.awt.Paint var97 = var93.getLabelShadowPaint();
//     var81.addLine("hi!", var86, var97);
//     var2.setLabelShadowPaint(var97);
//     
//     // Checks the contract:  equals-hashcode on var12 and var93
//     assertTrue("Contract failed: equals-hashcode on var12 and var93", var12.equals(var93) ? var12.hashCode() == var93.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var93 and var12
//     assertTrue("Contract failed: equals-hashcode on var93 and var12", var93.equals(var12) ? var93.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var94
//     assertTrue("Contract failed: equals-hashcode on var13 and var94", var13.equals(var94) ? var13.hashCode() == var94.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var94 and var13
//     assertTrue("Contract failed: equals-hashcode on var94 and var13", var94.equals(var13) ? var94.hashCode() == var13.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var32.", var21.equals(var32) == var32.equals(var21));
// 
//   }

//  public void test356() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", var1);
//
//  }
//
  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.labels.PieToolTipGenerator var6 = null;
//     var2.setToolTipGenerator(var6);
//     java.awt.Paint var8 = var2.getBackgroundPaint();
//     double var9 = var2.getMaximumLabelWidth();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var13);
//     var13.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var17 = var13.getURLGenerator();
//     java.awt.Shape var18 = var13.getLegendItemShape();
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
//     double var20 = var19.getCategoryMargin();
//     boolean var21 = var13.equals((java.lang.Object)var20);
//     org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
//     var22.clearSubtitles();
//     java.util.List var24 = var22.getSubtitles();
//     java.awt.Paint var25 = var22.getBackgroundPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.lang.Object var28 = var27.clone();
//     var27.setDrawOutlines(true);
//     org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var35 = var34.getAlpha();
//     java.awt.Paint var36 = var34.getPaint();
//     java.awt.Font var37 = var34.getLabelFont();
//     var27.setSeriesItemLabelFont(100, var37, false);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("", var37);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var41 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var43 = var41.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var45 = var44.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var46 = var44.getBaseItemLabelGenerator();
//     java.awt.Paint var48 = null;
//     var44.setSeriesFillPaint(1, var48, false);
//     var44.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var54 = var44.getLegendItemLabelGenerator();
//     var41.setLegendItemToolTipGenerator(var54);
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
//     java.lang.Object var57 = null;
//     boolean var58 = var56.equals(var57);
//     java.awt.Paint var59 = var56.getItemPaint();
//     org.jfree.chart.util.HorizontalAlignment var60 = var56.getHorizontalAlignment();
//     var40.setTextAlignment(var60);
//     var22.removeSubtitle((org.jfree.chart.title.Title)var40);
//     var2.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var22);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var14
//     assertTrue("Contract failed: equals-hashcode on var3 and var14", var3.equals(var14) ? var3.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var3
//     assertTrue("Contract failed: equals-hashcode on var14 and var3", var14.equals(var3) ? var14.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var3, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var8 = var7.toString();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var12, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var17 = var16.toString();
    org.jfree.chart.ui.Library[] var18 = var16.getLibraries();
    var7.addLibrary((org.jfree.chart.ui.Library)var16);
    var7.setLicenceText("");
    java.awt.Image var25 = null;
    org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var25, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var30 = var29.toString();
    java.awt.Image var34 = null;
    org.jfree.chart.ui.ProjectInfo var38 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var34, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var39 = var38.toString();
    org.jfree.chart.ui.Library[] var40 = var38.getLibraries();
    var29.addLibrary((org.jfree.chart.ui.Library)var38);
    var29.setLicenceText("");
    var7.addLibrary((org.jfree.chart.ui.Library)var29);
    java.util.List var45 = var7.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var8.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var17.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var30.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var39.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.jfree.data.time.Year var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, var1);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorRight((-7.0d));
    java.util.List var3 = var0.getTicks();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var2);
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var7 = var5.lookupSeriesShape((-1));
    var4.setUpArrow(var7);
    java.util.Date var9 = var4.getMaximumDate();
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var16.setRangeWithMargins((org.jfree.data.Range)var19, false, true);
    org.jfree.data.Range var23 = var16.getDefaultAutoRange();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.axis.AxisState var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    java.util.List var28 = var16.refreshTicks(var24, var25, var26, var27);
    java.awt.Font var29 = var16.getLabelFont();
    org.jfree.data.general.PieDataset var31 = null;
    org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D(var31);
    org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var32);
    var32.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var36 = var32.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var37 = null;
    var32.axisChanged(var37);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var29, (org.jfree.chart.plot.Plot)var32, false);
    var40.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var43 = var40.getTitle();
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.entity.EntityCollection var45 = null;
    org.jfree.chart.ChartRenderingInfo var46 = new org.jfree.chart.ChartRenderingInfo(var45);
    java.awt.geom.Rectangle2D var47 = var46.getChartArea();
    var43.draw(var44, var47);
    var4.setDownArrow((java.awt.Shape)var47);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var53 = null;
    org.jfree.chart.plot.PiePlot3D var54 = new org.jfree.chart.plot.PiePlot3D(var53);
    org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var54);
    var54.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var58 = var54.getURLGenerator();
    java.awt.Shape var59 = var54.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var60 = null;
    var54.setLabelGenerator(var60);
    java.lang.Object var62 = var54.clone();
    boolean var63 = var51.equals((java.lang.Object)var54);
    org.jfree.chart.util.SortOrder var64 = var51.getRowRenderingOrder();
    org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]", (org.jfree.chart.plot.Plot)var51);
    boolean var66 = var51.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis();
    double var68 = var67.getCategoryMargin();
    var67.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.DateAxis var71 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var72 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var74 = var72.lookupSeriesShape((-1));
    var71.setUpArrow(var74);
    java.util.Date var76 = var71.getMaximumDate();
    org.jfree.data.general.PieDataset var78 = null;
    org.jfree.chart.plot.PiePlot3D var79 = new org.jfree.chart.plot.PiePlot3D(var78);
    org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var79);
    boolean var81 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var71, (java.lang.Object)"SerialDate.weekInMonthToString(): invalid code.");
    var71.setLowerMargin(100.0d);
    org.jfree.chart.axis.SegmentedTimeline var87 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
    long var88 = var87.getSegmentsExcludedSize();
    int var89 = var87.getSegmentsIncluded();
    var71.setTimeline((org.jfree.chart.axis.Timeline)var87);
    java.lang.Number[][] var91 = null;
    java.lang.Number[] var92 = null;
    java.lang.Number[][] var93 = new java.lang.Number[][] { var92};
    org.jfree.data.category.DefaultIntervalCategoryDataset var94 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var91, var93);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var3, var47, var51, var67, (org.jfree.chart.axis.ValueAxis)var71, (org.jfree.data.category.CategoryDataset)var94, 3, 255, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(15);
    java.lang.String var3 = var2.getDescription();
    java.lang.String var4 = var2.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addMonths((-1), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    org.jfree.chart.text.TextAnchor var4 = var3.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var6 = var5.getWidthRatio();
    org.jfree.chart.text.TextAnchor var7 = var5.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var9 = new org.jfree.chart.labels.ItemLabelPosition(var0, var4, var7, 8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    var1.setIgnoreZeroValues(true);
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var5 = var1.getSectionPaint(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     org.jfree.chart.util.RectangleInsets var4 = var3.getLabelOffset();
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.GradientPaint var6 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var8 = var7.getBaseShape();
//     java.awt.GradientPaint var9 = var0.transform(var6, var8);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-435), (java.lang.Number)(short)10);
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    double var4 = var3.getCategoryMargin();
    int var5 = var3.getCategoryLabelPositionOffset();
    boolean var6 = var2.equals((java.lang.Object)var5);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var8.setRangeWithMargins((org.jfree.data.Range)var11, false, true);
    org.jfree.data.Range var15 = var8.getDefaultAutoRange();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.axis.AxisState var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    java.util.List var20 = var8.refreshTicks(var16, var17, var18, var19);
    java.awt.Font var21 = var8.getLabelFont();
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var24);
    var24.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var28 = var24.getURLGenerator();
    java.awt.Shape var29 = var24.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var30 = null;
    var24.setLabelGenerator(var30);
    org.jfree.data.general.PieDataset var33 = null;
    org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D(var33);
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var34);
    int var36 = var35.getBackgroundImageAlignment();
    var24.addChangeListener((org.jfree.chart.event.PlotChangeListener)var35);
    org.jfree.chart.renderer.category.IntervalBarRenderer var39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var41 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var39.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var41);
    org.jfree.chart.renderer.category.IntervalBarRenderer var43 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var45 = null;
    var43.setSeriesItemLabelFont(1, var45);
    boolean var47 = var43.getBaseSeriesVisibleInLegend();
    java.awt.Paint var50 = var43.getItemOutlinePaint(13, 100);
    var39.setBaseItemLabelPaint(var50);
    var24.setSectionPaint((java.lang.Comparable)(short)100, var50);
    org.jfree.chart.block.LabelBlock var53 = new org.jfree.chart.block.LabelBlock("Default Group", var21, var50);
    boolean var54 = var2.equals((java.lang.Object)var53);
    java.lang.Number var55 = var2.getMean();
    java.lang.Number var56 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-435)+ "'", var55.equals((-435)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + (short)10+ "'", var56.equals((short)10));

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var2 = null;
//     var1.addChangeListener(var2);
//     var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var6 = var5.getDataExtractOrder();
//     var0.setDataExtractOrder(var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (-7.0d)};
//     java.lang.Comparable[] var2 = null;
//     java.lang.Number[][] var3 = null;
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var4, var6);
//     org.jfree.data.category.DefaultIntervalCategoryDataset var8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var3, var6);
//     
//     // Checks the contract:  equals-hashcode on var7 and var8
//     assertTrue("Contract failed: equals-hashcode on var7 and var8", var7.equals(var8) ? var7.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var7
//     assertTrue("Contract failed: equals-hashcode on var8 and var7", var8.equals(var7) ? var8.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst", var1, 1.0f, 0.0f, 3.0d, 0.95f, 100.0f);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
//     var3.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
//     java.awt.Shape var8 = var3.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
//     var3.setLabelGenerator(var9);
//     java.lang.Object var11 = var3.clone();
//     boolean var12 = var0.equals((java.lang.Object)var3);
//     org.jfree.chart.util.SortOrder var13 = var0.getRowRenderingOrder();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D(var15);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var16);
//     var16.setShadowYOffset(0.0d);
//     var16.setShadowYOffset(1.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var22 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var23 = var22.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var24 = var22.getBaseItemLabelGenerator();
//     double var25 = var22.getBase();
//     java.awt.Stroke var26 = var22.getBaseOutlineStroke();
//     var16.setOutlineStroke(var26);
//     var16.setShadowYOffset(10.0d);
//     var0.setParent((org.jfree.chart.plot.Plot)var16);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var33 = var32.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var34 = var32.getBaseItemLabelGenerator();
//     java.awt.Paint var36 = null;
//     var32.setSeriesFillPaint(1, var36, false);
//     var32.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.ItemLabelPosition var43 = var32.getSeriesPositiveItemLabelPosition(100);
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var48 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var45.setRangeWithMargins((org.jfree.data.Range)var48, false, true);
//     org.jfree.data.Range var52 = var45.getDefaultAutoRange();
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.axis.AxisState var54 = null;
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     java.util.List var57 = var45.refreshTicks(var53, var54, var55, var56);
//     java.awt.Font var58 = var45.getLabelFont();
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot3D var61 = new org.jfree.chart.plot.PiePlot3D(var60);
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var61);
//     var61.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var65 = var61.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var66 = null;
//     var61.axisChanged(var66);
//     org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var58, (org.jfree.chart.plot.Plot)var61, false);
//     boolean var70 = var43.equals((java.lang.Object)var58);
//     java.awt.Color var72 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var76 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var77 = var72.getRGBColorComponents(var76);
//     org.jfree.chart.text.TextMeasurer var80 = null;
//     org.jfree.chart.text.TextBlock var81 = org.jfree.chart.text.TextUtilities.createTextBlock("", var58, (java.awt.Paint)var72, 0.0f, 10, var80);
//     var16.setLabelFont(var58);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var32.", var22.equals(var32) == var32.equals(var22));
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    java.awt.Shape var22 = var17.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var23 = null;
    var17.setLabelGenerator(var23);
    org.jfree.data.general.PieDataset var26 = null;
    org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D(var26);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var27);
    int var29 = var28.getBackgroundImageAlignment();
    var17.addChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
    org.jfree.chart.renderer.category.IntervalBarRenderer var32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var34);
    org.jfree.chart.renderer.category.IntervalBarRenderer var36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var38 = null;
    var36.setSeriesItemLabelFont(1, var38);
    boolean var40 = var36.getBaseSeriesVisibleInLegend();
    java.awt.Paint var43 = var36.getItemOutlinePaint(13, 100);
    var32.setBaseItemLabelPaint(var43);
    var17.setSectionPaint((java.lang.Comparable)(short)100, var43);
    org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("Default Group", var14, var43);
    org.jfree.data.general.SeriesChangeEvent var47 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     java.lang.Number[][] var0 = null;
//     java.lang.Number[] var1 = null;
//     java.lang.Number[][] var2 = new java.lang.Number[][] { var1};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
//     org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var3, (java.lang.Comparable)"org.jfree.chart.ChartColor[r=0,g=4,b=0]");
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 1.0d);
//     org.jfree.chart.util.HorizontalAlignment var5 = null;
//     org.jfree.chart.util.VerticalAlignment var6 = null;
//     org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement(var5, var6, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var10 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var11 = null;
//     var10.addChangeListener(var11);
//     org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var9, (org.jfree.data.general.Dataset)var10, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     boolean var15 = var4.equals((java.lang.Object)var10);
//     
//     // Checks the contract:  equals-hashcode on var4 and var9
//     assertTrue("Contract failed: equals-hashcode on var4 and var9", var4.equals(var9) ? var4.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var4
//     assertTrue("Contract failed: equals-hashcode on var9 and var4", var9.equals(var4) ? var9.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     double var16 = var15.getHeight();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getLegendItemGraphicPadding();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var20 = null;
//     var18.setSeriesItemLabelFont(1, var20);
//     double var22 = var18.getItemMargin();
//     boolean var24 = var18.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var26 = null;
//     var25.rendererChanged(var26);
//     var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var25);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var33 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var30.setRangeWithMargins((org.jfree.data.Range)var33, false, true);
//     org.jfree.data.Range var37 = var30.getDefaultAutoRange();
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.axis.AxisState var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     java.util.List var42 = var30.refreshTicks(var38, var39, var40, var41);
//     java.awt.Font var43 = var30.getLabelFont();
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot3D var46 = new org.jfree.chart.plot.PiePlot3D(var45);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var46);
//     var46.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var50 = var46.getURLGenerator();
//     java.awt.Shape var51 = var46.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var52 = null;
//     var46.setLabelGenerator(var52);
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.PiePlot3D var56 = new org.jfree.chart.plot.PiePlot3D(var55);
//     org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var56);
//     int var58 = var57.getBackgroundImageAlignment();
//     var46.addChangeListener((org.jfree.chart.event.PlotChangeListener)var57);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var61 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var63 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var61.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var63);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var65 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var67 = null;
//     var65.setSeriesItemLabelFont(1, var67);
//     boolean var69 = var65.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var72 = var65.getItemOutlinePaint(13, 100);
//     var61.setBaseItemLabelPaint(var72);
//     var46.setSectionPaint((java.lang.Comparable)(short)100, var72);
//     org.jfree.chart.block.LabelBlock var75 = new org.jfree.chart.block.LabelBlock("Default Group", var43, var72);
//     java.awt.geom.Rectangle2D var76 = var75.getBounds();
//     org.jfree.chart.util.RectangleInsets var77 = var75.getPadding();
//     var25.setInsets(var77);
//     java.lang.String var79 = var77.toString();
//     var15.setPadding(var77);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var3.", var18.equals(var3) == var3.equals(var18));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var65 and var3.", var65.equals(var3) == var3.equals(var65));
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    java.awt.Stroke var16 = var13.getBorderStroke();
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var19 = var17.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var21 = var20.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var20.getBaseItemLabelGenerator();
    java.awt.Paint var24 = null;
    var20.setSeriesFillPaint(1, var24, false);
    var20.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var20.getLegendItemLabelGenerator();
    var17.setLegendItemToolTipGenerator(var30);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.util.Size2D var34 = var32.arrange(var33);
    var13.addLegend(var32);
    org.jfree.chart.title.Title var37 = var13.getSubtitle(1);
    org.jfree.chart.block.BlockFrame var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var37.setFrame(var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(15);
    java.lang.String var3 = var2.getDescription();
    java.lang.String var4 = var2.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addYears((-435), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var1.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var1.getBaseItemLabelGenerator();
//     java.awt.Paint var5 = null;
//     var1.setSeriesFillPaint(1, var5, false);
//     var1.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var1.getSeriesPositiveItemLabelPosition(100);
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var14.setRangeWithMargins((org.jfree.data.Range)var17, false, true);
//     org.jfree.data.Range var21 = var14.getDefaultAutoRange();
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.AxisState var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     java.util.List var26 = var14.refreshTicks(var22, var23, var24, var25);
//     java.awt.Font var27 = var14.getLabelFont();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D(var29);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var30);
//     var30.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var34 = var30.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var35 = null;
//     var30.axisChanged(var35);
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var27, (org.jfree.chart.plot.Plot)var30, false);
//     boolean var39 = var12.equals((java.lang.Object)var27);
//     java.awt.Color var41 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var45 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var46 = var41.getRGBColorComponents(var45);
//     org.jfree.chart.text.TextMeasurer var49 = null;
//     org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var27, (java.awt.Paint)var41, 0.0f, 10, var49);
//     java.util.List var51 = var50.getLines();
//     org.jfree.chart.text.TextLine var53 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
//     var50.addLine(var53);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var55 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var57 = var55.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var58 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var60 = null;
//     var58.setSeriesItemLabelFont(1, var60);
//     double var62 = var58.getItemMargin();
//     boolean var64 = var58.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var65 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var66 = null;
//     var65.rendererChanged(var66);
//     var58.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var65);
//     var55.addChangeListener((org.jfree.chart.event.RendererChangeListener)var65);
//     boolean var70 = var50.equals((java.lang.Object)var65);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var55 and var1.", var55.equals(var1) == var1.equals(var55));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var58 and var1.", var58.equals(var1) == var1.equals(var58));
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
//     var2.setLabelGenerator(var8);
//     java.lang.Object var10 = var2.clone();
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
//     java.awt.geom.Point2D var13 = var11.getQuadrantOrigin();
//     org.jfree.chart.util.RectangleInsets var14 = var11.getAxisOffset();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var18);
//     var18.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var22 = var18.getURLGenerator();
//     java.awt.Shape var23 = var18.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var24 = null;
//     var18.setLabelGenerator(var24);
//     java.lang.Object var26 = var18.clone();
//     boolean var27 = var15.equals((java.lang.Object)var18);
//     org.jfree.chart.util.SortOrder var28 = var15.getRowRenderingOrder();
//     var15.setDrawSharedDomainAxis(true);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var33 = null;
//     var31.setSeriesItemLabelFont(1, var33);
//     double var35 = var31.getItemMargin();
//     boolean var37 = var31.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var38 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var39 = null;
//     var38.rendererChanged(var39);
//     var31.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var38);
//     org.jfree.data.general.Dataset var43 = null;
//     org.jfree.data.general.DatasetChangeEvent var44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var43);
//     var38.datasetChanged(var44);
//     var15.datasetChanged(var44);
//     org.jfree.data.general.Dataset var47 = var44.getDataset();
//     var11.datasetChanged(var44);
//     var2.datasetChanged(var44);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var19
//     assertTrue("Contract failed: equals-hashcode on var3 and var19", var3.equals(var19) ? var3.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var3
//     assertTrue("Contract failed: equals-hashcode on var19 and var3", var19.equals(var3) ? var19.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var26
//     assertTrue("Contract failed: equals-hashcode on var10 and var26", var10.equals(var26) ? var10.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var10
//     assertTrue("Contract failed: equals-hashcode on var26 and var10", var26.equals(var10) ? var26.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var5 = null;
    var3.setSeriesItemLabelFont(1, var5);
    double var7 = var3.getItemMargin();
    boolean var9 = var3.isSeriesVisibleInLegend(1);
    java.lang.Boolean var11 = var3.getSeriesCreateEntities(1);
    java.awt.Paint var13 = var3.getSeriesItemLabelPaint((-435));
    org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var16 = null;
    var14.setSeriesItemLabelFont(1, var16);
    boolean var18 = var14.getBaseSeriesVisibleInLegend();
    java.awt.Paint var21 = var14.getItemOutlinePaint(13, 100);
    var3.setBaseFillPaint(var21, true);
    var3.setSeriesCreateEntities(2, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var27 = var3.getBaseNegativeItemLabelPosition();
    boolean var28 = var2.equals((java.lang.Object)var27);
    org.jfree.data.DefaultKeyedValues2D var29 = new org.jfree.data.DefaultKeyedValues2D();
    boolean var30 = var2.equals((java.lang.Object)var29);
    org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
    java.util.Date var32 = var31.getEnd();
    org.jfree.data.time.RegularTimePeriod var33 = var31.previous();
    int var34 = var29.getColumnIndex((java.lang.Comparable)var31);
    java.lang.Number var36 = var0.getQ3Value((java.lang.Comparable)var31, (java.lang.Comparable)"Nearest");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var39 = var0.getQ3Value(2, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.95f);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    var1.addFragment(var3);
    java.awt.Font var5 = var3.getFont();
    var0.addFragment(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
    var0.clear();
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.util.RectangleAnchor var16 = null;
//     var15.setLegendItemGraphicLocation(var16);
//     org.jfree.chart.block.BlockContainer var18 = var15.getItemContainer();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.lang.Object var21 = var20.clone();
//     var20.setDrawOutlines(true);
//     org.jfree.chart.plot.IntervalMarker var27 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var28 = var27.getAlpha();
//     java.awt.Paint var29 = var27.getPaint();
//     java.awt.Font var30 = var27.getLabelFont();
//     var20.setSeriesItemLabelFont(100, var30, false);
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("", var30);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var36 = var34.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var38 = var37.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var39 = var37.getBaseItemLabelGenerator();
//     java.awt.Paint var41 = null;
//     var37.setSeriesFillPaint(1, var41, false);
//     var37.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var47 = var37.getLegendItemLabelGenerator();
//     var34.setLegendItemToolTipGenerator(var47);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     java.lang.Object var50 = null;
//     boolean var51 = var49.equals(var50);
//     java.awt.Paint var52 = var49.getItemPaint();
//     org.jfree.chart.util.HorizontalAlignment var53 = var49.getHorizontalAlignment();
//     var33.setTextAlignment(var53);
//     var15.setHorizontalAlignment(var53);
//     
//     // Checks the contract:  equals-hashcode on var13 and var47
//     assertTrue("Contract failed: equals-hashcode on var13 and var47", var13.equals(var47) ? var13.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var13
//     assertTrue("Contract failed: equals-hashcode on var47 and var13", var47.equals(var13) ? var47.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Object var1 = var0.clone();
    boolean var3 = var0.equals((java.lang.Object)"First");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.util.List var5 = var4.getColumnKeys();
    boolean var6 = var0.equals((java.lang.Object)var4);
    java.util.List var7 = var4.getColumnKeys();
    java.util.List var8 = var4.getColumnKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var3);
    java.lang.Object var5 = var3.clone();
    java.awt.geom.Point2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var3.getSubplotIndex(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    int var4 = var3.getBackgroundImageAlignment();
    java.awt.Image var5 = var3.getBackgroundImage();
    org.jfree.chart.entity.EntityCollection var8 = null;
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo(var8);
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    org.jfree.data.time.TimePeriodFormatException var12 = new org.jfree.data.time.TimePeriodFormatException("Default Group");
    boolean var13 = var9.equals((java.lang.Object)"Default Group");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var14 = var3.createBufferedImage(0, 15, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     int var1 = var0.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 2014);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var2);
    org.jfree.chart.util.GradientPaintTransformer var4 = var0.getGradientPaintTransformer();
    boolean var7 = var0.getItemCreateEntity(10, 255);
    org.jfree.chart.event.RendererChangeListener var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeChangeListener(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
//     var3.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
//     java.awt.Shape var8 = var3.getLegendItemShape();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     double var10 = var9.getCategoryMargin();
//     boolean var11 = var3.equals((java.lang.Object)var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var3);
//     var12.clearSubtitles();
//     java.util.List var14 = var12.getSubtitles();
//     java.awt.Paint var15 = var12.getBackgroundPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.lang.Object var18 = var17.clone();
//     var17.setDrawOutlines(true);
//     org.jfree.chart.plot.IntervalMarker var24 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var25 = var24.getAlpha();
//     java.awt.Paint var26 = var24.getPaint();
//     java.awt.Font var27 = var24.getLabelFont();
//     var17.setSeriesItemLabelFont(100, var27, false);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var27);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var33 = var31.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var35 = var34.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var34.getBaseItemLabelGenerator();
//     java.awt.Paint var38 = null;
//     var34.setSeriesFillPaint(1, var38, false);
//     var34.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var44 = var34.getLegendItemLabelGenerator();
//     var31.setLegendItemToolTipGenerator(var44);
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     java.awt.Paint var49 = var46.getItemPaint();
//     org.jfree.chart.util.HorizontalAlignment var50 = var46.getHorizontalAlignment();
//     var30.setTextAlignment(var50);
//     var12.removeSubtitle((org.jfree.chart.title.Title)var30);
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.PiePlot3D var56 = new org.jfree.chart.plot.PiePlot3D(var55);
//     org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var56);
//     var56.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var60 = var56.getURLGenerator();
//     java.awt.Shape var61 = var56.getLegendItemShape();
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis();
//     double var63 = var62.getCategoryMargin();
//     boolean var64 = var56.equals((java.lang.Object)var63);
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var56);
//     var65.clearSubtitles();
//     java.util.List var67 = var65.getSubtitles();
//     var30.addChangeListener((org.jfree.chart.event.TitleChangeListener)var65);
//     
//     // Checks the contract:  equals-hashcode on var3 and var56
//     assertTrue("Contract failed: equals-hashcode on var3 and var56", var3.equals(var56) ? var3.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var3
//     assertTrue("Contract failed: equals-hashcode on var56 and var3", var56.equals(var3) ? var56.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var57
//     assertTrue("Contract failed: equals-hashcode on var4 and var57", var4.equals(var57) ? var4.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var65
//     assertTrue("Contract failed: equals-hashcode on var12 and var65", var12.equals(var65) ? var12.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var4
//     assertTrue("Contract failed: equals-hashcode on var57 and var4", var57.equals(var4) ? var57.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var12
//     assertTrue("Contract failed: equals-hashcode on var65 and var12", var65.equals(var12) ? var65.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var1.addChangeListener(var2);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)'4');
    org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var10 = var9.getUpArrow();
    java.awt.Font var11 = var9.getLabelFont();
    java.text.DateFormat var12 = var9.getDateFormatOverride();
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D(var14);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var15);
    var15.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var19 = var15.getURLGenerator();
    java.awt.Shape var20 = var15.getLegendItemShape();
    org.jfree.chart.util.Rotation var21 = var15.getDirection();
    org.jfree.chart.util.RectangleInsets var22 = var15.getInsets();
    var9.setLabelInsets(var22);
    boolean var24 = var7.equals((java.lang.Object)var9);
    org.jfree.data.general.PieDataset var27 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var6, (java.lang.Comparable)var24, (-1.0d), 12);
    java.lang.Comparable var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var31 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var27, var28, 4.0d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    double var8 = var7.getCategoryMargin();
    var7.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var12 = var7.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    org.jfree.data.general.SeriesChangeEvent var13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var7);
    var0.seriesChanged(var13);
    java.lang.Comparable var15 = null;
    int var16 = var0.indexOf(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var0.getStartValue((java.lang.Comparable)"black", (java.lang.Comparable)1.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
    var0.clear();
    java.lang.Object var4 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var0.getValue(12, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
//     var2.setShadowYOffset(0.0d);
//     var2.setShadowYOffset(1.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var9 = var8.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getBaseItemLabelGenerator();
//     double var11 = var8.getBase();
//     java.awt.Stroke var12 = var8.getBaseOutlineStroke();
//     var2.setOutlineStroke(var12);
//     var2.setDepthFactor(0.0d);
//     org.jfree.chart.util.RectangleInsets var16 = var2.getInsets();
//     java.awt.Paint var17 = var2.getShadowPaint();
//     boolean var18 = var2.getLabelLinksVisible();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D(var25);
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var26);
//     var26.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var30 = var26.getURLGenerator();
//     java.awt.Shape var31 = var26.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var32 = null;
//     var26.setLabelGenerator(var32);
//     java.lang.Object var34 = var26.clone();
//     boolean var35 = var23.equals((java.lang.Object)var26);
//     org.jfree.chart.util.SortOrder var36 = var23.getRowRenderingOrder();
//     java.lang.Object var37 = null;
//     boolean var38 = var36.equals(var37);
//     var19.setRowRenderingOrder(var36);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.lang.Object var41 = var40.clone();
//     org.jfree.chart.urls.StandardCategoryURLGenerator var45 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "org.jfree.chart.event.ChartChangeEvent[source=true]", "");
//     org.jfree.chart.renderer.category.IntervalBarRenderer var46 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var48 = var46.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var50 = var49.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var51 = var49.getBaseItemLabelGenerator();
//     java.awt.Paint var53 = null;
//     var49.setSeriesFillPaint(1, var53, false);
//     var49.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var59 = var49.getLegendItemLabelGenerator();
//     var46.setLegendItemToolTipGenerator(var59);
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46);
//     java.lang.Object var62 = null;
//     boolean var63 = var61.equals(var62);
//     java.awt.Paint var64 = var61.getItemPaint();
//     boolean var65 = var45.equals((java.lang.Object)var64);
//     var40.setBasePaint(var64, true);
//     var19.setDomainGridlinePaint(var64);
//     var2.setLabelOutlinePaint(var64);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var49.", var8.equals(var49) == var49.equals(var8));
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "Default Group"+ "'", var0.equals("Default Group"));
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    int var16 = var2.getPieIndex();
    java.awt.Paint var17 = var2.getBaseSectionPaint();
    var2.setShadowYOffset(100.0d);
    org.jfree.chart.util.RectangleInsets var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setInsets(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var2 = null;
    var0.setSeriesItemLabelFont(1, var2);
    double var4 = var0.getItemMargin();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(1);
    var0.setBaseItemLabelsVisible(true, false);
    int var12 = var0.getRowCount();
    var0.setBaseCreateEntities(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
//     var3.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
//     java.awt.Shape var8 = var3.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
//     var3.setLabelGenerator(var9);
//     java.lang.Object var11 = var3.clone();
//     boolean var12 = var0.equals((java.lang.Object)var3);
//     java.awt.Color var14 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var15 = var14.getTransparency();
//     var0.setRangeCrosshairPaint((java.awt.Paint)var14);
//     org.jfree.chart.entity.EntityCollection var19 = null;
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo(var19);
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = var20.getPlotInfo();
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var26 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var28 = var26.lookupSeriesShape((-1));
//     var25.setUpArrow(var28);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var34 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var31.setRangeWithMargins((org.jfree.data.Range)var34, false, true);
//     org.jfree.data.Range var38 = var31.getDefaultAutoRange();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.axis.AxisState var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     java.util.List var43 = var31.refreshTicks(var39, var40, var41, var42);
//     java.awt.Font var44 = var31.getLabelFont();
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D(var46);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var47);
//     var47.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var51 = var47.getURLGenerator();
//     java.awt.Shape var52 = var47.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var53 = null;
//     var47.setLabelGenerator(var53);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.PiePlot3D var57 = new org.jfree.chart.plot.PiePlot3D(var56);
//     org.jfree.chart.JFreeChart var58 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var57);
//     int var59 = var58.getBackgroundImageAlignment();
//     var47.addChangeListener((org.jfree.chart.event.PlotChangeListener)var58);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var62 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var64 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var62.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var64);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var66 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var68 = null;
//     var66.setSeriesItemLabelFont(1, var68);
//     boolean var70 = var66.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var73 = var66.getItemOutlinePaint(13, 100);
//     var62.setBaseItemLabelPaint(var73);
//     var47.setSectionPaint((java.lang.Comparable)(short)100, var73);
//     org.jfree.chart.block.LabelBlock var76 = new org.jfree.chart.block.LabelBlock("Default Group", var44, var73);
//     java.awt.geom.Rectangle2D var77 = var76.getBounds();
//     boolean var78 = org.jfree.chart.util.ShapeUtilities.equal(var28, (java.awt.Shape)var77);
//     java.awt.geom.Point2D var79 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-7.0d), 0.0d, var77);
//     var0.zoomRangeAxes((-7.0d), 100.0d, var22, var79);
//     org.jfree.chart.axis.CategoryAnchor var81 = var0.getDomainGridlinePosition();
//     org.jfree.chart.entity.EntityCollection var84 = null;
//     org.jfree.chart.ChartRenderingInfo var85 = new org.jfree.chart.ChartRenderingInfo(var84);
//     java.awt.geom.Rectangle2D var86 = var85.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var87 = var85.getPlotInfo();
//     var0.handleClick(100, 100, var87);
//     
//     // Checks the contract:  equals-hashcode on var20 and var85
//     assertTrue("Contract failed: equals-hashcode on var20 and var85", var20.equals(var85) ? var20.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var20
//     assertTrue("Contract failed: equals-hashcode on var85 and var20", var85.equals(var20) ? var85.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var87
//     assertTrue("Contract failed: equals-hashcode on var22 and var87", var22.equals(var87) ? var22.hashCode() == var87.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var87 and var22
//     assertTrue("Contract failed: equals-hashcode on var87 and var22", var87.equals(var22) ? var87.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var4 = var3.getAlpha();
//     java.awt.Paint var5 = var3.getPaint();
//     var0.setAngleLabelPaint(var5);
//     org.jfree.chart.entity.EntityCollection var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo(var8);
//     java.awt.geom.Rectangle2D var10 = var9.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = var9.getPlotInfo();
//     java.awt.geom.Rectangle2D var12 = var11.getPlotArea();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D(var15);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var16);
//     var16.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var20 = var16.getURLGenerator();
//     java.awt.Shape var21 = var16.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var22 = null;
//     var16.setLabelGenerator(var22);
//     java.lang.Object var24 = var16.clone();
//     boolean var25 = var13.equals((java.lang.Object)var16);
//     java.awt.Color var27 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     int var28 = var27.getTransparency();
//     var13.setRangeCrosshairPaint((java.awt.Paint)var27);
//     org.jfree.chart.entity.EntityCollection var32 = null;
//     org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
//     java.awt.geom.Rectangle2D var34 = var33.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var35 = var33.getPlotInfo();
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var41 = var39.lookupSeriesShape((-1));
//     var38.setUpArrow(var41);
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var47 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var44.setRangeWithMargins((org.jfree.data.Range)var47, false, true);
//     org.jfree.data.Range var51 = var44.getDefaultAutoRange();
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.axis.AxisState var53 = null;
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.util.RectangleEdge var55 = null;
//     java.util.List var56 = var44.refreshTicks(var52, var53, var54, var55);
//     java.awt.Font var57 = var44.getLabelFont();
//     org.jfree.data.general.PieDataset var59 = null;
//     org.jfree.chart.plot.PiePlot3D var60 = new org.jfree.chart.plot.PiePlot3D(var59);
//     org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var60);
//     var60.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var64 = var60.getURLGenerator();
//     java.awt.Shape var65 = var60.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var66 = null;
//     var60.setLabelGenerator(var66);
//     org.jfree.data.general.PieDataset var69 = null;
//     org.jfree.chart.plot.PiePlot3D var70 = new org.jfree.chart.plot.PiePlot3D(var69);
//     org.jfree.chart.JFreeChart var71 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var70);
//     int var72 = var71.getBackgroundImageAlignment();
//     var60.addChangeListener((org.jfree.chart.event.PlotChangeListener)var71);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var75 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var77 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var75.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var77);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var79 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var81 = null;
//     var79.setSeriesItemLabelFont(1, var81);
//     boolean var83 = var79.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var86 = var79.getItemOutlinePaint(13, 100);
//     var75.setBaseItemLabelPaint(var86);
//     var60.setSectionPaint((java.lang.Comparable)(short)100, var86);
//     org.jfree.chart.block.LabelBlock var89 = new org.jfree.chart.block.LabelBlock("Default Group", var57, var86);
//     java.awt.geom.Rectangle2D var90 = var89.getBounds();
//     boolean var91 = org.jfree.chart.util.ShapeUtilities.equal(var41, (java.awt.Shape)var90);
//     java.awt.geom.Point2D var92 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-7.0d), 0.0d, var90);
//     var13.zoomRangeAxes((-7.0d), 100.0d, var35, var92);
//     var0.zoomRangeAxes(4.0d, var11, var92);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesLinesVisible(15, (java.lang.Boolean)true);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-435));
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var0.getColumnKey(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    double var5 = var4.getCategoryMargin();
    var4.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var9 = var4.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var10 = var0.getCategoriesForAxis(var4);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot3D var14 = new org.jfree.chart.plot.PiePlot3D(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var14);
    var14.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var18 = var14.getURLGenerator();
    java.awt.Shape var19 = var14.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var20 = null;
    var14.setLabelGenerator(var20);
    java.lang.Object var22 = var14.clone();
    boolean var23 = var11.equals((java.lang.Object)var14);
    org.jfree.chart.util.SortOrder var24 = var11.getRowRenderingOrder();
    var0.setColumnRenderingOrder(var24);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
    double var28 = var27.getCategoryMargin();
    org.jfree.chart.axis.CategoryAxis[] var29 = new org.jfree.chart.axis.CategoryAxis[] { var27};
    var26.setDomainAxes(var29);
    boolean var31 = var24.equals((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getMaxIcon();
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.ItemLabelPosition var14 = var3.getSeriesPositiveItemLabelPosition(100);
    var0.setSeriesPositiveItemLabelPosition(12, var14);
    double var16 = var14.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    java.lang.Object var11 = var3.clone();
    boolean var12 = var0.equals((java.lang.Object)var3);
    java.awt.Color var14 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var15 = var14.getTransparency();
    var0.setRangeCrosshairPaint((java.awt.Paint)var14);
    org.jfree.chart.entity.EntityCollection var19 = null;
    org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo(var19);
    java.awt.geom.Rectangle2D var21 = var20.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var22 = var20.getPlotInfo();
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var26 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var28 = var26.lookupSeriesShape((-1));
    var25.setUpArrow(var28);
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var34 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var31.setRangeWithMargins((org.jfree.data.Range)var34, false, true);
    org.jfree.data.Range var38 = var31.getDefaultAutoRange();
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.axis.AxisState var40 = null;
    java.awt.geom.Rectangle2D var41 = null;
    org.jfree.chart.util.RectangleEdge var42 = null;
    java.util.List var43 = var31.refreshTicks(var39, var40, var41, var42);
    java.awt.Font var44 = var31.getLabelFont();
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D(var46);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var47);
    var47.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var51 = var47.getURLGenerator();
    java.awt.Shape var52 = var47.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var53 = null;
    var47.setLabelGenerator(var53);
    org.jfree.data.general.PieDataset var56 = null;
    org.jfree.chart.plot.PiePlot3D var57 = new org.jfree.chart.plot.PiePlot3D(var56);
    org.jfree.chart.JFreeChart var58 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var57);
    int var59 = var58.getBackgroundImageAlignment();
    var47.addChangeListener((org.jfree.chart.event.PlotChangeListener)var58);
    org.jfree.chart.renderer.category.IntervalBarRenderer var62 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var64 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var62.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var64);
    org.jfree.chart.renderer.category.IntervalBarRenderer var66 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var68 = null;
    var66.setSeriesItemLabelFont(1, var68);
    boolean var70 = var66.getBaseSeriesVisibleInLegend();
    java.awt.Paint var73 = var66.getItemOutlinePaint(13, 100);
    var62.setBaseItemLabelPaint(var73);
    var47.setSectionPaint((java.lang.Comparable)(short)100, var73);
    org.jfree.chart.block.LabelBlock var76 = new org.jfree.chart.block.LabelBlock("Default Group", var44, var73);
    java.awt.geom.Rectangle2D var77 = var76.getBounds();
    boolean var78 = org.jfree.chart.util.ShapeUtilities.equal(var28, (java.awt.Shape)var77);
    java.awt.geom.Point2D var79 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-7.0d), 0.0d, var77);
    var0.zoomRangeAxes((-7.0d), 100.0d, var22, var79);
    org.jfree.chart.axis.AxisSpace var81 = var0.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.Comparable var1 = var0.getAggregatedItemsKey();
    var0.setBackgroundAlpha(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Other"+ "'", var1.equals("Other"));

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     java.lang.Number[][] var0 = null;
//     java.lang.Number[] var1 = null;
//     java.lang.Number[][] var2 = new java.lang.Number[][] { var1};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
//     int var4 = var3.getColumnCount();
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("Default Group");
//     java.lang.Comparable var2 = var1.getKey();
//     org.jfree.data.KeyToGroupMap var4 = new org.jfree.data.KeyToGroupMap();
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var7 = var6.getUpArrow();
//     boolean var8 = var4.equals((java.lang.Object)var7);
//     boolean var10 = var4.equals((java.lang.Object)0.0f);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var13 = var12.getUpArrow();
//     java.awt.Shape var14 = var12.getDownArrow();
//     java.util.Date var15 = var12.getMinimumDate();
//     int var16 = var4.getGroupIndex((java.lang.Comparable)var15);
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var19 = var18.getUpArrow();
//     java.awt.Shape var20 = var18.getDownArrow();
//     java.util.Date var21 = var18.getMinimumDate();
//     java.lang.String var22 = var18.getLabel();
//     java.util.Date var23 = var18.getMinimumDate();
//     org.jfree.data.gantt.Task var24 = new org.jfree.data.gantt.Task("Pie 3D Plot", var15, var23);
//     var1.add(var24);
//     org.jfree.data.KeyToGroupMap var27 = new org.jfree.data.KeyToGroupMap();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var30 = var29.getUpArrow();
//     boolean var31 = var27.equals((java.lang.Object)var30);
//     boolean var33 = var27.equals((java.lang.Object)0.0f);
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var36 = var35.getUpArrow();
//     java.awt.Shape var37 = var35.getDownArrow();
//     java.util.Date var38 = var35.getMinimumDate();
//     int var39 = var27.getGroupIndex((java.lang.Comparable)var38);
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var42 = var41.getUpArrow();
//     java.awt.Shape var43 = var41.getDownArrow();
//     java.util.Date var44 = var41.getMinimumDate();
//     java.lang.String var45 = var41.getLabel();
//     java.util.Date var46 = var41.getMinimumDate();
//     org.jfree.data.gantt.Task var47 = new org.jfree.data.gantt.Task("Pie 3D Plot", var38, var46);
//     java.lang.Object var48 = var47.clone();
//     var24.addSubtask(var47);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, 0.2d);
//     boolean var3 = var2.getRenderAsPercentages();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
//     var12.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var16 = var12.getURLGenerator();
//     java.awt.Shape var17 = var12.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var18 = null;
//     var12.setLabelGenerator(var18);
//     java.lang.Object var20 = var12.clone();
//     boolean var21 = var9.equals((java.lang.Object)var12);
//     org.jfree.chart.util.SortOrder var22 = var9.getRowRenderingOrder();
//     java.lang.Object var23 = null;
//     boolean var24 = var22.equals(var23);
//     var5.setRowRenderingOrder(var22);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = var5.getRenderer((-457));
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var29.setRangeWithMargins((org.jfree.data.Range)var32, false, true);
//     org.jfree.data.Range var36 = var29.getDefaultAutoRange();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.AxisState var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     java.util.List var41 = var29.refreshTicks(var37, var38, var39, var40);
//     java.awt.Font var42 = var29.getLabelFont();
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot3D var45 = new org.jfree.chart.plot.PiePlot3D(var44);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var45);
//     var45.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var49 = var45.getURLGenerator();
//     java.awt.Shape var50 = var45.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var51 = null;
//     var45.setLabelGenerator(var51);
//     org.jfree.data.general.PieDataset var54 = null;
//     org.jfree.chart.plot.PiePlot3D var55 = new org.jfree.chart.plot.PiePlot3D(var54);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var55);
//     int var57 = var56.getBackgroundImageAlignment();
//     var45.addChangeListener((org.jfree.chart.event.PlotChangeListener)var56);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var62 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var60.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var62);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var64 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var66 = null;
//     var64.setSeriesItemLabelFont(1, var66);
//     boolean var68 = var64.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var71 = var64.getItemOutlinePaint(13, 100);
//     var60.setBaseItemLabelPaint(var71);
//     var45.setSectionPaint((java.lang.Comparable)(short)100, var71);
//     org.jfree.chart.block.LabelBlock var74 = new org.jfree.chart.block.LabelBlock("Default Group", var42, var71);
//     java.awt.geom.Rectangle2D var75 = var74.getBounds();
//     var2.drawBackground(var4, var5, var75);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    java.lang.Object var11 = var3.clone();
    boolean var12 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.renderer.category.StackedAreaRenderer var14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Paint var16 = var14.lookupSeriesOutlinePaint(255);
    var3.setShadowPaint(var16);
    float var18 = var3.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0f);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.0f));
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var4.setRangeWithMargins((org.jfree.data.Range)var7, false, true);
    org.jfree.data.Range var11 = var4.getDefaultAutoRange();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.AxisState var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.util.RectangleEdge var15 = null;
    java.util.List var16 = var4.refreshTicks(var12, var13, var14, var15);
    java.awt.Font var17 = var4.getLabelFont();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var20);
    var20.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var24 = var20.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var25 = null;
    var20.axisChanged(var25);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var17, (org.jfree.chart.plot.Plot)var20, false);
    var28.setBackgroundImageAlignment(10);
    org.jfree.chart.plot.Plot var31 = var28.getPlot();
    org.jfree.chart.event.ChartProgressEvent var34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1.0f), var28, (-1), 0);
    int var35 = var28.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getRowIndex((java.lang.Comparable)(-1.05d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var5 = null;
    var3.setSeriesItemLabelFont(1, var5);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var15 = var13.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getCategoryMargin();
    boolean var11 = var3.equals((java.lang.Object)var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var14 = var12.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var3.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
//     java.awt.Paint var7 = null;
//     var3.setSeriesFillPaint(1, var7, false);
//     var3.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var13);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.util.RectangleAnchor var16 = null;
//     var15.setLegendItemGraphicLocation(var16);
//     java.lang.Object var18 = var15.clone();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var21 = null;
//     var19.setSeriesItemLabelFont(1, var21);
//     double var23 = var19.getItemMargin();
//     boolean var25 = var19.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var26 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var27 = null;
//     var26.rendererChanged(var27);
//     var19.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var34 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var31.setRangeWithMargins((org.jfree.data.Range)var34, false, true);
//     org.jfree.data.Range var38 = var31.getDefaultAutoRange();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.axis.AxisState var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     java.util.List var43 = var31.refreshTicks(var39, var40, var41, var42);
//     java.awt.Font var44 = var31.getLabelFont();
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D(var46);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var47);
//     var47.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var51 = var47.getURLGenerator();
//     java.awt.Shape var52 = var47.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var53 = null;
//     var47.setLabelGenerator(var53);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.PiePlot3D var57 = new org.jfree.chart.plot.PiePlot3D(var56);
//     org.jfree.chart.JFreeChart var58 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var57);
//     int var59 = var58.getBackgroundImageAlignment();
//     var47.addChangeListener((org.jfree.chart.event.PlotChangeListener)var58);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var62 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var64 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var62.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var64);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var66 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var68 = null;
//     var66.setSeriesItemLabelFont(1, var68);
//     boolean var70 = var66.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var73 = var66.getItemOutlinePaint(13, 100);
//     var62.setBaseItemLabelPaint(var73);
//     var47.setSectionPaint((java.lang.Comparable)(short)100, var73);
//     org.jfree.chart.block.LabelBlock var76 = new org.jfree.chart.block.LabelBlock("Default Group", var44, var73);
//     java.awt.geom.Rectangle2D var77 = var76.getBounds();
//     org.jfree.chart.util.RectangleInsets var78 = var76.getPadding();
//     var26.setInsets(var78);
//     double var80 = var78.getBottom();
//     var15.setLegendItemGraphicPadding(var78);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var3.", var19.equals(var3) == var3.equals(var19));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var66 and var3.", var66.equals(var3) == var3.equals(var66));
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var2 = var1.clone();
    var1.setDrawOutlines(true);
    org.jfree.chart.plot.IntervalMarker var8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
    float var9 = var8.getAlpha();
    java.awt.Paint var10 = var8.getPaint();
    java.awt.Font var11 = var8.getLabelFont();
    var1.setSeriesItemLabelFont(100, var11, false);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var11);
    org.jfree.chart.util.VerticalAlignment var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setVerticalAlignment(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("Default Group");
    java.lang.Comparable var2 = var1.getKey();
    org.jfree.data.KeyToGroupMap var4 = new org.jfree.data.KeyToGroupMap();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var7 = var6.getUpArrow();
    boolean var8 = var4.equals((java.lang.Object)var7);
    boolean var10 = var4.equals((java.lang.Object)0.0f);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var13 = var12.getUpArrow();
    java.awt.Shape var14 = var12.getDownArrow();
    java.util.Date var15 = var12.getMinimumDate();
    int var16 = var4.getGroupIndex((java.lang.Comparable)var15);
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var19 = var18.getUpArrow();
    java.awt.Shape var20 = var18.getDownArrow();
    java.util.Date var21 = var18.getMinimumDate();
    java.lang.String var22 = var18.getLabel();
    java.util.Date var23 = var18.getMinimumDate();
    org.jfree.data.gantt.Task var24 = new org.jfree.data.gantt.Task("Pie 3D Plot", var15, var23);
    var1.add(var24);
    java.lang.Class var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var29 = var28.getUpArrow();
    java.awt.Shape var30 = var28.getDownArrow();
    java.util.Date var31 = var28.getMinimumDate();
    java.util.TimeZone var32 = null;
    org.jfree.data.time.RegularTimePeriod var33 = org.jfree.data.time.RegularTimePeriod.createInstance(var26, var31, var32);
    org.jfree.data.time.Month var34 = new org.jfree.data.time.Month(var31);
    var24.setDuration((org.jfree.data.time.TimePeriod)var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var37 = var24.getSubtask(12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Default Group"+ "'", var2.equals("Default Group"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "hi!"+ "'", var22.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var3 = null;
//     var1.setSeriesItemLabelFont(1, var3);
//     double var5 = var1.getItemMargin();
//     boolean var7 = var1.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var10 = var1.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var12.setRangeWithMargins((org.jfree.data.Range)var15, false, true);
//     org.jfree.data.Range var19 = var12.getDefaultAutoRange();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.axis.AxisState var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.util.RectangleEdge var23 = null;
//     java.util.List var24 = var12.refreshTicks(var20, var21, var22, var23);
//     java.awt.Font var25 = var12.getLabelFont();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var28);
//     var28.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var32 = var28.getURLGenerator();
//     java.awt.Shape var33 = var28.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var34 = null;
//     var28.setLabelGenerator(var34);
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot3D var38 = new org.jfree.chart.plot.PiePlot3D(var37);
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var38);
//     int var40 = var39.getBackgroundImageAlignment();
//     var28.addChangeListener((org.jfree.chart.event.PlotChangeListener)var39);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var43 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var45 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var43.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var45);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var49 = null;
//     var47.setSeriesItemLabelFont(1, var49);
//     boolean var51 = var47.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var54 = var47.getItemOutlinePaint(13, 100);
//     var43.setBaseItemLabelPaint(var54);
//     var28.setSectionPaint((java.lang.Comparable)(short)100, var54);
//     org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("Default Group", var25, var54);
//     java.awt.geom.Rectangle2D var58 = var57.getBounds();
//     var1.setBaseShape((java.awt.Shape)var58, false);
//     java.awt.Font var63 = var1.getItemLabelFont((-457), 15);
//     org.jfree.data.general.PieDataset var65 = null;
//     org.jfree.chart.plot.PiePlot3D var66 = new org.jfree.chart.plot.PiePlot3D(var65);
//     org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var66);
//     var66.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var70 = var66.getURLGenerator();
//     java.awt.Shape var71 = var66.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var72 = null;
//     var66.setLabelGenerator(var72);
//     org.jfree.data.general.PieDataset var75 = null;
//     org.jfree.chart.plot.PiePlot3D var76 = new org.jfree.chart.plot.PiePlot3D(var75);
//     org.jfree.chart.JFreeChart var77 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var76);
//     int var78 = var77.getBackgroundImageAlignment();
//     var66.addChangeListener((org.jfree.chart.event.PlotChangeListener)var77);
//     int var80 = var66.getPieIndex();
//     java.awt.Paint var81 = var66.getBaseSectionPaint();
//     org.jfree.chart.text.TextMeasurer var83 = null;
//     org.jfree.chart.text.TextBlock var84 = org.jfree.chart.text.TextUtilities.createTextBlock("Other", var63, var81, 100.0f, var83);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.geom.Point2D var2 = var0.getQuadrantOrigin();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var9 = null;
//     var7.setSeriesItemLabelFont(1, var9);
//     boolean var11 = var7.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var14 = var7.getItemOutlinePaint(13, 100);
//     var3.setBaseItemLabelPaint(var14);
//     var0.setDomainTickBandPaint(var14);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.MultiplePiePlot var18 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.util.TableOrder var19 = var18.getDataExtractOrder();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var23 = null;
//     var21.setSeriesItemLabelFont(1, var23);
//     double var25 = var21.getItemMargin();
//     boolean var27 = var21.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var30 = var21.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var35 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var32.setRangeWithMargins((org.jfree.data.Range)var35, false, true);
//     org.jfree.data.Range var39 = var32.getDefaultAutoRange();
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.axis.AxisState var41 = null;
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     java.util.List var44 = var32.refreshTicks(var40, var41, var42, var43);
//     java.awt.Font var45 = var32.getLabelFont();
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.PiePlot3D var48 = new org.jfree.chart.plot.PiePlot3D(var47);
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var48);
//     var48.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var52 = var48.getURLGenerator();
//     java.awt.Shape var53 = var48.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var54 = null;
//     var48.setLabelGenerator(var54);
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.PiePlot3D var58 = new org.jfree.chart.plot.PiePlot3D(var57);
//     org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var58);
//     int var60 = var59.getBackgroundImageAlignment();
//     var48.addChangeListener((org.jfree.chart.event.PlotChangeListener)var59);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var63 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var65 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var63.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var65);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var67 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var69 = null;
//     var67.setSeriesItemLabelFont(1, var69);
//     boolean var71 = var67.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var74 = var67.getItemOutlinePaint(13, 100);
//     var63.setBaseItemLabelPaint(var74);
//     var48.setSectionPaint((java.lang.Comparable)(short)100, var74);
//     org.jfree.chart.block.LabelBlock var77 = new org.jfree.chart.block.LabelBlock("Default Group", var45, var74);
//     java.awt.geom.Rectangle2D var78 = var77.getBounds();
//     var21.setBaseShape((java.awt.Shape)var78, false);
//     var18.drawBackgroundImage(var20, var78);
//     org.jfree.data.gantt.TaskSeriesCollection var82 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var83 = null;
//     var82.addChangeListener(var83);
//     org.jfree.data.general.PieDataset var86 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var82, (-435));
//     org.jfree.data.Range var88 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var82, false);
//     java.util.List var89 = var82.getRowKeys();
//     var0.drawRangeTickBands(var17, var78, var89);
//     
//     // Checks the contract:  equals-hashcode on var5 and var65
//     assertTrue("Contract failed: equals-hashcode on var5 and var65", var5.equals(var65) ? var5.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var5
//     assertTrue("Contract failed: equals-hashcode on var65 and var5", var65.equals(var5) ? var65.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     java.awt.Image var3 = null;
//     org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var3, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
//     java.util.List var8 = var7.getContributors();
//     org.jfree.chart.ui.Library var9 = null;
//     var7.addLibrary(var9);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    var1.setAutoPopulateSeriesOutlineStroke(false);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var2 = null;
    var1.addChangeListener(var2);
    var0.setDataset((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)'4');
    boolean var7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "org.jfree.chart.event.ChartChangeEvent[source=true]", "");
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var6 = var4.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var8 = var7.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var7.getBaseItemLabelGenerator();
    java.awt.Paint var11 = null;
    var7.setSeriesFillPaint(1, var11, false);
    var7.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var7.getLegendItemLabelGenerator();
    var4.setLegendItemToolTipGenerator(var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.lang.Object var20 = null;
    boolean var21 = var19.equals(var20);
    java.awt.Paint var22 = var19.getItemPaint();
    boolean var23 = var3.equals((java.lang.Object)var22);
    java.io.ObjectOutputStream var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var22, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     double var9 = var8.getCategoryMargin();
//     var8.setMaximumCategoryLabelWidthRatio(1.0f);
//     java.lang.String var13 = var8.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
//     java.util.List var14 = var4.getCategoriesForAxis(var8);
//     java.lang.String var15 = var8.getLabelURL();
//     java.util.List var16 = var0.getCategoriesForAxis(var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var3.setRangeWithMargins((org.jfree.data.Range)var6, false, true);
//     org.jfree.data.Range var10 = var3.getDefaultAutoRange();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.AxisState var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     java.util.List var15 = var3.refreshTicks(var11, var12, var13, var14);
//     java.awt.Font var16 = var3.getLabelFont();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
//     var19.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var24 = null;
//     var19.axisChanged(var24);
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var16, (org.jfree.chart.plot.Plot)var19, false);
//     var27.setBackgroundImageAlignment(10);
//     org.jfree.chart.title.TextTitle var30 = var27.getTitle();
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.entity.EntityCollection var32 = null;
//     org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
//     java.awt.geom.Rectangle2D var34 = var33.getChartArea();
//     var30.draw(var31, var34);
//     java.awt.geom.Point2D var36 = null;
//     org.jfree.chart.plot.PlotState var37 = null;
//     org.jfree.chart.entity.EntityCollection var38 = null;
//     org.jfree.chart.ChartRenderingInfo var39 = new org.jfree.chart.ChartRenderingInfo(var38);
//     java.awt.geom.Rectangle2D var40 = var39.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var41 = var39.getPlotInfo();
//     java.awt.geom.Rectangle2D var42 = var41.getPlotArea();
//     org.jfree.chart.util.HorizontalAlignment var43 = null;
//     org.jfree.chart.util.VerticalAlignment var44 = null;
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var48 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var49 = null;
//     var48.addChangeListener(var49);
//     org.jfree.chart.title.LegendItemBlockContainer var52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var47, (org.jfree.data.general.Dataset)var48, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.data.general.Dataset var53 = var52.getDataset();
//     org.jfree.chart.entity.EntityCollection var54 = null;
//     org.jfree.chart.ChartRenderingInfo var55 = new org.jfree.chart.ChartRenderingInfo(var54);
//     java.awt.geom.Rectangle2D var56 = var55.getChartArea();
//     var52.setBounds(var56);
//     var41.setPlotArea(var56);
//     var0.draw(var1, var34, var36, var37, var41);
//     
//     // Checks the contract:  equals-hashcode on var33 and var55
//     assertTrue("Contract failed: equals-hashcode on var33 and var55", var33.equals(var55) ? var33.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var33
//     assertTrue("Contract failed: equals-hashcode on var55 and var33", var55.equals(var33) ? var55.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var6 = null;
//     var4.setSeriesItemLabelFont(1, var6);
//     double var8 = var4.getItemMargin();
//     boolean var10 = var4.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var4.getNegativeItemLabelPosition(13, 4);
//     org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
//     org.jfree.chart.plot.IntervalMarker var20 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var21 = var20.getAlpha();
//     java.awt.Paint var22 = var20.getPaint();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var25 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var23.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var25);
//     org.jfree.chart.util.GradientPaintTransformer var27 = var23.getGradientPaintTransformer();
//     var20.setGradientPaintTransformer(var27);
//     org.jfree.chart.text.TextAnchor var29 = var20.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
//     float var33 = var32.getWidthRatio();
//     org.jfree.chart.text.TextAnchor var34 = var32.getRotationAnchor();
//     org.jfree.chart.plot.IntervalMarker var37 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     org.jfree.chart.text.TextAnchor var38 = var37.getLabelTextAnchor();
//     org.jfree.chart.axis.NumberTick var40 = new org.jfree.chart.axis.NumberTick((java.lang.Number)10.0d, "java.awt.Color[r=0,g=0,b=0]", var34, var38, 0.0d);
//     org.jfree.chart.axis.NumberTick var42 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0f, "RectangleEdge.TOP", var29, var38, 0.0d);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("EXPAND", var1, 10.0f, (-1.0f), var14, 2.0d, var38);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var1 = null;
    var0.addChangeListener(var1);
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    java.util.List var7 = var0.getRowKeys();
    boolean var8 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.gantt.TaskSeries var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    var1.zoomRange((-0.5d), Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("DateTickMarkPosition.START", var1, var2, var3);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)' ', var1, 0, 100);
    int var5 = var4.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.05d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var4 = var2.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var7 = null;
//     var5.setSeriesItemLabelFont(1, var7);
//     double var9 = var5.getItemMargin();
//     boolean var11 = var5.isSeriesVisibleInLegend(1);
//     org.jfree.chart.plot.WaferMapPlot var12 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var13 = null;
//     var12.rendererChanged(var13);
//     var5.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     boolean var17 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.axis.AxisState var18 = new org.jfree.chart.axis.AxisState();
//     var18.setMax(100.0d);
//     var18.cursorDown(0.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var26 = var24.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var27 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var28 = var27.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var27.getBaseItemLabelGenerator();
//     java.awt.Paint var31 = null;
//     var27.setSeriesFillPaint(1, var31, false);
//     var27.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var37 = var27.getLegendItemLabelGenerator();
//     var24.setLegendItemToolTipGenerator(var37);
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.util.Size2D var41 = var39.arrange(var40);
//     org.jfree.chart.util.RectangleEdge var42 = var39.getPosition();
//     var18.moveCursor(100.0d, var42);
//     org.jfree.chart.axis.CategoryLabelPosition var44 = var1.getLabelPosition(var42);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var27.", var2.equals(var27) == var27.equals(var2));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var27.", var5.equals(var27) == var27.equals(var5));
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var2);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    boolean var8 = var4.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var4.getItemOutlinePaint(13, 100);
    var0.setBaseItemLabelPaint(var11);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var15 = var13.getRowIndex((java.lang.Comparable)(-1.05d));
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    boolean var20 = var16.getBaseSeriesVisibleInLegend();
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var20);
    boolean var22 = var13.equals((java.lang.Object)var20);
    org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
    org.jfree.chart.util.Size2D var28 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    java.lang.Object var29 = var28.clone();
    int var30 = var25.compareTo((java.lang.Object)var28);
    var13.addValue(3.0d, (java.lang.Comparable)(short)0, (java.lang.Comparable)var25);
    org.jfree.data.DefaultKeyedValues2D var32 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var33 = var32.getRowKeys();
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var37 = var35.lookupSeriesShape((-1));
    var34.setUpArrow(var37);
    java.util.Date var39 = var34.getMaximumDate();
    int var40 = var32.getColumnIndex((java.lang.Comparable)var39);
    org.jfree.data.DefaultKeyedValues2D var41 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var42 = var41.getRowKeys();
    org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var46 = var44.lookupSeriesShape((-1));
    var43.setUpArrow(var46);
    java.util.Date var48 = var43.getMaximumDate();
    int var49 = var41.getColumnIndex((java.lang.Comparable)var48);
    var13.removeValue((java.lang.Comparable)var40, (java.lang.Comparable)var49);
    org.jfree.data.Range var51 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var54 = var13.getValue(12, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4);
//     java.lang.String var6 = var5.toString();
//     java.lang.Object var7 = var5.getSource();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var11);
//     var11.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var15 = var11.getURLGenerator();
//     java.awt.Shape var16 = var11.getLegendItemShape();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     double var18 = var17.getCategoryMargin();
//     boolean var19 = var11.equals((java.lang.Object)var18);
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var11);
//     var20.clearSubtitles();
//     java.util.List var22 = var20.getSubtitles();
//     var5.setChart(var20);
//     java.lang.Object var24 = var20.clone();
//     org.jfree.chart.event.ChartProgressListener var25 = null;
//     var20.addProgressListener(var25);
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
//     var29.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var33 = var29.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var34 = null;
//     var29.axisChanged(var34);
//     org.jfree.chart.event.PlotChangeEvent var36 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var29);
//     var20.plotChanged(var36);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var30
//     assertTrue("Contract failed: equals-hashcode on var12 and var30", var12.equals(var30) ? var12.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var12
//     assertTrue("Contract failed: equals-hashcode on var30 and var12", var30.equals(var12) ? var30.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
//     var3.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
//     java.awt.Shape var8 = var3.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
//     var3.setLabelGenerator(var9);
//     java.lang.Object var11 = var3.clone();
//     boolean var12 = var0.equals((java.lang.Object)var3);
//     java.util.List var13 = var0.getAnnotations();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.plot.DrawingSupplier var18 = null;
//     var14.setDrawingSupplier(var18);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     double var22 = var21.getCategoryMargin();
//     org.jfree.chart.axis.CategoryAxis[] var23 = new org.jfree.chart.axis.CategoryAxis[] { var21};
//     var20.setDomainAxes(var23);
//     var14.setDomainAxes(var23);
//     var0.setDomainAxes(var23);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.entity.EntityCollection var2 = null;
    org.jfree.chart.ChartRenderingInfo var3 = new org.jfree.chart.ChartRenderingInfo(var2);
    java.awt.geom.Rectangle2D var4 = var3.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var5 = var3.getPlotInfo();
    java.awt.geom.Rectangle2D var6 = var5.getPlotArea();
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    org.jfree.chart.util.VerticalAlignment var8 = null;
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement(var7, var8, 0.0d, 1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var12 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.DatasetChangeListener var13 = null;
    var12.addChangeListener(var13);
    org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, (org.jfree.data.general.Dataset)var12, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    org.jfree.data.general.Dataset var17 = var16.getDataset();
    org.jfree.chart.entity.EntityCollection var18 = null;
    org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo(var18);
    java.awt.geom.Rectangle2D var20 = var19.getChartArea();
    var16.setBounds(var20);
    var5.setPlotArea(var20);
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var25);
    var25.setShadowYOffset(0.0d);
    double var29 = var25.getMaximumLabelWidth();
    org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var32 = null;
    var30.setSeriesItemLabelFont(1, var32);
    boolean var34 = var30.getBaseSeriesVisibleInLegend();
    java.awt.Paint var37 = var30.getItemOutlinePaint(13, 100);
    var25.setBackgroundPaint(var37);
    boolean var39 = var25.isCircular();
    org.jfree.chart.entity.EntityCollection var41 = null;
    org.jfree.chart.ChartRenderingInfo var42 = new org.jfree.chart.ChartRenderingInfo(var41);
    java.awt.geom.Rectangle2D var43 = var42.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var44 = var42.getPlotInfo();
    org.jfree.chart.renderer.category.CategoryItemRendererState var45 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var46 = var0.initialise(var1, var20, (org.jfree.chart.plot.PiePlot)var25, (java.lang.Integer)255, var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
//     int var4 = var3.getSegmentsIncluded();
//     org.jfree.data.KeyToGroupMap var5 = new org.jfree.data.KeyToGroupMap();
//     java.lang.Comparable var7 = var5.getGroup((java.lang.Comparable)(short)1);
//     java.util.List var8 = var5.getGroups();
//     var3.setExceptionSegments(var8);
//     var3.addBaseTimelineException((-2208960000001L));
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var4 = var3.getAlpha();
//     java.awt.Paint var5 = var3.getPaint();
//     var0.setAngleLabelPaint(var5);
//     var0.zoom(Double.NaN);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    boolean var2 = var0.isSeriesItemLabelsVisible(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-457), (java.lang.Boolean)true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    java.awt.Paint var4 = var0.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var6 = null;
//     var4.setSeriesItemLabelFont(1, var6);
//     double var8 = var4.getItemMargin();
//     boolean var10 = var4.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var12 = var4.getSeriesCreateEntities(1);
//     java.awt.Paint var14 = var4.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var17 = null;
//     var15.setSeriesItemLabelFont(1, var17);
//     boolean var19 = var15.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var22 = var15.getItemOutlinePaint(13, 100);
//     var4.setBaseFillPaint(var22, true);
//     var4.setSeriesCreateEntities(2, (java.lang.Boolean)false);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var4.getBaseNegativeItemLabelPosition();
//     boolean var29 = var3.equals((java.lang.Object)var28);
//     org.jfree.data.DefaultKeyedValues2D var30 = new org.jfree.data.DefaultKeyedValues2D();
//     boolean var31 = var3.equals((java.lang.Object)var30);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     java.util.Date var33 = var32.getEnd();
//     org.jfree.data.time.RegularTimePeriod var34 = var32.previous();
//     int var35 = var30.getColumnIndex((java.lang.Comparable)var32);
//     java.lang.Number var36 = var0.getMinOutlier((java.lang.Comparable)(byte)10, (java.lang.Comparable)var32);
//     org.jfree.data.Range var38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, (-7.0d));
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var40 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.category.DefaultCategoryDataset var41 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var43 = var41.getRowIndex((java.lang.Comparable)(-1.05d));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var46 = null;
//     var44.setSeriesItemLabelFont(1, var46);
//     boolean var48 = var44.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var48);
//     boolean var50 = var41.equals((java.lang.Object)var48);
//     org.jfree.data.time.Month var53 = new org.jfree.data.time.Month();
//     org.jfree.chart.util.Size2D var56 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
//     java.lang.Object var57 = var56.clone();
//     int var58 = var53.compareTo((java.lang.Object)var56);
//     var41.addValue(3.0d, (java.lang.Comparable)(short)0, (java.lang.Comparable)var53);
//     java.lang.Number var61 = var40.getMeanValue((java.lang.Comparable)var53, (java.lang.Comparable)8.0d);
//     long var62 = var53.getMiddleMillisecond();
//     java.util.List var63 = var0.getOutliers((java.lang.Comparable)10.0f, (java.lang.Comparable)var53);
//     
//     // Checks the contract:  equals-hashcode on var0 and var40
//     assertTrue("Contract failed: equals-hashcode on var0 and var40", var0.equals(var40) ? var0.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var0
//     assertTrue("Contract failed: equals-hashcode on var40 and var0", var40.equals(var0) ? var40.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var5 = null;
//     var3.setSeriesItemLabelFont(1, var5);
//     double var7 = var3.getItemMargin();
//     boolean var9 = var3.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var11 = var3.getSeriesCreateEntities(1);
//     java.awt.Paint var13 = var3.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var16 = null;
//     var14.setSeriesItemLabelFont(1, var16);
//     boolean var18 = var14.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var21 = var14.getItemOutlinePaint(13, 100);
//     var3.setBaseFillPaint(var21, true);
//     var3.setSeriesCreateEntities(2, (java.lang.Boolean)false);
//     org.jfree.chart.labels.ItemLabelPosition var27 = var3.getBaseNegativeItemLabelPosition();
//     boolean var28 = var2.equals((java.lang.Object)var27);
//     org.jfree.data.DefaultKeyedValues2D var29 = new org.jfree.data.DefaultKeyedValues2D();
//     boolean var30 = var2.equals((java.lang.Object)var29);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     java.util.Date var32 = var31.getEnd();
//     org.jfree.data.time.RegularTimePeriod var33 = var31.previous();
//     int var34 = var29.getColumnIndex((java.lang.Comparable)var31);
//     java.lang.Number var36 = var0.getQ3Value((java.lang.Comparable)var31, (java.lang.Comparable)"Nearest");
//     int var37 = var31.getYear();
//     java.util.Calendar var38 = null;
//     long var39 = var31.getFirstMillisecond(var38);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    var0.setItemMargin(0.05d);
    double var3 = var0.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    var1.setSeriesItemLabelsVisible(0, (java.lang.Boolean)false);
    var1.setSeriesItemLabelsVisible(255, (java.lang.Boolean)false, false);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var3 = var0.getShape(0);
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var6 = var5.getLeftArrow();
    var0.setShape(0, var6);
    org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var10 = var8.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var12 = var11.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var11.getBaseItemLabelGenerator();
    java.awt.Paint var15 = null;
    var11.setSeriesFillPaint(1, var15, false);
    var11.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var21 = var11.getLegendItemLabelGenerator();
    var8.setLegendItemToolTipGenerator(var21);
    boolean var23 = var8.getAutoPopulateSeriesStroke();
    boolean var24 = var0.equals((java.lang.Object)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var4 = var3.getUpArrow();
    boolean var5 = var1.equals((java.lang.Object)var4);
    boolean var7 = var1.equals((java.lang.Object)0.0f);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var10 = var9.getUpArrow();
    java.awt.Shape var11 = var9.getDownArrow();
    java.util.Date var12 = var9.getMinimumDate();
    int var13 = var1.getGroupIndex((java.lang.Comparable)var12);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var16 = var15.getUpArrow();
    java.awt.Shape var17 = var15.getDownArrow();
    java.util.Date var18 = var15.getMinimumDate();
    java.lang.String var19 = var15.getLabel();
    java.util.Date var20 = var15.getMinimumDate();
    org.jfree.data.gantt.Task var21 = new org.jfree.data.gantt.Task("Pie 3D Plot", var12, var20);
    java.lang.Object var22 = var21.clone();
    var21.setPercentComplete((java.lang.Double)(-0.9500000000000001d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "hi!"+ "'", var19.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var2 = var0.getRowIndex((java.lang.Comparable)(-7.0d));
//     double var4 = var0.getRangeUpperBound(true);
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var9 = var0.getMeanValue(3, 13);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var1.setRangeWithMargins((org.jfree.data.Range)var4, false, true);
    org.jfree.data.Range var8 = var1.getDefaultAutoRange();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var1.refreshTicks(var9, var10, var11, var12);
    java.awt.Font var14 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D(var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var17);
    var17.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var21 = var17.getURLGenerator();
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var17.axisChanged(var22);
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var14, (org.jfree.chart.plot.Plot)var17, false);
    var25.setBackgroundImageAlignment(10);
    org.jfree.chart.title.TextTitle var28 = var25.getTitle();
    java.lang.String var29 = var28.getToolTipText();
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.IntervalBarRenderer var31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var33 = var31.lookupSeriesShape((-1));
    var30.setUpArrow(var33);
    java.util.Date var35 = var30.getMaximumDate();
    org.jfree.chart.axis.DateTickMarkPosition var36 = var30.getTickMarkPosition();
    boolean var37 = var28.equals((java.lang.Object)var30);
    java.lang.String var38 = var28.getText();
    var28.setText("({0}, {1}) = {3} - {4}");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=true]"+ "'", var38.equals("org.jfree.chart.event.ChartChangeEvent[source=true]"));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = var0.getDataExtractOrder();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var5 = null;
    var3.setSeriesItemLabelFont(1, var5);
    double var7 = var3.getItemMargin();
    boolean var9 = var3.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var12 = var3.getNegativeItemLabelPosition(13, 4);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var14.setRangeWithMargins((org.jfree.data.Range)var17, false, true);
    org.jfree.data.Range var21 = var14.getDefaultAutoRange();
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.AxisState var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    java.util.List var26 = var14.refreshTicks(var22, var23, var24, var25);
    java.awt.Font var27 = var14.getLabelFont();
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D(var29);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var30);
    var30.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var34 = var30.getURLGenerator();
    java.awt.Shape var35 = var30.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var36 = null;
    var30.setLabelGenerator(var36);
    org.jfree.data.general.PieDataset var39 = null;
    org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D(var39);
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var40);
    int var42 = var41.getBackgroundImageAlignment();
    var30.addChangeListener((org.jfree.chart.event.PlotChangeListener)var41);
    org.jfree.chart.renderer.category.IntervalBarRenderer var45 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var47 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var45.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var47);
    org.jfree.chart.renderer.category.IntervalBarRenderer var49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var51 = null;
    var49.setSeriesItemLabelFont(1, var51);
    boolean var53 = var49.getBaseSeriesVisibleInLegend();
    java.awt.Paint var56 = var49.getItemOutlinePaint(13, 100);
    var45.setBaseItemLabelPaint(var56);
    var30.setSectionPaint((java.lang.Comparable)(short)100, var56);
    org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("Default Group", var27, var56);
    java.awt.geom.Rectangle2D var60 = var59.getBounds();
    var3.setBaseShape((java.awt.Shape)var60, false);
    var0.drawBackgroundImage(var2, var60);
    java.lang.String var64 = var0.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var3 = var2.getUpArrow();
    java.awt.Shape var4 = var2.getDownArrow();
    java.awt.Stroke var5 = var2.getTickMarkStroke();
    var0.setRangeCrosshairStroke(var5);
    java.awt.geom.Point2D var7 = var0.getQuadrantOrigin();
    java.lang.String var8 = var0.getPlotType();
    java.awt.Stroke var9 = var0.getRangeZeroBaselineStroke();
    boolean var10 = var0.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "XY Plot"+ "'", var8.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
//     var0.setMax(100.0d);
//     var0.cursorDown(0.0d);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var8 = var6.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var10 = var9.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var9.getBaseItemLabelGenerator();
//     java.awt.Paint var13 = null;
//     var9.setSeriesFillPaint(1, var13, false);
//     var9.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var9.getLegendItemLabelGenerator();
//     var6.setLegendItemToolTipGenerator(var19);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.util.Size2D var23 = var21.arrange(var22);
//     org.jfree.chart.util.RectangleEdge var24 = var21.getPosition();
//     var0.moveCursor(100.0d, var24);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var27 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var29 = var27.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var31 = var30.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getBaseItemLabelGenerator();
//     java.awt.Paint var34 = null;
//     var30.setSeriesFillPaint(1, var34, false);
//     var30.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var40 = var30.getLegendItemLabelGenerator();
//     var27.setLegendItemToolTipGenerator(var40);
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.util.Size2D var44 = var42.arrange(var43);
//     org.jfree.chart.util.RectangleEdge var45 = var42.getPosition();
//     boolean var46 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var45);
//     var0.moveCursor(100.0d, var45);
//     
//     // Checks the contract:  equals-hashcode on var19 and var40
//     assertTrue("Contract failed: equals-hashcode on var19 and var40", var19.equals(var40) ? var19.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var19
//     assertTrue("Contract failed: equals-hashcode on var40 and var19", var40.equals(var19) ? var40.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var44
//     assertTrue("Contract failed: equals-hashcode on var23 and var44", var23.equals(var44) ? var23.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var23
//     assertTrue("Contract failed: equals-hashcode on var44 and var23", var44.equals(var23) ? var44.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    boolean var1 = var0.getAutoPopulateSeriesOutlinePaint();
    var0.setAutoPopulateSeriesShape(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)0.0f);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Multiple Pie Plot", var1, (-10.0d), 0.8f, 0.95f);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var4 = var3.getUpArrow();
//     boolean var5 = var1.equals((java.lang.Object)var4);
//     boolean var7 = var1.equals((java.lang.Object)0.0f);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var10 = var9.getUpArrow();
//     java.awt.Shape var11 = var9.getDownArrow();
//     java.util.Date var12 = var9.getMinimumDate();
//     int var13 = var1.getGroupIndex((java.lang.Comparable)var12);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var16 = var15.getUpArrow();
//     java.awt.Shape var17 = var15.getDownArrow();
//     java.util.Date var18 = var15.getMinimumDate();
//     java.lang.String var19 = var15.getLabel();
//     java.util.Date var20 = var15.getMinimumDate();
//     org.jfree.data.gantt.Task var21 = new org.jfree.data.gantt.Task("Pie 3D Plot", var12, var20);
//     java.lang.Object var22 = var21.clone();
//     java.lang.Object var23 = var21.clone();
//     
//     // Checks the contract:  equals-hashcode on var22 and var23
//     assertTrue("Contract failed: equals-hashcode on var22 and var23", var22.equals(var23) ? var22.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var22
//     assertTrue("Contract failed: equals-hashcode on var23 and var22", var23.equals(var22) ? var23.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var1 = var0.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
//     java.awt.Paint var4 = null;
//     var0.setSeriesFillPaint(1, var4, false);
//     var0.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = var0.getLegendItemLabelGenerator();
//     double var11 = var0.getBase();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var15 = null;
//     var13.setSeriesItemLabelFont(1, var15);
//     double var17 = var13.getItemMargin();
//     boolean var19 = var13.isSeriesVisibleInLegend(1);
//     java.lang.Boolean var21 = var13.getSeriesCreateEntities(1);
//     java.awt.Paint var23 = var13.getSeriesItemLabelPaint((-435));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var26 = null;
//     var24.setSeriesItemLabelFont(1, var26);
//     boolean var28 = var24.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var31 = var24.getItemOutlinePaint(13, 100);
//     var13.setBaseFillPaint(var31, true);
//     var13.setSeriesCreateEntities(2, (java.lang.Boolean)false);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var13.getBaseNegativeItemLabelPosition();
//     var0.setSeriesPositiveItemLabelPosition(2, var37, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var0.", var24.equals(var0) == var0.equals(var24));
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    float var1 = var0.getMaximumCategoryLabelWidthRatio();
    boolean var2 = var0.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-7.0d), 10.0d);
    double var3 = var2.getYOffset();
    java.lang.Boolean var5 = var2.getSeriesItemLabelsVisible(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = null;
    var2.setLabelGenerator(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var12);
    int var14 = var13.getBackgroundImageAlignment();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    java.awt.Stroke var16 = var13.getBorderStroke();
    org.jfree.chart.renderer.category.IntervalBarRenderer var17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var19 = var17.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var21 = var20.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var20.getBaseItemLabelGenerator();
    java.awt.Paint var24 = null;
    var20.setSeriesFillPaint(1, var24, false);
    var20.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var20.getLegendItemLabelGenerator();
    var17.setLegendItemToolTipGenerator(var30);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.util.RectangleAnchor var33 = null;
    var32.setLegendItemGraphicLocation(var33);
    java.lang.Object var35 = var32.clone();
    var13.addSubtitle((org.jfree.chart.title.Title)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var3 = null;
    var1.setSeriesItemLabelFont(1, var3);
    double var5 = var1.getItemMargin();
    boolean var7 = var1.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var8 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var8.rendererChanged(var9);
    var1.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var8);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var13.setRangeWithMargins((org.jfree.data.Range)var16, false, true);
    org.jfree.data.Range var20 = var13.getDefaultAutoRange();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.AxisState var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    java.util.List var25 = var13.refreshTicks(var21, var22, var23, var24);
    java.awt.Font var26 = var13.getLabelFont();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var29);
    var29.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var33 = var29.getURLGenerator();
    java.awt.Shape var34 = var29.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var35 = null;
    var29.setLabelGenerator(var35);
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D(var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var39);
    int var41 = var40.getBackgroundImageAlignment();
    var29.addChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
    org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var46 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var44.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var46);
    org.jfree.chart.renderer.category.IntervalBarRenderer var48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var50 = null;
    var48.setSeriesItemLabelFont(1, var50);
    boolean var52 = var48.getBaseSeriesVisibleInLegend();
    java.awt.Paint var55 = var48.getItemOutlinePaint(13, 100);
    var44.setBaseItemLabelPaint(var55);
    var29.setSectionPaint((java.lang.Comparable)(short)100, var55);
    org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("Default Group", var26, var55);
    java.awt.geom.Rectangle2D var59 = var58.getBounds();
    org.jfree.chart.util.RectangleInsets var60 = var58.getPadding();
    var8.setInsets(var60);
    double var62 = var60.getBottom();
    var0.setInsets(var60);
    java.awt.Paint var64 = var0.getRangeGridlinePaint();
    org.jfree.chart.plot.PlotOrientation var65 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var65);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("java.awt.Color[r=0,g=0,b=0]");

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    java.awt.Color var1 = java.awt.Color.getColor("XY Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    java.lang.Object var11 = var3.clone();
    boolean var12 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.util.SortOrder var13 = var0.getRowRenderingOrder();
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var18 = null;
    var16.setSeriesItemLabelFont(1, var18);
    double var20 = var16.getItemMargin();
    boolean var22 = var16.isSeriesVisibleInLegend(1);
    org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var24 = null;
    var23.rendererChanged(var24);
    var16.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var23);
    org.jfree.data.general.Dataset var28 = null;
    org.jfree.data.general.DatasetChangeEvent var29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var28);
    var23.datasetChanged(var29);
    var0.datasetChanged(var29);
    org.jfree.chart.util.RectangleEdge var32 = var0.getRangeAxisEdge();
    org.jfree.chart.util.Layer var34 = null;
    java.util.Collection var35 = var0.getDomainMarkers(0, var34);
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var40 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var37.setRangeWithMargins((org.jfree.data.Range)var40, false, true);
    org.jfree.data.Range var44 = var37.getDefaultAutoRange();
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.axis.AxisState var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.util.RectangleEdge var48 = null;
    java.util.List var49 = var37.refreshTicks(var45, var46, var47, var48);
    java.awt.Font var50 = var37.getLabelFont();
    org.jfree.chart.plot.MultiplePiePlot var51 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var52 = var51.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var53 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var56 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var53.setRangeWithMargins((org.jfree.data.Range)var56, false, true);
    org.jfree.data.Range var60 = var53.getDefaultAutoRange();
    java.awt.Graphics2D var61 = null;
    org.jfree.chart.axis.AxisState var62 = null;
    java.awt.geom.Rectangle2D var63 = null;
    org.jfree.chart.util.RectangleEdge var64 = null;
    java.util.List var65 = var53.refreshTicks(var61, var62, var63, var64);
    org.jfree.chart.plot.Plot var66 = var53.getPlot();
    boolean var67 = var51.equals((java.lang.Object)var53);
    java.awt.Paint var68 = var53.getAxisLinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
    org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var36, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var53, var69);
    org.jfree.chart.axis.AxisLocation var71 = var70.getRangeAxisLocation();
    var0.setDomainAxisLocation(var71);
    org.jfree.chart.axis.AxisLocation var74 = var0.getDomainAxisLocation(0);
    org.jfree.chart.plot.PlotOrientation var75 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var76 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var74, var75);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    double var3 = var0.getUpperClip();
    boolean var6 = var0.isItemLabelVisible(100, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getBarWidth();
    double var3 = var1.getSeriesRunningTotal();
    org.jfree.chart.plot.PlotRenderingInfo var4 = var1.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Pie 3D Plot", var1);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     double var2 = var1.getCategoryMargin();
//     var1.setMaximumCategoryLabelWidthRatio(1.0f);
//     java.lang.String var6 = var1.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
//     java.awt.Font var8 = var1.getTickLabelFont((java.lang.Comparable)(-1.0d));
//     org.jfree.chart.urls.StandardCategoryURLGenerator var12 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "org.jfree.chart.event.ChartChangeEvent[source=true]", "");
//     org.jfree.chart.renderer.category.IntervalBarRenderer var13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var15 = var13.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var17 = var16.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var16.getBaseItemLabelGenerator();
//     java.awt.Paint var20 = null;
//     var16.setSeriesFillPaint(1, var20, false);
//     var16.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = var16.getLegendItemLabelGenerator();
//     var13.setLegendItemToolTipGenerator(var26);
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     java.lang.Object var29 = null;
//     boolean var30 = var28.equals(var29);
//     java.awt.Paint var31 = var28.getItemPaint();
//     boolean var32 = var12.equals((java.lang.Object)var31);
//     org.jfree.chart.text.TextMeasurer var35 = null;
//     org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("Other", var8, var31, 2.0f, 100, var35);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    int var1 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var0.getMaxRegularValue(255, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
    var2.clearRangeAxes();
    var2.clearDomainMarkers(100);
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D(var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var9);
    var9.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var13 = var9.getURLGenerator();
    java.awt.Shape var14 = var9.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var15 = null;
    var9.setLabelGenerator(var15);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
    int var21 = var20.getBackgroundImageAlignment();
    var9.addChangeListener((org.jfree.chart.event.PlotChangeListener)var20);
    int var23 = var9.getPieIndex();
    java.awt.Paint var24 = var9.getBaseSectionPaint();
    var2.setRangeTickBandPaint(var24);
    var0.setSeriesFillPaint(100, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var2);
    var2.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var6 = var2.getURLGenerator();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D(var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var9);
    var9.setShadowYOffset(0.0d);
    org.jfree.chart.plot.Plot var13 = var9.getRootPlot();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.lang.Object var15 = var14.clone();
    org.jfree.chart.urls.StandardCategoryURLGenerator var19 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "org.jfree.chart.event.ChartChangeEvent[source=true]", "");
    org.jfree.chart.renderer.category.IntervalBarRenderer var20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var22 = var20.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var24 = var23.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getBaseItemLabelGenerator();
    java.awt.Paint var27 = null;
    var23.setSeriesFillPaint(1, var27, false);
    var23.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var33 = var23.getLegendItemLabelGenerator();
    var20.setLegendItemToolTipGenerator(var33);
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
    java.lang.Object var36 = null;
    boolean var37 = var35.equals(var36);
    java.awt.Paint var38 = var35.getItemPaint();
    boolean var39 = var19.equals((java.lang.Object)var38);
    var14.setBasePaint(var38, true);
    var9.setOutlinePaint(var38);
    var2.setBackgroundPaint(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var2 = null;
//     var0.setSeriesItemLabelFont(1, var2);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
//     var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
//     var0.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D(var18);
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var19);
//     var19.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var23 = var19.getURLGenerator();
//     java.awt.Shape var24 = var19.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var25 = null;
//     var19.setLabelGenerator(var25);
//     java.lang.Object var27 = var19.clone();
//     boolean var28 = var16.equals((java.lang.Object)var19);
//     org.jfree.chart.util.SortOrder var29 = var16.getRowRenderingOrder();
//     java.lang.Object var30 = null;
//     boolean var31 = var29.equals(var30);
//     var12.setRowRenderingOrder(var29);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var12.getRenderer((-457));
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.util.VerticalAlignment var36 = null;
//     org.jfree.chart.block.ColumnArrangement var39 = new org.jfree.chart.block.ColumnArrangement(var35, var36, 0.0d, 1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var40 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.DatasetChangeListener var41 = null;
//     var40.addChangeListener(var41);
//     org.jfree.chart.title.LegendItemBlockContainer var44 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var39, (org.jfree.data.general.Dataset)var40, (java.lang.Comparable)"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.data.general.Dataset var45 = var44.getDataset();
//     org.jfree.chart.entity.EntityCollection var46 = null;
//     org.jfree.chart.ChartRenderingInfo var47 = new org.jfree.chart.ChartRenderingInfo(var46);
//     java.awt.geom.Rectangle2D var48 = var47.getChartArea();
//     var44.setBounds(var48);
//     org.jfree.chart.entity.ChartEntity var52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var48, "Monday", "RectangleEdge.TOP");
//     var0.drawOutline(var11, var12, var48);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.String var1 = var0.toString();

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(15);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.addYears(0, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = var2.getPreviousDayOfWeek(12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 0, 1);
    long var4 = var3.getSegmentsExcludedSize();
    int var5 = var3.getSegmentsIncluded();
    long var7 = var3.getTimeFromLong(1L);
    var3.setAdjustForDaylightSaving(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.renderer.category.IntervalBarRenderer var1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var2 = var1.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var1.getBaseItemLabelGenerator();
//     java.awt.Paint var5 = null;
//     var1.setSeriesFillPaint(1, var5, false);
//     var1.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var1.getSeriesPositiveItemLabelPosition(100);
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var14.setRangeWithMargins((org.jfree.data.Range)var17, false, true);
//     org.jfree.data.Range var21 = var14.getDefaultAutoRange();
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.AxisState var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     java.util.List var26 = var14.refreshTicks(var22, var23, var24, var25);
//     java.awt.Font var27 = var14.getLabelFont();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D(var29);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var30);
//     var30.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var34 = var30.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var35 = null;
//     var30.axisChanged(var35);
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var27, (org.jfree.chart.plot.Plot)var30, false);
//     boolean var39 = var12.equals((java.lang.Object)var27);
//     java.awt.Color var41 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var45 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var46 = var41.getRGBColorComponents(var45);
//     org.jfree.chart.text.TextMeasurer var49 = null;
//     org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var27, (java.awt.Paint)var41, 0.0f, 10, var49);
//     java.util.List var51 = var50.getLines();
//     org.jfree.chart.text.TextLine var53 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
//     var50.addLine(var53);
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.text.TextBlockAnchor var58 = null;
//     var50.draw(var55, 100.0f, 0.0f, var58, 0.8f, (-1.0f), 90.0d);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var0.setRangeWithMargins((org.jfree.data.Range)var3, false, true);
    var0.setTickMarkOutsideLength(100.0f);
    double var9 = var0.getLowerBound();
    java.lang.String var10 = var0.getLabel();
    var0.centerRange(1.0d);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var15 = var14.getUpArrow();
    java.awt.Shape var16 = var14.getDownArrow();
    java.util.Date var17 = var14.getMinimumDate();
    java.lang.String var18 = var14.getLabel();
    java.util.Date var19 = var14.getMinimumDate();
    var14.setLabelToolTip("org.jfree.chart.event.ChartChangeEvent[source=true]");
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var25 = var24.getLowerDate();
    org.jfree.data.Range var27 = org.jfree.data.Range.shift((org.jfree.data.Range)var24, (-1.0d));
    var14.setRangeWithMargins((org.jfree.data.Range)var24);
    float var29 = var14.getTickMarkInsideLength();
    java.awt.Shape var30 = var14.getLeftArrow();
    var0.setLeftArrow(var30);
    java.util.TimeZone var32 = var0.getTimeZone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(4.0d, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.05d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "hi!"+ "'", var18.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    java.util.Date var3 = var2.getLowerDate();
    org.jfree.data.Range var6 = org.jfree.data.Range.shift((org.jfree.data.Range)var2, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, 1.0d);
    org.jfree.chart.util.Size2D var11 = new org.jfree.chart.util.Size2D((-1.0d), (-1.0d));
    org.jfree.chart.util.Size2D var12 = var8.calculateConstrainedSize(var11);
    org.jfree.data.Range var13 = var8.getWidthRange();
    double var14 = var8.getWidth();
    org.jfree.data.Range var15 = var8.getWidthRange();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var3, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var8 = var7.toString();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "", "Default Group", var12, "SerialDate.weekInMonthToString(): invalid code.", "hi!", "First");
    java.lang.String var17 = var16.toString();
    org.jfree.chart.ui.Library[] var18 = var16.getLibraries();
    var7.addLibrary((org.jfree.chart.ui.Library)var16);
    var16.setLicenceName("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var8.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + " version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"+ "'", var17.equals(" version .\nSerialDate.weekInMonthToString(): invalid code..\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:Default Group\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nFirst"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.2d, 100.0d, (-0.9500000000000001d), 90.0d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    double var5 = var4.getCategoryMargin();
    var4.setMaximumCategoryLabelWidthRatio(1.0f);
    java.lang.String var9 = var4.getCategoryLabelToolTip((java.lang.Comparable)(-1.0d));
    java.util.List var10 = var0.getCategoriesForAxis(var4);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot3D var14 = new org.jfree.chart.plot.PiePlot3D(var13);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var14);
    var14.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var18 = var14.getURLGenerator();
    java.awt.Shape var19 = var14.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var20 = null;
    var14.setLabelGenerator(var20);
    java.lang.Object var22 = var14.clone();
    boolean var23 = var11.equals((java.lang.Object)var14);
    org.jfree.chart.util.SortOrder var24 = var11.getRowRenderingOrder();
    var0.setColumnRenderingOrder(var24);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
    var27.setMaximumCategoryLabelLines((-435));
    var27.setMaximumCategoryLabelLines((-435));
    var0.setDomainAxis(0, var27, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setAngleLabelsVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.IntervalBarRenderer var9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var11 = var9.lookupSeriesShape((-1));
//     var8.setUpArrow(var11);
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var14.setRangeWithMargins((org.jfree.data.Range)var17, false, true);
//     org.jfree.data.Range var21 = var14.getDefaultAutoRange();
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.AxisState var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     java.util.List var26 = var14.refreshTicks(var22, var23, var24, var25);
//     java.awt.Font var27 = var14.getLabelFont();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D(var29);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var30);
//     var30.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var34 = var30.getURLGenerator();
//     java.awt.Shape var35 = var30.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var36 = null;
//     var30.setLabelGenerator(var36);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D(var39);
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var40);
//     int var42 = var41.getBackgroundImageAlignment();
//     var30.addChangeListener((org.jfree.chart.event.PlotChangeListener)var41);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var45 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var47 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var45.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var47);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var51 = null;
//     var49.setSeriesItemLabelFont(1, var51);
//     boolean var53 = var49.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var56 = var49.getItemOutlinePaint(13, 100);
//     var45.setBaseItemLabelPaint(var56);
//     var30.setSectionPaint((java.lang.Comparable)(short)100, var56);
//     org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("Default Group", var27, var56);
//     java.awt.geom.Rectangle2D var60 = var59.getBounds();
//     boolean var61 = org.jfree.chart.util.ShapeUtilities.equal(var11, (java.awt.Shape)var60);
//     java.awt.geom.Point2D var62 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-7.0d), 0.0d, var60);
//     var0.zoomRangeAxes((-7.0d), 8.0d, var5, var62);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(10.0d, 10.0d);
//     float var4 = var3.getAlpha();
//     java.awt.Paint var5 = var3.getPaint();
//     var0.setAngleLabelPaint(var5);
//     java.awt.Color var8 = org.jfree.chart.util.PaintUtilities.stringToColor("");
//     float[] var12 = new float[] { 1.0f, 10.0f, (-1.0f)};
//     float[] var13 = var8.getRGBColorComponents(var12);
//     boolean var14 = var0.equals((java.lang.Object)var8);
//     double var15 = var0.getMaxRadius();
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.Layer var1 = null;
    java.util.Collection var2 = var0.getDomainMarkers(var1);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var7.setRangeWithMargins((org.jfree.data.Range)var10, false, true);
    org.jfree.data.Range var14 = var7.getDefaultAutoRange();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.axis.AxisState var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    java.util.List var19 = var7.refreshTicks(var15, var16, var17, var18);
    java.awt.Font var20 = var7.getLabelFont();
    org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var22 = var21.getDataExtractOrder();
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var23.setRangeWithMargins((org.jfree.data.Range)var26, false, true);
    org.jfree.data.Range var30 = var23.getDefaultAutoRange();
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.axis.AxisState var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    java.util.List var35 = var23.refreshTicks(var31, var32, var33, var34);
    org.jfree.chart.plot.Plot var36 = var23.getPlot();
    boolean var37 = var21.equals((java.lang.Object)var23);
    java.awt.Paint var38 = var23.getAxisLinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var23, var39);
    org.jfree.chart.axis.AxisLocation var41 = var40.getRangeAxisLocation();
    var3.setRangeAxisLocation(15, var41);
    org.jfree.data.general.PieDataset var44 = null;
    org.jfree.chart.plot.PiePlot3D var45 = new org.jfree.chart.plot.PiePlot3D(var44);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var45);
    java.awt.Shape var47 = var45.getLegendItemShape();
    org.jfree.data.general.PieDataset var48 = var45.getDataset();
    org.jfree.chart.labels.PieSectionLabelGenerator var49 = var45.getLabelGenerator();
    org.jfree.chart.renderer.category.IntervalBarRenderer var50 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var51 = var50.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var52 = var50.getBaseItemLabelGenerator();
    java.awt.Paint var54 = null;
    var50.setSeriesFillPaint(1, var54, false);
    java.awt.Stroke var58 = null;
    var50.setSeriesStroke(0, var58);
    org.jfree.chart.renderer.category.IntervalBarRenderer var61 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var63 = null;
    var61.setSeriesItemLabelFont(1, var63);
    org.jfree.chart.renderer.category.IntervalBarRenderer var65 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var67 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var65.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var67);
    var61.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var67);
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var70 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.data.general.PieDataset var72 = null;
    org.jfree.chart.plot.PiePlot3D var73 = new org.jfree.chart.plot.PiePlot3D(var72);
    org.jfree.chart.JFreeChart var74 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var73);
    var73.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var77 = var73.getURLGenerator();
    java.awt.Shape var78 = var73.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var79 = null;
    var73.setLabelGenerator(var79);
    org.jfree.data.general.PieDataset var82 = null;
    org.jfree.chart.plot.PiePlot3D var83 = new org.jfree.chart.plot.PiePlot3D(var82);
    org.jfree.chart.JFreeChart var84 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var83);
    int var85 = var84.getBackgroundImageAlignment();
    var73.addChangeListener((org.jfree.chart.event.PlotChangeListener)var84);
    java.awt.Stroke var87 = var84.getBorderStroke();
    var70.setGroupStroke(var87);
    var61.setBaseStroke(var87);
    var50.setSeriesStroke(0, var87);
    var45.setLabelLinkStroke(var87);
    var3.setRangeGridlineStroke(var87);
    var0.setRangeCrosshairStroke(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
    var3.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
    java.awt.Shape var8 = var3.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
    var3.setLabelGenerator(var9);
    java.lang.Object var11 = var3.clone();
    boolean var12 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.renderer.category.StackedAreaRenderer var14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
    java.awt.Paint var16 = var14.lookupSeriesOutlinePaint(255);
    var3.setShadowPaint(var16);
    java.awt.Color var19 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var20 = var19.getTransparency();
    int var21 = var19.getAlpha();
    int var22 = var19.getAlpha();
    var3.setLabelPaint((java.awt.Paint)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 255);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 100.0d, 1.0d);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var9.setRangeWithMargins((org.jfree.data.Range)var12, false, true);
//     org.jfree.data.Range var16 = var9.getDefaultAutoRange();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.AxisState var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     java.util.List var21 = var9.refreshTicks(var17, var18, var19, var20);
//     java.awt.Font var22 = var9.getLabelFont();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var25);
//     var25.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var29 = var25.getURLGenerator();
//     java.awt.Shape var30 = var25.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var31 = null;
//     var25.setLabelGenerator(var31);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot3D var35 = new org.jfree.chart.plot.PiePlot3D(var34);
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var35);
//     int var37 = var36.getBackgroundImageAlignment();
//     var25.addChangeListener((org.jfree.chart.event.PlotChangeListener)var36);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var40 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var42 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var40.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var42);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Font var46 = null;
//     var44.setSeriesItemLabelFont(1, var46);
//     boolean var48 = var44.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var51 = var44.getItemOutlinePaint(13, 100);
//     var40.setBaseItemLabelPaint(var51);
//     var25.setSectionPaint((java.lang.Comparable)(short)100, var51);
//     org.jfree.chart.block.LabelBlock var54 = new org.jfree.chart.block.LabelBlock("Default Group", var22, var51);
//     java.awt.geom.Rectangle2D var55 = var54.getBounds();
//     java.awt.geom.Point2D var56 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 0.2d, var55);
//     var4.draw(var5, var55);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.KeyToGroupMap var0 = new org.jfree.data.KeyToGroupMap();
    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var2 = var1.getRowKeys();
    boolean var3 = var0.equals((java.lang.Object)var1);
    java.lang.Comparable var5 = var0.getGroup((java.lang.Comparable)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Default Group"+ "'", var5.equals("Default Group"));

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
    var2.setRangeWithMargins((org.jfree.data.Range)var5, false, true);
    org.jfree.data.Range var9 = var2.getDefaultAutoRange();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.AxisState var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleEdge var13 = null;
    java.util.List var14 = var2.refreshTicks(var10, var11, var12, var13);
    java.awt.Font var15 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var18);
    var18.setShadowYOffset(0.0d);
    org.jfree.chart.urls.PieURLGenerator var22 = var18.getURLGenerator();
    java.awt.Shape var23 = var18.getLegendItemShape();
    org.jfree.chart.labels.PieSectionLabelGenerator var24 = null;
    var18.setLabelGenerator(var24);
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var28);
    int var30 = var29.getBackgroundImageAlignment();
    var18.addChangeListener((org.jfree.chart.event.PlotChangeListener)var29);
    org.jfree.chart.renderer.category.IntervalBarRenderer var33 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var33.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var35);
    org.jfree.chart.renderer.category.IntervalBarRenderer var37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var39 = null;
    var37.setSeriesItemLabelFont(1, var39);
    boolean var41 = var37.getBaseSeriesVisibleInLegend();
    java.awt.Paint var44 = var37.getItemOutlinePaint(13, 100);
    var33.setBaseItemLabelPaint(var44);
    var18.setSectionPaint((java.lang.Comparable)(short)100, var44);
    org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("Default Group", var15, var44);
    var0.setLabelBackgroundPaint(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("org.jfree.chart.ChartColor[r=0,g=4,b=0]", "", "AreaRendererEndType.TAPER", "RectangleEdge.TOP", "");

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("({0}, {1}) = {3} - {4}", "", var3);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=1.0, height=0.0]");
//     var1.setAutoRangeIncludesZero(true);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var7 = var5.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var9 = var8.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getBaseItemLabelGenerator();
//     java.awt.Paint var12 = null;
//     var8.setSeriesFillPaint(1, var12, false);
//     var8.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var18 = var8.getLegendItemLabelGenerator();
//     var5.setLegendItemToolTipGenerator(var18);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     java.lang.Object var21 = null;
//     boolean var22 = var20.equals(var21);
//     java.awt.Paint var23 = var20.getItemPaint();
//     org.jfree.chart.util.HorizontalAlignment var24 = var20.getHorizontalAlignment();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//     org.jfree.chart.LegendItemSource[] var27 = new org.jfree.chart.LegendItemSource[] { var26};
//     var20.setSources(var27);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.DateRange var33 = new org.jfree.data.time.DateRange((-1.0d), 0.0d);
//     var30.setRangeWithMargins((org.jfree.data.Range)var33, false, true);
//     org.jfree.data.Range var37 = var30.getDefaultAutoRange();
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.axis.AxisState var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     java.util.List var42 = var30.refreshTicks(var38, var39, var40, var41);
//     java.awt.Font var43 = var30.getLabelFont();
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot3D var46 = new org.jfree.chart.plot.PiePlot3D(var45);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var46);
//     var46.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var50 = var46.getURLGenerator();
//     org.jfree.chart.event.AxisChangeEvent var51 = null;
//     var46.axisChanged(var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=true]", var43, (org.jfree.chart.plot.Plot)var46, false);
//     var54.setBackgroundImageAlignment(10);
//     org.jfree.chart.title.TextTitle var57 = var54.getTitle();
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.entity.EntityCollection var59 = null;
//     org.jfree.chart.ChartRenderingInfo var60 = new org.jfree.chart.ChartRenderingInfo(var59);
//     java.awt.geom.Rectangle2D var61 = var60.getChartArea();
//     var57.draw(var58, var61);
//     var20.setBounds(var61);
//     org.jfree.chart.renderer.category.IntervalBarRenderer var64 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var66 = var64.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.IntervalBarRenderer var67 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
//     java.awt.Shape var68 = var67.getBaseShape();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var69 = var67.getBaseItemLabelGenerator();
//     java.awt.Paint var71 = null;
//     var67.setSeriesFillPaint(1, var71, false);
//     var67.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var77 = var67.getLegendItemLabelGenerator();
//     var64.setLegendItemToolTipGenerator(var77);
//     org.jfree.chart.title.LegendTitle var79 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var64);
//     java.awt.Graphics2D var80 = null;
//     org.jfree.chart.util.Size2D var81 = var79.arrange(var80);
//     org.jfree.chart.util.RectangleEdge var82 = var79.getPosition();
//     boolean var83 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var82);
//     double var84 = var1.valueToJava2D(8.0d, var61, var82);
//     
//     // Checks the contract:  equals-hashcode on var18 and var77
//     assertTrue("Contract failed: equals-hashcode on var18 and var77", var18.equals(var77) ? var18.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var18
//     assertTrue("Contract failed: equals-hashcode on var77 and var18", var77.equals(var18) ? var77.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var2);
    org.jfree.chart.renderer.category.IntervalBarRenderer var4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Font var6 = null;
    var4.setSeriesItemLabelFont(1, var6);
    boolean var8 = var4.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var4.getItemOutlinePaint(13, 100);
    var0.setBaseItemLabelPaint(var11);
    java.awt.Paint var13 = var0.getBaseOutlinePaint();
    java.awt.Color var19 = org.jfree.chart.util.PaintUtilities.stringToColor("");
    int var20 = var19.getTransparency();
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder(10.0d, 10.0d, 100.0d, 1.0d, (java.awt.Paint)var19);
    int var22 = var19.getTransparency();
    java.awt.image.ColorModel var23 = null;
    java.awt.Rectangle var24 = null;
    org.jfree.chart.renderer.category.LayeredBarRenderer var25 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    org.jfree.chart.block.LineBorder var26 = new org.jfree.chart.block.LineBorder();
    boolean var27 = var25.equals((java.lang.Object)var26);
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis();
    double var30 = var29.getCategoryMargin();
    int var31 = var29.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAnchor var32 = null;
    org.jfree.chart.entity.EntityCollection var35 = null;
    org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo(var35);
    java.awt.geom.Rectangle2D var37 = var36.getChartArea();
    org.jfree.chart.renderer.category.IntervalBarRenderer var38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var40 = var38.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var41 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var42 = var41.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var43 = var41.getBaseItemLabelGenerator();
    java.awt.Paint var45 = null;
    var41.setSeriesFillPaint(1, var45, false);
    var41.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var51 = var41.getLegendItemLabelGenerator();
    var38.setLegendItemToolTipGenerator(var51);
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
    java.awt.Graphics2D var54 = null;
    org.jfree.chart.util.Size2D var55 = var53.arrange(var54);
    org.jfree.chart.util.RectangleEdge var56 = var53.getPosition();
    boolean var57 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var56);
    double var58 = var29.getCategoryJava2DCoordinate(var32, 0, 10, var37, var56);
    var26.draw(var28, var37);
    java.awt.geom.AffineTransform var60 = null;
    java.awt.RenderingHints var61 = null;
    java.awt.PaintContext var62 = var19.createContext(var23, var24, var37, var60, var61);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape((java.awt.Shape)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    java.lang.Number[][] var0 = null;
    java.lang.Number[] var1 = null;
    java.lang.Number[][] var2 = new java.lang.Number[][] { var1};
    org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var3.getValue(3, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var3);
//     var3.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var7 = var3.getURLGenerator();
//     java.awt.Shape var8 = var3.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var9 = null;
//     var3.setLabelGenerator(var9);
//     java.lang.Object var11 = var3.clone();
//     boolean var12 = var0.equals((java.lang.Object)var3);
//     org.jfree.chart.util.SortOrder var13 = var0.getRowRenderingOrder();
//     org.jfree.chart.plot.CategoryMarker var15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     var15.setKey((java.lang.Comparable)1.0d);
//     var15.setDrawAsLine(true);
//     org.jfree.chart.event.MarkerChangeEvent var20 = null;
//     var15.notifyListeners(var20);
//     org.jfree.chart.plot.CategoryMarker var23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     org.jfree.chart.util.LengthAdjustmentType var24 = var23.getLabelOffsetType();
//     var15.setLabelOffsetType(var24);
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var15);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot3D var31 = new org.jfree.chart.plot.PiePlot3D(var30);
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("SerialDate.weekInMonthToString(): invalid code.", (org.jfree.chart.plot.Plot)var31);
//     var31.setShadowYOffset(0.0d);
//     org.jfree.chart.urls.PieURLGenerator var35 = var31.getURLGenerator();
//     java.awt.Shape var36 = var31.getLegendItemShape();
//     org.jfree.chart.labels.PieSectionLabelGenerator var37 = null;
//     var31.setLabelGenerator(var37);
//     java.lang.Object var39 = var31.clone();
//     boolean var40 = var28.equals((java.lang.Object)var31);
//     org.jfree.chart.util.SortOrder var41 = var28.getRowRenderingOrder();
//     org.jfree.chart.plot.CategoryMarker var43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     var43.setKey((java.lang.Comparable)1.0d);
//     var43.setDrawAsLine(true);
//     org.jfree.chart.event.MarkerChangeEvent var48 = null;
//     var43.notifyListeners(var48);
//     org.jfree.chart.plot.CategoryMarker var51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100L);
//     org.jfree.chart.util.LengthAdjustmentType var52 = var51.getLabelOffsetType();
//     var43.setLabelOffsetType(var52);
//     var28.addRangeMarker((org.jfree.chart.plot.Marker)var43);
//     org.jfree.chart.util.Layer var55 = null;
//     var0.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var43, var55);
//     
//     // Checks the contract:  equals-hashcode on var0 and var28
//     assertTrue("Contract failed: equals-hashcode on var0 and var28", var0.equals(var28) ? var0.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var0
//     assertTrue("Contract failed: equals-hashcode on var28 and var0", var28.equals(var0) ? var28.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var31
//     assertTrue("Contract failed: equals-hashcode on var3 and var31", var3.equals(var31) ? var3.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var3
//     assertTrue("Contract failed: equals-hashcode on var31 and var3", var31.equals(var3) ? var31.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var32
//     assertTrue("Contract failed: equals-hashcode on var4 and var32", var4.equals(var32) ? var4.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var4
//     assertTrue("Contract failed: equals-hashcode on var32 and var4", var32.equals(var4) ? var32.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var39
//     assertTrue("Contract failed: equals-hashcode on var11 and var39", var11.equals(var39) ? var11.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var11
//     assertTrue("Contract failed: equals-hashcode on var39 and var11", var39.equals(var11) ? var39.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var43
//     assertTrue("Contract failed: equals-hashcode on var15 and var43", var15.equals(var43) ? var15.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var51
//     assertTrue("Contract failed: equals-hashcode on var23 and var51", var23.equals(var51) ? var23.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var15
//     assertTrue("Contract failed: equals-hashcode on var43 and var15", var43.equals(var15) ? var43.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var23
//     assertTrue("Contract failed: equals-hashcode on var51 and var23", var51.equals(var23) ? var51.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.IntervalBarRenderer var3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Shape var4 = var3.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getBaseItemLabelGenerator();
    java.awt.Paint var7 = null;
    var3.setSeriesFillPaint(1, var7, false);
    var3.setSeriesItemLabelsVisible(0, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var13);
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    java.awt.Paint var18 = var15.getItemPaint();
    org.jfree.chart.util.RectangleEdge var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setPosition(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

}
