
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    java.lang.Comparable var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var2 = null;
    var1.setPlot(var2);
    var1.setLowerBound(2.0d);
    java.lang.String var6 = var1.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var7 = var1.getTickUnit();
    int var8 = var7.getMinorTickCount();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var13 = null;
    var12.setPlot(var13);
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var12, var15);
    java.awt.Stroke var17 = var12.getTickMarkStroke();
    java.awt.Font var18 = var12.getLabelFont();
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var19, var20, (org.jfree.chart.axis.ValueAxis)var21, var24);
    java.awt.Stroke var26 = var21.getTickMarkStroke();
    var21.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var30 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var31 = var30.getPadding();
    double var33 = var31.calculateTopInset(100.0d);
    var21.setLabelInsets(var31);
    java.awt.Paint var35 = var21.getTickMarkPaint();
    org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("NOID", var18, var35, 10.0f);
    int var38 = var7.compareTo((java.lang.Object)"NOID");
    java.lang.String var40 = var7.valueToString(0.0d);
    org.jfree.data.category.CategoryDataset var41 = null;
    org.jfree.chart.axis.CategoryAxis var42 = null;
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var44 = null;
    var43.setPlot(var44);
    org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var41, var42, (org.jfree.chart.axis.ValueAxis)var43, var46);
    var47.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var53 = null;
    var51.setSeriesItemLabelsVisible(0, var53, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var57 = null;
    var51.setSeriesToolTipGenerator(1, var57, false);
    org.jfree.chart.urls.CategoryURLGenerator var60 = null;
    var51.setBaseURLGenerator(var60);
    java.awt.Graphics2D var62 = null;
    org.jfree.chart.plot.CategoryPlot var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.plot.Marker var65 = null;
    java.awt.geom.Rectangle2D var66 = null;
    var51.drawRangeMarker(var62, var63, var64, var65, var66);
    boolean var69 = var51.isSeriesVisibleInLegend(0);
    var47.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
    org.jfree.chart.axis.CategoryAxis var71 = null;
    java.util.List var72 = var47.getCategoriesForAxis(var71);
    java.awt.Paint var73 = var47.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var74 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var75 = var47.getRendererForDataset((org.jfree.data.category.CategoryDataset)var74);
    org.jfree.data.general.PieDataset var77 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var74, (java.lang.Comparable)(-1L));
    java.lang.Comparable var78 = null;
    org.jfree.data.general.PieDataset var80 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var77, var78, 3.0d);
    org.jfree.data.general.PieDataset var83 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var80, (java.lang.Comparable)"AxisLocation.TOP_OR_RIGHT", 1.0d);
    org.jfree.data.category.CategoryDataset var84 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var40, (org.jfree.data.KeyedValues)var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var85 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, (org.jfree.data.KeyedValues)var80);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "0"+ "'", var40.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!");
    org.jfree.chart.ui.ProjectInfo var5 = new org.jfree.chart.ui.ProjectInfo();
    var5.setInfo("");
    java.lang.String var8 = var5.getVersion();
    org.jfree.chart.ui.ProjectInfo var9 = new org.jfree.chart.ui.ProjectInfo();
    var5.addLibrary((org.jfree.chart.ui.Library)var9);
    var5.setLicenceName("hi!");
    java.lang.String var13 = var5.getLicenceText();
    var4.addOptionalLibrary((org.jfree.chart.ui.Library)var5);
    java.lang.String var15 = var5.getLicenceText();
    java.lang.String var16 = var5.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    boolean var7 = var6.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var9 = var6.getDataset((-123));
    var6.clearRangeMarkers(0);
    java.awt.Color var16 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var24 = new org.jfree.chart.entity.ChartEntity(var22, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var27 = null;
    var25.setSeriesItemLabelsVisible(0, var27, false);
    java.awt.Stroke var30 = var25.getErrorIndicatorStroke();
    java.awt.Paint var31 = null;
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var22, var30, var31);
    org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var16, var30);
    var6.setDomainGridlineStroke(var30);
    org.jfree.chart.event.PlotChangeEvent var35 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
    java.lang.Object var36 = var35.getSource();
    java.lang.Object var37 = var35.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var2 = null;
//     var0.addObject((java.lang.Comparable)'#', var2);
//     org.jfree.data.KeyedObjects2D var5 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var6 = var5.getColumnKeys();
//     java.lang.Object var9 = var5.getObject((java.lang.Comparable)(-1), (java.lang.Comparable)0L);
//     java.util.List var10 = var5.getColumnKeys();
//     org.jfree.data.KeyedObject var11 = new org.jfree.data.KeyedObject((java.lang.Comparable)100.0d, (java.lang.Object)var5);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var13 = null;
//     var12.setPlot(var13);
//     var12.setLowerBound(2.0d);
//     java.lang.String var17 = var12.getLabelToolTip();
//     org.jfree.chart.axis.NumberTickUnit var18 = var12.getTickUnit();
//     java.lang.Comparable var19 = null;
//     java.lang.Object var20 = var5.getObject((java.lang.Comparable)var18, var19);
//     java.lang.Object var21 = var0.getObject((java.lang.Comparable)var18);
//     java.lang.Comparable[] var22 = new java.lang.Comparable[] { var18};
//     java.lang.Comparable[] var24 = new java.lang.Comparable[] { "0,100,100,-100,-100,-100,-100,-100"};
//     double[] var25 = null;
//     double[][] var26 = new double[][] { var25};
//     org.jfree.data.category.CategoryDataset var27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var22, var24, var26);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var5 = var3.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var8 = var3.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getBaseURLGenerator();
//     java.lang.Boolean var11 = var3.getSeriesItemLabelsVisible((-855310));
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var15 = null;
//     var14.setPlot(var15);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
//     java.awt.Stroke var19 = var14.getTickMarkStroke();
//     var3.setBaseOutlineStroke(var19);
//     var3.setMaximumBarWidth(2.0d);
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var27 = null;
//     var26.setPlot(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var26, var29);
//     org.jfree.chart.LegendItemSource var31 = null;
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
//     org.jfree.chart.util.RectangleEdge var33 = var32.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var35 = var34.getNextOutlinePaint();
//     var32.setBackgroundPaint(var35);
//     var30.setOutlinePaint(var35);
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var30);
//     var38.fireChartChanged();
//     boolean var40 = var38.getAntiAlias();
//     boolean var41 = var3.hasListener((java.util.EventListener)var38);
//     org.jfree.data.KeyedObjects2D var43 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var44 = var43.getColumnKeys();
//     java.lang.Object var47 = var43.getObject((java.lang.Comparable)(-1), (java.lang.Comparable)0L);
//     java.util.List var48 = var43.getColumnKeys();
//     org.jfree.data.KeyedObject var49 = new org.jfree.data.KeyedObject((java.lang.Comparable)100.0d, (java.lang.Object)var43);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var51 = null;
//     var50.setPlot(var51);
//     var50.setLowerBound(2.0d);
//     java.lang.String var55 = var50.getLabelToolTip();
//     org.jfree.chart.axis.NumberTickUnit var56 = var50.getTickUnit();
//     java.lang.Comparable var57 = null;
//     java.lang.Object var58 = var43.getObject((java.lang.Comparable)var56, var57);
//     java.util.List var59 = var43.getRowKeys();
//     var38.setSubtitles(var59);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var63 = null;
//     var61.setSeriesItemLabelsVisible(0, var63, false);
//     java.awt.Stroke var66 = var61.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var67 = var61.getDrawingSupplier();
//     java.awt.Stroke var68 = var61.getErrorIndicatorStroke();
//     java.awt.Color var73 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     int var74 = var73.getTransparency();
//     var61.setSeriesItemLabelPaint(1, (java.awt.Paint)var73);
//     org.jfree.chart.text.TextBlock var76 = new org.jfree.chart.text.TextBlock();
//     java.util.List var77 = var76.getLines();
//     org.jfree.chart.text.TextLine var78 = null;
//     var76.addLine(var78);
//     org.jfree.chart.util.HorizontalAlignment var80 = var76.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var81 = null;
//     org.jfree.chart.block.FlowArrangement var84 = new org.jfree.chart.block.FlowArrangement(var80, var81, 10.0d, 3.0d);
//     org.jfree.chart.block.CenterArrangement var85 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.block.BlockContainer var86 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var85);
//     var85.clear();
//     var85.clear();
//     org.jfree.chart.title.LegendTitle var89 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var61, (org.jfree.chart.block.Arrangement)var84, (org.jfree.chart.block.Arrangement)var85);
//     var38.addLegend(var89);
//     org.jfree.chart.util.RectangleEdge var91 = var89.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleAnchor var92 = var89.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var93 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, (-5.0d), (-1.05d), var92);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var7, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    java.awt.Stroke var15 = var10.getErrorIndicatorStroke();
    java.awt.Paint var16 = null;
    org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var7, var15, var16);
    java.awt.Shape var18 = var17.getShape();
    java.text.AttributedString var19 = var17.getAttributedLabel();
    java.awt.Stroke var20 = var17.getOutlineStroke();
    var0.setStroke(242, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Stroke var16 = var11.getTickMarkStroke();
    var0.setBaseOutlineStroke(var16);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
    int var19 = var0.getPassCount();
    java.awt.Paint var21 = var0.lookupSeriesOutlinePaint(1);
    java.awt.Paint var23 = var0.lookupSeriesOutlinePaint(10);
    java.lang.Boolean var25 = var0.getSeriesVisible(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    java.lang.String var5 = var0.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var6 = var0.getTickUnit();
    org.jfree.data.Range var7 = var0.getRange();
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var20 = var19.getNextOutlinePaint();
    var17.setBackgroundPaint(var20);
    var15.setOutlinePaint(var20);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
    var23.fireChartChanged();
    var23.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var27 = var23.getCategoryPlot();
    var27.clearRangeAxes();
    org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var30 = var29.clone();
    org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
    var29.ensureAtLeast(var31);
    double var33 = var31.getTop();
    var27.setFixedRangeAxisSpace(var31);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var27);
    var0.setUpperBound((-12.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var12 = var11.getPadding();
    double var14 = var12.calculateTopInset(100.0d);
    var2.setLabelInsets(var12);
    org.jfree.chart.axis.MarkerAxisBand var16 = var2.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    java.awt.Shape var16 = var15.getShape();
    org.jfree.data.general.Dataset var17 = null;
    var15.setDataset(var17);
    int var19 = var15.getDatasetIndex();
    org.jfree.data.general.Dataset var20 = var15.getDataset();
    java.text.AttributedString var21 = var15.getAttributedLabel();
    java.awt.Paint var22 = var15.getOutlinePaint();
    java.awt.Shape var23 = var15.getShape();
    java.awt.Shape var24 = var15.getLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisCollection var2 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var3 = var2.getAxesAtTop();
    boolean var4 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var6 = null;
    var5.setPlot(var6);
    var5.setLowerBound(2.0d);
    java.lang.String var10 = var5.getLabelToolTip();
    java.awt.Shape var11 = var5.getRightArrow();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
    boolean var16 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var15);
    var2.add((org.jfree.chart.axis.Axis)var5, var15);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var19 = null;
    var18.setPlot(var19);
    var18.setLowerBound(2.0d);
    java.lang.String var23 = var18.getLabelToolTip();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var27 = null;
    var26.setPlot(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var26, var29);
    org.jfree.chart.LegendItemSource var31 = null;
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
    org.jfree.chart.util.RectangleEdge var33 = var32.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var35 = var34.getNextOutlinePaint();
    var32.setBackgroundPaint(var35);
    var30.setOutlinePaint(var35);
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var41 = null;
    var40.setPlot(var41);
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var40, var43);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var46 = null;
    var45.setPlot(var46);
    org.jfree.chart.axis.ValueAxis[] var48 = new org.jfree.chart.axis.ValueAxis[] { var45};
    var44.setRangeAxes(var48);
    var30.setParent((org.jfree.chart.plot.Plot)var44);
    java.awt.Stroke var51 = var44.getRangeCrosshairStroke();
    var18.addChangeListener((org.jfree.chart.event.AxisChangeListener)var44);
    org.jfree.chart.LegendItemSource var53 = null;
    org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
    org.jfree.chart.util.RectangleEdge var55 = var54.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var56 = org.jfree.chart.util.RectangleEdge.opposite(var55);
    boolean var57 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var56);
    var2.add((org.jfree.chart.axis.Axis)var18, var56);
    java.util.List var59 = var2.getAxesAtTop();
    java.util.List var60 = var2.getAxesAtLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    boolean var5 = var0.getItemCreateEntity(1, (-1));
    var0.setAutoPopulateSeriesStroke(false);
    java.lang.Comparable var8 = null;
    org.jfree.chart.text.TextBlock var9 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.util.Size2D var11 = var9.calculateDimensions(var10);
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var16 = null;
    var15.setPlot(var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
    java.awt.Stroke var20 = var15.getTickMarkStroke();
    java.awt.Font var21 = var15.getLabelFont();
    java.awt.Color var24 = java.awt.Color.getColor("", (-1));
    var9.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var21, (java.awt.Paint)var24);
    org.jfree.data.KeyedObject var26 = new org.jfree.data.KeyedObject(var8, (java.lang.Object)var21);
    var0.setBaseItemLabelFont(var21, true);
    boolean var29 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.urls.CategoryURLGenerator var30 = var0.getBaseURLGenerator();
    java.awt.Font var31 = var0.getBaseItemLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     boolean var2 = var1.isNegativeArrowVisible();
//     java.lang.String var3 = var1.getLabelURL();
//     var1.setLabelAngle(6.0d);
//     var1.setAutoRange(false);
//     java.awt.Font var8 = var1.getTickLabelFont();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var9.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var13 = var9.getItemLabelPaint((-123), (-1));
//     org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("CategoryLabelWidthType.CATEGORY", var8, var13);
//     float var15 = var14.getBaselineOffset();
//     float var16 = var14.getBaselineOffset();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var19 = null;
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var22 = org.jfree.chart.util.RectangleEdge.opposite(var21);
//     boolean var23 = var18.equals((java.lang.Object)var22);
//     java.lang.Object var24 = null;
//     boolean var25 = var18.equals(var24);
//     org.jfree.chart.text.TextAnchor var26 = var18.getTextAnchor();
//     float var27 = var14.calculateBaselineOffset(var17, var26);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var14, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    java.awt.Paint var23 = null;
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var14, var22, var23);
    boolean var25 = var24.isLineVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    java.lang.Object var28 = var26.clone();
    var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    java.lang.Boolean var32 = var0.getSeriesVisibleInLegend((-855310));
    java.awt.Paint var35 = var0.getItemOutlinePaint((-1), 0);
    var0.setDrawBarOutline(false);
    org.jfree.chart.labels.ItemLabelPosition var38 = var0.getPositiveItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var3 = var1.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var4 = var1.getItemContainer();
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
    org.jfree.chart.util.RectangleInsets var7 = var6.getItemLabelPadding();
    double var9 = var7.calculateTopOutset(4.0d);
    var4.setMargin(var7);
    double var12 = var7.calculateBottomInset((-3.95d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    boolean var7 = var6.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var9 = var6.getDataset((-123));
    var6.clearRangeMarkers(0);
    var6.mapDatasetToRangeAxis(255, 4);
    var6.zoom((-12.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    double var9 = var0.getUpperClip();
    java.awt.Stroke var10 = var0.getBaseStroke();
    java.awt.Shape var13 = var0.getItemShape(4, 10);
    org.jfree.chart.event.RendererChangeEvent var14 = null;
    var0.notifyListeners(var14);
    boolean var17 = var0.isSeriesVisibleInLegend((-123));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var20 = null;
    var18.setSeriesItemLabelsVisible(0, var20, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = null;
    var18.setSeriesToolTipGenerator(1, var24, false);
    org.jfree.chart.urls.CategoryURLGenerator var27 = null;
    var18.setBaseURLGenerator(var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.plot.Marker var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    var18.drawRangeMarker(var29, var30, var31, var32, var33);
    org.jfree.chart.urls.CategoryURLGenerator var35 = null;
    var18.setBaseURLGenerator(var35, true);
    org.jfree.data.statistics.MeanAndStandardDeviation var40 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
    boolean var42 = var40.equals((java.lang.Object)'a');
    boolean var43 = var18.equals((java.lang.Object)var40);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var46 = var44.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var49 = var44.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var50 = var44.getBaseURLGenerator();
    java.lang.Boolean var52 = var44.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var53 = null;
    org.jfree.chart.axis.CategoryAxis var54 = null;
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var56 = null;
    var55.setPlot(var56);
    org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var55, var58);
    java.awt.Stroke var60 = var55.getTickMarkStroke();
    var44.setBaseOutlineStroke(var60);
    org.jfree.chart.labels.ItemLabelPosition var62 = var44.getBaseNegativeItemLabelPosition();
    var18.setBasePositiveItemLabelPosition(var62, false);
    var0.setPositiveItemLabelPositionFallback(var62);
    var0.setItemMargin((-5.0d));
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
//     java.util.List var7 = var6.getLines();
//     boolean var8 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.util.RectangleEdge var9 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var1.setWrapper(var10);
//     org.jfree.chart.util.HorizontalAlignment var12 = var1.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, (-8.0d), (-1.0d));
//     org.jfree.chart.block.BlockContainer var17 = null;
//     java.awt.Graphics2D var18 = null;
//     org.jfree.data.Range var21 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, (-1.0d));
//     org.jfree.data.Range var25 = null;
//     org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, (-1.0d));
//     org.jfree.data.Range var28 = org.jfree.data.Range.combine(var24, var27);
//     java.lang.String var29 = var27.toString();
//     double var30 = var27.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(var21, var27);
//     org.jfree.chart.block.BlockContainer var32 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var33 = var32.getPadding();
//     double var34 = var32.getWidth();
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.data.Range var39 = null;
//     org.jfree.data.Range var41 = org.jfree.data.Range.expandToInclude(var39, (-1.0d));
//     org.jfree.data.Range var42 = null;
//     org.jfree.data.Range var44 = org.jfree.data.Range.expandToInclude(var42, (-1.0d));
//     org.jfree.data.Range var45 = org.jfree.data.Range.combine(var41, var44);
//     double var46 = var44.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var47 = var38.toRangeHeight(var44);
//     org.jfree.chart.util.Size2D var48 = var32.arrange(var35, var47);
//     org.jfree.chart.block.RectangleConstraint var49 = var47.toUnconstrainedWidth();
//     org.jfree.data.Range var50 = var49.getHeightRange();
//     org.jfree.data.Range var52 = org.jfree.data.Range.shift(var50, Double.NEGATIVE_INFINITY);
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(var21, var50);
//     org.jfree.chart.util.Size2D var54 = var16.arrange(var17, var18, var53);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var4 = var2.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var0, var4, 0.0d, 2.0d);
    org.jfree.data.general.Dataset var8 = null;
    org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var8, (java.lang.Comparable)Double.NaN);
    org.jfree.data.general.Dataset var11 = var10.getDataset();
    java.lang.String var12 = var10.getURLText();
    org.jfree.chart.LegendItemSource var13 = null;
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var16 = var14.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var17 = var14.getItemContainer();
    org.jfree.chart.LegendItemSource var18 = null;
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
    org.jfree.chart.util.RectangleInsets var20 = var19.getItemLabelPadding();
    double var22 = var20.calculateTopOutset(4.0d);
    var17.setMargin(var20);
    java.awt.geom.Rectangle2D var24 = var17.getBounds();
    var10.setBounds(var24);
    var10.setURLText("RectangleAnchor.CENTER");
    var10.setToolTipText("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.text.TextBlock var31 = new org.jfree.chart.text.TextBlock();
    java.util.List var32 = var31.getLines();
    org.jfree.chart.text.TextLine var33 = null;
    var31.addLine(var33);
    org.jfree.chart.util.HorizontalAlignment var35 = var31.getLineAlignment();
    org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var40 = var38.toFixedWidth(0.05d);
    boolean var41 = var35.equals((java.lang.Object)var40);
    var30.setTextAlignment(var35);
    org.jfree.chart.block.BlockFrame var43 = var30.getFrame();
    java.lang.Object var44 = null;
    var10.add((org.jfree.chart.block.Block)var30, var44);
    org.jfree.data.general.Dataset var46 = var10.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var11 = var10.getNextOutlinePaint();
//     var8.setBackgroundPaint(var11);
//     var6.setOutlinePaint(var11);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.lang.Object var18 = var17.clone();
//     var6.handleClick(4, (-123), var17);
//     org.jfree.chart.axis.AxisSpace var20 = var6.getFixedRangeAxisSpace();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var21.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var25 = var21.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var29 = null;
//     var28.setPlot(var29);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var26, var27, (org.jfree.chart.axis.ValueAxis)var28, var31);
//     java.awt.Stroke var33 = var28.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var34 = null;
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var34);
//     org.jfree.chart.util.RectangleInsets var36 = var35.getItemLabelPadding();
//     double var37 = var36.getTop();
//     org.jfree.chart.block.LineBorder var38 = new org.jfree.chart.block.LineBorder(var25, var33, var36);
//     java.awt.Stroke var39 = var38.getStroke();
//     java.awt.Stroke var40 = var38.getStroke();
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.LegendItemSource var42 = null;
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle(var42);
//     org.jfree.chart.util.RectangleInsets var44 = var43.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var45 = null;
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle(var45);
//     org.jfree.chart.util.RectangleInsets var47 = var46.getItemLabelPadding();
//     double var48 = var47.getTop();
//     var43.setPadding(var47);
//     org.jfree.chart.util.Size2D var50 = new org.jfree.chart.util.Size2D();
//     boolean var52 = var50.equals((java.lang.Object)(-1L));
//     double var53 = var50.getWidth();
//     double var54 = var50.getHeight();
//     org.jfree.chart.util.RectangleAnchor var57 = null;
//     java.awt.geom.Rectangle2D var58 = org.jfree.chart.util.RectangleAnchor.createRectangle(var50, 2.0d, (-1.0d), var57);
//     org.jfree.chart.axis.CategoryLabelPositions var61 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var62 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var63 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var61, var62);
//     org.jfree.chart.util.RectangleAnchor var64 = var62.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var65 = org.jfree.chart.util.RectangleAnchor.createRectangle(var50, 2.0d, 1.0d, var64);
//     java.awt.geom.Rectangle2D var66 = var47.createOutsetRectangle(var65);
//     var38.draw(var41, var65);
//     java.awt.Paint var68 = var38.getPaint();
//     org.jfree.chart.util.RectangleInsets var69 = var38.getInsets();
//     var6.setInsets(var69, false);
//     org.jfree.chart.ChartRenderingInfo var74 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var75 = new org.jfree.chart.plot.PlotRenderingInfo(var74);
//     java.awt.geom.Rectangle2D var76 = var75.getDataArea();
//     java.awt.geom.Point2D var77 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(4.0d, 0.0d, var76);
//     java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var76);
//     java.awt.geom.Rectangle2D var81 = var69.createInsetRectangle(var76, false, true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var75
//     assertTrue("Contract failed: equals-hashcode on var17 and var75", var17.equals(var75) ? var17.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var17
//     assertTrue("Contract failed: equals-hashcode on var75 and var17", var75.equals(var17) ? var75.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    java.awt.Paint var11 = var0.getErrorIndicatorPaint();
    java.awt.Paint var12 = var0.getBaseFillPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    var0.setSeriesToolTipGenerator(0, var14, false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    boolean var24 = var23.isNegativeArrowVisible();
    java.lang.String var25 = var23.getLabelURL();
    var23.setLabelAngle(6.0d);
    var23.setAutoRange(false);
    java.awt.Font var30 = var23.getTickLabelFont();
    var17.setBaseItemLabelFont(var30, false);
    var0.setBaseItemLabelFont(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    var0.setBaseItemLabelGenerator(var3);
    org.jfree.chart.plot.DefaultDrawingSupplier var5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var6 = var5.getNextOutlinePaint();
    var0.setErrorIndicatorPaint(var6);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    org.jfree.chart.util.GradientPaintTransformer var9 = var0.getGradientPaintTransformer();
    boolean var11 = var0.isSeriesItemLabelsVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var13 = var0.getSeriesURLGenerator((-917504));
    java.awt.Stroke var16 = var0.getItemOutlineStroke(0, 0);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getSeriesPositiveItemLabelPosition(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    boolean var7 = var6.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var9 = var6.getDataset((-123));
    var6.setBackgroundAlpha(100.0f);
    var6.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.chart.LegendItemSource var21 = null;
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
    org.jfree.chart.util.RectangleEdge var23 = var22.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var25 = var24.getNextOutlinePaint();
    var22.setBackgroundPaint(var25);
    var20.setOutlinePaint(var25);
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
    java.lang.Object var29 = var28.clone();
    boolean var30 = var28.isNotify();
    org.jfree.chart.LegendItemSource var31 = null;
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
    org.jfree.chart.util.RectangleInsets var33 = var32.getItemLabelPadding();
    var28.addLegend(var32);
    org.jfree.chart.title.TextTitle var35 = var28.getTitle();
    var6.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var28);
    org.jfree.chart.axis.CategoryAxis var37 = null;
    int var38 = var6.getDomainAxisIndex(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    var0.setBaseSeriesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    var0.setBaseItemLabelGenerator(var3);
    org.jfree.chart.plot.DefaultDrawingSupplier var5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var6 = var5.getNextOutlinePaint();
    var0.setErrorIndicatorPaint(var6);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    org.jfree.chart.util.GradientPaintTransformer var9 = var0.getGradientPaintTransformer();
    boolean var11 = var0.isSeriesItemLabelsVisible(0);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    boolean var14 = var13.isNegativeArrowVisible();
    java.awt.Shape var15 = var13.getDownArrow();
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    var0.setSeriesShape(1, var15, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.LegendItemSource var6 = null;
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
    org.jfree.chart.util.RectangleEdge var8 = var7.getLegendItemGraphicEdge();
    java.awt.Paint var9 = var7.getItemPaint();
    var7.setNotify(true);
    boolean var12 = var1.equals((java.lang.Object)var7);
    org.jfree.chart.util.Size2D var13 = new org.jfree.chart.util.Size2D();
    boolean var15 = var13.equals((java.lang.Object)(-1L));
    double var16 = var13.getWidth();
    double var17 = var13.getHeight();
    org.jfree.chart.util.RectangleAnchor var20 = null;
    java.awt.geom.Rectangle2D var21 = org.jfree.chart.util.RectangleAnchor.createRectangle(var13, 2.0d, (-1.0d), var20);
    org.jfree.chart.axis.CategoryLabelPositions var24 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var25 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var26 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var24, var25);
    org.jfree.chart.util.RectangleAnchor var27 = var25.getCategoryAnchor();
    java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var13, 2.0d, 1.0d, var27);
    var7.setLegendItemGraphicLocation(var27);
    double var30 = var7.getContentYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
    double var18 = var17.getTop();
    var13.setPadding(var17);
    org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D();
    boolean var22 = var20.equals((java.lang.Object)(-1L));
    double var23 = var20.getWidth();
    double var24 = var20.getHeight();
    org.jfree.chart.util.RectangleAnchor var27 = null;
    java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, (-1.0d), var27);
    org.jfree.chart.axis.CategoryLabelPositions var31 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var31, var32);
    org.jfree.chart.util.RectangleAnchor var34 = var32.getCategoryAnchor();
    java.awt.geom.Rectangle2D var35 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, 1.0d, var34);
    java.awt.geom.Rectangle2D var36 = var17.createOutsetRectangle(var35);
    java.awt.geom.Point2D var37 = null;
    org.jfree.chart.plot.PlotState var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    var6.draw(var11, var36, var37, var38, var39);
    boolean var41 = var6.isRangeCrosshairLockedOnData();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var44 = var42.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var47 = var42.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var48 = var42.getBaseURLGenerator();
    java.lang.Boolean var50 = var42.getSeriesItemLabelsVisible((-855310));
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var51 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var42};
    var6.setRenderers(var51);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var53 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var55 = null;
    var53.setSeriesItemLabelsVisible(0, var55, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var59 = null;
    var53.setSeriesToolTipGenerator(1, var59, false);
    double var62 = var53.getUpperClip();
    java.awt.Stroke var63 = var53.getBaseStroke();
    int var64 = var6.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var53);
    org.jfree.chart.labels.ItemLabelPosition var66 = var53.getSeriesNegativeItemLabelPosition((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getPositiveItemLabelPositionFallback();
    java.awt.Paint var4 = var0.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    java.awt.Stroke var12 = var7.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var13 = null;
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getItemLabelPadding();
    double var16 = var15.getTop();
    org.jfree.chart.block.LineBorder var17 = new org.jfree.chart.block.LineBorder(var4, var12, var15);
    java.awt.Stroke var18 = var17.getStroke();
    java.awt.Stroke var19 = var17.getStroke();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.LegendItemSource var21 = null;
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var24 = null;
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
    org.jfree.chart.util.RectangleInsets var26 = var25.getItemLabelPadding();
    double var27 = var26.getTop();
    var22.setPadding(var26);
    org.jfree.chart.util.Size2D var29 = new org.jfree.chart.util.Size2D();
    boolean var31 = var29.equals((java.lang.Object)(-1L));
    double var32 = var29.getWidth();
    double var33 = var29.getHeight();
    org.jfree.chart.util.RectangleAnchor var36 = null;
    java.awt.geom.Rectangle2D var37 = org.jfree.chart.util.RectangleAnchor.createRectangle(var29, 2.0d, (-1.0d), var36);
    org.jfree.chart.axis.CategoryLabelPositions var40 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var41 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var42 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var40, var41);
    org.jfree.chart.util.RectangleAnchor var43 = var41.getCategoryAnchor();
    java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var29, 2.0d, 1.0d, var43);
    java.awt.geom.Rectangle2D var45 = var26.createOutsetRectangle(var44);
    var17.draw(var20, var44);
    java.awt.Paint var47 = var17.getPaint();
    org.jfree.chart.util.RectangleInsets var48 = var17.getInsets();
    java.lang.Comparable var49 = null;
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity(var51, "Range[-1.0,-1.0]");
    org.jfree.chart.entity.CategoryLabelEntity var56 = new org.jfree.chart.entity.CategoryLabelEntity(var49, var51, "hi!", "");
    java.lang.String var57 = var56.toString();
    var56.setURLText("hi!");
    var56.setToolTipText("");
    java.lang.Object var62 = var56.clone();
    boolean var63 = var17.equals(var62);
    org.jfree.chart.block.LabelBlock var65 = new org.jfree.chart.block.LabelBlock("");
    org.jfree.data.category.CategoryDataset var67 = null;
    org.jfree.chart.axis.CategoryAxis var68 = null;
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var70 = null;
    var69.setPlot(var70);
    org.jfree.chart.renderer.category.CategoryItemRenderer var72 = null;
    org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot(var67, var68, (org.jfree.chart.axis.ValueAxis)var69, var72);
    org.jfree.chart.LegendItemSource var74 = null;
    org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle(var74);
    org.jfree.chart.util.RectangleEdge var76 = var75.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var77 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var78 = var77.getNextOutlinePaint();
    var75.setBackgroundPaint(var78);
    var73.setOutlinePaint(var78);
    org.jfree.chart.JFreeChart var81 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var73);
    var81.fireChartChanged();
    boolean var83 = var81.getAntiAlias();
    java.awt.Image var84 = var81.getBackgroundImage();
    org.jfree.chart.event.ChartProgressListener var85 = null;
    var81.removeProgressListener(var85);
    boolean var87 = var65.equals((java.lang.Object)var81);
    java.lang.Object var88 = var65.clone();
    boolean var89 = var17.equals((java.lang.Object)var65);
    org.jfree.chart.util.RectangleInsets var90 = var17.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "CategoryLabelEntity: category=null, tooltip=hi!, url="+ "'", var57.equals("CategoryLabelEntity: category=null, tooltip=hi!, url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    var0.setBaseCreateEntities(false, false);
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)false);
    boolean var17 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var0.setBaseURLGenerator(var18, false);
    boolean var21 = var0.getBaseCreateEntities();
    double var22 = var0.getUpperClip();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var26 = var24.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var29 = var24.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var24.getLegendItemToolTipGenerator();
    var24.setItemLabelAnchorOffset(100.0d);
    var24.setBase(1.0E-8d);
    org.jfree.chart.labels.CategoryItemLabelGenerator var36 = null;
    var24.setSeriesItemLabelGenerator(242, var36, false);
    org.jfree.chart.labels.ItemLabelPosition var39 = var24.getBaseNegativeItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var40 = var24.getPositiveItemLabelPositionFallback();
    java.awt.Stroke var42 = var24.lookupSeriesOutlineStroke((-10289251));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlineStroke((-16777212), var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(2.0d);
    var1.cursorLeft(0.0d);
    double var4 = var1.getMax();
    var1.setMax((-1.0d));
    var1.setMax(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var4 = var2.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var2.setBaseItemLabelGenerator(var5);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var8 = var7.getNextOutlinePaint();
    var2.setErrorIndicatorPaint(var8);
    java.awt.Font var10 = var2.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.CATEGORY", var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var15 = null;
    var14.setPlot(var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var20 = null;
    var19.setPlot(var20);
    org.jfree.chart.axis.ValueAxis[] var22 = new org.jfree.chart.axis.ValueAxis[] { var19};
    var18.setRangeAxes(var22);
    java.awt.Paint var24 = var18.getDomainGridlinePaint();
    org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("Range[-1.0,-1.0]", var10, var24);
    org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var28 = var27.getFont();
    var25.setFont(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }
// 
// 
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var10 = null;
//     var8.setSeriesItemLabelsVisible(0, var10, false);
//     java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
//     java.awt.Paint var14 = null;
//     org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
//     boolean var16 = var15.isLineVisible();
//     boolean var17 = var15.isShapeOutlineVisible();
//     var15.setDatasetIndex(1);
//     int var20 = var15.getSeriesIndex();
//     org.jfree.chart.util.BooleanList var21 = new org.jfree.chart.util.BooleanList();
//     java.lang.Object var22 = null;
//     boolean var23 = var21.equals(var22);
//     org.jfree.data.KeyedObjects var24 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var26 = null;
//     var24.addObject((java.lang.Comparable)'#', var26);
//     java.lang.Object var28 = var24.clone();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var32 = null;
//     var31.setPlot(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var29, var30, (org.jfree.chart.axis.ValueAxis)var31, var34);
//     var31.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var31.java2DToValue(0.0d, var39, var40);
//     org.jfree.chart.axis.NumberTickUnit var42 = var31.getTickUnit();
//     int var43 = var24.getIndex((java.lang.Comparable)var42);
//     boolean var44 = var21.equals((java.lang.Object)var42);
//     java.lang.String var46 = var42.valueToString(0.0d);
//     double var47 = var42.getSize();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var50 = var48.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var53 = var48.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var54 = var48.getLegendItemToolTipGenerator();
//     var48.setItemLabelAnchorOffset(100.0d);
//     java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var64 = new org.jfree.chart.entity.ChartEntity(var62, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var67 = null;
//     var65.setSeriesItemLabelsVisible(0, var67, false);
//     java.awt.Stroke var70 = var65.getErrorIndicatorStroke();
//     java.awt.Paint var71 = null;
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var62, var70, var71);
//     boolean var73 = var72.isLineVisible();
//     org.jfree.chart.util.StandardGradientPaintTransformer var74 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.lang.Object var75 = var74.clone();
//     java.lang.Object var76 = var74.clone();
//     var72.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var74);
//     var48.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var74);
//     var48.setBaseSeriesVisibleInLegend(true, true);
//     var48.removeAnnotations();
//     org.jfree.chart.labels.ItemLabelPosition var85 = var48.getPositiveItemLabelPosition(255, 242);
//     int var86 = var42.compareTo((java.lang.Object)242);
//     var15.setSeriesKey((java.lang.Comparable)var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "0"+ "'", var46.equals("0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == (-1));
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.95f);
    org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
    java.lang.Comparable var3 = var2.getSeriesKey();
    java.lang.Object var4 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    boolean var7 = var6.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var9 = var6.getDataset((-123));
    var6.clearRangeMarkers(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var6.getRenderer(0);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    var20.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var26 = null;
    var24.setSeriesItemLabelsVisible(0, var26, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var30 = null;
    var24.setSeriesToolTipGenerator(1, var30, false);
    org.jfree.chart.urls.CategoryURLGenerator var33 = null;
    var24.setBaseURLGenerator(var33);
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.plot.Marker var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    var24.drawRangeMarker(var35, var36, var37, var38, var39);
    boolean var42 = var24.isSeriesVisibleInLegend(0);
    var20.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    org.jfree.chart.util.Layer var45 = null;
    java.util.Collection var46 = var20.getDomainMarkers(10, var45);
    org.jfree.chart.axis.AxisLocation var48 = var20.getDomainAxisLocation((-1));
    var6.setRangeAxisLocation(var48);
    var6.setAnchorValue(2.0d);
    org.jfree.chart.axis.ValueAxis var53 = var6.getRangeAxis((-1));
    var6.clearRangeMarkers((-917504));
    org.jfree.chart.plot.Plot var56 = var6.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(10, (-10289251), 2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getSeriesRunningTotal();
    org.jfree.chart.entity.EntityCollection var3 = var1.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    java.awt.Image var30 = var6.getBackgroundImage();
    java.awt.Stroke var31 = var6.getDomainGridlineStroke();
    org.jfree.chart.plot.CategoryMarker var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    boolean var2 = var0.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    boolean var3 = var0.equals((java.lang.Object)var2);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var10 = null;
    var9.setPlot(var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var8, (org.jfree.chart.axis.ValueAxis)var9, var12);
    var13.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var23 = null;
    var17.setSeriesToolTipGenerator(1, var23, false);
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    var17.setBaseURLGenerator(var26);
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var17.drawRangeMarker(var28, var29, var30, var31, var32);
    boolean var35 = var17.isSeriesVisibleInLegend(0);
    var13.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
    org.jfree.chart.axis.CategoryAxis var37 = null;
    java.util.List var38 = var13.getCategoriesForAxis(var37);
    java.awt.Paint var39 = var13.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var40 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = var13.getRendererForDataset((org.jfree.data.category.CategoryDataset)var40);
    org.jfree.data.general.PieDataset var43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var40, (java.lang.Comparable)(-1L));
    org.jfree.data.category.CategoryDataset var44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)' ', (org.jfree.data.KeyedValues)var43);
    org.jfree.chart.entity.CategoryItemEntity var47 = new org.jfree.chart.entity.CategoryItemEntity(var2, "Size2D[width=0.0, height=-1.0]", "java.awt.Color[r=255,g=255,b=255]", var44, (java.lang.Comparable)(-0.55d), (java.lang.Comparable)(-8.0d));
    java.lang.String var48 = var47.toString();
    org.jfree.data.category.CategoryDataset var49 = var47.getDataset();
    java.lang.String var50 = var47.toString();
    java.lang.Comparable var51 = var47.getColumnKey();
    java.lang.Comparable var52 = var47.getColumnKey();
    org.jfree.data.KeyedObjects var53 = new org.jfree.data.KeyedObjects();
    java.lang.Comparable var55 = var53.getKey((-16777212));
    java.util.List var56 = var53.getKeys();
    java.util.List var57 = var53.getKeys();
    boolean var58 = var47.equals((java.lang.Object)var57);
    org.jfree.data.category.CategoryDataset var59 = var47.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + (-8.0d)+ "'", var51.equals((-8.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + (-8.0d)+ "'", var52.equals((-8.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.lang.String var5 = var4.getToolTipText();
    java.lang.String var6 = var4.getText();
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var10 = null;
    var9.setPlot(var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var8, (org.jfree.chart.axis.ValueAxis)var9, var12);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var15 = null;
    var14.setPlot(var15);
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var14};
    var13.setRangeAxes(var17);
    java.awt.Paint var19 = var13.getDomainGridlinePaint();
    var4.setPaint(var19);
    var0.setBaseOutlinePaint(var19, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var23 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var25 = null;
    var24.setPlot(var25);
    var24.setLowerBound(2.0d);
    java.lang.String var29 = var24.getLabelToolTip();
    java.lang.String var30 = var24.getLabel();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var33 = null;
    var31.setSeriesItemLabelsVisible(0, var33, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
    var31.setSeriesToolTipGenerator(1, var37, false);
    org.jfree.chart.urls.CategoryURLGenerator var40 = null;
    var31.setBaseURLGenerator(var40);
    java.awt.Graphics2D var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.plot.Marker var45 = null;
    java.awt.geom.Rectangle2D var46 = null;
    var31.drawRangeMarker(var42, var43, var44, var45, var46);
    org.jfree.chart.urls.CategoryURLGenerator var48 = null;
    var31.setBaseURLGenerator(var48, true);
    org.jfree.data.statistics.MeanAndStandardDeviation var53 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
    boolean var55 = var53.equals((java.lang.Object)'a');
    boolean var56 = var31.equals((java.lang.Object)var53);
    var31.setSeriesCreateEntities(255, (java.lang.Boolean)true, false);
    var31.setBaseItemLabelsVisible(false);
    java.awt.Paint var64 = var31.lookupSeriesPaint((-1));
    org.jfree.chart.labels.CategoryToolTipGenerator var66 = null;
    var31.setSeriesToolTipGenerator(0, var66);
    boolean var68 = var31.getBaseSeriesVisibleInLegend();
    boolean var69 = var24.equals((java.lang.Object)var31);
    org.jfree.chart.labels.ItemLabelPosition var72 = var31.getPositiveItemLabelPosition(3, (-124390));
    var0.setBaseNegativeItemLabelPosition(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    java.lang.String var1 = var0.getID();
    java.lang.Object var2 = null;
    boolean var3 = var0.equals(var2);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var6 = null;
    var4.setSeriesItemLabelsVisible(0, var6, false);
    java.awt.Stroke var9 = var4.getErrorIndicatorStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var11 = var10.getPositiveItemLabelPositionFallback();
    java.awt.Paint var14 = var10.getItemLabelPaint((-123), (-1));
    int var15 = var10.getColumnCount();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = var16.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var21 = var16.getPositiveItemLabelPosition(100, 0);
    var10.setBasePositiveItemLabelPosition(var21);
    var4.setNegativeItemLabelPositionFallback(var21);
    var4.setSeriesVisible(10, (java.lang.Boolean)true);
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var29 = null;
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var31 = null;
    var30.setPlot(var31);
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var28, var29, (org.jfree.chart.axis.ValueAxis)var30, var33);
    org.jfree.chart.LegendItemSource var35 = null;
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle(var35);
    org.jfree.chart.util.RectangleEdge var37 = var36.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var39 = var38.getNextOutlinePaint();
    var36.setBackgroundPaint(var39);
    var34.setOutlinePaint(var39);
    java.awt.Stroke var42 = var34.getRangeCrosshairStroke();
    var4.setSeriesOutlineStroke(10, var42, true);
    int var45 = var4.getPassCount();
    boolean var46 = var0.equals((java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "NOID"+ "'", var1.equals("NOID"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var6 = null;
    var5.setPlot(var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var3, var4, (org.jfree.chart.axis.ValueAxis)var5, var8);
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleEdge var12 = var11.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var14 = var13.getNextOutlinePaint();
    var11.setBackgroundPaint(var14);
    var9.setOutlinePaint(var14);
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var17.fireChartChanged();
    var17.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var21 = var17.getCategoryPlot();
    var21.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var27 = var26.getFont();
    java.awt.Color var31 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var27, (java.awt.Paint)var31);
    java.awt.Color var33 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var31);
    var21.setDomainGridlinePaint((java.awt.Paint)var31);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var36 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.NumberTickUnit var41 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
    var36.add((java.lang.Number)(-1.0d), (java.lang.Number)(-855310), (java.lang.Comparable)0.05d, (java.lang.Comparable)1.0E-8d);
    var21.setDataset(100, (org.jfree.data.category.CategoryDataset)var36);
    var21.clearRangeMarkers();
    boolean var45 = var0.hasListener((java.util.EventListener)var21);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var48 = var46.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var51 = var46.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var52 = var46.getBaseURLGenerator();
    java.lang.Boolean var54 = var46.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var57 = java.awt.Color.getColor("", (-1));
    var46.setBasePaint((java.awt.Paint)var57, true);
    org.jfree.data.category.CategoryDataset var60 = null;
    org.jfree.chart.axis.CategoryAxis var61 = null;
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var63 = null;
    var62.setPlot(var63);
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var60, var61, (org.jfree.chart.axis.ValueAxis)var62, var65);
    boolean var67 = var66.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var69 = var66.getDataset((-123));
    var66.clearRangeMarkers(0);
    java.awt.Color var76 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var82 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var84 = new org.jfree.chart.entity.ChartEntity(var82, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var85 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var87 = null;
    var85.setSeriesItemLabelsVisible(0, var87, false);
    java.awt.Stroke var90 = var85.getErrorIndicatorStroke();
    java.awt.Paint var91 = null;
    org.jfree.chart.LegendItem var92 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var82, var90, var91);
    org.jfree.chart.plot.ValueMarker var93 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var76, var90);
    var66.setDomainGridlineStroke(var90);
    var46.addChangeListener((org.jfree.chart.event.RendererChangeListener)var66);
    org.jfree.chart.axis.AxisLocation var97 = var66.getDomainAxisLocation(10);
    var21.setDomainAxisLocation(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var20.setRangeAxes(var24);
    var6.setParent((org.jfree.chart.plot.Plot)var20);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.NumberTickUnit var33 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
    var28.add((java.lang.Number)(-1.0d), (java.lang.Number)(-855310), (java.lang.Comparable)0.05d, (java.lang.Comparable)1.0E-8d);
    org.jfree.data.general.DatasetGroup var35 = new org.jfree.data.general.DatasetGroup();
    var28.setGroup(var35);
    int var37 = var28.getRowCount();
    var20.setDataset(242, (org.jfree.data.category.CategoryDataset)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    java.awt.Paint var12 = var6.getDomainGridlinePaint();
    float var13 = var6.getForegroundAlpha();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.TOP_OR_RIGHT");
    org.jfree.chart.axis.CategoryAxis[] var16 = new org.jfree.chart.axis.CategoryAxis[] { var15};
    var6.setDomainAxes(var16);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var19 = null;
    var18.setPlot(var19);
    var18.setLowerBound(2.0d);
    java.lang.String var23 = var18.getLabelToolTip();
    boolean var24 = var18.isNegativeArrowVisible();
    org.jfree.data.Range var25 = var18.getDefaultAutoRange();
    var6.setRangeAxis((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.data.category.CategoryDataset var27 = null;
    org.jfree.chart.axis.CategoryAxis var28 = null;
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var30 = null;
    var29.setPlot(var30);
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var29, var32);
    var29.setAutoRangeMinimumSize(2.0d);
    org.jfree.data.RangeType var36 = var29.getRangeType();
    java.lang.String var37 = var36.toString();
    var18.setRangeType(var36);
    boolean var39 = var18.getAutoRangeIncludesZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "RangeType.FULL"+ "'", var37.equals("RangeType.FULL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var11 = java.awt.Color.getColor("", (-1));
    var0.setBasePaint((java.awt.Paint)var11, true);
    double var14 = var0.getLowerClip();
    java.lang.Boolean var16 = var0.getSeriesCreateEntities((-1));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity(var18, "Range[-1.0,-1.0]");
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var18, "java.awt.Color[r=242,g=242,b=242]");
    var0.setBaseShape(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.util.HorizontalAlignment var6 = var1.getHorizontalAlignment();
    org.jfree.chart.LegendItemSource[] var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSources(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var6 = null;
    var5.setPlot(var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var3, var4, (org.jfree.chart.axis.ValueAxis)var5, var8);
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleEdge var12 = var11.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var14 = var13.getNextOutlinePaint();
    var11.setBackgroundPaint(var14);
    var9.setOutlinePaint(var14);
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var17.fireChartChanged();
    boolean var19 = var17.getAntiAlias();
    java.awt.Image var20 = var17.getBackgroundImage();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var17.removeProgressListener(var21);
    boolean var23 = var1.equals((java.lang.Object)var17);
    org.jfree.chart.LegendItemSource var24 = null;
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
    org.jfree.chart.util.RectangleInsets var26 = var25.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var27 = var25.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var28 = var25.getItemContainer();
    org.jfree.chart.LegendItemSource var29 = null;
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
    org.jfree.chart.util.RectangleInsets var31 = var30.getItemLabelPadding();
    double var33 = var31.calculateTopOutset(4.0d);
    var28.setMargin(var31);
    java.awt.geom.Rectangle2D var35 = var28.getBounds();
    org.jfree.chart.LegendItemSource var36 = null;
    org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle(var36);
    org.jfree.chart.util.RectangleInsets var38 = var37.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var39 = var37.getLegendItemGraphicLocation();
    java.awt.geom.Point2D var40 = org.jfree.chart.util.RectangleAnchor.coordinates(var35, var39);
    boolean var41 = var1.equals((java.lang.Object)var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    var1.setLegendItemGraphicLocation(var3);
    var1.setWidth(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }
// 
// 
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextBlockAnchor var5 = null;
//     var1.draw(var2, 100.0f, 100.0f, var5);
//     org.jfree.data.KeyedObjects2D var8 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var9 = var8.getColumnKeys();
//     int var11 = var8.getRowIndex((java.lang.Comparable)100);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     boolean var13 = var12.isNegativeArrowVisible();
//     java.lang.String var14 = var12.getLabelURL();
//     var12.setLabelAngle(6.0d);
//     var12.setAutoRange(false);
//     java.awt.Font var19 = var12.getTickLabelFont();
//     var8.setObject((java.lang.Object)var19, (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=", (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var26 = var24.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var24.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var30 = var24.getBaseURLGenerator();
//     java.lang.Boolean var32 = var24.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var35 = java.awt.Color.getColor("", (-1));
//     var24.setBasePaint((java.awt.Paint)var35, true);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     boolean var39 = var38.isNegativeArrowVisible();
//     java.lang.String var40 = var38.getLabelURL();
//     var38.setLabelAngle(6.0d);
//     float var43 = var38.getTickMarkOutsideLength();
//     var38.setVerticalTickLabels(true);
//     boolean var46 = var35.equals((java.lang.Object)true);
//     java.awt.Color var47 = java.awt.Color.getColor("UnitType.ABSOLUTE", var35);
//     var1.addLine("UnitType.ABSOLUTE", var19, (java.awt.Paint)var35);
//     org.jfree.data.category.CategoryDataset var50 = null;
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var53 = null;
//     var52.setPlot(var53);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var50, var51, (org.jfree.chart.axis.ValueAxis)var52, var55);
//     org.jfree.chart.LegendItemSource var57 = null;
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle(var57);
//     org.jfree.chart.util.RectangleEdge var59 = var58.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var61 = var60.getNextOutlinePaint();
//     var58.setBackgroundPaint(var61);
//     var56.setOutlinePaint(var61);
//     org.jfree.chart.JFreeChart var64 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var56);
//     var64.fireChartChanged();
//     org.jfree.chart.plot.CategoryPlot var66 = var64.getCategoryPlot();
//     org.jfree.chart.renderer.category.BarRenderer var67 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var68 = var67.getBasePositiveItemLabelPosition();
//     org.jfree.chart.plot.DefaultDrawingSupplier var69 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     boolean var71 = var69.equals((java.lang.Object)(short)10);
//     java.awt.Paint var72 = var69.getNextFillPaint();
//     var67.setBaseItemLabelPaint(var72, false);
//     var66.setRangeGridlinePaint(var72);
//     java.awt.Graphics2D var77 = null;
//     org.jfree.chart.text.G2TextMeasurer var78 = new org.jfree.chart.text.G2TextMeasurer(var77);
//     org.jfree.chart.text.TextBlock var79 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, var72, 2.0f, (org.jfree.chart.text.TextMeasurer)var78);
//     
//     // Checks the contract:  equals-hashcode on var29 and var68
//     assertTrue("Contract failed: equals-hashcode on var29 and var68", var29.equals(var68) ? var29.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var29
//     assertTrue("Contract failed: equals-hashcode on var68 and var29", var68.equals(var29) ? var68.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    org.jfree.chart.plot.CategoryPlot var18 = var15.getCategoryPlot();
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var22 = var15.createBufferedImage(2, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    var0.setBaseItemLabelGenerator(var3);
    org.jfree.chart.plot.DefaultDrawingSupplier var5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var6 = var5.getNextOutlinePaint();
    var0.setErrorIndicatorPaint(var6);
    java.awt.Font var8 = var0.getBaseItemLabelFont();
    java.lang.Boolean var10 = var0.getSeriesVisible(242);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 0.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var15);
    var15.clear();
    org.jfree.chart.util.StandardGradientPaintTransformer var18 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.event.ChartChangeEvent var20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var18);
    boolean var21 = var15.equals((java.lang.Object)var18);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var18);
    var0.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }


    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 1.0f, 2.0f);
    org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder((-8.0d), 1.0d, 0.55d, 0.0d, (java.awt.Paint)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var4 = null;
    var2.setSeriesItemLabelsVisible(0, var4, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var2.setSeriesToolTipGenerator(1, var8, false);
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var2.setBaseURLGenerator(var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.Marker var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    var2.drawRangeMarker(var13, var14, var15, var16, var17);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var2.setBaseURLGenerator(var19, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var24 = null;
    var22.setSeriesItemLabelsVisible(0, var24, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
    var22.setSeriesToolTipGenerator(1, var28, false);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var22.setBaseURLGenerator(var31);
    var22.setBaseCreateEntities(false, false);
    var22.setBaseSeriesVisibleInLegend(false);
    var22.setBaseItemLabelsVisible(true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var43 = var41.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var46 = var41.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var47 = var41.getBaseURLGenerator();
    java.lang.Boolean var49 = var41.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var50 = null;
    org.jfree.chart.axis.CategoryAxis var51 = null;
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var53 = null;
    var52.setPlot(var53);
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var50, var51, (org.jfree.chart.axis.ValueAxis)var52, var55);
    java.awt.Stroke var57 = var52.getTickMarkStroke();
    var41.setBaseOutlineStroke(var57);
    org.jfree.chart.labels.ItemLabelPosition var59 = var41.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var60 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var61 = var60.getEntityCollection();
    boolean var62 = var59.equals((java.lang.Object)var60);
    var22.setSeriesPositiveItemLabelPosition(0, var59);
    var2.setPositiveItemLabelPositionFallback(var59);
    org.jfree.data.category.CategoryDataset var66 = null;
    org.jfree.chart.axis.CategoryAxis var67 = null;
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var69 = null;
    var68.setPlot(var69);
    org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var66, var67, (org.jfree.chart.axis.ValueAxis)var68, var71);
    org.jfree.chart.LegendItemSource var73 = null;
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
    org.jfree.chart.util.RectangleEdge var75 = var74.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var77 = var76.getNextOutlinePaint();
    var74.setBackgroundPaint(var77);
    var72.setOutlinePaint(var77);
    org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var72);
    var80.fireChartChanged();
    var80.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var84 = var80.getCategoryPlot();
    var84.clearRangeAxes();
    var84.clearDomainMarkers();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var87 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var88 = var87.getPositiveItemLabelPositionFallback();
    java.awt.Paint var91 = var87.getItemLabelPaint((-123), (-1));
    var84.setOutlinePaint(var91);
    var2.setBaseOutlinePaint(var91);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic(var1, var91);
    java.awt.Shape var95 = var94.getShape();
    java.awt.Stroke var96 = null;
    var94.setLineStroke(var96);
    java.awt.Paint var98 = var94.getLinePaint();
    java.awt.Shape var99 = var94.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    java.awt.Stroke var7 = var0.getSeriesOutlineStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = var0.getLegendItemURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var14, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    java.awt.Paint var23 = null;
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var14, var22, var23);
    boolean var25 = var24.isLineVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    java.lang.Object var28 = var26.clone();
    var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    java.lang.Boolean var32 = var0.getSeriesVisibleInLegend((-855310));
    java.awt.Paint var35 = var0.getItemOutlinePaint((-1), 0);
    boolean var36 = var0.getBaseSeriesVisible();
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
    var0.setBaseToolTipGenerator(var37);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var42 = null;
    var40.setSeriesItemLabelsVisible(0, var42, false);
    java.awt.Stroke var45 = var40.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var46 = var40.getDrawingSupplier();
    java.awt.Stroke var47 = var40.getErrorIndicatorStroke();
    java.awt.Color var52 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    int var53 = var52.getTransparency();
    var40.setSeriesItemLabelPaint(1, (java.awt.Paint)var52);
    var40.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    org.jfree.chart.labels.CategoryToolTipGenerator var59 = null;
    var40.setSeriesToolTipGenerator(255, var59, false);
    java.awt.Paint var63 = var40.lookupSeriesPaint(4);
    org.jfree.chart.urls.CategoryURLGenerator var65 = var40.getSeriesURLGenerator(10);
    org.jfree.chart.title.TextTitle var67 = new org.jfree.chart.title.TextTitle("Size2D[width=0.0, height=-1.0]");
    org.jfree.chart.block.LabelBlock var69 = new org.jfree.chart.block.LabelBlock("");
    var69.setURLText("");
    org.jfree.chart.text.TextBlock var72 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var73 = null;
    org.jfree.chart.util.Size2D var74 = var72.calculateDimensions(var73);
    org.jfree.data.category.CategoryDataset var76 = null;
    org.jfree.chart.axis.CategoryAxis var77 = null;
    org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var79 = null;
    var78.setPlot(var79);
    org.jfree.chart.renderer.category.CategoryItemRenderer var81 = null;
    org.jfree.chart.plot.CategoryPlot var82 = new org.jfree.chart.plot.CategoryPlot(var76, var77, (org.jfree.chart.axis.ValueAxis)var78, var81);
    java.awt.Stroke var83 = var78.getTickMarkStroke();
    java.awt.Font var84 = var78.getLabelFont();
    java.awt.Color var87 = java.awt.Color.getColor("", (-1));
    var72.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var84, (java.awt.Paint)var87);
    var69.setFont(var84);
    var67.setFont(var84);
    var40.setBaseItemLabelFont(var84);
    var0.setSeriesItemLabelFont(0, var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    boolean var7 = var6.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var9 = var6.getDataset((-123));
    int var10 = var6.getDatasetCount();
    float var11 = var6.getForegroundAlpha();
    var6.configureRangeAxes();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var14 = null;
    var13.setPlot(var14);
    var13.setLowerBound(2.0d);
    java.lang.String var18 = var13.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var19 = var13.getTickUnit();
    int var20 = var6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var13);
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var23 = var21.equals((java.lang.Object)(short)10);
    java.awt.Paint var24 = var21.getNextFillPaint();
    java.lang.Object var25 = var21.clone();
    java.awt.Paint var26 = var21.getNextPaint();
    java.awt.Paint var27 = var21.getNextOutlinePaint();
    var6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var21);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker((-3.95d));
    var6.addRangeMarker((org.jfree.chart.plot.Marker)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var13 = null;
    var12.setPlot(var13);
    org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var11.setRangeAxes(var15);
    java.awt.Paint var17 = var11.getDomainGridlinePaint();
    boolean var18 = var0.equals((java.lang.Object)var11);
    var11.setBackgroundImageAlignment(0);
    var11.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var7 = null;
    var6.setPlot(var7);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
    org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var15 = var14.getNextOutlinePaint();
    var12.setBackgroundPaint(var15);
    var10.setOutlinePaint(var15);
    var0.setSeriesPaint(1, var15, false);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Paint var24 = var0.getItemOutlinePaint(1, 0);
    var0.setBaseItemLabelsVisible(false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-16777116), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
    java.util.List var2 = var1.getLines();
    org.jfree.chart.text.TextLine var3 = null;
    var1.addLine(var3);
    org.jfree.chart.util.HorizontalAlignment var5 = var1.getLineAlignment();
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var10 = var8.toFixedWidth(0.05d);
    boolean var11 = var5.equals((java.lang.Object)var10);
    var0.setTextAlignment(var5);
    org.jfree.chart.block.BlockFrame var13 = var0.getFrame();
    java.awt.Font var14 = var0.getFont();
    boolean var15 = var0.getNotify();
    org.jfree.chart.text.TextBlock var16 = new org.jfree.chart.text.TextBlock();
    java.util.List var17 = var16.getLines();
    org.jfree.chart.text.TextLine var18 = null;
    var16.addLine(var18);
    org.jfree.chart.util.HorizontalAlignment var20 = var16.getLineAlignment();
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var25 = var23.toFixedWidth(0.05d);
    boolean var26 = var20.equals((java.lang.Object)var25);
    var0.setTextAlignment(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    org.jfree.chart.plot.Plot var21 = var19.getParent();
    org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxisForDataset(10);
    org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(15);
    java.awt.Stroke var26 = var19.getRangeGridlineStroke();
    var19.clearDomainMarkers();
    var19.setRangeCrosshairValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    var0.centerRange(Double.NaN);
    double var7 = var0.getFixedAutoRange();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var11 = null;
    var10.setPlot(var11);
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var8, var9, (org.jfree.chart.axis.ValueAxis)var10, var13);
    java.awt.Stroke var15 = var10.getTickMarkStroke();
    var10.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var19 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var20 = var19.getPadding();
    double var22 = var20.calculateTopInset(100.0d);
    var10.setLabelInsets(var20);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var27 = null;
    org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, (-1.0d));
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, (-1.0d));
    org.jfree.data.Range var33 = org.jfree.data.Range.combine(var29, var32);
    java.lang.String var34 = var32.toString();
    double var35 = var32.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var36 = new org.jfree.chart.block.RectangleConstraint(var26, var32);
    var10.setRange(var32, false, false);
    double var41 = var32.constrain((-0.55d));
    var0.setRangeWithMargins(var32);
    var0.setTickMarkInsideLength(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "Range[-1.0,-1.0]"+ "'", var34.equals("Range[-1.0,-1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1.0d));

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 1.0d, false);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    var0.setBaseItemLabelGenerator(var3);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var13 = var12.getPositiveItemLabelPositionFallback();
    java.awt.Paint var16 = var12.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var20 = null;
    var19.setPlot(var20);
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var17, var18, (org.jfree.chart.axis.ValueAxis)var19, var22);
    java.awt.Stroke var24 = var19.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var25 = null;
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
    org.jfree.chart.util.RectangleInsets var27 = var26.getItemLabelPadding();
    double var28 = var27.getTop();
    org.jfree.chart.block.LineBorder var29 = new org.jfree.chart.block.LineBorder(var16, var24, var27);
    var11.setAxisOffset(var27);
    org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var32 = var31.clone();
    org.jfree.chart.axis.AxisSpace var33 = new org.jfree.chart.axis.AxisSpace();
    var31.ensureAtLeast(var33);
    var11.setFixedRangeAxisSpace(var33);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
    boolean var37 = var0.getBaseSeriesVisible();
    var0.setBaseSeriesVisibleInLegend(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var3 = null;
//     var1.setSeriesItemLabelsVisible(0, var3, false);
//     java.awt.Stroke var6 = var1.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var7 = var1.getDrawingSupplier();
//     java.lang.Boolean var9 = var1.getSeriesCreateEntities(10);
//     java.awt.Paint var10 = var1.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var14 = var12.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var12.getBaseURLGenerator();
//     java.lang.Boolean var20 = var12.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var23 = java.awt.Color.getColor("", (-1));
//     var12.setBasePaint((java.awt.Paint)var23, true);
//     var1.setSeriesPaint(0, (java.awt.Paint)var23, false);
//     int var28 = var23.getRGB();
//     org.jfree.chart.LegendItemSource var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
//     org.jfree.chart.util.RectangleEdge var31 = var30.getLegendItemGraphicEdge();
//     java.awt.Paint var32 = var30.getItemPaint();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var37 = null;
//     var36.setPlot(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var34, var35, (org.jfree.chart.axis.ValueAxis)var36, var39);
//     org.jfree.chart.LegendItemSource var41 = null;
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle(var41);
//     org.jfree.chart.util.RectangleEdge var43 = var42.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var45 = var44.getNextOutlinePaint();
//     var42.setBackgroundPaint(var45);
//     var40.setOutlinePaint(var45);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var40);
//     var48.fireChartChanged();
//     boolean var50 = var48.getAntiAlias();
//     java.util.List var51 = var48.getSubtitles();
//     var30.addChangeListener((org.jfree.chart.event.TitleChangeListener)var48);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var56 = null;
//     var55.setPlot(var56);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var55, var58);
//     var55.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var55.java2DToValue(0.0d, var63, var64);
//     var55.setAutoTickUnitSelection(true);
//     java.awt.Stroke var68 = var55.getAxisLineStroke();
//     var48.setBorderStroke(var68);
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(Double.NaN, (java.awt.Paint)var23, var68);
//     java.awt.Paint var71 = var70.getPaint();
//     org.jfree.chart.util.RectangleAnchor var72 = var70.getLabelAnchor();
//     java.lang.Class var73 = null;
//     java.util.EventListener[] var74 = var70.getListeners(var73);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    java.util.List var19 = var15.getSubtitles();
    org.jfree.chart.util.RectangleInsets var20 = var15.getPadding();
    org.jfree.chart.plot.CategoryPlot var21 = var15.getCategoryPlot();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var23 = var22.getBasePositiveItemLabelPosition();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var33, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var38 = null;
    var36.setSeriesItemLabelsVisible(0, var38, false);
    java.awt.Stroke var41 = var36.getErrorIndicatorStroke();
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var33, var41, var42);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var45 = var44.getPositiveItemLabelPositionFallback();
    java.awt.Paint var48 = var44.getItemLabelPaint((-123), (-1));
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "Range[-1.0,-1.0]", var33, var48);
    java.awt.Paint var50 = var49.getOutlinePaint();
    var22.setBasePaint(var50, true);
    var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var22, true);
    org.jfree.chart.util.SortOrder var55 = var21.getRowRenderingOrder();
    org.jfree.chart.axis.AxisSpace var56 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var57 = var56.clone();
    org.jfree.chart.axis.AxisSpace var58 = new org.jfree.chart.axis.AxisSpace();
    var56.ensureAtLeast(var58);
    var21.setFixedRangeAxisSpace(var58);
    org.jfree.chart.axis.AxisSpace var61 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var62 = var61.clone();
    org.jfree.chart.axis.AxisCollection var63 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var64 = var63.getAxesAtTop();
    boolean var65 = var61.equals((java.lang.Object)var63);
    var58.ensureAtLeast(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.event.PlotChangeEvent var30 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
    java.awt.Color var35 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var43 = new org.jfree.chart.entity.ChartEntity(var41, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var46 = null;
    var44.setSeriesItemLabelsVisible(0, var46, false);
    java.awt.Stroke var49 = var44.getErrorIndicatorStroke();
    java.awt.Paint var50 = null;
    org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var41, var49, var50);
    org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var35, var49);
    var6.addRangeMarker((org.jfree.chart.plot.Marker)var52);
    var52.setLabel("TextBlockAnchor.BOTTOM_CENTER");
    java.awt.Stroke var56 = var52.getOutlineStroke();
    java.lang.Object var57 = var52.clone();
    var52.setValue(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    int var1 = var0.size();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var2.setBaseURLGenerator(var3);
    boolean var5 = var0.equals((java.lang.Object)var3);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var8, var11);
    java.awt.Stroke var13 = var8.getTickMarkStroke();
    java.awt.Font var14 = var8.getLabelFont();
    float var15 = var8.getTickMarkInsideLength();
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var19 = var17.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var20 = var17.getItemContainer();
    org.jfree.chart.LegendItemSource var21 = null;
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getItemLabelPadding();
    double var25 = var23.calculateTopOutset(4.0d);
    var20.setMargin(var23);
    java.awt.geom.Rectangle2D var27 = var20.getBounds();
    org.jfree.chart.entity.AxisLabelEntity var30 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var8, (java.awt.Shape)var27, "java.awt.Color[r=255,g=255,b=255]", "Size2D[width=0.0, height=0.0]");
    org.jfree.chart.axis.Axis var31 = var30.getAxis();
    boolean var32 = var0.equals((java.lang.Object)var30);
    java.lang.Object var33 = var30.clone();
    java.lang.String var34 = var30.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "AxisLabelEntity: label = null"+ "'", var34.equals("AxisLabelEntity: label = null"));

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Category Plot");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.LegendItemSource var3 = null;
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getItemLabelPadding();
    double var7 = var5.calculateTopOutset(4.0d);
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var11 = null;
    var10.setPlot(var11);
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var8, var9, (org.jfree.chart.axis.ValueAxis)var10, var13);
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleEdge var17 = var16.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var19 = var18.getNextOutlinePaint();
    var16.setBackgroundPaint(var19);
    var14.setOutlinePaint(var19);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var25 = null;
    var24.setPlot(var25);
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var22, var23, (org.jfree.chart.axis.ValueAxis)var24, var27);
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var30 = null;
    var29.setPlot(var30);
    org.jfree.chart.axis.ValueAxis[] var32 = new org.jfree.chart.axis.ValueAxis[] { var29};
    var28.setRangeAxes(var32);
    var14.setParent((org.jfree.chart.plot.Plot)var28);
    java.awt.Stroke var35 = var28.getRangeCrosshairStroke();
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.LegendItemSource var37 = null;
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
    org.jfree.chart.util.RectangleInsets var39 = var38.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var40 = null;
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
    org.jfree.chart.util.RectangleInsets var42 = var41.getItemLabelPadding();
    double var43 = var42.getTop();
    var38.setPadding(var42);
    org.jfree.chart.util.Size2D var45 = new org.jfree.chart.util.Size2D();
    boolean var47 = var45.equals((java.lang.Object)(-1L));
    double var48 = var45.getWidth();
    double var49 = var45.getHeight();
    org.jfree.chart.util.RectangleAnchor var52 = null;
    java.awt.geom.Rectangle2D var53 = org.jfree.chart.util.RectangleAnchor.createRectangle(var45, 2.0d, (-1.0d), var52);
    org.jfree.chart.axis.CategoryLabelPositions var56 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var57 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var58 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var56, var57);
    org.jfree.chart.util.RectangleAnchor var59 = var57.getCategoryAnchor();
    java.awt.geom.Rectangle2D var60 = org.jfree.chart.util.RectangleAnchor.createRectangle(var45, 2.0d, 1.0d, var59);
    java.awt.geom.Rectangle2D var61 = var42.createOutsetRectangle(var60);
    org.jfree.chart.plot.PlotRenderingInfo var63 = null;
    boolean var64 = var28.render(var36, var61, 255, var63);
    java.awt.geom.Rectangle2D var67 = var5.createInsetRectangle(var61, false, false);
    var1.setDataArea(var61);
    java.awt.geom.Rectangle2D var69 = var1.getDataArea();
    org.jfree.chart.renderer.RendererState var70 = new org.jfree.chart.renderer.RendererState(var1);
    org.jfree.chart.renderer.RendererState var71 = new org.jfree.chart.renderer.RendererState(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var15 = null;
    var13.setSeriesItemLabelsVisible(0, var15, false);
    java.awt.Stroke var18 = var13.getErrorIndicatorStroke();
    java.awt.Paint var19 = null;
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var10, var18, var19);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var18);
    org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
    java.lang.String var23 = var21.getLabel();
    org.jfree.chart.block.BlockContainer var24 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var25 = var24.getPadding();
    double var27 = var25.calculateTopInset(100.0d);
    boolean var28 = var21.equals((java.lang.Object)100.0d);
    java.lang.String var29 = var21.getLabel();
    java.lang.String var30 = var21.getLabel();
    java.lang.Object var31 = var21.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     double var2 = var0.getWidth();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, (-1.0d));
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, (-1.0d));
//     org.jfree.data.Range var13 = org.jfree.data.Range.combine(var9, var12);
//     double var14 = var12.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var15 = var6.toRangeHeight(var12);
//     org.jfree.chart.util.Size2D var16 = var0.arrange(var3, var15);
//     org.jfree.chart.LegendItemSource var17 = null;
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var17);
//     org.jfree.chart.util.RectangleEdge var19 = var18.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var21 = var20.getNextOutlinePaint();
//     var18.setBackgroundPaint(var21);
//     org.jfree.chart.text.TextBlock var23 = new org.jfree.chart.text.TextBlock();
//     java.util.List var24 = var23.getLines();
//     boolean var25 = var18.equals((java.lang.Object)var23);
//     org.jfree.chart.util.RectangleEdge var26 = var18.getLegendItemGraphicEdge();
//     org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer();
//     var18.setWrapper(var27);
//     org.jfree.chart.util.HorizontalAlignment var29 = var18.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement(var29, var30, (-8.0d), (-1.0d));
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var33);
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.LegendItemSource var36 = null;
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle(var36);
//     org.jfree.chart.util.RectangleInsets var38 = var37.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var39 = var37.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var35, var39, 0.0d, 2.0d);
//     org.jfree.data.general.Dataset var43 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var45 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var42, var43, (java.lang.Comparable)Double.NaN);
//     boolean var46 = var45.isEmpty();
//     java.lang.Comparable var47 = var45.getSeriesKey();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var50 = null;
//     var48.setSeriesItemLabelsVisible(0, var50, false);
//     java.awt.Stroke var53 = var48.getErrorIndicatorStroke();
//     java.awt.Stroke var54 = var48.getBaseStroke();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var55 = var48.getLegendItemURLGenerator();
//     java.awt.Stroke var56 = var48.getBaseOutlineStroke();
//     boolean var57 = var45.equals((java.lang.Object)var48);
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.block.BlockContainer var59 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var60 = var59.getPadding();
//     double var61 = var59.getWidth();
//     java.awt.Graphics2D var62 = null;
//     org.jfree.chart.block.RectangleConstraint var65 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.data.Range var66 = null;
//     org.jfree.data.Range var68 = org.jfree.data.Range.expandToInclude(var66, (-1.0d));
//     org.jfree.data.Range var69 = null;
//     org.jfree.data.Range var71 = org.jfree.data.Range.expandToInclude(var69, (-1.0d));
//     org.jfree.data.Range var72 = org.jfree.data.Range.combine(var68, var71);
//     double var73 = var71.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var74 = var65.toRangeHeight(var71);
//     org.jfree.chart.util.Size2D var75 = var59.arrange(var62, var74);
//     org.jfree.chart.block.RectangleConstraint var76 = var74.toUnconstrainedWidth();
//     org.jfree.data.Range var77 = var74.getWidthRange();
//     org.jfree.chart.util.Size2D var78 = var33.arrange((org.jfree.chart.block.BlockContainer)var45, var58, var74);
//     
//     // Checks the contract:  equals-hashcode on var27 and var59
//     assertTrue("Contract failed: equals-hashcode on var27 and var59", var27.equals(var59) ? var27.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var27
//     assertTrue("Contract failed: equals-hashcode on var59 and var27", var59.equals(var27) ? var59.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var75
//     assertTrue("Contract failed: equals-hashcode on var16 and var75", var16.equals(var75) ? var16.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var16
//     assertTrue("Contract failed: equals-hashcode on var75 and var16", var75.equals(var16) ? var75.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.getLicenceText();
    java.util.List var2 = null;
    var0.setContributors(var2);
    java.awt.Image var4 = var0.getLogo();
    java.lang.String var5 = var0.getLicenceText();
    var0.setLicenceName("HorizontalAlignment.CENTER version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY HorizontalAlignment.CENTER:None\nHorizontalAlignment.CENTER LICENCE TERMS:\nnull");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var6.setAnchorValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
//     int var11 = var6.getWeight();
//     org.jfree.chart.plot.DatasetRenderingOrder var12 = var6.getDatasetRenderingOrder();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var16 = null;
//     var15.setPlot(var16);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var21 = null;
//     var20.setPlot(var21);
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var20};
//     var19.setRangeAxes(var23);
//     java.awt.Paint var25 = var19.getDomainGridlinePaint();
//     org.jfree.chart.axis.ValueAxis var26 = var19.getRangeAxis();
//     int var27 = var6.getRangeAxisIndex(var26);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.util.RectangleInsets var16 = var7.getAxisOffset();
    org.jfree.chart.util.UnitType var17 = var16.getUnitType();
    java.lang.String var18 = var17.toString();
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.CategoryLabelPositions var20 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var21 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var22 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var20, var21);
    org.jfree.chart.axis.CategoryLabelPositions var23 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var24 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var25 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var23, var24);
    org.jfree.chart.axis.CategoryLabelPositions var26 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var20, var24);
    boolean var28 = var26.equals((java.lang.Object)(-8.0d));
    var19.setCategoryLabelPositions(var26);
    org.jfree.chart.axis.CategoryLabelPositions var30 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var31 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var32 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var30, var31);
    org.jfree.chart.axis.CategoryLabelPositions var33 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var34 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var35 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var33, var34);
    org.jfree.chart.axis.CategoryLabelPositions var36 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var37 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var38 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var36, var37);
    org.jfree.chart.axis.CategoryLabelPositions var39 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var33, var37);
    org.jfree.chart.axis.CategoryLabelPositions var40 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var32, var37);
    org.jfree.chart.axis.CategoryLabelWidthType var41 = var37.getWidthType();
    org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var44 = var43.getFont();
    boolean var45 = var37.equals((java.lang.Object)var44);
    org.jfree.chart.text.TextBlockAnchor var46 = var37.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var47 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var26, var37);
    boolean var48 = var17.equals((java.lang.Object)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "UnitType.ABSOLUTE"+ "'", var18.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    var0.setBaseCreateEntities(false, false);
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)false);
    boolean var17 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var0.getSeriesItemLabelGenerator(255);
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var23 = var21.equals((java.lang.Object)(short)10);
    java.awt.Paint var24 = var21.getNextFillPaint();
    java.awt.Paint var25 = var21.getNextPaint();
    java.awt.Stroke var26 = var21.getNextStroke();
    java.awt.Paint var27 = var21.getNextFillPaint();
    var0.setSeriesOutlinePaint(15, var27);
    double var29 = var0.getUpperClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setMaximumCategoryLabelWidthRatio(0.95f);
    double var3 = var0.getLowerMargin();
    java.lang.Object var4 = var0.clone();
    java.awt.Font var6 = var0.getTickLabelFont((java.lang.Comparable)"null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    int var7 = var0.getCategoryLabelPositionOffset();
    java.awt.Font var9 = var0.getTickLabelFont((java.lang.Comparable)2.0f);
    var0.addCategoryLabelToolTip((java.lang.Comparable)"RectangleAnchor.CENTER", "CategoryLabelWidthType.CATEGORY");
    var0.setLowerMargin((-8.0d));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = var16.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = null;
    var16.setBaseItemLabelGenerator(var19);
    java.awt.Paint var23 = var16.getItemFillPaint(0, (-855310));
    var0.setTickLabelPaint((java.lang.Comparable)(byte)1, var23);
    var0.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var4 = var3.getPadding();
    double var5 = var3.getWidth();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.CategoryLabelPositions var10 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var11 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var12 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var10, var11);
    org.jfree.chart.text.TextAnchor var13 = var11.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var15 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.util.RectangleEdge.opposite(var18);
    boolean var20 = var15.equals((java.lang.Object)var19);
    org.jfree.chart.labels.ItemLabelAnchor var21 = var15.getItemLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
    org.jfree.chart.text.TextAnchor var25 = var23.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var26 = new org.jfree.chart.labels.ItemLabelPosition(var21, var25);
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var7, 100.0f, 0.0f, var13, 100.0d, var25);
    org.jfree.chart.LegendItemSource var28 = null;
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
    org.jfree.chart.util.RectangleEdge var30 = var29.getLegendItemGraphicEdge();
    java.awt.Paint var31 = var29.getItemPaint();
    var29.setNotify(true);
    java.awt.geom.Rectangle2D var34 = var29.getBounds();
    boolean var35 = var25.equals((java.lang.Object)var34);
    boolean var36 = var3.equals((java.lang.Object)var25);
    java.awt.Color var41 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var49 = new org.jfree.chart.entity.ChartEntity(var47, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var50 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var52 = null;
    var50.setSeriesItemLabelsVisible(0, var52, false);
    java.awt.Stroke var55 = var50.getErrorIndicatorStroke();
    java.awt.Paint var56 = null;
    org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var47, var55, var56);
    org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var41, var55);
    org.jfree.chart.text.TextAnchor var59 = var58.getLabelTextAnchor();
    org.jfree.chart.axis.NumberTick var61 = new org.jfree.chart.axis.NumberTick(var0, 1.0E-8d, "Size2D[width=0.0, height=-1.0]", var25, var59, 4.0d);
    org.jfree.chart.axis.TickType var62 = var61.getTickType();
    java.lang.Number var63 = var61.getNumber();
    org.jfree.chart.axis.TickType var64 = var61.getTickType();
    org.jfree.chart.axis.TickType var65 = var61.getTickType();
    double var66 = var61.getValue();
    org.jfree.chart.axis.TickType var67 = var61.getTickType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + 1.0E-8d+ "'", var63.equals(1.0E-8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var3 = var2.getFont();
    java.awt.Color var7 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var3, (java.awt.Paint)var7);
    int var9 = var7.getAlpha();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = var10.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var15 = var10.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var16 = var10.getBaseURLGenerator();
    java.lang.Boolean var18 = var10.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var21 = java.awt.Color.getColor("", (-1));
    var10.setBasePaint((java.awt.Paint)var21, true);
    java.awt.Color var29 = java.awt.Color.getColor("", (-1));
    float[] var30 = null;
    float[] var31 = var29.getRGBComponents(var30);
    float[] var32 = java.awt.Color.RGBtoHSB(0, (-123), 100, var31);
    float[] var33 = var21.getRGBComponents(var31);
    float[] var34 = var7.getRGBComponents(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var20 = null;
    var18.setSeriesItemLabelsVisible(0, var20, false);
    java.awt.Stroke var23 = var18.getErrorIndicatorStroke();
    var15.setBorderStroke(var23);
    boolean var25 = var15.isBorderVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, 100.0f, 100.0f, var4);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var9 = null;
    var7.setSeriesItemLabelsVisible(0, var9, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
    var7.setSeriesToolTipGenerator(1, var13, false);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var7.setBaseURLGenerator(var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.plot.Marker var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    var7.drawRangeMarker(var18, var19, var20, var21, var22);
    org.jfree.chart.urls.CategoryURLGenerator var24 = null;
    var7.setBaseURLGenerator(var24, true);
    org.jfree.data.statistics.MeanAndStandardDeviation var29 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
    boolean var31 = var29.equals((java.lang.Object)'a');
    boolean var32 = var7.equals((java.lang.Object)var29);
    var7.setSeriesCreateEntities(255, (java.lang.Boolean)true, false);
    java.awt.Paint var38 = null;
    var7.setSeriesFillPaint(10, var38);
    java.awt.Font var42 = var7.getItemLabelFont((-253), (-16777212));
    org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("Size2D[width=0.0, height=-1.0]", var42);
    var0.addLine(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var13 = null;
    var12.setPlot(var13);
    org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var11.setRangeAxes(var15);
    java.awt.Paint var17 = var11.getDomainGridlinePaint();
    boolean var18 = var0.equals((java.lang.Object)var11);
    var11.clearAnnotations();
    java.awt.Stroke var20 = var11.getDomainGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var13 = null;
    var12.setPlot(var13);
    org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var11.setRangeAxes(var15);
    java.awt.Paint var17 = var11.getDomainGridlinePaint();
    boolean var18 = var0.equals((java.lang.Object)var11);
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var19, var20, (org.jfree.chart.axis.ValueAxis)var21, var24);
    var21.setAutoRangeMinimumSize(2.0d);
    var21.setLabel("CategoryLabelWidthType.CATEGORY");
    var21.setLowerBound(0.525d);
    org.jfree.data.Range var32 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Stroke var16 = var11.getTickMarkStroke();
    var0.setBaseOutlineStroke(var16);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var19 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var20 = var19.getEntityCollection();
    boolean var21 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.labels.ItemLabelAnchor var22 = var18.getItemLabelAnchor();
    org.jfree.chart.labels.ItemLabelAnchor var23 = var18.getItemLabelAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    var19.clearDomainMarkers();
    org.jfree.chart.LegendItemCollection var22 = null;
    var19.setFixedLegendItems(var22);
    org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var26 = var24.equals((java.lang.Object)(short)10);
    java.awt.Paint var27 = var24.getNextFillPaint();
    java.awt.Paint var28 = var24.getNextPaint();
    java.awt.Paint var29 = var24.getNextFillPaint();
    org.jfree.chart.util.HorizontalAlignment var30 = null;
    org.jfree.chart.LegendItemSource var31 = null;
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
    org.jfree.chart.util.RectangleInsets var33 = var32.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var34 = var32.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var30, var34, 0.0d, 2.0d);
    org.jfree.data.general.Dataset var38 = null;
    org.jfree.chart.title.LegendItemBlockContainer var40 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var37, var38, (java.lang.Comparable)Double.NaN);
    org.jfree.data.general.Dataset var41 = var40.getDataset();
    java.lang.String var42 = var40.getURLText();
    org.jfree.chart.LegendItemSource var43 = null;
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle(var43);
    org.jfree.chart.util.RectangleInsets var45 = var44.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var46 = var44.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var47 = var44.getItemContainer();
    org.jfree.chart.LegendItemSource var48 = null;
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle(var48);
    org.jfree.chart.util.RectangleInsets var50 = var49.getItemLabelPadding();
    double var52 = var50.calculateTopOutset(4.0d);
    var47.setMargin(var50);
    java.awt.geom.Rectangle2D var54 = var47.getBounds();
    var40.setBounds(var54);
    var40.setURLText("RectangleAnchor.CENTER");
    org.jfree.chart.block.BlockContainer var58 = new org.jfree.chart.block.BlockContainer();
    java.util.List var59 = var58.getBlocks();
    boolean var60 = var58.isEmpty();
    var40.add((org.jfree.chart.block.Block)var58);
    boolean var62 = var24.equals((java.lang.Object)var40);
    var19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var2 = null;
//     var0.addObject((java.lang.Comparable)'#', var2);
//     java.lang.Object var4 = var0.clone();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     var7.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var7.java2DToValue(0.0d, var15, var16);
//     org.jfree.chart.axis.NumberTickUnit var18 = var7.getTickUnit();
//     int var19 = var0.getIndex((java.lang.Comparable)var18);
//     java.lang.Object var21 = var0.getObject((-855310));
//     int var22 = var0.getItemCount();
//     java.util.List var23 = var0.getKeys();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     boolean var26 = var25.isNegativeArrowVisible();
//     java.lang.String var27 = var25.getLabelURL();
//     var25.setLabelAngle(6.0d);
//     var25.setAutoRange(false);
//     java.lang.Object var32 = var25.clone();
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var34 = null;
//     var33.setPlot(var34);
//     org.jfree.chart.block.BlockContainer var36 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var37 = var36.getPadding();
//     double var39 = var37.calculateTopInset(100.0d);
//     double var41 = var37.calculateTopInset(2.0d);
//     var33.setLabelInsets(var37);
//     var33.setFixedAutoRange(10.0d);
//     org.jfree.data.Range var47 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.Range var48 = null;
//     org.jfree.data.Range var50 = org.jfree.data.Range.expandToInclude(var48, (-1.0d));
//     org.jfree.data.Range var51 = null;
//     org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, (-1.0d));
//     org.jfree.data.Range var54 = org.jfree.data.Range.combine(var50, var53);
//     java.lang.String var55 = var53.toString();
//     double var56 = var53.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var57 = new org.jfree.chart.block.RectangleConstraint(var47, var53);
//     var33.setRange(var47);
//     var25.setDefaultAutoRange(var47);
//     var0.setObject((java.lang.Comparable)246.39999999999995d, (java.lang.Object)var47);
//     java.lang.Object var62 = var0.getObject((java.lang.Comparable)0.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "Range[-1.0,-1.0]"+ "'", var55.equals("Range[-1.0,-1.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), (-1.0f), 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    double var5 = var2.getLowerMargin();
    java.awt.Shape var6 = var2.getDownArrow();
    var0.setShape(0, var6);
    boolean var9 = var0.equals((java.lang.Object)(short)1);
    java.lang.Object var10 = var0.clone();
    java.awt.Shape var12 = var0.getShape(0);
    java.awt.Shape var14 = var0.getShape(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("5,9,5,9,5,9,5,9,5,9,5,9", var1, 0.8f, 0.0f, (-5.0d), 10.0f, 1.0f);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var21 = null;
    var19.setSeriesItemLabelsVisible(0, var21, false);
    java.awt.Stroke var24 = var19.getErrorIndicatorStroke();
    java.awt.Paint var25 = null;
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var16, var24, var25);
    var0.setBaseStroke(var24, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var29 = var0.getLegendItemLabelGenerator();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var34 = null;
    var33.setPlot(var34);
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var31, var32, (org.jfree.chart.axis.ValueAxis)var33, var36);
    org.jfree.chart.LegendItemSource var38 = null;
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle(var38);
    org.jfree.chart.util.RectangleEdge var40 = var39.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var42 = var41.getNextOutlinePaint();
    var39.setBackgroundPaint(var42);
    var37.setOutlinePaint(var42);
    org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var37);
    java.lang.Object var46 = var45.clone();
    org.jfree.chart.plot.CategoryPlot var47 = var45.getCategoryPlot();
    var0.setPlot(var47);
    boolean var49 = var47.getDrawSharedDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var14, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    java.awt.Paint var23 = null;
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var14, var22, var23);
    boolean var25 = var24.isLineVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    java.lang.Object var28 = var26.clone();
    var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setBaseSeriesVisibleInLegend(true, true);
    java.awt.Stroke var36 = var0.getItemStroke((-855310), (-123));
    boolean var37 = var0.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    var0.ensureAtLeast(var2);
    double var4 = var2.getTop();
    double var5 = var2.getBottom();
    double var6 = var2.getRight();
    var2.setBottom(0.0d);
    double var9 = var2.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    var0.ensureAtLeast(var2);
    double var4 = var2.getTop();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    var11.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var17 = null;
    var15.setSeriesItemLabelsVisible(0, var17, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
    var15.setSeriesToolTipGenerator(1, var21, false);
    org.jfree.chart.urls.CategoryURLGenerator var24 = null;
    var15.setBaseURLGenerator(var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.plot.Marker var29 = null;
    java.awt.geom.Rectangle2D var30 = null;
    var15.drawRangeMarker(var26, var27, var28, var29, var30);
    boolean var33 = var15.isSeriesVisibleInLegend(0);
    var11.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.CategoryAxis var35 = null;
    java.util.List var36 = var11.getCategoriesForAxis(var35);
    java.awt.Font var37 = var11.getNoDataMessageFont();
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    boolean var39 = var2.equals((java.lang.Object)var11);
    org.jfree.chart.axis.AxisLocation var41 = var11.getRangeAxisLocation(0);
    org.jfree.chart.util.SortOrder var42 = var11.getRowRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var1 = var0.getLocale();
    java.lang.Object[][] var2 = var0.getContents();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject("java.awt.Color[r=255,g=255,b=255]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    int var1 = var0.size();
    java.lang.Object var2 = var0.clone();
    java.awt.Stroke var4 = var0.getStroke(100);
    java.awt.Stroke var6 = var0.getStroke((-16777212));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.setVerticalTickLabels(false);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var13 = null;
    var12.setPlot(var13);
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var12, var15);
    var16.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var22 = null;
    var20.setSeriesItemLabelsVisible(0, var22, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var26 = null;
    var20.setSeriesToolTipGenerator(1, var26, false);
    org.jfree.chart.urls.CategoryURLGenerator var29 = null;
    var20.setBaseURLGenerator(var29);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.plot.Marker var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    var20.drawRangeMarker(var31, var32, var33, var34, var35);
    boolean var38 = var20.isSeriesVisibleInLegend(0);
    var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    var2.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
    org.jfree.chart.axis.AxisSpace var41 = var16.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisSpace var42 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var43 = var42.clone();
    org.jfree.chart.axis.AxisSpace var44 = new org.jfree.chart.axis.AxisSpace();
    var42.ensureAtLeast(var44);
    var16.setFixedRangeAxisSpace(var44);
    var44.setTop(100.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    var1.setLegendItemGraphicLocation(var3);
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    org.jfree.chart.LegendItemSource var6 = null;
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var9 = var7.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var5, var9, 0.0d, 2.0d);
    org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var14 = var13.getPadding();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.util.Size2D var19 = var12.arrange(var13, var15, var18);
    var1.setWrapper(var13);
    org.jfree.chart.util.RectangleAnchor var21 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.util.RectangleInsets var22 = var1.getMargin();
    double var23 = var22.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     org.jfree.chart.text.TextBlock var3 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.util.Size2D var5 = var3.calculateDimensions(var4);
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var10 = null;
//     var9.setPlot(var10);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var8, (org.jfree.chart.axis.ValueAxis)var9, var12);
//     java.awt.Stroke var14 = var9.getTickMarkStroke();
//     java.awt.Font var15 = var9.getLabelFont();
//     java.awt.Color var18 = java.awt.Color.getColor("", (-1));
//     var3.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var15, (java.awt.Paint)var18);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var22 = var20.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var23 = null;
//     var20.setBaseItemLabelGenerator(var23);
//     java.awt.Paint var27 = var20.getItemFillPaint(0, (-855310));
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("NOID", var15, var27, 2.0f);
//     var1.addFragment(var29);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.util.Size2D var32 = var29.calculateDimensions(var31);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var14, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    java.awt.Paint var23 = null;
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var14, var22, var23);
    boolean var25 = var24.isLineVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    java.lang.Object var28 = var26.clone();
    var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setAutoPopulateSeriesPaint(true);
    java.awt.Font var35 = var0.getItemLabelFont((-855310), (-16777212));
    java.awt.Stroke var36 = var0.getBaseOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }


    org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
    java.util.List var2 = var1.getLines();
    org.jfree.chart.text.TextLine var3 = null;
    var1.addLine(var3);
    org.jfree.chart.util.HorizontalAlignment var5 = var1.getLineAlignment();
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
    boolean var16 = var11.equals((java.lang.Object)var15);
    org.jfree.chart.labels.ItemLabelAnchor var17 = var11.getItemLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var18 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var18, var19);
    org.jfree.chart.text.TextAnchor var21 = var19.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var22 = new org.jfree.chart.labels.ItemLabelPosition(var17, var21);
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var8, 1.0f, (-1.0f), var21, 2.0d, 1.0f, 0.0f);
    org.jfree.chart.axis.CategoryTick var28 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var1, var6, var21, 0.0d);
    org.jfree.chart.text.TextAnchor var29 = var28.getTextAnchor();
    org.jfree.chart.text.TextBlockAnchor var30 = var28.getLabelAnchor();
    org.jfree.chart.text.TextBlockAnchor var31 = var28.getLabelAnchor();
    org.jfree.chart.plot.DefaultDrawingSupplier var32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var34 = var32.equals((java.lang.Object)(short)10);
    java.awt.Paint var35 = var32.getNextFillPaint();
    java.awt.Paint var36 = var32.getNextPaint();
    java.awt.Paint var37 = var32.getNextFillPaint();
    org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var37);
    boolean var39 = var28.equals((java.lang.Object)var37);
    org.jfree.chart.LegendItemSource var40 = null;
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
    org.jfree.chart.util.RectangleEdge var42 = var41.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var43 = null;
    var41.setLegendItemGraphicLocation(var43);
    org.jfree.chart.util.HorizontalAlignment var45 = null;
    org.jfree.chart.LegendItemSource var46 = null;
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var46);
    org.jfree.chart.util.RectangleInsets var48 = var47.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var49 = var47.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement(var45, var49, 0.0d, 2.0d);
    org.jfree.chart.block.BlockContainer var53 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var54 = var53.getPadding();
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.block.RectangleConstraint var58 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.util.Size2D var59 = var52.arrange(var53, var55, var58);
    var41.setWrapper(var53);
    boolean var61 = var28.equals((java.lang.Object)var53);
    double var62 = var53.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var4 = null;
    var2.setSeriesItemLabelsVisible(0, var4, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var2.setSeriesToolTipGenerator(1, var8, false);
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var2.setBaseURLGenerator(var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.Marker var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    var2.drawRangeMarker(var13, var14, var15, var16, var17);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var2.setBaseURLGenerator(var19, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var24 = null;
    var22.setSeriesItemLabelsVisible(0, var24, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
    var22.setSeriesToolTipGenerator(1, var28, false);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var22.setBaseURLGenerator(var31);
    var22.setBaseCreateEntities(false, false);
    var22.setBaseSeriesVisibleInLegend(false);
    var22.setBaseItemLabelsVisible(true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var43 = var41.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var46 = var41.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var47 = var41.getBaseURLGenerator();
    java.lang.Boolean var49 = var41.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var50 = null;
    org.jfree.chart.axis.CategoryAxis var51 = null;
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var53 = null;
    var52.setPlot(var53);
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var50, var51, (org.jfree.chart.axis.ValueAxis)var52, var55);
    java.awt.Stroke var57 = var52.getTickMarkStroke();
    var41.setBaseOutlineStroke(var57);
    org.jfree.chart.labels.ItemLabelPosition var59 = var41.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var60 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var61 = var60.getEntityCollection();
    boolean var62 = var59.equals((java.lang.Object)var60);
    var22.setSeriesPositiveItemLabelPosition(0, var59);
    var2.setPositiveItemLabelPositionFallback(var59);
    org.jfree.data.category.CategoryDataset var66 = null;
    org.jfree.chart.axis.CategoryAxis var67 = null;
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var69 = null;
    var68.setPlot(var69);
    org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var66, var67, (org.jfree.chart.axis.ValueAxis)var68, var71);
    org.jfree.chart.LegendItemSource var73 = null;
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
    org.jfree.chart.util.RectangleEdge var75 = var74.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var77 = var76.getNextOutlinePaint();
    var74.setBackgroundPaint(var77);
    var72.setOutlinePaint(var77);
    org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var72);
    var80.fireChartChanged();
    var80.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var84 = var80.getCategoryPlot();
    var84.clearRangeAxes();
    var84.clearDomainMarkers();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var87 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var88 = var87.getPositiveItemLabelPositionFallback();
    java.awt.Paint var91 = var87.getItemLabelPaint((-123), (-1));
    var84.setOutlinePaint(var91);
    var2.setBaseOutlinePaint(var91);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic(var1, var91);
    java.awt.Stroke var95 = null;
    var94.setOutlineStroke(var95);
    java.lang.Object var97 = var94.clone();
    boolean var98 = var94.isShapeVisible();
    org.jfree.chart.util.RectangleAnchor var99 = var94.getShapeAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var15 = null;
    var13.setSeriesItemLabelsVisible(0, var15, false);
    java.awt.Stroke var18 = var13.getErrorIndicatorStroke();
    java.awt.Paint var19 = null;
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var10, var18, var19);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var18);
    org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
    java.lang.String var23 = var21.getLabel();
    org.jfree.chart.util.LengthAdjustmentType var24 = var21.getLabelOffsetType();
    java.awt.Stroke var25 = var21.getOutlineStroke();
    org.jfree.chart.event.MarkerChangeEvent var26 = null;
    var21.notifyListeners(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    java.awt.Font var10 = var0.getSeriesItemLabelFont((-123));
    org.jfree.chart.util.StrokeList var11 = new org.jfree.chart.util.StrokeList();
    java.awt.Shape[] var12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    boolean var13 = var11.equals((java.lang.Object)var12);
    boolean var14 = var0.equals((java.lang.Object)var12);
    var0.setSeriesItemLabelsVisible(255, false);
    org.jfree.chart.util.StandardGradientPaintTransformer var18 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var18);
    java.awt.Paint var22 = var0.getItemFillPaint((-1), 0);
    boolean var23 = var0.getAutoPopulateSeriesOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var2 = null;
//     var0.addObject((java.lang.Comparable)'#', var2);
//     java.lang.Object var4 = var0.clone();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     var7.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var7.java2DToValue(0.0d, var15, var16);
//     org.jfree.chart.axis.NumberTickUnit var18 = var7.getTickUnit();
//     int var19 = var0.getIndex((java.lang.Comparable)var18);
//     org.jfree.chart.block.CenterArrangement var20 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.text.TextBlock var22 = new org.jfree.chart.text.TextBlock();
//     java.util.List var23 = var22.getLines();
//     org.jfree.chart.text.TextLine var24 = null;
//     var22.addLine(var24);
//     org.jfree.chart.util.HorizontalAlignment var26 = var22.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var27 = null;
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.labels.ItemLabelPosition var32 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.util.RectangleEdge var35 = var34.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var36 = org.jfree.chart.util.RectangleEdge.opposite(var35);
//     boolean var37 = var32.equals((java.lang.Object)var36);
//     org.jfree.chart.labels.ItemLabelAnchor var38 = var32.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var39 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var40 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var41 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var39, var40);
//     org.jfree.chart.text.TextAnchor var42 = var40.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var43 = new org.jfree.chart.labels.ItemLabelPosition(var38, var42);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var29, 1.0f, (-1.0f), var42, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var49 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var22, var27, var42, 0.0d);
//     java.lang.String var50 = var49.getText();
//     boolean var51 = var20.equals((java.lang.Object)var50);
//     org.jfree.chart.block.BlockContainer var52 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var53 = var52.getPadding();
//     double var54 = var52.getWidth();
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.block.RectangleConstraint var58 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.data.Range var59 = null;
//     org.jfree.data.Range var61 = org.jfree.data.Range.expandToInclude(var59, (-1.0d));
//     org.jfree.data.Range var62 = null;
//     org.jfree.data.Range var64 = org.jfree.data.Range.expandToInclude(var62, (-1.0d));
//     org.jfree.data.Range var65 = org.jfree.data.Range.combine(var61, var64);
//     double var66 = var64.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var67 = var58.toRangeHeight(var64);
//     org.jfree.chart.util.Size2D var68 = var52.arrange(var55, var67);
//     java.awt.Graphics2D var69 = null;
//     org.jfree.chart.util.Size2D var70 = var52.arrange(var69);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var71 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.util.EventListener var72 = null;
//     boolean var73 = var71.hasListener(var72);
//     int var75 = var71.getRowIndex((java.lang.Comparable)(-855310));
//     var20.add((org.jfree.chart.block.Block)var52, (java.lang.Object)(-855310));
//     int var77 = var18.compareTo((java.lang.Object)var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + ""+ "'", var50.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == (-1));
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.util.List var7 = var6.getLines();
    boolean var8 = var1.equals((java.lang.Object)var6);
    org.jfree.chart.util.RectangleEdge var9 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var10 = var1.getLegendItemGraphicLocation();
    java.lang.Object var11 = var1.clone();
    org.jfree.chart.util.HorizontalAlignment var12 = var1.getHorizontalAlignment();
    org.jfree.data.general.DatasetGroup var13 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.LegendItemSource var14 = null;
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
    org.jfree.chart.util.RectangleEdge var16 = var15.getLegendItemGraphicEdge();
    boolean var17 = var13.equals((java.lang.Object)var15);
    org.jfree.chart.util.StandardGradientPaintTransformer var18 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var19 = var18.clone();
    boolean var20 = var15.equals((java.lang.Object)var18);
    org.jfree.chart.LegendItemSource[] var21 = var15.getSources();
    var1.setSources(var21);
    java.lang.String var23 = var1.getID();
    org.jfree.chart.util.RectangleAnchor var24 = var1.getLegendItemGraphicLocation();
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var26 = null;
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var28 = null;
    var27.setPlot(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var25, var26, (org.jfree.chart.axis.ValueAxis)var27, var30);
    boolean var32 = var31.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var34 = var31.getDataset((-123));
    var31.clearRangeMarkers(0);
    java.awt.Paint var37 = var31.getBackgroundPaint();
    var31.setAnchorValue((-1.0d));
    org.jfree.chart.util.RectangleEdge var41 = var31.getRangeAxisEdge((-855310));
    var1.setLegendItemGraphicEdge(var41);
    org.jfree.chart.util.HorizontalAlignment var43 = null;
    org.jfree.chart.LegendItemSource var44 = null;
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle(var44);
    org.jfree.chart.util.RectangleInsets var46 = var45.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var47 = var45.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var43, var47, 0.0d, 2.0d);
    org.jfree.data.general.Dataset var51 = null;
    org.jfree.chart.title.LegendItemBlockContainer var53 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var50, var51, (java.lang.Comparable)Double.NaN);
    org.jfree.data.general.Dataset var54 = var53.getDataset();
    org.jfree.data.general.Dataset var55 = var53.getDataset();
    var1.setWrapper((org.jfree.chart.block.BlockContainer)var53);
    org.jfree.chart.block.BlockContainer var57 = var1.getItemContainer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var4 = var2.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var0, var4, 0.0d, 2.0d);
//     org.jfree.data.general.Dataset var8 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var8, (java.lang.Comparable)Double.NaN);
//     boolean var11 = var10.isEmpty();
//     java.lang.Comparable var12 = var10.getSeriesKey();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.LegendItemSource var14 = null;
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
//     org.jfree.chart.util.RectangleEdge var16 = var15.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var18 = var17.getNextOutlinePaint();
//     var15.setBackgroundPaint(var18);
//     org.jfree.chart.util.HorizontalAlignment var20 = var15.getHorizontalAlignment();
//     double var21 = var15.getContentYOffset();
//     org.jfree.chart.text.TextBlock var22 = new org.jfree.chart.text.TextBlock();
//     java.util.List var23 = var22.getLines();
//     org.jfree.chart.text.TextLine var24 = null;
//     var22.addLine(var24);
//     org.jfree.chart.util.HorizontalAlignment var26 = var22.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 1.0d, 100.0d);
//     var15.setHorizontalAlignment(var26);
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.util.RectangleInsets var35 = var34.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var36 = var34.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var39 = new org.jfree.chart.block.ColumnArrangement(var32, var36, 0.0d, 2.0d);
//     org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var26, var36, 1.0d, 1.0E-8d);
//     org.jfree.chart.block.FlowArrangement var45 = new org.jfree.chart.block.FlowArrangement(var13, var36, 0.0d, 4.0d);
//     var45.clear();
//     var10.setArrangement((org.jfree.chart.block.Arrangement)var45);
//     
//     // Checks the contract:  equals-hashcode on var7 and var39
//     assertTrue("Contract failed: equals-hashcode on var7 and var39", var7.equals(var39) ? var7.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var7
//     assertTrue("Contract failed: equals-hashcode on var39 and var7", var39.equals(var7) ? var39.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setMaximumCategoryLabelWidthRatio(0.95f);
    double var3 = var0.getLowerMargin();
    java.lang.Object var4 = var0.clone();
    java.awt.Font var6 = var0.getTickLabelFont((java.lang.Comparable)"null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    int var7 = var0.getCategoryLabelPositionOffset();
    java.awt.Font var9 = var0.getTickLabelFont((java.lang.Comparable)2.0f);
    var0.addCategoryLabelToolTip((java.lang.Comparable)"RectangleAnchor.CENTER", "CategoryLabelWidthType.CATEGORY");
    var0.setLowerMargin((-8.0d));
    double var15 = var0.getCategoryMargin();
    var0.setMaximumCategoryLabelWidthRatio(2.0f);
    int var18 = var0.getMaximumCategoryLabelLines();
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var19, var20, (org.jfree.chart.axis.ValueAxis)var21, var24);
    var25.setAnchorValue(0.0d, true);
    boolean var29 = var25.getDrawSharedDomainAxis();
    org.jfree.chart.axis.ValueAxis var30 = var25.getRangeAxis();
    int var31 = var25.getWeight();
    var0.setPlot((org.jfree.chart.plot.Plot)var25);
    org.jfree.chart.LegendItemCollection var33 = var25.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    int var1 = var0.size();
    java.lang.Object var2 = var0.clone();
    java.awt.Stroke var4 = var0.getStroke(1);
    int var5 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var2.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var2.java2DToValue(0.0d, var10, var11);
//     var2.setAutoTickUnitSelection(true);
//     org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo();
//     var15.setInfo("");
//     java.lang.String var18 = var15.getLicenceText();
//     java.lang.String var19 = var15.getCopyright();
//     var15.setInfo("hi!");
//     boolean var22 = var2.equals((java.lang.Object)"hi!");
//     double var23 = var2.getFixedAutoRange();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    int var16 = var15.getDatasetIndex();
    org.jfree.data.general.Dataset var17 = var15.getDataset();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var19 = null;
    var18.setPlot(var19);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    var21.setLowerBound(2.0d);
    java.lang.String var26 = var21.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var27 = var21.getTickUnit();
    int var28 = var27.getMinorTickCount();
    org.jfree.data.category.CategoryDataset var30 = null;
    org.jfree.chart.axis.CategoryAxis var31 = null;
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var33 = null;
    var32.setPlot(var33);
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var30, var31, (org.jfree.chart.axis.ValueAxis)var32, var35);
    java.awt.Stroke var37 = var32.getTickMarkStroke();
    java.awt.Font var38 = var32.getLabelFont();
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var40 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var42 = null;
    var41.setPlot(var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var40, (org.jfree.chart.axis.ValueAxis)var41, var44);
    java.awt.Stroke var46 = var41.getTickMarkStroke();
    var41.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var50 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var51 = var50.getPadding();
    double var53 = var51.calculateTopInset(100.0d);
    var41.setLabelInsets(var51);
    java.awt.Paint var55 = var41.getTickMarkPaint();
    org.jfree.chart.text.TextFragment var57 = new org.jfree.chart.text.TextFragment("NOID", var38, var55, 10.0f);
    int var58 = var27.compareTo((java.lang.Object)"NOID");
    java.lang.String var60 = var27.valueToString(4.0d);
    var18.setTickUnit(var27);
    org.jfree.chart.LegendItemSource var62 = null;
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle(var62);
    org.jfree.chart.util.RectangleEdge var64 = var63.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var65 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var66 = var65.getNextOutlinePaint();
    var63.setBackgroundPaint(var66);
    org.jfree.chart.text.TextBlock var68 = new org.jfree.chart.text.TextBlock();
    java.util.List var69 = var68.getLines();
    boolean var70 = var63.equals((java.lang.Object)var68);
    java.awt.Graphics2D var71 = null;
    org.jfree.chart.axis.CategoryLabelPositions var74 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var75 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var76 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var74, var75);
    float var77 = var75.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var78 = var75.getLabelAnchor();
    java.awt.Shape var82 = var68.calculateBounds(var71, 0.5f, 0.0f, var78, 1.0f, 0.0f, (-12.0d));
    int var83 = var27.compareTo((java.lang.Object)var71);
    var15.setSeriesKey((java.lang.Comparable)var83);
    int var85 = var15.getSeriesIndex();
    java.awt.Stroke var86 = var15.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + "4"+ "'", var60.equals("4"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getSeriesRunningTotal();
    double var3 = var1.getBarWidth();
    double var4 = var1.getSeriesRunningTotal();
    var1.setBarWidth(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var4 = var2.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var2.setBaseItemLabelGenerator(var5);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var8 = var7.getNextOutlinePaint();
    var2.setErrorIndicatorPaint(var8);
    java.awt.Font var10 = var2.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.CATEGORY", var10);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var14 = null;
    var12.setSeriesItemLabelsVisible(0, var14, false);
    java.awt.Stroke var17 = var12.getErrorIndicatorStroke();
    boolean var18 = var12.getBaseSeriesVisible();
    java.awt.Color var21 = java.awt.Color.getColor("Range[-1.0,-1.0]", 0);
    int var22 = var21.getBlue();
    org.jfree.chart.block.BlockContainer var23 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var24 = var23.getPadding();
    double var25 = var23.getWidth();
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, (-1.0d));
    org.jfree.data.Range var33 = null;
    org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, (-1.0d));
    org.jfree.data.Range var36 = org.jfree.data.Range.combine(var32, var35);
    double var37 = var35.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var38 = var29.toRangeHeight(var35);
    org.jfree.chart.util.Size2D var39 = var23.arrange(var26, var38);
    org.jfree.chart.block.RectangleConstraint var40 = var38.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var42 = var38.toFixedWidth(100.0d);
    org.jfree.chart.block.RectangleConstraint var44 = var42.toFixedWidth(100.0d);
    boolean var45 = var21.equals((java.lang.Object)100.0d);
    var12.setBaseItemLabelPaint((java.awt.Paint)var21);
    org.jfree.chart.text.TextLine var47 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=-5.0, height=0.0]", var10, (java.awt.Paint)var21);
    java.lang.String var48 = var21.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var48.equals("java.awt.Color[r=0,g=0,b=0]"));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    boolean var7 = var6.isDomainZoomable();
    float var8 = var6.getBackgroundAlpha();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var15 = null;
    var14.setPlot(var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
    org.jfree.chart.LegendItemSource var19 = null;
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var23 = var22.getNextOutlinePaint();
    var20.setBackgroundPaint(var23);
    var18.setOutlinePaint(var23);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var18);
    var26.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var28 = var26.getCategoryPlot();
    org.jfree.chart.plot.Plot var29 = var26.getPlot();
    org.jfree.chart.LegendItemSource var30 = null;
    org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle(var30);
    org.jfree.chart.util.RectangleInsets var32 = var31.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var33 = var31.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var34 = var31.getItemContainer();
    var26.removeSubtitle((org.jfree.chart.title.Title)var31);
    org.jfree.chart.block.LabelBlock var37 = new org.jfree.chart.block.LabelBlock("");
    boolean var39 = var37.equals((java.lang.Object)' ');
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    boolean var41 = var40.isNegativeArrowVisible();
    java.lang.String var42 = var40.getLabelURL();
    var40.setLabelAngle(6.0d);
    var40.setAutoRange(false);
    java.awt.Font var47 = var40.getTickLabelFont();
    var37.setFont(var47);
    var31.setItemFont(var47);
    org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.CATEGORY", var47);
    org.jfree.chart.block.LabelBlock var51 = new org.jfree.chart.block.LabelBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var47);
    var6.setNoDataMessageFont(var47);
    org.jfree.data.general.DatasetGroup var53 = var6.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    double var9 = var0.getUpperClip();
    java.awt.Stroke var10 = var0.getBaseStroke();
    java.awt.Shape var13 = var0.getItemShape(4, 10);
    org.jfree.chart.labels.ItemLabelPosition var14 = var0.getBasePositiveItemLabelPosition();
    java.awt.Paint var17 = var0.getItemOutlinePaint(0, 0);
    java.awt.Stroke var19 = var0.getSeriesOutlineStroke((-123));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(2.0d);
    org.jfree.chart.LegendItemSource var3 = null;
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
    org.jfree.chart.util.RectangleEdge var5 = var4.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var7 = var6.getNextOutlinePaint();
    var4.setBackgroundPaint(var7);
    org.jfree.chart.text.TextBlock var9 = new org.jfree.chart.text.TextBlock();
    java.util.List var10 = var9.getLines();
    boolean var11 = var4.equals((java.lang.Object)var9);
    org.jfree.chart.util.RectangleEdge var12 = var4.getLegendItemGraphicEdge();
    var1.moveCursor(2.0d, var12);
    org.jfree.chart.axis.AxisSpace var15 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.axis.AxisCollection var17 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var18 = var17.getAxesAtTop();
    boolean var19 = var15.equals((java.lang.Object)var17);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var21 = null;
    var20.setPlot(var21);
    var20.setLowerBound(2.0d);
    java.lang.String var25 = var20.getLabelToolTip();
    java.awt.Shape var26 = var20.getRightArrow();
    org.jfree.chart.LegendItemSource var27 = null;
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle(var27);
    org.jfree.chart.util.RectangleEdge var29 = var28.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var30 = org.jfree.chart.util.RectangleEdge.opposite(var29);
    boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
    var17.add((org.jfree.chart.axis.Axis)var20, var30);
    var1.moveCursor(6.0d, var30);
    var1.setCursor(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var2 = null;
//     var0.addObject((java.lang.Comparable)'#', var2);
//     java.lang.Object var4 = var0.clone();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     var7.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var7.java2DToValue(0.0d, var15, var16);
//     org.jfree.chart.axis.NumberTickUnit var18 = var7.getTickUnit();
//     int var19 = var0.getIndex((java.lang.Comparable)var18);
//     java.util.List var20 = var0.getKeys();
//     org.jfree.data.KeyedObjects2D var21 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var22 = var21.getColumnKeys();
//     var21.removeColumn((java.lang.Comparable)0.0f);
//     org.jfree.chart.axis.CategoryLabelPositions var25 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var26 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var27 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var25, var26);
//     org.jfree.chart.text.TextAnchor var28 = var26.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var29 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var30 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var29, var30);
//     org.jfree.chart.util.RectangleAnchor var32 = var30.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var33 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var34 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var35 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var33, var34);
//     org.jfree.chart.text.TextAnchor var36 = var34.getRotationAnchor();
//     boolean var38 = var34.equals((java.lang.Object)6.0d);
//     org.jfree.chart.axis.CategoryLabelPosition var39 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var40 = var39.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var41 = new org.jfree.chart.axis.CategoryLabelPositions(var26, var30, var34, var39);
//     java.lang.Comparable var42 = null;
//     var21.addObject((java.lang.Object)var41, var42, (java.lang.Comparable)'4');
//     boolean var45 = var0.equals((java.lang.Object)var21);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var47 = null;
//     var46.setPlot(var47);
//     var46.setLowerBound(2.0d);
//     java.lang.String var51 = var46.getLabelToolTip();
//     org.jfree.chart.axis.NumberTickUnit var52 = var46.getTickUnit();
//     org.jfree.data.general.DatasetGroup var53 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.chart.LegendItemSource var54 = null;
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle(var54);
//     org.jfree.chart.util.RectangleEdge var56 = var55.getLegendItemGraphicEdge();
//     boolean var57 = var53.equals((java.lang.Object)var55);
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var61 = null;
//     var60.setPlot(var61);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var58, var59, (org.jfree.chart.axis.ValueAxis)var60, var63);
//     boolean var65 = var64.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var67 = var64.getDataset((-123));
//     var64.clearRangeMarkers(0);
//     java.awt.Paint var70 = var64.getBackgroundPaint();
//     var64.setAnchorValue((-1.0d));
//     org.jfree.chart.util.RectangleEdge var74 = var64.getRangeAxisEdge((-855310));
//     boolean var75 = var53.equals((java.lang.Object)var64);
//     boolean var76 = var52.equals((java.lang.Object)var64);
//     int var77 = var21.getColumnIndex((java.lang.Comparable)var76);
//     java.util.List var78 = var21.getRowKeys();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    org.jfree.chart.text.TextLine var2 = null;
    var0.addLine(var2);
    org.jfree.chart.util.HorizontalAlignment var4 = var0.getLineAlignment();
    org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var6 = var5.getLastTextFragment();
    var0.addLine(var5);
    org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=null, tooltip=hi!, url=");
    var0.addLine(var9);
    org.jfree.chart.text.TextFragment var11 = var9.getLastTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    java.lang.String var5 = var0.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var6 = var0.getTickUnit();
    org.jfree.data.Range var7 = var0.getRange();
    boolean var8 = var0.getAutoRangeStickyZero();
    double var9 = var0.getFixedAutoRange();
    org.jfree.chart.axis.TickUnitSource var10 = var0.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var11 = null;
    var0.setMarkerBand(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }


    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleEdge var3 = var2.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var5 = var4.getNextOutlinePaint();
    var2.setBackgroundPaint(var5);
    org.jfree.chart.util.HorizontalAlignment var7 = var2.getHorizontalAlignment();
    org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.LegendItemSource var9 = null;
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getItemLabelPadding();
    double var12 = var11.getTop();
    double var14 = var11.trimWidth(10.0d);
    var8.setMargin(var11);
    var2.setLegendItemGraphicPadding(var11);
    double var18 = var11.extendWidth((-1.0d));
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var19, var20, (org.jfree.chart.axis.ValueAxis)var21, var24);
    var25.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var29 = var25.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var30 = var25.getRangeAxisEdge();
    java.awt.Color var37 = java.awt.Color.getColor("", (-1));
    org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder((-8.0d), (-1.0d), (-8.0d), 0.0d, (java.awt.Paint)var37);
    var25.setDomainGridlinePaint((java.awt.Paint)var37);
    org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder(var11, (java.awt.Paint)var37);
    java.lang.String var41 = var37.toString();
    java.awt.Color var42 = java.awt.Color.getColor("Size2D[width=0.0, height=-1.0]", var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "java.awt.Color[r=255,g=255,b=255]"+ "'", var41.equals("java.awt.Color[r=255,g=255,b=255]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    boolean var6 = var0.getBaseSeriesVisible();
    java.awt.Color var9 = java.awt.Color.getColor("Range[-1.0,-1.0]", 0);
    int var10 = var9.getBlue();
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var12 = var11.getPadding();
    double var13 = var11.getWidth();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, (-1.0d));
    org.jfree.data.Range var21 = null;
    org.jfree.data.Range var23 = org.jfree.data.Range.expandToInclude(var21, (-1.0d));
    org.jfree.data.Range var24 = org.jfree.data.Range.combine(var20, var23);
    double var25 = var23.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var26 = var17.toRangeHeight(var23);
    org.jfree.chart.util.Size2D var27 = var11.arrange(var14, var26);
    org.jfree.chart.block.RectangleConstraint var28 = var26.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var30 = var26.toFixedWidth(100.0d);
    org.jfree.chart.block.RectangleConstraint var32 = var30.toFixedWidth(100.0d);
    boolean var33 = var9.equals((java.lang.Object)100.0d);
    var0.setBaseItemLabelPaint((java.awt.Paint)var9);
    int var35 = var9.getAlpha();
    org.jfree.chart.block.LabelBlock var39 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var40 = var39.getFont();
    java.awt.Color var44 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var40, (java.awt.Paint)var44);
    java.awt.Color var46 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var44);
    java.awt.Color var49 = java.awt.Color.getColor("", (-1));
    java.awt.image.ColorModel var50 = null;
    java.awt.Rectangle var51 = null;
    org.jfree.chart.LegendItemSource var52 = null;
    org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle(var52);
    org.jfree.chart.util.RectangleInsets var54 = var53.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var55 = null;
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle(var55);
    org.jfree.chart.util.RectangleInsets var57 = var56.getItemLabelPadding();
    double var58 = var57.getTop();
    var53.setPadding(var57);
    org.jfree.chart.util.Size2D var60 = new org.jfree.chart.util.Size2D();
    boolean var62 = var60.equals((java.lang.Object)(-1L));
    double var63 = var60.getWidth();
    double var64 = var60.getHeight();
    org.jfree.chart.util.RectangleAnchor var67 = null;
    java.awt.geom.Rectangle2D var68 = org.jfree.chart.util.RectangleAnchor.createRectangle(var60, 2.0d, (-1.0d), var67);
    org.jfree.chart.axis.CategoryLabelPositions var71 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var72 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var73 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var71, var72);
    org.jfree.chart.util.RectangleAnchor var74 = var72.getCategoryAnchor();
    java.awt.geom.Rectangle2D var75 = org.jfree.chart.util.RectangleAnchor.createRectangle(var60, 2.0d, 1.0d, var74);
    java.awt.geom.Rectangle2D var76 = var57.createOutsetRectangle(var75);
    java.awt.geom.AffineTransform var77 = null;
    java.awt.RenderingHints var78 = null;
    java.awt.PaintContext var79 = var49.createContext(var50, var51, var76, var77, var78);
    java.awt.color.ColorSpace var80 = var49.getColorSpace();
    java.awt.Color var86 = java.awt.Color.getColor("", (-1));
    float[] var87 = null;
    float[] var88 = var86.getRGBComponents(var87);
    float[] var89 = java.awt.Color.RGBtoHSB(0, (-123), 100, var88);
    float[] var90 = var49.getColorComponents(var88);
    float[] var91 = var46.getRGBColorComponents(var88);
    float[] var92 = var9.getRGBComponents(var88);
    int var93 = var9.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 255);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine();
//     org.jfree.chart.text.TextFragment var5 = var4.getFirstTextFragment();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     boolean var7 = var6.isNegativeArrowVisible();
//     java.lang.String var8 = var6.getLabelURL();
//     java.awt.Paint var9 = var6.getTickMarkPaint();
//     org.jfree.chart.event.AxisChangeEvent var10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var6);
//     boolean var11 = var4.equals((java.lang.Object)var6);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var16 = var15.getPadding();
//     double var17 = var15.getWidth();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
//     org.jfree.chart.text.TextAnchor var25 = var23.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var27 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var28 = null;
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
//     org.jfree.chart.util.RectangleEdge var30 = var29.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var31 = org.jfree.chart.util.RectangleEdge.opposite(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.chart.labels.ItemLabelAnchor var33 = var27.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var34 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var35 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var36 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var34, var35);
//     org.jfree.chart.text.TextAnchor var37 = var35.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var38 = new org.jfree.chart.labels.ItemLabelPosition(var33, var37);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var19, 100.0f, 0.0f, var25, 100.0d, var37);
//     org.jfree.chart.LegendItemSource var40 = null;
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
//     org.jfree.chart.util.RectangleEdge var42 = var41.getLegendItemGraphicEdge();
//     java.awt.Paint var43 = var41.getItemPaint();
//     var41.setNotify(true);
//     java.awt.geom.Rectangle2D var46 = var41.getBounds();
//     boolean var47 = var37.equals((java.lang.Object)var46);
//     boolean var48 = var15.equals((java.lang.Object)var37);
//     var4.draw(var12, (-1.0f), 0.0f, var37, 1.0f, 1.0f, 0.0d);
//     float var53 = var2.calculateBaselineOffset(var3, var37);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var1 = null;
//     var0.setPlot(var1);
//     var0.setLowerBound(2.0d);
//     java.lang.String var5 = var0.getLabelToolTip();
//     boolean var6 = var0.isNegativeArrowVisible();
//     org.jfree.data.Range var7 = var0.getDefaultAutoRange();
//     var0.setAutoTickUnitSelection(true, false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var14 = var12.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var18 = var12.getLegendItemToolTipGenerator();
//     var12.setItemLabelAnchorOffset(100.0d);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var26, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var31 = null;
//     var29.setSeriesItemLabelsVisible(0, var31, false);
//     java.awt.Stroke var34 = var29.getErrorIndicatorStroke();
//     java.awt.Paint var35 = null;
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var26, var34, var35);
//     boolean var37 = var36.isLineVisible();
//     org.jfree.chart.util.StandardGradientPaintTransformer var38 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.lang.Object var39 = var38.clone();
//     java.lang.Object var40 = var38.clone();
//     var36.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var38);
//     var12.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var38);
//     java.lang.Boolean var44 = var12.getSeriesVisibleInLegend((-855310));
//     org.jfree.chart.labels.ItemLabelPosition var47 = var12.getNegativeItemLabelPosition((-16777212), (-16777212));
//     org.jfree.chart.ChartRenderingInfo var49 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var50 = new org.jfree.chart.plot.PlotRenderingInfo(var49);
//     java.awt.geom.Rectangle2D var51 = var50.getDataArea();
//     var12.setSeriesShape(0, (java.awt.Shape)var51, true);
//     org.jfree.chart.labels.ItemLabelPosition var54 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var55 = null;
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle(var55);
//     org.jfree.chart.util.RectangleEdge var57 = var56.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var58 = org.jfree.chart.util.RectangleEdge.opposite(var57);
//     boolean var59 = var54.equals((java.lang.Object)var58);
//     double var60 = var0.java2DToValue(0.2d, var51, var58);
//     
//     // Checks the contract:  equals-hashcode on var17 and var54
//     assertTrue("Contract failed: equals-hashcode on var17 and var54", var17.equals(var54) ? var17.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var17
//     assertTrue("Contract failed: equals-hashcode on var54 and var17", var54.equals(var17) ? var54.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var20.setRangeAxes(var24);
    var6.setParent((org.jfree.chart.plot.Plot)var20);
    java.awt.Stroke var27 = var20.getRangeCrosshairStroke();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.LegendItemSource var29 = null;
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
    org.jfree.chart.util.RectangleInsets var31 = var30.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var32 = null;
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
    org.jfree.chart.util.RectangleInsets var34 = var33.getItemLabelPadding();
    double var35 = var34.getTop();
    var30.setPadding(var34);
    org.jfree.chart.util.Size2D var37 = new org.jfree.chart.util.Size2D();
    boolean var39 = var37.equals((java.lang.Object)(-1L));
    double var40 = var37.getWidth();
    double var41 = var37.getHeight();
    org.jfree.chart.util.RectangleAnchor var44 = null;
    java.awt.geom.Rectangle2D var45 = org.jfree.chart.util.RectangleAnchor.createRectangle(var37, 2.0d, (-1.0d), var44);
    org.jfree.chart.axis.CategoryLabelPositions var48 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var49 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var50 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var48, var49);
    org.jfree.chart.util.RectangleAnchor var51 = var49.getCategoryAnchor();
    java.awt.geom.Rectangle2D var52 = org.jfree.chart.util.RectangleAnchor.createRectangle(var37, 2.0d, 1.0d, var51);
    java.awt.geom.Rectangle2D var53 = var34.createOutsetRectangle(var52);
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    boolean var56 = var20.render(var28, var53, 255, var55);
    org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis("CategoryLabelEntity: category=null, tooltip=hi!, url=");
    double var60 = var59.getCategoryMargin();
    var20.setDomainAxis(4, var59, true);
    int var63 = var59.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 4);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Set var1 = var0.keySet();
    java.util.Set var2 = var0.keySet();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var4 = var0.getStringArray("TextAnchor.CENTER");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     var15.fireChartChanged();
//     org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
//     org.jfree.chart.plot.Plot var18 = var15.getPlot();
//     org.jfree.chart.LegendItemSource var19 = null;
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var22 = var20.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var23 = var20.getItemContainer();
//     var15.removeSubtitle((org.jfree.chart.title.Title)var20);
//     var20.setMargin(1.0E-8d, 0.0d, 246.39999999999995d, (-0.55d));
//     org.jfree.chart.util.RectangleInsets var30 = var20.getMargin();
//     org.jfree.chart.LegendItemSource var31 = null;
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
//     org.jfree.chart.util.RectangleEdge var33 = var32.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var35 = var34.getNextOutlinePaint();
//     var32.setBackgroundPaint(var35);
//     org.jfree.chart.util.HorizontalAlignment var37 = var32.getHorizontalAlignment();
//     double var38 = var32.getContentYOffset();
//     org.jfree.chart.text.TextBlock var39 = new org.jfree.chart.text.TextBlock();
//     java.util.List var40 = var39.getLines();
//     org.jfree.chart.text.TextLine var41 = null;
//     var39.addLine(var41);
//     org.jfree.chart.util.HorizontalAlignment var43 = var39.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var44 = null;
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 1.0d, 100.0d);
//     var32.setHorizontalAlignment(var43);
//     org.jfree.chart.util.HorizontalAlignment var49 = null;
//     org.jfree.chart.LegendItemSource var50 = null;
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle(var50);
//     org.jfree.chart.util.RectangleInsets var52 = var51.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var53 = var51.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement(var49, var53, 0.0d, 2.0d);
//     org.jfree.chart.block.ColumnArrangement var59 = new org.jfree.chart.block.ColumnArrangement(var43, var53, 1.0d, 1.0E-8d);
//     var20.setVerticalAlignment(var53);
//     
//     // Checks the contract:  equals-hashcode on var11 and var34
//     assertTrue("Contract failed: equals-hashcode on var11 and var34", var11.equals(var34) ? var11.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var11
//     assertTrue("Contract failed: equals-hashcode on var34 and var11", var34.equals(var11) ? var34.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    var19.clearDomainMarkers();
    int var22 = var19.getBackgroundImageAlignment();
    var19.mapDatasetToDomainAxis(242, 0);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    boolean var27 = var26.isNegativeArrowVisible();
    org.jfree.chart.util.RectangleInsets var28 = var26.getTickLabelInsets();
    var19.setInsets(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    java.awt.Paint var12 = var6.getDomainGridlinePaint();
    float var13 = var6.getForegroundAlpha();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.TOP_OR_RIGHT");
    org.jfree.chart.axis.CategoryAxis[] var16 = new org.jfree.chart.axis.CategoryAxis[] { var15};
    var6.setDomainAxes(var16);
    var6.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    java.util.List var19 = var15.getSubtitles();
    org.jfree.chart.util.RectangleInsets var20 = var15.getPadding();
    org.jfree.chart.plot.CategoryPlot var21 = var15.getCategoryPlot();
    org.jfree.chart.plot.PlotOrientation var22 = var21.getOrientation();
    java.lang.String var23 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var23.equals("PlotOrientation.VERTICAL"));

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextBlockAnchor.BOTTOM_CENTER", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    boolean var7 = var6.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var9 = var6.getDataset((-123));
    var6.clearRangeMarkers(0);
    java.awt.Paint var12 = var6.getBackgroundPaint();
    var6.setAnchorValue((-1.0d));
    org.jfree.chart.util.RectangleEdge var16 = var6.getRangeAxisEdge((-855310));
    boolean var17 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleEdge var3 = var2.getLegendItemGraphicEdge();
    boolean var4 = var0.equals((java.lang.Object)var2);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    boolean var12 = var11.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var14 = var11.getDataset((-123));
    var11.clearRangeMarkers(0);
    java.awt.Paint var17 = var11.getBackgroundPaint();
    var11.setAnchorValue((-1.0d));
    org.jfree.chart.util.RectangleEdge var21 = var11.getRangeAxisEdge((-855310));
    boolean var22 = var0.equals((java.lang.Object)var11);
    var11.clearRangeAxes();
    org.jfree.chart.axis.CategoryAxis var24 = null;
    java.util.List var25 = var11.getCategoriesForAxis(var24);
    org.jfree.chart.util.RectangleEdge var27 = var11.getDomainAxisEdge(15);
    org.jfree.chart.axis.CategoryAnchor var28 = var11.getDomainGridlinePosition();
    org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var30 = var29.clone();
    org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
    var29.ensureAtLeast(var31);
    double var33 = var31.getTop();
    org.jfree.data.category.CategoryDataset var34 = null;
    org.jfree.chart.axis.CategoryAxis var35 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var37 = null;
    var36.setPlot(var37);
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var34, var35, (org.jfree.chart.axis.ValueAxis)var36, var39);
    var40.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var46 = null;
    var44.setSeriesItemLabelsVisible(0, var46, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var50 = null;
    var44.setSeriesToolTipGenerator(1, var50, false);
    org.jfree.chart.urls.CategoryURLGenerator var53 = null;
    var44.setBaseURLGenerator(var53);
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = null;
    org.jfree.chart.axis.ValueAxis var57 = null;
    org.jfree.chart.plot.Marker var58 = null;
    java.awt.geom.Rectangle2D var59 = null;
    var44.drawRangeMarker(var55, var56, var57, var58, var59);
    boolean var62 = var44.isSeriesVisibleInLegend(0);
    var40.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var44);
    org.jfree.chart.axis.CategoryAxis var64 = null;
    java.util.List var65 = var40.getCategoriesForAxis(var64);
    java.awt.Font var66 = var40.getNoDataMessageFont();
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
    boolean var68 = var31.equals((java.lang.Object)var40);
    org.jfree.chart.axis.AxisLocation var70 = var40.getRangeAxisLocation(0);
    var11.setRangeAxisLocation(var70, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     var3.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.java2DToValue(0.0d, var11, var12);
//     var3.setAutoTickUnitSelection(true);
//     var3.setUpperMargin(0.0d);
//     org.jfree.chart.LegendItemSource var18 = null;
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var21 = var19.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var22 = var19.getItemContainer();
//     org.jfree.chart.LegendItemSource var23 = null;
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var24.getItemLabelPadding();
//     double var27 = var25.calculateTopOutset(4.0d);
//     var22.setMargin(var25);
//     java.awt.geom.Rectangle2D var29 = var22.getBounds();
//     org.jfree.chart.LegendItemSource var30 = null;
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var33 = var31.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var34 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var33);
//     var3.setDownArrow((java.awt.Shape)var29);
//     org.jfree.data.Range var39 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.Range var40 = null;
//     org.jfree.data.Range var42 = org.jfree.data.Range.expandToInclude(var40, (-1.0d));
//     org.jfree.data.Range var43 = null;
//     org.jfree.data.Range var45 = org.jfree.data.Range.expandToInclude(var43, (-1.0d));
//     org.jfree.data.Range var46 = org.jfree.data.Range.combine(var42, var45);
//     java.lang.String var47 = var45.toString();
//     double var48 = var45.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(var39, var45);
//     org.jfree.data.Range var52 = org.jfree.data.Range.shift(var45, 4.0d, true);
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(0.0d, var52);
//     org.jfree.data.Range var55 = org.jfree.data.Range.expandToInclude(var52, (-1.0d));
//     var3.setRangeWithMargins(var55, false, false);
//     org.jfree.data.Range var61 = org.jfree.data.Range.shift(var55, 0.0d, false);
//     org.jfree.chart.block.RectangleConstraint var62 = new org.jfree.chart.block.RectangleConstraint(3.0d, var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "Range[-1.0,-1.0]"+ "'", var47.equals("Range[-1.0,-1.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test132"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var11 = java.awt.Color.getColor("", (-1));
    var0.setBasePaint((java.awt.Paint)var11, true);
    java.awt.Font var15 = var0.getSeriesItemLabelFont(100);
    org.jfree.chart.annotations.CategoryAnnotation var16 = null;
    boolean var17 = var0.removeAnnotation(var16);
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var0.setBaseURLGenerator(var18, true);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var23 = var22.getPaint();
    var0.setSeriesPaint(1, var23, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test133"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    boolean var5 = var0.equals((java.lang.Object)var4);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var8, var11);
    var12.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = null;
    var16.setSeriesItemLabelsVisible(0, var18, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var16.setSeriesToolTipGenerator(1, var22, false);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var16.setBaseURLGenerator(var25);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.plot.Marker var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    var16.drawRangeMarker(var27, var28, var29, var30, var31);
    boolean var34 = var16.isSeriesVisibleInLegend(0);
    var12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    boolean var36 = var0.equals((java.lang.Object)var16);
    boolean var37 = var16.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.block.BorderArrangement var38 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
    var39.setMaximumCategoryLabelWidthRatio(0.95f);
    var39.setCategoryMargin(0.05d);
    boolean var44 = var38.equals((java.lang.Object)0.05d);
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var46 = var45.getPadding();
    boolean var47 = var45.isEmpty();
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var52 = null;
    org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, (-1.0d));
    org.jfree.data.Range var55 = null;
    org.jfree.data.Range var57 = org.jfree.data.Range.expandToInclude(var55, (-1.0d));
    org.jfree.data.Range var58 = org.jfree.data.Range.combine(var54, var57);
    double var59 = var57.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var60 = var51.toRangeHeight(var57);
    org.jfree.chart.util.Size2D var61 = var38.arrange(var45, var48, var51);
    org.jfree.chart.util.HorizontalAlignment var62 = null;
    org.jfree.chart.util.VerticalAlignment var63 = null;
    org.jfree.chart.block.FlowArrangement var66 = new org.jfree.chart.block.FlowArrangement(var62, var63, 0.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var67 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var66);
    var66.clear();
    org.jfree.chart.util.StandardGradientPaintTransformer var69 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var70 = var69.clone();
    org.jfree.chart.event.ChartChangeEvent var71 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var69);
    boolean var72 = var66.equals((java.lang.Object)var69);
    org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, (org.jfree.chart.block.Arrangement)var38, (org.jfree.chart.block.Arrangement)var66);
    org.jfree.chart.plot.DefaultDrawingSupplier var74 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var75 = var74.getNextOutlinePaint();
    boolean var76 = var38.equals((java.lang.Object)var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test134"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    boolean var3 = var0.equals((java.lang.Object)var2);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var10 = null;
    var9.setPlot(var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var8, (org.jfree.chart.axis.ValueAxis)var9, var12);
    var13.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var23 = null;
    var17.setSeriesToolTipGenerator(1, var23, false);
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    var17.setBaseURLGenerator(var26);
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var17.drawRangeMarker(var28, var29, var30, var31, var32);
    boolean var35 = var17.isSeriesVisibleInLegend(0);
    var13.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
    org.jfree.chart.axis.CategoryAxis var37 = null;
    java.util.List var38 = var13.getCategoriesForAxis(var37);
    java.awt.Paint var39 = var13.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var40 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = var13.getRendererForDataset((org.jfree.data.category.CategoryDataset)var40);
    org.jfree.data.general.PieDataset var43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var40, (java.lang.Comparable)(-1L));
    org.jfree.data.category.CategoryDataset var44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)' ', (org.jfree.data.KeyedValues)var43);
    org.jfree.chart.entity.CategoryItemEntity var47 = new org.jfree.chart.entity.CategoryItemEntity(var2, "Size2D[width=0.0, height=-1.0]", "java.awt.Color[r=255,g=255,b=255]", var44, (java.lang.Comparable)(-0.55d), (java.lang.Comparable)(-8.0d));
    java.lang.String var48 = var47.toString();
    org.jfree.data.category.CategoryDataset var49 = var47.getDataset();
    java.lang.String var50 = var47.toString();
    java.lang.Comparable var51 = var47.getColumnKey();
    java.lang.Comparable var52 = var47.getColumnKey();
    java.lang.Object var53 = var47.clone();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var55 = null;
    var54.setPlot(var55);
    org.jfree.chart.block.BlockContainer var57 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var58 = var57.getPadding();
    double var60 = var58.calculateTopInset(100.0d);
    double var62 = var58.calculateTopInset(2.0d);
    var54.setLabelInsets(var58);
    var54.setFixedAutoRange(10.0d);
    boolean var66 = var47.equals((java.lang.Object)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + (-8.0d)+ "'", var51.equals((-8.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + (-8.0d)+ "'", var52.equals((-8.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test135"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    boolean var2 = var0.equals((java.lang.Object)(-1L));
    double var3 = var0.getWidth();
    double var4 = var0.getHeight();
    org.jfree.chart.util.RectangleAnchor var7 = null;
    java.awt.geom.Rectangle2D var8 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, (-1.0d), var7);
    org.jfree.chart.axis.CategoryLabelPositions var11 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var12 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var11, var12);
    org.jfree.chart.util.RectangleAnchor var14 = var12.getCategoryAnchor();
    java.awt.geom.Rectangle2D var15 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, 1.0d, var14);
    org.jfree.chart.text.TextBlock var17 = new org.jfree.chart.text.TextBlock();
    java.util.List var18 = var17.getLines();
    org.jfree.chart.text.TextLine var19 = null;
    var17.addLine(var19);
    org.jfree.chart.util.HorizontalAlignment var21 = var17.getLineAlignment();
    org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
    float var25 = var23.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var26 = var23.getLabelAnchor();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.CategoryLabelPositions var31 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var31, var32);
    org.jfree.chart.text.TextAnchor var34 = var32.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var36 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.LegendItemSource var37 = null;
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
    org.jfree.chart.util.RectangleEdge var39 = var38.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var40 = org.jfree.chart.util.RectangleEdge.opposite(var39);
    boolean var41 = var36.equals((java.lang.Object)var40);
    org.jfree.chart.labels.ItemLabelAnchor var42 = var36.getItemLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var43 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var43, var44);
    org.jfree.chart.text.TextAnchor var46 = var44.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var47 = new org.jfree.chart.labels.ItemLabelPosition(var42, var46);
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var28, 100.0f, 0.0f, var34, 100.0d, var46);
    org.jfree.chart.axis.CategoryTick var50 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1.0f), var17, var26, var46, 10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var51 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var52 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var53 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var51, var52);
    float var54 = var52.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var55 = var52.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var56 = var52.getWidthType();
    org.jfree.chart.axis.CategoryLabelPosition var58 = new org.jfree.chart.axis.CategoryLabelPosition(var14, var26, var56, (-1.0f));
    java.lang.String var59 = var56.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "CategoryLabelWidthType.CATEGORY"+ "'", var59.equals("CategoryLabelWidthType.CATEGORY"));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test136"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setMaximumCategoryLabelWidthRatio(0.95f);
    java.awt.Color var5 = java.awt.Color.getColor("AxisLocation.TOP_OR_RIGHT", (-1));
    var0.setAxisLinePaint((java.awt.Paint)var5);
    org.jfree.chart.block.BlockContainer var7 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var8 = var7.getPadding();
    double var9 = var7.getWidth();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, (-1.0d));
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, (-1.0d));
    org.jfree.data.Range var20 = org.jfree.data.Range.combine(var16, var19);
    double var21 = var19.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var22 = var13.toRangeHeight(var19);
    org.jfree.chart.util.Size2D var23 = var7.arrange(var10, var22);
    org.jfree.chart.block.RectangleConstraint var24 = var22.toUnconstrainedWidth();
    boolean var25 = var5.equals((java.lang.Object)var22);
    int var26 = var5.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test137"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var2.setAutoRangeMinimumSize(2.0d);
    var2.setLabel("CategoryLabelWidthType.CATEGORY");
    org.jfree.chart.axis.TickUnitSource var11 = null;
    var2.setStandardTickUnits(var11);
    var2.setAxisLineVisible(true);
    java.lang.Object var15 = var2.clone();
    boolean var16 = var2.getAutoRangeIncludesZero();
    java.awt.Font var17 = var2.getLabelFont();
    org.jfree.chart.LegendItemSource var19 = null;
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    java.awt.Paint var22 = var20.getItemPaint();
    var20.setNotify(true);
    org.jfree.chart.axis.AxisSpace var25 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.LegendItemSource var27 = null;
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle(var27);
    org.jfree.chart.util.RectangleEdge var29 = var28.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var30 = org.jfree.chart.util.RectangleEdge.opposite(var29);
    var25.ensureAtLeast(100.0d, var30);
    var20.setPosition(var30);
    java.lang.Object var33 = var20.clone();
    org.jfree.chart.ChartRenderingInfo var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
    java.lang.Object var36 = var35.clone();
    java.awt.geom.Rectangle2D var37 = var35.getDataArea();
    var20.setBounds(var37);
    org.jfree.chart.axis.AxisState var39 = new org.jfree.chart.axis.AxisState();
    double var40 = var39.getMax();
    var39.cursorLeft(Double.NaN);
    org.jfree.chart.axis.AxisState var44 = new org.jfree.chart.axis.AxisState();
    org.jfree.chart.LegendItemSource var46 = null;
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var46);
    org.jfree.chart.util.RectangleEdge var48 = var47.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var49 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var50 = var49.getNextOutlinePaint();
    var47.setBackgroundPaint(var50);
    org.jfree.chart.block.BlockContainer var52 = var47.getItemContainer();
    org.jfree.chart.event.TitleChangeEvent var53 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var47);
    org.jfree.chart.util.RectangleEdge var54 = var47.getLegendItemGraphicEdge();
    var44.moveCursor(0.0d, var54);
    var39.moveCursor(1.0d, var54);
    double var57 = var2.valueToJava2D(2.0d, var37, var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test138"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    var0.setBaseItemLabelGenerator(var3);
    org.jfree.chart.plot.DefaultDrawingSupplier var5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var6 = var5.getNextOutlinePaint();
    var0.setErrorIndicatorPaint(var6);
    java.awt.Font var8 = var0.getBaseItemLabelFont();
    double var9 = var0.getLowerClip();
    org.jfree.chart.util.GradientPaintTransformer var10 = var0.getGradientPaintTransformer();
    java.lang.Boolean var12 = null;
    var0.setSeriesCreateEntities(100, var12, false);
    boolean var17 = var0.getItemCreateEntity(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test139"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleEdge.LEFT");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
    java.util.List var5 = var4.getLines();
    org.jfree.chart.text.TextLine var6 = null;
    var4.addLine(var6);
    org.jfree.chart.util.HorizontalAlignment var8 = var4.getLineAlignment();
    org.jfree.chart.text.TextBlockAnchor var9 = null;
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.labels.ItemLabelPosition var14 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleEdge var17 = var16.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var18 = org.jfree.chart.util.RectangleEdge.opposite(var17);
    boolean var19 = var14.equals((java.lang.Object)var18);
    org.jfree.chart.labels.ItemLabelAnchor var20 = var14.getItemLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var21 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var22 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var23 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var21, var22);
    org.jfree.chart.text.TextAnchor var24 = var22.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var25 = new org.jfree.chart.labels.ItemLabelPosition(var20, var24);
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var11, 1.0f, (-1.0f), var24, 2.0d, 1.0f, 0.0f);
    org.jfree.chart.axis.CategoryTick var31 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var4, var9, var24, 0.0d);
    org.jfree.chart.LegendItemSource var32 = null;
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
    org.jfree.chart.util.RectangleEdge var34 = var33.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var36 = var35.getNextOutlinePaint();
    var33.setBackgroundPaint(var36);
    org.jfree.chart.util.HorizontalAlignment var38 = var33.getHorizontalAlignment();
    var4.setLineAlignment(var38);
    java.lang.Object var40 = null;
    boolean var41 = var38.equals(var40);
    var1.setTextAlignment(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test140"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var25 = var24.getFont();
    java.awt.Color var29 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var25, (java.awt.Paint)var29);
    java.awt.Color var31 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var29);
    var19.setDomainGridlinePaint((java.awt.Paint)var29);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.NumberTickUnit var39 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
    var34.add((java.lang.Number)(-1.0d), (java.lang.Number)(-855310), (java.lang.Comparable)0.05d, (java.lang.Comparable)1.0E-8d);
    var19.setDataset(100, (org.jfree.data.category.CategoryDataset)var34);
    org.jfree.chart.ui.BasicProjectInfo var46 = new org.jfree.chart.ui.BasicProjectInfo("0,100,100,-100,-100,-100,-100,-100", "", "poly", "NOID");
    boolean var47 = var34.equals((java.lang.Object)"NOID");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test141"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.setNegativeArrowVisible(false);
    org.jfree.data.Range var10 = var2.getRange();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var13 = var11.equals((java.lang.Object)(short)10);
    java.awt.Paint var14 = var11.getNextFillPaint();
    java.awt.Paint var15 = var11.getNextPaint();
    java.awt.Shape var16 = var11.getNextShape();
    org.jfree.chart.entity.AxisLabelEntity var19 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, var16, "CategoryLabelEntity: category=null, tooltip=hi!, url=", "SortOrder.ASCENDING");
    java.lang.String var20 = var19.getShapeType();
    org.jfree.chart.axis.Axis var21 = var19.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "rect"+ "'", var20.equals("rect"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test142"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var11 = var10.getNextOutlinePaint();
//     var8.setBackgroundPaint(var11);
//     var6.setOutlinePaint(var11);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.lang.Object var18 = var17.clone();
//     var6.handleClick(4, (-123), var17);
//     org.jfree.chart.axis.AxisSpace var20 = var6.getFixedRangeAxisSpace();
//     float var21 = var6.getBackgroundImageAlpha();
//     org.jfree.chart.LegendItemSource var22 = null;
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var22);
//     org.jfree.chart.util.RectangleEdge var24 = var23.getLegendItemGraphicEdge();
//     java.awt.Paint var25 = var23.getItemPaint();
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var30 = null;
//     var29.setPlot(var30);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var29, var32);
//     org.jfree.chart.LegendItemSource var34 = null;
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var34);
//     org.jfree.chart.util.RectangleEdge var36 = var35.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var38 = var37.getNextOutlinePaint();
//     var35.setBackgroundPaint(var38);
//     var33.setOutlinePaint(var38);
//     org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var33);
//     var41.fireChartChanged();
//     boolean var43 = var41.getAntiAlias();
//     java.util.List var44 = var41.getSubtitles();
//     var23.addChangeListener((org.jfree.chart.event.TitleChangeListener)var41);
//     org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     boolean var48 = var46.equals((java.lang.Object)(short)10);
//     java.awt.Paint var49 = var46.getNextFillPaint();
//     java.awt.Paint var50 = var46.getNextPaint();
//     java.awt.Stroke var51 = var46.getNextStroke();
//     java.awt.Paint var52 = var46.getNextFillPaint();
//     var41.setBackgroundPaint(var52);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var57 = null;
//     var56.setPlot(var57);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var54, var55, (org.jfree.chart.axis.ValueAxis)var56, var59);
//     var60.setAnchorValue(0.0d, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var64 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var66 = null;
//     var64.setSeriesItemLabelsVisible(0, var66, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var70 = null;
//     var64.setSeriesToolTipGenerator(1, var70, false);
//     org.jfree.chart.urls.CategoryURLGenerator var73 = null;
//     var64.setBaseURLGenerator(var73);
//     java.awt.Graphics2D var75 = null;
//     org.jfree.chart.plot.CategoryPlot var76 = null;
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.plot.Marker var78 = null;
//     java.awt.geom.Rectangle2D var79 = null;
//     var64.drawRangeMarker(var75, var76, var77, var78, var79);
//     boolean var82 = var64.isSeriesVisibleInLegend(0);
//     var60.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var64);
//     org.jfree.chart.axis.CategoryAxis var84 = null;
//     java.util.List var85 = var60.getCategoriesForAxis(var84);
//     java.awt.Image var86 = var60.getBackgroundImage();
//     org.jfree.chart.event.PlotChangeEvent var87 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var60);
//     var41.plotChanged(var87);
//     var41.setBackgroundImageAlignment((-855310));
//     var6.addChangeListener((org.jfree.chart.event.PlotChangeListener)var41);
//     
//     // Checks the contract:  equals-hashcode on var6 and var33
//     assertTrue("Contract failed: equals-hashcode on var6 and var33", var6.equals(var33) ? var6.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var6
//     assertTrue("Contract failed: equals-hashcode on var33 and var6", var33.equals(var6) ? var33.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test143"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
//     var0.setSeriesToolTipGenerator(1, var6, false);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = null;
//     var0.setBaseURLGenerator(var9);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.Marker var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var0.drawRangeMarker(var11, var12, var13, var14, var15);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var0.setBaseURLGenerator(var17, true);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = var0.getLegendItemURLGenerator();
//     boolean var22 = var0.isSeriesItemLabelsVisible((-16777116));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var26 = var24.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var24.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var24.getLegendItemToolTipGenerator();
//     boolean var31 = var24.getAutoPopulateSeriesFillPaint();
//     boolean var32 = var24.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var33 = var24.getBaseNegativeItemLabelPosition();
//     var0.setSeriesPositiveItemLabelPosition(1, var33, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var0.", var24.equals(var0) == var0.equals(var24));
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test144"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    java.awt.Image var30 = var6.getBackgroundImage();
    java.awt.Stroke var31 = var6.getDomainGridlineStroke();
    var6.clearRangeMarkers(100);
    org.jfree.data.category.CategoryDataset var35 = null;
    org.jfree.chart.axis.CategoryAxis var36 = null;
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var38 = null;
    var37.setPlot(var38);
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var35, var36, (org.jfree.chart.axis.ValueAxis)var37, var40);
    org.jfree.chart.LegendItemSource var42 = null;
    org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle(var42);
    org.jfree.chart.util.RectangleEdge var44 = var43.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var46 = var45.getNextOutlinePaint();
    var43.setBackgroundPaint(var46);
    var41.setOutlinePaint(var46);
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var41);
    var49.fireChartChanged();
    var49.setNotify(false);
    java.awt.Paint var53 = var49.getBackgroundPaint();
    var6.setOutlinePaint(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test145"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
    org.jfree.chart.text.TextAnchor var3 = var1.getRotationAnchor();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var6 = null;
    var4.setSeriesItemLabelsVisible(0, var6, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var4.setSeriesToolTipGenerator(1, var10, false);
    org.jfree.chart.urls.CategoryURLGenerator var13 = null;
    var4.setBaseURLGenerator(var13);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.Marker var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var4.drawRangeMarker(var15, var16, var17, var18, var19);
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    var4.setBaseURLGenerator(var21, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var26 = null;
    var24.setSeriesItemLabelsVisible(0, var26, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var30 = null;
    var24.setSeriesToolTipGenerator(1, var30, false);
    org.jfree.chart.urls.CategoryURLGenerator var33 = null;
    var24.setBaseURLGenerator(var33);
    var24.setBaseCreateEntities(false, false);
    var24.setBaseSeriesVisibleInLegend(false);
    var24.setBaseItemLabelsVisible(true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var43 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var45 = var43.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var48 = var43.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var49 = var43.getBaseURLGenerator();
    java.lang.Boolean var51 = var43.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var52 = null;
    org.jfree.chart.axis.CategoryAxis var53 = null;
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var55 = null;
    var54.setPlot(var55);
    org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var52, var53, (org.jfree.chart.axis.ValueAxis)var54, var57);
    java.awt.Stroke var59 = var54.getTickMarkStroke();
    var43.setBaseOutlineStroke(var59);
    org.jfree.chart.labels.ItemLabelPosition var61 = var43.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var62 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var63 = var62.getEntityCollection();
    boolean var64 = var61.equals((java.lang.Object)var62);
    var24.setSeriesPositiveItemLabelPosition(0, var61);
    var4.setPositiveItemLabelPositionFallback(var61);
    boolean var69 = var4.getItemCreateEntity(255, (-123));
    java.awt.Paint var71 = var4.getSeriesItemLabelPaint(0);
    var4.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.urls.CategoryURLGenerator var74 = null;
    var4.setBaseURLGenerator(var74);
    boolean var76 = var1.equals((java.lang.Object)var4);
    java.awt.Paint var79 = var4.getItemLabelPaint((-5658199), (-124390));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test146"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    var1.setLegendItemGraphicLocation(var3);
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    org.jfree.chart.LegendItemSource var6 = null;
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var9 = var7.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var5, var9, 0.0d, 2.0d);
    org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var14 = var13.getPadding();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.util.Size2D var19 = var12.arrange(var13, var15, var18);
    var1.setWrapper(var13);
    org.jfree.chart.util.RectangleInsets var21 = var1.getItemLabelPadding();
    org.jfree.chart.util.RectangleEdge var22 = var1.getLegendItemGraphicEdge();
    boolean var23 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test147"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.plot.DefaultDrawingSupplier var2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.awt.Paint var5 = var2.getNextFillPaint();
    var0.setBaseItemLabelPaint(var5, false);
    boolean var8 = var0.getAutoPopulateSeriesStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test148"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    java.awt.Font var8 = var2.getLabelFont();
    float var9 = var2.getTickMarkInsideLength();
    var2.resizeRange(4.0d);
    boolean var12 = var2.isAutoTickUnitSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test149"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var4 = null;
    var2.setSeriesItemLabelsVisible(0, var4, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var2.setSeriesToolTipGenerator(1, var8, false);
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var2.setBaseURLGenerator(var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.Marker var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    var2.drawRangeMarker(var13, var14, var15, var16, var17);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var2.setBaseURLGenerator(var19, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var24 = null;
    var22.setSeriesItemLabelsVisible(0, var24, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
    var22.setSeriesToolTipGenerator(1, var28, false);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var22.setBaseURLGenerator(var31);
    var22.setBaseCreateEntities(false, false);
    var22.setBaseSeriesVisibleInLegend(false);
    var22.setBaseItemLabelsVisible(true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var43 = var41.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var46 = var41.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var47 = var41.getBaseURLGenerator();
    java.lang.Boolean var49 = var41.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var50 = null;
    org.jfree.chart.axis.CategoryAxis var51 = null;
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var53 = null;
    var52.setPlot(var53);
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var50, var51, (org.jfree.chart.axis.ValueAxis)var52, var55);
    java.awt.Stroke var57 = var52.getTickMarkStroke();
    var41.setBaseOutlineStroke(var57);
    org.jfree.chart.labels.ItemLabelPosition var59 = var41.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var60 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var61 = var60.getEntityCollection();
    boolean var62 = var59.equals((java.lang.Object)var60);
    var22.setSeriesPositiveItemLabelPosition(0, var59);
    var2.setPositiveItemLabelPositionFallback(var59);
    org.jfree.data.category.CategoryDataset var66 = null;
    org.jfree.chart.axis.CategoryAxis var67 = null;
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var69 = null;
    var68.setPlot(var69);
    org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var66, var67, (org.jfree.chart.axis.ValueAxis)var68, var71);
    org.jfree.chart.LegendItemSource var73 = null;
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
    org.jfree.chart.util.RectangleEdge var75 = var74.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var77 = var76.getNextOutlinePaint();
    var74.setBackgroundPaint(var77);
    var72.setOutlinePaint(var77);
    org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var72);
    var80.fireChartChanged();
    var80.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var84 = var80.getCategoryPlot();
    var84.clearRangeAxes();
    var84.clearDomainMarkers();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var87 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var88 = var87.getPositiveItemLabelPositionFallback();
    java.awt.Paint var91 = var87.getItemLabelPaint((-123), (-1));
    var84.setOutlinePaint(var91);
    var2.setBaseOutlinePaint(var91);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic(var1, var91);
    java.awt.Stroke var95 = null;
    var94.setOutlineStroke(var95);
    java.lang.Object var97 = var94.clone();
    org.jfree.chart.util.RectangleAnchor var98 = var94.getShapeAnchor();
    boolean var99 = var94.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == true);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test150"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
//     org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var3, var4);
//     org.jfree.chart.axis.CategoryLabelPositions var6 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var4);
//     boolean var8 = var6.equals((java.lang.Object)(-8.0d));
//     org.jfree.chart.axis.CategoryLabelPositions var9 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var9, var10);
//     org.jfree.chart.axis.CategoryLabelPositions var12 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var13 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var12, var13);
//     org.jfree.chart.axis.CategoryLabelPositions var15 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var16 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var17 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var15, var16);
//     org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var12, var16);
//     org.jfree.chart.axis.CategoryLabelPositions var19 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var11, var16);
//     org.jfree.chart.axis.CategoryLabelWidthType var20 = var16.getWidthType();
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Font var23 = var22.getFont();
//     boolean var24 = var16.equals((java.lang.Object)var23);
//     org.jfree.chart.axis.CategoryLabelPositions var25 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var6, var16);
//     org.jfree.chart.axis.CategoryLabelPositions var26 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var27 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var28 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var26, var27);
//     org.jfree.chart.axis.CategoryLabelPosition var29 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var30 = var29.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var28, var29);
//     org.jfree.chart.axis.CategoryLabelPositions var32 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var25, var29);
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.util.RectangleEdge var35 = var34.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleAnchor var36 = null;
//     var34.setLegendItemGraphicLocation(var36);
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.LegendItemSource var39 = null;
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle(var39);
//     org.jfree.chart.util.RectangleInsets var41 = var40.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var42 = var40.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var38, var42, 0.0d, 2.0d);
//     org.jfree.chart.block.BlockContainer var46 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var47 = var46.getPadding();
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.util.Size2D var52 = var45.arrange(var46, var48, var51);
//     var34.setWrapper(var46);
//     org.jfree.chart.util.RectangleAnchor var54 = var34.getLegendItemGraphicLocation();
//     org.jfree.chart.util.RectangleInsets var55 = var34.getMargin();
//     org.jfree.data.category.CategoryDataset var56 = null;
//     org.jfree.chart.axis.CategoryAxis var57 = null;
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var59 = null;
//     var58.setPlot(var59);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var56, var57, (org.jfree.chart.axis.ValueAxis)var58, var61);
//     var58.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var66 = null;
//     org.jfree.chart.util.RectangleEdge var67 = null;
//     double var68 = var58.java2DToValue(0.0d, var66, var67);
//     var58.setAutoTickUnitSelection(true);
//     var58.setUpperMargin(0.0d);
//     org.jfree.chart.LegendItemSource var73 = null;
//     org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
//     org.jfree.chart.util.RectangleInsets var75 = var74.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var76 = var74.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var77 = var74.getItemContainer();
//     org.jfree.chart.LegendItemSource var78 = null;
//     org.jfree.chart.title.LegendTitle var79 = new org.jfree.chart.title.LegendTitle(var78);
//     org.jfree.chart.util.RectangleInsets var80 = var79.getItemLabelPadding();
//     double var82 = var80.calculateTopOutset(4.0d);
//     var77.setMargin(var80);
//     java.awt.geom.Rectangle2D var84 = var77.getBounds();
//     org.jfree.chart.LegendItemSource var85 = null;
//     org.jfree.chart.title.LegendTitle var86 = new org.jfree.chart.title.LegendTitle(var85);
//     org.jfree.chart.util.RectangleInsets var87 = var86.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var88 = var86.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var89 = org.jfree.chart.util.RectangleAnchor.coordinates(var84, var88);
//     var58.setDownArrow((java.awt.Shape)var84);
//     org.jfree.chart.util.LengthAdjustmentType var91 = null;
//     org.jfree.chart.util.LengthAdjustmentType var92 = null;
//     java.awt.geom.Rectangle2D var93 = var55.createAdjustedRectangle(var84, var91, var92);
//     boolean var94 = var29.equals((java.lang.Object)var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == false);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test151"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.CategoryAnchor var1 = null;
    org.jfree.chart.LegendItemSource var4 = null;
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleInsets var9 = var8.getItemLabelPadding();
    double var10 = var9.getTop();
    var5.setPadding(var9);
    org.jfree.chart.util.Size2D var12 = new org.jfree.chart.util.Size2D();
    boolean var14 = var12.equals((java.lang.Object)(-1L));
    double var15 = var12.getWidth();
    double var16 = var12.getHeight();
    org.jfree.chart.util.RectangleAnchor var19 = null;
    java.awt.geom.Rectangle2D var20 = org.jfree.chart.util.RectangleAnchor.createRectangle(var12, 2.0d, (-1.0d), var19);
    org.jfree.chart.axis.CategoryLabelPositions var23 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var24 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var25 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var23, var24);
    org.jfree.chart.util.RectangleAnchor var26 = var24.getCategoryAnchor();
    java.awt.geom.Rectangle2D var27 = org.jfree.chart.util.RectangleAnchor.createRectangle(var12, 2.0d, 1.0d, var26);
    java.awt.geom.Rectangle2D var28 = var9.createOutsetRectangle(var27);
    org.jfree.chart.axis.AxisState var30 = new org.jfree.chart.axis.AxisState(2.0d);
    org.jfree.chart.LegendItemSource var32 = null;
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
    org.jfree.chart.util.RectangleEdge var34 = var33.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var36 = var35.getNextOutlinePaint();
    var33.setBackgroundPaint(var36);
    org.jfree.chart.text.TextBlock var38 = new org.jfree.chart.text.TextBlock();
    java.util.List var39 = var38.getLines();
    boolean var40 = var33.equals((java.lang.Object)var38);
    org.jfree.chart.util.RectangleEdge var41 = var33.getLegendItemGraphicEdge();
    var30.moveCursor(2.0d, var41);
    double var43 = var0.getCategoryJava2DCoordinate(var1, (-123), 0, var28, var41);
    int var44 = var0.getMaximumCategoryLabelLines();
    var0.setMaximumCategoryLabelWidthRatio(1.0f);
    var0.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test152"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    java.awt.Paint var12 = var6.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var16 = null;
    var15.setPlot(var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
    var19.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var25 = null;
    var23.setSeriesItemLabelsVisible(0, var25, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var29 = null;
    var23.setSeriesToolTipGenerator(1, var29, false);
    org.jfree.chart.urls.CategoryURLGenerator var32 = null;
    var23.setBaseURLGenerator(var32);
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.plot.Marker var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    var23.drawRangeMarker(var34, var35, var36, var37, var38);
    boolean var41 = var23.isSeriesVisibleInLegend(0);
    var19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.util.Layer var44 = null;
    java.util.Collection var45 = var19.getDomainMarkers(10, var44);
    org.jfree.chart.axis.AxisLocation var47 = var19.getDomainAxisLocation((-1));
    java.lang.String var48 = var47.toString();
    var6.setRangeAxisLocation(var47);
    java.awt.Paint var50 = var6.getRangeCrosshairPaint();
    org.jfree.chart.util.Layer var52 = null;
    java.util.Collection var53 = var6.getDomainMarkers(255, var52);
    java.awt.Color var57 = java.awt.Color.getHSBColor(0.0f, 1.0f, 2.0f);
    var6.setRangeGridlinePaint((java.awt.Paint)var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var48.equals("AxisLocation.TOP_OR_RIGHT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test153"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    java.awt.Paint var12 = var6.getDomainGridlinePaint();
    float var13 = var6.getForegroundAlpha();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.TOP_OR_RIGHT");
    org.jfree.chart.axis.CategoryAxis[] var16 = new org.jfree.chart.axis.CategoryAxis[] { var15};
    var6.setDomainAxes(var16);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var19 = null;
    var18.setPlot(var19);
    var18.setLowerBound(2.0d);
    java.lang.String var23 = var18.getLabelToolTip();
    boolean var24 = var18.isNegativeArrowVisible();
    org.jfree.data.Range var25 = var18.getDefaultAutoRange();
    var6.setRangeAxis((org.jfree.chart.axis.ValueAxis)var18);
    java.awt.Shape var27 = var18.getRightArrow();
    var18.setAutoTickUnitSelection(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test154"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    var0.setAutoPopulateSeriesStroke(false);
    var0.removeAnnotations();
    boolean var14 = var0.getBaseSeriesVisible();
    java.awt.Paint var15 = var0.getBasePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test155"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.title.LegendTitle var17 = var15.getLegend();
    org.jfree.chart.util.Size2D var18 = new org.jfree.chart.util.Size2D();
    boolean var20 = var18.equals((java.lang.Object)(-1L));
    double var21 = var18.getWidth();
    double var22 = var18.getHeight();
    org.jfree.chart.util.RectangleAnchor var25 = null;
    java.awt.geom.Rectangle2D var26 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, 2.0d, (-1.0d), var25);
    org.jfree.chart.axis.CategoryLabelPositions var29 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var30 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var29, var30);
    org.jfree.chart.util.RectangleAnchor var32 = var30.getCategoryAnchor();
    java.awt.geom.Rectangle2D var33 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, 2.0d, 1.0d, var32);
    var17.setLegendItemGraphicLocation(var32);
    org.jfree.chart.LegendItemSource[] var35 = var17.getSources();
    var17.setHeight(100.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test156"); }


    java.lang.Object var1 = null;
    org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject((java.lang.Comparable)' ', var1);
    java.lang.Object var3 = var2.getObject();
    java.lang.Comparable var4 = var2.getKey();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextOutlinePaint();
    var13.setBackgroundPaint(var16);
    var11.setOutlinePaint(var16);
    java.awt.Stroke var19 = var11.getRangeCrosshairStroke();
    boolean var20 = var2.equals((java.lang.Object)var19);
    java.lang.Comparable var21 = var2.getKey();
    java.lang.Object var22 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + ' '+ "'", var4.equals(' '));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + ' '+ "'", var21.equals(' '));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test157"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var25 = var24.getFont();
    java.awt.Color var29 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var25, (java.awt.Paint)var29);
    java.awt.Color var31 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var29);
    var19.setDomainGridlinePaint((java.awt.Paint)var29);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.NumberTickUnit var39 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
    var34.add((java.lang.Number)(-1.0d), (java.lang.Number)(-855310), (java.lang.Comparable)0.05d, (java.lang.Comparable)1.0E-8d);
    var19.setDataset(100, (org.jfree.data.category.CategoryDataset)var34);
    java.lang.Comparable var45 = null;
    var34.add(3.0d, (-0.55d), (java.lang.Comparable)0.0f, var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test158"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var4 = null;
    var2.setSeriesItemLabelsVisible(0, var4, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var2.setSeriesToolTipGenerator(1, var8, false);
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var2.setBaseURLGenerator(var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.Marker var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    var2.drawRangeMarker(var13, var14, var15, var16, var17);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var2.setBaseURLGenerator(var19, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var24 = null;
    var22.setSeriesItemLabelsVisible(0, var24, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
    var22.setSeriesToolTipGenerator(1, var28, false);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var22.setBaseURLGenerator(var31);
    var22.setBaseCreateEntities(false, false);
    var22.setBaseSeriesVisibleInLegend(false);
    var22.setBaseItemLabelsVisible(true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var43 = var41.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var46 = var41.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var47 = var41.getBaseURLGenerator();
    java.lang.Boolean var49 = var41.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var50 = null;
    org.jfree.chart.axis.CategoryAxis var51 = null;
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var53 = null;
    var52.setPlot(var53);
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var50, var51, (org.jfree.chart.axis.ValueAxis)var52, var55);
    java.awt.Stroke var57 = var52.getTickMarkStroke();
    var41.setBaseOutlineStroke(var57);
    org.jfree.chart.labels.ItemLabelPosition var59 = var41.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var60 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var61 = var60.getEntityCollection();
    boolean var62 = var59.equals((java.lang.Object)var60);
    var22.setSeriesPositiveItemLabelPosition(0, var59);
    var2.setPositiveItemLabelPositionFallback(var59);
    org.jfree.data.category.CategoryDataset var66 = null;
    org.jfree.chart.axis.CategoryAxis var67 = null;
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var69 = null;
    var68.setPlot(var69);
    org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var66, var67, (org.jfree.chart.axis.ValueAxis)var68, var71);
    org.jfree.chart.LegendItemSource var73 = null;
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
    org.jfree.chart.util.RectangleEdge var75 = var74.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var77 = var76.getNextOutlinePaint();
    var74.setBackgroundPaint(var77);
    var72.setOutlinePaint(var77);
    org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var72);
    var80.fireChartChanged();
    var80.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var84 = var80.getCategoryPlot();
    var84.clearRangeAxes();
    var84.clearDomainMarkers();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var87 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var88 = var87.getPositiveItemLabelPositionFallback();
    java.awt.Paint var91 = var87.getItemLabelPaint((-123), (-1));
    var84.setOutlinePaint(var91);
    var2.setBaseOutlinePaint(var91);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic(var1, var91);
    java.awt.Shape var95 = var94.getShape();
    java.awt.Stroke var96 = null;
    var94.setLineStroke(var96);
    java.awt.Paint var98 = var94.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var98);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test159"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    java.lang.String var2 = var0.getLabelURL();
    java.awt.Paint var3 = var0.getTickMarkPaint();
    org.jfree.chart.event.AxisChangeEvent var4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    var0.resizeRange(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test160"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    java.lang.String var1 = var0.getLGPL();
    java.lang.String var2 = var0.getGPL();
    java.lang.String var3 = var0.getLGPL();
    java.lang.String var4 = var0.getLGPL();
    java.lang.String var5 = var0.getGPL();

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test161"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, 1.0d);
    org.jfree.chart.util.Size2D var3 = null;
    org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
    double var5 = var4.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test162"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    boolean var2 = var1.isNegativeArrowVisible();
    java.lang.String var3 = var1.getLabelURL();
    var1.setLabelAngle(6.0d);
    var1.setAutoRange(false);
    java.awt.Font var8 = var1.getTickLabelFont();
    java.awt.Color var11 = java.awt.Color.getColor("", (-1));
    float[] var12 = null;
    float[] var13 = var11.getRGBComponents(var12);
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("", var8, (java.awt.Paint)var11);
    java.awt.Paint var15 = var14.getPaint();
    java.lang.Object var16 = var14.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test163"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    org.jfree.chart.plot.Plot var18 = var15.getPlot();
    org.jfree.chart.LegendItemSource var19 = null;
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
    org.jfree.chart.util.RectangleInsets var21 = var20.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var22 = var20.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var23 = var20.getItemContainer();
    var15.removeSubtitle((org.jfree.chart.title.Title)var20);
    org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("");
    boolean var28 = var26.equals((java.lang.Object)' ');
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
    boolean var30 = var29.isNegativeArrowVisible();
    java.lang.String var31 = var29.getLabelURL();
    var29.setLabelAngle(6.0d);
    var29.setAutoRange(false);
    java.awt.Font var36 = var29.getTickLabelFont();
    var26.setFont(var36);
    var20.setItemFont(var36);
    double var39 = var20.getContentYOffset();
    org.jfree.chart.util.RectangleInsets var40 = var20.getItemLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test164"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var2 = var0.equals((java.lang.Object)(short)10);
    java.awt.Paint var3 = var0.getNextFillPaint();
    java.lang.Object var4 = var0.clone();
    java.awt.Paint var5 = var0.getNextPaint();
    java.awt.Paint var6 = var0.getNextOutlinePaint();
    java.lang.Object var7 = var0.clone();
    java.awt.Paint var8 = var0.getNextOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test165"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    int var7 = var0.getColumnCount();
    java.awt.Shape var9 = var0.getSeriesShape((-855310));
    var0.setBaseCreateEntities(true, false);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var18 = null;
    var17.setPlot(var18);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
    org.jfree.chart.LegendItemSource var22 = null;
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var22);
    org.jfree.chart.util.RectangleEdge var24 = var23.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var26 = var25.getNextOutlinePaint();
    var23.setBackgroundPaint(var26);
    var21.setOutlinePaint(var26);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var21);
    var29.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var31 = var29.getCategoryPlot();
    java.awt.image.BufferedImage var34 = var29.createBufferedImage(1, 1);
    java.awt.RenderingHints var35 = var29.getRenderingHints();
    java.awt.Stroke var36 = var29.getBorderStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-10289251), var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test166"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var25 = var24.getFont();
    java.awt.Color var29 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var25, (java.awt.Paint)var29);
    java.awt.Color var31 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var29);
    var19.setDomainGridlinePaint((java.awt.Paint)var29);
    org.jfree.chart.util.RectangleEdge var33 = var19.getDomainAxisEdge();
    java.awt.Paint var34 = var19.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test167"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var6 = null;
//     var5.setPlot(var6);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var3, var4, (org.jfree.chart.axis.ValueAxis)var5, var8);
//     org.jfree.chart.LegendItemSource var10 = null;
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
//     org.jfree.chart.util.RectangleEdge var12 = var11.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var14 = var13.getNextOutlinePaint();
//     var11.setBackgroundPaint(var14);
//     var9.setOutlinePaint(var14);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
//     var17.fireChartChanged();
//     org.jfree.chart.plot.CategoryPlot var19 = var17.getCategoryPlot();
//     org.jfree.chart.plot.Plot var20 = var17.getPlot();
//     org.jfree.chart.LegendItemSource var21 = null;
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var24 = var22.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var25 = var22.getItemContainer();
//     var17.removeSubtitle((org.jfree.chart.title.Title)var22);
//     org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("");
//     boolean var30 = var28.equals((java.lang.Object)' ');
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     boolean var32 = var31.isNegativeArrowVisible();
//     java.lang.String var33 = var31.getLabelURL();
//     var31.setLabelAngle(6.0d);
//     var31.setAutoRange(false);
//     java.awt.Font var38 = var31.getTickLabelFont();
//     var28.setFont(var38);
//     var22.setItemFont(var38);
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("CategoryLabelWidthType.CATEGORY", var38);
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("Size2D[width=0.0, height=-1.0]", var38);
//     java.awt.Graphics2D var43 = null;
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var48 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var49 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var50 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var48, var49);
//     org.jfree.chart.text.TextAnchor var51 = var49.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var53 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var54 = null;
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle(var54);
//     org.jfree.chart.util.RectangleEdge var56 = var55.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var57 = org.jfree.chart.util.RectangleEdge.opposite(var56);
//     boolean var58 = var53.equals((java.lang.Object)var57);
//     org.jfree.chart.labels.ItemLabelAnchor var59 = var53.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var60 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var61 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var62 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var60, var61);
//     org.jfree.chart.text.TextAnchor var63 = var61.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var64 = new org.jfree.chart.labels.ItemLabelPosition(var59, var63);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var45, 100.0f, 0.0f, var51, 100.0d, var63);
//     org.jfree.chart.LegendItemSource var66 = null;
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle(var66);
//     org.jfree.chart.util.RectangleEdge var68 = var67.getLegendItemGraphicEdge();
//     java.awt.Paint var69 = var67.getItemPaint();
//     var67.setNotify(true);
//     java.awt.geom.Rectangle2D var72 = var67.getBounds();
//     boolean var73 = var63.equals((java.lang.Object)var72);
//     float var74 = var42.calculateBaselineOffset(var43, var63);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test168"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    int var12 = var6.getRangeAxisCount();
    var6.setForegroundAlpha(0.0f);
    java.awt.Color var18 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.color.ColorSpace var19 = var18.getColorSpace();
    var6.setNoDataMessagePaint((java.awt.Paint)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test169"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.util.List var7 = var6.getLines();
    boolean var8 = var1.equals((java.lang.Object)var6);
    org.jfree.chart.event.TitleChangeEvent var9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleInsets var12 = var11.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var13 = var11.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var14 = var11.getItemContainer();
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
    double var19 = var17.calculateTopOutset(4.0d);
    var14.setMargin(var17);
    java.awt.geom.Rectangle2D var21 = var14.getBounds();
    org.jfree.chart.LegendItemSource var22 = null;
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var22);
    org.jfree.chart.util.RectangleInsets var24 = var23.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var25 = var23.getLegendItemGraphicLocation();
    java.awt.geom.Point2D var26 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var25);
    var1.setLegendItemGraphicAnchor(var25);
    org.jfree.chart.util.VerticalAlignment var28 = var1.getVerticalAlignment();
    org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("");
    boolean var32 = var30.equals((java.lang.Object)' ');
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
    boolean var34 = var33.isNegativeArrowVisible();
    java.lang.String var35 = var33.getLabelURL();
    var33.setLabelAngle(6.0d);
    var33.setAutoRange(false);
    java.awt.Font var40 = var33.getTickLabelFont();
    var30.setFont(var40);
    java.lang.String var42 = var30.getURLText();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var43 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var45 = var43.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var48 = var43.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var49 = var43.getLegendItemToolTipGenerator();
    java.awt.Paint var52 = var43.getItemPaint(1, (-123));
    var30.setPaint(var52);
    var1.setBackgroundPaint(var52);
    org.jfree.chart.event.TitleChangeEvent var55 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    org.jfree.chart.JFreeChart var56 = var55.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test170"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedWidth(0.05d);
    org.jfree.chart.block.RectangleConstraint var5 = var4.toUnconstrainedHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test171"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisCollection var2 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var3 = var2.getAxesAtTop();
    boolean var4 = var0.equals((java.lang.Object)var2);
    java.util.List var5 = var2.getAxesAtTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test172"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtTop();
    java.util.List var2 = var0.getAxesAtLeft();
    java.util.List var3 = var0.getAxesAtBottom();
    java.util.List var4 = var0.getAxesAtBottom();
    java.util.List var5 = var0.getAxesAtRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test173"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var4 = var2.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var0, var4, 0.0d, 2.0d);
    org.jfree.data.general.Dataset var8 = null;
    org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var8, (java.lang.Comparable)Double.NaN);
    var10.setMargin(0.0d, Double.NaN, (-0.55d), Double.NEGATIVE_INFINITY);
    var10.setToolTipText("-1");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test174"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var11 = java.awt.Color.getColor("", (-1));
    var0.setBasePaint((java.awt.Paint)var11, true);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    boolean var21 = var20.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var23 = var20.getDataset((-123));
    var20.clearRangeMarkers(0);
    java.awt.Color var30 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity(var36, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var41 = null;
    var39.setSeriesItemLabelsVisible(0, var41, false);
    java.awt.Stroke var44 = var39.getErrorIndicatorStroke();
    java.awt.Paint var45 = null;
    org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var36, var44, var45);
    org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var30, var44);
    var20.setDomainGridlineStroke(var44);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
    boolean var51 = var0.isSeriesItemLabelsVisible((-621738));
    boolean var53 = var0.isSeriesVisible(1);
    var0.setBaseSeriesVisibleInLegend(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test175"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var6 = var4.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var4.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var10 = var4.getBaseURLGenerator();
//     int var11 = var4.getColumnCount();
//     boolean var12 = var4.getAutoPopulateSeriesOutlineStroke();
//     var4.setAutoPopulateSeriesStroke(false);
//     java.awt.Stroke var16 = var4.lookupSeriesOutlineStroke(0);
//     org.jfree.chart.LegendItemCollection var17 = new org.jfree.chart.LegendItemCollection();
//     int var18 = var17.getItemCount();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var21 = null;
//     var19.setSeriesItemLabelsVisible(0, var21, false);
//     java.awt.Stroke var24 = var19.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var25 = var19.getDrawingSupplier();
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity(var28, "Range[-1.0,-1.0]");
//     var19.setSeriesShape(10, var28);
//     boolean var32 = var17.equals((java.lang.Object)var28);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, Double.NaN, 0.0f, 10.0f);
//     var4.setBaseShape(var28, false);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var42 = null;
//     var41.setPlot(var42);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var40, (org.jfree.chart.axis.ValueAxis)var41, var44);
//     var41.setAutoRangeMinimumSize(2.0d);
//     var41.setFixedDimension(0.05d);
//     double var50 = var41.getLowerBound();
//     boolean var51 = var41.getAutoRangeStickyZero();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var53 = null;
//     var52.setBaseURLGenerator(var53);
//     org.jfree.data.category.CategoryDataset var56 = null;
//     org.jfree.chart.axis.CategoryAxis var57 = null;
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var59 = null;
//     var58.setPlot(var59);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var56, var57, (org.jfree.chart.axis.ValueAxis)var58, var61);
//     org.jfree.chart.LegendItemSource var63 = null;
//     org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle(var63);
//     org.jfree.chart.util.RectangleEdge var65 = var64.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var66 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var67 = var66.getNextOutlinePaint();
//     var64.setBackgroundPaint(var67);
//     var62.setOutlinePaint(var67);
//     var52.setSeriesPaint(1, var67, false);
//     java.awt.Stroke var72 = var52.getBaseOutlineStroke();
//     var41.setAxisLineStroke(var72);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var74 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var76 = var74.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var77 = null;
//     var74.setBaseItemLabelGenerator(var77);
//     java.awt.Paint var81 = var74.getItemFillPaint(0, (-855310));
//     org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("[size=1]", "CategoryLabelWidthType.CATEGORY", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "SortOrder.ASCENDING", var28, var72, var81);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var74 and var19.", var74.equals(var19) == var19.equals(var74));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var74 and var52.", var74.equals(var52) == var52.equals(var74));
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test176"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var14, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    java.awt.Paint var23 = null;
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var14, var22, var23);
    boolean var25 = var24.isLineVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    java.lang.Object var28 = var26.clone();
    var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    org.jfree.chart.LegendItemSource var31 = null;
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
    org.jfree.chart.util.RectangleInsets var33 = var32.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var34 = var32.getLegendItemGraphicLocation();
    boolean var35 = var26.equals((java.lang.Object)var34);
    org.jfree.chart.util.GradientPaintTransformType var36 = var26.getType();
    java.lang.String var37 = var36.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var37.equals("GradientPaintTransformType.VERTICAL"));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test177"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    double var4 = var2.calculateTopOutset(4.0d);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextOutlinePaint();
    var13.setBackgroundPaint(var16);
    var11.setOutlinePaint(var16);
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var19, var20, (org.jfree.chart.axis.ValueAxis)var21, var24);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var27 = null;
    var26.setPlot(var27);
    org.jfree.chart.axis.ValueAxis[] var29 = new org.jfree.chart.axis.ValueAxis[] { var26};
    var25.setRangeAxes(var29);
    var11.setParent((org.jfree.chart.plot.Plot)var25);
    java.awt.Stroke var32 = var25.getRangeCrosshairStroke();
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.LegendItemSource var34 = null;
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var34);
    org.jfree.chart.util.RectangleInsets var36 = var35.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var37 = null;
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
    org.jfree.chart.util.RectangleInsets var39 = var38.getItemLabelPadding();
    double var40 = var39.getTop();
    var35.setPadding(var39);
    org.jfree.chart.util.Size2D var42 = new org.jfree.chart.util.Size2D();
    boolean var44 = var42.equals((java.lang.Object)(-1L));
    double var45 = var42.getWidth();
    double var46 = var42.getHeight();
    org.jfree.chart.util.RectangleAnchor var49 = null;
    java.awt.geom.Rectangle2D var50 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 2.0d, (-1.0d), var49);
    org.jfree.chart.axis.CategoryLabelPositions var53 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var54 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var55 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var53, var54);
    org.jfree.chart.util.RectangleAnchor var56 = var54.getCategoryAnchor();
    java.awt.geom.Rectangle2D var57 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 2.0d, 1.0d, var56);
    java.awt.geom.Rectangle2D var58 = var39.createOutsetRectangle(var57);
    org.jfree.chart.plot.PlotRenderingInfo var60 = null;
    boolean var61 = var25.render(var33, var58, 255, var60);
    java.awt.geom.Rectangle2D var64 = var2.createInsetRectangle(var58, false, false);
    java.lang.String var65 = var2.toString();
    org.jfree.chart.LegendItemSource var66 = null;
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle(var66);
    org.jfree.chart.util.RectangleEdge var68 = var67.getLegendItemGraphicEdge();
    java.awt.Paint var69 = var67.getItemPaint();
    var67.setNotify(true);
    org.jfree.chart.axis.AxisSpace var72 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.LegendItemSource var74 = null;
    org.jfree.chart.title.LegendTitle var75 = new org.jfree.chart.title.LegendTitle(var74);
    org.jfree.chart.util.RectangleEdge var76 = var75.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var77 = org.jfree.chart.util.RectangleEdge.opposite(var76);
    var72.ensureAtLeast(100.0d, var77);
    var67.setPosition(var77);
    java.lang.Object var80 = var67.clone();
    org.jfree.chart.ChartRenderingInfo var81 = null;
    org.jfree.chart.plot.PlotRenderingInfo var82 = new org.jfree.chart.plot.PlotRenderingInfo(var81);
    java.lang.Object var83 = var82.clone();
    java.awt.geom.Rectangle2D var84 = var82.getDataArea();
    var67.setBounds(var84);
    var2.trim(var84);
    double var88 = var2.trimHeight(0.55d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"+ "'", var65.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == (-3.45d));

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test178"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var7 = null;
    var6.setPlot(var7);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
    org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var15 = var14.getNextOutlinePaint();
    var12.setBackgroundPaint(var15);
    var10.setOutlinePaint(var15);
    var0.setSeriesPaint(1, var15, false);
    java.awt.Stroke var20 = var0.getBaseOutlineStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var23 = var21.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var26 = var21.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var27 = var21.getBaseURLGenerator();
    java.lang.Boolean var29 = var21.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var32 = java.awt.Color.getColor("", (-1));
    var21.setBasePaint((java.awt.Paint)var32, true);
    boolean var35 = var0.equals((java.lang.Object)var21);
    var21.setItemLabelAnchorOffset((-8.0d));
    java.awt.Stroke var39 = var21.getSeriesOutlineStroke((-855310));
    var21.setBaseCreateEntities(false, false);
    var21.setAutoPopulateSeriesShape(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test179"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    double var9 = var0.getUpperClip();
    java.awt.Stroke var10 = var0.getBaseStroke();
    java.awt.Shape var13 = var0.getItemShape(4, 10);
    org.jfree.chart.event.RendererChangeEvent var14 = null;
    var0.notifyListeners(var14);
    boolean var17 = var0.isSeriesVisibleInLegend((-123));
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var21 = null;
    var20.setPlot(var21);
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
    org.jfree.chart.LegendItemSource var25 = null;
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
    org.jfree.chart.util.RectangleEdge var27 = var26.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var29 = var28.getNextOutlinePaint();
    var26.setBackgroundPaint(var29);
    var24.setOutlinePaint(var29);
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.axis.CategoryAxis var33 = null;
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var35 = null;
    var34.setPlot(var35);
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var34, var37);
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var40 = null;
    var39.setPlot(var40);
    org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var39};
    var38.setRangeAxes(var42);
    var24.setParent((org.jfree.chart.plot.Plot)var38);
    var24.setRangeGridlinesVisible(true);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("rect");
    var24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test180"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    boolean var18 = var17.getDrawSharedDomainAxis();
    java.lang.String var19 = var17.getNoDataMessage();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var23 = null;
    var22.setPlot(var23);
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var20, var21, (org.jfree.chart.axis.ValueAxis)var22, var25);
    java.awt.Stroke var27 = var22.getTickMarkStroke();
    var22.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var31 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var32 = var31.getPadding();
    double var34 = var32.calculateTopInset(100.0d);
    var22.setLabelInsets(var32);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.95f);
    org.jfree.chart.entity.AxisLabelEntity var41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var22, var38, "CategoryLabelEntity: category=null, tooltip=hi!, url=", "");
    java.awt.Stroke var42 = var22.getAxisLineStroke();
    org.jfree.data.Range var43 = var22.getRange();
    var17.setRangeAxis((org.jfree.chart.axis.ValueAxis)var22);
    boolean var45 = var22.isAutoTickUnitSelection();
    boolean var46 = var22.getAutoRangeStickyZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test181"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    java.awt.Paint var12 = var6.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var16 = null;
    var15.setPlot(var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
    var19.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var25 = null;
    var23.setSeriesItemLabelsVisible(0, var25, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var29 = null;
    var23.setSeriesToolTipGenerator(1, var29, false);
    org.jfree.chart.urls.CategoryURLGenerator var32 = null;
    var23.setBaseURLGenerator(var32);
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.plot.Marker var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    var23.drawRangeMarker(var34, var35, var36, var37, var38);
    boolean var41 = var23.isSeriesVisibleInLegend(0);
    var19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.util.Layer var44 = null;
    java.util.Collection var45 = var19.getDomainMarkers(10, var44);
    org.jfree.chart.axis.AxisLocation var47 = var19.getDomainAxisLocation((-1));
    java.lang.String var48 = var47.toString();
    var6.setRangeAxisLocation(var47);
    boolean var50 = var6.isRangeCrosshairVisible();
    org.jfree.chart.plot.PlotOrientation var51 = var6.getOrientation();
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.95f);
    org.jfree.chart.entity.LegendItemEntity var54 = new org.jfree.chart.entity.LegendItemEntity(var53);
    org.jfree.data.general.Dataset var55 = var54.getDataset();
    java.lang.Comparable var56 = var54.getSeriesKey();
    java.lang.String var57 = var54.toString();
    java.lang.Object var58 = var54.clone();
    boolean var59 = var51.equals(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var48.equals("AxisLocation.TOP_OR_RIGHT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var57.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test182"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Stroke var16 = var11.getTickMarkStroke();
    var0.setBaseOutlineStroke(var16);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var19 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var20 = var19.getEntityCollection();
    boolean var21 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.labels.ItemLabelAnchor var22 = var18.getItemLabelAnchor();
    java.lang.String var23 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "ItemLabelAnchor.OUTSIDE6"+ "'", var23.equals("ItemLabelAnchor.OUTSIDE6"));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test183"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    var1.setURLText("");
    java.lang.String var4 = var1.getToolTipText();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    boolean var6 = var5.isNegativeArrowVisible();
    java.lang.String var7 = var5.getLabelURL();
    var5.setLabelAngle(6.0d);
    var5.setAutoRange(false);
    java.lang.Object var12 = var5.clone();
    double var13 = var5.getLowerMargin();
    org.jfree.chart.plot.Plot var14 = var5.getPlot();
    org.jfree.data.KeyedObjects2D var17 = new org.jfree.data.KeyedObjects2D();
    java.util.List var18 = var17.getColumnKeys();
    int var20 = var17.getRowIndex((java.lang.Comparable)100);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    boolean var22 = var21.isNegativeArrowVisible();
    java.lang.String var23 = var21.getLabelURL();
    var21.setLabelAngle(6.0d);
    var21.setAutoRange(false);
    java.awt.Font var28 = var21.getTickLabelFont();
    var17.setObject((java.lang.Object)var28, (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=", (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var33 = var32.getPositiveItemLabelPositionFallback();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var35 = var34.getPositiveItemLabelPositionFallback();
    java.awt.Paint var38 = var34.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var40 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var42 = null;
    var41.setPlot(var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var40, (org.jfree.chart.axis.ValueAxis)var41, var44);
    java.awt.Stroke var46 = var41.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var47 = null;
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle(var47);
    org.jfree.chart.util.RectangleInsets var49 = var48.getItemLabelPadding();
    double var50 = var49.getTop();
    org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder(var38, var46, var49);
    var32.setBaseOutlinePaint(var38);
    java.awt.Paint var53 = var32.getBaseFillPaint();
    org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("HorizontalAlignment.CENTER", var28, var53, 1.0f);
    org.jfree.chart.text.TextLine var56 = new org.jfree.chart.text.TextLine("RectangleAnchor.CENTER", var28);
    var5.setLabelFont(var28);
    var1.setFont(var28);
    java.lang.String var59 = var1.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test184"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.95f);
    org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
    org.jfree.data.general.Dataset var3 = var2.getDataset();
    java.lang.Object var4 = var2.clone();
    java.lang.String var5 = var2.getToolTipText();
    java.lang.Comparable var6 = var2.getSeriesKey();
    java.lang.Comparable var7 = var2.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test185"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    var0.setIncludeBaseInRange(false);
    java.awt.Shape var5 = var0.getBaseShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test186"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)(byte)10);
    java.lang.Number var3 = var2.getMean();
    java.lang.Number var4 = var2.getStandardDeviation();
    org.jfree.data.KeyedObjects2D var5 = new org.jfree.data.KeyedObjects2D();
    java.util.List var6 = var5.getColumnKeys();
    java.lang.Object var9 = var5.getObject((java.lang.Comparable)(-1), (java.lang.Comparable)0L);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var11 = var10.getPositiveItemLabelPositionFallback();
    java.awt.Paint var14 = var10.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var18 = null;
    var17.setPlot(var18);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
    java.awt.Stroke var22 = var17.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var23 = null;
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle(var23);
    org.jfree.chart.util.RectangleInsets var25 = var24.getItemLabelPadding();
    double var26 = var25.getTop();
    org.jfree.chart.block.LineBorder var27 = new org.jfree.chart.block.LineBorder(var14, var22, var25);
    java.awt.Stroke var28 = var27.getStroke();
    var5.setObject((java.lang.Object)var27, (java.lang.Comparable)"", (java.lang.Comparable)4.0d);
    boolean var32 = var2.equals((java.lang.Object)var27);
    java.awt.Paint var33 = var27.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)10+ "'", var4.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test187"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.util.List var7 = var6.getLines();
    boolean var8 = var1.equals((java.lang.Object)var6);
    org.jfree.chart.util.RectangleEdge var9 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var10 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    boolean var12 = var11.isNegativeArrowVisible();
    java.awt.Shape var13 = var11.getDownArrow();
    boolean var14 = var10.equals((java.lang.Object)var11);
    var11.setAutoTickUnitSelection(false, false);
    java.awt.Paint var18 = var11.getLabelPaint();
    org.jfree.chart.axis.NumberTickUnit var19 = var11.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test188"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    java.awt.Paint var11 = var0.getErrorIndicatorPaint();
    java.awt.Paint var12 = var0.getBaseFillPaint();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var16 = null;
    var15.setPlot(var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
    org.jfree.chart.LegendItemSource var20 = null;
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle(var20);
    org.jfree.chart.util.RectangleEdge var22 = var21.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var24 = var23.getNextOutlinePaint();
    var21.setBackgroundPaint(var24);
    var19.setOutlinePaint(var24);
    org.jfree.data.category.CategoryDataset var27 = null;
    org.jfree.chart.axis.CategoryAxis var28 = null;
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var30 = null;
    var29.setPlot(var30);
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var29, var32);
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var35 = null;
    var34.setPlot(var35);
    org.jfree.chart.axis.ValueAxis[] var37 = new org.jfree.chart.axis.ValueAxis[] { var34};
    var33.setRangeAxes(var37);
    var19.setParent((org.jfree.chart.plot.Plot)var33);
    org.jfree.chart.LegendItemSource var40 = null;
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
    org.jfree.chart.util.RectangleInsets var42 = var41.getItemLabelPadding();
    double var43 = var42.getTop();
    var33.setAxisOffset(var42);
    boolean var45 = var0.hasListener((java.util.EventListener)var33);
    org.jfree.chart.plot.DatasetRenderingOrder var46 = var33.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test189"); }


    java.lang.Comparable var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "Range[-1.0,-1.0]");
    org.jfree.chart.entity.CategoryLabelEntity var7 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var2, "hi!", "");
    java.lang.String var8 = var7.toString();
    var7.setURLText("hi!");
    var7.setToolTipText("");
    java.awt.Shape var13 = var7.getArea();
    java.lang.Comparable var14 = var7.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "CategoryLabelEntity: category=null, tooltip=hi!, url="+ "'", var8.equals("CategoryLabelEntity: category=null, tooltip=hi!, url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test190"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getSeriesRunningTotal();
    double var3 = var1.getBarWidth();
    double var4 = var1.getSeriesRunningTotal();
    double var5 = var1.getSeriesRunningTotal();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test191"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    boolean var5 = var0.equals((java.lang.Object)var4);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var8, var11);
    var12.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = null;
    var16.setSeriesItemLabelsVisible(0, var18, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var16.setSeriesToolTipGenerator(1, var22, false);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var16.setBaseURLGenerator(var25);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.plot.Marker var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    var16.drawRangeMarker(var27, var28, var29, var30, var31);
    boolean var34 = var16.isSeriesVisibleInLegend(0);
    var12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    boolean var36 = var0.equals((java.lang.Object)var16);
    boolean var37 = var16.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.block.BorderArrangement var38 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
    var39.setMaximumCategoryLabelWidthRatio(0.95f);
    var39.setCategoryMargin(0.05d);
    boolean var44 = var38.equals((java.lang.Object)0.05d);
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var46 = var45.getPadding();
    boolean var47 = var45.isEmpty();
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var52 = null;
    org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, (-1.0d));
    org.jfree.data.Range var55 = null;
    org.jfree.data.Range var57 = org.jfree.data.Range.expandToInclude(var55, (-1.0d));
    org.jfree.data.Range var58 = org.jfree.data.Range.combine(var54, var57);
    double var59 = var57.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var60 = var51.toRangeHeight(var57);
    org.jfree.chart.util.Size2D var61 = var38.arrange(var45, var48, var51);
    org.jfree.chart.util.HorizontalAlignment var62 = null;
    org.jfree.chart.util.VerticalAlignment var63 = null;
    org.jfree.chart.block.FlowArrangement var66 = new org.jfree.chart.block.FlowArrangement(var62, var63, 0.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var67 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var66);
    var66.clear();
    org.jfree.chart.util.StandardGradientPaintTransformer var69 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var70 = var69.clone();
    org.jfree.chart.event.ChartChangeEvent var71 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var69);
    boolean var72 = var66.equals((java.lang.Object)var69);
    org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, (org.jfree.chart.block.Arrangement)var38, (org.jfree.chart.block.Arrangement)var66);
    org.jfree.chart.LegendItemSource[] var74 = var73.getSources();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test192"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.LegendItemSource var6 = null;
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
//     org.jfree.chart.util.RectangleEdge var8 = var7.getLegendItemGraphicEdge();
//     java.awt.Paint var9 = var7.getItemPaint();
//     var7.setNotify(true);
//     boolean var12 = var1.equals((java.lang.Object)var7);
//     var7.setMargin(Double.NaN, 100.0d, Double.NaN, 6.0d);
//     org.jfree.chart.axis.AxisSpace var18 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var19 = var18.clone();
//     org.jfree.chart.axis.AxisCollection var20 = new org.jfree.chart.axis.AxisCollection();
//     java.util.List var21 = var20.getAxesAtTop();
//     boolean var22 = var18.equals((java.lang.Object)var20);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var24 = null;
//     var23.setPlot(var24);
//     var23.setLowerBound(2.0d);
//     java.lang.String var28 = var23.getLabelToolTip();
//     java.awt.Shape var29 = var23.getRightArrow();
//     org.jfree.chart.LegendItemSource var30 = null;
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle(var30);
//     org.jfree.chart.util.RectangleEdge var32 = var31.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var33 = org.jfree.chart.util.RectangleEdge.opposite(var32);
//     boolean var34 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var33);
//     var20.add((org.jfree.chart.axis.Axis)var23, var33);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var37 = null;
//     var36.setPlot(var37);
//     var36.setLowerBound(2.0d);
//     java.lang.String var41 = var36.getLabelToolTip();
//     org.jfree.data.category.CategoryDataset var42 = null;
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var45 = null;
//     var44.setPlot(var45);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var42, var43, (org.jfree.chart.axis.ValueAxis)var44, var47);
//     org.jfree.chart.LegendItemSource var49 = null;
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle(var49);
//     org.jfree.chart.util.RectangleEdge var51 = var50.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var52 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var53 = var52.getNextOutlinePaint();
//     var50.setBackgroundPaint(var53);
//     var48.setOutlinePaint(var53);
//     org.jfree.data.category.CategoryDataset var56 = null;
//     org.jfree.chart.axis.CategoryAxis var57 = null;
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var59 = null;
//     var58.setPlot(var59);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var56, var57, (org.jfree.chart.axis.ValueAxis)var58, var61);
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var64 = null;
//     var63.setPlot(var64);
//     org.jfree.chart.axis.ValueAxis[] var66 = new org.jfree.chart.axis.ValueAxis[] { var63};
//     var62.setRangeAxes(var66);
//     var48.setParent((org.jfree.chart.plot.Plot)var62);
//     java.awt.Stroke var69 = var62.getRangeCrosshairStroke();
//     var36.addChangeListener((org.jfree.chart.event.AxisChangeListener)var62);
//     org.jfree.chart.LegendItemSource var71 = null;
//     org.jfree.chart.title.LegendTitle var72 = new org.jfree.chart.title.LegendTitle(var71);
//     org.jfree.chart.util.RectangleEdge var73 = var72.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var74 = org.jfree.chart.util.RectangleEdge.opposite(var73);
//     boolean var75 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var74);
//     var20.add((org.jfree.chart.axis.Axis)var36, var74);
//     var7.setLegendItemGraphicEdge(var74);
//     
//     // Checks the contract:  equals-hashcode on var3 and var52
//     assertTrue("Contract failed: equals-hashcode on var3 and var52", var3.equals(var52) ? var3.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var3
//     assertTrue("Contract failed: equals-hashcode on var52 and var3", var52.equals(var3) ? var52.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test193"); }


    java.lang.Comparable var2 = null;
    org.jfree.chart.text.TextBlock var3 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.util.Size2D var5 = var3.calculateDimensions(var4);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var10 = null;
    var9.setPlot(var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var8, (org.jfree.chart.axis.ValueAxis)var9, var12);
    java.awt.Stroke var14 = var9.getTickMarkStroke();
    java.awt.Font var15 = var9.getLabelFont();
    java.awt.Color var18 = java.awt.Color.getColor("", (-1));
    var3.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var15, (java.awt.Paint)var18);
    org.jfree.data.KeyedObject var20 = new org.jfree.data.KeyedObject(var2, (java.lang.Object)var15);
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=242,g=242,b=242]", var15);
    java.awt.Color var24 = java.awt.Color.getColor("Range[-1.0,-1.0]", 0);
    org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("", var15, (java.awt.Paint)var24);
    java.awt.Font var26 = var25.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test194"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Size2D[width=0.0, height=-1.0]", var1);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test195"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    boolean var5 = var0.equals((java.lang.Object)var4);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var8, var11);
    var12.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = null;
    var16.setSeriesItemLabelsVisible(0, var18, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var16.setSeriesToolTipGenerator(1, var22, false);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var16.setBaseURLGenerator(var25);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.plot.Marker var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    var16.drawRangeMarker(var27, var28, var29, var30, var31);
    boolean var34 = var16.isSeriesVisibleInLegend(0);
    var12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    boolean var36 = var0.equals((java.lang.Object)var16);
    boolean var37 = var16.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.block.BorderArrangement var38 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
    var39.setMaximumCategoryLabelWidthRatio(0.95f);
    var39.setCategoryMargin(0.05d);
    boolean var44 = var38.equals((java.lang.Object)0.05d);
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var46 = var45.getPadding();
    boolean var47 = var45.isEmpty();
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var52 = null;
    org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, (-1.0d));
    org.jfree.data.Range var55 = null;
    org.jfree.data.Range var57 = org.jfree.data.Range.expandToInclude(var55, (-1.0d));
    org.jfree.data.Range var58 = org.jfree.data.Range.combine(var54, var57);
    double var59 = var57.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var60 = var51.toRangeHeight(var57);
    org.jfree.chart.util.Size2D var61 = var38.arrange(var45, var48, var51);
    org.jfree.chart.util.HorizontalAlignment var62 = null;
    org.jfree.chart.util.VerticalAlignment var63 = null;
    org.jfree.chart.block.FlowArrangement var66 = new org.jfree.chart.block.FlowArrangement(var62, var63, 0.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var67 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var66);
    var66.clear();
    org.jfree.chart.util.StandardGradientPaintTransformer var69 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var70 = var69.clone();
    org.jfree.chart.event.ChartChangeEvent var71 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var69);
    boolean var72 = var66.equals((java.lang.Object)var69);
    org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, (org.jfree.chart.block.Arrangement)var38, (org.jfree.chart.block.Arrangement)var66);
    var38.clear();
    var38.clear();
    var38.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test196"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    java.lang.String var5 = var0.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var6 = var0.getTickUnit();
    org.jfree.data.Range var7 = var0.getRange();
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var20 = var19.getNextOutlinePaint();
    var17.setBackgroundPaint(var20);
    var15.setOutlinePaint(var20);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
    var23.fireChartChanged();
    var23.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var27 = var23.getCategoryPlot();
    var27.clearRangeAxes();
    org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var30 = var29.clone();
    org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
    var29.ensureAtLeast(var31);
    double var33 = var31.getTop();
    var27.setFixedRangeAxisSpace(var31);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var27);
    org.jfree.chart.plot.DatasetRenderingOrder var36 = var27.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var39 = null;
    var37.setSeriesItemLabelsVisible(0, var39, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
    var37.setSeriesToolTipGenerator(1, var43, false);
    org.jfree.chart.urls.CategoryURLGenerator var46 = null;
    var37.setBaseURLGenerator(var46);
    var37.setBaseCreateEntities(false, false);
    var37.setSeriesVisibleInLegend(0, (java.lang.Boolean)false);
    boolean var54 = var37.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryItemLabelGenerator var56 = var37.getSeriesItemLabelGenerator(255);
    org.jfree.chart.util.GradientPaintTransformer var57 = var37.getGradientPaintTransformer();
    boolean var58 = var36.equals((java.lang.Object)var57);
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var60 = null;
    var59.setPlot(var60);
    var59.setLowerBound(2.0d);
    java.lang.String var64 = var59.getLabelToolTip();
    java.awt.Shape var65 = var59.getRightArrow();
    org.jfree.chart.block.BorderArrangement var66 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.BlockContainer var67 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var68 = var67.getPadding();
    var67.setHeight(10.0d);
    java.awt.Graphics2D var71 = null;
    org.jfree.chart.block.RectangleConstraint var74 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var75 = var74.toUnconstrainedWidth();
    double var76 = var74.getHeight();
    org.jfree.chart.block.LengthConstraintType var77 = var74.getWidthConstraintType();
    org.jfree.chart.util.Size2D var78 = var66.arrange(var67, var71, var74);
    org.jfree.chart.axis.CategoryLabelPositions var81 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var82 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var83 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var81, var82);
    org.jfree.chart.axis.CategoryLabelPositions var84 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var85 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var86 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var84, var85);
    org.jfree.chart.axis.CategoryLabelPositions var87 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var88 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var89 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var87, var88);
    org.jfree.chart.axis.CategoryLabelPositions var90 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var84, var88);
    org.jfree.chart.axis.CategoryLabelPositions var91 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var83, var88);
    org.jfree.chart.util.RectangleAnchor var92 = var88.getCategoryAnchor();
    java.awt.geom.Rectangle2D var93 = org.jfree.chart.util.RectangleAnchor.createRectangle(var78, 0.05d, 1.0E-8d, var92);
    var59.setDownArrow((java.awt.Shape)var93);
    boolean var95 = var36.equals((java.lang.Object)var93);
    java.awt.Shape var99 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var93, 6.0d, 0.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test197"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var3 = null;
    var1.setSeriesItemLabelsVisible(0, var3, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var1.setSeriesToolTipGenerator(1, var7, false);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var1.setBaseURLGenerator(var10);
    var1.setBaseCreateEntities(false, false);
    var1.setBaseSeriesVisibleInLegend(false);
    var1.setBaseItemLabelsVisible(true);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var23 = null;
    var22.setPlot(var23);
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var20, var21, (org.jfree.chart.axis.ValueAxis)var22, var25);
    org.jfree.chart.LegendItemSource var27 = null;
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle(var27);
    org.jfree.chart.util.RectangleEdge var29 = var28.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var31 = var30.getNextOutlinePaint();
    var28.setBackgroundPaint(var31);
    var26.setOutlinePaint(var31);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var26);
    var34.fireChartChanged();
    var34.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var38 = var34.getCategoryPlot();
    var38.clearRangeAxes();
    var38.clearDomainMarkers();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var42 = var41.getPositiveItemLabelPositionFallback();
    java.awt.Paint var45 = var41.getItemLabelPaint((-123), (-1));
    var38.setOutlinePaint(var45);
    var1.setBasePaint(var45, false);
    java.awt.Font var51 = var1.getItemLabelFont(4, (-16777212));
    org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle("", var51);
    java.awt.Paint var53 = var52.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test198"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var11 = var6.getRangeAxisEdge();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var16 = null;
    var15.setPlot(var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
    org.jfree.chart.LegendItemSource var20 = null;
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle(var20);
    org.jfree.chart.util.RectangleEdge var22 = var21.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var24 = var23.getNextOutlinePaint();
    var21.setBackgroundPaint(var24);
    var19.setOutlinePaint(var24);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var19);
    var27.fireChartChanged();
    var27.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var31 = var27.getCategoryPlot();
    var31.clearRangeAxes();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var35 = var33.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var38 = var33.getPositiveItemLabelPosition(100, 0);
    org.jfree.data.general.Dataset var39 = null;
    org.jfree.data.general.DatasetChangeEvent var40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)0, var39);
    var31.datasetChanged(var40);
    org.jfree.data.general.Dataset var42 = var40.getDataset();
    var6.datasetChanged(var40);
    org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis();
    var44.setMaximumCategoryLabelWidthRatio(0.95f);
    var44.setCategoryMargin(0.05d);
    int var49 = var6.getDomainAxisIndex(var44);
    int var50 = var44.getMaximumCategoryLabelLines();
    int var51 = var44.getMaximumCategoryLabelLines();
    var44.setMaximumCategoryLabelWidthRatio(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test199"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)(byte)10);
    java.lang.Number var3 = var2.getMean();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var6 = var4.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var9 = var4.getPositiveItemLabelPosition(100, 0);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.data.general.DatasetChangeEvent var11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)0, var10);
    boolean var12 = var2.equals((java.lang.Object)0);
    java.lang.Number var13 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (byte)10+ "'", var13.equals((byte)10));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test200"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var2 = var0.getWidth();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, (-1.0d));
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, (-1.0d));
    org.jfree.data.Range var13 = org.jfree.data.Range.combine(var9, var12);
    double var14 = var12.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var15 = var6.toRangeHeight(var12);
    org.jfree.chart.util.Size2D var16 = var0.arrange(var3, var15);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.util.Size2D var18 = var0.arrange(var17);
    java.lang.Object var19 = var18.clone();
    double var20 = var18.getWidth();
    java.awt.Color var27 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var33, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var38 = null;
    var36.setSeriesItemLabelsVisible(0, var38, false);
    java.awt.Stroke var41 = var36.getErrorIndicatorStroke();
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var33, var41, var42);
    org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var27, var41);
    org.jfree.chart.text.TextAnchor var45 = var44.getLabelTextAnchor();
    org.jfree.chart.event.MarkerChangeEvent var46 = null;
    var44.notifyListeners(var46);
    org.jfree.chart.event.MarkerChangeEvent var48 = null;
    var44.notifyListeners(var48);
    org.jfree.chart.LegendItemSource var50 = null;
    org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle(var50);
    org.jfree.chart.util.RectangleInsets var52 = var51.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var53 = var51.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var54 = var51.getItemContainer();
    org.jfree.chart.LegendItemSource var55 = null;
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle(var55);
    org.jfree.chart.util.RectangleInsets var57 = var56.getItemLabelPadding();
    double var59 = var57.calculateTopOutset(4.0d);
    var54.setMargin(var57);
    java.awt.geom.Rectangle2D var61 = var54.getBounds();
    org.jfree.chart.LegendItemSource var62 = null;
    org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle(var62);
    org.jfree.chart.util.RectangleInsets var64 = var63.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var65 = var63.getLegendItemGraphicLocation();
    java.awt.geom.Point2D var66 = org.jfree.chart.util.RectangleAnchor.coordinates(var61, var65);
    var44.setLabelAnchor(var65);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var68 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var70 = var68.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var71 = null;
    var68.setBaseItemLabelGenerator(var71);
    org.jfree.chart.plot.DefaultDrawingSupplier var73 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var74 = var73.getNextOutlinePaint();
    var68.setErrorIndicatorPaint(var74);
    java.awt.Font var76 = var68.getBaseItemLabelFont();
    double var77 = var68.getLowerClip();
    org.jfree.chart.urls.CategoryURLGenerator var78 = null;
    var68.setBaseURLGenerator(var78, false);
    org.jfree.chart.labels.ItemLabelPosition var81 = var68.getBasePositiveItemLabelPosition();
    boolean var82 = var65.equals((java.lang.Object)var68);
    java.awt.geom.Rectangle2D var83 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, (-7.8d), 0.0d, var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test201"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Stroke var16 = var11.getTickMarkStroke();
    var0.setBaseOutlineStroke(var16);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
    int var19 = var0.getPassCount();
    java.awt.Paint var21 = var0.lookupSeriesOutlinePaint(1);
    java.awt.Paint var23 = var0.lookupSeriesOutlinePaint(10);
    org.jfree.chart.util.BooleanList var25 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26);
    org.jfree.chart.event.ChartChangeEventType var29 = var28.getType();
    boolean var30 = var25.equals((java.lang.Object)var29);
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var34 = null;
    var33.setPlot(var34);
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var31, var32, (org.jfree.chart.axis.ValueAxis)var33, var36);
    var37.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var43 = null;
    var41.setSeriesItemLabelsVisible(0, var43, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var47 = null;
    var41.setSeriesToolTipGenerator(1, var47, false);
    org.jfree.chart.urls.CategoryURLGenerator var50 = null;
    var41.setBaseURLGenerator(var50);
    java.awt.Graphics2D var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = null;
    org.jfree.chart.axis.ValueAxis var54 = null;
    org.jfree.chart.plot.Marker var55 = null;
    java.awt.geom.Rectangle2D var56 = null;
    var41.drawRangeMarker(var52, var53, var54, var55, var56);
    boolean var59 = var41.isSeriesVisibleInLegend(0);
    var37.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
    boolean var61 = var25.equals((java.lang.Object)var41);
    java.awt.Paint var63 = var41.getSeriesOutlinePaint(1);
    org.jfree.chart.event.RendererChangeEvent var64 = null;
    var41.notifyListeners(var64);
    org.jfree.chart.labels.ItemLabelPosition var66 = var41.getBaseNegativeItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-16777212), var66, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test202"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    java.awt.Shape var16 = var15.getShape();
    org.jfree.data.general.Dataset var17 = null;
    var15.setDataset(var17);
    int var19 = var15.getDatasetIndex();
    java.awt.Shape var20 = var15.getLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test203"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var6.getCategoriesForAxis(var30);
    java.awt.Paint var32 = var6.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var6.getRendererForDataset((org.jfree.data.category.CategoryDataset)var33);
    org.jfree.data.general.PieDataset var36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var33, (java.lang.Comparable)(-1L));
    java.lang.Comparable var37 = null;
    org.jfree.data.general.PieDataset var39 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var36, var37, 3.0d);
    org.jfree.data.general.PieDataset var42 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var39, (java.lang.Comparable)"AxisLocation.TOP_OR_RIGHT", 1.0d);
    org.jfree.data.general.PieDataset var46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var42, (java.lang.Comparable)"-4", 0.0d, (-253));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test204"); }


    java.lang.Comparable var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var2 = null;
    var1.setPlot(var2);
    double var4 = var1.getLowerMargin();
    java.awt.Shape var5 = var1.getDownArrow();
    org.jfree.chart.entity.CategoryLabelEntity var8 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var5, "Size2D[width=0.0, height=NaN]", "-1");
    java.lang.String var9 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "CategoryLabelEntity: category=null, tooltip=Size2D[width=0.0, height=NaN], url=-1"+ "'", var9.equals("CategoryLabelEntity: category=null, tooltip=Size2D[width=0.0, height=NaN], url=-1"));

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test205"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    java.awt.Paint var11 = var0.getErrorIndicatorPaint();
    java.awt.Paint var13 = var0.lookupSeriesOutlinePaint((-10289251));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test206"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    java.util.List var19 = var15.getSubtitles();
    org.jfree.chart.util.RectangleInsets var20 = var15.getPadding();
    org.jfree.chart.plot.CategoryPlot var21 = var15.getCategoryPlot();
    org.jfree.chart.util.SortOrder var22 = var21.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
    float var26 = var25.getTickMarkOutsideLength();
    java.lang.Object var27 = var25.clone();
    var25.setUpperMargin((-1.0d));
    var21.setDomainAxis(0, var25);
    float var31 = var25.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0f);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test207"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var12 = var11.getPadding();
    double var14 = var12.calculateTopInset(100.0d);
    var2.setLabelInsets(var12);
    java.awt.Color var19 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    var2.setTickLabelPaint((java.awt.Paint)var19);
    var2.setNegativeArrowVisible(false);
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.axis.AxisState var25 = new org.jfree.chart.axis.AxisState(0.0d);
    var25.setCursor(100.0d);
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var2.refreshTicks(var23, var25, var28, var29);
    var25.cursorUp(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test208"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, (-1.0d));
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, (-1.0d));
    org.jfree.data.Range var7 = org.jfree.data.Range.combine(var3, var6);
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(0.55d, var6);
    org.jfree.chart.block.RectangleConstraint var10 = var8.toFixedWidth((-5.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test209"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getToolTipText();
    java.lang.String var2 = var0.getText();
    java.awt.Paint var3 = var0.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test210"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    var1.setLegendItemGraphicLocation(var3);
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    org.jfree.chart.LegendItemSource var6 = null;
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var9 = var7.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var5, var9, 0.0d, 2.0d);
    org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var14 = var13.getPadding();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.util.Size2D var19 = var12.arrange(var13, var15, var18);
    var1.setWrapper(var13);
    double var21 = var13.getContentXOffset();
    double var22 = var13.getContentYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test211"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Stroke var16 = var11.getTickMarkStroke();
    var0.setBaseOutlineStroke(var16);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var19 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var20 = var19.getEntityCollection();
    boolean var21 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.labels.ItemLabelAnchor var22 = var18.getItemLabelAnchor();
    org.jfree.chart.ChartRenderingInfo var23 = null;
    org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
    java.lang.Object var25 = var24.clone();
    boolean var26 = var22.equals((java.lang.Object)var24);
    java.awt.geom.Rectangle2D var27 = var24.getPlotArea();
    java.awt.geom.Rectangle2D var28 = var24.getPlotArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test212"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-12.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test213"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var4 = var2.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var0, var4, 0.0d, 2.0d);
    org.jfree.data.general.Dataset var8 = null;
    org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var8, (java.lang.Comparable)Double.NaN);
    org.jfree.data.general.Dataset var11 = var10.getDataset();
    java.lang.String var12 = var10.getToolTipText();
    boolean var13 = var10.isEmpty();
    org.jfree.data.general.Dataset var14 = var10.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test214"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setUpperMargin(1.0E-8d);
    java.awt.Paint var3 = var0.getTickLabelPaint();
    double var4 = var0.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0E-8d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test215"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    var0.setBaseCreateEntities(false, false);
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)false);
    var0.setBaseCreateEntities(false);
    java.awt.Color var25 = java.awt.Color.getColor("", (-1));
    org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(1.0d, 0.05d, 4.0d, 4.0d, (java.awt.Paint)var25);
    boolean var27 = var0.equals((java.lang.Object)0.05d);
    var0.setBaseSeriesVisibleInLegend(false, true);
    var0.setMinimumBarLength(0.2d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var35 = null;
    var33.setSeriesItemLabelsVisible(0, var35, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var39 = null;
    var33.setSeriesToolTipGenerator(1, var39, false);
    org.jfree.chart.urls.CategoryURLGenerator var42 = null;
    var33.setBaseURLGenerator(var42);
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.plot.Marker var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    var33.drawRangeMarker(var44, var45, var46, var47, var48);
    org.jfree.chart.urls.CategoryURLGenerator var50 = null;
    var33.setBaseURLGenerator(var50, true);
    org.jfree.data.statistics.MeanAndStandardDeviation var55 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
    boolean var57 = var55.equals((java.lang.Object)'a');
    boolean var58 = var33.equals((java.lang.Object)var55);
    var33.setSeriesCreateEntities(255, (java.lang.Boolean)true, false);
    var33.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var66 = var33.getSeriesPositiveItemLabelPosition(255);
    var0.setNegativeItemLabelPositionFallback(var66);
    java.awt.Paint var68 = var0.getBasePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test216"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var2 = var0.getWidth();
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.text.TextBlock var5 = new org.jfree.chart.text.TextBlock();
    java.util.List var6 = var5.getLines();
    org.jfree.chart.text.TextLine var7 = null;
    var5.addLine(var7);
    org.jfree.chart.util.HorizontalAlignment var9 = var5.getLineAlignment();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var14 = var12.toFixedWidth(0.05d);
    boolean var15 = var9.equals((java.lang.Object)var14);
    var4.setTextAlignment(var9);
    org.jfree.chart.block.BlockFrame var17 = var4.getFrame();
    java.awt.Font var18 = var4.getFont();
    var0.add((org.jfree.chart.block.Block)var4);
    java.lang.Object var20 = var4.clone();
    var4.setURLText("java.awt.Color[r=255,g=255,b=255]");
    java.awt.Paint var23 = var4.getBackgroundPaint();
    var4.setExpandToFitSpace(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test217"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    var1.setMargin(6.0d, 1.0d, (-1.0d), 2.0d);
    org.jfree.chart.axis.CategoryLabelPositions var7 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var7, var8);
    org.jfree.chart.axis.CategoryLabelPositions var10 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var11 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var12 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var10, var11);
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var7, var11);
    boolean var15 = var13.equals((java.lang.Object)(-8.0d));
    org.jfree.chart.axis.CategoryLabelPositions var16 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var17 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var16, var17);
    org.jfree.chart.axis.CategoryLabelPositions var19 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var19, var20);
    org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
    org.jfree.chart.axis.CategoryLabelPositions var25 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var19, var23);
    org.jfree.chart.axis.CategoryLabelPositions var26 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var18, var23);
    org.jfree.chart.axis.CategoryLabelWidthType var27 = var23.getWidthType();
    org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var30 = var29.getFont();
    boolean var31 = var23.equals((java.lang.Object)var30);
    org.jfree.chart.axis.CategoryLabelPositions var32 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var13, var23);
    org.jfree.chart.LegendItemSource var33 = null;
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
    org.jfree.chart.util.RectangleEdge var35 = var34.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var36 = org.jfree.chart.util.RectangleEdge.opposite(var35);
    boolean var37 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var36);
    org.jfree.chart.axis.CategoryLabelPosition var38 = var32.getLabelPosition(var36);
    boolean var39 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var36);
    var1.setPosition(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test218"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var11 = var10.getNextOutlinePaint();
//     var8.setBackgroundPaint(var11);
//     var6.setOutlinePaint(var11);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var18 = null;
//     var17.setPlot(var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
//     var17.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var17.java2DToValue(0.0d, var25, var26);
//     var17.setAutoTickUnitSelection(true);
//     var17.setUpperMargin(0.0d);
//     org.jfree.chart.LegendItemSource var32 = null;
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
//     org.jfree.chart.util.RectangleInsets var34 = var33.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var35 = var33.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var36 = var33.getItemContainer();
//     org.jfree.chart.LegendItemSource var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getItemLabelPadding();
//     double var41 = var39.calculateTopOutset(4.0d);
//     var36.setMargin(var39);
//     java.awt.geom.Rectangle2D var43 = var36.getBounds();
//     org.jfree.chart.LegendItemSource var44 = null;
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle(var44);
//     org.jfree.chart.util.RectangleInsets var46 = var45.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var47 = var45.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var48 = org.jfree.chart.util.RectangleAnchor.coordinates(var43, var47);
//     var17.setDownArrow((java.awt.Shape)var43);
//     var6.drawBackgroundImage(var14, var43);
//     org.jfree.chart.util.Layer var52 = null;
//     java.util.Collection var53 = var6.getRangeMarkers(4, var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test219"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var6.getCategoriesForAxis(var30);
    java.awt.Font var32 = var6.getNoDataMessageFont();
    java.lang.String var33 = var6.getNoDataMessage();
    org.jfree.chart.LegendItemCollection var34 = var6.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test220"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    boolean var5 = var0.getItemCreateEntity(1, (-1));
    java.awt.Paint var6 = null;
    var0.setErrorIndicatorPaint(var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    java.lang.String var9 = var8.getToolTipText();
    java.lang.String var10 = var8.getText();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    var11.setLowerBound(2.0d);
    var11.centerRange(Double.NaN);
    double var18 = var11.getFixedAutoRange();
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var21 = var20.getFont();
    var11.setLabelFont(var21);
    var8.setFont(var21);
    var0.setBaseItemLabelFont(var21);
    var0.setItemLabelAnchorOffset((-5.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test221"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    boolean var16 = var15.isLineVisible();
    var15.setSeriesKey((java.lang.Comparable)0L);
    boolean var19 = var15.isShapeVisible();
    boolean var20 = var15.isShapeVisible();
    boolean var21 = var15.isLineVisible();
    java.text.AttributedString var22 = var15.getAttributedLabel();
    java.awt.Paint var23 = var15.getOutlinePaint();
    java.lang.String var24 = var15.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + ""+ "'", var24.equals(""));

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test222"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1);
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var6 = null;
    var5.setPlot(var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var3, var4, (org.jfree.chart.axis.ValueAxis)var5, var8);
    var9.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var13 = var9.getDomainAxis();
    int var14 = var9.getWeight();
    boolean var15 = var0.hasListener((java.util.EventListener)var9);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = null;
    var16.setSeriesItemLabelsVisible(0, var18, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var16.setSeriesToolTipGenerator(1, var22, false);
    double var25 = var16.getUpperClip();
    java.awt.Stroke var26 = var16.getBaseStroke();
    java.awt.Shape var29 = var16.getItemShape(4, 10);
    org.jfree.chart.event.RendererChangeEvent var30 = null;
    var16.notifyListeners(var30);
    boolean var33 = var16.isSeriesVisibleInLegend((-123));
    int var34 = var9.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test223"); }


    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var9, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var14 = null;
    var12.setSeriesItemLabelsVisible(0, var14, false);
    java.awt.Stroke var17 = var12.getErrorIndicatorStroke();
    java.awt.Paint var18 = null;
    org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var9, var17, var18);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var21 = var20.getPositiveItemLabelPositionFallback();
    java.awt.Paint var24 = var20.getItemLabelPaint((-123), (-1));
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "Range[-1.0,-1.0]", var9, var24);
    java.awt.Paint var26 = var25.getOutlinePaint();
    java.lang.String var27 = var25.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "CategoryLabelEntity: category=null, tooltip=hi!, url="+ "'", var27.equals("CategoryLabelEntity: category=null, tooltip=hi!, url="));

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test224"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var5 = null;
    var4.setPlot(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var2, var3, (org.jfree.chart.axis.ValueAxis)var4, var7);
    var8.setAnchorValue(0.0d, true);
    boolean var12 = var0.hasListener((java.util.EventListener)var8);
    var0.setAutoRangeMinimumSize(246.39999999999995d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test225"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Size2D[width=0.0, height=NaN]", var1, 2.0f, 100.0f, 6.0d, (-1.0f), 2.0f);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test226"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    var4.clear();
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var10 = null;
    var9.setPlot(var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var8, (org.jfree.chart.axis.ValueAxis)var9, var12);
    org.jfree.chart.LegendItemSource var14 = null;
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
    org.jfree.chart.util.RectangleEdge var16 = var15.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var18 = var17.getNextOutlinePaint();
    var15.setBackgroundPaint(var18);
    var13.setOutlinePaint(var18);
    var13.clearDomainMarkers();
    org.jfree.chart.util.SortOrder var22 = var13.getRowRenderingOrder();
    java.lang.String var23 = var22.toString();
    java.lang.String var24 = var22.toString();
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var26 = null;
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var28 = null;
    var27.setPlot(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var25, var26, (org.jfree.chart.axis.ValueAxis)var27, var30);
    var31.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var37 = null;
    var35.setSeriesItemLabelsVisible(0, var37, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var41 = null;
    var35.setSeriesToolTipGenerator(1, var41, false);
    org.jfree.chart.urls.CategoryURLGenerator var44 = null;
    var35.setBaseURLGenerator(var44);
    java.awt.Graphics2D var46 = null;
    org.jfree.chart.plot.CategoryPlot var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.plot.Marker var49 = null;
    java.awt.geom.Rectangle2D var50 = null;
    var35.drawRangeMarker(var46, var47, var48, var49, var50);
    boolean var53 = var35.isSeriesVisibleInLegend(0);
    var31.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
    org.jfree.chart.axis.CategoryAxis var55 = null;
    java.util.List var56 = var31.getCategoriesForAxis(var55);
    java.awt.Paint var57 = var31.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var58 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var59 = var31.getRendererForDataset((org.jfree.data.category.CategoryDataset)var58);
    org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var58);
    org.jfree.data.general.DatasetChangeEvent var61 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var24, (org.jfree.data.general.Dataset)var58);
    org.jfree.chart.axis.NumberTickUnit var63 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
    org.jfree.chart.title.LegendItemBlockContainer var64 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var58, (java.lang.Comparable)1.0E-8d);
    java.lang.String var65 = var64.getURLText();
    java.lang.String var66 = var64.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "SortOrder.ASCENDING"+ "'", var23.equals("SortOrder.ASCENDING"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "SortOrder.ASCENDING"+ "'", var24.equals("SortOrder.ASCENDING"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test227"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var2.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var2.java2DToValue(0.0d, var10, var11);
//     org.jfree.chart.axis.NumberTickUnit var13 = var2.getTickUnit();
//     java.awt.Paint var14 = var2.getTickLabelPaint();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(2.0f);
//     var2.setLeftArrow(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test228"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    java.awt.image.BufferedImage var20 = var15.createBufferedImage(1, 1);
    var15.fireChartChanged();
    org.jfree.chart.title.Title var23 = var15.getSubtitle(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test229"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Stroke var16 = var11.getTickMarkStroke();
    var0.setBaseOutlineStroke(var16);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
    int var19 = var0.getPassCount();
    double var20 = var0.getUpperClip();
    boolean var21 = var0.getAutoPopulateSeriesOutlineStroke();
    var0.setBaseSeriesVisible(true);
    java.lang.Boolean var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-5658199), var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test230"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    java.lang.String var5 = var0.getLabelToolTip();
    boolean var6 = var0.isNegativeArrowVisible();
    org.jfree.data.Range var7 = var0.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    boolean var9 = var8.isNegativeArrowVisible();
    java.lang.String var10 = var8.getLabelURL();
    var8.setLabelAngle(6.0d);
    float var13 = var8.getTickMarkOutsideLength();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var15 = null;
    var14.setPlot(var15);
    var14.setLowerBound(2.0d);
    java.lang.String var19 = var14.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var20 = var14.getTickUnit();
    int var21 = var20.getMinorTickCount();
    var8.setTickUnit(var20, true, true);
    org.jfree.data.Range var25 = var8.getRange();
    org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var7, var25);
    double var27 = var7.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.5d);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test231"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var3 = null;
//     var1.setSeriesItemLabelsVisible(0, var3, false);
//     java.awt.Stroke var6 = var1.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var7 = var1.getDrawingSupplier();
//     java.lang.Boolean var9 = var1.getSeriesCreateEntities(10);
//     java.awt.Paint var10 = var1.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var14 = var12.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var12.getBaseURLGenerator();
//     java.lang.Boolean var20 = var12.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var23 = java.awt.Color.getColor("", (-1));
//     var12.setBasePaint((java.awt.Paint)var23, true);
//     var1.setSeriesPaint(0, (java.awt.Paint)var23, false);
//     int var28 = var23.getRGB();
//     org.jfree.chart.LegendItemSource var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
//     org.jfree.chart.util.RectangleEdge var31 = var30.getLegendItemGraphicEdge();
//     java.awt.Paint var32 = var30.getItemPaint();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var37 = null;
//     var36.setPlot(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var34, var35, (org.jfree.chart.axis.ValueAxis)var36, var39);
//     org.jfree.chart.LegendItemSource var41 = null;
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle(var41);
//     org.jfree.chart.util.RectangleEdge var43 = var42.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var45 = var44.getNextOutlinePaint();
//     var42.setBackgroundPaint(var45);
//     var40.setOutlinePaint(var45);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var40);
//     var48.fireChartChanged();
//     boolean var50 = var48.getAntiAlias();
//     java.util.List var51 = var48.getSubtitles();
//     var30.addChangeListener((org.jfree.chart.event.TitleChangeListener)var48);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var56 = null;
//     var55.setPlot(var56);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var55, var58);
//     var55.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var55.java2DToValue(0.0d, var63, var64);
//     var55.setAutoTickUnitSelection(true);
//     java.awt.Stroke var68 = var55.getAxisLineStroke();
//     var48.setBorderStroke(var68);
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(Double.NaN, (java.awt.Paint)var23, var68);
//     java.awt.Paint var71 = var70.getPaint();
//     org.jfree.chart.util.RectangleAnchor var72 = var70.getLabelAnchor();
//     java.awt.Paint var73 = var70.getOutlinePaint();
//     java.awt.Stroke var74 = var70.getOutlineStroke();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test232"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setMaximumCategoryLabelWidthRatio(0.95f);
    double var3 = var0.getLowerMargin();
    java.lang.Object var4 = var0.clone();
    java.awt.Font var6 = var0.getTickLabelFont((java.lang.Comparable)"null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    int var7 = var0.getCategoryLabelPositionOffset();
    java.awt.Font var9 = var0.getTickLabelFont((java.lang.Comparable)2.0f);
    var0.addCategoryLabelToolTip((java.lang.Comparable)"RectangleAnchor.CENTER", "CategoryLabelWidthType.CATEGORY");
    var0.setLowerMargin((-8.0d));
    double var15 = var0.getCategoryMargin();
    var0.setMaximumCategoryLabelWidthRatio(2.0f);
    float var18 = var0.getMaximumCategoryLabelWidthRatio();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var21 = null;
    var19.setSeriesItemLabelsVisible(0, var21, false);
    java.awt.Stroke var24 = var19.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var25 = var19.getDrawingSupplier();
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity(var28, "Range[-1.0,-1.0]");
    var19.setSeriesShape(10, var28);
    org.jfree.chart.entity.TickLabelEntity var34 = new org.jfree.chart.entity.TickLabelEntity(var28, "CategoryLabelWidthType.CATEGORY", "Size2D[width=0.0, height=-1.0]");
    org.jfree.chart.entity.AxisLabelEntity var37 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var28, "-8", "CategoryLabelWidthType.CATEGORY");
    org.jfree.chart.axis.Axis var38 = var37.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test233"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var25 = var24.getFont();
    java.awt.Color var29 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var25, (java.awt.Paint)var29);
    java.awt.Color var31 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var29);
    var19.setDomainGridlinePaint((java.awt.Paint)var29);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.NumberTickUnit var39 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
    var34.add((java.lang.Number)(-1.0d), (java.lang.Number)(-855310), (java.lang.Comparable)0.05d, (java.lang.Comparable)1.0E-8d);
    var19.setDataset(100, (org.jfree.data.category.CategoryDataset)var34);
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = var19.getRenderer((-16777212));
    org.jfree.chart.util.SortOrder var44 = var19.getColumnRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test234"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtTop();
    java.util.List var2 = var0.getAxesAtLeft();
    org.jfree.chart.axis.Axis var3 = null;
    org.jfree.chart.LegendItemSource var4 = null;
    org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle(var4);
    org.jfree.chart.util.RectangleInsets var6 = var5.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var7 = var5.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var8 = var5.getItemContainer();
    org.jfree.chart.LegendItemSource var9 = null;
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getItemLabelPadding();
    double var13 = var11.calculateTopOutset(4.0d);
    var8.setMargin(var11);
    java.awt.geom.Rectangle2D var15 = var8.getBounds();
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var19 = var17.getLegendItemGraphicLocation();
    java.awt.geom.Point2D var20 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var19);
    org.jfree.chart.LegendItemSource var21 = null;
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
    org.jfree.chart.util.RectangleEdge var23 = var22.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var25 = var24.getNextOutlinePaint();
    var22.setBackgroundPaint(var25);
    org.jfree.chart.text.TextBlock var27 = new org.jfree.chart.text.TextBlock();
    java.util.List var28 = var27.getLines();
    boolean var29 = var22.equals((java.lang.Object)var27);
    org.jfree.chart.util.RectangleEdge var30 = var22.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var31 = org.jfree.chart.util.RectangleEdge.opposite(var30);
    double var32 = org.jfree.chart.util.RectangleEdge.coordinate(var15, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var3, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test235"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(2.0d);
    org.jfree.chart.LegendItemSource var3 = null;
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
    org.jfree.chart.util.RectangleEdge var5 = var4.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var7 = var6.getNextOutlinePaint();
    var4.setBackgroundPaint(var7);
    org.jfree.chart.text.TextBlock var9 = new org.jfree.chart.text.TextBlock();
    java.util.List var10 = var9.getLines();
    boolean var11 = var4.equals((java.lang.Object)var9);
    org.jfree.chart.util.RectangleEdge var12 = var4.getLegendItemGraphicEdge();
    var1.moveCursor(2.0d, var12);
    boolean var14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test236"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
    org.jfree.chart.util.RectangleInsets var7 = var6.getItemLabelPadding();
    double var8 = var7.getTop();
    var3.setPadding(var7);
    org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D();
    boolean var12 = var10.equals((java.lang.Object)(-1L));
    double var13 = var10.getWidth();
    double var14 = var10.getHeight();
    org.jfree.chart.util.RectangleAnchor var17 = null;
    java.awt.geom.Rectangle2D var18 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, 2.0d, (-1.0d), var17);
    org.jfree.chart.axis.CategoryLabelPositions var21 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var22 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var23 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var21, var22);
    org.jfree.chart.util.RectangleAnchor var24 = var22.getCategoryAnchor();
    java.awt.geom.Rectangle2D var25 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, 2.0d, 1.0d, var24);
    java.awt.geom.Rectangle2D var26 = var7.createOutsetRectangle(var25);
    var0.setRightArrow((java.awt.Shape)var26);
    java.awt.Paint var28 = var0.getTickMarkPaint();
    var0.setTickMarkInsideLength(0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test237"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
    var0.setBaseItemLabelGenerator(var11);
    double var13 = var0.getMaximumBarWidth();
    java.lang.Boolean var15 = var0.getSeriesCreateEntities((-621738));
    java.awt.Paint var17 = var0.getSeriesOutlinePaint((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test238"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    java.lang.String var5 = var0.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var6 = var0.getTickUnit();
    org.jfree.data.Range var7 = var0.getRange();
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var20 = var19.getNextOutlinePaint();
    var17.setBackgroundPaint(var20);
    var15.setOutlinePaint(var20);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
    var23.fireChartChanged();
    var23.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var27 = var23.getCategoryPlot();
    var27.clearRangeAxes();
    org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var30 = var29.clone();
    org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
    var29.ensureAtLeast(var31);
    double var33 = var31.getTop();
    var27.setFixedRangeAxisSpace(var31);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var27);
    org.jfree.chart.plot.DatasetRenderingOrder var36 = var27.getDatasetRenderingOrder();
    java.lang.String var37 = var36.toString();
    java.lang.String var38 = var36.toString();
    java.lang.String var39 = var36.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var37.equals("DatasetRenderingOrder.REVERSE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var38.equals("DatasetRenderingOrder.REVERSE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var39.equals("DatasetRenderingOrder.REVERSE"));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test239"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
    org.jfree.chart.axis.CategoryLabelPosition var3 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextAnchor var4 = var3.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var2, var3);
    org.jfree.chart.axis.CategoryLabelPositions var6 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var8 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var6, var7);
    float var9 = var7.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var10 = var7.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var2, var7);
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    java.awt.Paint var15 = var13.getItemPaint();
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var20 = null;
    var19.setPlot(var20);
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var17, var18, (org.jfree.chart.axis.ValueAxis)var19, var22);
    org.jfree.chart.LegendItemSource var24 = null;
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
    org.jfree.chart.util.RectangleEdge var26 = var25.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var28 = var27.getNextOutlinePaint();
    var25.setBackgroundPaint(var28);
    var23.setOutlinePaint(var28);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var23);
    var31.fireChartChanged();
    boolean var33 = var31.getAntiAlias();
    java.util.List var34 = var31.getSubtitles();
    var13.addChangeListener((org.jfree.chart.event.TitleChangeListener)var31);
    boolean var36 = var2.equals((java.lang.Object)var31);
    org.jfree.chart.plot.Plot var37 = var31.getPlot();
    java.lang.Object var38 = var31.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test240"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getPositiveItemLabelPositionFallback();
    java.awt.Shape var2 = var0.getBaseShape();
    double var3 = var0.getLowerClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test241"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var6 = null;
    var5.setPlot(var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var3, var4, (org.jfree.chart.axis.ValueAxis)var5, var8);
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleEdge var12 = var11.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var14 = var13.getNextOutlinePaint();
    var11.setBackgroundPaint(var14);
    var9.setOutlinePaint(var14);
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var9);
    var17.fireChartChanged();
    boolean var19 = var17.getAntiAlias();
    java.awt.Image var20 = var17.getBackgroundImage();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var17.removeProgressListener(var21);
    boolean var23 = var1.equals((java.lang.Object)var17);
    var17.setBorderVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test242"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("Range[-1.0,-1.0]");
    var1.setFixedDimension(0.05d);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var7 = null;
    var6.setPlot(var7);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
    org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var15 = var14.getNextOutlinePaint();
    var12.setBackgroundPaint(var15);
    var10.setOutlinePaint(var15);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var21 = null;
    var20.setPlot(var21);
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var26 = null;
    var25.setPlot(var26);
    org.jfree.chart.axis.ValueAxis[] var28 = new org.jfree.chart.axis.ValueAxis[] { var25};
    var24.setRangeAxes(var28);
    var10.setParent((org.jfree.chart.plot.Plot)var24);
    var24.setRangeCrosshairValue(10.0d, false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var35 = var34.getPositiveItemLabelPositionFallback();
    java.awt.Paint var38 = var34.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var40 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var42 = null;
    var41.setPlot(var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var40, (org.jfree.chart.axis.ValueAxis)var41, var44);
    java.awt.Stroke var46 = var41.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var47 = null;
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle(var47);
    org.jfree.chart.util.RectangleInsets var49 = var48.getItemLabelPadding();
    double var50 = var49.getTop();
    org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder(var38, var46, var49);
    java.awt.Stroke var52 = var51.getStroke();
    java.awt.Stroke var53 = var51.getStroke();
    var24.setOutlineStroke(var53);
    var24.clearRangeMarkers();
    org.jfree.data.category.CategoryDataset var56 = null;
    org.jfree.chart.axis.CategoryAxis var57 = null;
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var59 = null;
    var58.setPlot(var59);
    org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
    org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var56, var57, (org.jfree.chart.axis.ValueAxis)var58, var61);
    var62.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var66 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var68 = null;
    var66.setSeriesItemLabelsVisible(0, var68, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var72 = null;
    var66.setSeriesToolTipGenerator(1, var72, false);
    org.jfree.chart.urls.CategoryURLGenerator var75 = null;
    var66.setBaseURLGenerator(var75);
    java.awt.Graphics2D var77 = null;
    org.jfree.chart.plot.CategoryPlot var78 = null;
    org.jfree.chart.axis.ValueAxis var79 = null;
    org.jfree.chart.plot.Marker var80 = null;
    java.awt.geom.Rectangle2D var81 = null;
    var66.drawRangeMarker(var77, var78, var79, var80, var81);
    boolean var84 = var66.isSeriesVisibleInLegend(0);
    var62.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var66);
    org.jfree.chart.util.Layer var87 = null;
    java.util.Collection var88 = var62.getDomainMarkers(10, var87);
    org.jfree.chart.axis.AxisLocation var90 = var62.getDomainAxisLocation((-1));
    java.lang.String var91 = var90.toString();
    boolean var93 = var90.equals((java.lang.Object)(short)1);
    org.jfree.chart.axis.AxisLocation var94 = var90.getOpposite();
    var24.setDomainAxisLocation(var94, true);
    boolean var97 = var1.equals((java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var91 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var91.equals("AxisLocation.TOP_OR_RIGHT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test243"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.util.HorizontalAlignment var6 = var1.getHorizontalAlignment();
    org.jfree.chart.block.BlockContainer var7 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleInsets var10 = var9.getItemLabelPadding();
    double var11 = var10.getTop();
    double var13 = var10.trimWidth(10.0d);
    var7.setMargin(var10);
    var1.setLegendItemGraphicPadding(var10);
    double var17 = var10.extendWidth((-1.0d));
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var21 = null;
    var20.setPlot(var21);
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
    var24.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var28 = var24.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var29 = var24.getRangeAxisEdge();
    java.awt.Color var36 = java.awt.Color.getColor("", (-1));
    org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder((-8.0d), (-1.0d), (-8.0d), 0.0d, (java.awt.Paint)var36);
    var24.setDomainGridlinePaint((java.awt.Paint)var36);
    org.jfree.chart.block.BlockBorder var39 = new org.jfree.chart.block.BlockBorder(var10, (java.awt.Paint)var36);
    java.lang.String var40 = var36.toString();
    int var41 = var36.getTransparency();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "java.awt.Color[r=255,g=255,b=255]"+ "'", var40.equals("java.awt.Color[r=255,g=255,b=255]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test244"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, (-1.0d));
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var0, 10.0d);
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var0, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var7 = var6.getWidthConstraintType();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, (-1.0d));
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, (-1.0d));
    org.jfree.data.Range var14 = org.jfree.data.Range.combine(var10, var13);
    double var15 = var14.getLength();
    boolean var17 = var14.contains(0.0d);
    boolean var18 = var7.equals((java.lang.Object)var14);
    boolean var20 = var14.contains(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test245"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var0.drawRangeMarker(var11, var12, var13, var14, var15);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var0.setBaseURLGenerator(var17, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var22 = null;
    var20.setSeriesItemLabelsVisible(0, var22, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var26 = null;
    var20.setSeriesToolTipGenerator(1, var26, false);
    org.jfree.chart.urls.CategoryURLGenerator var29 = null;
    var20.setBaseURLGenerator(var29);
    var20.setBaseCreateEntities(false, false);
    var20.setBaseSeriesVisibleInLegend(false);
    var20.setBaseItemLabelsVisible(true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var41 = var39.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var44 = var39.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var45 = var39.getBaseURLGenerator();
    java.lang.Boolean var47 = var39.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var48 = null;
    org.jfree.chart.axis.CategoryAxis var49 = null;
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var51 = null;
    var50.setPlot(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var48, var49, (org.jfree.chart.axis.ValueAxis)var50, var53);
    java.awt.Stroke var55 = var50.getTickMarkStroke();
    var39.setBaseOutlineStroke(var55);
    org.jfree.chart.labels.ItemLabelPosition var57 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var58 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var59 = var58.getEntityCollection();
    boolean var60 = var57.equals((java.lang.Object)var58);
    var20.setSeriesPositiveItemLabelPosition(0, var57);
    var0.setPositiveItemLabelPositionFallback(var57);
    java.awt.Paint var63 = var0.getBasePaint();
    boolean var65 = var0.isSeriesVisible(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test246"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var4 = var2.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var0, var4, 0.0d, 2.0d);
    org.jfree.data.general.Dataset var8 = null;
    org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var8, (java.lang.Comparable)Double.NaN);
    org.jfree.data.general.Dataset var11 = var10.getDataset();
    org.jfree.chart.block.Arrangement var12 = var10.getArrangement();
    var10.setURLText("Size2D[width=0.0, height=-1.0]");
    org.jfree.chart.block.Block var15 = null;
    var10.add(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test247"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.zoomRange((-1.0d), 100.0d);
    boolean var11 = var2.isTickLabelsVisible();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var13 = null;
    var12.setPlot(var13);
    var12.setLowerBound(2.0d);
    java.lang.String var17 = var12.getLabelToolTip();
    java.awt.Shape var18 = var12.getRightArrow();
    org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity(var18);
    var2.setDownArrow(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test248"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var6.getCategoriesForAxis(var30);
    java.awt.Font var32 = var6.getNoDataMessageFont();
    java.lang.String var33 = var6.getNoDataMessage();
    org.jfree.chart.axis.AxisLocation var35 = var6.getRangeAxisLocation(100);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var38 = null;
    var36.setSeriesItemLabelsVisible(0, var38, false);
    java.awt.Stroke var41 = var36.getErrorIndicatorStroke();
    boolean var42 = var36.getBaseSeriesVisible();
    var36.setAutoPopulateSeriesPaint(false);
    var36.setSeriesItemLabelsVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.urls.CategoryURLGenerator var48 = null;
    var36.setBaseURLGenerator(var48);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var50 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var52 = null;
    var50.setSeriesItemLabelsVisible(0, var52, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var56 = null;
    var50.setSeriesToolTipGenerator(1, var56, false);
    org.jfree.chart.urls.CategoryURLGenerator var59 = null;
    var50.setBaseURLGenerator(var59);
    java.awt.Graphics2D var61 = null;
    org.jfree.chart.plot.CategoryPlot var62 = null;
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.plot.Marker var64 = null;
    java.awt.geom.Rectangle2D var65 = null;
    var50.drawRangeMarker(var61, var62, var63, var64, var65);
    org.jfree.chart.urls.CategoryURLGenerator var67 = null;
    var50.setBaseURLGenerator(var67, true);
    org.jfree.data.statistics.MeanAndStandardDeviation var72 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
    boolean var74 = var72.equals((java.lang.Object)'a');
    boolean var75 = var50.equals((java.lang.Object)var72);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var76 = var50.getLegendItemURLGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var79 = var50.getURLGenerator(10, (-1));
    org.jfree.data.category.CategoryDataset var80 = null;
    org.jfree.chart.axis.CategoryAxis var81 = null;
    org.jfree.chart.axis.NumberAxis var82 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var83 = null;
    var82.setPlot(var83);
    org.jfree.chart.renderer.category.CategoryItemRenderer var85 = null;
    org.jfree.chart.plot.CategoryPlot var86 = new org.jfree.chart.plot.CategoryPlot(var80, var81, (org.jfree.chart.axis.ValueAxis)var82, var85);
    var86.setAnchorValue(0.0d, true);
    org.jfree.chart.util.RectangleInsets var90 = var86.getAxisOffset();
    java.awt.Paint var91 = var86.getBackgroundPaint();
    var50.setBasePaint(var91);
    var36.setBaseItemLabelPaint(var91, true);
    boolean var95 = var35.equals((java.lang.Object)var36);
    java.lang.String var96 = var35.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var96 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT"+ "'", var96.equals("AxisLocation.BOTTOM_OR_RIGHT"));

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test249"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    boolean var16 = var15.isLineVisible();
    var15.setSeriesKey((java.lang.Comparable)0L);
    boolean var19 = var15.isShapeVisible();
    boolean var20 = var15.isShapeVisible();
    boolean var21 = var15.isLineVisible();
    java.lang.String var22 = var15.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + ""+ "'", var22.equals(""));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test250"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.5f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test251"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Comparable var3 = null;
    var0.add((java.lang.Number)(short)0, (java.lang.Number)2.0d, var3, (java.lang.Comparable)"RectangleAnchor.CENTER");
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, (-0.55d));
    int var11 = var0.getRowIndex((java.lang.Comparable)1.0E-8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var0.getStdDevValue(3, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test252"); }
// 
// 
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.util.RectangleEdge var3 = var2.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var5 = var4.getNextOutlinePaint();
//     var2.setBackgroundPaint(var5);
//     org.jfree.chart.util.HorizontalAlignment var7 = var2.getHorizontalAlignment();
//     double var8 = var2.getHeight();
//     java.awt.Font var9 = var2.getItemFont();
//     java.awt.Color var12 = java.awt.Color.getColor("", (-1));
//     float[] var13 = null;
//     float[] var14 = var12.getRGBComponents(var13);
//     int var15 = var12.getRed();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.text.G2TextMeasurer var18 = new org.jfree.chart.text.G2TextMeasurer(var17);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("GradientPaintTransformType.VERTICAL", var9, (java.awt.Paint)var12, 1.0f, (org.jfree.chart.text.TextMeasurer)var18);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test253"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    boolean var5 = var0.equals((java.lang.Object)var4);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var8, var11);
    var12.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = null;
    var16.setSeriesItemLabelsVisible(0, var18, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var16.setSeriesToolTipGenerator(1, var22, false);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var16.setBaseURLGenerator(var25);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.plot.Marker var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    var16.drawRangeMarker(var27, var28, var29, var30, var31);
    boolean var34 = var16.isSeriesVisibleInLegend(0);
    var12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    boolean var36 = var0.equals((java.lang.Object)var16);
    int var37 = var0.size();
    var0.setBoolean(0, (java.lang.Boolean)false);
    java.lang.Boolean var42 = var0.getBoolean(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test254"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    double var3 = var0.getLowerMargin();
    java.awt.Shape var4 = var0.getDownArrow();
    org.jfree.data.KeyedObjects var5 = new org.jfree.data.KeyedObjects();
    java.lang.Object var7 = null;
    var5.addObject((java.lang.Comparable)'#', var7);
    org.jfree.data.KeyedObjects2D var10 = new org.jfree.data.KeyedObjects2D();
    java.util.List var11 = var10.getColumnKeys();
    java.lang.Object var14 = var10.getObject((java.lang.Comparable)(-1), (java.lang.Comparable)0L);
    java.util.List var15 = var10.getColumnKeys();
    org.jfree.data.KeyedObject var16 = new org.jfree.data.KeyedObject((java.lang.Comparable)100.0d, (java.lang.Object)var10);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var18 = null;
    var17.setPlot(var18);
    var17.setLowerBound(2.0d);
    java.lang.String var22 = var17.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var23 = var17.getTickUnit();
    java.lang.Comparable var24 = null;
    java.lang.Object var25 = var10.getObject((java.lang.Comparable)var23, var24);
    java.lang.Object var26 = var5.getObject((java.lang.Comparable)var23);
    var0.setTickUnit(var23, false, false);
    java.lang.Object var30 = var0.clone();
    var0.setUpperMargin(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test255"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("CategoryLabelEntity: category=[size=1], tooltip=TextAnchor.CENTER, url=Size2D[width=0.0, height=-1.0]", var1);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test256"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "DatasetRenderingOrder.REVERSE", "RectangleConstraintType.RANGE");
    java.lang.Object var5 = var4.clone();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity(var11, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var16 = null;
    var14.setSeriesItemLabelsVisible(0, var16, false);
    java.awt.Stroke var19 = var14.getErrorIndicatorStroke();
    java.awt.Paint var20 = null;
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var11, var19, var20);
    boolean var22 = var21.isLineVisible();
    java.awt.Paint var23 = var21.getFillPaint();
    java.awt.Shape var24 = var21.getLine();
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
    var4.setArea(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test257"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.LegendItemSource var6 = null;
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getItemLabelPadding();
    var1.setItemLabelPadding(var8);
    java.lang.Object var10 = var1.clone();
    java.awt.Paint var11 = var1.getItemPaint();
    org.jfree.chart.block.CenterArrangement var12 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.LegendItemSource var13 = null;
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
    org.jfree.chart.util.RectangleEdge var15 = var14.getLegendItemGraphicEdge();
    java.awt.Paint var16 = var14.getItemPaint();
    var14.setNotify(true);
    org.jfree.chart.axis.AxisSpace var19 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.LegendItemSource var21 = null;
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
    org.jfree.chart.util.RectangleEdge var23 = var22.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var24 = org.jfree.chart.util.RectangleEdge.opposite(var23);
    var19.ensureAtLeast(100.0d, var24);
    var14.setPosition(var24);
    org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer();
    java.util.List var28 = var27.getBlocks();
    org.jfree.chart.block.BlockFrame var29 = var27.getFrame();
    var14.setWrapper(var27);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
    var31.setMaximumCategoryLabelWidthRatio(0.95f);
    java.awt.Color var36 = java.awt.Color.getColor("AxisLocation.TOP_OR_RIGHT", (-1));
    var31.setAxisLinePaint((java.awt.Paint)var36);
    java.lang.String var38 = var36.toString();
    var12.add((org.jfree.chart.block.Block)var27, (java.lang.Object)var38);
    var1.setWrapper(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "java.awt.Color[r=255,g=255,b=255]"+ "'", var38.equals("java.awt.Color[r=255,g=255,b=255]"));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test258"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Comparable var3 = null;
    var0.add((java.lang.Number)(short)0, (java.lang.Number)2.0d, var3, (java.lang.Comparable)"RectangleAnchor.CENTER");
    org.jfree.data.general.DatasetGroup var6 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    boolean var10 = var6.equals((java.lang.Object)var8);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var14 = null;
    var13.setPlot(var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var11, var12, (org.jfree.chart.axis.ValueAxis)var13, var16);
    boolean var18 = var17.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var20 = var17.getDataset((-123));
    var17.clearRangeMarkers(0);
    java.awt.Paint var23 = var17.getBackgroundPaint();
    var17.setAnchorValue((-1.0d));
    org.jfree.chart.util.RectangleEdge var27 = var17.getRangeAxisEdge((-855310));
    boolean var28 = var6.equals((java.lang.Object)var17);
    var0.setGroup(var6);
    java.util.List var30 = var0.getRowKeys();
    org.jfree.data.Range var32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 2.0d);
    org.jfree.data.Range var34 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var39 = null;
    var38.setPlot(var39);
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var36, var37, (org.jfree.chart.axis.ValueAxis)var38, var41);
    org.jfree.chart.LegendItemSource var43 = null;
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle(var43);
    org.jfree.chart.util.RectangleEdge var45 = var44.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var47 = var46.getNextOutlinePaint();
    var44.setBackgroundPaint(var47);
    var42.setOutlinePaint(var47);
    org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var42);
    var50.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var52 = var50.getCategoryPlot();
    org.jfree.chart.util.RectangleInsets var53 = var50.getPadding();
    boolean var54 = var34.equals((java.lang.Object)var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test259"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.renderer.category.CategoryItemRendererState var3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var1);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var7 = null;
    var6.setPlot(var7);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
    org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var15 = var14.getNextOutlinePaint();
    var12.setBackgroundPaint(var15);
    var10.setOutlinePaint(var15);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    org.jfree.chart.LegendItemSource var21 = null;
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
    org.jfree.chart.util.RectangleInsets var23 = var22.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var24 = var22.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var25 = var22.getItemContainer();
    org.jfree.chart.LegendItemSource var26 = null;
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle(var26);
    org.jfree.chart.util.RectangleInsets var28 = var27.getItemLabelPadding();
    double var30 = var28.calculateTopOutset(4.0d);
    var25.setMargin(var28);
    java.awt.geom.Rectangle2D var32 = var25.getBounds();
    org.jfree.chart.LegendItemSource var33 = null;
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
    org.jfree.chart.util.RectangleInsets var35 = var34.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var36 = var34.getLegendItemGraphicLocation();
    java.awt.geom.Point2D var37 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var36);
    var10.zoomRangeAxes((-5.0d), 0.2d, var20, var37);
    int var39 = var1.getSubplotIndex(var37);
    java.awt.geom.Rectangle2D var40 = var1.getPlotArea();
    org.jfree.chart.ChartRenderingInfo var41 = var1.getOwner();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test260"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    java.awt.Paint var11 = var0.getErrorIndicatorPaint();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var15 = null;
    var14.setPlot(var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
    org.jfree.chart.LegendItemSource var19 = null;
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var23 = var22.getNextOutlinePaint();
    var20.setBackgroundPaint(var23);
    var18.setOutlinePaint(var23);
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var29 = null;
    var28.setPlot(var29);
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var26, var27, (org.jfree.chart.axis.ValueAxis)var28, var31);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var34 = null;
    var33.setPlot(var34);
    org.jfree.chart.axis.ValueAxis[] var36 = new org.jfree.chart.axis.ValueAxis[] { var33};
    var32.setRangeAxes(var36);
    var18.setParent((org.jfree.chart.plot.Plot)var32);
    java.awt.Stroke var39 = var32.getRangeCrosshairStroke();
    var0.setBaseOutlineStroke(var39, true);
    java.awt.Shape var42 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
    var0.setBaseToolTipGenerator(var43, true);
    java.awt.Font var46 = var0.getBaseItemLabelFont();
    org.jfree.chart.labels.CategoryItemLabelGenerator var47 = null;
    var0.setBaseItemLabelGenerator(var47, false);
    var0.setAutoPopulateSeriesFillPaint(true);
    java.awt.Paint var53 = null;
    var0.setSeriesOutlinePaint(255, var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test261"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    boolean var3 = var1.equals((java.lang.Object)' ');
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    boolean var5 = var4.isNegativeArrowVisible();
    java.lang.String var6 = var4.getLabelURL();
    var4.setLabelAngle(6.0d);
    var4.setAutoRange(false);
    java.awt.Font var11 = var4.getTickLabelFont();
    var1.setFont(var11);
    org.jfree.chart.event.ChartChangeEvent var13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.JFreeChart var14 = var13.getChart();
    org.jfree.chart.util.StandardGradientPaintTransformer var15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15);
    org.jfree.chart.event.ChartChangeEventType var18 = var17.getType();
    java.lang.Object var19 = null;
    boolean var20 = var18.equals(var19);
    java.lang.String var21 = var18.toString();
    var13.setType(var18);
    java.lang.Object var23 = null;
    boolean var24 = var18.equals(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var21.equals("ChartChangeEventType.GENERAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test262"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var25 = var24.getFont();
    java.awt.Color var29 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var25, (java.awt.Paint)var29);
    java.awt.Color var31 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var29);
    var19.setDomainGridlinePaint((java.awt.Paint)var29);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.NumberTickUnit var39 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
    var34.add((java.lang.Number)(-1.0d), (java.lang.Number)(-855310), (java.lang.Comparable)0.05d, (java.lang.Comparable)1.0E-8d);
    var19.setDataset(100, (org.jfree.data.category.CategoryDataset)var34);
    var34.add(100.0d, 2.0d, (java.lang.Comparable)0L, (java.lang.Comparable)(-253));
    java.util.List var47 = var34.getRowKeys();
    java.lang.Number var48 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var34);
    org.jfree.chart.axis.TickUnits var51 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var52 = var51.clone();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
    boolean var54 = var53.isNegativeArrowVisible();
    java.lang.String var55 = var53.getLabelURL();
    var53.setLabelAngle(6.0d);
    float var58 = var53.getTickMarkOutsideLength();
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var60 = null;
    var59.setPlot(var60);
    var59.setLowerBound(2.0d);
    java.lang.String var64 = var59.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var65 = var59.getTickUnit();
    int var66 = var65.getMinorTickCount();
    var53.setTickUnit(var65, true, true);
    var51.add((org.jfree.chart.axis.TickUnit)var65);
    var34.add(1.0E-8d, (-8.0d), (java.lang.Comparable)var65, (java.lang.Comparable)"SortOrder.ASCENDING");
    int var73 = var65.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + (-1.0d)+ "'", var48.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test263"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
    org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var3, var4);
    org.jfree.chart.axis.CategoryLabelPositions var6 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var8 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var6, var7);
    org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var3, var7);
    org.jfree.chart.axis.CategoryLabelPositions var10 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var2, var7);
    org.jfree.chart.axis.CategoryLabelWidthType var11 = var7.getWidthType();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var16 = null;
    var15.setPlot(var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
    org.jfree.chart.LegendItemSource var20 = null;
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle(var20);
    org.jfree.chart.util.RectangleEdge var22 = var21.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var24 = var23.getNextOutlinePaint();
    var21.setBackgroundPaint(var24);
    var19.setOutlinePaint(var24);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var19);
    var27.fireChartChanged();
    var27.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var31 = var27.getCategoryPlot();
    int var32 = var27.getSubtitleCount();
    boolean var33 = var11.equals((java.lang.Object)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test264"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
    double var18 = var17.getTop();
    var13.setPadding(var17);
    org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D();
    boolean var22 = var20.equals((java.lang.Object)(-1L));
    double var23 = var20.getWidth();
    double var24 = var20.getHeight();
    org.jfree.chart.util.RectangleAnchor var27 = null;
    java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, (-1.0d), var27);
    org.jfree.chart.axis.CategoryLabelPositions var31 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var31, var32);
    org.jfree.chart.util.RectangleAnchor var34 = var32.getCategoryAnchor();
    java.awt.geom.Rectangle2D var35 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, 1.0d, var34);
    java.awt.geom.Rectangle2D var36 = var17.createOutsetRectangle(var35);
    java.awt.geom.Point2D var37 = null;
    org.jfree.chart.plot.PlotState var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    var6.draw(var11, var36, var37, var38, var39);
    boolean var41 = var6.isRangeCrosshairLockedOnData();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var44 = var42.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var47 = var42.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var48 = var42.getBaseURLGenerator();
    java.lang.Boolean var50 = var42.getSeriesItemLabelsVisible((-855310));
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var51 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var42};
    var6.setRenderers(var51);
    var6.setNoDataMessage("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.plot.DatasetRenderingOrder var55 = var6.getDatasetRenderingOrder();
    org.jfree.chart.event.PlotChangeEvent var56 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis();
    var57.setMaximumCategoryLabelWidthRatio(0.95f);
    double var60 = var57.getLowerMargin();
    java.lang.Object var61 = var57.clone();
    java.awt.Font var63 = var57.getTickLabelFont((java.lang.Comparable)"null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    java.awt.Color var67 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    var57.setTickMarkPaint((java.awt.Paint)var67);
    var6.setDomainAxis(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test265"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var2.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var2.java2DToValue(0.0d, var10, var11);
//     var2.setAutoTickUnitSelection(true);
//     org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo();
//     var15.setInfo("");
//     java.lang.String var18 = var15.getLicenceText();
//     java.lang.String var19 = var15.getCopyright();
//     var15.setInfo("hi!");
//     boolean var22 = var2.equals((java.lang.Object)"hi!");
//     double var23 = var2.getAutoRangeMinimumSize();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2.0d);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test266"); }


    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var3 = var2.getFont();
    java.awt.Color var7 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var3, (java.awt.Paint)var7);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var11 = null;
    var9.setSeriesItemLabelsVisible(0, var11, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
    var9.setSeriesToolTipGenerator(1, var15, false);
    double var18 = var9.getUpperClip();
    java.awt.Stroke var19 = var9.getBaseStroke();
    java.awt.Shape var22 = var9.getItemShape(4, 10);
    org.jfree.chart.event.RendererChangeEvent var23 = null;
    var9.notifyListeners(var23);
    boolean var26 = var9.isSeriesVisibleInLegend((-123));
    boolean var27 = var8.equals((java.lang.Object)var9);
    org.jfree.chart.LegendItemSource var28 = null;
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
    org.jfree.chart.util.RectangleEdge var30 = var29.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var32 = var31.getNextOutlinePaint();
    var29.setBackgroundPaint(var32);
    org.jfree.chart.util.HorizontalAlignment var34 = var29.getHorizontalAlignment();
    double var35 = var29.getContentYOffset();
    org.jfree.chart.text.TextBlock var36 = new org.jfree.chart.text.TextBlock();
    java.util.List var37 = var36.getLines();
    org.jfree.chart.text.TextLine var38 = null;
    var36.addLine(var38);
    org.jfree.chart.util.HorizontalAlignment var40 = var36.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 1.0d, 100.0d);
    var29.setHorizontalAlignment(var40);
    org.jfree.chart.util.HorizontalAlignment var46 = null;
    org.jfree.chart.LegendItemSource var47 = null;
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle(var47);
    org.jfree.chart.util.RectangleInsets var49 = var48.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var50 = var48.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var53 = new org.jfree.chart.block.ColumnArrangement(var46, var50, 0.0d, 2.0d);
    org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement(var40, var50, 1.0d, 1.0E-8d);
    var8.setLineAlignment(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test267"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var6.getCategoriesForAxis(var30);
    java.awt.Paint var32 = var6.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var6.getRendererForDataset((org.jfree.data.category.CategoryDataset)var33);
    org.jfree.data.general.PieDataset var36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var33, 255);
    org.jfree.data.Range var37 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var33);
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var33, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test268"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var15 = null;
    var13.setSeriesItemLabelsVisible(0, var15, false);
    java.awt.Stroke var18 = var13.getErrorIndicatorStroke();
    java.awt.Paint var19 = null;
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var10, var18, var19);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var18);
    org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
    java.awt.Stroke var23 = var21.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test269"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    java.awt.Paint var12 = var6.getBackgroundPaint();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var16 = null;
    var15.setPlot(var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
    var19.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var25 = null;
    var23.setSeriesItemLabelsVisible(0, var25, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var29 = null;
    var23.setSeriesToolTipGenerator(1, var29, false);
    org.jfree.chart.urls.CategoryURLGenerator var32 = null;
    var23.setBaseURLGenerator(var32);
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.plot.Marker var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    var23.drawRangeMarker(var34, var35, var36, var37, var38);
    boolean var41 = var23.isSeriesVisibleInLegend(0);
    var19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.event.PlotChangeEvent var43 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var19);
    java.awt.Color var48 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var56 = new org.jfree.chart.entity.ChartEntity(var54, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var57 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var59 = null;
    var57.setSeriesItemLabelsVisible(0, var59, false);
    java.awt.Stroke var62 = var57.getErrorIndicatorStroke();
    java.awt.Paint var63 = null;
    org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var54, var62, var63);
    org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var48, var62);
    var19.addRangeMarker((org.jfree.chart.plot.Marker)var65);
    var65.setLabel("TextBlockAnchor.BOTTOM_CENTER");
    org.jfree.chart.util.Layer var69 = null;
    var6.addRangeMarker((org.jfree.chart.plot.Marker)var65, var69);
    var65.setValue(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test270"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var4 = null;
    var2.setSeriesItemLabelsVisible(0, var4, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var2.setSeriesToolTipGenerator(1, var8, false);
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var2.setBaseURLGenerator(var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.Marker var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    var2.drawRangeMarker(var13, var14, var15, var16, var17);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var2.setBaseURLGenerator(var19, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var24 = null;
    var22.setSeriesItemLabelsVisible(0, var24, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
    var22.setSeriesToolTipGenerator(1, var28, false);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var22.setBaseURLGenerator(var31);
    var22.setBaseCreateEntities(false, false);
    var22.setBaseSeriesVisibleInLegend(false);
    var22.setBaseItemLabelsVisible(true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var43 = var41.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var46 = var41.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var47 = var41.getBaseURLGenerator();
    java.lang.Boolean var49 = var41.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var50 = null;
    org.jfree.chart.axis.CategoryAxis var51 = null;
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var53 = null;
    var52.setPlot(var53);
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var50, var51, (org.jfree.chart.axis.ValueAxis)var52, var55);
    java.awt.Stroke var57 = var52.getTickMarkStroke();
    var41.setBaseOutlineStroke(var57);
    org.jfree.chart.labels.ItemLabelPosition var59 = var41.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var60 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var61 = var60.getEntityCollection();
    boolean var62 = var59.equals((java.lang.Object)var60);
    var22.setSeriesPositiveItemLabelPosition(0, var59);
    var2.setPositiveItemLabelPositionFallback(var59);
    org.jfree.data.category.CategoryDataset var66 = null;
    org.jfree.chart.axis.CategoryAxis var67 = null;
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var69 = null;
    var68.setPlot(var69);
    org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var66, var67, (org.jfree.chart.axis.ValueAxis)var68, var71);
    org.jfree.chart.LegendItemSource var73 = null;
    org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
    org.jfree.chart.util.RectangleEdge var75 = var74.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var77 = var76.getNextOutlinePaint();
    var74.setBackgroundPaint(var77);
    var72.setOutlinePaint(var77);
    org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var72);
    var80.fireChartChanged();
    var80.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var84 = var80.getCategoryPlot();
    var84.clearRangeAxes();
    var84.clearDomainMarkers();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var87 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var88 = var87.getPositiveItemLabelPositionFallback();
    java.awt.Paint var91 = var87.getItemLabelPaint((-123), (-1));
    var84.setOutlinePaint(var91);
    var2.setBaseOutlinePaint(var91);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic(var1, var91);
    java.awt.Stroke var95 = var94.getLineStroke();
    java.awt.Shape var96 = var94.getLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var96);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test271"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    boolean var6 = var0.getBaseSeriesVisible();
    var0.setAutoPopulateSeriesPaint(false);
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.urls.CategoryURLGenerator var12 = null;
    var0.setBaseURLGenerator(var12);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var16 = null;
    var14.setSeriesItemLabelsVisible(0, var16, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
    var14.setSeriesToolTipGenerator(1, var20, false);
    org.jfree.chart.urls.CategoryURLGenerator var23 = null;
    var14.setBaseURLGenerator(var23);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.plot.Marker var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var14.drawRangeMarker(var25, var26, var27, var28, var29);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var14.setBaseURLGenerator(var31, true);
    org.jfree.data.statistics.MeanAndStandardDeviation var36 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
    boolean var38 = var36.equals((java.lang.Object)'a');
    boolean var39 = var14.equals((java.lang.Object)var36);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var40 = var14.getLegendItemURLGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var43 = var14.getURLGenerator(10, (-1));
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var45 = null;
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var47 = null;
    var46.setPlot(var47);
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var44, var45, (org.jfree.chart.axis.ValueAxis)var46, var49);
    var50.setAnchorValue(0.0d, true);
    org.jfree.chart.util.RectangleInsets var54 = var50.getAxisOffset();
    java.awt.Paint var55 = var50.getBackgroundPaint();
    var14.setBasePaint(var55);
    var0.setBaseItemLabelPaint(var55, true);
    boolean var59 = var0.getBaseCreateEntities();
    boolean var60 = var0.getBaseSeriesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test272"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var1 = var0.clone();
//     int var2 = var0.size();
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var7 = null;
//     var6.setPlot(var7);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     var10.setAnchorValue(0.0d, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var16 = null;
//     var14.setSeriesItemLabelsVisible(0, var16, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
//     var14.setSeriesToolTipGenerator(1, var20, false);
//     org.jfree.chart.urls.CategoryURLGenerator var23 = null;
//     var14.setBaseURLGenerator(var23);
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.plot.Marker var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     var14.drawRangeMarker(var25, var26, var27, var28, var29);
//     boolean var32 = var14.isSeriesVisibleInLegend(0);
//     var10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     java.util.List var35 = var10.getCategoriesForAxis(var34);
//     java.awt.Paint var36 = var10.getNoDataMessagePaint();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = var10.getRendererForDataset((org.jfree.data.category.CategoryDataset)var37);
//     org.jfree.data.general.PieDataset var40 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var37, (java.lang.Comparable)(-1L));
//     org.jfree.data.category.CategoryDataset var41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)' ', (org.jfree.data.KeyedValues)var40);
//     org.jfree.data.general.PieDataset var45 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var40, (java.lang.Comparable)'a', (-8.0d), 1);
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var49 = null;
//     var48.setPlot(var49);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var51 = null;
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot(var46, var47, (org.jfree.chart.axis.ValueAxis)var48, var51);
//     var48.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var56 = null;
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var48.java2DToValue(0.0d, var56, var57);
//     org.jfree.chart.axis.NumberTickUnit var59 = var48.getTickUnit();
//     org.jfree.data.general.PieDataset var62 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var40, (java.lang.Comparable)var59, 1.0E-8d, 255);
//     org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var64 = var63.getToolTipText();
//     java.awt.Shape var74 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var76 = new org.jfree.chart.entity.ChartEntity(var74, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var77 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var79 = null;
//     var77.setSeriesItemLabelsVisible(0, var79, false);
//     java.awt.Stroke var82 = var77.getErrorIndicatorStroke();
//     java.awt.Paint var83 = null;
//     org.jfree.chart.LegendItem var84 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var74, var82, var83);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var85 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var86 = var85.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var89 = var85.getItemLabelPaint((-123), (-1));
//     org.jfree.chart.LegendItem var90 = new org.jfree.chart.LegendItem("", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "Range[-1.0,-1.0]", var74, var89);
//     var63.setPaint(var89);
//     boolean var92 = var59.equals((java.lang.Object)var89);
//     var0.add((org.jfree.chart.axis.TickUnit)var59);
//     java.lang.String var95 = var59.valueToString(8.45d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var95 + "' != '" + "8"+ "'", var95.equals("8"));
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test273"); }


    java.lang.Comparable var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "Range[-1.0,-1.0]");
    org.jfree.chart.entity.CategoryLabelEntity var7 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var2, "hi!", "");
    java.lang.String var8 = var7.toString();
    var7.setURLText("hi!");
    java.lang.String var11 = var7.toString();
    java.lang.Object var12 = var7.clone();
    java.awt.Shape var13 = var7.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "CategoryLabelEntity: category=null, tooltip=hi!, url="+ "'", var8.equals("CategoryLabelEntity: category=null, tooltip=hi!, url="));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "CategoryLabelEntity: category=null, tooltip=hi!, url=hi!"+ "'", var11.equals("CategoryLabelEntity: category=null, tooltip=hi!, url=hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test274"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     org.jfree.chart.text.TextBlock var3 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.util.Size2D var5 = var3.calculateDimensions(var4);
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var10 = null;
//     var9.setPlot(var10);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var7, var8, (org.jfree.chart.axis.ValueAxis)var9, var12);
//     java.awt.Stroke var14 = var9.getTickMarkStroke();
//     java.awt.Font var15 = var9.getLabelFont();
//     java.awt.Color var18 = java.awt.Color.getColor("", (-1));
//     var3.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var15, (java.awt.Paint)var18);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var22 = var20.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var23 = null;
//     var20.setBaseItemLabelGenerator(var23);
//     java.awt.Paint var27 = var20.getItemFillPaint(0, (-855310));
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("NOID", var15, var27, 2.0f);
//     var1.addFragment(var29);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var34 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var35 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var36 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var34, var35);
//     org.jfree.chart.util.RectangleAnchor var37 = var35.getCategoryAnchor();
//     float var38 = var35.getWidthRatio();
//     org.jfree.chart.text.TextAnchor var39 = var35.getRotationAnchor();
//     var29.draw(var31, 0.8f, 2.0f, var39, 0.0f, 0.0f, (-8.0d));
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test275"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    boolean var5 = var0.equals((java.lang.Object)var4);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var8, var11);
    var12.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = null;
    var16.setSeriesItemLabelsVisible(0, var18, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var16.setSeriesToolTipGenerator(1, var22, false);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var16.setBaseURLGenerator(var25);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.plot.Marker var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    var16.drawRangeMarker(var27, var28, var29, var30, var31);
    boolean var34 = var16.isSeriesVisibleInLegend(0);
    var12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    boolean var36 = var0.equals((java.lang.Object)var16);
    java.awt.Paint var38 = var16.getSeriesOutlinePaint(1);
    org.jfree.chart.event.RendererChangeEvent var39 = null;
    var16.notifyListeners(var39);
    org.jfree.data.category.CategoryDataset var42 = null;
    org.jfree.chart.axis.CategoryAxis var43 = null;
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var45 = null;
    var44.setPlot(var45);
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var42, var43, (org.jfree.chart.axis.ValueAxis)var44, var47);
    boolean var49 = var48.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var51 = var48.getDataset((-123));
    var48.clearRangeMarkers(0);
    java.awt.Paint var54 = var48.getBackgroundPaint();
    var48.setAnchorValue((-1.0d));
    org.jfree.chart.util.RectangleInsets var57 = var48.getInsets();
    org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis();
    var58.setMaximumCategoryLabelWidthRatio(0.95f);
    double var61 = var58.getLowerMargin();
    java.lang.Object var62 = var58.clone();
    java.awt.Font var64 = var58.getTickLabelFont((java.lang.Comparable)"null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    int var65 = var58.getCategoryLabelPositionOffset();
    java.awt.Font var67 = var58.getTickLabelFont((java.lang.Comparable)2.0f);
    var58.addCategoryLabelToolTip((java.lang.Comparable)"RectangleAnchor.CENTER", "CategoryLabelWidthType.CATEGORY");
    var58.setLowerMargin((-8.0d));
    double var73 = var58.getCategoryMargin();
    java.util.List var74 = var48.getCategoriesForAxis(var58);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var75 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var76 = null;
    var75.setBaseURLGenerator(var76);
    org.jfree.data.category.CategoryDataset var78 = null;
    org.jfree.chart.axis.CategoryAxis var79 = null;
    org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var81 = null;
    var80.setPlot(var81);
    org.jfree.chart.renderer.category.CategoryItemRenderer var83 = null;
    org.jfree.chart.plot.CategoryPlot var84 = new org.jfree.chart.plot.CategoryPlot(var78, var79, (org.jfree.chart.axis.ValueAxis)var80, var83);
    var84.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var88 = var84.getDomainAxis();
    int var89 = var84.getWeight();
    boolean var90 = var75.hasListener((java.util.EventListener)var84);
    java.awt.Paint var93 = var75.getItemFillPaint((-621738), 15);
    var48.setBackgroundPaint(var93);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setSeriesOutlinePaint((-16777212), var93, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test276"); }


    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
    var2.setURLText("");
    java.lang.String var5 = var2.getToolTipText();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    boolean var7 = var6.isNegativeArrowVisible();
    java.lang.String var8 = var6.getLabelURL();
    var6.setLabelAngle(6.0d);
    var6.setAutoRange(false);
    java.lang.Object var13 = var6.clone();
    double var14 = var6.getLowerMargin();
    org.jfree.chart.plot.Plot var15 = var6.getPlot();
    org.jfree.data.KeyedObjects2D var18 = new org.jfree.data.KeyedObjects2D();
    java.util.List var19 = var18.getColumnKeys();
    int var21 = var18.getRowIndex((java.lang.Comparable)100);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    boolean var23 = var22.isNegativeArrowVisible();
    java.lang.String var24 = var22.getLabelURL();
    var22.setLabelAngle(6.0d);
    var22.setAutoRange(false);
    java.awt.Font var29 = var22.getTickLabelFont();
    var18.setObject((java.lang.Object)var29, (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=", (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var34 = var33.getPositiveItemLabelPositionFallback();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var36 = var35.getPositiveItemLabelPositionFallback();
    java.awt.Paint var39 = var35.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var43 = null;
    var42.setPlot(var43);
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot(var40, var41, (org.jfree.chart.axis.ValueAxis)var42, var45);
    java.awt.Stroke var47 = var42.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var48 = null;
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle(var48);
    org.jfree.chart.util.RectangleInsets var50 = var49.getItemLabelPadding();
    double var51 = var50.getTop();
    org.jfree.chart.block.LineBorder var52 = new org.jfree.chart.block.LineBorder(var39, var47, var50);
    var33.setBaseOutlinePaint(var39);
    java.awt.Paint var54 = var33.getBaseFillPaint();
    org.jfree.chart.text.TextFragment var56 = new org.jfree.chart.text.TextFragment("HorizontalAlignment.CENTER", var29, var54, 1.0f);
    org.jfree.chart.text.TextLine var57 = new org.jfree.chart.text.TextLine("RectangleAnchor.CENTER", var29);
    var6.setLabelFont(var29);
    var2.setFont(var29);
    org.jfree.chart.block.LabelBlock var60 = new org.jfree.chart.block.LabelBlock("PlotOrientation.VERTICAL", var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test277"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    java.awt.Paint var3 = var1.getItemPaint();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextOutlinePaint();
    var13.setBackgroundPaint(var16);
    var11.setOutlinePaint(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var11);
    var19.fireChartChanged();
    boolean var21 = var19.getAntiAlias();
    java.util.List var22 = var19.getSubtitles();
    var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    var19.fireChartChanged();
    boolean var25 = var19.isNotify();
    org.jfree.chart.plot.Plot var26 = var19.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test278"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var4 = var3.getPadding();
    double var6 = var4.calculateTopInset(100.0d);
    double var8 = var4.calculateTopInset(2.0d);
    var0.setLabelInsets(var4);
    org.jfree.chart.axis.CategoryLabelPositions var10 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var11 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var12 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var10, var11);
    float var13 = var11.getWidthRatio();
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, (-1.0d));
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, (-1.0d));
    org.jfree.data.Range var20 = org.jfree.data.Range.combine(var16, var19);
    double var21 = var20.getLowerBound();
    boolean var22 = var11.equals((java.lang.Object)var20);
    double var24 = var20.constrain(0.0d);
    var0.setDefaultAutoRange(var20);
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var29 = null;
    var28.setPlot(var29);
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var26, var27, (org.jfree.chart.axis.ValueAxis)var28, var31);
    boolean var33 = var32.isOutlineVisible();
    boolean var34 = var0.hasListener((java.util.EventListener)var32);
    boolean var35 = var0.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test279"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var2 = var0.getWidth();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, (-1.0d));
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, (-1.0d));
    org.jfree.data.Range var13 = org.jfree.data.Range.combine(var9, var12);
    double var14 = var12.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var15 = var6.toRangeHeight(var12);
    org.jfree.chart.util.Size2D var16 = var0.arrange(var3, var15);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.util.Size2D var18 = var0.arrange(var17);
    java.lang.Object var19 = var18.clone();
    double var20 = var18.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test280"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test281"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var2 = null;
//     var0.addObject((java.lang.Comparable)'#', var2);
//     java.lang.Object var4 = var0.clone();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     var7.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var7.java2DToValue(0.0d, var15, var16);
//     org.jfree.chart.axis.NumberTickUnit var18 = var7.getTickUnit();
//     int var19 = var0.getIndex((java.lang.Comparable)var18);
//     java.lang.Object var21 = var0.getObject((-855310));
//     java.lang.Object var23 = var0.getObject((-855310));
//     java.lang.Object var25 = var0.getObject((java.lang.Comparable)(-0.55d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test282"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getBaseItemLabelGenerator();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
//     var0.setBaseItemLabelGenerator(var11);
//     double var13 = var0.getMaximumBarWidth();
//     java.lang.Boolean var15 = var0.getSeriesCreateEntities(0);
//     var0.setAutoPopulateSeriesStroke(false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var21 = var19.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var19.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var25 = var19.getBaseURLGenerator();
//     java.lang.Boolean var27 = var19.getSeriesItemLabelsVisible((-855310));
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var31 = null;
//     var30.setPlot(var31);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var28, var29, (org.jfree.chart.axis.ValueAxis)var30, var33);
//     java.awt.Stroke var35 = var30.getTickMarkStroke();
//     var19.setBaseOutlineStroke(var35);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var19.getBaseNegativeItemLabelPosition();
//     int var38 = var19.getPassCount();
//     org.jfree.chart.urls.CategoryURLGenerator var39 = var19.getBaseURLGenerator();
//     java.awt.Shape var41 = var19.lookupSeriesShape(4);
//     var0.setSeriesShape(0, var41);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test283"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Comparable var3 = null;
    var0.add((java.lang.Number)(short)0, (java.lang.Number)2.0d, var3, (java.lang.Comparable)"RectangleAnchor.CENTER");
    java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0d+ "'", var6.equals(0.0d));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test284"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("org.jfree.chart.event.ChartChangeEvent[source=hi!]");

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test285"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
    var0.setBaseItemLabelGenerator(var11);
    org.jfree.data.KeyedObjects2D var13 = new org.jfree.data.KeyedObjects2D();
    java.util.List var14 = var13.getColumnKeys();
    java.lang.Object var17 = var13.getObject((java.lang.Comparable)(-1), (java.lang.Comparable)0L);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var19 = var18.getPositiveItemLabelPositionFallback();
    java.awt.Paint var22 = var18.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var26 = null;
    var25.setPlot(var26);
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var23, var24, (org.jfree.chart.axis.ValueAxis)var25, var28);
    java.awt.Stroke var30 = var25.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var31 = null;
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
    org.jfree.chart.util.RectangleInsets var33 = var32.getItemLabelPadding();
    double var34 = var33.getTop();
    org.jfree.chart.block.LineBorder var35 = new org.jfree.chart.block.LineBorder(var22, var30, var33);
    java.awt.Stroke var36 = var35.getStroke();
    var13.setObject((java.lang.Object)var35, (java.lang.Comparable)"", (java.lang.Comparable)4.0d);
    java.awt.Paint var40 = var35.getPaint();
    java.awt.Paint var41 = var35.getPaint();
    var0.setBaseFillPaint(var41, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test286"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    java.awt.Stroke var12 = var7.getTickMarkStroke();
    var7.setVerticalTickLabels(false);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var18 = null;
    var17.setPlot(var18);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
    var21.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var27 = null;
    var25.setSeriesItemLabelsVisible(0, var27, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var25.setSeriesToolTipGenerator(1, var31, false);
    org.jfree.chart.urls.CategoryURLGenerator var34 = null;
    var25.setBaseURLGenerator(var34);
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.plot.Marker var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var25.drawRangeMarker(var36, var37, var38, var39, var40);
    boolean var43 = var25.isSeriesVisibleInLegend(0);
    var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    var7.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    var0.configure();
    double var48 = var0.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.05d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test287"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    java.awt.Paint var3 = var1.getItemPaint();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var16 = var15.getNextOutlinePaint();
    var13.setBackgroundPaint(var16);
    var11.setOutlinePaint(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var11);
    var19.fireChartChanged();
    boolean var21 = var19.getAntiAlias();
    java.util.List var22 = var19.getSubtitles();
    var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    var19.fireChartChanged();
    float var25 = var19.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.5f);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test288"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleEdge var3 = var2.getLegendItemGraphicEdge();
    boolean var4 = var0.equals((java.lang.Object)var2);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    boolean var12 = var11.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var14 = var11.getDataset((-123));
    var11.clearRangeMarkers(0);
    java.awt.Paint var17 = var11.getBackgroundPaint();
    var11.setAnchorValue((-1.0d));
    org.jfree.chart.util.RectangleEdge var21 = var11.getRangeAxisEdge((-855310));
    boolean var22 = var0.equals((java.lang.Object)var11);
    org.jfree.chart.axis.AxisSpace var23 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var24 = var23.clone();
    org.jfree.chart.axis.AxisSpace var25 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var26 = var25.clone();
    org.jfree.chart.axis.AxisSpace var27 = new org.jfree.chart.axis.AxisSpace();
    var25.ensureAtLeast(var27);
    double var29 = var27.getTop();
    var23.ensureAtLeast(var27);
    var11.setFixedDomainAxisSpace(var27);
    var27.setTop((-0.55d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test289"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("AxisLabelEntity: label = null", "java.awt.Color[r=242,g=242,b=242]", "LengthConstraintType.FIXED", "[size=1]");

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test290"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setGenerateEntities(false);
    var0.setGenerateEntities(true);
    var0.setGenerateEntities(false);
    var0.setTranslateX(0.2d);
    var0.setTranslateY(0.0d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test291"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.lang.Object var3 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test292"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    double var3 = var0.getLowerMargin();
    java.awt.Shape var4 = var0.getDownArrow();
    org.jfree.chart.entity.TickLabelEntity var7 = new org.jfree.chart.entity.TickLabelEntity(var4, "Range[10.0,10.0]", "SortOrder.ASCENDING");
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test293"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    var0.setMaximumBarWidth((-8.0d));
    java.awt.Paint var7 = null;
    var0.setErrorIndicatorPaint(var7);
    var0.setSeriesItemLabelsVisible(4, true);
    boolean var12 = var0.getBaseCreateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test294"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    var6.clearDomainMarkers();
    org.jfree.chart.util.SortOrder var15 = var6.getRowRenderingOrder();
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var20 = null;
    var19.setPlot(var20);
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var17, var18, (org.jfree.chart.axis.ValueAxis)var19, var22);
    boolean var24 = var23.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var26 = var23.getDataset((-123));
    var23.clearRangeMarkers(0);
    java.awt.Paint var29 = var23.getBackgroundPaint();
    var23.setAnchorValue((-1.0d));
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.axis.CategoryAxis var33 = null;
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var35 = null;
    var34.setPlot(var35);
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var34, var37);
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var40 = null;
    var39.setPlot(var40);
    org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var39};
    var38.setRangeAxes(var42);
    java.awt.Paint var44 = var38.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var45 = null;
    org.jfree.chart.axis.CategoryAxis var46 = null;
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var48 = null;
    var47.setPlot(var48);
    org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var45, var46, (org.jfree.chart.axis.ValueAxis)var47, var50);
    var51.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var55 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var57 = null;
    var55.setSeriesItemLabelsVisible(0, var57, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var61 = null;
    var55.setSeriesToolTipGenerator(1, var61, false);
    org.jfree.chart.urls.CategoryURLGenerator var64 = null;
    var55.setBaseURLGenerator(var64);
    java.awt.Graphics2D var66 = null;
    org.jfree.chart.plot.CategoryPlot var67 = null;
    org.jfree.chart.axis.ValueAxis var68 = null;
    org.jfree.chart.plot.Marker var69 = null;
    java.awt.geom.Rectangle2D var70 = null;
    var55.drawRangeMarker(var66, var67, var68, var69, var70);
    boolean var73 = var55.isSeriesVisibleInLegend(0);
    var51.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var55);
    org.jfree.chart.util.Layer var76 = null;
    java.util.Collection var77 = var51.getDomainMarkers(10, var76);
    org.jfree.chart.axis.AxisLocation var79 = var51.getDomainAxisLocation((-1));
    java.lang.String var80 = var79.toString();
    var38.setRangeAxisLocation(var79);
    var23.setRangeAxisLocation(var79, false);
    var6.setRangeAxisLocation(255, var79, false);
    org.jfree.chart.axis.AxisLocation var86 = org.jfree.chart.axis.AxisLocation.getOpposite(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var80.equals("AxisLocation.TOP_OR_RIGHT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test295"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    org.jfree.chart.plot.Plot var18 = var15.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var20 = var15.getSubtitle((-124390));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test296"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.util.List var7 = var6.getLines();
    boolean var8 = var1.equals((java.lang.Object)var6);
    org.jfree.chart.util.RectangleEdge var9 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var10 = var1.getLegendItemGraphicLocation();
    java.lang.Object var11 = var1.clone();
    org.jfree.chart.util.HorizontalAlignment var12 = var1.getHorizontalAlignment();
    org.jfree.data.general.DatasetGroup var13 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.LegendItemSource var14 = null;
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
    org.jfree.chart.util.RectangleEdge var16 = var15.getLegendItemGraphicEdge();
    boolean var17 = var13.equals((java.lang.Object)var15);
    org.jfree.chart.util.StandardGradientPaintTransformer var18 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var19 = var18.clone();
    boolean var20 = var15.equals((java.lang.Object)var18);
    org.jfree.chart.LegendItemSource[] var21 = var15.getSources();
    var1.setSources(var21);
    java.lang.String var23 = var1.getID();
    org.jfree.chart.util.RectangleAnchor var24 = var1.getLegendItemGraphicLocation();
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var26 = null;
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var28 = null;
    var27.setPlot(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var25, var26, (org.jfree.chart.axis.ValueAxis)var27, var30);
    boolean var32 = var31.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var34 = var31.getDataset((-123));
    var31.clearRangeMarkers(0);
    java.awt.Paint var37 = var31.getBackgroundPaint();
    var31.setAnchorValue((-1.0d));
    org.jfree.chart.util.RectangleEdge var41 = var31.getRangeAxisEdge((-855310));
    var1.setLegendItemGraphicEdge(var41);
    org.jfree.chart.util.HorizontalAlignment var43 = null;
    org.jfree.chart.LegendItemSource var44 = null;
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle(var44);
    org.jfree.chart.util.RectangleInsets var46 = var45.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var47 = var45.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var43, var47, 0.0d, 2.0d);
    org.jfree.data.general.Dataset var51 = null;
    org.jfree.chart.title.LegendItemBlockContainer var53 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var50, var51, (java.lang.Comparable)Double.NaN);
    org.jfree.data.general.Dataset var54 = var53.getDataset();
    org.jfree.data.general.Dataset var55 = var53.getDataset();
    var1.setWrapper((org.jfree.chart.block.BlockContainer)var53);
    java.awt.Paint var57 = var1.getItemPaint();
    java.awt.Paint var58 = var1.getItemPaint();
    org.jfree.chart.block.BlockContainer var59 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var60 = var59.getPadding();
    double var62 = var60.calculateRightOutset(0.0d);
    double var64 = var60.extendHeight(8.45d);
    var1.setLegendItemGraphicPadding(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 8.45d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test297"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    boolean var18 = var17.getDrawSharedDomainAxis();
    var17.setDrawSharedDomainAxis(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test298"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    boolean var3 = var2.isNegativeArrowVisible();
    java.lang.String var4 = var2.getLabelURL();
    var2.setLabelAngle(6.0d);
    float var7 = var2.getTickMarkOutsideLength();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    var8.setLowerBound(2.0d);
    java.lang.String var13 = var8.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var14 = var8.getTickUnit();
    int var15 = var14.getMinorTickCount();
    var2.setTickUnit(var14, true, true);
    var0.add((org.jfree.chart.axis.TickUnit)var14);
    int var20 = var0.size();
    java.lang.Object var21 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test299"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.util.Layer var31 = null;
    java.util.Collection var32 = var6.getDomainMarkers(10, var31);
    java.awt.Stroke var33 = var6.getOutlineStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var37 = var35.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var40 = var35.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var41 = var35.getBaseURLGenerator();
    java.lang.Boolean var43 = var35.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var46 = java.awt.Color.getColor("", (-1));
    var35.setBasePaint((java.awt.Paint)var46, true);
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var50 = null;
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var52 = null;
    var51.setPlot(var52);
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var49, var50, (org.jfree.chart.axis.ValueAxis)var51, var54);
    boolean var56 = var55.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var58 = var55.getDataset((-123));
    var55.clearRangeMarkers(0);
    java.awt.Color var65 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var71 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var73 = new org.jfree.chart.entity.ChartEntity(var71, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var74 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var76 = null;
    var74.setSeriesItemLabelsVisible(0, var76, false);
    java.awt.Stroke var79 = var74.getErrorIndicatorStroke();
    java.awt.Paint var80 = null;
    org.jfree.chart.LegendItem var81 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var71, var79, var80);
    org.jfree.chart.plot.ValueMarker var82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var65, var79);
    var55.setDomainGridlineStroke(var79);
    var35.addChangeListener((org.jfree.chart.event.RendererChangeListener)var55);
    org.jfree.chart.axis.AxisLocation var86 = var55.getDomainAxisLocation(10);
    org.jfree.chart.axis.AxisLocation var87 = org.jfree.chart.axis.AxisLocation.getOpposite(var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRangeAxisLocation((-16777216), var87);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test300"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setNotify(false);
    var15.fireChartChanged();
    var15.setNotify(false);
    org.jfree.chart.title.Title var23 = var15.getSubtitle(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test301"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    org.jfree.chart.text.TextLine var2 = null;
    var0.addLine(var2);
    org.jfree.chart.util.HorizontalAlignment var4 = var0.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement(var4, var5, 1.0d, 100.0d);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.text.TextBlock var10 = new org.jfree.chart.text.TextBlock();
    java.util.List var11 = var10.getLines();
    org.jfree.chart.text.TextLine var12 = null;
    var10.addLine(var12);
    org.jfree.chart.util.HorizontalAlignment var14 = var10.getLineAlignment();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var19 = var17.toFixedWidth(0.05d);
    boolean var20 = var14.equals((java.lang.Object)var19);
    var9.setTextAlignment(var14);
    org.jfree.chart.block.BlockFrame var22 = var9.getFrame();
    java.awt.Font var23 = var9.getFont();
    org.jfree.chart.LegendItemSource var24 = null;
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
    org.jfree.chart.util.RectangleEdge var26 = var25.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var27 = null;
    var25.setLegendItemGraphicLocation(var27);
    org.jfree.chart.util.HorizontalAlignment var29 = var25.getHorizontalAlignment();
    org.jfree.chart.util.Size2D var30 = new org.jfree.chart.util.Size2D();
    boolean var32 = var30.equals((java.lang.Object)(-1L));
    double var33 = var30.getWidth();
    boolean var34 = var29.equals((java.lang.Object)var30);
    var9.setTextAlignment(var29);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    var8.add((org.jfree.chart.block.Block)var9, (java.lang.Object)var37);
    var8.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test302"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    boolean var11 = var0.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test303"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(2.0d);
    org.jfree.chart.LegendItemSource var3 = null;
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
    org.jfree.chart.util.RectangleEdge var5 = var4.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var7 = var6.getNextOutlinePaint();
    var4.setBackgroundPaint(var7);
    org.jfree.chart.text.TextBlock var9 = new org.jfree.chart.text.TextBlock();
    java.util.List var10 = var9.getLines();
    boolean var11 = var4.equals((java.lang.Object)var9);
    org.jfree.chart.util.RectangleEdge var12 = var4.getLegendItemGraphicEdge();
    var1.moveCursor(2.0d, var12);
    org.jfree.chart.axis.AxisSpace var15 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.axis.AxisCollection var17 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var18 = var17.getAxesAtTop();
    boolean var19 = var15.equals((java.lang.Object)var17);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var21 = null;
    var20.setPlot(var21);
    var20.setLowerBound(2.0d);
    java.lang.String var25 = var20.getLabelToolTip();
    java.awt.Shape var26 = var20.getRightArrow();
    org.jfree.chart.LegendItemSource var27 = null;
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle(var27);
    org.jfree.chart.util.RectangleEdge var29 = var28.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var30 = org.jfree.chart.util.RectangleEdge.opposite(var29);
    boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
    var17.add((org.jfree.chart.axis.Axis)var20, var30);
    var1.moveCursor(6.0d, var30);
    java.util.List var34 = var1.getTicks();
    var1.setCursor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

}
